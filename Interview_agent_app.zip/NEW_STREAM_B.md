# NEW_STREAM_B — design plan (review before building)

> **Status:** plan only. No code yet. Read top-to-bottom, leave inline
> comments / call-outs for anything you want changed, then we start building.

This document plans the **complete revamp** of Stream B. The goal is to
replace `STREAM_A_B_Integration/stream_b/` and `STREAM_A_B_Integration/orchestrator/`
with two new directories:

1. **`orchestrator_new/`** — a *thin* shim. Boots Stream A's STT/VAD/TTS
   processes, opens the mic + speakers, hands control to Stream B. **Owns no
   agent logic.**
2. **`stream_b_new/`** — a fully agentic interviewer. Owns its own connections
   to Stream A (no orchestrator-side bridging), runs a director-with-sub-agents
   pattern, exposes tools the LLMs can call to mutate session state, and ships
   a real **latency orchestrator** that handles fast/slow LLM coordination
   plus an "I need a moment" fallback.

The plan is grounded in three sources:

- **`Final_Interview_app_plan.docx`** — the SSOT document. Sections relevant
  here: §1 (system overview), §3.2 (agent loop), §4 (contracts), §6 (Stream B
  scope and tickets B-01…B-08), §14 (latency budget).
- **`STREAM_A_B_Integration/README.md`** — the brutally honest post-mortem of
  what broke in v1. Every "Known issue + temporary fix" section is a
  requirement for v2 to do better.
- **The existing `stream_b/` and `orchestrator/`** — a working baseline we
  can crib contracts from (Phase enum, EventKind, WS message formats).

---

## 1. Why a revamp (what v1 got wrong)

These are quoted from `README.md` and re-organised by category. v2 must address
each one architecturally, not with another orchestrator-side patch.

### 1.1 The `TTSSender` was write-only — root cause of 4 separate bugs

> §5a: "Stream B's `TTSSender` (…) only ever calls `ws.send(...)` — it never
> calls `ws.recv()`. There is no reader task."

This single omission caused:

- **Connection death** (`1011 keepalive ping timeout` after ~30s) because the
  `websockets` library's recv queue filled and stopped processing pongs.
  Bandaged in v1 via `_drain_tts` in `orchestrator/stream_a_bridge.py`.
- **No `tts_audio_start` / `tts_audio_end` events** in Stream B itself.
  Bandaged in v1 by having the bridge emit them out-of-band into the event log.
- **No way for `AgentSession` to know when audio actually finished playing.**
  This is what forced the "AI talks over itself" and "AI hallucinates
  back-to-back turns" workarounds, both implemented in the bridge with private
  field pokes (`session._last_any_speech_ms = ...`).

**v2 fix:** Stream B owns the TTS WebSocket end-to-end. The TTS client has a
parallel reader task (the upstream fix the v1 README explicitly calls for).
Audio lifecycle events become first-class `EventKind` values. `_ai_active`
becomes a real piece of `SessionState`, not a private flag on a bridge.

### 1.2 Sentence-level streaming collided with per-turn `request_id`

> §"What I had to change in the bundled sources" / "Stream B: tts_sender.py":
> "Stream A's TTS service rejects duplicate `request_id`s (…) the 2nd and
> later speaks crashed on Stream A's `register` call — `_run_speak` task died
> silently, no `audio_start`/`audio_end` ever fired for them, and the text was
> lost. The candidate heard only the first sentence of each turn."

v1 worked around this by minting `<turn-id>-<flush-counter>` sub-IDs and
broadcasting cancels across all active sub-IDs. **v2 makes that the native
behaviour** of the new TTS client — no sub-ID hack required, just a
`speak_chunk(turn_id, sequence_id, text)` API that's correct by design.

### 1.3 Filler timing was wrong (VAD endpoint vs STT final)

> §F1 / Status: "v1's VAD-endpoint trigger fired too eagerly on background
> noise."

v2 fires fillers off **STT final** by default, and only when `_ai_active`
suggests we're going to be slow. Pulled into the latency orchestrator as a
first-class state machine, not a side-loaded `FillerOrchestrator`.

### 1.4 Barge-in fired on every VAD speech_start, including monologue audio

> §3 (Behavioural / tuning issues): "12 of 21 AI turns got cut off mid-sentence
> in our e2e run. The AI never got to complete a meaningful response."

v2 only treats VAD speech_start as a barge-in when **TTS is actually playing
audio** (i.e. `_ai_active == AUDIO_PLAYING`, not just `LLM_GENERATING`). The
guard becomes a pure function of session state.

### 1.5 No real conversation-context awareness for the LLM

The v1 prompts didn't tell the LLM things like "you were barged in mid-word 7
of a 12-word sentence" or "the candidate has been silent for 14 seconds and you
just played a filler that said 'Got it, let me think'". This is the
single biggest lever for making the AI sound natural — the LLM has to know
what just happened in the audio world.

v2 makes the **conversation context object** explicit and rich. Every LLM call
gets it.

### 1.6 Observability was shallow

The v1 event log captures Stream B's own events plus a handful of
integration-side ones, but doesn't capture: the actual prompt sent to each
LLM, the LLM's tool-call decision before mutation, sub-agent invocations, or
phase-transition reasoning. v2 traces all of these by default.

---

## 2. Where v2 sits relative to the SSOT doc

The SSOT doc plans a **production** Stream B with FSM, policy, prompts, LLM
client, context assembler, agent loop, etc. (§6, tickets B-01…B-08). v2 is a
faithful implementation of that — except:

| SSOT calls for | v2 deviation | Why |
|---|---|---|
| Anthropic Claude Opus via streaming + prompt caching | OpenRouter (DeepSeek-V3.2 slow / `gpt-4o-mini` fast) by default; provider abstracted | Matches what we're already paying for; SSOT calls out swap in §5 fallback row |
| Redis + Postgres tiered store | In-memory `SessionStore` with a clean adapter interface; JSONL event sink remains | Live mic loop on a single laptop has no Redis. Adapter lets us add Redis later without touching agent code |
| Microsoft Teams `.NET` bot for audio | Local mic + speakers via Stream A | Teams bot is Stream D, out of scope for this revamp. The `AudioSource` / `AudioSink` interfaces in §4 below preserve the SSOT invariant ("switching between sources is a single env-var change", §11.2 of SSOT) |
| FSM with 7 phases | Same 7 phases, same transitions | Direct lift. Existing `contracts/session_state.py:Phase` keeps its values |
| Tool-call schema named `respond` | Multiple tools (§5 below): `respond`, `update_score`, `transition_phase`, `flag_integrity`, `request_clarification` | SSOT §4.4 describes one combined tool. v2 splits them so each is independently testable and the LLM's intent is explicit. The `respond` tool stays as the primary; the others are sub-tools the director can call between turns |

Everything else (FSM transitions, turn-taking rules, latency budget targets,
event log shape) follows the SSOT.

---

## 3. High-level architecture

```
┌─ orchestrator_new/ ──── thin shim ─────────────────────────────────────────┐
│                                                                            │
│  mic ──────► MicAudioSource ───┐                                           │
│                                │ raw PCM16 frames                          │
│                                ▼                                           │
│  speakers ◄── SpeakerAudioSink ┐                                           │
│                                │ raw PCM16 frames                          │
│                                ▼                                           │
│                       InterviewSession.run()  ◄──── ALL the brain          │
│                                                     lives here, in         │
│                                                     stream_b_new/          │
└────────────────────────────────────────────────────────────────────────────┘

┌─ stream_b_new/ ──── owns Stream A connections + agent ─────────────────────┐
│                                                                            │
│  ┌─ streamA_bridge/ ─ thin WS clients with parallel readers ─────────────┐ │
│  │   STTClient   ◄── partials / finals + words ─────────────────────────┐│ │
│  │   VADClient   ◄── speech_start / speech_end / endpoint ──────────────┤│ │
│  │   TTSClient   ◄── audio_start / audio_end / cancelled / PCM frames ──┘│ │
│  │      (the v1 TTSSender bug is fixed here — parallel reader task)      │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
│                              │                                             │
│  ┌─ core/ ─────────────────  ▼  ──────────────────────────────────────────┐│
│  │   EventBus  ◄────  every WS event lands here, every state change      ││
│  │      │             writes here, every LLM call traces through here    ││
│  │      ▼                                                                  ││
│  │   SessionStore  ◄── single source of truth for SessionState            ││
│  │      ▲                                                                  ││
│  │      │                                                                  ││
│  │   Director   ◄── 500ms tick. Owns the agentic decision loop.            ││
│  │      │                                                                  ││
│  │      ├─ TurnTakingPolicy   — pure fn, decides YES/NO/WAIT               ││
│  │      ├─ LatencyOrchestrator — fast LLM / slow LLM / apology arbiter     ││
│  │      ├─ BargeInGuard        — pure fn, decides whether to cancel TTS    ││
│  │      └─ PhaseMachine        — FSM, decides phase transitions            ││
│  │                                                                         ││
│  │   Sub-agents (each is a tool-using LLM session, sharing SessionStore)   ││
│  │      ├─ QuestionAgent     — slow LLM, generates next interviewer turn   ││
│  │      ├─ FillerAgent       — fast LLM, generates noncommittal ack        ││
│  │      ├─ ApologyAgent      — canned phrase ("Give me a second…")         ││
│  │      ├─ ScorerAgent       — slow LLM (async), updates rubric            ││
│  │      ├─ SummarizerAgent   — cheap LLM (async), compresses old turns     ││
│  │      └─ IntegrityAgent    — slow LLM (async), watches for cheating      ││
│  └─────────────────────────────────────────────────────────────────────────┘│
│                                                                            │
│  ┌─ observability/ ─ structured tracing ─────────────────────────────────┐ │
│  │   tracer.span(name, **fields) → measures + emits events                │ │
│  │   event_log.jsonl                                                       │ │
│  │   langfuse adapter (optional, when env set)                             │ │
│  └────────────────────────────────────────────────────────────────────────┘│
└────────────────────────────────────────────────────────────────────────────┘
```

The key reorganisation: **the bridge moves into stream_b_new**. v1 had the
bridge in the orchestrator because Stream B's `TTSSender` couldn't read; the
orchestrator had to step in. With v2's TTS client owning the read direction,
the bridge has no reason to live outside Stream B.

---

## 4. `orchestrator_new/` — what it actually does

Three files, ~300 lines total. Its job is just to put audio in front of Stream B.

```
orchestrator_new/
├── __init__.py
├── live_main.py        # CLI entry point — argparse, signal handling, banner
├── audio_source.py     # MicAudioSource — async iterator yielding PCM16 frames
├── audio_sink.py       # SpeakerAudioSink — accepts PCM16 chunks, plays them
└── stream_a_boot.py    # subprocess launcher for Stream A STT/VAD/TTS
```

### 4.1 `AudioSource` / `AudioSink` interfaces

Mirroring the SSOT's §11.2 "fake audio source" invariant — Stream B sees a
narrow interface, not the implementation:

```python
# in stream_b_new/contracts/audio.py
class AudioSource(Protocol):
    async def frames(self) -> AsyncIterator[bytes]:
        """Yield 20ms PCM16 mono frames at 16kHz (640 bytes each)."""

class AudioSink(Protocol):
    async def play(self, pcm: bytes) -> None:
        """Append PCM16 mono samples to the playback buffer."""

    async def stop(self) -> None:
        """Stop playback and clear the buffer (used on barge-in)."""
```

`MicAudioSource` (orchestrator) wraps `sounddevice.InputStream`.
`SpeakerAudioSink` (orchestrator) wraps `sounddevice.OutputStream`.

A future `WavFileAudioSource` and `TeamsBotAudioSource` would slot in
identically — that's the invariant from SSOT §11.2.

### 4.2 `live_main.py` — the only entry point worth ~200 lines

```python
async def main_async() -> int:
    args = _parse_args()
    settings = load_settings()                                    # OPENROUTER_API_KEY etc.
    await stream_a_boot.ensure_running(args)                      # boot or skip if already up

    source = MicAudioSource(sample_rate=16_000)
    sink   = SpeakerAudioSink(sample_rate=args.tts_sample_rate)

    async with InterviewSession(
        candidate_profile=CandidateProfile(...),
        audio_source=source,
        audio_sink=sink,
        config=load_session_config(args),                          # tick_ms, model picks, thresholds
    ) as session:
        await session.run_until_signal()                           # SIGINT-aware

    print(session.summary())
    return 0
```

Key points:

- The orchestrator **does not** import `services.agent.*`. It depends only on
  `stream_b_new.runtime.InterviewSession` and the audio interfaces.
- The orchestrator **does not** know about WebSockets, fillers, sub-agents, or
  state machines. Every one of those is private to Stream B.
- The orchestrator is responsible for booting Stream A subprocesses (or
  refusing to run if they're not up). The current `scripts/run_live.sh` already
  does this; we'll port it.

---

## 5. `stream_b_new/` — directory structure

```
stream_b_new/
├── pyproject.toml
├── contracts/
│   ├── __init__.py
│   ├── audio.py                  # AudioSource / AudioSink protocols (§4.1)
│   ├── events.py                 # EventKind enum (extended)
│   ├── session_state.py          # Phase, Speaker, Turn, SessionState (lifted from v1, extended)
│   ├── tool_schema.py            # JSON-schemas for the 5 LLM tools
│   └── ws_messages.py            # STT/VAD/TTS WS payload models
│
├── streamA_bridge/
│   ├── __init__.py
│   ├── stt_client.py             # WS client + parallel reader, emits StreamAEvents
│   ├── vad_client.py             # WS client + parallel reader
│   └── tts_client.py             # WS client + parallel reader (THE v1 fix)
│
├── runtime/
│   ├── __init__.py
│   └── interview_session.py      # top-level façade. Wires everything together.
│
├── core/
│   ├── __init__.py
│   ├── event_bus.py              # in-process pub/sub for state-change events
│   ├── session_store.py          # SessionState container + atomic mutators
│   ├── director.py               # the 500ms tick agent
│   ├── policy/
│   │   ├── turn_taking.py        # pure fn, the 5 rules from SSOT §6.4 (refined)
│   │   ├── barge_in_guard.py     # pure fn, decides on cancel
│   │   └── config.yaml           # thresholds (tail_ms, silence_prompt_ms, …)
│   ├── latency/
│   │   ├── orchestrator.py       # fast/slow LLM arbiter + apology fallback
│   │   ├── timers.py             # asyncio timer primitives
│   │   └── config.yaml           # filler_threshold_s, apology_threshold_s, …
│   ├── fsm/
│   │   ├── phases.py             # Phase enum (re-exports from contracts)
│   │   └── transitions.py        # transition map + phase-budget logic
│   └── conversation_context.py   # builds the rich "what just happened" object
│
├── agents/
│   ├── __init__.py
│   ├── base.py                   # SubAgent protocol — uses LLM, returns ToolCall
│   ├── question_agent.py         # the main interviewer. SLOW LLM, streaming.
│   ├── filler_agent.py           # fast LLM, ≤8 tokens, contextual ack
│   ├── apology_agent.py          # canned phrase bank — no LLM call
│   ├── scorer_agent.py           # async, runs after each candidate turn
│   ├── summarizer_agent.py       # async, every N turns
│   └── integrity_agent.py        # async, every K turns or on suspicion
│
├── llm/
│   ├── __init__.py
│   ├── client.py                 # provider-agnostic streaming wrapper
│   ├── slow.py                   # config: which model is "slow" (DeepSeek-V3.2)
│   ├── fast.py                   # config: which model is "fast" (gpt-4o-mini, Groq, …)
│   └── tool_call.py              # streaming tool-call parser, validates against tool_schema.py
│
├── tools/
│   ├── __init__.py
│   ├── respond.py                # the primary tool: speak now
│   ├── update_score.py           # mutate rubric_scores
│   ├── transition_phase.py       # mutate phase
│   ├── flag_integrity.py         # append to active_flags
│   └── request_clarification.py  # speak a "didn't catch that" turn
│
├── prompts/
│   ├── system_prompt.md          # 1 root system prompt, prompt-cache friendly
│   ├── filler_prompt.md          # for FillerAgent
│   ├── apology_phrases.yaml      # canned bank for ApologyAgent
│   ├── scorer_prompt.md
│   ├── summarizer_prompt.md
│   ├── integrity_prompt.md
│   └── phases/
│       ├── join_check.md
│       ├── warm_up.md
│       ├── project_deep_dive.md
│       ├── programming.md
│       ├── system_design.md
│       ├── candidate_qa.md
│       └── wrap_up.md
│
├── observability/
│   ├── __init__.py
│   ├── tracer.py                 # span() context manager, emits to event bus + langfuse
│   ├── event_log.py              # JSONL appender
│   └── langfuse_adapter.py       # optional, when LANGFUSE_* env vars set
│
└── tests/
    ├── unit/
    │   ├── test_turn_taking.py
    │   ├── test_barge_in_guard.py
    │   ├── test_fsm.py
    │   ├── test_latency_orchestrator.py
    │   ├── test_session_store.py
    │   └── test_tool_validation.py
    ├── integration/
    │   ├── test_against_mock_streamA.py
    │   └── fixtures/
    └── README.md
```

The biggest difference vs v1: **`director.py` is small** (~150 lines). It just
ticks, asks the policy what to do, and delegates to sub-agents. All the
intelligence lives in the sub-agents and the latency orchestrator.

---

## 6. The agentic core — director, sub-agents, tools

This is the conceptual heart of the revamp. Let me walk through how a single
turn flows.

### 6.1 The director's tick

Every 500ms (configurable):

```python
async def tick(self, now_ms: int) -> None:
    with self.tracer.span("director.tick", now_ms=now_ms) as span:
        state = self.store.snapshot()
        decision = self.turn_taking.decide(state, now_ms)
        span.set("decision", decision.value)

        if decision is Decision.NO or decision is Decision.WAIT:
            return

        # decision == YES — director picks a sub-agent based on context
        intent = self._classify_intent(state)
        # intent ∈ {ASK_QUESTION, CLARIFY, ACK_AND_CONTINUE, WRAP_UP, …}

        await self.latency_orchestrator.respond(
            intent=intent,
            state=state,
            on_text_chunk=self._emit_to_tts,
            on_complete=self._record_turn,
        )
```

Decisions stay deterministic and fast. Latency-aware response generation is
delegated to the latency orchestrator (§7).

### 6.2 Sub-agent contract

```python
class SubAgent(Protocol):
    name: str
    model: ModelTier  # FAST | SLOW | OFFLINE

    async def run(
        self,
        state: SessionState,
        context: ConversationContext,
        tools: list[ToolDef],
        on_tool_call: Callable[[ToolCall], Awaitable[None]],
    ) -> AgentResult:
        ...
```

`tools` is the list of tools this sub-agent is allowed to invoke. The LLM
must respond via a tool call (per SSOT §4.4 — extended to support multiple
tools). `on_tool_call` is the side-effect handler — the director hands in a
closure that knows how to apply the tool's effect to `SessionStore`.

### 6.3 Tools — concrete schemas

Five tools, each with strict JSON schema. The LLM is forced to use one.

| Tool | Effect on state | Used by |
|---|---|---|
| `respond` | Streams `utterance` text into TTS via `TTSClient.speak_chunk()`. Records a Turn with `speaker=AI`. | `QuestionAgent`, `FillerAgent`, `ApologyAgent` |
| `update_score` | Appends a `RunningScore` delta to `state.rubric_scores`. Records an `EvidenceRef`. | `ScorerAgent` |
| `transition_phase` | Changes `state.phase`. Validated against `transitions.py`. | `QuestionAgent` (via `transition_intent` field) |
| `flag_integrity` | Appends to `state.active_flags`. Bumps `state.risk_score`. | `IntegrityAgent` |
| `request_clarification` | Same as `respond` but fires a templated "I'm sorry, could you say that again?" turn. Used for low-confidence STT. | `QuestionAgent` |

Each tool has a Pydantic model and a JSON schema in
`stream_b_new/contracts/tool_schema.py`. The LLM call wrapper in
`llm/tool_call.py` validates streamed deltas against the schema and only
fires `on_tool_call` once a complete validated payload is in hand.

### 6.4 Why split tools instead of SSOT's single `respond`

SSOT §4.4 has a single `respond` tool whose payload includes `score_deltas`,
`transition_intent`, `concern`, etc. That's fine for the production design,
but in v2 I want each side-effect to be:

- **Independently testable** — `test_update_score.py` doesn't need to invent a
  fake utterance.
- **Independently traceable in Langfuse** — different sub-agents call different
  tools, so spans cluster naturally.
- **Independently rate-limited** — the `IntegrityAgent` shouldn't get to mutate
  `phase`; the `QuestionAgent` shouldn't get to flag integrity.

The `respond` tool is still the primary path in 90% of turns. The others fire
in the background or in special cases.

### 6.5 Sub-agent cadence

| Sub-agent | When it runs | Tier | Blocks tick? |
|---|---|---|---|
| `QuestionAgent` | When director decides YES and intent ≠ filler | SLOW (e.g. DeepSeek-V3.2) | Yes — but token-streamed so first audio fast |
| `FillerAgent` | Triggered by latency orchestrator (§7) when slow LLM is taking >800ms | FAST (e.g. `gpt-4o-mini`) | No — fires in parallel |
| `ApologyAgent` | Latency-orchestrator fallback when fast LLM also slow | OFFLINE (canned phrases, zero LLM) | No |
| `ScorerAgent` | After each candidate `Turn` is finalised | SLOW | No — async, never blocks tick |
| `SummarizerAgent` | Every 6 turns | OFFLINE-cheap (Haiku-class) | No — async |
| `IntegrityAgent` | Every 4 turns OR when prosody features look suspicious | SLOW | No — async |

The director's tick is `~50ms` p95 even when the LLM is generating, because
it kicks off async tasks and returns.

---

## 7. The latency orchestrator — the headline new piece

This is what you specifically called out: "fast LLM if main LLM is slow; if fast
LLM also slow, intimate that we are running slow and to give some moment".

### 7.1 The state machine

A single `LatencyOrchestrator` owns the full "candidate finished → AI speaking"
journey.

States:

```
IDLE
  │
  │ user_finished_speaking (STT final)
  ▼
DISPATCHED_SLOW
  │
  ├── slow_first_token < 800ms ──────────────► STREAMING_SLOW ─► IDLE
  │
  ├── 800ms elapsed, slow not done ───────────► DISPATCHED_FILLER
  │       │
  │       ├── filler_first_token < 1500ms total ─► STREAMING_FILLER
  │       │       │
  │       │       ├── filler audio_end ─► hold-back: SLOW_PENDING
  │       │       │       │
  │       │       │       ├── slow already done ─► STREAMING_SLOW ─► IDLE
  │       │       │       └── slow not yet done ─► waiting (no speech)
  │       │       │
  │       │       └── slow first_token while filler streaming ─► QUEUED_SLOW
  │       │                       (slow tokens buffered until filler audio_end)
  │       │
  │       └── 2500ms total elapsed, filler not done ─► DISPATCHED_APOLOGY
  │                                                       │
  │                                                       ▼
  │                                                  STREAMING_APOLOGY
  │                                                  ("Give me a second to think
  │                                                   that through carefully…")
  │                                                       │
  │                                                       ▼
  │                                                  SLOW_PENDING (as above)
  │
  └── candidate barges in (BargeInGuard says yes) ─► CANCELLED ─► IDLE
```

### 7.2 Why a state machine and not "just timers + flags"

The v1 `FillerOrchestrator` was a side-loaded thing with its own WS
connection and a list of timers. It worked, but reasoning about edge cases
("filler is half-played and slow LLM finishes" / "candidate barges in during
the filler" / "slow LLM errors mid-stream") meant chasing flags across files.

A single state machine with explicit transitions makes the test surface
small. `tests/unit/test_latency_orchestrator.py` enumerates every transition.

### 7.3 Audio coordination — TTS pause/resume becomes a first-class API

The TTS client exposes:

```python
class TTSClient:
    async def speak_chunk(self, turn_id: str, sequence_id: int, text: str) -> None: ...
    async def cancel_turn(self, turn_id: str) -> None: ...
    async def pause(self) -> None: ...   # buffers further chunks server-side or holds-back client-side
    async def resume(self) -> None: ...
    async def drain(self) -> None: ...   # awaits all pending audio_end events
```

The latency orchestrator drives these. When filler is playing and slow LLM
chunks arrive, those chunks queue inside `TTSClient` (paused). When the
filler's `audio_end` fires, the orchestrator calls `resume()` — and Kokoro
synthesises the slow response immediately afterward. The candidate hears
filler → seamless → real response.

This was cobbled together in v1 by patching Stream B's `TTSSender` with
`pause()`/`resume()` from the orchestrator side. v2 makes it native.

### 7.4 Conversation-context awareness — closing your point #2

When the slow LLM eventually starts generating, it gets a `ConversationContext`
that includes:

```yaml
recent_audio_events:
  - {ts: -2.1s, kind: ai_filler_spoken, text: "Got it — Kafka, give me a second."}
  - {ts: -3.4s, kind: candidate_finished, text: "I used Kafka with 3 brokers...",
     stt_confidence: 0.91, prosody: {wpm: 170, hesitation: low}}
  - {ts: -8.7s, kind: ai_response_barged_in, played_words: 7, total_words: 12,
     interrupted_at: "...how did you handle <barge-in>"}

silence_state:
  ms_since_last_candidate_speech: 4_300
  ai_currently_speaking: false
  recent_apology_played: false

phase:
  current: project_deep_dive
  elapsed_in_phase_s: 412
  budget_s: 720
  pace: on_track
```

The system prompt (`prompts/system_prompt.md`) instructs the LLM:

> You are conducting a live audio interview. The `recent_audio_events` field
> tells you exactly what's been happening in the last few seconds. **Do not
> repeat acknowledgments the candidate already heard** (e.g. if a filler said
> "Got it", don't open with "Got it" again — start with the substantive
> question). If you were `barged_in`, decide whether to retry the original
> point or move on based on what the candidate just said.

This is the lever that makes the AI *sound* like it heard itself talk. It's
worth more than any individual prompt-engineering trick.

### 7.5 Apology bank examples (no LLM required)

```yaml
# prompts/apology_phrases.yaml
generic:
  - "Give me just a second to think that through carefully."
  - "One moment — let me pull this together."
  - "Hmm, give me a beat to phrase this properly."

after_long_candidate_answer:
  - "That's a lot — give me a moment to digest it."
  - "Quite a bit there. Let me think about that for a second."

after_technical_answer:
  - "Interesting — let me work through that."
```

`ApologyAgent` selects based on the last candidate turn's length and phase;
`TTSClient` plays it directly. Latency: ~zero LLM, ~150ms TTFA after pre-warm.

---

## 8. Engineering plumbing — coordination, fallbacks & edge cases

This is the longest section because it's where the real production-readiness
work lives. Every v2 deployment will discover some of these the hard way; the
plan addresses them upfront. Sub-sections are grouped by category. The three
examples you wrote are §8B.2, §8B.3, and §8B.4.

### 8A. Conversation continuity — the tag vocabulary

This is the single most important addition to v2 from a quality-of-conversation
standpoint. v1 reduced the LLM's view of the past to "previous turns + rolling
summary". v2 makes the conversation history **tag-rich** so the LLM has explicit
signals about what just happened in the audio world. Tags are inline in
recorded turns. The system prompt explicitly defines each tag.

#### 8A.1 Tag vocabulary

| Tag | Where it appears | Meaning |
|---|---|---|
| `<barged_in/>` | end of an AI turn | TTS playback was cancelled before this turn finished. Everything *before* this tag is what the candidate actually heard; everything after, only the LLM thought of. |
| `<filler text="..."/>` | start of an AI turn | A fast-LLM filler was played before this turn's substance. The candidate already heard the quoted text — don't re-acknowledge. |
| `<apology text="..."/>` | start of an AI turn | A canned apology was played. |
| `<silence_ms=14000/>` | start of an AI turn | This turn fired because Rule 4 (silence_prompt). It is a prompt, not a response to anything specific. |
| `<low_confidence stt=0.42/>` | wraps a candidate turn | STT confidence was low. The text may be partly wrong. |
| `<no_response_yet/>` | end of a candidate turn | This is a candidate utterance the AI hasn't yet responded to — it was preempted by another candidate utterance. (See §8B.2.) |
| `<continued/>` | start of a candidate turn | This turn is a continuation of the previous candidate turn (false-endpoint detected after-the-fact, §8B.1). |
| `<protected_response/>` | wraps an AI turn | This turn was generated in protected-response mode (§8B.4). Cannot be barge-in cancelled. |
| `<phase_changed from="warm_up" to="project_deep_dive" reason="budget"/>` | between turns | A phase transition just fired. |
| `<inconsistency note="..."/>` | wraps a candidate turn | IntegrityAgent flagged this turn as inconsistent with earlier statements. |
| `<retry n=1 reason="..."/>` | wraps an AI turn | Tool-call validation failed and was retried. Mostly useful in Langfuse audit. |
| `<mic_dropout/>` | recent_audio_events | Mic stopped delivering frames. NOT candidate silence. |

The full list lives in `stream_b_new/contracts/tags.py` as an enum with a
docstring per tag. The system prompt embeds the docstrings verbatim so the
LLM has a single source-of-truth for what each tag means.

#### 8A.2 Worked example — full turn history with tags

```
[ai]        Welcome, Raghu — could you tell me about a recent project?
[candidate] I worked on a Kafka pipeline.
[ai]        <filler text="Got it, Kafka — let me dig in."/>What was the throughput target?
[candidate] About 500k messages per second.<no_response_yet/>
[candidate] Sorry, peak. Steady state was around 200k.
[ai]        <silence_ms=8200/>Take your time, no rush.
[candidate] So with that load we used a hash partitioner.
[ai]        How did you handle the partition<barged_in/>
[candidate] Yeah, we used the user_id as the hash key.
[ai]        Good — user_id keying. What was the rebalancing story when brokers went down?
```

Notice the LLM in the last turn does NOT re-ask the partitioning question
(it sees `<barged_in/>` plus the candidate's answer); does NOT re-acknowledge
"Got it" (it's already in the recent filler); and naturally pivots to the
next sub-topic.

### 8B. Cancellation & cost protection

#### 8B.1 False-endpoint grace window — cancel before any LLM cost

**Problem.** VAD endpoints fire on every 600ms-ish silence. Many are
mid-sentence pauses. Today, the slow LLM dispatches immediately on STT
final. If the candidate resumes 200ms later, we've already paid for an LLM
call that gets cancelled.

**Fix.** A 250ms grace window between STT final and slow-LLM dispatch:
- VAD speech_start within the window → drop the endpoint, treat as
  continuation, tag the resumed turn `<continued/>`.
- Window expires → dispatch as normal.

**Trade-off.** 250ms added perceived latency at the start of every response.
Compensated by tightening the filler-trigger threshold by the same 250ms.
Net: imperceptible to a human ear, but cost waste on false endpoints drops
to ~zero.

#### 8B.2 Barge-in during LLM generation (your example #2)

Sequence:
1. Candidate says "...we used Kafka." STT final.
2. Slow LLM dispatched.
3. Before/while LLM is producing tokens, candidate says "Actually, RabbitMQ
   for the smaller queues."

**Mechanic:**
- Cancel in-flight slow LLM (stops further tokens; already-paid tokens are
  written off as cost).
- *Do not* record any partial LLM output as an AI turn. The candidate never
  heard it.
- Tag the previous candidate turn with `<no_response_yet/>`.
- Wait for STT final on the new utterance, then dispatch a fresh slow LLM
  call covering BOTH candidate turns concatenated.

**Recorded turns:**
```
[candidate] ...we used Kafka.<no_response_yet/>
[candidate] Actually, RabbitMQ for the smaller queues.
```

The next prompt sees both consecutive candidate turns. System-prompt rule:
> *"Two consecutive candidate turns where the first ends with
> `<no_response_yet/>` mean the candidate self-corrected before you could
> respond. Treat them as a single coherent message."*

Critical engineering bit: cancel **before any tokens fire** if possible — that
saves the most cost. Cancellation that happens after tokens have started is
still a net win because we stop early; but the turn produces no recorded
output and no audio.

#### 8B.3 Barge-in during TTS playback (your example #3)

Sequence:
1. Slow LLM produces "How did you handle partitioning across the brokers?"
2. TTS speaks "How did you handle partit-" (~50% played).
3. Candidate barges in: "Hash on user_id."
4. STT final on the new utterance.

**Mechanic:**
- Cancel TTS turn (TTSClient broadcasts cancel for all sub-IDs).
- Compute truncation:
  `played_ratio = audio_played_ms / expected_total_ms`
  `truncated_words = int(played_ratio × word_count)`
  Truncate the AI's recorded turn at that word boundary, append `<barged_in/>`.
- Record the truncated AI turn AND the candidate's reply.

**Recorded turns:**
```
[ai]        How did you handle partit<barged_in/>
[candidate] Hash on user_id.
```

Keep the *full* original text on `tts_speak_chunk_sent` events for audit /
debugging. Only the recorded `Turn.text` is truncated, because that's what
the LLM sees in subsequent prompts.

System-prompt rule:
> *"`<barged_in/>` means the candidate cut you off. Read what they said —
> they may have answered the question you were asking, in which case
> acknowledge and continue ('Good, hash on user_id — what about hot keys?').
> They may have changed topic, in which case follow them. Do NOT re-ask the
> question that got cut off as if nothing happened."*

#### 8B.4 The 3-strike protected-response rule (your example #1)

**Problem.** Repeated barge-ins starve the slow LLM of any chance to
respond. Every cancel still costs partial LLM tokens. The candidate may feel
ignored. The conversation deadlocks.

**Detection.** A `barge_in_strike_count` counter on SessionState, scoped to
the current phase. Increments on:
- §8B.2 (cancel LLM mid-generation)
- §8B.3 (cancel TTS mid-playback)

Resets on:
- A successful AI turn (LLM output → TTS audio_end without cancellation).
- 30 seconds of candidate silence.
- Phase transition.

**Action at strike == 3.** LatencyOrchestrator transitions to
`PROTECTED_RESPONSE_MODE`:
1. Cancel any in-flight slow LLM.
2. Play canned message via fast bypass: "Let me make sure I have the full
   picture before I respond — give me a few seconds to get this right."
3. **Suspend `Director.tick`** (no policy decisions, no new dispatches —
   directly answers your "override and reset all the ticks" requirement).
4. Set `BargeInGuard.allow_barge_in = false` for the next AI turn only.
5. Build a single LLM call covering all 3+ candidate utterances concatenated,
   each tagged `<no_response_yet/>` plus a system-prompt addendum explaining
   protected mode.
6. Stream the slow LLM's output to TTS. **TTS turn cannot be barge-in
   cancelled.** Candidate VAD events during this turn are still *recorded*
   in the event log but ignored for cancellation purposes (so we have a
   record that the candidate tried to interrupt, but we held our ground).
7. After audio_end: re-enable barge-in, reset strike count to 0, resume
   ticks.

**LLM prompt addendum during protected mode:**
> *"You are in protected response mode because of repeated interruptions
> (the candidate has tried to respond 3+ times before you could speak).
> Acknowledge the pattern gracefully ('let me address those points one at a
> time'), give a coherent response covering all of their utterances, then
> explicitly cede the turn ('does that cover what you were asking?'). Keep
> your response to 2-3 sentences max — long answers risk new interruptions
> when protected mode ends."*

**Why this works.**
- Candidate hears "let me get this right" — they understand the AI is
  taking control, not ignoring them.
- The single protected response covers everything they said, which is the
  natural human resolution to over-talking.
- The 3-strike threshold is generous enough that it only fires in genuinely
  pathological situations.

**Tag in the next normal turn's history:**
```
[ai] <protected_response/>Let me address those points one at a time. First,
     on the Kafka throughput — yes, hash partitioning is the standard play;
     the trick is the rebalancing. Second, RabbitMQ — that's a different
     beast entirely; smaller queues, lower latency, no partition concept.
     Does that cover what you were asking?
```

#### 8B.5 Cost meter & ceiling

SSOT §17.2 alerts at $2.50/session. v2 enforces a per-session meter:

| Threshold | Action | Event |
|---|---|---|
| Soft ($2.00 default) | Switch slow LLM to cheaper provider for the rest of the session | `cost_ceiling_soft_crossed` |
| Hard ($3.00 default) | Play apology, force phase-jump to wrap_up, end session | `cost_ceiling_hard_crossed` |

Cost is computed per LLM call from token counts × per-million pricing
defined in `stream_b_new/llm/pricing.yaml` (one entry per model).
Thresholds configurable per session via CLI flags.

#### 8B.6 LLM call idempotency

Provider failover (§8D.3) means the same prompt may run on a second
provider. Without dedup, a tool-call effect (e.g. score update) could apply
twice. Each LLM call has a deterministic
`call_id = hash(turn_id, prompt_hash, attempt_number)`. The tool-call effect
handler dedups by `call_id` before applying mutations.

### 8C. Audio robustness

#### 8C.1 Audio-end grace window

The "AI says '...how did you handle partitioning?' — exactly as TTS is
finishing, candidate starts answering, we cancel TTS at 95%, candidate hears
'...how did you handle partit-'" failure mode.

**Fix.** BargeInGuard has a 200ms grace window before expected audio_end.
If VAD speech_start fires within `[expected_audio_end - 200ms, ∞)` AND TTS
is within 95% of `expected_audio_end`, treat it as the next candidate turn,
NOT a barge-in. Don't cancel TTS.

`expected_audio_end` is estimated from `text_length / kokoro_chars_per_second`
(empirically ~150 chars/s on this hardware; calibrated at session start
during pre-warm).

Emits `audio_end_grace_blocked_barge_in` when triggered.

#### 8C.2 TTS reconnect + replay

TTSClient owns reconnection. On WS drop:
1. Detect via `recv()` in the parallel reader (1011 keepalive, 1006
   abnormal closure, etc.).
2. Mark current turn as `audio_partial`; capture `audio_played_ms`.
3. Reconnect (up to 3 attempts with 200ms / 500ms / 1500ms backoff).
4. If the AI turn was mid-flight: speak the unspoken remainder as a fresh
   request (with a fresh `turn_id` to avoid Stream A's `cancel_manager`
   collisions).
5. Emit `tts_reconnect_attempted` / `_succeeded` / `_failed`.

If reconnect fails 3 times: play canned "I'm having an audio glitch — let
me wrap up", force phase-jump to wrap_up, end session.

#### 8C.3 AudioSink backpressure

Speaker can't keep up if Kokoro produces audio faster than playback rate.
SpeakerAudioSink exposes `bytes_buffered()`. TTSClient throttles
`speak_chunk` when buffer > 2s of audio (~64 KB at 16 kHz mono PCM16). If
buffer hits 4s, drop oldest chunks (the conversation has gone catastrophically
wrong; logged as `tts_buffer_overflow`).

#### 8C.4 Mic dropout / silence detection

MicAudioSource emits `mic_silence_detected` if no non-zero PCM arrives
for >2s. The bridge tags `<mic_dropout/>` (NOT `<silence_ms=...>`) so the
LLM doesn't interpret it as candidate-thinking. Rule 4 is suppressed while
`<mic_dropout/>` is the most recent audio event — wait until mic resumes
or the session is ended manually.

#### 8C.5 Pre-warm Kokoro on session start

(README §F2.1 — cheapest, highest-impact single fix.)
`InterviewSession.__aenter__` sends a silent `speak("a")` to TTS during
startup so the first real turn doesn't pay the ~500ms cold-start cliff.
AudioSink mutes the audio_start/end of the pre-warm turn.

While warming, also calibrate `kokoro_chars_per_second` empirically by
measuring `audio_played_ms / text_chars` for the warm-up turn — feeds into
§8C.1's `expected_audio_end` estimator.

### 8D. LLM safety nets

#### 8D.1 Tool-call validation retry

LLM emits an invalid tool call (missing required field, bad enum, malformed
JSON):
1. Validation error caught in `llm/tool_call.py`.
2. Re-call LLM with a system addendum:
   `"Your last response was invalid: <field> must be <constraint>. Try
   again."`
3. Up to 2 retries. After that, fall back to a phase-canned response and
   log `llm_validation_failure`.

Tag: `<retry n=1 reason="..."/>` appears in the conversation history (rare,
mostly useful for debugging via Langfuse).

#### 8D.2 Catastrophic-output detection

Before sending an AI turn to TTS, screen for:

| Pattern | Action |
|---|---|
| Empty text | drop, retry once, then apology |
| Identical to prev AI turn (Levenshtein > 0.95) | drop, ask QuestionAgent for variation: "Your previous turn was identical. Vary wording or topic." |
| Forbidden patterns ("I am an AI", "as an AI assistant", system-prompt leakage) | drop, use canned phase-appropriate phrase |
| Excessive length (>300 words default) | truncate at sentence boundary closest to limit |

Each emits a dedicated `catastrophic_output_dropped` event with a `reason`
field for triage.

#### 8D.3 Provider failover

`LLMClient(providers=[primary, secondary, ...])`. On 5xx / 429 / timeout,
retry with secondary within the same turn. Recorded as
`llm_provider_failover`. If both fail twice, trigger PROTECTED_RESPONSE_MODE
(§8B.4) and consider the slow path failed.

#### 8D.4 STT confidence floor → clarification

If STT final has `confidence < 0.5` AND text is ≤ 6 words, **don't run the
slow LLM at all**. Fire `request_clarification` directly with a templated
phrase ("Sorry — could you say that again? I didn't catch it."), tagged
`<low_confidence/>`. Saves cost; avoids confidently-wrong answers to
garbled input.

#### 8D.5 Empty-utterance suppression

STT final with `text == ""` or only filler-words ("um", "uh", "ah") doesn't
fire `turn_taking.decide()`. Emits `noise_only_final`; director ignores it.

#### 8D.6 Repeat-detection at the dispatch level

If LatencyOrchestrator is about to fire the same response twice in a row
(Levenshtein > 0.95 vs. previous AI turn), reject before TTS. Falls back to
phase-appropriate canned phrase. Bumps `repeat_dropped_count` for
monitoring. Different from §8D.2 — that fires on the LLM's raw output;
this one catches loops across multiple LLM calls.

### 8E. State, lifecycle & ordering

#### 8E.1 Greeting / first turn is forced YES

First tick after `session_started` deterministically fires QuestionAgent
against a "greeting" phase prompt (candidate name, role, intro). No
candidate audio required. The first prompt's history shows just
`<silence_ms=0/>` so the LLM knows it's an opener, not a response.

#### 8E.2 Phase transitions are atomic

Phase transition is *queued*, not applied, while a turn is in flight (LLM
generating or TTS playing). The transition fires at audio_end (or at LLM
cancel). Prevents the "next LLM call gets the new phase prompt while still
finishing the old phase's response" race.

The pending transition is visible in SessionState as `pending_phase` so
observers can see it's coming. When applied, emits `phase_changed` event +
inserts `<phase_changed from=X to=Y reason=...>` tag in conversation history.

#### 8E.3 Phase-budget safety valve

If a phase has been running > 120% of budget AND no transition has fired,
PhaseMachine forces a transition to the next phase. The next LLM prompt
includes the `<phase_changed reason="budget"/>` tag so the LLM understands
why it's suddenly in a new phase.

#### 8E.4 Session-end teardown order

`InterviewSession.__aexit__` runs in this exact order — order matters:

1. Cancel any in-flight slow LLM call.
2. Send `cancel_turn` to TTSClient for any active turn.
3. Wait for TTS audio_end (timeout 2s).
4. Run SummarizerAgent one last time on the full transcript.
5. Run ScorerAgent final pass (synchronous this time, not skip-if-busy).
6. Write `session_ended` event with final state snapshot.
7. Close all WS clients (STT, VAD, TTS).
8. Flush event log + Langfuse.
9. Stop AudioSource / AudioSink.

Cancelling LLM before TTS prevents tokens streaming into a closed
connection. Closing WS clients before audio sources prevents the sink
dying mid-write — exactly the v1 issue we worked around with bash trap
timing in `run_live.sh`.

#### 8E.5 Async sub-agent task bounds

Each async sub-agent has at most 1 in-flight task per session:
- `ScorerAgent`: queue depth 1, last-write-wins (SessionState is the source
  of truth, so dropping a redundant task is fine).
- `SummarizerAgent`: skip-if-busy (preserves consistency of summary).
- `IntegrityAgent`: skip-if-busy.

Eliminates the "30-minute session has 200 pending Scorer tasks" failure
mode. Each sub-agent invocation is also wrapped in `asyncio.wait_for` with
a hard timeout so a hung LLM call can't block teardown.

#### 8E.6 Heartbeat health watcher

Background task pings `/healthz` on STT/VAD/TTS every 5s. If any goes
unhealthy mid-session: play canned phrase ("My audio just hiccupped — give
me a moment"), attempt reconnect, emit `service_reconnect`. After 3 failed
reconnects, end session with apology summary.

#### 8E.7 Crash recovery via event-log replay (future)

On startup, if `--resume <session_id>` is passed:
1. Read events.jsonl, find last `session_started` for that session_id.
2. Replay events forward to rebuild SessionState.
3. Trim incomplete state (turn with `tts_audio_start` but no `tts_audio_end`
   becomes `interruption=interrupted` with played_words estimated from
   `audio_played_ms`).
4. Resume director ticks.

Out of scope for v2 day-one; the event log + SessionState shape are
designed to support it without retrofitting.

### 8F. Latency-orchestrator edge cases (extension of §7)

#### 8F.1 Slow LLM completes during filler — handoff
Slow done while filler streaming. Slow's tokens buffer inside TTSClient
(via `pause()`). Filler audio_end fires `resume()`. Slow plays seamlessly.
(Already in §7 state machine — listed here for completeness.)

#### 8F.2 Slow LLM completes BEFORE filler audio finishes
Slow finishes during filler synthesis. Hold slow output until filler
audio_end. Same code path as 8F.1.

#### 8F.3 Slow LLM produces shorter output than the filler
Filler said "Got it, just a moment" (2.3s audio). Slow said "Yes." (0.4s).
Total: 2.7s of audio, only 0.4s is substance. Awkward.

**Mitigation.** Minimum-substance threshold inside `QuestionAgent.run()`. If
slow output < 8 words AND a filler was played, the agent makes a follow-up
LLM micro-call: *"Your response is very short and a filler was already
played. Add a follow-up question or elaborate by 1–2 sentences."* Streams
the elaboration to TTS.

#### 8F.4 Filler text overlaps with slow text
Fast LLM: "Got it — Kafka with three brokers, give me a second."
Slow LLM: "Got it. So with three brokers, how did you handle..."
Result: candidate hears "Got it... Got it..." back-to-back.

**Mitigation.** `ConversationContext.recent_audio_events[0]` contains the
just-played filler. The system prompt says: *"Never re-acknowledge what's
in the most recent filler. Start your substantive turn with content, not
acknowledgments like 'Got it' / 'Sure' / 'Right'."* The filler agent's
prompt also forbids commitment language ("That's a great question") so the
two outputs don't fight.

#### 8F.5 Apology fired but slow LLM never returns
Apology played; slow LLM still hung past 30s. Treat as provider failure:
trigger §8D.3 failover. If failover also hangs: play "I'm sorry, my
connection is glitching — let me wrap up here", force phase-jump to
wrap_up, end session.

#### 8F.6 Long candidate monologue (>60s without endpoint)
VAD never fires endpoint; partials accumulate. Two effects:

1. The agent has no signal to respond. Fix: emit a "soft endpoint" if
   candidate speech > `monologue_soft_endpoint_s` (default 45s) AND a
   sentence-ending punctuation appears in the latest partial. The director
   treats it as a regular endpoint.
2. The candidate may want a backchannel to feel heard. Fix: every 15s of
   continuous speech, the FillerAgent fires a quiet "Mhm." through the
   filler TTS path. Doesn't interrupt, doesn't cancel, just signals
   listening.

### 8G. Barge-in semantic refinement

Per README §3, only treat `vad_speech_start` as a barge-in when ALL of:

1. `SessionState.ai_activity == AUDIO_PLAYING` (not LLM_GENERATING /
   TTS_QUEUED).
2. The speech-start has been continuous for ≥ 200ms.
3. We're outside the audio-end grace window (§8C.1).

Otherwise: speech_start is *recorded* but does not trigger TTS cancel.
That's the difference between "candidate cleared their throat while AI was
talking" (don't cancel) and "candidate is genuinely interrupting" (do
cancel). Pure function lives in `core/policy/barge_in_guard.py`, tested
exhaustively with synthetic event sequences.

### 8H. Observability for these edge cases

Every edge-case path emits a dedicated event so they're queryable in
events.jsonl. The full list is in §9.2 below; the engineering-edge-case
events are these:

| Event | Fired by | Carries |
|---|---|---|
| `false_endpoint_dropped` | Bridge / latency orchestrator | candidate_text_so_far, ms_since_endpoint |
| `barge_in_strike_increment` | LatencyOrchestrator | new_count, phase, scope |
| `protected_response_mode_entered` / `_exited` | LatencyOrchestrator | reason, candidate_utterances_count |
| `cost_ceiling_soft_crossed` / `_hard_crossed` | LLMClient | total_cost_usd, threshold_usd |
| `tts_reconnect_attempted` / `_succeeded` / `_failed` | TTSClient | attempt, backoff_ms |
| `audio_end_grace_blocked_barge_in` | BargeInGuard | ms_to_expected_end |
| `tool_call_validation_retry` | llm/tool_call.py | retry_n, validation_error |
| `catastrophic_output_dropped` | QuestionAgent | reason, dropped_text_excerpt |
| `mic_silence_detected` / `_recovered` | MicAudioSource | duration_ms |
| `service_reconnect` | health watcher | service, attempt |
| `monologue_soft_endpoint_fired` | bridge | duration_s, partial_text |
| `backchannel_played` | FillerAgent | text |

`jq 'select(.kind=="barge_in_strike_increment")' /tmp/integration/events.jsonl`
gives a session's barge-in trace at a glance — easy to correlate with bad
candidate experience reports.

---

## 9. Observability (your point about full tracing)

Every interesting moment emits a structured event with timestamp.
**Every LLM call** captures: model, prompt (system + user), response (text),
duration, token counts, cost (when known), tool-call validity.
**Every service call** (STT/VAD/TTS WS message, in or out) is logged.
**Every state mutation** is recorded.

### 9.1 The `Tracer.span` context manager

```python
with tracer.span("question_agent.run", phase="warm_up", model="deepseek-v3.2") as span:
    span.set_input(prompt_text=prompt, system_prompt=system, history=hist)
    result = await llm.complete_streaming(prompt)
    span.set_output(text=result.text, tool_call=result.tool_call)
    span.set_metrics(ttft_ms=ttft, tokens_out=n)
```

On exit, the span:

1. Writes a row to `events.jsonl` with `kind`, `started_at`, `duration_ms`,
   `inputs`, `outputs`, `metrics`.
2. If Langfuse is configured, also pushes a `Trace` (parent span) and `Generation`
   (LLM call sub-span). Otherwise no-ops.
3. Calls `event_bus.publish(span_event)` so live consumers (e.g. a future
   TA-console websocket) can subscribe.

### 9.2 What events.jsonl will contain (extended from v1)

```
session_started, session_ended
mic_frame_in (heartbeat, every 1000 frames)
stt_partial, stt_final
vad_speech_start, vad_speech_end, vad_endpoint
tts_speak_chunk_sent, tts_audio_start, tts_audio_end, tts_cancelled

director_tick                              # each tick, with policy decision
policy_decision                             # only on YES (less noise)
phase_transition

latency_state_changed                       # every state-machine transition
filler_dispatched, apology_dispatched

llm_call_started                            # NEW — captures full prompt + system
llm_call_first_token                        # NEW — TTFT measured
llm_call_completed                          # NEW — full output + usage + cost
llm_call_failed                             # NEW — exception, latency
llm_provider_failover                       # NEW — switched provider mid-call

tool_call_validated, tool_call_executed, tool_call_validation_retry
sub_agent_invoked, sub_agent_completed

score_updated, integrity_flagged, summary_compressed

service_health_check, service_reconnect
ai_response_barged_in                       # captures played_words/total_words

# Engineering edge-case events (added in §8H)
false_endpoint_dropped                      # §8B.1 — saved an LLM call
barge_in_strike_increment                   # §8B.4 — strike counter tick
protected_response_mode_entered             # §8B.4 — entered 3-strike mode
protected_response_mode_exited              # §8B.4 — turn finished, normal resumes
cost_ceiling_soft_crossed                   # §8B.5 — switched to cheaper provider
cost_ceiling_hard_crossed                   # §8B.5 — ending session
tts_reconnect_attempted                     # §8C.2
tts_reconnect_succeeded
tts_reconnect_failed
tts_buffer_overflow                         # §8C.3
audio_end_grace_blocked_barge_in            # §8C.1
catastrophic_output_dropped                 # §8D.2 — empty/duplicate/forbidden
mic_silence_detected                        # §8C.4
mic_silence_recovered
monologue_soft_endpoint_fired               # §8F.6
backchannel_played                          # §8F.6
noise_only_final                            # §8D.5
```

Each entry has `ts`, `session_id`, `kind`, `payload`.

### 9.3 Privacy note

`llm_call_started` includes the prompt verbatim. That's fine for development;
in production it would be redacted (candidate name, etc.) before leaving the
host. Out of scope for v2 day-one — the SSOT covers it in §16.

---

## 10. Key contract details

### 10.1 Extended `EventKind`

v1's `contracts/events.py` had ~10 kinds. v2 adds the items from §9.2 above.
`tts_audio_start` and `tts_audio_end` are first-class enum values, not
out-of-band string kinds.

### 10.2 Extended `SessionState`

```python
class TurnInterruption(BaseModel):
    interrupted_at_word: int
    total_words: int
    candidate_text_after: str | None
    ts_ms: int

class Turn(BaseModel):
    # … all v1 fields preserved …
    audio_played_ms: int = 0           # NEW — how much of TTS actually played
    interruption: TurnInterruption | None = None  # NEW — populated on barge-in

class AIActivityState(str, Enum):
    IDLE = "idle"
    LLM_GENERATING = "llm_generating"
    TTS_QUEUED = "tts_queued"
    AUDIO_PLAYING = "audio_playing"
    AUDIO_DONE = "audio_done"   # within grace period

class SessionState(BaseModel):
    # … all v1 fields preserved …
    ai_activity: AIActivityState = AIActivityState.IDLE   # replaces the v1 _ai_active flag
    last_audio_end_ts_ms: int = 0                          # replaces the v1 _last_any_speech_ms hack
    last_filler_text: str | None = None
    last_apology_ts_ms: int = 0
    consecutive_low_conf_finals: int = 0

    # ── §8B engineering plumbing fields ──
    barge_in_strike_count: int = 0                         # §8B.4 — counter, scoped to current phase
    in_protected_response: bool = False                    # §8B.4 — true while protected turn streaming
    pending_phase: Phase | None = None                     # §8E.2 — queued transition

    # ── §8B.5 cost meter ──
    cost_so_far_usd: float = 0.0
    cost_ceiling_soft_crossed: bool = False
    cost_ceiling_hard_crossed: bool = False

    # ── §8C.5 calibration ──
    kokoro_chars_per_second: float = 150.0                  # estimated at pre-warm, used for grace window

    # ── §8F.6 monologue tracking ──
    candidate_continuous_speech_ms: int = 0
    last_backchannel_ts_ms: int = 0
```

These are the fields the v1 README §"Known issues" sections kept poking at via
private attributes. v2 promotes them to public state.

### 10.3 Tag rendering — how `Turn.text` becomes prompt input

Tags (§8A.1) are *not* stored separately from `Turn.text`. The contract is:

- `Turn.text` stores the truncated/annotated string ready for LLM prompting
  (e.g. `"How did you handle partit<barged_in/>"`).
- `Turn.text_full` is added as a **new** field (Optional) that stores the
  un-truncated, un-tagged original — for audit and Langfuse display.
- A helper `Turn.render_for_prompt() -> str` is the single function that
  prompts use. Today it returns `Turn.text`. Future formatters (e.g. for a
  human-readable transcript) live alongside without polluting the type.

Tag rendering happens at *write time* (when an event triggers a state
mutation), not at prompt-build time. This avoids two bugs:

- A history rebuilt at prompt time can drift from the event log.
- Tag-rendering at read time means cost is paid on every prompt build (N²
  in turn count for a long session).

The functions live in `core/tag_render.py`. Each tag has one writer,
testable in isolation (`tests/unit/test_tag_render.py`).

### 10.4 `ConversationContext` — the rich object passed to every LLM call

```python
@dataclass
class RecentAudioEvent:
    ts_offset_s: float
    kind: Literal["candidate_finished", "ai_filler_spoken", "ai_response_completed",
                  "ai_response_barged_in", "candidate_silence_started", "apology_played"]
    text: str | None = None
    metadata: dict = field(default_factory=dict)

@dataclass
class ConversationContext:
    recent_turns: list[Turn]                # last N=6, tag-rendered
    rolling_summary: str
    recent_audio_events: list[RecentAudioEvent]   # last 10s of audio activity
    candidate_silence_ms: int
    ai_activity: AIActivityState
    phase: Phase
    phase_elapsed_s: int
    phase_budget_s: int
    phase_pace: Literal["ahead", "on_track", "behind"]
    active_integrity_flags: list[IntegrityFlag]
    last_stt_confidence: float

    # ── §8 engineering signals the LLM should reason about ──
    last_filler_text: str | None                 # if present, do NOT re-acknowledge
    last_apology_ts_ms: int                       # if recent, the candidate just heard "give me a moment"
    barge_in_strike_count: int                    # §8B.4 — drives PROTECTED_RESPONSE_MODE prompt addendum
    in_protected_response: bool                   # §8B.4 — adds the "address all points, then cede" rule
    pending_phase: Phase | None                   # §8E.2 — heads-up for the next response
    consecutive_low_conf_finals: int              # §8D.4 — consider asking the candidate to check audio
```

Every sub-agent that calls an LLM gets one of these. The system prompt
(`prompts/system_prompt.md`) explicitly references these fields by name so
the model knows what they mean. The fields are deliberately rendered into
the prompt as a YAML block (not a Python dict) so the LLM sees a familiar
structured-data format.

---

## 11. The run script

`scripts/run_live_v2.sh` (we'll keep the v1 script around until cutover):

```bash
#!/usr/bin/env bash
# Boots Stream A then runs orchestrator_new.live_main against the mic.
# Same shape as run_live.sh but pointed at the new modules.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
INTEGRATION_ROOT="$(cd "$HERE/.." && pwd)"
STREAM_A_DIR="$INTEGRATION_ROOT/stream_a"

# venv discovery, .env sourcing, port-cleanup, log dirs — identical to run_live.sh
# ... (same as v1) ...

# Boot Stream A's STT/VAD/TTS
"$PY" -m services.speech_io.stt_service.main > /tmp/integration_logs/stt.log 2>&1 &
"$PY" -m services.speech_io.vad_service.main > /tmp/integration_logs/vad.log 2>&1 &
"$PY" -m services.speech_io.tts_service.main > /tmp/integration_logs/tts.log 2>&1 &

# Wait for /healthz on 8010/8011/8012 — identical loop to v1.
# ...

# Run the new orchestrator (CWD = integration root so both packages resolve)
cd "$INTEGRATION_ROOT"
"$PY" -m orchestrator_new.live_main "$@"
```

Flags supported (all defaulted, all optional):

```
--candidate-name                 default "Live Candidate"
--role                            default "Senior Backend Engineer"
--initial-phase                   default "warm_up"
--tick-ms                         default 500
--filler-threshold-ms             default 800     (was 1000 in v1, tighter is better post §F2)
--apology-threshold-ms            default 2500
--filler-model                    default "openai/gpt-4o-mini" (or "canned")
--slow-model                      default "deepseek/deepseek-chat-v3.2"
--no-filler                       disable fast-LLM fillers
--no-apology                      disable apology fallback
--no-prewarm                      skip Kokoro pre-warm
--event-log                       default "/tmp/integration/events.jsonl"
--tts-sample-rate                 default 16000
--no-playback                     silent mode (events only, no speakers)
--config                          path to yaml overriding any of the above
```

---

## 12. Build sequence (suggested PR-by-PR plan)

I want to land this in small, mergeable chunks. Each step has a clear
"done = green" gate. None of them require the next one to compile — that's
deliberate.

| Step | What | Done when |
|---|---|---|
| 1 | `stream_b_new/contracts/` — Pydantic models, EventKind, tool schemas | `pytest tests/unit/test_contracts.py` passes; JSON round-trip works |
| 2 | `stream_b_new/streamA_bridge/` — STT/VAD/TTS clients with parallel readers | An integration test pumps a fixture WAV through STTClient against the live Stream A STT service and asserts at least one `final` arrives |
| 3 | `stream_b_new/core/session_store.py` + `event_bus.py` | Unit tests cover atomic mutations, event publishing |
| 4 | `stream_b_new/core/policy/turn_taking.py` + `barge_in_guard.py` + tests | Unit tests cover all 5 turn-taking rules and 4 barge-in scenarios |
| 5 | `stream_b_new/core/fsm/` + tests | 100% line coverage on transitions; budget overflow path tested |
| 6 | `stream_b_new/llm/` — streaming wrapper + tool-call parser | Unit test against a mocked OpenRouter response stream |
| 7 | `stream_b_new/agents/question_agent.py` + `prompts/system_prompt.md` (v0) + `prompts/phases/warm_up.md` | A scripted test runs one warm-up turn end-to-end against mocked STT/TTS |
| 8 | `stream_b_new/core/director.py` (minimal — no latency orchestrator yet, no fillers) | Same scripted test now driven by director.tick |
| 9 | `stream_b_new/core/latency/orchestrator.py` + `agents/filler_agent.py` + `agents/apology_agent.py` | Unit tests cover all state-machine transitions; integration test hits all three branches (slow_fast / slow_filler / slow_apology) with synthetic LLM delays |
| 10 | `orchestrator_new/` — mic/speakers/CLI + `scripts/run_live_v2.sh` | A real laptop run: speak in, hear AI back, transcript prints, events.jsonl populated |
| 11 | `stream_b_new/agents/scorer_agent.py` + `summarizer_agent.py` + `integrity_agent.py` | Async sub-agents fire after turns without blocking the tick |
| 12 | `stream_b_new/observability/langfuse_adapter.py` | When env vars are set, every LLM call appears as a Langfuse generation under a session-scoped trace |
| 13 | Add remaining 6 phase prompts | All 7 phases tested with 1+ mock transcript each |

After step 10 we have a working real-mic interview with one phase. Steps 11-13
add depth without changing structure.

---

## 13. What this plan does NOT cover (explicitly out-of-scope)

- **Teams `.NET` bot integration.** The `AudioSource` interface preserves the
  swap-in path, but the bot itself is the SSOT's Stream D, separate work.
- **Postgres + Redis state tier.** SSOT's three-tier store is replaced with
  in-memory + JSONL for v2 day-one. The `SessionStore` adapter interface lets
  us add Redis later in one PR without touching agent code.
- **TA console.** SSOT's Stream E. Uses the event bus to subscribe later.
- **Diarization, prosody scoring.** SSOT items A-05/A-06. Stream A side, not
  Stream B.
- **Streaming STT partials.** README §F2.3 — depends on Stream A config change.
  The hook (`on_stt_partial`) will be wired through to the director, but
  partials won't flow until Stream A is updated.

---

## 14. Open questions for you to answer before we start building

1. **Models.** Default slow LLM = DeepSeek-V3.2 via OpenRouter (matches v1). Default
   fast LLM = `openai/gpt-4o-mini` via OpenRouter (matches v1). Both swappable
   via flag. **OK?** Or do you want to default to Anthropic Claude Opus 4.7
   per SSOT §13's `ANTHROPIC_MODEL=claude-opus-4-7`?

2. **In-memory state vs. day-one Redis.** I planned in-memory with adapter
   interface to keep the laptop-only run fast. **OK?** Or should Redis be
   required from PR-1?

3. **Tool split granularity.** I split into 5 tools (§6.3). SSOT keeps one
   `respond` tool with embedded fields. The split adds testability but means
   the LLM sometimes emits multiple sequential tool calls per turn (e.g.
   `update_score` then `respond`). **Comfortable with that?** Or merge back
   into a single `respond` tool with sub-sections?

4. **Pre-built phase prompts.** I'd ship one (`warm_up.md`) at PR-7 and stub
   the rest until PR-13. **OK?** Or do you want all 7 written before any
   integration test runs?

5. **Apology fallback wording.** I drafted the bank in §7.5. Should the
   apology be a single canned phrase per phase, or 3-5 variants chosen at
   random to avoid repetition?

6. **Should `IntegrityAgent` be in v2 day-one, or punt to a follow-up PR?**
   It's listed in §6.5 but the live mic mode mostly doesn't surface its
   value. Punting saves ~3 days of prompt work.

7. **Old `orchestrator/` and `stream_b/` — keep around or delete after cutover?**
   I'd keep the v1 dirs until `run_live_v2.sh` is stable for a week, then
   delete. **OK?**

8. **Two-tier model strategy from README §F2.4** — should the fast LLM
   *also* generate the opener of the substantive response (per the SSOT
   "Got it.") AND then DeepSeek pick up the body, or is fast = filler-only?
   The state machine in §7.1 assumes filler-only. The two-tier-opener variant
   is the bigger latency win but is more complex to coordinate.

9. **Tag vocabulary scope (§8A.1).** I defined 12 tags. **Are you OK with
   that surface area on day one?** Each tag adds prompt-engineering work and
   model risk (the LLM might mis-handle a rare tag). The minimum viable set
   is 4: `<barged_in/>`, `<filler.../>`, `<no_response_yet/>`,
   `<silence_ms=.../>`. We could ship those first and add the rest in a
   follow-up.

10. **3-strike threshold & resets (§8B.4).** Default: 3 strikes within the
    current phase, reset on success / 30s silence / phase change. **Tune
    these now or after a few real sessions?** 2 strikes might be too eager;
    4 might be too lenient. I'd recommend keeping 3 + emitting
    `barge_in_strike_increment` so we can post-hoc tune from the event log.

11. **False-endpoint grace window (§8B.1) — 250ms.** Trades 250ms perceived
    latency for ~zero cost waste on partial endpoints. **OK?** Could go as
    low as 150ms but VAD's own jitter sets a floor. Could go higher to 400ms
    if cost matters more than first-audio latency.

12. **Cost ceiling defaults (§8B.5) — soft $2.00 / hard $3.00.** SSOT alerts
    at $2.50. **Keep these or different?** Per-call DeepSeek + Kokoro is
    cheap enough that a 60-min session rarely crosses $1; the ceiling is
    really for "something has gone wrong and we're in a loop" detection.

13. **Tag rendering at write time vs. read time (§10.3).** I picked write
    time (truncated text + tags lives in `Turn.text`; full text in
    `Turn.text_full`). **OK?** Alternative is to keep `Turn.text` clean and
    materialise tags during prompt build — easier to evolve the tag set
    later, but slower per-prompt and prone to history drift.

14. **Backchannel during long monologues (§8F.6) — fire "Mhm." every 15s.**
    **Worth it day-one or punt?** Adds an LLM call (or canned audio if we
    pre-render). Risk: candidate hears it as the AI trying to interrupt.
    Mitigation: very short (<300ms), low-volume, no cancel-on-VAD.

15. **Protected-response audio blocking (§8B.4 step 6).** Should TTS during
    protected mode be **truly uncancellable** (we ignore VAD speech_start
    entirely), or just **harder to cancel** (require 1s of continuous
    candidate speech instead of 200ms)? The former is simpler; the latter
    is safer if the candidate is genuinely panicking. I picked uncancellable
    for the plan; happy to soften.

---

## 15. Summary

- **`orchestrator_new/`**: ~300 lines. Mic + speakers + Stream A boot. No agent.
- **`stream_b_new/`**: a real agentic interviewer with director + sub-agents +
  tools + a state-machine-based latency orchestrator (slow→fast→apology) +
  rich tag-aware conversation context + first-class observability.
- **Every v1 hack has a real home in v2** — `_ai_active` becomes
  `SessionState.ai_activity`, the silence-timer poke becomes
  `last_audio_end_ts_ms`, the sub-ID hack becomes `speak_chunk(turn_id, seq)`,
  the keepalive bandaid becomes a configurable client default, the filler
  side-loaded WS becomes an arbiter inside the latency orchestrator that
  shares the main TTS client.
- **§8 covers production plumbing the v1 README only hinted at** — false-endpoint
  grace, 3-strike protected response, barge-in-during-LLM cancel + merge,
  barge-in-during-TTS truncate + `<barged_in/>` tagging, audio-end grace,
  TTS reconnect, cost ceiling with provider step-down, catastrophic-output
  detection, atomic phase transitions, monologue backchanneling, deterministic
  teardown order. Each path has a dedicated event for postmortems.
- **The tag vocabulary (§8A) is the lever for natural-feeling conversation.**
  The LLM sees what audio actually played, what got cut off, what filler was
  spoken, how long the candidate has been silent. The system prompt teaches
  the meaning of every tag. This is what closes the gap between "AI
  responding" and "AI listening."

Read through, push back where you disagree, answer the 15 questions in §14,
and we start at PR-1 (contracts).
