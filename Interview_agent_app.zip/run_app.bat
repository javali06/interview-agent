@echo off
setlocal enabledelayedexpansion
pushd "%~dp0"

REM ---------------------------------------------------------------------------
REM run_app.bat - single entry point.
REM
REM Boots:
REM   1. Stream A (STT/VAD/TTS) in a separate terminal window
REM   2. The admin web server (FastAPI + uvicorn on :8000) in this window
REM
REM Opens the browser to http://localhost:8000/admin/login.
REM Per-session orchestrators are spawned by the admin server in new
REM terminal windows when the admin clicks "Approve & Generate Link".
REM ---------------------------------------------------------------------------

if not exist ".venv\Scripts\python.exe" (
    echo ERROR: .venv\Scripts\python.exe not found. Set up the venv first:
    echo     uv venv .venv
    echo     uv pip install -e .
    exit /b 2
)

if not exist ".env" (
    echo ERROR: .env not found. Copy .env.example to .env and fill in keys.
    exit /b 2
)

REM 1. Kill stale Stream A processes on 8010/8011/8012 + admin on 8000
for %%P in (8000 8010 8011 8012) do (
    for /f "tokens=5" %%I in ('netstat -ano ^| findstr ":%%P " ^| findstr "LISTENING"') do (
        taskkill /F /PID %%I >nul 2>&1
    )
)

REM 2. Boot Stream A in a separate terminal so its logs are isolated.
echo Booting Stream A in a separate window...
start "Stream A (STT/VAD/TTS)" cmd /k scripts\run_stream_a_only.bat

REM 3. Wait for Stream A /healthz before starting the admin server.
echo Waiting for Stream A to come up (this is ~30-60s on first run after a reboot)...
set /a "ELAPSED=0"
:waithealth
curl -sf http://127.0.0.1:8010/healthz >nul 2>&1
if errorlevel 1 goto notyet
curl -sf http://127.0.0.1:8011/healthz >nul 2>&1
if errorlevel 1 goto notyet
curl -sf http://127.0.0.1:8012/healthz >nul 2>&1
if errorlevel 1 goto notyet
goto allup

:notyet
if !ELAPSED! GEQ 900 goto failed
timeout /t 2 /nobreak >nul
set /a "ELAPSED+=2"
if !ELAPSED! GEQ 30 (
    set /a "MOD=ELAPSED %% 15"
    if !MOD! EQU 0 echo   [+!ELAPSED!s] still waiting on Stream A healthz...
)
goto waithealth

:failed
echo.
echo ERROR: Stream A did not come up in 15 min. Check the Stream A window for errors.
exit /b 3

:allup
echo Stream A ready.

REM 4. Open browser to admin login. (Browser may briefly show a connection
REM    error if it loads before uvicorn binds on the next line; refresh and
REM    it will work — uvicorn typically binds in under a second.)
start "" "http://localhost:8000/admin/login"

REM 5. Run uvicorn in the foreground of THIS window. Closing this window
REM    stops the admin server. The Stream A window is independent.
echo.
echo ============================================================
echo   ADMIN APP STARTING on http://localhost:8000
echo   Sign in via the browser tab that just opened.
echo.
echo   This window: admin server logs.
echo   Other window: Stream A (STT/VAD/TTS) logs.
echo   Per-interview windows: opened when admin approves a cadence.
echo ============================================================
echo.

.venv\Scripts\python.exe -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload --reload-dir app
popd
endlocal
