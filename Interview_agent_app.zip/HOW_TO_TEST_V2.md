# How to test the v2 build (live mic on your laptop)

This is the end-to-end runbook for the rewrite that lives in `stream_b_new/`
and `orchestrator_new/`. Five-minute version: plug in headphones, run one
shell command, talk.

---

## 0. One-time prerequisites

If you've already run v1 (`./scripts/run_live.sh`) successfully, **skip this
whole section** — your environment already has everything.

```bash
# from STREAM_A_B_Integration/
brew install espeak-ng portaudio        # macOS
# apt install espeak-ng portaudio19-dev   # Linux

# Python 3.12 venv (3.13+ has no wheels for ctranslate2 on macOS Intel)
uv venv --python 3.12 .venv
VIRTUAL_ENV=$(pwd)/.venv uv pip install -e ".[dev]"

# Pre-download Whisper so first run isn't held up by 1.5GB of HF traffic
.venv/bin/python -c "from huggingface_hub import snapshot_download; \
  snapshot_download('Systran/faster-distil-whisper-large-v3')"

# OpenRouter key — same file the v1 script uses
echo 'OPENROUTER_API_KEY=sk-or-v1-...' >> .env
```

The Silero VAD ONNX is bundled at `stream_a/models/silero_vad.onnx` already.

---

## 1. Plug in headphones (seriously)

Without headphones, AI audio plays through your speakers, gets picked up by
the mic, and triggers a feedback loop:

> VAD treats the AI's voice as candidate speech → barge-in fires → cancels
> the AI turn → strike counter ticks up → after 3 strikes, protected mode
> kicks in and the AI speaks over its own echo with a "let me get this
> right" canned line. The session degenerates fast.

There is no software echo cancellation in the pipeline. **Headphones or
earbuds, every time.**

---

## 2. Run it

```bash
cd /path/to/STREAM_A_B_Integration
./scripts/run_live_v2.sh
```

Output goes through three phases:

```
1. "killing stale process on :8010 (pids: ...)"          ← any leftover services
2. "starting STT/VAD/TTS"                                 ← Stream A subprocesses
3. "waiting for healthchecks (up to 15 min)"              ← models loading
   (heartbeats every 30s if any service still warming)
4. "Stream A services ready (took 18s)"                   ← good to go
5. "running orchestrator_new (live mic)"                  ← speak now
```

When you see this banner:

```
======================================================================
  LIVE MIC MODE — speak into your microphone
  Press Ctrl-C to end the interview
======================================================================
```

Talk. The agent is in the `warm_up` phase and will greet you within ~2-3s.

Hit **Ctrl-C** to end. The transcript and event-log path print at exit.

---

## 3. Useful flags

All optional. Defaults match the plan in `NEW_STREAM_B.md`.

```bash
# Interview persona / opening
./scripts/run_live_v2.sh \
  --candidate-name "Ayush" \
  --role "Senior Backend Engineer" \
  --resume-summary "5 years on Kafka pipelines; recently led a Redis migration."

# Filler tuning (NEW_STREAM_B.md §7)
./scripts/run_live_v2.sh --filler-threshold-ms 500   # tighter — filler fires sooner
./scripts/run_live_v2.sh --filler-threshold-ms 1500  # looser
./scripts/run_live_v2.sh --canned-filler             # skip fast LLM, use canned phrases
./scripts/run_live_v2.sh --no-filler                 # no filler at all

# Apology fallback
./scripts/run_live_v2.sh --apology-threshold-ms 4000

# Protected-response mode (§8B.4)
./scripts/run_live_v2.sh --strike-threshold 2        # tighter — fires after 2 strikes
./scripts/run_live_v2.sh --strike-threshold 5        # more lenient

# Models
./scripts/run_live_v2.sh --slow-model "openai/gpt-4o"
./scripts/run_live_v2.sh --fast-model "groq/llama-3.1-8b-instant"

# Phases
./scripts/run_live_v2.sh --initial-phase project_deep_dive

# Turn-taking
./scripts/run_live_v2.sh --silence-prompt-ms 5000    # AI prompts you sooner on silence
./scripts/run_live_v2.sh --endpoint-tail-ms 800      # waits longer after you stop

# Debugging
./scripts/run_live_v2.sh --no-playback               # silent run; only events.jsonl
./scripts/run_live_v2.sh --log-level DEBUG           # very chatty stdout
./scripts/run_live_v2.sh --prewarm                   # play a brief "Hi" at startup to warm Kokoro
```

---

## 4. What to listen for — the four interactions to verify

### 4a. Plain back-and-forth (the happy path)

Say something like *"Hi, my name is Ayush. I'm a backend engineer at a
fintech."* Pause. Within 1-3 seconds the AI greets you and asks a follow-up.
Expected console:

```
INFO orchestrator_new mic capture started @ 16000 Hz, 320-sample frames
INFO STT connected ...
INFO VAD connected ...
INFO TTS connected ...
INFO ... (the AI's response streams to TTS)
```

Look in `/tmp/integration/events.jsonl`:

```bash
jq -r '.kind' /tmp/integration/events.jsonl | sort | uniq -c | sort -rn
```

You should see `director_tick` (lots), `stt_partial`, `stt_final`,
`policy_decision`, `llm_call_started`, `llm_call_completed`,
`tts_speak_chunk_sent`, `tts_audio_start`, `tts_audio_end`, `ai_utterance`.

### 4b. Filler activation (§7 / §F1)

Stay silent for ~10 seconds after the AI's first turn. The AI should fire
Rule 4 ("silence_prompt") and gently re-engage.

Then answer something. Within ~800ms of you stopping, you'll either:

- Hear the filler ("Got it.", "Mhm — interesting.", etc.) followed seamlessly
  by the substantive AI response, **or**
- Hear just the substantive response (because the slow LLM was fast enough).

In events.jsonl: `filler_dispatched` then `filler_spoken` if the filler fired.
The next AI turn will start with `<filler text="..."/>` in `payload.text`.

### 4c. Barge-in mid-AI (§8B.3)

Wait until the AI is mid-sentence. Talk over it. Expected:

- AI's audio cuts off within ~250-500ms.
- `events.jsonl` shows `tts_cancelled`, then `ai_response_barged_in` with
  `played_words` < `total_words`.
- The AI's recorded turn ends with `<barged_in/>` (visible in transcript at
  exit).
- Strike counter increments — `barge_in_strike_increment` event with
  `new_count: 1`.

### 4d. Protected-response mode (§8B.4)

Repeat (4c) **three times in a row**. After the third interruption you should
hear: *"Let me make sure I have the full picture before I respond — give me
a few seconds to get this right."* Then a single uncancellable AI turn that
addresses everything you said. Expected:

- `events.jsonl` shows `barge_in_strike_increment new_count: 3`.
- `protected_response_mode_entered`.
- `apology_dispatched` with the canned phrase.
- One slow LLM call → one AI turn (talk over it; nothing happens, that's the
  point).
- `protected_response_mode_exited` after audio_end. Strike counter resets.

---

## 5. Reading the event log

Everything is in `/tmp/integration/events.jsonl`. Each line is one event.
Some recipes:

```bash
# The full timeline of a session, just kinds + timestamps:
jq -r '"\(.ts)  \(.kind)"' /tmp/integration/events.jsonl

# Just the conversation text (what was said + the LLM's intended response):
jq -r 'select(.kind=="stt_final") | "[cand] \(.payload.text)"' /tmp/integration/events.jsonl
jq -r 'select(.kind=="ai_utterance") | "[ai  ] \(.payload.text)"' /tmp/integration/events.jsonl

# The actual prompts the slow LLM saw (debugging the AI's reasoning):
jq -r 'select(.kind=="llm_call_started") | .payload.user_prompt' /tmp/integration/events.jsonl

# Latency timings per turn:
jq -r 'select(.kind=="llm_call_completed") | "\(.payload.agent) ttft=\(.payload.ttft_ms)ms latency=\(.payload.latency_ms)ms"' \
    /tmp/integration/events.jsonl

# Did barge-in fire? When? Did we enter protected mode?
jq -r 'select(.kind | test("barge|protected|cancelled")) | "\(.ts)  \(.kind)  \(.payload)"' \
    /tmp/integration/events.jsonl
```

## 6. Per-service logs

If something looks wrong — e.g. the AI never speaks, or the mic doesn't
capture — check Stream A's per-service logs:

```bash
tail -f /tmp/integration_logs/stt.log     # what STT thinks it heard
tail -f /tmp/integration_logs/vad.log     # speech_start/end/endpoint timings
tail -f /tmp/integration_logs/tts.log     # Kokoro synthesis timings
```

The orchestrator's own logs are on stdout (set `--log-level DEBUG` for verbose).

---

## 7. Common things that might go wrong (and what to check first)

| Symptom | Most likely cause | Fix |
|---|---|---|
| `OPENROUTER_API_KEY not found` | `.env` missing the key | `echo 'OPENROUTER_API_KEY=...' >> STREAM_A_B_Integration/.env` |
| "Stream A services failed to come up in 15 min" | Whisper model still downloading on slow connection | Re-run; or download manually per §0 |
| Mic captures but AI never responds | Health-checks passed but a Stream A service crashed mid-session | `tail /tmp/integration_logs/{stt,vad,tts}.log` for tracebacks |
| AI speaks instantly then cuts off | Without headphones — TTS plays through speakers, mic picks it up, treats it as barge-in | **Headphones.** See §1. |
| AI loops "let me get the full picture" | Stuck in protected mode because feedback loop keeps triggering strikes | Headphones. Then `--strike-threshold 5` to make it less eager. |
| TTS audio glitchy / underruns | `bytes_buffered()` warnings. Probably a slow Kokoro warmup | Pass `--prewarm` so first synthesis isn't real-time |
| `1011 keepalive ping timeout` | A Stream A service died mid-session and TTSClient detected the WS drop | Check the corresponding service log; usually a Python traceback in there |
| Filler text bleeds into the AI's substantive turn | The slow LLM started saying "Got it" too — the system prompt's "don't re-acknowledge" rule isn't being followed | Try `--no-filler` to confirm; consider adjusting the prompt in `prompts/system_prompt.md` |

---

## 8. Difference vs v1 (`run_live.sh`)

Same Stream A. Different agent. Side-by-side flags map cleanly:

| v1 flag | v2 flag | Notes |
|---|---|---|
| `--filler-threshold-s 1.0` | `--filler-threshold-ms 800` | Tightened default per README §F2 |
| `--filler-model openai/gpt-4o-mini` | `--fast-model openai/gpt-4o-mini` | Same default |
| `--filler-model canned` | `--canned-filler` | |
| `--no-filler` | `--no-filler` | Same |
| (none) | `--apology-threshold-ms 2500` | NEW — §7 apology fallback |
| (none) | `--strike-threshold 3` | NEW — §8B.4 protected response |
| (none) | `--prewarm` | NEW — §8C.5 |

v2's event log has a **superset** of v1's events plus the engineering
edge-case kinds from `NEW_STREAM_B.md` §9.2 (e.g. `barge_in_strike_increment`,
`protected_response_mode_entered`, `false_endpoint_dropped`). Old jq recipes
keep working; new ones unlock.

---

## 9. If you only have 60 seconds to verify the build works

```bash
cd /path/to/STREAM_A_B_Integration

# Smoke test: just check the package layers parse and CLI works.
.venv/bin/python -m orchestrator_new.live_main --help | head -5

# If that prints, you're good. Then for an actual run:
./scripts/run_live_v2.sh
# (talk into mic, Ctrl-C, read the transcript)
```
