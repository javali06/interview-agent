#!/usr/bin/env python3
"""
render_dashboard.py — build a self-contained dashboard.html from metrics.json.

`render(metrics: dict) -> str` returns a single HTML string (no external assets,
no CDN). analyze.py calls this; you can also run it standalone against an
existing metrics.json:

    python3 render_dashboard.py metrics.json > dashboard.html
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

# The page is static HTML + vanilla JS. Metrics are injected as JSON at the
# __METRICS_JSON__ token (string replace, so the JS braces are left untouched).
_TEMPLATE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Interview Concurrency Capacity</title>
<style>
  :root{
    --bg:#0f1216; --panel:#171b22; --panel2:#1e242d; --line:#2a323d;
    --text:#e6edf3; --mute:#9aa7b4; --accent:#4f9cff; --accent2:#7c5cff;
    --slow:#4f9cff; --fast:#3fb950; --danger:#f85149; --warn:#d29922; --ok:#3fb950;
  }
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--text);
    font:14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
  .wrap{max-width:1180px;margin:0 auto;padding:28px 20px 80px}
  h1{font-size:22px;margin:0 0 4px}
  h2{font-size:15px;text-transform:uppercase;letter-spacing:.06em;color:var(--mute);
    margin:34px 0 12px;border-bottom:1px solid var(--line);padding-bottom:6px}
  .sub{color:var(--mute);font-size:13px}
  .grid{display:grid;gap:14px}
  .panel{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:16px}
  .mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
  code{background:var(--panel2);padding:1px 5px;border-radius:4px;font-size:12.5px}
  table{width:100%;border-collapse:collapse}
  th,td{text-align:right;padding:7px 10px;border-bottom:1px solid var(--line);white-space:nowrap}
  th:first-child,td:first-child{text-align:left}
  th{color:var(--mute);font-weight:600;font-size:12px;text-transform:uppercase;letter-spacing:.04em}
  .tag{display:inline-block;padding:1px 7px;border-radius:20px;font-size:11px;font-weight:600}
  .tag.slow{background:#132a45;color:#8cc2ff}
  .tag.fast{background:#12331d;color:#79e08e}
  /* answer hero */
  .hero{display:grid;grid-template-columns:1.1fr .9fr;gap:16px}
  @media(max-width:820px){.hero{grid-template-columns:1fr}}
  .bignum{font-size:64px;font-weight:800;line-height:1;letter-spacing:-.02em}
  .bignum small{font-size:16px;font-weight:600;color:var(--mute);letter-spacing:0}
  .bottleneck{font-size:15px;margin-top:8px}
  .pill{display:inline-block;padding:3px 10px;border-radius:6px;font-weight:700}
  .pill.speech{background:#3a2a12;color:#f0c674}
  .pill.rpm,.pill.tpm{background:#2a1230;color:#e29bff}
  .pill.conc{background:#12222a;color:#8fe3ff}
  /* input controls */
  .ctl{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:6px 0}
  .ctl label{color:var(--mute)}
  .ctl input{width:130px;background:var(--panel2);border:1px solid var(--line);color:var(--text);
    border-radius:6px;padding:6px 8px;font-family:ui-monospace,monospace;text-align:right}
  .ctl input:focus{outline:1px solid var(--accent);border-color:var(--accent)}
  .ceilbar{display:flex;flex-direction:column;gap:9px;margin-top:6px}
  .ceilrow{display:grid;grid-template-columns:150px 1fr 70px;align-items:center;gap:10px}
  .ceilrow .name{color:var(--mute);font-size:13px}
  .track{background:var(--panel2);border-radius:6px;height:22px;overflow:hidden;position:relative}
  .fill{height:100%;border-radius:6px;transition:width .18s}
  .ceilrow .val{text-align:right;font-weight:700;font-family:ui-monospace,monospace}
  .binder .name{color:var(--danger);font-weight:700}
  .note{color:var(--mute);font-size:12.5px;margin-top:10px}
  .warnbox{background:#2a1f0e;border:1px solid #5c4410;color:#f0c674;border-radius:8px;
    padding:10px 12px;font-size:13px;margin-top:12px}
  svg{display:block;width:100%;height:auto}
  .legend{display:flex;gap:16px;flex-wrap:wrap;font-size:12.5px;color:var(--mute);margin-top:6px}
  .dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:5px;vertical-align:middle}
  .kv{display:grid;grid-template-columns:auto 1fr;gap:4px 14px;font-size:13px}
  .kv b{color:var(--mute);font-weight:600}
  .two{display:grid;grid-template-columns:1fr 1fr;gap:14px}
  @media(max-width:820px){.two{grid-template-columns:1fr}}
</style>
</head>
<body>
<div class="wrap">
  <h1>Interview Concurrency &amp; Capacity</h1>
  <div class="sub" id="hdr"></div>

  <h2>How many interviews can I run in parallel?</h2>
  <div class="hero">
    <div class="panel">
      <div class="sub">Ceiling with your current limits</div>
      <div class="bignum" id="answer">—</div>
      <div class="bottleneck" id="bottleneck"></div>
      <div class="ceilbar" id="ceilbar"></div>
      <div class="note" id="keysneeded" style="margin-top:12px;color:var(--text)"></div>
      <div class="note" id="ratehint"></div>
    </div>
    <div class="panel">
      <div class="sub" style="margin-bottom:8px">Your limits — <b>OpenRouter account-level</b>, from
        <code>GET /api/v1/key</code> (not per-provider — see routing panel below)</div>
      <div class="ctl"><label title="Your key returned rate_limit.requests = -1 (deprecated) → OpenRouter enforces no RPM. Leave checked."><b>OpenRouter: no enforced rate limit</b> (paid key)</label><input id="or_unlimited" type="checkbox" style="width:auto"></div>
      <div id="or_rate_inputs" style="opacity:.45">
        <div class="ctl"><label title="Only if OpenRouter DOES cap you (free key / provisioned limit)">OpenRouter RPM limit</label><input id="or_rpm" type="number" min="1"></div>
        <div class="ctl"><label>OpenRouter TPM limit</label><input id="or_tpm" type="number" min="1"></div>
        <div class="ctl"><label>Max concurrent requests</label><input id="or_conc" type="number" min="1"></div>
      </div>
      <div class="ctl"><label title="usage-gated, not rate-gated: you run out of money, not throughput">OpenRouter credits left ($)</label><input id="or_credits" type="number" min="0" step="0.01"></div>
      <div class="ctl"><label title="Azure concurrent STT streams per Speech key (repo assumes 5)">Azure STT streams / key</label><input id="sp_streams" type="number" min="1"></div>
      <div class="ctl"><label>Azure Speech keys</label><input id="sp_keys" type="number" min="1"></div>
      <div class="ctl"><label title="How many simultaneous interviews you want to support — computes keys needed">Target concurrent interviews</label><input id="tgt_concurrent" type="number" min="1"></div>
      <div class="ctl"><label title="Leave headroom below the hard limit">Safety margin %</label><input id="margin" type="number" min="0" max="90"></div>
      <div class="ctl"><label title="Ceilings barely move with length; cost + worst-case slow context do">Target interview length (min)</label><input id="tgt_min" type="number" min="1"></div>
      <div class="note">Your key has <b>no enforced OpenRouter rate limit</b>, so the LLM side does not
        cap concurrency — only your <b>credit balance</b> does (a spend budget). The binding constraint
        is <b>Azure Speech</b>. Add Speech keys to scale.</div>
    </div>
  </div>

  <h2>Per-interview demand — what one live interview draws</h2>
  <div class="panel">
    <table>
      <thead><tr><th>Component</th><th>Model</th><th>RPM</th><th>TPM avg</th>
        <th>TPM peak / 60s</th><th>Peak concurrent</th></tr></thead>
      <tbody id="demand"></tbody>
    </table>
    <div class="note">RPM/TPM = requests / tokens per minute for <b>one</b> interview. The
      <b>peak/60s</b> column is the worst 60-second window (what a rate limiter actually sees).
      "All (one OR key)" is the sum, because a single OpenRouter key serves both models across
      every interview.</div>
  </div>

  <h2>Slow-LLM context growth — the "prompts get huge" question</h2>
  <div class="two">
    <div class="panel">
      <div id="growthchart"></div>
      <div class="legend"><span><span class="dot" style="background:var(--slow)"></span>question_agent tokens_in per turn</span></div>
    </div>
    <div class="panel">
      <div class="kv" id="growthkv"></div>
      <div class="warnbox" id="growthwarn"></div>
    </div>
  </div>

  <h2>LLM request timeline — where calls overlap (this sample)</h2>
  <div class="panel">
    <div id="timeline"></div>
    <div class="legend">
      <span><span class="dot" style="background:var(--slow)"></span>question (slow)</span>
      <span><span class="dot" style="background:var(--fast)"></span>verifier / override (fast)</span>
      <span class="sub">bar length = request latency; stacked bars = concurrent in-flight calls</span>
    </div>
  </div>

  <h2>Azure Speech</h2>
  <div class="panel" id="speech"></div>

  <h2>Provider routing &amp; limits (researched, OpenRouter · Jul 2026)</h2>
  <div class="panel">
    <div class="warnbox" style="background:#0e2233;border-color:#164a63;color:#8fd6ff">
      <b>Two separate limits — don't conflate them:</b><br>
      <b>(1) OpenRouter account limit → none for you.</b> <code>/api/v1/key</code> returns
      <code>rate_limit.requests = -1</code> (deprecated) and <code>byok_usage = 0</code>; the only account
      ceiling is <b>credit balance</b> (a spend budget).<br>
      <b>(2) Upstream provider limit → real.</b> OpenRouter defers each call to a provider; a provider 429
      comes back as <i>"provider returned error"</i>. Because you're <b>not on BYOK</b>, you share OpenRouter's
      <b>pooled</b> capacity with each provider — a 429 fires when OpenRouter's <i>total</i> traffic to that
      provider (all users) exceeds the quota it secured, <b>not</b> your personal "Groq 30 RPM / 8k TPM" free-tier
      numbers. So it's a <b>shared-pool reliability risk under load</b>, not a fixed per-user ceiling.<br>
      <b>Mitigation (you already have it):</b> <code>allow_fallbacks:false</code> + your order list means a 429
      walks <b>Groq→Baseten→Cerebras</b> (slow) / <b>Groq→DeepInfra</b> (fast) before erroring; if all error, the
      turn degrades to a canned filler (not a crash). Add client retry/backoff + <code>MAX_LLM_INFLIGHT</code> admission.<br>
      <b>For predictable, controllable limits: use BYOK</b> — then your OWN provider tier applies (known TPM/RPM,
      usually far roomier), and you size it against the per-interview demand table above. Extra OpenRouter keys do
      NOT help (capacity is governed globally). Net: <b>Azure Speech is the hard cap; provider 429s are a soft risk on top.</b>
    </div>
    <div class="two" style="margin-top:14px">
      <div>
        <div class="sub" style="margin-bottom:6px"><span class="tag slow">slow · gpt-oss-120b</span>
          order: Groq → Baseten → Cerebras</div>
        <table><thead><tr><th>Provider</th><th>ctx</th><th>max out</th><th>$in/Mtok</th><th>$out/Mtok</th><th>uptime 1d</th></tr></thead><tbody>
          <tr><td>Groq <span class="sub">(primary)</span></td><td>131k</td><td>65,536</td><td>0.15</td><td>0.60</td><td>99.99%</td></tr>
          <tr><td>Baseten</td><td>128k</td><td>128,072</td><td>0.10</td><td>0.50</td><td>99.86%</td></tr>
          <tr><td>Cerebras</td><td>131k</td><td><b>40,960</b></td><td>0.35</td><td>0.75</td><td>99.99%</td></tr>
        </tbody></table>
      </div>
      <div>
        <div class="sub" style="margin-bottom:6px"><span class="tag fast">fast · llama-3.1-8b-instruct</span>
          order: Groq → DeepInfra</div>
        <table><thead><tr><th>Provider</th><th>ctx</th><th>max out</th><th>$in/Mtok</th><th>$out/Mtok</th><th>uptime 1d</th></tr></thead><tbody>
          <tr><td>Groq <span class="sub">(primary)</span></td><td>131k</td><td>131,072</td><td>0.05</td><td>0.08</td><td>99.97%</td></tr>
          <tr><td>DeepInfra <span class="sub">(fp8)</span></td><td>131k</td><td>16,384</td><td>0.02</td><td>0.03</td><td>99.96%</td></tr>
          <tr><td>DeepInfra <span class="sub">(bf16)</span></td><td>131k</td><td>16,384</td><td>0.02</td><td>0.05</td><td>98.17%</td></tr>
        </tbody></table>
      </div>
    </div>
    <div class="note">DeepInfra is <b>concurrency-limited</b> (≈200 concurrent/model default, autoscales) rather than
      RPM-capped. <b>Guardrail:</b> keep <code>SLOW_LLM_MAX_TOKENS</code> under the smallest provider's
      <code>max out</code> in the order list — for slow that's <b>Cerebras 40,960</b> (your outputs are ~300–700 tok,
      so you're fine). Context (128–131k) dwarfs your ~5k prompts, so length is never the LLM constraint.
      Prices here match your <code>llm_models.yaml</code> Groq route.</div>
  </div>

  <h2>Per-model rollup</h2>
  <div class="panel"><table>
    <thead><tr><th>Model</th><th>Agents</th><th>Calls</th><th>Tokens in</th>
      <th>Tokens out</th><th>RPM</th><th>TPM avg</th><th>Cost</th></tr></thead>
    <tbody id="models"></tbody>
  </table></div>

  <div class="note" id="foot" style="margin-top:26px"></div>
</div>

<script id="metrics" type="application/json">__METRICS_JSON__</script>
<script>
const M = JSON.parse(document.getElementById('metrics').textContent);
const $ = id => document.getElementById(id);
const fmt = (n,d=0) => (n==null?'—':Number(n).toLocaleString(undefined,{maximumFractionDigits:d,minimumFractionDigits:d}));
const floor = Math.floor;

// ── header ──────────────────────────────────────────────────────────────
const s = M.session, pi = M.per_interview;
$('hdr').innerHTML =
  `${M.log_count} log(s) · mean ${(pi.duration_s_mean/60).toFixed(1)} min/interview · `+
  `slow <code>${s.slow_model||'?'}</code> · fast <code>${s.fast_model||'?'}</code>`;

// ── inputs seeded from defaults ───────────────────────────────────────────
const d = M.defaults;
const numInputs = {or_rpm:'or_rpm_limit', or_tpm:'or_tpm_limit', or_conc:'or_concurrent_limit',
  or_credits:'or_credits_remaining', sp_streams:'speech_streams_per_key', sp_keys:'speech_keys',
  margin:'safety_margin_pct', tgt_min:'target_interview_min', tgt_concurrent:'target_concurrent'};
for(const [el,key] of Object.entries(numInputs)){ $(el).value = d[key]; $(el).addEventListener('input', recompute); }
$('or_unlimited').checked = !!d.or_unlimited;
$('or_unlimited').addEventListener('change', ()=>{ $('or_rate_inputs').style.opacity = $('or_unlimited').checked?'.45':'1'; recompute(); });

const O = pi.openrouter_all;

function recompute(){
  const unlimited=$('or_unlimited').checked;
  $('or_rate_inputs').style.opacity = unlimited?'.45':'1';
  const orRpm=+$('or_rpm').value, orTpm=+$('or_tpm').value, orConc=+$('or_conc').value;
  const spS=+$('sp_streams').value, spK=+$('sp_keys').value, mg=1-(+$('margin').value)/100, tgt=+$('tgt_min').value;

  // Azure Speech: STT holds one stream for the whole interview.
  const ceil = { 'Azure Speech': {v: spS*spK, cls:'speech',
                   why:`${spS} streams/key × ${spK} key(s), 1 stream/interview`} };
  // OpenRouter rate ceilings apply ONLY if your key is actually rate-capped.
  // Yours returns rate_limit.requests = -1 → unlimited, so these drop out.
  if(!unlimited){
    ceil['OpenRouter RPM']={v: floor(orRpm*mg/Math.max(O.rpm_peak60,1e-9)), cls:'rpm',
      why:`${fmt(orRpm)} × ${(mg*100)|0}% ÷ ${fmt(O.rpm_peak60,1)} peak RPM/interview`};
    ceil['OpenRouter TPM']={v: floor(orTpm*mg/Math.max(O.tpm_peak60,1e-9)), cls:'tpm',
      why:`${fmt(orTpm)} × ${(mg*100)|0}% ÷ ${fmt(O.tpm_peak60)} peak TPM/interview`};
    ceil['Concurrent req']={v: floor(orConc*mg/Math.max(O.peak_concurrent,1)), cls:'conc',
      why:`${fmt(orConc)} × ${(mg*100)|0}% ÷ ${O.peak_concurrent} concurrent/interview`};
  }
  const entries = Object.entries(ceil);
  const minV = Math.min(...entries.map(([_,c])=>c.v));
  const binder = entries.find(([_,c])=>c.v===minV)[0];
  const maxV = Math.max(...entries.map(([_,c])=>c.v), 1);

  $('answer').innerHTML = `${minV<0?0:minV} <small>concurrent interviews</small>`;
  $('bottleneck').innerHTML = `Bottleneck: <span class="pill ${ceil[binder].cls}">${binder}</span>`
    + (unlimited? ` <span class="sub">· OpenRouter rate limit: none (credit-gated)</span>`:``);

  $('ceilbar').innerHTML = entries
    .sort((a,b)=>a[1].v-b[1].v)
    .map(([name,c])=>{
      const w = Math.max(3, 100*c.v/maxV);
      const col = name===binder? 'var(--danger)': 'var(--accent)';
      return `<div class="ceilrow ${name===binder?'binder':''}" title="${c.why}">
        <div class="name">${name}</div>
        <div class="track"><div class="fill" style="width:${w}%;background:${col}"></div></div>
        <div class="val">${c.v}</div></div>`;
    }).join('');

  // Keys-needed planner: to hit a target concurrency, how many Speech keys?
  const tgtC = Math.max(1, +$('tgt_concurrent').value||1);
  const keysNeeded = Math.ceil(tgtC / Math.max(spS,1));
  const orNote = unlimited
    ? 'OpenRouter sets no account cap (credit-gated); watch for upstream provider 429s under load — your failover + retry mitigate.'
    : `also confirm the OpenRouter ceilings above still clear ${tgtC}.`;
  $('keysneeded').innerHTML =
    `<b>Capacity planner:</b> to run <b>${tgtC}</b> concurrent interviews at ${spS} streams/key, `+
    `provision <b>${keysNeeded}</b> Azure Speech key(s) `+
    `(<code>AZURE_SPEECH_KEYS</code>, ${keysNeeded}×${spS} = ${keysNeeded*spS} streams). ${orNote}`;

  // The real OpenRouter constraint is the credit BUDGET, not a rate.
  const costAt = M.per_interview.cost_usd * (tgt/(pi.duration_s_mean/60));
  const credits=+$('or_credits').value;
  const runway = costAt>0? floor(credits/costAt) : 0;
  $('ratehint').innerHTML =
    `At <b>${tgt} min</b>/interview ≈ <b>$${costAt.toFixed(4)}</b> LLM each. `+
    (unlimited
      ? `OpenRouter caps you by <b>spend</b>, not rate: <b>$${credits.toFixed(2)}</b> left ≈ `+
        `<b>${runway}</b> more ${tgt}-min interviews before top-up (any concurrency).`
      : `Rate ceilings barely change with interview length.`);
}

// ── per-interview demand table ────────────────────────────────────────────
const rows = [
  ['Slow (question)','slow', s.slow_model, pi.slow.rpm, pi.slow.tpm_avg, pi.slow.tpm_peak60, pi.slow.peak_concurrent],
  ['Fast (verifier + override)','fast', s.fast_model, pi.fast.rpm, pi.fast.tpm_avg, pi.fast.tpm_peak60, pi.fast.peak_concurrent],
  ['All (one OR key)','', '—', O.rpm_avg, O.tpm_avg, O.tpm_peak60, O.peak_concurrent],
];
$('demand').innerHTML = rows.map(r=>{
  const tag = r[1]? `<span class="tag ${r[1]}">${r[0]}</span>` : `<b>${r[0]}</b>`;
  return `<tr><td>${tag}</td><td class="mono sub">${(r[2]||'').split('/').pop()}</td>
    <td>${fmt(r[3],1)}</td><td>${fmt(r[4])}</td><td>${fmt(r[5])}</td><td>${r[6]}</td></tr>`;
}).join('');

// ── slow-LLM growth ───────────────────────────────────────────────────────
const g = M.slow_growth;
const slowTl = M.timeline.filter(c=>c.agent==='question_agent');
$('growthkv').innerHTML = [
  ['Base tokens_in', fmt(g.base_tin)],
  ['Max seen (this log)', fmt(g.max_tin)],
  ['Growth within a phase', `~${fmt(g.slope_tok_per_min)} tokens/min`],
  ['Context resets', `${g.resets} (phase boundaries)`],
].map(([k,v])=>`<b>${k}</b><span class="mono">${v}</span>`).join('');
{
  const tgt=+$('tgt_min').value||60;
  const worst = g.base_tin + g.slope_tok_per_min*tgt;
  $('growthwarn').innerHTML = g.slope_tok_per_min>0
    ? `Context <b>resets ${g.resets}×</b> here (per phase), so it stays bounded — it did not grow unbounded.
       Worst case: if a <b>single phase</b> ran the full ${tgt} min at ~${fmt(g.slope_tok_per_min)} tok/min,
       one slow prompt would reach ≈ <b>${fmt(worst)} tokens_in</b>. Keep phases time-boxed to cap this.`
    : `Slow context looks flat in this log — no meaningful growth measured.`;
}
drawGrowth();
function drawGrowth(){
  const W=560,H=200,pad=36;
  if(!slowTl.length){$('growthchart').innerHTML='<div class="sub">no slow calls</div>';return;}
  const xs=slowTl.map(c=>c.t), ys=slowTl.map(c=>c.tin);
  const xmax=Math.max(...xs,1), ymax=Math.max(...ys,1)*1.1;
  const X=t=>pad+(W-2*pad)*t/xmax, Y=v=>H-pad-(H-2*pad)*v/ymax;
  const pts=slowTl.map(c=>`${X(c.t).toFixed(1)},${Y(c.tin).toFixed(1)}`).join(' ');
  const dots=slowTl.map(c=>`<circle cx="${X(c.t).toFixed(1)}" cy="${Y(c.tin).toFixed(1)}" r="3" fill="var(--slow)"><title>t=${c.t}s  ${c.tin} tok_in</title></circle>`).join('');
  const yticks=[0,.5,1].map(f=>{const v=ymax*f;return `<text x="4" y="${(Y(v)+4).toFixed(1)}" fill="var(--mute)" font-size="10">${fmt(v)}</text><line x1="${pad}" y1="${Y(v).toFixed(1)}" x2="${W-pad}" y2="${Y(v).toFixed(1)}" stroke="var(--line)"/>`;}).join('');
  $('growthchart').innerHTML=`<svg viewBox="0 0 ${W} ${H}">${yticks}
    <polyline points="${pts}" fill="none" stroke="var(--slow)" stroke-width="2"/>${dots}
    <text x="${W-pad}" y="${H-8}" fill="var(--mute)" font-size="10" text-anchor="end">time → (${fmt(xmax)}s)</text></svg>`;
}

// ── request timeline (overlap view) ────────────────────────────────────────
function drawTimeline(){
  const tl=M.timeline; if(!tl.length){$('timeline').innerHTML='<div class="sub">no calls</div>';return;}
  const W=1100,rowH=13,pad=30;
  const tmax=Math.max(...tl.map(c=>c.t+ c.lat_ms/1000),1);
  const X=t=>pad+(W-2*pad)*t/tmax;
  // Greedy lane packing so overlapping calls stack (visualises concurrency).
  const lanes=[]; const placed=[];
  tl.forEach(c=>{
    const a=c.t - c.lat_ms/2000, b=c.t + c.lat_ms/2000;
    let li=lanes.findIndex(end=>a>=end);
    if(li<0){li=lanes.length;lanes.push(b);} else lanes[li]=b;
    placed.push({c,a,b,li});
  });
  const H=pad+lanes.length*rowH+22;
  const bars=placed.map(({c,a,b,li})=>{
    const col=c.agent==='question_agent'?'var(--slow)':'var(--fast)';
    const x=X(a), w=Math.max(2,X(b)-X(a)), y=pad+li*rowH;
    return `<rect x="${x.toFixed(1)}" y="${y}" width="${w.toFixed(1)}" height="${rowH-3}" rx="2" fill="${col}" opacity=".9"><title>${c.agent} ${c.model} · ${c.lat_ms}ms · ${c.tin}→${c.tout} tok · t=${c.t}s</title></rect>`;
  }).join('');
  const axis=[0,.25,.5,.75,1].map(f=>{const t=tmax*f;return `<text x="${X(t).toFixed(1)}" y="${H-6}" fill="var(--mute)" font-size="10" text-anchor="middle">${fmt(t)}s</text><line x1="${X(t).toFixed(1)}" y1="${pad}" x2="${X(t).toFixed(1)}" y2="${pad+lanes.length*rowH}" stroke="var(--line)"/>`;}).join('');
  $('timeline').innerHTML=`<svg viewBox="0 0 ${W} ${H}">${axis}${bars}</svg>
    <div class="sub" style="margin-top:6px">Max stacked = <b>${pi.openrouter_all.peak_concurrent}</b> concurrent in-flight LLM calls in one interview.</div>`;
}
drawTimeline();

// ── speech ────────────────────────────────────────────────────────────────
$('speech').innerHTML = `
  <div class="kv">
    <b>STT model</b><span>one continuous Azure stream, opened for the whole interview</span>
    <b>Streams / interview</b><span class="mono">1</span>
    <b>Stream coverage</b><span class="mono">${fmt(pi.stt_coverage_pct)}% of call duration</span>
    <b>Audio recognised</b><span class="mono">${fmt(M.stt.audio_ms/1000,1)} s</span>
    <b>TTS chars synthesised</b><span class="mono">${fmt(M.tts.chars)} in ${fmt(M.tts.segments)} chunks</span>
    <b>TTS concurrency</b><span>bursty, ≤ 1 active per interview (AI speaks one turn at a time)</span>
  </div>
  <div class="warnbox">Because STT holds one stream for the entire interview, your Azure ceiling is
    simply <b>streams-per-key × keys</b>. With the repo's assumption of 5 streams/key and 1 key that's
    <b>5 concurrent interviews</b> — verify your resource's real S0 real-time limit (it is often higher).
    TTS is bursty and short, so STT is the binding Speech constraint.</div>`;

// ── per-model table ─────────────────────────────────────────────────────────
{
  const bm = M.per_log[0].by_model;
  $('models').innerHTML = Object.entries(bm).map(([m,e])=>
    `<tr><td class="mono">${m}</td><td class="sub">${(e.agents||[]).join(', ')}</td>
     <td>${fmt(e.calls)}</td><td>${fmt(e.tin_sum)}</td><td>${fmt(e.tout_sum)}</td>
     <td>${fmt(e.rpm_avg,1)}</td><td>${fmt(e.tpm_avg)}</td><td>$${(e.cost||0).toFixed(4)}</td></tr>`
  ).join('');
}

$('foot').innerHTML = `Generated from <code>${M.generated_from.join(', ')}</code>. `+
  `Token counts and cost are the provider's own numbers from each event. `+
  `Defaults for provider limits are placeholders — set your real OpenRouter and Azure limits above.`;

recompute();
window.addEventListener('resize', ()=>{drawGrowth();drawTimeline();});
</script>
</body>
</html>
"""


def render(metrics: dict) -> str:
    return _TEMPLATE.replace("__METRICS_JSON__", json.dumps(metrics))


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("usage: python3 render_dashboard.py metrics.json > dashboard.html")
    m = json.loads(Path(sys.argv[1]).read_text())
    sys.stdout.write(render(m))
