#!/usr/bin/env python3
"""
analyze.py — turn an interview events.jsonl into concurrency-capacity numbers.

WHAT THIS ANSWERS
  "Given ONE Azure Speech key and ONE OpenRouter key, how many interviews can I
   run in parallel before I hit a rate limit or a stream cap?"

HOW
  1. Parse the log with the SAME parser the app UI uses
     (app.event_viewer.annotate + group_by_phase) so the turn/prompt view here
     matches what you see in the session-detail page.
  2. From the LLM events (llm_call_completed / verifier_classified /
     phase_override_decided) reconstruct every model request as an interval
     [start = ts - latency_ms, end = ts] with its model + token counts + cost.
  3. Roll those up into the numbers that actually bind concurrency:
       - RPM   requests / minute        (OpenRouter account request-rate limit)
       - TPM   tokens   / minute         (OpenRouter / underlying-provider token limit)
       - peak concurrent in-flight calls (provider concurrent-request limit)
     computed per-agent, per-model, and combined (one OR key sees the sum),
     as a whole-interview average AND a sliding 60s-window PEAK.
  4. Measure Azure Speech demand: STT is one continuous stream held for the whole
     interview (=> 1 stream / interview); TTS is bursty (<=1 at a time / interview).
  5. Emit metrics.json and generate a self-contained dashboard.html with an
     interactive ceiling calculator (edit your limits, see max parallel interviews).

USAGE
    python3 analyze.py events-XXXX.jsonl                 # one log
    python3 analyze.py *.jsonl                            # average across many
    python3 analyze.py events.jsonl --out-dir .           # where to write outputs

No third-party deps — standard library only. Cost comes straight from each
event's `cost_usd` (OpenRouter's authoritative number), so the pricing module
(and its `openai` import) is never needed.
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
from datetime import datetime
from pathlib import Path

# ── Reuse the codebase parser ──────────────────────────────────────────────
# annotate() is pure stdlib. group_by_phase() lazily imports the pricing module
# (which pulls `openai`) only to price STT/TTS — stub those two helpers to 0 so
# the phase/turn/prompt grouping runs anywhere. Per-call LLM cost we read from
# the event's own cost_usd field, so nothing billable is lost.
REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))
try:
    import app.event_viewer as ev
    ev._stt_usd_per_audio_ms = lambda: 0.0   # noqa: E731  (stub; cost via cost_usd)
    ev._tts_usd_per_char = lambda: 0.0       # noqa: E731
    from app.event_viewer import annotate, group_by_phase
    _HAVE_PARSER = True
except Exception as e:  # pragma: no cover - fallback if repo layout changes
    print(f"[warn] could not import app.event_viewer ({e!r}); using built-in parse", file=sys.stderr)
    _HAVE_PARSER = False

    def annotate(path: Path) -> list[dict]:
        rows = []
        for line in path.open(encoding="utf-8"):
            line = line.strip()
            if not line:
                continue
            try:
                o = json.loads(line)
            except json.JSONDecodeError:
                continue
            rows.append({"kind": o.get("kind", ""), "ts": o.get("ts", ""),
                         "payload": o.get("payload") or {}})
        return rows

    def group_by_phase(rows):  # minimal stand-in
        return []


SLOW_AGENT = "question_agent"
FAST_AGENTS = {"verifier_agent", "phase_override_agent", "filler_agent", "apology_agent"}
LLM_KINDS = ("llm_call_completed", "verifier_classified", "phase_override_decided")


def _ts(s: str) -> float:
    try:
        return datetime.fromisoformat(s).timestamp()
    except Exception:
        return 0.0


def _pct(vals, q):
    if not vals:
        return 0.0
    s = sorted(vals)
    k = max(0, min(len(s) - 1, int(round(q / 100.0 * (len(s) - 1)))))
    return float(s[k])


# ────────────────────────────────────────────────────────────────────────────
#  Per-log extraction
# ────────────────────────────────────────────────────────────────────────────
def extract(path: Path) -> dict:
    rows = annotate(path)
    if not rows:
        raise SystemExit(f"{path}: no parseable events")

    t0 = _ts(rows[0]["ts"])
    tN = _ts(rows[-1]["ts"])

    session = {"id": "", "candidate": "", "role": "", "slow_model": "", "fast_model": ""}
    # LLM calls as intervals + STT/TTS accounting.
    calls = []          # {agent, model, tin, tout, lat_ms, cost, start_s, end_s, mid_s}
    stt_first = stt_last = None
    stt_audio_ms = 0
    tts_chars = 0
    tts_segments = 0

    for r in rows:
        kind = r["kind"]
        p = r["payload"] or {}
        ts = _ts(r["ts"])
        rel = ts - t0

        if kind == "session_started":
            session.update(
                id=p.get("session_id", ""),
                candidate=p.get("candidate_name", ""),
                role=p.get("role", ""),
                slow_model=p.get("slow_model", ""),
                fast_model=p.get("fast_model", ""),
            )
            continue

        if kind in LLM_KINDS:
            agent = p.get("agent") or "?"
            lat = float(p.get("latency_ms") or 0.0)
            calls.append({
                "agent": agent,
                "model": p.get("model") or "",
                "tin": int(p.get("tokens_in") or 0),
                "tout": int(p.get("tokens_out") or 0),
                "lat_ms": lat,
                "cost": float(p.get("cost_usd") or 0.0),
                "start_s": rel - lat / 1000.0,   # reconstructed request start
                "end_s": rel,                    # completion timestamp
                "mid_s": rel - lat / 2000.0,
            })
            continue

        if kind in ("stt_final", "stt_segment", "stt_partial"):
            stt_first = rel if stt_first is None else min(stt_first, rel)
            stt_last = rel if stt_last is None else max(stt_last, rel)
            if kind == "stt_final":
                stt_audio_ms += int(p.get("audio_ms") or p.get("end_ms") or 0)
            continue

        if kind == "tts_speak_chunk_sent":
            tts_chars += len(p.get("text") or "")
            tts_segments += 1
            continue

    dur_s = max(1.0, tN - t0)
    dur_min = dur_s / 60.0

    # ── phase/turn structure (reused parser) for the turn view + phase list ──
    phases = []
    try:
        for ph in group_by_phase(rows):
            phases.append({
                "id": ph["id"],
                "duration_ms": ph["duration_ms"],
                "turns": ph["turn_count"],
                "ai_turns": ph["ai_turn_count"],
                "llm_calls": ph["llm_calls"],
                "tokens_in": ph["llm_tokens_in"],
                "tokens_out": ph["llm_tokens_out"],
            })
    except Exception as e:  # pragma: no cover
        print(f"[warn] group_by_phase failed ({e!r}); phase list omitted", file=sys.stderr)

    return {
        "file": path.name,
        "session": session,
        "duration_s": dur_s,
        "duration_min": dur_min,
        "calls": calls,
        "phases": phases,
        "stt": {
            "span_s": (stt_last - stt_first) if (stt_first is not None and stt_last is not None) else 0.0,
            "first_s": stt_first or 0.0,
            "last_s": stt_last or 0.0,
            "audio_ms": stt_audio_ms,
        },
        "tts": {"chars": tts_chars, "segments": tts_segments},
    }


# ────────────────────────────────────────────────────────────────────────────
#  Concurrency / rate math
# ────────────────────────────────────────────────────────────────────────────
def peak_concurrency(intervals: list[tuple[float, float]]) -> int:
    """Max number of overlapping [start, end] intervals (sweep line)."""
    ev_pts = []
    for a, b in intervals:
        if b < a:
            a, b = b, a
        ev_pts.append((a, 1))
        ev_pts.append((b, -1))
    ev_pts.sort(key=lambda x: (x[0], -x[1]))  # opens before closes at a tie
    cur = peak = 0
    for _, d in ev_pts:
        cur += d
        peak = max(peak, cur)
    return peak


def sliding_peak(starts_with_weight: list[tuple[float, float]], dur_s: float,
                 window_s: float = 60.0, step_s: float = 1.0) -> float:
    """Max sum-of-weights whose start falls in any window of length window_s.
    Weight=1 -> peak requests/window (RPM if window=60). Weight=tokens -> peak TPM."""
    if not starts_with_weight:
        return 0.0
    pts = sorted(starts_with_weight)
    best = 0.0
    w = 0.0
    end = max(dur_s, window_s)
    while w <= end - window_s + step_s:
        lo, hi = w, w + window_s
        s = sum(wt for (t, wt) in pts if lo <= t < hi)
        best = max(best, s)
        w += step_s
    return best


def rollup(rec: dict) -> dict:
    """Compute per-agent / per-model / combined RPM, TPM, peak-concurrent for one log."""
    calls = rec["calls"]
    dur_min = rec["duration_min"]
    dur_s = rec["duration_s"]

    def bucket(cs: list[dict]) -> dict:
        if not cs:
            return {"calls": 0, "tin_sum": 0, "tout_sum": 0, "tok_sum": 0,
                    "cost": 0.0, "rpm_avg": 0.0, "tpm_avg": 0.0,
                    "peak_rpm_60s": 0.0, "peak_tpm_60s": 0.0, "peak_concurrent": 0,
                    "lat_p50": 0.0, "lat_p95": 0.0, "lat_max": 0.0,
                    "tin_mean": 0, "tin_max": 0}
        tin = [c["tin"] for c in cs]
        tout = [c["tout"] for c in cs]
        tok = [c["tin"] + c["tout"] for c in cs]
        lat = [c["lat_ms"] for c in cs if c["lat_ms"] > 0]
        return {
            "calls": len(cs),
            "tin_sum": sum(tin), "tout_sum": sum(tout), "tok_sum": sum(tok),
            "cost": sum(c["cost"] for c in cs),
            "rpm_avg": len(cs) / dur_min,
            "tpm_avg": sum(tok) / dur_min,
            "peak_rpm_60s": sliding_peak([(c["start_s"], 1.0) for c in cs], dur_s),
            "peak_tpm_60s": sliding_peak([(c["start_s"], c["tin"] + c["tout"]) for c in cs], dur_s),
            "peak_concurrent": peak_concurrency([(c["start_s"], c["end_s"]) for c in cs]),
            "lat_p50": _pct(lat, 50), "lat_p95": _pct(lat, 95), "lat_max": max(lat) if lat else 0.0,
            "tin_mean": int(statistics.mean(tin)), "tin_max": max(tin),
        }

    by_agent = {}
    for a in sorted({c["agent"] for c in calls}):
        by_agent[a] = bucket([c for c in calls if c["agent"] == a])

    by_model = {}
    for m in sorted({c["model"] for c in calls}):
        b = bucket([c for c in calls if c["model"] == m])
        b["agents"] = sorted({c["agent"] for c in calls if c["model"] == m})
        by_model[m] = b

    slow = bucket([c for c in calls if c["agent"] == SLOW_AGENT])
    fast = bucket([c for c in calls if c["agent"] in FAST_AGENTS])
    allc = bucket(calls)

    # ── slow-LLM context growth (the "prompts get big" worry) ───────────────
    slow_calls = sorted([c for c in calls if c["agent"] == SLOW_AGENT], key=lambda c: c["mid_s"])
    growth = {"base_tin": 0, "max_tin": 0, "slope_tok_per_min": 0.0, "resets": 0}
    if slow_calls:
        tins = [c["tin"] for c in slow_calls]
        growth["base_tin"] = min(tins)
        growth["max_tin"] = max(tins)
        # Largest monotonically-increasing run -> within-phase growth slope.
        best_run = cur = [slow_calls[0]]
        for c in slow_calls[1:]:
            if c["tin"] >= cur[-1]["tin"]:
                cur.append(c)
            else:
                growth["resets"] += 1
                if len(cur) > len(best_run):
                    best_run = cur
                cur = [c]
        if len(cur) > len(best_run):
            best_run = cur
        if len(best_run) >= 2:
            dt_min = (best_run[-1]["mid_s"] - best_run[0]["mid_s"]) / 60.0
            dtok = best_run[-1]["tin"] - best_run[0]["tin"]
            growth["slope_tok_per_min"] = (dtok / dt_min) if dt_min > 0 else 0.0

    return {
        "by_agent": by_agent, "by_model": by_model,
        "slow": slow, "fast": fast, "all_llm": allc,
        "slow_growth": growth,
    }


def build_metrics(recs: list[dict]) -> dict:
    """Combine one or more logs. Multi-log => per-interview values are averaged."""
    rolls = [rollup(r) for r in recs]
    n = len(recs)

    def avg(fn):
        return sum(fn(r) for r in rolls) / n

    def avg_rec(fn):
        return sum(fn(r) for r in recs) / n

    # STT/TTS per-interview demand.
    stt_coverage = avg_rec(lambda r: (r["stt"]["span_s"] / r["duration_s"]) if r["duration_s"] else 0.0)

    per_interview = {
        "duration_s_mean": avg_rec(lambda r: r["duration_s"]),
        "slow": {
            "rpm": avg(lambda r: r["slow"]["rpm_avg"]),
            "tpm_avg": avg(lambda r: r["slow"]["tpm_avg"]),
            "tpm_peak60": avg(lambda r: r["slow"]["peak_tpm_60s"]),
            "peak_concurrent": max(r["slow"]["peak_concurrent"] for r in rolls),
            "tin_mean": avg(lambda r: r["slow"]["tin_mean"]),
            "tin_max": max(r["slow"]["tin_max"] for r in rolls),
        },
        "fast": {
            "rpm": avg(lambda r: r["fast"]["rpm_avg"]),
            "tpm_avg": avg(lambda r: r["fast"]["tpm_avg"]),
            "tpm_peak60": avg(lambda r: r["fast"]["peak_tpm_60s"]),
            "peak_concurrent": max(r["fast"]["peak_concurrent"] for r in rolls),
        },
        # One OpenRouter key sees the SUM of slow + fast.
        "openrouter_all": {
            "rpm_avg": avg(lambda r: r["all_llm"]["rpm_avg"]),
            "rpm_peak60": avg(lambda r: r["all_llm"]["peak_rpm_60s"]),
            "tpm_avg": avg(lambda r: r["all_llm"]["tpm_avg"]),
            "tpm_peak60": avg(lambda r: r["all_llm"]["peak_tpm_60s"]),
            "peak_concurrent": max(r["all_llm"]["peak_concurrent"] for r in rolls),
        },
        "stt_streams": 1,                       # continuous, one per interview
        "stt_coverage_pct": 100.0 * stt_coverage,
        "cost_usd": avg(lambda r: r["all_llm"]["cost"]),
    }

    # Growth (worst across logs).
    gr = max(rolls, key=lambda r: r["slow_growth"]["max_tin"])["slow_growth"]

    # Timeline of the FIRST log (for charts).
    r0 = recs[0]
    timeline = [{
        "t": round(c["mid_s"], 1), "agent": c["agent"],
        "model": c["model"].split("/")[-1],
        "tin": c["tin"], "tout": c["tout"], "lat_ms": round(c["lat_ms"]),
    } for c in sorted(r0["calls"], key=lambda c: c["mid_s"])]

    # Default provider ceilings — EDIT THESE to your account's real limits.
    # OpenRouter's per-account limits vary with credit balance and the
    # underlying provider (Groq/Baseten/etc.) forwards its own TPM/RPM. These
    # are placeholders sized to a modest paid tier; the dashboard lets you change
    # them live. Azure Speech: the repo assumes 5 concurrent streams/key
    # (SPEECH_STREAMS_PER_KEY); Azure's real S0 real-time STT limit is higher —
    # confirm for your resource.
    defaults = {
        # From this account's GET /api/v1/key (paid tier): rate_limit.requests = -1
        # and flagged deprecated → OpenRouter enforces NO fixed RPM. The only
        # OpenRouter ceiling is credit BALANCE (a spend cap, not a concurrency cap).
        "or_unlimited": True,           # no enforced OpenRouter rate limit
        "or_rpm_limit": 200,            # only used if you UNCHECK "no rate limit"
        "or_tpm_limit": 300000,
        "or_concurrent_limit": 50,
        "or_credits_remaining": 37.5,   # $ left on the key (usage-gated, not rate-gated)
        "is_free_tier": False,
        "speech_streams_per_key": 5,    # Azure STT concurrent streams per key
        "speech_keys": 1,
        "target_interview_min": 60,
        "target_concurrent": 10,        # capacity planner: keys needed for this many parallel
        "safety_margin_pct": 20,        # leave headroom below the hard limit
    }

    return {
        "generated_from": [r["file"] for r in recs],
        "log_count": n,
        "session": recs[0]["session"],
        "phases": recs[0]["phases"],
        "per_log": [{
            "file": r["file"],
            "duration_s": round(r["duration_s"], 1),
            "by_agent": rl["by_agent"],
            "by_model": rl["by_model"],
        } for r, rl in zip(recs, rolls)],
        "per_interview": per_interview,
        "slow_growth": gr,
        "timeline": timeline,
        "stt": recs[0]["stt"],
        "tts": recs[0]["tts"],
        "defaults": defaults,
    }


# ────────────────────────────────────────────────────────────────────────────
#  Console summary
# ────────────────────────────────────────────────────────────────────────────
def print_summary(m: dict) -> None:
    pi = m["per_interview"]
    s = m["session"]
    print("=" * 74)
    print(f"  {s.get('candidate','?')} — {s.get('role','?')}   "
          f"({m['log_count']} log(s), mean {pi['duration_s_mean']/60:.1f} min)")
    print(f"  slow={s.get('slow_model','?')}   fast={s.get('fast_model','?')}")
    print("=" * 74)
    print("\nPER-INTERVIEW LLM DEMAND (what one live interview draws):")
    print(f"  {'':22s} {'RPM':>7} {'TPM avg':>9} {'TPM peak/60s':>13} {'peak concurrent':>16}")
    print(f"  {'slow (question)':22s} {pi['slow']['rpm']:>7.1f} {pi['slow']['tpm_avg']:>9.0f} "
          f"{pi['slow']['tpm_peak60']:>13.0f} {pi['slow']['peak_concurrent']:>16d}")
    print(f"  {'fast (verif+override)':22s} {pi['fast']['rpm']:>7.1f} {pi['fast']['tpm_avg']:>9.0f} "
          f"{pi['fast']['tpm_peak60']:>13.0f} {pi['fast']['peak_concurrent']:>16d}")
    o = pi["openrouter_all"]
    print(f"  {'ALL (one OR key)':22s} {o['rpm_avg']:>7.1f} {o['tpm_avg']:>9.0f} "
          f"{o['tpm_peak60']:>13.0f} {o['peak_concurrent']:>16d}")
    print(f"    peak RPM/60s (all) = {o['rpm_peak60']:.0f}")
    g = m["slow_growth"]
    print(f"\nSLOW-LLM CONTEXT GROWTH:  base={g['base_tin']} max={g['max_tin']} tok_in, "
          f"~{g['slope_tok_per_min']:.0f} tok/min within a phase, {g['resets']} reset(s)")
    print(f"AZURE SPEECH:  1 continuous STT stream / interview "
          f"(covers {pi['stt_coverage_pct']:.0f}% of the call); TTS bursty (<=1/interview)")
    print(f"COST:  ~${pi['cost_usd']:.4f} LLM / interview (this length)\n")

    # Quick ceiling with defaults.
    d = m["defaults"]
    margin = 1.0 - d["safety_margin_pct"] / 100.0
    ceils = {"Azure Speech": d["speech_streams_per_key"] * d["speech_keys"]}
    if d.get("or_unlimited"):
        print("OPENROUTER: paid key, rate_limit.requests = -1 → NO enforced RPM/TPM/concurrent limit.")
        runway = d["or_credits_remaining"] / max(pi["cost_usd"] * (d["target_interview_min"] /
                                                 (pi["duration_s_mean"] / 60.0)), 1e-9)
        print(f"            Only ceiling is credits: ${d['or_credits_remaining']:.2f} left "
              f"≈ {runway:.0f} interviews of {d['target_interview_min']} min before top-up.\n")
    else:
        ceils.update({
            "OpenRouter RPM": int(d["or_rpm_limit"] * margin / max(o["rpm_peak60"], 1e-9)),
            "OpenRouter TPM": int(d["or_tpm_limit"] * margin / max(o["tpm_peak60"], 1e-9)),
            "OR concurrent":  int(d["or_concurrent_limit"] * margin / max(o["peak_concurrent"], 1)),
        })
    binder = min(ceils, key=ceils.get)
    print("MAX CONCURRENT INTERVIEWS:")
    for k, v in sorted(ceils.items(), key=lambda kv: kv[1]):
        mark = "  <-- BOTTLENECK" if k == binder else ""
        print(f"  {k:18s} {v:>5d}{mark}")
    print(f"\n  => {ceils[binder]} concurrent interviews, limited by {binder}."
          " Add Azure Speech keys to scale.\n")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("logs", nargs="+", help="one or more events*.jsonl files")
    ap.add_argument("--out-dir", default=None, help="where to write metrics.json + dashboard.html "
                    "(default: alongside this script)")
    a = ap.parse_args()

    paths = [Path(p) for p in a.logs]
    for p in paths:
        if not p.exists():
            raise SystemExit(f"not found: {p}")
    recs = [extract(p) for p in paths]
    metrics = build_metrics(recs)

    out_dir = Path(a.out_dir) if a.out_dir else Path(__file__).resolve().parent
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "metrics.json").write_text(json.dumps(metrics, indent=2))

    # Generate the dashboard (imports lazily so analyze can run without it).
    try:
        from render_dashboard import render
    except Exception:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        from render_dashboard import render
    html = render(metrics)
    (out_dir / "dashboard.html").write_text(html)

    print_summary(metrics)
    print(f"wrote {out_dir/'metrics.json'}")
    print(f"wrote {out_dir/'dashboard.html'}  <- open this in a browser")


if __name__ == "__main__":
    main()
