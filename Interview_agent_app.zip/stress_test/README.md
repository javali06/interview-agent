# stress_test — interview concurrency capacity

Answer to: **"With one Azure Speech key and one OpenRouter key, how many interviews
can I run in parallel?"** — computed from a real interview's `events.jsonl`, no
live load test required.

## Run

```bash
cd stress_test
python3 analyze.py events-a756167e.jsonl        # one log
python3 analyze.py *.jsonl                       # average across several logs
```

Outputs (written next to the script):
- **`dashboard.html`** — open in a browser. Interactive: type in your real
  OpenRouter / Azure limits and it shows max parallel interviews + the bottleneck.
- **`metrics.json`** — all raw numbers (feed to anything else).

Stdlib only. To re-render the dashboard from an existing metrics file:
`python3 render_dashboard.py metrics.json > dashboard.html`.

## What it measures (per interview)

The parser reuses the app's own `app/event_viewer.py` (`annotate` +
`group_by_phase`) so the turn/prompt view matches the session-detail page. On top
of it we compute the things that actually bind concurrency:

| Metric | Why it binds |
|---|---|
| **RPM** requests/min (slow, fast, and combined — one OR key serves both) | OpenRouter account request-rate limit |
| **TPM** tokens/min (avg **and** peak 60-second window) | OpenRouter / underlying-provider token limit |
| **Peak concurrent** in-flight LLM calls | provider max-concurrent-requests limit |
| **STT streams** = 1 continuous stream held the whole interview | Azure Speech `streams_per_key × keys` |

The **peak/60s** numbers are what a rate limiter actually enforces; the ceiling
math uses them (conservative — assumes worst-case alignment). The average columns
are shown too if you want the optimistic view.

## Key facts the data shows

- **Rate limits are ~duration-independent.** A 60-min interview draws about the
  same RPM/TPM *per minute* as a 6-min one — more turns, same rate. Interview
  length scales **cost** and the worst-case slow-LLM context, not the rate ceiling.
- **Slow-LLM context is bounded, not unbounded.** `question_agent` `tokens_in`
  grows within a phase (~640 tok/min in the sample) then **resets at phase
  boundaries**. The dashboard shows the worst case if one phase ran the whole
  interview — keep phases time-boxed to cap it.
- **STT is the Azure ceiling.** One continuous stream per interview ⇒
  `streams_per_key × keys`. The repo assumes 5 streams/key; confirm your S0
  resource's real real-time limit (often higher). TTS is bursty/short — not binding.

## The LLM side is not the bottleneck — Azure Speech is

**Confirmed from `GET /api/v1/key` (Jul 2026):** the account is **paid**
(`is_free_tier:false`) and returns `rate_limit.requests = -1` flagged *deprecated*
— i.e. OpenRouter enforces **no RPM/TPM/concurrency** limit. The only OpenRouter
ceiling is **credit balance** (a spend budget, not a rate). So:

- **OpenRouter account limit: none.** No RPM/TPM cap at the account level.
- **Upstream provider 429s: real, but a *soft* risk — not a fixed ceiling.** OpenRouter
  defers each call to a provider; a provider 429 returns as *"provider returned error."*
  Since this key is **not BYOK** (`byok_usage:0`), you share OpenRouter's **pooled**
  capacity with each provider, so a 429 fires on OpenRouter's *aggregate* traffic to that
  provider — **not** your personal "Groq 30 RPM / 8k TPM" free-tier numbers. It's a
  shared-pool reliability risk under load, masked by failover:
  `allow_fallbacks:false` + your order list walks **Groq→Baseten→Cerebras** (slow) /
  **Groq→DeepInfra** (fast); if all error, the turn degrades to a canned filler.
  Mitigate with client retry/backoff + `MAX_LLM_INFLIGHT`. **For predictable, controllable
  provider limits, use BYOK** — then your own provider tier applies (known TPM/RPM, usually
  roomier) and you size it against the per-interview demand table.
- **Binding constraint: Azure Speech = `streams_per_key × keys`** (STT holds one
  stream per interview). With 1 key ≈ **5 concurrent interviews**. Add Speech keys
  to scale.
- **OpenRouter's real limit is a budget:** at ~$0.03 LLM / 6.5-min interview,
  $37.50 of credits ≈ 135 hour-long interviews before top-up (independent of how
  many run in parallel).

The dashboard's "OpenRouter: no enforced rate limit" box is checked by default to
reflect this; untick it only if you move to a rate-capped key. See its "Provider
routing & limits" panel for the per-provider reference and the `SLOW_LLM_MAX_TOKENS`
guardrail (smallest slow cap = Cerebras 40,960).

## Confirm your real Azure STT stream limit

The `5 streams/key` figure is the repo's *assumption* (`SPEECH_STREAMS_PER_KEY`), not
Azure's actual cap for your resource — which varies by region/tier and can be raised.
Measure it directly:

```bash
.venv/bin/pip install azure-cognitiveservices-speech      # once
.venv/bin/python stress_test/azure_stt_probe.py           # reads key/region from ../.env
# or: python3 azure_stt_probe.py --ramp 1,5,10,20,30,50 --hold 15
```

It ramps N concurrent continuous-recognition streams (same 16 kHz push-stream setup as
`azure_stt_client.py`) and reports the largest N that connects with no throttling — that
number goes straight into the dashboard's "Azure STT streams / key" input. It opens real
(cheaply billed) connections and changes nothing on your resource.

The dashboard's **capacity planner** then inverts it: enter a target concurrency and it
tells you how many Speech keys to provision (`AZURE_SPEECH_KEYS`).

## The CPU / memory dimension (separate from this)

This tool covers **Speech + LLM** ceilings, which are pure arithmetic. **CPU/RAM
per session shard** can't be derived from a log — you need load on a running
shard. That harness already exists: [`scripts/loadtest_interviews.py`](../scripts/loadtest_interviews.py)
opens N synthetic candidate WebSockets streaming a real-time WAV and prints the
per-turn latency knee. Run it against one shard pinned to the prod vCPU
(`docker run --cpus=1`), with Speech taken out of the way, to find the CPU-bound
interviews-per-shard. Your real ceiling is
`min(CPU-per-shard × shards, Speech ceiling, LLM ceiling)`.
