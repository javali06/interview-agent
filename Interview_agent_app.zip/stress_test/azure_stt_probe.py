#!/usr/bin/env python3
"""
azure_stt_probe.py — find the REAL concurrent STT-stream limit of one Azure Speech key.

WHY EMPIRICAL
  Azure's documented real-time STT concurrency varies by region, tier, and model,
  and can be custom-raised per resource — so the only trustworthy number for YOUR
  key is measured. This ramps N concurrent continuous-recognition streams (exactly
  how deploy/.../azure_stt_client.py opens them: 16 kHz mono PushAudioInputStream +
  start_continuous_recognition) and reports the largest N where every stream
  connects with no throttling. That number is your Azure ceiling per key
  (max concurrent interviews = limit × keys).

USAGE
  # key/region read from ../.env (AZURE_SPEECH_KEY / AZURE_SPEECH_REGION) by default
  python3 azure_stt_probe.py
  python3 azure_stt_probe.py --ramp 1,5,10,20,30,50 --hold 15
  python3 azure_stt_probe.py --key <KEY> --region eastus

REQUIRES the Azure Speech SDK in the venv you run this with:
  pip install azure-cognitiveservices-speech        # (into .venv)

This OPENS real billed connections to Azure (STT is billed by audio-time; each
stream here pushes ~hold seconds of silence, so cost is a few cents at most). It
makes no changes to your resource.
"""
from __future__ import annotations

import argparse
import sys
import threading
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent

try:
    import azure.cognitiveservices.speech as speechsdk
except Exception:
    sys.exit(
        "Azure Speech SDK not installed in this interpreter.\n"
        "  Install it into your venv, e.g.:\n"
        "    .venv/bin/pip install azure-cognitiveservices-speech\n"
        "  then run:  .venv/bin/python stress_test/azure_stt_probe.py"
    )

SR = 16_000
FRAME_MS = 20
FRAME_BYTES = SR * 2 * FRAME_MS // 1000       # 640 bytes = 20 ms 16-bit mono
SILENCE = b"\x00" * FRAME_BYTES

# Cancellation error codes that mean "you hit a capacity/quota wall" (as opposed
# to a bad key or a network blip). Names differ slightly across SDK versions, so
# we match by attribute name AND scan the human error string.
_THROTTLE_CODES = {"TooManyRequests", "Forbidden", "ServiceUnavailable", "ServiceTimeout"}
_THROTTLE_WORDS = ("429", "quota", "throttl", "exceeded", "too many", "concurrent",
                   "rate limit", "capacity")


def _read_env(name: str) -> str | None:
    env_path = REPO_ROOT / ".env"
    if not env_path.exists():
        return None
    for line in env_path.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if line.startswith(name + "="):
            return line[len(name) + 1:].strip().strip('"').strip("'")
    return None


class ProbeStream:
    """One continuous-recognition stream. Reports connected / throttled / errored."""

    def __init__(self, key: str, region: str) -> None:
        self._key, self._region = key, region
        self.started = threading.Event()
        self.canceled = threading.Event()
        self.throttled = False
        self.err = ""
        self._stop = threading.Event()
        self._rec = None
        self._push = None
        self._pump: threading.Thread | None = None

    def start(self) -> None:
        cfg = speechsdk.SpeechConfig(subscription=self._key, region=self._region)
        cfg.speech_recognition_language = "en-US"
        fmt = speechsdk.audio.AudioStreamFormat(
            samples_per_second=SR, bits_per_sample=16, channels=1)
        self._push = speechsdk.audio.PushAudioInputStream(stream_format=fmt)
        self._rec = speechsdk.SpeechRecognizer(
            speech_config=cfg,
            audio_config=speechsdk.audio.AudioConfig(stream=self._push))
        self._rec.session_started.connect(lambda evt: self.started.set())
        self._rec.canceled.connect(self._on_canceled)
        self._rec.start_continuous_recognition_async()
        self._pump = threading.Thread(target=self._feed, daemon=True)
        self._pump.start()

    def _on_canceled(self, evt) -> None:
        try:
            det = evt.cancellation_details
            code = getattr(getattr(det, "error_code", None), "name", "") or str(getattr(det, "error_code", ""))
            msg = (getattr(det, "error_details", "") or "").lower()
            reason = getattr(det, "reason", None)
            is_err = reason == speechsdk.CancellationReason.Error
            if is_err and (code in _THROTTLE_CODES or any(w in msg for w in _THROTTLE_WORDS)):
                self.throttled = True
            if is_err:
                self.err = f"{code}: {(getattr(det, 'error_details', '') or '')[:120]}"
        except Exception as e:  # never let a callback crash the run
            self.err = f"canceled-parse-error: {e!r}"
        self.canceled.set()

    def _feed(self) -> None:
        # Push real-time silence so the session stays active during the hold.
        while not self._stop.is_set():
            try:
                self._push.write(SILENCE)
            except Exception:
                return
            time.sleep(FRAME_MS / 1000)

    def stop(self) -> None:
        self._stop.set()
        try:
            if self._push:
                self._push.close()
            if self._rec:
                self._rec.stop_continuous_recognition_async()
        except Exception:
            pass


def run_level(key: str, region: str, n: int, connect_timeout: float, hold: float) -> dict:
    streams = [ProbeStream(key, region) for _ in range(n)]
    for s in streams:
        s.start()
        time.sleep(0.03)  # slight stagger so we don't thundering-herd the SDK init

    # Wait until each stream has either connected or been canceled.
    deadline = time.perf_counter() + connect_timeout
    while time.perf_counter() < deadline:
        if all(s.started.is_set() or s.canceled.is_set() for s in streams):
            break
        time.sleep(0.1)

    time.sleep(hold)  # hold the concurrent connections open

    connected = sum(1 for s in streams if s.started.is_set() and not s.throttled)
    throttled = sum(1 for s in streams if s.throttled)
    errored = [s.err for s in streams if s.err and not s.throttled]
    for s in streams:
        s.stop()
    time.sleep(0.5)
    return {"n": n, "connected": connected, "throttled": throttled,
            "errors": errored}


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--key", default=None, help="Azure Speech key (default: AZURE_SPEECH_KEY from ../.env)")
    ap.add_argument("--region", default=None, help="Azure region (default: AZURE_SPEECH_REGION from ../.env)")
    ap.add_argument("--ramp", default="1,5,10,15,20,25,30,40,50",
                    help="comma list of concurrency levels to try")
    ap.add_argument("--hold", type=float, default=15.0, help="seconds to hold each level open")
    ap.add_argument("--connect-timeout", type=float, default=20.0,
                    help="seconds to wait for streams to connect at each level")
    a = ap.parse_args()

    key = a.key or _read_env("AZURE_SPEECH_KEY")
    region = a.region or _read_env("AZURE_SPEECH_REGION")
    if not key or not region:
        sys.exit("Missing key/region. Set AZURE_SPEECH_KEY + AZURE_SPEECH_REGION in ../.env "
                 "or pass --key/--region.")

    levels = [int(x) for x in a.ramp.split(",")]
    print(f"Probing Azure STT concurrency  region={region}  ramp={levels}  hold={a.hold}s")
    print(f"(each stream = one 16 kHz continuous recognizer pushing silence)\n")
    print(f"{'N':>4} {'connected':>10} {'throttled':>10} {'other-err':>10}  verdict")

    limit = 0
    for n in levels:
        r = run_level(key, region, n, a.connect_timeout, a.hold)
        verdict = ""
        if r["throttled"] > 0:
            verdict = "<-- THROTTLED (limit reached)"
        elif r["connected"] < n:
            verdict = "<-- some failed (see errors)"
        else:
            limit = n
        print(f"{n:>4} {r['connected']:>10} {r['throttled']:>10} {len(r['errors']):>10}  {verdict}")
        if r["errors"]:
            print(f"       e.g. {r['errors'][0]}")
        if r["throttled"] > 0:
            break  # found the wall; no point pushing higher

    print()
    if limit and (levels.index(limit) == len(levels) - 1):
        print(f"All {limit} concurrent streams connected with NO throttling — your real "
              f"per-key limit is AT LEAST {limit}. Re-run with a higher --ramp to find the ceiling.")
    elif limit:
        print(f"CONFIRMED: ~{limit} concurrent STT streams per key before Azure throttles.")
        print(f"  => max concurrent interviews = {limit} × (number of Speech keys).")
        print(f"  Put {limit} in the dashboard's 'Azure STT streams / key' input.")
    else:
        print("Even the smallest level didn't cleanly connect — check the key/region and errors above.")


if __name__ == "__main__":
    main()
