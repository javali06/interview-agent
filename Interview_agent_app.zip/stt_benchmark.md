# STT Benchmark — Model Selection, Methodology, and Metrics

A comprehensive write-up of the speech-to-text benchmark conducted on 2026-05-08 to evaluate candidate STT models for the interview agent. Covers the model-selection process, the metrics we measure (and why), how each metric is computed, and how to interpret the numbers in [bench_results/stt_FINAL_consolidated/report.md](bench_results/stt_FINAL_consolidated/report.md).

---

## 1. Goal

The interview agent currently uses a local `faster-whisper` model (`Systran/faster-distil-whisper-large-v3`) for STT. Two questions drove this benchmark:

1. **Is the current local model good enough on accuracy and latency** for live, turn-taking conversation?
2. **Which hosted alternatives** offer better trade-offs across accuracy, latency, reliability, and cost?

Six models were evaluated against the same 20-utterance audio set with identical preprocessing, identical ground truth, and a unified scoring pipeline.

---

## 2. Model selection — the journey

The user provided an initial list of six models. Below is the story of what we tried, what failed, and how the final lineup landed.

### 2.1 Initial request

| # | Model | Intended provider |
|---|---|---|
| 1 | `Systran/faster-distil-whisper-large-v3` | local (current STT in production config) |
| 2 | `google/chirp-3` | "Google" — assumed OpenRouter |
| 3 | `openai/whisper-large-v3-turbo` | OpenRouter |
| 4 | `openai/whisper-large-v3` | OpenRouter |
| 5 | `nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free` | OpenRouter |
| 6 | `google/gemini-2.5-flash-lite` | OpenRouter |

### 2.2 First discovery: 3 models returned 500 errors

When all hosted models were initially routed through OpenRouter's `chat/completions` endpoint with audio input, three returned HTTP 500 on every single call:

- `google/chirp-3`
- `openai/whisper-large-v3-turbo`
- `openai/whisper-large-v3`

A 500 (rather than 404) suggested the request shape reached an upstream provider that rejected it — not a missing slug.

### 2.3 Catalog audit — verifying what's actually on OpenRouter

To rule out typos and confirm availability, we queried OpenRouter's models API directly:

```
GET https://openrouter.ai/api/v1/models
```

Out of **367 total models** in the catalog:

- **Searching for `whisper` in any model id or display name → 0 matches.**
- **Searching for `chirp` in any model id or display name → 0 matches.**
- Filtering to `input_modalities=audio` → 23 models, all of them multimodal **chat LLMs** (Gemini variants, GPT-4o-audio, GPT-audio, Voxtral, Nemotron Omni, MiMo, Gemini 3.x previews).

**Conclusion:** OpenRouter does not host Whisper or Chirp 3. The reason is structural: OpenRouter routes `chat/completions` requests, while Whisper and Chirp are dedicated **STT-only** endpoints (`/v1/audio/transcriptions`-style APIs). They aren't chat models, so they don't fit OpenRouter's routing model.

### 2.4 First substitution — pick available models in the same capability tier

| Original | Substituted with | Reason |
|---|---|---|
| `google/chirp-3` | `google/gemini-2.5-flash` | Google's flagship audio-capable chat model on OpenRouter — closest available "Google STT" proxy |
| `openai/whisper-large-v3-turbo` | `openai/gpt-audio-mini` | OpenAI's smaller audio-capable chat model |
| `openai/whisper-large-v3` | `openai/gpt-audio` | OpenAI's flagship audio-capable chat model |

### 2.5 Second issue — OpenAI audio chat models reject the standard payload

After the substitution, `openai/gpt-audio` and `openai/gpt-audio-mini` returned HTTP 400 with the message:

```
"Invalid parameter: 'response_format' of type 'json_object' is not supported with this model."
```

OpenAI's audio chat API requires:
- **Drop `response_format: {"type": "json_object"}`** (Gemini accepts it; OpenAI doesn't)
- **Add `modalities: ["text"]`** to indicate the model should output text (not synthesized audio)

The `OpenRouterAudioRunner` was updated to detect OpenAI audio slugs and adjust the payload accordingly.

### 2.6 Third issue — `gpt-audio` *refuses* to recognize audio

After the payload fix, `gpt-audio` returned HTTP 200 successfully — but the model ignored the audio and replied with prose:

> *"Understood. Please provide the audio file, and I will transcribe it according to the specified format."*

This drove WER to **75.22%**. Inspecting per-utterance results showed this happened on ~16 of 20 calls. `gpt-audio-mini` did not exhibit this issue (12.28% WER, 1 outlier hallucination on 1 of 20).

This is a meaningful finding: **OpenRouter's relay of OpenAI's `gpt-audio` does not reliably deliver audio to the model**. It's a known quirk of the relay path.

### 2.7 Pivot — host Whisper on Groq instead

Since the user already had a `GROQ_API_KEY` in `.env` and Groq hosts Whisper-large-v3 and -turbo as proper STT endpoints, we pivoted Models 3 & 4 to Groq:

```
POST https://api.groq.com/openai/v1/audio/transcriptions
Content-Type: multipart/form-data
```

Groq's API is OpenAI-compatible — same multipart-form audio upload shape OpenAI uses for its native Whisper API. A new `GroqWhisperRunner` was added to handle this code path.

### 2.8 Final lineup

| # | Model | Backend | Routing |
|---|---|---|---|
| 1 | `Systran/faster-distil-whisper-large-v3` | local `faster-whisper` (CTranslate2), CPU/int8 | The current production STT — matches `WHISPER_MODEL_PATH` default in `scripts/run_live.sh` |
| 2 | `google/gemini-2.5-flash` | OpenRouter `/chat/completions` with audio input | Substitute for `google/chirp-3` (Chirp 3 is GCP-only, not on OpenRouter) |
| 3 | `whisper-large-v3-turbo` | **Groq** `/audio/transcriptions` (multipart) | The originally-requested model, hosted natively on Groq |
| 4 | `whisper-large-v3` | **Groq** `/audio/transcriptions` (multipart) | Same — full-size Whisper Large v3 |
| 5 | `nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free` | OpenRouter `/chat/completions` with audio input | Free tier |
| 6 | `google/gemini-2.5-flash-lite` | OpenRouter `/chat/completions` with audio input | |

### 2.9 Why these 6 and not others

- **Model 1** is non-negotiable — it's the production baseline.
- **Models 3 & 4 (Whisper)** are the industry-standard accuracy reference for English STT. Including them is essential.
- **Model 2 (Gemini Flash)** represents Google's current-gen audio-capable LLM tier — what Chirp 3 would compete with from a buyer's perspective.
- **Model 6 (Gemini Flash Lite)** represents Google's cheapest hosted audio tier — a price/perf comparison point.
- **Model 5 (Nemotron Omni)** is a free, multimodal audio LLM — included as a "what does free quality look like?" datapoint.

---

## 3. Metrics — what we measure and why

Each per-utterance result records 13 numbers across four families: **accuracy**, **latency**, **throughput**, and **output sanity**. Each metric below has: what it measures, how it's computed, what "good" looks like, and when it matters.

### 3.1 Accuracy metrics

All accuracy metrics compare a **predicted transcript (hypothesis)** against the **ground-truth reference**. Both are normalized first — see §3.5.

#### 3.1.1 Word Error Rate (WER)

**Definition:** The fraction of reference words that the model got wrong, where "wrong" includes substitutions, deletions, and insertions.

**Formula:**
```
WER = (S + D + I) / N
```
Where:
- `S` = substitutions (e.g. "their" predicted as "there")
- `D` = deletions (a reference word missing from the hypothesis)
- `I` = insertions (a hypothesis word not in the reference)
- `N` = total reference words

WER is computed via a minimum-edit-distance alignment between the two word sequences.

**Worked example:**
- Reference: `the cat sat on the mat` (6 words)
- Hypothesis: `the cat ate on the mat`
- Edits: 1 substitution (`sat` → `ate`)
- WER = 1 / 6 = **16.67%**

**Range and interpretation:**
- **0.0** = perfect transcription
- **0.05–0.10** = professional broadcast quality
- **0.10–0.20** = typical conversational accuracy on noisy audio
- **>0.30** = unreliable; transcripts will be hard to read
- **>1.0 is possible** — if the hypothesis is much longer than the reference, insertions can drive WER above 100%. In our run, `gpt-audio` hit WER 320% on one sample because it returned a long refusal message.

**When it matters:** the headline accuracy number. Optimize this for any STT system.

#### 3.1.2 Character Error Rate (CER)

**Definition:** Same as WER, but at the **character** level instead of word level.

**Formula:**
```
CER = (S_char + D_char + I_char) / N_chars
```

**Why it's useful:** CER is more forgiving of word-boundary disagreements (e.g. "good morning" vs "goodmorning") and capitalization differences (after lowercase normalization, this doesn't matter — but CER also catches partial-word mistakes that WER counts as full word errors). For non-English languages with no clear word boundaries (Chinese, Japanese, Thai), CER is the *primary* metric.

**Worked example:**
- Reference: `hello world` (11 characters including space)
- Hypothesis: `helloworld`
- Edits: 1 deletion (the space)
- CER = 1 / 11 = **9.09%** (whereas WER = 100%, since both words mismatched)

**Interpretation:** CER is typically about ⅓ to ½ of WER for English. If CER is **>50%** of WER, the model is making partial-word errors (likely truncating words). If CER is much smaller than WER, the model is misordering otherwise-correct characters.

#### 3.1.3 Match Error Rate (MER)

**Definition:** Like WER, but normalized to penalize insertions and deletions equally relative to total alignment length.

**Formula:**
```
MER = (S + D + I) / (S + D + I + C)
```
Where `C` = correct words in the alignment.

**Why it differs from WER:** WER's denominator is reference length; MER's denominator is the alignment length (correct + incorrect words). When the hypothesis is much longer than the reference (insertions), WER can explode (>100%), but MER stays bounded in [0, 1].

**Interpretation:** A model with high WER and high MER is making errors of all kinds. A model with high WER but moderate MER is mostly inserting extra content (hallucinating). Useful when comparing models that produce different output lengths.

#### 3.1.4 Word Information Lost (WIL)

**Definition:** A measure of how much *information* is lost between reference and hypothesis. Combines precision and recall over the alignment.

**Formula:**
```
WIL = 1 - (C² / (N × M))
```
Where:
- `C` = correctly-matched words in the alignment
- `N` = reference word count
- `M` = hypothesis word count

**Why it's useful:** WIL captures the geometric mean of precision (`C/M`, what fraction of predicted words were correct) and recall (`C/N`, what fraction of reference words were captured). If a model adds a lot of correct content but also a lot of garbage, WER might look bad while WIL stays moderate — because the right info is in there.

**Interpretation:** Always between 0 and 1. Lower is better. WIL near 0 means almost all reference info was captured *and* the hypothesis didn't add much noise.

#### 3.1.5 Aggregation: micro vs macro

When we have N utterances per model and want a single accuracy number, two strategies give different answers:

**Micro-average (corpus-level):**
- Concatenate all references into one long string; concatenate all hypotheses similarly; compute WER once.
- Equivalently: sum all S, D, I across utterances; sum all N; divide.
- **Longer utterances dominate** the score (one error in a 100-word reference matters less than one error in a 5-word reference).
- This is the number most papers report.

**Macro-average (per-utterance mean):**
- Compute WER on each utterance individually; take the arithmetic mean.
- **Treats each utterance equally** regardless of length.
- More volatile when utterance lengths vary widely.
- Sometimes higher than micro because short utterances can hit 100% WER easily (one wrong word in a 3-word reference = 33% already).

**Both are reported** in our summary CSV and report. The leaderboards use the micro number.

### 3.2 Latency metrics

Latency is measured as **wall-clock time from `submit` to `transcript ready`**, in milliseconds. All hosted-model latencies include network round-trip time. The local model has no network — its latency is pure CPU work.

#### 3.2.1 Cold start

**Definition:** The wall-clock time of the **very first call** to a model in a run.

For local models, this includes loading the model into memory, compiling kernels, allocating tensors, and decoding the first sample. For hosted models, this includes establishing the HTTPS connection, the first request's TLS handshake, and any provider-side warm-up.

**Why it matters:** It's the user-visible "time to first response" after a cold start. If your service auto-scales to zero, every new instance pays this. The local Whisper in our setup has a 67-second cold start — would be unacceptable for a user-facing service.

#### 3.2.2 Warm latency — mean, median, p95, stdev

After the first call, subsequent calls are "warm" — model is loaded, connection is reused, kernels are compiled.

| Stat | Computation | What it tells you |
|---|---|---|
| **Mean** | Σ latencies / N | The average. Sensitive to outliers — one 360s hang skews this badly. |
| **Median** | The middle latency value | The "typical" experience. Robust to outliers. |
| **p95** | 95th-percentile latency | The "worst typical" experience — 1 in 20 calls is slower than this. **The user-facing SLA number.** |
| **Stdev** | sqrt(Σ(x - mean)²/N) | Variability. Low stdev = predictable; high stdev = jittery. |

**Interpretation guide:**
- **Mean ≈ median:** distribution is symmetric, no outliers.
- **Mean >> median:** there are slow outliers (one or two long calls).
- **p95 ≈ median:** highly consistent latency.
- **p95 >> median:** tail latency problem. Warning sign for production.

In our results, Nemotron's mean (26.5 s) was ~5× its median (~5 s) because of one 361-second outlier. The mean is misleading; the user almost never sees that.

### 3.3 Throughput metrics

#### 3.3.1 Real-Time Factor (RTF)

**Definition:** The ratio of processing time to audio duration.

**Formula:**
```
RTF = processing_time_seconds / audio_duration_seconds
```

**Worked example:**
- Audio: 5 seconds
- Processing: 1.5 seconds
- RTF = 1.5 / 5 = **0.3** (3.3× faster than realtime)

**Critical threshold:**
- **RTF < 1.0 = faster than realtime** ✅ — required for live captions / streaming STT
- **RTF = 1.0** — exactly realtime; can transcribe live but with no headroom
- **RTF > 1.0 = slower than realtime** ❌ — only viable for batch/offline processing

In our run, the local Whisper had RTF 6.96 — for every second of audio, transcription takes ~7 seconds. **This is the killer metric for live STT.** It explains why the local Whisper, despite reasonable WER, can't drive a real-time interview agent on this hardware.

Groq's hosted Whisper had RTF 0.03 — about 33× faster than realtime, which gives massive headroom for batching multiple streams or running on long-form audio.

#### 3.3.2 Audio seconds total / wall seconds total

**Definition:** The sum of audio duration vs the sum of wall-clock processing time across all warm calls.

**Use:** Sanity-checks RTF and lets you compute throughput as `audio_seconds_total / wall_seconds_total`. This is the hourly throughput — how many hours of audio you can transcribe per hour of compute.

### 3.4 Output sanity metrics

These don't measure correctness directly — they detect **failure modes** that WER alone might mask.

#### 3.4.1 Length ratio

**Definition:** The ratio of predicted word count to reference word count.

**Formula:**
```
length_ratio = words_in_hypothesis / words_in_reference
```

**Interpretation:**
- **~1.0** = healthy; the model produced about as many words as it should have.
- **>1.3** = **hallucination warning** — the model wrote substantially more than the reference says. Often this is verbose framing ("The audio says: ...") or invented continuation.
- **<0.7** = **truncation warning** — the model cut off early or refused. Possibly a refusal text shorter than the audio (`gpt-audio` showed length ratio 0.66).
- **0.0** = empty output; the model gave up.

**Why it matters:** WER doesn't distinguish between "got the words wrong" and "made up a totally different output." Length ratio adds that signal.

#### 3.4.2 Failure rate

**Definition:** The fraction of calls that errored (HTTP 4xx/5xx, exceptions, timeouts) or returned `null` content.

**Formula:**
```
failure_rate = n_failed / n_total
```

**Interpretation:**
- **0.00** = perfect; every call succeeded.
- **0.01–0.05** = occasional flaky responses; tolerable with retries.
- **>0.10** = unreliable; not production-ready without circuit-breakers and fallbacks.

In our run, Nemotron had a 0.10 failure rate on the second OpenRouter run (2/20 returned `null` content) — this is the kind of thing that a single-shot test would miss.

### 3.5 Text normalization (the foundation under accuracy)

Before *any* WER computation, both reference and hypothesis are normalized:

1. **Lowercase** everything
2. **Strip punctuation** (commas, periods, quotes) except apostrophes inside contractions
3. **Drop edge apostrophes** (quoted speech: `'word'` → `word`)
4. **Collapse whitespace** (tabs, newlines, multiple spaces → single space)
5. **Trim leading/trailing whitespace**

**Without normalization, WER is meaningless.** Consider:
- Reference: `Hello, world.`
- Hypothesis: `hello world`

Raw comparison gives WER = 100% (every word mismatches due to case + punctuation). After normalization, both become `hello world` and WER = 0%. Clean.

**What we *don't* normalize:**
- **Number formatting** ("twenty" vs "20") — different models choose differently; we accept the small WER penalty when this varies.
- **Spelling variants** ("colour" vs "color") — too project-specific to handle generically.

For deeper normalization (e.g. handling "Mr." vs "Mister"), use Whisper's `EnglishTextNormalizer` from the `whisper-normalizer` package. Our normalizer is intentionally minimal to avoid extra deps.

---

## 4. Methodology

### 4.1 Dataset

- **Source:** `hf-internal-testing/librispeech_asr_dummy` from HuggingFace
- **Why:** Public, no auth, no license issues. Subset of the canonical LibriSpeech corpus used in nearly every ASR paper. 73 utterances total in the validation/clean split.
- **Sample:** 20 utterances (~187.7 s of audio), enough for stable WER estimates without burning API budget.
- **Domain:** Narrated literary text — read-aloud, clean recording, single male speaker. **This is the easy case.** Conversational/interview audio with disfluencies, overlapping speech, and varied accents will produce different (probably worse) numbers across all models.
- **Ground truth:** Provided by the dataset; uppercase, no punctuation. Matched against normalized hypotheses.

### 4.2 Audio handling

- All audio is converted to **mono 16 kHz float32** before being fed to any model. This matches what every shipped engine assumes.
- The HuggingFace dataset is decoded with `soundfile` (we explicitly disable `datasets`' default `torchcodec` decoder to avoid pulling in `torch` as a transitive dependency).
- Each engine receives the *same* numpy array — no model gets a different preprocessing path.

### 4.3 Run protocol

1. Load model (timed as setup; not part of cold-start latency).
2. **First call** runs all bookkeeping for cold-start: time from submit to transcript-ready becomes `cold_start_ms`.
3. **Calls 2 through N** are warm calls. These feed mean/median/p95/stdev.
4. **Streamed JSONL writes** — every per-utterance result is appended to `raw.jsonl` immediately after the call returns. A crash mid-run preserves all prior data.
5. **Sequential, not parallel** — running OpenRouter calls in parallel risks rate-limiting. Sequential gives clean per-call timing.
6. **Failure handling** — exceptions are caught per-call and logged as `error="..."` in the result; the run continues.

### 4.4 What's *not* measured (yet)

- **Cost** — no per-call dollar cost is captured. OpenRouter and Groq both return token usage in responses; we could parse and price-multiply if needed.
- **Streaming latency** — every model is invoked utterance-at-a-time. A "time to first token" metric would matter for streaming STT but isn't measured here because the underlying APIs are utterance-level.
- **Multi-speaker / diarization** — not tested.
- **Noisy / accented audio** — single speaker, clean, US English. Adversarial conditions would shift the rankings.
- **Long-form** — utterances are 5–15 seconds. Long-form transcription (>30 s) might surface different issues (chunking, context loss).

---

## 5. Final results

Run dir: [bench_results/stt_20260508T113703Z/](bench_results/stt_20260508T113703Z/) (canonical 6-model run).
Consolidated narrative: [bench_results/stt_FINAL_consolidated/report.md](bench_results/stt_FINAL_consolidated/report.md).

### 5.1 Leaderboard — Accuracy (lower WER is better)

| Rank | Model | WER (micro) | CER | MER | WIL | Failures |
|---|---|---|---|---|---|---|
| 🥇 | **whisper-large-v3 (Groq)** | **3.57%** | **1.91%** | **3.18%** | 5.84% | 0/20 |
| 🥈 | whisper-large-v3-turbo (Groq) | 4.69% | 2.24% | 4.13% | 7.50% | 0/20 |
| 🥉 | nvidia/nemotron-3-nano-omni:free | 5.13% | 2.97% | 4.81% | 8.02% | 0/20 |
| 4 | google/gemini-2.5-flash *(↔ Chirp 3)* | 5.58% | 2.32% | 5.27% | 9.08% | 0/20 |
| 5 | current STT (local faster-distil-whisper, CPU/int8) | 5.80% | 2.60% | 5.28% | 9.50% | 0/20 |
| 6 | google/gemini-2.5-flash-lite | 6.47% | 2.89% | 6.01% | 10.41% | 0/20 |

### 5.2 Leaderboard — Latency (lower is better)

| Rank | Model | Cold start | Warm mean | Warm median | Warm p95 | Stdev | RTF | Faster than realtime? |
|---|---|---|---|---|---|---|---|---|
| 🥇 | **whisper-large-v3-turbo (Groq)** | 373 ms | **223 ms** | 209 ms | 283 ms | 65 ms | **0.03** | ✅ ~33× |
| 🥈 | whisper-large-v3 (Groq) | 354 ms | 261 ms | 234 ms | 391 ms | 88 ms | 0.03 | ✅ ~33× |
| 🥉 | google/gemini-2.5-flash-lite | 2.88 s | 2.41 s | 2.40 s | 3.05 s | 0.45 s | 0.34 | ✅ ~3× |
| 4 | google/gemini-2.5-flash *(↔ Chirp 3)* | (cold) | 3.55 s | 2.65 s | 6.75 s | 3.5 s | 0.40 | ✅ ~2.5× |
| 5 | nvidia/nemotron-3-nano-omni:free | 4.08 s | 26.52 s* | ~5 s | 60.80 s | 78 s | 4.62 | ❌ |
| 6 | current STT (local faster-distil-whisper, CPU/int8) | 67.0 s | 47.48 s | 47.10 s | 54.16 s | 5.0 s | 6.96 | ❌ |

*\* Nemotron mean inflated by one 361s outlier (likely free-tier rate-limit pause); median was ~5s, consistent with earlier runs.*

> RTF = `processing_time_seconds / audio_duration_seconds`. Anything <1.0 is faster than realtime — required for live captions.

### 5.3 Full summary

| # | Model | n_ok | WER | CER | MER | WIL | Cold | Warm mean | Warm p95 | RTF | Length ratio |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | current STT (local faster-distil-whisper) | 20/20 | 5.80% | 2.60% | 5.28% | 9.50% | 67.0 s | 47.48 s | 54.16 s | 6.96 | 0.99 |
| 2 | google/gemini-2.5-flash | 20/20 | 5.58% | 2.32% | 5.27% | 9.08% | (cold) | 3.55 s | 6.75 s | 0.40 | 1.00 |
| 3 | **whisper-large-v3-turbo (Groq)** | 20/20 | **4.69%** | 2.24% | 4.13% | 7.50% | 373 ms | **223 ms** | 283 ms | **0.03** | 0.99 |
| 4 | **whisper-large-v3 (Groq)** | 20/20 | **3.57%** | **1.91%** | **3.18%** | 5.84% | 354 ms | 261 ms | 391 ms | **0.03** | 0.99 |
| 5 | nvidia/nemotron-3-nano-omni:free | 20/20 | 5.13% | 2.97% | 4.81% | 8.02% | 4.08 s | 26.52 s* | 60.80 s | 4.62 | 0.96 |
| 6 | google/gemini-2.5-flash-lite | 20/20 | 6.47% | 2.89% | 6.01% | 10.41% | 2.88 s | 2.41 s | 3.05 s | 0.34 | 1.00 |

### 5.4 The headline finding — local Whisper vs Groq Whisper

The current production STT and Groq's hosted Whisper are **the same model family** (Whisper-large-v3, with the local one being a distilled variant). The only difference is *where* the inference runs.

| Metric | Local (current, CPU/int8) | Groq (`whisper-large-v3`) | Improvement |
|---|---|---|---|
| WER | 5.80% | **3.57%** | **38% better** |
| CER | 2.60% | **1.91%** | 27% better |
| MER | 5.28% | **3.18%** | 40% better |
| Cold start | 67.0 s | 354 ms | **~190× faster** |
| Warm mean | 47.48 s | 261 ms | **~180× faster** |
| Warm p95 | 54.16 s | 391 ms | **~140× faster** |
| RTF | 6.96 (slower than realtime) | **0.03 (~33× faster)** | ✅ |
| Failures | 0/20 | 0/20 | tied |

Groq beats local Whisper on every metric simultaneously — accuracy, latency, throughput. There is no axis on which the local CPU model is better.

### 5.5 Headline takeaways

#### 1. Groq's hosted Whisper wins on every dimension

Both Groq Whisper variants top the leaderboards:
- `whisper-large-v3` — **best WER (3.57%), best CER (1.91%), best MER (3.18%)**
- `whisper-large-v3-turbo` — second-best WER (4.69%), **lowest warm latency (223 ms)**
- 0% failure rate, length ratio 0.99 (no hallucination), cold start <400 ms

#### 2. The local STT is unusable for live STT on this hardware

CPU/int8 inference of Whisper-distil-large-v3 takes 47 seconds on average to transcribe ~7 seconds of audio — RTF 6.96, ~7× slower than realtime. The accuracy (5.80% WER) is in the same class as the hosted Whisper variants, but the latency makes it impossible to drive a real-time interview agent from this machine. **GPU would change this**, but Groq's hosted Whisper is faster than even most GPU setups.

#### 3. Gemini Flash family is a strong fallback

`google/gemini-2.5-flash` (5.58% WER, 3.55 s warm mean, 0% failures) and `google/gemini-2.5-flash-lite` (6.47% WER, 2.41 s warm mean) both run faster than realtime and are well-suited for a fallback path when Groq is unavailable.

#### 4. Nemotron Omni is competitive on accuracy but variable on latency

Nemotron's WER (5.13%) ties or beats every non-Groq option, and as a free tier, that's notable. But latency is highly variable — median ~5 s, but one outlier hit 361 s (free-tier rate-limit pause). Not viable for live STT, but interesting for batch transcription if cost dominates.

#### 5. No hallucination detected in any model in this run

All six models had length ratio between 0.96 and 1.00 — meaning predicted word counts matched reference word counts cleanly. No model produced verbose framing, refusals, or truncated output on this dataset.

> **Earlier runs that *did* show hallucination:** in the OpenRouter-only run (`stt_20260508T105101Z`), `openai/gpt-audio` had length ratio 0.66 because it returned the refusal text *"Understood. Please provide the audio file..."* on most calls — driving its WER to 75.22%. That model is not in the final lineup; documented in §2.6.

### 5.6 Recommendation

**Migrate the production STT path from local faster-whisper to Groq's `whisper-large-v3`.**

Concrete steps:
1. Add a new `GroqWhisperEngine` to `stream_a/services/speech_io/stt_service/engine.py` mirroring the existing `STTEngine` protocol. The runner in `scripts/stt_bench/runners.py:GroqWhisperRunner` is the reference implementation (~50 lines).
2. Add backend `groq_whisper` to `stt_service/config.yaml` with model id `whisper-large-v3` (or `whisper-large-v3-turbo` for slightly lower latency).
3. Set `WHISPER_MODEL` (or equivalent) to `whisper-large-v3`. Source `GROQ_API_KEY` from the existing `.env`.
4. Keep the existing `faster_whisper` backend wired up as an offline/fallback option.
5. Add `google/gemini-2.5-flash` as a secondary fallback for OpenRouter so an outage on Groq doesn't take down STT.

**Expected user-visible impact for the interview agent:**
- Per-utterance STT latency: ~47 s → ~250 ms — fundamentally enables real-time turn-taking.
- WER: 5.80% → 3.57% — a 38% relative reduction in transcription errors.
- Cold start: 67 s → <400 ms — services can scale to zero without "first call" pain.

---

## 6. How to reproduce

```powershell
# From project root
pip install jiwer datasets librosa tqdm faster-whisper

# Default: 30 utterances from LibriSpeech dummy on HuggingFace
python scripts/benchmark_stt.py

# Smaller smoke run, hosted only:
python scripts/benchmark_stt.py --num-samples 10 --only gemini,whisper,nemotron

# Use your own audio (must contain transcripts.tsv):
python scripts/benchmark_stt.py --audio-dir path/to/wavs

# Override the Chirp 3 substitute slug:
python scripts/benchmark_stt.py --chirp-model-id <openrouter-slug>
```

Outputs land in `bench_results/stt_<UTC-timestamp>/`:
- `raw.jsonl` — append-only per-utterance results
- `per_utterance.csv` — full grid (model × sample × all metrics + reference + hypothesis)
- `summary.csv` — one row per model
- `report.md` — leaderboards + glossary

---

## 7. File map

| Path | Purpose |
|---|---|
| `scripts/benchmark_stt.py` | CLI entry point — argument parsing, dataset load, orchestration |
| `scripts/stt_bench/loaders.py` | HuggingFace dataset loader + local-WAV-dir loader, all resampled to 16 kHz mono |
| `scripts/stt_bench/runners.py` | Per-engine adapters: `FasterWhisperRunner`, `WhisperHFRunner`, `OpenRouterAudioRunner`, `GroqWhisperRunner` |
| `scripts/stt_bench/metrics.py` | WER/CER/MER/WIL + RTF + per-model summary aggregation |
| `scripts/stt_bench/normalizer.py` | Text normalization for fair cross-engine comparison |
| `scripts/stt_bench/report.py` | CSV + Markdown report writers |
| `bench_results/stt_FINAL_consolidated/report.md` | Final consolidated report (this benchmark's results) |
| `bench_results/stt_<timestamp>/` | Individual run outputs |
| `stt_benchmark.md` | This document |
