#!/usr/bin/env bash
# Boots Stream A (STT/VAD/TTS) then runs orchestrator_new.live_main.
# Same shape as run_live.sh, pointed at the new modules.
#
# Usage:
#   ./scripts/run_live_v2.sh
#   ./scripts/run_live_v2.sh --candidate-name "Ayush" --role "Backend"
#   ./scripts/run_live_v2.sh --resume-path resume.pdf --cadence-path cadence.yaml
#   ./scripts/run_live_v2.sh --config path/to/system_config.yaml
#
# Tuning (models, providers, thresholds, STT/TTS/VAD, AEC, etc.) now lives in
# config/system_config.yaml — edit that file, NOT CLI flags. Prompts live in
# config/prompts.yaml. Secrets stay in .env. Per-session inputs (candidate,
# resume, cadence) remain CLI flags above.
#
# Stop with Ctrl-C. The transcript prints at exit.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
INTEGRATION_ROOT="$(cd "$HERE/.." && pwd)"
STREAM_A_DIR="$INTEGRATION_ROOT/stream_a"
PARENT_REPO_ROOT="$(cd "$INTEGRATION_ROOT/.." && pwd)"

# Pick a venv: prefer integration's own, fall back to parent repo's.
if [[ -x "$INTEGRATION_ROOT/.venv/bin/python" ]]; then
    PY="$INTEGRATION_ROOT/.venv/bin/python"
elif [[ -x "$PARENT_REPO_ROOT/.venv/bin/python" ]]; then
    PY="$PARENT_REPO_ROOT/.venv/bin/python"
else
    echo "ERROR: no .venv/bin/python in $INTEGRATION_ROOT or $PARENT_REPO_ROOT" >&2
    echo "       run the install steps in README.md first" >&2
    exit 2
fi

# spaCy's en_core_web_sm is a separate download (not a normal PyPI wheel
# that uv tracks). Kokoro's phonemizer imports it during TTS init; if
# missing, the TTS process hangs silently with no log output. Install it
# on first run — idempotent fast no-op afterward.
if ! "$PY" -c "import en_core_web_sm" 2>/dev/null; then
    echo "--- installing spaCy en_core_web_sm (one-time, ~12MB) ---"
    "$PY" -m spacy download en_core_web_sm
fi

# Source LLM credentials. Prefer GROQ_API_KEY (Groq is much faster than
# OpenRouter for our slow LLM); fall back to OPENROUTER_API_KEY.
GROQ_KEY=""
OR_KEY=""
for cand in \
    "$INTEGRATION_ROOT/.env" \
    "$PARENT_REPO_ROOT/.env" \
    "$PARENT_REPO_ROOT/STREAM_B/Interview_agent_app/.env" \
    "$INTEGRATION_ROOT/.env.example"
do
    if [[ -f "$cand" ]]; then
        if [[ -z "$GROQ_KEY" ]] && grep -qE '^GROQ_API_KEY=.+' "$cand"; then
            GROQ_KEY=$(grep '^GROQ_API_KEY=' "$cand" | cut -d= -f2-)
            echo "GROQ_API_KEY sourced from $cand"
        fi
        if [[ -z "$OR_KEY" ]] && grep -qE '^OPENROUTER_API_KEY=.+' "$cand"; then
            OR_KEY=$(grep '^OPENROUTER_API_KEY=' "$cand" | cut -d= -f2-)
        fi
    fi
done
if [[ -z "$GROQ_KEY" && -z "$OR_KEY" ]]; then
    echo "ERROR: neither GROQ_API_KEY nor OPENROUTER_API_KEY found in any .env" >&2
    exit 2
fi
[[ -n "$GROQ_KEY" ]] && export GROQ_API_KEY="$GROQ_KEY"
[[ -n "$OR_KEY"   ]] && export OPENROUTER_API_KEY="$OR_KEY"

mkdir -p /tmp/integration_logs /tmp/integration
rm -f /tmp/integration_logs/*.log /tmp/integration/events.jsonl

# Decide whether to boot Stream A's STT service. The STT provider now lives
# in config/system_config.yaml (stt.provider), not a CLI flag. If it's
# 'streamA' we boot the bundled faster-whisper service; otherwise (groq /
# azure) we skip it — it loads ~1.5 GB and adds 5-15 min of init for nothing,
# since the orchestrator routes audio straight to the remote STT API.
# Honour a user-supplied --config <path>; else use the repo default.
CONFIG_PATH="$INTEGRATION_ROOT/config/system_config.yaml"
prev=""
for arg in "$@"; do
    [[ "$prev" == "--config" ]] && CONFIG_PATH="$arg"
    [[ "$arg" == --config=* ]] && CONFIG_PATH="${arg#--config=}"
    prev="$arg"
done
STT_PROVIDER=$("$PY" -c "
import sys, yaml
try:
    cfg = yaml.safe_load(open(sys.argv[1])) or {}
    print(((cfg.get('stt') or {}).get('provider') or 'groq'))
except Exception:
    print('groq')
" "$CONFIG_PATH" 2>/dev/null || echo groq)
echo "STT provider (from $CONFIG_PATH): $STT_PROVIDER"
USE_STREAMA_STT=0
[[ "$STT_PROVIDER" == "streamA" ]] && USE_STREAMA_STT=1

# Ports we'll actually start. STT (8010) is conditional.
PORTS_TO_KILL=(8011 8012)
(( USE_STREAMA_STT == 1 )) && PORTS_TO_KILL+=(8010)
for port in "${PORTS_TO_KILL[@]}"; do
    pids=$(lsof -ti tcp:$port 2>/dev/null || true)
    if [[ -n "$pids" ]]; then
        echo "killing stale process on :$port (pids: $pids)"
        kill -9 $pids 2>/dev/null || true
    fi
done

PIDS=()
cleanup() {
    echo ""
    echo "--- shutting down Stream A subprocesses ---"
    for pid in "${PIDS[@]:-}"; do kill "$pid" 2>/dev/null || true; done
    wait 2>/dev/null || true
}
# Trap on EXIT only — same rationale as run_live.sh: SIGINT goes to Python
# first, Python flushes, then EXIT trap fires.
trap cleanup EXIT

cd "$STREAM_A_DIR"

if (( USE_STREAMA_STT == 1 )); then
    echo "--- starting STT (bundled Stream A — faster-whisper) ---"
    STREAM_A_FAKE_BACKENDS=0 \
    KMP_DUPLICATE_LIB_OK=TRUE \
    WHISPER_MODEL_PATH="${WHISPER_MODEL_PATH:-Systran/faster-distil-whisper-large-v3}" \
    "$PY" -m services.speech_io.stt_service.main > /tmp/integration_logs/stt.log 2>&1 &
    PIDS+=($!)
else
    echo "--- skipping STT service (using Groq STT — no local model needed) ---"
fi

echo "--- starting VAD (bundled Stream A) ---"
STREAM_A_FAKE_BACKENDS=0 \
SILERO_MODEL_PATH="$STREAM_A_DIR/models/silero_vad.onnx" \
"$PY" -m services.speech_io.vad_service.main > /tmp/integration_logs/vad.log 2>&1 &
PIDS+=($!)

echo "--- starting TTS (bundled Stream A — Kokoro local) ---"
# HF_HUB_OFFLINE=1 — Kokoro's KPipeline does a HEAD request to
# huggingface.co/hexgrad/Kokoro-82M/resolve/main/config.json on startup to
# check whether the cached model is up to date. When HF is slow or
# unreachable (corporate proxy, VPN, flaky Wi-Fi) this times out 5× (10s +
# backoff = ~40s wasted) before falling back to local cache, which can
# blow past the script's 120s health-check budget. Force-offline mode
# skips the HEAD entirely; model is downloaded once on first install at
# ~/.cache/huggingface/ and this flag has no effect on that initial fetch.
STREAM_A_FAKE_BACKENDS=0 \
KMP_DUPLICATE_LIB_OK=TRUE \
HF_HUB_OFFLINE=1 \
"$PY" -m services.speech_io.tts_service.main > /tmp/integration_logs/tts.log 2>&1 &
PIDS+=($!)

# Health-check budget depends on which services are starting.
# - Groq mode (VAD + TTS only): 120s is plenty after first run.
# - streamA mode (STT included): keep the 15-min budget for the
#   first-time faster-whisper download (~1.5 GB).
if (( USE_STREAMA_STT == 1 )); then
    HEALTH_DEADLINE_S=900
    HEALTH_URLS=( "http://127.0.0.1:8010/healthz" "http://127.0.0.1:8011/healthz" "http://127.0.0.1:8012/healthz" )
    HEALTH_NAMES=( "STT" "VAD" "TTS" )
    echo "--- waiting for /healthz on 8010/8011/8012 (15-min budget for first-time whisper download) ---"
else
    HEALTH_DEADLINE_S=120
    HEALTH_URLS=( "http://127.0.0.1:8011/healthz" "http://127.0.0.1:8012/healthz" )
    HEALTH_NAMES=( "VAD" "TTS" )
    echo "--- waiting for /healthz on 8011/8012 (2-min budget — no whisper to download) ---"
fi
START_TS=$(date +%s)
DEADLINE=$(( START_TS + HEALTH_DEADLINE_S ))
NEXT_HEARTBEAT=$(( START_TS + 15 ))
while :; do
    all_up=1
    for url in "${HEALTH_URLS[@]}"; do
        curl -sf "$url" >/dev/null || { all_up=0; break; }
    done
    (( all_up == 1 )) && break

    NOW=$(date +%s)
    if (( NOW > DEADLINE )); then
        echo "ERROR: services failed to come up in $((HEALTH_DEADLINE_S))s"
        for s in stt vad tts; do
            [[ -f /tmp/integration_logs/$s.log ]] || continue
            echo "--- $s.log (last 20 lines) ---"
            tail -20 /tmp/integration_logs/$s.log 2>/dev/null
        done
        exit 3
    fi
    if (( NOW > NEXT_HEARTBEAT )); then
        DOWN=()
        for i in "${!HEALTH_URLS[@]}"; do
            curl -sf "${HEALTH_URLS[$i]}" >/dev/null || DOWN+=("${HEALTH_NAMES[$i]}")
        done
        echo "  [+$((NOW - START_TS))s] still waiting on: ${DOWN[*]}"
        NEXT_HEARTBEAT=$(( NOW + 15 ))
    fi
    sleep 1
done
echo "Stream A services ready (took $(( $(date +%s) - START_TS ))s)"

echo ""
echo "--- running orchestrator_new (live mic) ---"
cd "$INTEGRATION_ROOT"
"$PY" -m engine.orchestrator.live_main "$@"
