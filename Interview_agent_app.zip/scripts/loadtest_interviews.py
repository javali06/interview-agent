#!/usr/bin/env python3
"""
Load-test ONE session shard to find interviews-per-shard (C).

Opens N concurrent candidate WebSockets against a single session process,
streams a 16 kHz mono PCM WAV as *real-time* candidate speech, and measures
per-turn reply latency (you-stop-speaking → first AI-audio frame). Ramps N and
prints p50/p95/p99 so you can spot the knee where the shard saturates.

    pip install websockets
    python scripts/loadtest_interviews.py \
        --url ws://localhost:8080 --wav answer_16k.wav \
        --ramp 1,5,10,20,25,30 --turns 6

Make it a valid measurement:
  • Point --url at ONE shard. Locally with a single session container this is
    just the gateway (ws://localhost:8080); in cloud, target one session
    container's internal URL (or temporarily run a single shard).
  • Pin the shard to the PROD vCPU (docker run --cpus=1 …) — a laptop core
    overestimates C badly.
  • Take Speech OUT of the way so you measure CPU, not the 5-stream cap:
    give the shard ceil(maxN/5) Speech keys (AZURE_SPEECH_KEYS) or a Groq
    STT fallback. Otherwise you're measuring Speech quota, not the shard.
  • Uses the NO-TOKEN path → each socket is an independent interview on the
    default cadence (no pre-scheduling). If your build requires a cadence,
    bulk-create N tokens first and pass them via --token-file instead.
"""
import argparse, asyncio, json, time, uuid, wave
import websockets  # pip install websockets

SR = 16000
FRAME_MS = 20
FRAME_BYTES = SR * 2 * FRAME_MS // 1000          # 640 bytes = 20 ms of 16-bit mono
SILENCE = b"\x00" * FRAME_BYTES


def load_pcm(path: str) -> bytes:
    w = wave.open(path, "rb")
    ok = w.getframerate() == SR and w.getnchannels() == 1 and w.getsampwidth() == 2
    data = w.readframes(w.getnframes())
    w.close()
    if not ok:
        raise SystemExit("WAV must be 16 kHz, mono, 16-bit PCM")
    return data


async def _send_stream(ws, pcm: bytes, seconds: float, off: int) -> int:
    """Stream `seconds` of audio at real-time pace; loop the clip if short."""
    frames = int(seconds * 1000 / FRAME_MS)
    for _ in range(frames):
        if pcm:
            chunk = pcm[off:off + FRAME_BYTES]
            if len(chunk) < FRAME_BYTES:
                off = 0
                chunk = pcm[:FRAME_BYTES]
            off += FRAME_BYTES
        else:
            chunk = SILENCE
        await ws.send(chunk)
        await asyncio.sleep(FRAME_MS / 1000)
    return off


async def _send_silence(ws, seconds: float) -> None:
    for _ in range(int(seconds * 1000 / FRAME_MS)):
        await ws.send(SILENCE)
        await asyncio.sleep(FRAME_MS / 1000)


async def _drain_until_quiet(ws, quiet_ms: int, hard_timeout: float) -> None:
    """Consume inbound frames until the AI has been silent for quiet_ms
    (its turn is over), or hard_timeout elapses."""
    deadline = time.perf_counter() + hard_timeout
    last = time.perf_counter()
    while (time.perf_counter() - last) * 1000 < quiet_ms and time.perf_counter() < deadline:
        try:
            m = await asyncio.wait_for(ws.recv(), timeout=quiet_ms / 1000)
            if isinstance(m, (bytes, bytearray)):
                last = time.perf_counter()
        except asyncio.TimeoutError:
            return


async def _wait_ai_audio(ws, timeout: float):
    """Return timestamp of the first AI-audio (binary) frame, or None."""
    end = time.perf_counter() + timeout
    while time.perf_counter() < end:
        try:
            m = await asyncio.wait_for(ws.recv(), timeout=end - time.perf_counter())
        except asyncio.TimeoutError:
            return None
        if isinstance(m, (bytes, bytearray)) and len(m) > 0:
            return time.perf_counter()
    return None


async def one_client(base: str, pcm: bytes, turns: int, token: str | None,
                     results: list, errors: list) -> None:
    sid = "load-" + uuid.uuid4().hex[:8]
    q = f"?token={token}" if token else ""
    url = f"{base}/ws/candidate/{sid}{q}"
    off = 0
    try:
        async with websockets.connect(url, max_size=None, open_timeout=25,
                                      ping_interval=20, ping_timeout=40) as ws:
            await ws.send(json.dumps({"type": "start", "visual_mode": "none",
                                      "candidate": {"name": "load", "role": "test"}}))
            for t in range(turns):
                await _drain_until_quiet(ws, quiet_ms=600, hard_timeout=20)   # let AI finish
                off = await _send_stream(ws, pcm, seconds=4.0, off=off)       # candidate answers
                t0 = time.perf_counter()
                await _send_silence(ws, seconds=1.2)                          # go quiet → VAD endpoint
                first = await _wait_ai_audio(ws, timeout=15)
                if first is None:
                    errors.append((sid, f"turn{t}:no-reply"))
                    break
                if t > 0:                                                     # skip warm-up turn
                    results.append((first - t0) * 1000)
            try:
                await ws.send(json.dumps({"type": "end"}))
            except Exception:
                pass
    except Exception as e:
        errors.append((sid, repr(e)[:90]))


async def run_level(base, pcm, n, turns, tokens):
    results, errors = [], []
    tasks = [one_client(base, pcm, turns, (tokens[i] if tokens else None),
                        results, errors) for i in range(n)]
    await asyncio.gather(*tasks)
    return results, errors


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", required=True, help="session/gateway WS base, e.g. ws://localhost:8080")
    ap.add_argument("--wav", required=True, help="16 kHz mono 16-bit PCM WAV of candidate speech")
    ap.add_argument("--ramp", default="1,5,10,20,25,30")
    ap.add_argument("--turns", type=int, default=6)
    ap.add_argument("--token-file", help="optional: one interview token per line (>= max ramp N)")
    a = ap.parse_args()

    pcm = load_pcm(a.wav)
    tokens = None
    if a.token_file:
        tokens = [ln.strip() for ln in open(a.token_file) if ln.strip()]

    print(f"{'N':>4} {'turns':>6} {'errs':>5} {'p50ms':>7} {'p95ms':>7} {'p99ms':>7}")
    for n in [int(x) for x in a.ramp.split(",")]:
        res, err = await run_level(a.url, pcm, n, a.turns, tokens)
        if res:
            res.sort()
            pct = lambda qv: res[min(len(res) - 1, int(len(res) * qv))]
            print(f"{n:>4} {len(res):>6} {len(err):>5} {pct(.5):>7.0f} {pct(.95):>7.0f} {pct(.99):>7.0f}")
        else:
            print(f"{n:>4} {0:>6} {len(err):>5}   no successful turns  e.g. {err[:1]}")
    print("\nC = the largest N before p95 KNEES upward. The number includes the ~1 s "
          "VAD end-of-speech window; the processing budget itself is ~900 ms.")


if __name__ == "__main__":
    asyncio.run(main())
