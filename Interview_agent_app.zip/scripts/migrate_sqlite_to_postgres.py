#!/usr/bin/env python3
"""One-shot: copy the local SQLite DB into Postgres for the tiered cutover.

The monolith (demo-prod) runs on SQLite at <SESSIONS_DIR>/sessions.db. The
tiered deploy needs ONE shared Postgres every replica reads/writes. This lifts
existing rows (roles, candidates, sessions, scores, observer notes) across so
the cutover doesn't lose scheduled interviews or shortlist history.

Usage:
    # explicit
    python scripts/migrate_sqlite_to_postgres.py \
        --sqlite sessions/sessions.db \
        --postgres "postgresql+psycopg://user:pw@host:5432/interview"

    # or rely on env: DATABASE_URL for the dest, default path for the source
    DATABASE_URL="postgresql+psycopg://..." python scripts/migrate_sqlite_to_postgres.py

Safe to re-run: a dest table that already has rows is SKIPPED (use --force to
insert anyway). Tables new to the tiered schema (e.g. `jobs`) that don't exist
in the old SQLite file are simply created empty on the dest.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Make the repo importable when run as a script.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import create_engine, inspect, select  # noqa: E402

from db.engine import Base, _default_sqlite_url, _ensure_added_columns  # noqa: E402
import db.models  # noqa: E402,F401  (register mappers on Base)


def _norm(url: str) -> str:
    """Accept a bare path or a sqlite/postgres URL; normalise to a SQLAlchemy URL."""
    if "://" in url:
        return url
    return f"sqlite:///{url}"


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--sqlite", help="source SQLite file or URL (default: SESSIONS_DIR/sessions.db)")
    ap.add_argument("--postgres", help="dest Postgres URL (default: $DATABASE_URL)")
    ap.add_argument("--force", action="store_true",
                    help="insert even if the dest table already has rows")
    ap.add_argument("--batch", type=int, default=500, help="insert batch size")
    args = ap.parse_args()

    import os
    src_url = _norm(args.sqlite) if args.sqlite else _default_sqlite_url()
    dst_url = args.postgres or os.environ.get("DATABASE_URL")
    if not dst_url:
        ap.error("no dest: pass --postgres or set DATABASE_URL")
    if dst_url.startswith("sqlite"):
        ap.error("dest looks like SQLite — this tool migrates INTO Postgres")

    print(f"source (sqlite):  {src_url}")
    print(f"dest   (postgres): {dst_url}")

    src = create_engine(src_url, future=True)
    dst = create_engine(dst_url, future=True, pool_pre_ping=True)

    # Build the full tiered schema on the dest (idempotent) + additive columns.
    Base.metadata.create_all(dst)
    _ensure_added_columns(dst)

    src_tables = set(inspect(src).get_table_names())
    total = 0
    # sorted_tables respects FK order (parents before children).
    for table in Base.metadata.sorted_tables:
        name = table.name
        if name not in src_tables:
            print(f"  - {name}: not in source, created empty on dest")
            continue

        with src.connect() as sc:
            rows = [dict(r) for r in sc.execute(select(table)).mappings().all()]
        if not rows:
            print(f"  - {name}: 0 rows")
            continue

        with dst.begin() as dc:
            existing = dc.execute(select(table)).mappings().first()
            if existing is not None and not args.force:
                print(f"  - {name}: dest already has rows — SKIP (use --force)")
                continue
            for i in range(0, len(rows), args.batch):
                dc.execute(table.insert(), rows[i:i + args.batch])
        print(f"  - {name}: copied {len(rows)} rows")
        total += len(rows)

    print(f"done. {total} rows migrated.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
