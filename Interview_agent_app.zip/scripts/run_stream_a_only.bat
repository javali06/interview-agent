@echo off
setlocal enabledelayedexpansion

REM ---------------------------------------------------------------------------
REM run_stream_a_only.bat - Stream A (STT/VAD/TTS) services only.
REM
REM Boots the three speech-IO services on 8010/8011/8012, waits for /healthz,
REM and stays alive so the admin app can spawn per-session orchestrators
REM against them without re-paying model-load time per interview.
REM
REM Closing this window kills all three services (they're start /B children).
REM ---------------------------------------------------------------------------

set "HERE=%~dp0"
pushd "%HERE%.."
set "INTEGRATION_ROOT=%CD%"
popd
set "STREAM_A_DIR=%INTEGRATION_ROOT%\engine\speech"

if not exist "%INTEGRATION_ROOT%\.venv\Scripts\python.exe" (
    echo ERROR: no .venv\Scripts\python.exe at %INTEGRATION_ROOT%
    exit /b 2
)
set "PY=%INTEGRATION_ROOT%\.venv\Scripts\python.exe"

if not exist "%INTEGRATION_ROOT%\.env" (
    echo ERROR: .env not found at %INTEGRATION_ROOT%\.env
    exit /b 2
)

where curl >nul 2>&1
if errorlevel 1 (
    echo ERROR: curl not found on PATH.
    exit /b 2
)

REM Load LLM keys from .env (live_main will re-source them; this exports for any child diagnostic)
for /f "usebackq tokens=1,* delims==" %%A in (`findstr /B /C:"GROQ_API_KEY=" /C:"OPENROUTER_API_KEY=" "%INTEGRATION_ROOT%\.env"`) do (
    set "%%A=%%B"
)

set "LOG_DIR=%TEMP%\integration_logs"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
del /q "%LOG_DIR%\*.log" 2>nul

echo.
echo --- killing stale processes on Stream A ports (8010/8011/8012) ---
for %%P in (8010 8011 8012) do (
    for /f "tokens=5" %%I in ('netstat -ano ^| findstr ":%%P " ^| findstr "LISTENING"') do (
        echo   killing PID %%I on :%%P
        taskkill /F /PID %%I >nul 2>&1
    )
)

set "STREAM_A_FAKE_BACKENDS=0"
set "KMP_DUPLICATE_LIB_OK=TRUE"
set "PYTHONUNBUFFERED=1"
set "HF_HUB_OFFLINE=1"
if not defined WHISPER_MODEL_PATH set "WHISPER_MODEL_PATH=Systran/faster-distil-whisper-large-v3"
set "SILERO_MODEL_PATH=%STREAM_A_DIR%\models\silero_vad.onnx"

echo.
echo ============================================================
echo   STREAM A STARTING - STT/VAD/TTS logs interleave below
echo ============================================================
echo.
cd /d "%STREAM_A_DIR%"
start /B "" "%PY%" -u -m services.speech_io.stt_service.main
start /B "" "%PY%" -u -m services.speech_io.vad_service.main
start /B "" "%PY%" -u -m services.speech_io.tts_service.main
cd /d "%INTEGRATION_ROOT%"

set /a "ELAPSED=0"
set /a "DEADLINE=900"
set /a "NEXT_HEARTBEAT=30"

:waithealth
curl -sf http://127.0.0.1:8010/healthz >nul 2>&1
if errorlevel 1 goto notyet
curl -sf http://127.0.0.1:8011/healthz >nul 2>&1
if errorlevel 1 goto notyet
curl -sf http://127.0.0.1:8012/healthz >nul 2>&1
if errorlevel 1 goto notyet
goto allup

:notyet
if !ELAPSED! GEQ !DEADLINE! goto failed
if !ELAPSED! GEQ !NEXT_HEARTBEAT! call :heartbeat
timeout /t 1 /nobreak >nul
set /a "ELAPSED+=1"
goto waithealth

:heartbeat
set "DOWN="
curl -sf http://127.0.0.1:8010/healthz >nul 2>&1
if errorlevel 1 set "DOWN=!DOWN! STT"
curl -sf http://127.0.0.1:8011/healthz >nul 2>&1
if errorlevel 1 set "DOWN=!DOWN! VAD"
curl -sf http://127.0.0.1:8012/healthz >nul 2>&1
if errorlevel 1 set "DOWN=!DOWN! TTS"
echo.
echo [stream_a] [+!ELAPSED!s] still waiting on:!DOWN!
echo.
set /a "NEXT_HEARTBEAT+=30"
goto :eof

:failed
echo.
echo ERROR: Stream A services failed to come up in 15 min. Scroll up for tracebacks.
exit /b 3

:allup
echo.
echo ============================================================
echo   STREAM A READY (took !ELAPSED!s) - admin app can now
echo   spawn per-session orchestrators against these services.
echo.
echo   Close this window to stop Stream A.
echo ============================================================
echo.

REM Idle loop so the script stays alive and the start /B children keep running.
:idle
timeout /t 3600 /nobreak >nul
goto idle
