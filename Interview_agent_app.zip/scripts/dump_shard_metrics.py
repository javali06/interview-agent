#!/usr/bin/env python3
"""Dump session-shard CPU + memory from Azure Monitor — for load-test capacity.

Run this DURING or right AFTER a load test against a session shard to see how
CPU/memory climb as concurrency ramps. Per-minute samples (Azure Monitor's
finest granularity). CPU is shown in cores AND as a % of the app's vCPU limit,
so the saturation point (CPU% → ~100) is obvious.

    python3 scripts/dump_shard_metrics.py                 # all session-* apps, last 30 min
    python3 scripts/dump_shard_metrics.py --app session-0 --minutes 60

Pair it with the load test's p50/p95/p99 knee and the app's own "[loop-lag]"
log lines: when CPU% nears 100 AND loop-lag spikes past ~100ms AND p95 knees,
that concurrency is your interviews-per-shard ceiling (C).

Requires `az` logged in (this repo's az lives at ~/azure-cli-env/bin).
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
import shutil
import subprocess
import sys

RG = os.environ.get("RESOURCE_GROUP", "AI-COE")

# az is a shell alias on this machine, not on a non-interactive PATH.
if shutil.which("az") is None:
    os.environ["PATH"] = "/Users/ayush.kothiyal/azure-cli-env/bin:" + os.environ.get("PATH", "")


def az(*args: str) -> str:
    r = subprocess.run(["az", *args], capture_output=True, text=True)
    if r.returncode != 0:
        sys.stderr.write(r.stderr)
        sys.exit(r.returncode)
    return r.stdout


def _metric(rid: str, name: str, aggs: list[str], start: str) -> list[dict]:
    raw = az(
        "monitor", "metrics", "list", "--resource", rid, "--metric", name,
        "--aggregation", *aggs, "--interval", "PT1M", "--start-time", start, "-o", "json",
    )
    try:
        return json.loads(raw)["value"][0]["timeseries"][0]["data"]
    except (IndexError, KeyError, json.JSONDecodeError):
        return []


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--app", default=None, help="shard app name (default: all session-*)")
    ap.add_argument("--minutes", type=int, default=30, help="lookback window")
    args = ap.parse_args()

    start = (
        datetime.datetime.now(datetime.timezone.utc)
        - datetime.timedelta(minutes=args.minutes)
    ).strftime("%Y-%m-%dT%H:%M:%SZ")

    if args.app:
        apps = [args.app]
    else:
        apps = az(
            "containerapp", "list", "-g", RG,
            "--query", "[?starts_with(name,'session-')].name", "-o", "tsv",
        ).split()

    for app in apps:
        rid = az("containerapp", "show", "-g", RG, "-n", app, "--query", "id", "-o", "tsv").strip()
        lim = float(az(
            "containerapp", "show", "-g", RG, "-n", app,
            "--query", "properties.template.containers[0].resources.cpu", "-o", "tsv",
        ).strip() or "1.0")
        cpu = {d["timeStamp"]: d for d in _metric(rid, "UsageNanoCores", ["Average", "Maximum"], start)}
        mem = {d["timeStamp"]: d for d in _metric(rid, "WorkingSetBytes", ["Maximum"], start)}

        print(f"\n==================== {app}  (limit {lim} vCPU / 2Gi) ====================")
        print(f"{'time(UTC)':<10} {'cpu_avg':>8} {'cpu_max':>8} {'cpu%_max':>9} {'mem_MB':>8} {'mem%':>6}")
        for ts in sorted(cpu):
            avg = (cpu[ts].get("average") or 0.0) / 1e9
            mx = (cpu[ts].get("maximum") or 0.0) / 1e9
            mem_mb = (mem.get(ts, {}).get("maximum") or 0.0) / 1048576
            print(
                f"{ts[11:19]:<10} {avg:>8.2f} {mx:>8.2f} {mx / lim * 100:>8.1f}% "
                f"{mem_mb:>8.0f} {mem_mb / 2048 * 100:>5.0f}%"
            )
        if not cpu:
            print("  (no samples — no load in the window, or metrics not yet emitted)")


if __name__ == "__main__":
    main()
