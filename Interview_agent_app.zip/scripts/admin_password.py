"""Generate a bcrypt hash for the admin password.

Usage:
    python scripts/admin_password.py centific123

Paste the printed hash into .env as `ADMIN_PASSWORD_HASH=...`.
"""
from __future__ import annotations

import sys

import bcrypt


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print("Usage: python scripts/admin_password.py <password>", file=sys.stderr)
        return 2
    password = argv[1].encode("utf-8")
    hashed = bcrypt.hashpw(password, bcrypt.gensalt()).decode("utf-8")
    print(hashed)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
