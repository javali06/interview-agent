"""Per-engine adapters for the STT benchmark.

Each runner implements the same minimal interface:

    runner.name           # short identifier used in the report
    runner.label          # human-readable description (e.g. "openai/whisper-large-v3 (HF, CPU)")
    runner.setup()        # heavy init (model load, HTTP client) — timed as cold-start
    runner.transcribe(audio, sr) -> str   # returns the predicted text
    runner.teardown()     # release resources

The runners are intentionally decoupled from Stream A's `engine.py` so the
benchmark can evolve without dragging in `contracts.*` and the YAML config
machinery. The underlying libraries (faster_whisper, transformers, httpx) are
the same ones Stream A uses.

Skip behavior: if a runner's prerequisites are missing (missing API key,
unavailable model, missing optional package), `setup()` raises a
`RunnerUnavailable` and the bench harness records the row as "skipped".
"""

from __future__ import annotations

import base64
import io
import json
import os
import time
import wave
from typing import Protocol

import numpy as np


class RunnerUnavailable(Exception):
    """Raised by setup() when the runner can't be used (missing key, missing dep, etc.)."""


class Runner(Protocol):
    name: str
    label: str

    def setup(self) -> None: ...
    def transcribe(self, audio: np.ndarray, sr: int) -> str: ...
    def teardown(self) -> None: ...


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _float32_to_wav_bytes(audio: np.ndarray, sr: int = 16_000) -> bytes:
    pcm = (np.clip(audio, -1.0, 1.0) * 32767).astype("<i2").tobytes()
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes(pcm)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Local: faster-whisper (the "current" engine when WHISPER_MODEL_PATH is set)
# ---------------------------------------------------------------------------


class FasterWhisperRunner:
    """Wraps faster-whisper (CTranslate2). Used for "Model 1: current STT".

    If `WHISPER_MODEL_PATH` is unset, this runner cannot start. The harness will
    fall back to recording it as skipped — the README documents how to install a
    local model.
    """

    def __init__(self, model_path: str | None = None, beam_size: int = 1) -> None:
        self.name = "current_faster_whisper"
        self._model_path = model_path or os.environ.get("WHISPER_MODEL_PATH", "")
        self._beam_size = beam_size
        self._model = None
        self._device = "cpu"
        self._compute_type = "int8"
        self.label = "current STT (faster-whisper, CPU/int8)"

    def setup(self) -> None:
        if not self._model_path:
            raise RunnerUnavailable(
                "WHISPER_MODEL_PATH not set — faster-whisper has no local model to load. "
                "Set it to a CTranslate2 model dir (or pass --current-model-path), "
                "or use --current-fallback-hf to substitute a HuggingFace Whisper as Model 1."
            )
        try:
            from faster_whisper import WhisperModel
        except ImportError as e:
            raise RunnerUnavailable(f"faster-whisper not importable: {e}") from e
        try:
            import ctranslate2
            if ctranslate2.get_cuda_device_count() > 0:
                self._device = "cuda"
                self._compute_type = "float16"
        except Exception:
            pass
        self._model = WhisperModel(self._model_path, device=self._device, compute_type=self._compute_type)
        self.label = f"current STT (faster-whisper @ {self._model_path}, {self._device}/{self._compute_type})"

    def transcribe(self, audio: np.ndarray, sr: int) -> str:
        assert self._model is not None
        segments, _info = self._model.transcribe(
            audio.astype(np.float32),
            beam_size=self._beam_size,
            word_timestamps=False,
            vad_filter=False,
        )
        return "".join(s.text for s in segments).strip()

    def teardown(self) -> None:
        self._model = None


# ---------------------------------------------------------------------------
# Local: HuggingFace Transformers Whisper
# ---------------------------------------------------------------------------


class WhisperHFRunner:
    """OpenAI Whisper via HuggingFace transformers pipeline.

    Used for `whisper-large-v3` and `whisper-large-v3-turbo`. CPU is supported
    but slow — large-v3 on CPU is ~2-5x realtime per utterance. Set
    BENCH_WHISPER_DEVICE=cuda:0 if you have a GPU.
    """

    def __init__(self, model_id: str, language: str = "en") -> None:
        self.name = model_id.replace("/", "_")
        self.label = f"{model_id} (HF transformers)"
        self._model_id = model_id
        self._language = language
        self._pipe = None
        self._device = os.environ.get("BENCH_WHISPER_DEVICE", "auto")

    def setup(self) -> None:
        try:
            import torch
            from transformers import (
                AutoModelForSpeechSeq2Seq,
                AutoProcessor,
                pipeline,
            )
        except ImportError as e:
            raise RunnerUnavailable(f"transformers/torch not importable: {e}") from e

        if self._device == "auto":
            self._device = "cuda:0" if torch.cuda.is_available() else "cpu"
        torch_dtype = torch.float16 if self._device.startswith("cuda") else torch.float32

        try:
            model = AutoModelForSpeechSeq2Seq.from_pretrained(
                self._model_id, torch_dtype=torch_dtype, low_cpu_mem_usage=True
            )
            model.to(self._device)
            processor = AutoProcessor.from_pretrained(self._model_id)
        except Exception as e:
            raise RunnerUnavailable(f"failed to load {self._model_id}: {e}") from e

        self._pipe = pipeline(
            "automatic-speech-recognition",
            model=model,
            tokenizer=processor.tokenizer,
            feature_extractor=processor.feature_extractor,
            torch_dtype=torch_dtype,
            device=self._device,
        )
        self.label = f"{self._model_id} (HF, {self._device})"

    def transcribe(self, audio: np.ndarray, sr: int) -> str:
        assert self._pipe is not None
        result = self._pipe(
            audio.astype(np.float32),
            return_timestamps=False,
            chunk_length_s=30.0,
            generate_kwargs={"language": self._language, "task": "transcribe"},
        )
        return (result.get("text") or "").strip()

    def teardown(self) -> None:
        self._pipe = None


# ---------------------------------------------------------------------------
# Hosted: OpenRouter chat/completions with audio input
# ---------------------------------------------------------------------------


_OPENROUTER_PROMPT = (
    "Transcribe the following audio verbatim. Return STRICT JSON only — no prose "
    'before or after — with this exact shape: {"text": "<full transcript>"}\n'
    "Do not include timestamps. Do not wrap in code fences."
)


class OpenRouterAudioRunner:
    """Send audio to OpenRouter's chat/completions for utterance-level transcription.

    Works for any OpenRouter model that accepts `input_audio` content blocks.
    Used for: google/chirp-3, nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free,
    google/gemini-2.5-flash-lite.

    Models that don't support audio input (or are 404) raise RunnerUnavailable
    on the first transcribe call — the harness catches it and records "skipped".
    """

    def __init__(self, model_id: str, api_key: str | None = None, base_url: str | None = None,
                 timeout_s: float = 60.0) -> None:
        self.name = model_id.replace("/", "_").replace(":", "_")
        self.label = f"{model_id} (OpenRouter)"
        self._model_id = model_id
        self._api_key = api_key or os.environ.get("OPENROUTER_API_KEY", "")
        self._base_url = base_url or os.environ.get("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1")
        self._timeout_s = timeout_s
        self._client = None

    def setup(self) -> None:
        if not self._api_key:
            raise RunnerUnavailable("OPENROUTER_API_KEY is empty")
        try:
            import httpx
        except ImportError as e:
            raise RunnerUnavailable(f"httpx not importable: {e}") from e
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "HTTP-Referer": "https://interview-assist.local",
                "X-Title": "interview-assist STT bench",
            },
            timeout=self._timeout_s,
        )

    def transcribe(self, audio: np.ndarray, sr: int) -> str:
        assert self._client is not None
        wav_bytes = _float32_to_wav_bytes(audio, sr=sr)
        b64 = base64.b64encode(wav_bytes).decode("ascii")
        # OpenAI's audio chat models (gpt-audio, gpt-audio-mini, gpt-4o-audio-preview)
        # reject `response_format: json_object` (400) and need `modalities: ["text"]`
        # to indicate they should NOT generate audio output. Detect by slug prefix.
        is_openai_audio = self._model_id.startswith("openai/") and "audio" in self._model_id
        payload: dict = {
            "model": self._model_id,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": _OPENROUTER_PROMPT},
                        {"type": "input_audio", "input_audio": {"data": b64, "format": "wav"}},
                    ],
                }
            ],
            "temperature": 0.0,
        }
        if is_openai_audio:
            payload["modalities"] = ["text"]
        else:
            payload["response_format"] = {"type": "json_object"}
        resp = self._client.post("/chat/completions", json=payload)
        if resp.status_code == 404:
            raise RunnerUnavailable(f"OpenRouter returned 404 for model {self._model_id} — model id likely wrong or not exposed")
        if resp.status_code == 401:
            raise RunnerUnavailable("OpenRouter returned 401 — check OPENROUTER_API_KEY")
        resp.raise_for_status()
        data = resp.json()
        try:
            raw = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError) as e:
            raise RuntimeError(f"unexpected OpenRouter response shape: {data}") from e
        # Some models (Nemotron Omni in particular) occasionally return null content
        # — treat that as an empty transcript rather than crashing on .strip() below.
        if raw is None:
            return ""
        return _parse_json_text(raw)

    def teardown(self) -> None:
        if self._client is not None:
            self._client.close()
        self._client = None


# ---------------------------------------------------------------------------
# Hosted: Groq /audio/transcriptions — proper Whisper STT endpoint
# ---------------------------------------------------------------------------


class GroqWhisperRunner:
    """Whisper-large-v3 (and -turbo) hosted on Groq.

    Groq exposes Whisper via the OpenAI-compatible `/audio/transcriptions`
    endpoint — *not* `/chat/completions`. Audio is uploaded as multipart/form-data
    (a real file part), and the response is `{"text": "<transcript>"}`.

    Models known to exist on Groq:
        - whisper-large-v3
        - whisper-large-v3-turbo
        - distil-whisper-large-v3-en
    """

    def __init__(self, model_id: str, api_key: str | None = None,
                 base_url: str | None = None, timeout_s: float = 60.0) -> None:
        self.name = f"groq_{model_id.replace('/', '_').replace('-', '_')}"
        self.label = f"{model_id} (Groq audio/transcriptions)"
        self._model_id = model_id
        self._api_key = api_key or os.environ.get("GROQ_API_KEY", "")
        self._base_url = base_url or os.environ.get("GROQ_BASE_URL", "https://api.groq.com/openai/v1")
        self._timeout_s = timeout_s
        self._client = None

    def setup(self) -> None:
        if not self._api_key:
            raise RunnerUnavailable("GROQ_API_KEY is empty")
        try:
            import httpx
        except ImportError as e:
            raise RunnerUnavailable(f"httpx not importable: {e}") from e
        self._client = httpx.Client(
            base_url=self._base_url,
            headers={"Authorization": f"Bearer {self._api_key}"},
            timeout=self._timeout_s,
        )

    def transcribe(self, audio: np.ndarray, sr: int) -> str:
        assert self._client is not None
        wav_bytes = _float32_to_wav_bytes(audio, sr=sr)
        # multipart/form-data: audio as a file part, model as a form field.
        files = {"file": ("audio.wav", wav_bytes, "audio/wav")}
        data = {
            "model": self._model_id,
            "response_format": "json",
            "temperature": "0",
            "language": "en",
        }
        resp = self._client.post("/audio/transcriptions", files=files, data=data)
        if resp.status_code == 404:
            raise RunnerUnavailable(f"Groq returned 404 for model {self._model_id} — model id likely wrong")
        if resp.status_code == 401:
            raise RunnerUnavailable("Groq returned 401 — check GROQ_API_KEY")
        resp.raise_for_status()
        body = resp.json()
        return (body.get("text") or "").strip()

    def teardown(self) -> None:
        if self._client is not None:
            self._client.close()
        self._client = None


def _parse_json_text(raw: str) -> str:
    """Recover the transcript from an OpenRouter response.

    Models occasionally wrap the JSON in code fences or return plain prose
    despite the system prompt. Try JSON first, fall back to the raw string.
    """
    s = raw.strip()
    # Strip ```json ... ``` fences if present.
    if s.startswith("```"):
        lines = s.splitlines()
        if lines:
            lines = lines[1:]                # drop opening fence
            if lines and lines[-1].strip().startswith("```"):
                lines = lines[:-1]
        s = "\n".join(lines).strip()
    try:
        obj = json.loads(s)
    except json.JSONDecodeError:
        return s
    if isinstance(obj, dict) and isinstance(obj.get("text"), str):
        return obj["text"].strip()
    return s


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def build_runner(spec: dict) -> Runner:
    """Construct a runner from a spec dict.

    Spec format:
        {"kind": "openrouter", "model_id": "google/chirp-3"}
        {"kind": "groq", "model_id": "whisper-large-v3"}
        {"kind": "whisper_hf", "model_id": "openai/whisper-large-v3"}
        {"kind": "faster_whisper", "model_path": "/path/to/model"}
    """
    kind = spec["kind"]
    if kind == "faster_whisper":
        return FasterWhisperRunner(model_path=spec.get("model_path"))
    if kind == "whisper_hf":
        return WhisperHFRunner(model_id=spec["model_id"])
    if kind == "openrouter":
        return OpenRouterAudioRunner(model_id=spec["model_id"])
    if kind == "groq":
        return GroqWhisperRunner(model_id=spec["model_id"])
    raise ValueError(f"unknown runner kind: {kind}")
