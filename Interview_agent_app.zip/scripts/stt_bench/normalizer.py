"""Lightweight text normalizer so WER comparisons are fair across engines.

Different engines emit different casing, punctuation, and number formatting.
Without normalization, "Hello, world." vs "hello world" scores as a 100% WER —
which would make every cloud engine look terrible vs Whisper's clean output.

This is intentionally simpler than Whisper's `EnglishTextNormalizer`. It does:
  - lowercase
  - strip non-alphanumeric punctuation (keep apostrophes inside contractions)
  - collapse whitespace
  - basic digit-to-word conversion is NOT done — we leave numbers as-is and
    accept the small WER penalty when one engine writes "twenty" and another "20"

For deeper normalization, swap in `whisper_normalizer.EnglishTextNormalizer`.
"""

from __future__ import annotations

import re

_PUNCT_RE = re.compile(r"[^\w\s']")
_APOSTROPHE_EDGES_RE = re.compile(r"(?<!\w)'|'(?!\w)")
_WHITESPACE_RE = re.compile(r"\s+")


def normalize(text: str) -> str:
    if not text:
        return ""
    t = text.lower()
    t = _PUNCT_RE.sub(" ", t)          # strip punctuation except apostrophes
    t = _APOSTROPHE_EDGES_RE.sub(" ", t)  # drop stray apostrophes (quoted "'word'")
    t = _WHITESPACE_RE.sub(" ", t).strip()
    return t
