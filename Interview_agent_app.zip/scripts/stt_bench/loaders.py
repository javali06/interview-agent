"""Audio sample loaders for the STT benchmark.

Two sources are supported:

  1. HuggingFace `hf-internal-testing/librispeech_asr_dummy` — small public mirror
     of LibriSpeech test-clean (~73 utterances, no gating, no auth required).
     This is the default and gives us proper ground-truth references for WER.

  2. Local WAV files in --audio-dir, paired with a transcripts.tsv (one
     "<filename>\\t<reference>" per line). Used as a fallback or for custom
     domain audio.

All audio is resampled to mono 16 kHz float32 — every shipped engine assumes that.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass(frozen=True, slots=True)
class AudioSample:
    sample_id: str
    audio: np.ndarray         # mono float32 in [-1, 1] at 16 kHz
    sample_rate: int          # always 16_000 after loading
    reference: str            # ground-truth transcript (already lowercased? no — we normalize at scoring time)
    duration_s: float


def _ensure_mono_16k(audio: np.ndarray, sr: int) -> tuple[np.ndarray, int]:
    """Downmix to mono and resample to 16 kHz. Lazy-imports librosa."""
    if audio.ndim == 2:
        audio = audio.mean(axis=1)
    audio = audio.astype(np.float32)
    if sr != 16_000:
        import librosa  # noqa: local import — heavy
        audio = librosa.resample(audio, orig_sr=sr, target_sr=16_000)
    return audio, 16_000


def load_huggingface(num_samples: int, dataset_name: str = "hf-internal-testing/librispeech_asr_dummy") -> list[AudioSample]:
    """Load N samples from a HuggingFace ASR dataset.

    Default `hf-internal-testing/librispeech_asr_dummy` requires no auth and
    is the canonical demo set used in HF Whisper docs. Returns up to N items
    from the validation split (clean).

    Audio is loaded with `Audio(decode=False)` and decoded manually via
    `soundfile`. The default decoder in recent `datasets` releases is
    `torchcodec`, which depends on `torch` and adds ~2 GB. soundfile is
    already pulled in by librosa, so this avoids the heavyweight dep.
    """
    import io as _io

    import soundfile as sf
    from datasets import Audio, load_dataset  # noqa: local import — heavy

    ds = load_dataset(dataset_name, "clean", split="validation")
    ds = ds.cast_column("audio", Audio(decode=False))
    samples: list[AudioSample] = []
    for i, item in enumerate(ds):
        if i >= num_samples:
            break
        audio_field = item["audio"]
        if isinstance(audio_field, dict) and audio_field.get("bytes"):
            audio_arr, sr = sf.read(_io.BytesIO(audio_field["bytes"]), dtype="float32")
        elif isinstance(audio_field, dict) and audio_field.get("path"):
            audio_arr, sr = sf.read(audio_field["path"], dtype="float32")
        else:
            raise RuntimeError(f"unexpected audio field shape for sample {i}: {audio_field!r}")
        audio_arr = np.asarray(audio_arr, dtype=np.float32)
        audio_arr, sr = _ensure_mono_16k(audio_arr, sr)
        samples.append(
            AudioSample(
                sample_id=str(item.get("id", f"sample_{i:03d}")),
                audio=audio_arr,
                sample_rate=sr,
                reference=str(item["text"]).strip(),
                duration_s=float(audio_arr.size) / sr,
            )
        )
    return samples


def load_local_dir(audio_dir: Path) -> list[AudioSample]:
    """Load WAV files paired with a transcripts.tsv inside `audio_dir`.

    transcripts.tsv format (tab-separated, no header):
        speaker26_000.wav<TAB>and that the words you spoke were a great help

    Files without a matching transcript line are skipped with a warning.
    """
    import soundfile as sf  # noqa: local import

    audio_dir = Path(audio_dir)
    transcripts_path = audio_dir / "transcripts.tsv"
    refs: dict[str, str] = {}
    if transcripts_path.exists():
        with open(transcripts_path, encoding="utf-8") as f:
            for row in csv.reader(f, delimiter="\t"):
                if len(row) >= 2:
                    refs[row[0].strip()] = row[1].strip()

    samples: list[AudioSample] = []
    for wav_path in sorted(audio_dir.glob("*.wav")):
        ref = refs.get(wav_path.name, "")
        if not ref:
            # Reference-less samples are still useful for latency-only stats but
            # WER will be skipped. We include them anyway.
            pass
        audio_arr, sr = sf.read(str(wav_path), dtype="float32")
        audio_arr, sr = _ensure_mono_16k(audio_arr, sr)
        samples.append(
            AudioSample(
                sample_id=wav_path.stem,
                audio=audio_arr,
                sample_rate=sr,
                reference=ref,
                duration_s=float(audio_arr.size) / sr,
            )
        )
    return samples


def load_samples(num_samples: int, audio_dir: Path | None, dataset_name: str | None) -> list[AudioSample]:
    """Resolve the dataset source: explicit local dir > HuggingFace > built-in fixture."""
    if audio_dir is not None:
        return load_local_dir(audio_dir)[:num_samples]
    try:
        return load_huggingface(num_samples, dataset_name or "hf-internal-testing/librispeech_asr_dummy")
    except Exception as e:
        # Last-ditch fallback: the single WAV we already have in tests/fixtures.
        # No reference text available — WER can't be computed, but latency still works.
        fixture = Path(__file__).resolve().parents[2] / "tests" / "fixtures"
        if fixture.exists():
            print(f"[loader] HuggingFace load failed ({e!r}); falling back to {fixture}")
            return load_local_dir(fixture)[:num_samples]
        raise
