"""Report writers — CSV (per-utterance), CSV (per-model), Markdown rollup."""

from __future__ import annotations

import csv
import dataclasses
import json
from pathlib import Path
from typing import Iterable

from scripts.stt_bench.metrics import ModelSummary, UtteranceResult


def write_raw_jsonl(path: Path, results: Iterable[UtteranceResult]) -> None:
    """Append-only JSONL of every per-utterance result. Survives mid-run crashes."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        for r in results:
            f.write(json.dumps(dataclasses.asdict(r), ensure_ascii=False) + "\n")


def write_per_utterance_csv(path: Path, results: list[UtteranceResult]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow([
            "model", "sample_id", "audio_seconds", "latency_ms", "rtf",
            "wer", "cer", "mer", "wil", "cold_start", "error",
            "reference", "hypothesis",
        ])
        for r in results:
            w.writerow([
                r.model, r.sample_id, f"{r.audio_seconds:.3f}",
                f"{r.latency_ms:.1f}", f"{r.rtf:.3f}",
                f"{r.wer:.4f}", f"{r.cer:.4f}", f"{r.mer:.4f}", f"{r.wil:.4f}",
                int(r.cold_start), (r.error or ""),
                r.reference, r.hypothesis,
            ])


def write_summary_csv(path: Path, summaries: list[ModelSummary]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow([
            "model", "n_total", "n_ok", "n_failed", "failure_rate",
            "wer_micro", "wer_macro", "cer_micro", "cer_macro",
            "mer_macro", "wil_macro",
            "cold_start_ms", "latency_warm_mean_ms", "latency_warm_median_ms",
            "latency_warm_p95_ms", "latency_warm_stdev_ms",
            "rtf_mean", "audio_seconds_total", "wall_seconds_total",
            "length_ratio_mean", "notes",
        ])
        for s in summaries:
            w.writerow([
                s.model, s.n_total, s.n_ok, s.n_failed, f"{s.failure_rate:.3f}",
                f"{s.wer_micro:.4f}", f"{s.wer_macro:.4f}",
                f"{s.cer_micro:.4f}", f"{s.cer_macro:.4f}",
                f"{s.mer_macro:.4f}", f"{s.wil_macro:.4f}",
                f"{s.cold_start_ms:.1f}", f"{s.latency_warm_mean_ms:.1f}",
                f"{s.latency_warm_median_ms:.1f}", f"{s.latency_warm_p95_ms:.1f}",
                f"{s.latency_warm_stdev_ms:.1f}",
                f"{s.rtf_mean:.3f}", f"{s.audio_seconds_total:.2f}",
                f"{s.wall_seconds_total:.2f}",
                f"{s.length_ratio_mean:.3f}",
                "; ".join(s.notes),
            ])


def _fmt_pct(x: float) -> str:
    return f"{x * 100:.2f}%"


def _fmt_ms(x: float) -> str:
    if x >= 1000:
        return f"{x / 1000:.2f}s"
    return f"{x:.0f}ms"


def write_markdown_report(
    path: Path,
    summaries: list[ModelSummary],
    skipped: list[tuple[str, str]],
    dataset_info: dict,
) -> None:
    """Render the leaderboard + per-model breakdown.

    `skipped` is a list of (model_label, reason) for runners that never ran —
    listed in their own section so the reader sees what was attempted.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    lines: list[str] = []
    lines.append("# STT Benchmark Report")
    lines.append("")
    lines.append("## Dataset")
    lines.append(f"- Source: `{dataset_info.get('source', 'unknown')}`")
    lines.append(f"- Utterances: **{dataset_info.get('n_samples', 0)}**")
    lines.append(f"- Total audio: **{dataset_info.get('audio_seconds_total', 0):.1f}s**")
    lines.append(f"- Generated: {dataset_info.get('timestamp', '')}")
    lines.append("")

    # ---- Leaderboard: sorted by WER (micro) ascending ----
    by_wer = sorted([s for s in summaries if s.n_ok > 0], key=lambda s: s.wer_micro)
    lines.append("## Leaderboard — Accuracy (lower WER is better)")
    lines.append("")
    lines.append("| Rank | Model | WER (micro) | CER (micro) | WER (macro) | Failures |")
    lines.append("|---|---|---|---|---|---|")
    for i, s in enumerate(by_wer, 1):
        lines.append(
            f"| {i} | {s.model} | {_fmt_pct(s.wer_micro)} | {_fmt_pct(s.cer_micro)} | "
            f"{_fmt_pct(s.wer_macro)} | {s.n_failed}/{s.n_total} |"
        )
    lines.append("")

    # ---- Leaderboard: sorted by warm-mean latency ----
    by_lat = sorted([s for s in summaries if s.n_ok > 0], key=lambda s: s.latency_warm_mean_ms)
    lines.append("## Leaderboard — Latency (lower is better)")
    lines.append("")
    lines.append("| Rank | Model | Warm mean | Warm p95 | Warm median | Cold start | RTF |")
    lines.append("|---|---|---|---|---|---|---|")
    for i, s in enumerate(by_lat, 1):
        lines.append(
            f"| {i} | {s.model} | {_fmt_ms(s.latency_warm_mean_ms)} | "
            f"{_fmt_ms(s.latency_warm_p95_ms)} | {_fmt_ms(s.latency_warm_median_ms)} | "
            f"{_fmt_ms(s.cold_start_ms)} | {s.rtf_mean:.2f} |"
        )
    lines.append("")
    lines.append("> RTF = real-time factor = processing_time / audio_duration. "
                 "Values <1.0 are faster than realtime, which is the threshold for live streaming.")
    lines.append("")

    # ---- Combined summary ----
    lines.append("## Full Summary")
    lines.append("")
    lines.append("| Model | n_ok | WER | CER | MER | WIL | Cold | Warm mean | p95 | RTF | Length ratio |")
    lines.append("|---|---|---|---|---|---|---|---|---|---|---|")
    for s in summaries:
        if s.n_ok == 0:
            lines.append(
                f"| {s.model} | 0/{s.n_total} | — | — | — | — | — | — | — | — | — |"
            )
            continue
        lines.append(
            f"| {s.model} | {s.n_ok}/{s.n_total} | {_fmt_pct(s.wer_micro)} | "
            f"{_fmt_pct(s.cer_micro)} | {_fmt_pct(s.mer_macro)} | {_fmt_pct(s.wil_macro)} | "
            f"{_fmt_ms(s.cold_start_ms)} | {_fmt_ms(s.latency_warm_mean_ms)} | "
            f"{_fmt_ms(s.latency_warm_p95_ms)} | {s.rtf_mean:.2f} | "
            f"{s.length_ratio_mean:.2f} |"
        )
    lines.append("")

    # ---- Skipped runners ----
    if skipped:
        lines.append("## Skipped Models")
        lines.append("")
        for model, reason in skipped:
            lines.append(f"- **{model}** — {reason}")
        lines.append("")

    # ---- Notes ----
    notes = [(s.model, n) for s in summaries for n in s.notes]
    if notes:
        lines.append("## Notes")
        lines.append("")
        for model, n in notes:
            lines.append(f"- **{model}**: {n}")
        lines.append("")

    # ---- Glossary ----
    lines.append("## Metrics glossary")
    lines.append("")
    lines.append("- **WER (Word Error Rate)** — fraction of reference words that were substituted, deleted, or inserted. Lower is better.")
    lines.append("- **CER (Character Error Rate)** — same, at character level. More tolerant of minor word boundary mistakes.")
    lines.append("- **MER (Match Error Rate)** — penalises both insertions and deletions; useful when output length varies.")
    lines.append("- **WIL (Word Information Lost)** — captures information loss; higher = more meaning lost.")
    lines.append("- **micro vs macro** — *micro* concatenates all utterances and computes once (longer utterances weigh more); *macro* averages per-utterance scores (treats each utterance equally).")
    lines.append("- **Cold start** — time of the very first call, which includes model load + warmup.")
    lines.append("- **Warm latency** — wall-clock from submit → transcript ready, excluding cold-start.")
    lines.append("- **RTF (Real-Time Factor)** — processing_time ÷ audio_duration. <1.0 = faster than realtime; required for live captions.")
    lines.append("- **Length ratio** — predicted_word_count ÷ reference_word_count. ~1.0 is healthy; >1.3 suggests hallucination, <0.7 suggests truncation.")
    lines.append("")

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
