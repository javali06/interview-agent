"""STT benchmarking utilities — see ../benchmark_stt.py for the CLI entry point."""
