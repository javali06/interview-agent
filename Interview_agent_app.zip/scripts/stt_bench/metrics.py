"""Accuracy + latency aggregation for STT benchmark runs.

Per-utterance metrics are computed on normalized text (see normalizer.py).
Aggregate metrics are computed two ways:
  - micro: concatenate all hypotheses and references, compute WER once. This
           weighs longer utterances more — closer to "what fraction of words
           did we get wrong overall."
  - macro: per-utterance WER averaged. Treats every utterance equally. Useful
           when utterance lengths vary widely.

Both are reported. Reviewers usually quote the micro number.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from statistics import mean, median, stdev
from typing import Iterable

from scripts.stt_bench.normalizer import normalize


@dataclass(frozen=True, slots=True)
class UtteranceResult:
    model: str
    sample_id: str
    reference: str
    hypothesis: str
    audio_seconds: float
    latency_ms: float          # wall-clock from submit to full transcript returned
    cold_start: bool           # True for the model's very first call (loading + warmup)
    error: str | None = None   # populated if the call failed; other fields are zero/empty

    # Computed lazily; populated by `score()` below to avoid double work.
    wer: float = 0.0
    cer: float = 0.0
    mer: float = 0.0
    wil: float = 0.0
    rtf: float = 0.0           # processing_time / audio_duration. <1 == faster than realtime.


def score(result: UtteranceResult) -> UtteranceResult:
    """Compute WER/CER/MER/WIL + RTF for a single utterance result."""
    if result.error:
        return result
    ref_n = normalize(result.reference)
    hyp_n = normalize(result.hypothesis)
    if not ref_n:
        # Reference is empty after normalization — can't compute WER meaningfully.
        return result
    import jiwer  # lazy import — bench extras may not be installed at module load time
    # jiwer raises if hypothesis is empty after normalization; guard with a space.
    hyp_for_jiwer = hyp_n if hyp_n else " "
    wer_val = jiwer.wer(ref_n, hyp_for_jiwer)
    cer_val = jiwer.cer(ref_n, hyp_for_jiwer)
    mer_val = jiwer.mer(ref_n, hyp_for_jiwer)
    wil_val = jiwer.wil(ref_n, hyp_for_jiwer)
    rtf_val = (result.latency_ms / 1000.0) / result.audio_seconds if result.audio_seconds > 0 else 0.0
    return UtteranceResult(
        model=result.model,
        sample_id=result.sample_id,
        reference=result.reference,
        hypothesis=result.hypothesis,
        audio_seconds=result.audio_seconds,
        latency_ms=result.latency_ms,
        cold_start=result.cold_start,
        error=None,
        wer=float(wer_val),
        cer=float(cer_val),
        mer=float(mer_val),
        wil=float(wil_val),
        rtf=float(rtf_val),
    )


@dataclass(slots=True)
class ModelSummary:
    model: str
    n_total: int
    n_ok: int
    n_failed: int

    # Accuracy — micro (corpus-level) and macro (per-utterance mean)
    wer_micro: float = 0.0
    wer_macro: float = 0.0
    cer_micro: float = 0.0
    cer_macro: float = 0.0
    mer_macro: float = 0.0
    wil_macro: float = 0.0

    # Latency
    cold_start_ms: float = 0.0
    latency_warm_mean_ms: float = 0.0
    latency_warm_median_ms: float = 0.0
    latency_warm_p95_ms: float = 0.0
    latency_warm_stdev_ms: float = 0.0

    # Throughput
    rtf_mean: float = 0.0      # < 1.0 == faster than realtime
    audio_seconds_total: float = 0.0
    wall_seconds_total: float = 0.0  # excludes cold start

    # Output sanity
    length_ratio_mean: float = 0.0   # predicted_words / reference_words (1.0 == match)
    failure_rate: float = 0.0
    notes: list[str] = field(default_factory=list)


def _percentile(values: list[float], pct: float) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    k = (len(s) - 1) * pct
    lo = int(k)
    hi = min(lo + 1, len(s) - 1)
    frac = k - lo
    return s[lo] + (s[hi] - s[lo]) * frac


def summarize(model: str, results: Iterable[UtteranceResult]) -> ModelSummary:
    rs = list(results)
    summary = ModelSummary(model=model, n_total=len(rs), n_ok=0, n_failed=0)
    if not rs:
        return summary

    ok = [r for r in rs if r.error is None]
    failed = [r for r in rs if r.error is not None]
    summary.n_ok = len(ok)
    summary.n_failed = len(failed)
    summary.failure_rate = len(failed) / len(rs)

    if failed:
        # Surface the first error verbatim — usually it's the same root cause for all.
        summary.notes.append(f"{len(failed)} call(s) failed; first error: {failed[0].error}")

    if not ok:
        return summary

    # ---- Latency: split cold-start from warm calls ----
    cold = [r for r in ok if r.cold_start]
    warm = [r for r in ok if not r.cold_start]
    summary.cold_start_ms = cold[0].latency_ms if cold else 0.0
    warm_lat = [r.latency_ms for r in warm] or [r.latency_ms for r in ok]
    summary.latency_warm_mean_ms = float(mean(warm_lat))
    summary.latency_warm_median_ms = float(median(warm_lat))
    summary.latency_warm_p95_ms = _percentile(warm_lat, 0.95)
    summary.latency_warm_stdev_ms = float(stdev(warm_lat)) if len(warm_lat) >= 2 else 0.0

    # ---- Throughput ----
    summary.audio_seconds_total = sum(r.audio_seconds for r in ok)
    summary.wall_seconds_total = sum(r.latency_ms for r in warm) / 1000.0
    if warm:
        summary.rtf_mean = float(mean(r.rtf for r in warm))
    else:
        summary.rtf_mean = float(mean(r.rtf for r in ok))

    # ---- Accuracy ----
    refs = [normalize(r.reference) for r in ok]
    hyps = [normalize(r.hypothesis) or " " for r in ok]
    # Filter out pairs where reference is empty (can't WER against nothing).
    pairs = [(rf, hp) for rf, hp in zip(refs, hyps) if rf]
    if pairs:
        import jiwer  # lazy import
        ref_list, hyp_list = zip(*pairs)
        summary.wer_micro = float(jiwer.wer(list(ref_list), list(hyp_list)))
        summary.cer_micro = float(jiwer.cer(list(ref_list), list(hyp_list)))
    summary.wer_macro = float(mean(r.wer for r in ok))
    summary.cer_macro = float(mean(r.cer for r in ok))
    summary.mer_macro = float(mean(r.mer for r in ok))
    summary.wil_macro = float(mean(r.wil for r in ok))

    # ---- Output sanity ----
    ratios = []
    for r in ok:
        ref_w = len(normalize(r.reference).split())
        hyp_w = len(normalize(r.hypothesis).split())
        if ref_w > 0:
            ratios.append(hyp_w / ref_w)
    summary.length_ratio_mean = float(mean(ratios)) if ratios else 0.0

    return summary
