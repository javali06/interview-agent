"""STT benchmarking script — runs identical audio through 6 STT backends and
emits CSV + Markdown reports of accuracy, latency, and throughput.

Usage (from project root):

    # Install bench-only deps once:
    uv pip install -e ".[bench]"

    # Run with defaults (30 utterances from LibriSpeech dummy on HuggingFace):
    python scripts/benchmark_stt.py

    # Use your own audio directory (must contain transcripts.tsv):
    python scripts/benchmark_stt.py --audio-dir path/to/wavs

Models benchmarked:

    1. Current STT — faster-whisper at $WHISPER_MODEL_PATH                       (LOCAL)
                     (default: Systran/faster-distil-whisper-large-v3)
    2. google/gemini-2.5-flash         (substitute for Chirp 3, on OpenRouter)
    3. whisper-large-v3-turbo                                                    (Groq)
    4. whisper-large-v3                                                          (Groq)
    5. nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free                        (OpenRouter)
    6. google/gemini-2.5-flash-lite                                              (OpenRouter)

Outputs:

    bench_results/stt_<UTC-timestamp>/
        raw.jsonl          — per-utterance results (append-only; survives crashes)
        per_utterance.csv  — full per-utterance grid
        summary.csv        — one row per model
        report.md          — human-readable rollup with leaderboards

Skip behavior: any runner whose prerequisites are missing (no API key, no model
path, OpenRouter 404 on first call, missing optional package) is recorded in a
"Skipped Models" section with the reason. The rest of the bench continues.
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

# Make `scripts.stt_bench.*` importable when running `python scripts/benchmark_stt.py`
# from the project root.
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from scripts.stt_bench.loaders import AudioSample, load_samples
from scripts.stt_bench.metrics import UtteranceResult, score, summarize
from scripts.stt_bench.report import (
    write_markdown_report,
    write_per_utterance_csv,
    write_raw_jsonl,
    write_summary_csv,
)
from scripts.stt_bench.runners import (
    FasterWhisperRunner,
    GroqWhisperRunner,
    OpenRouterAudioRunner,
    Runner,
    RunnerUnavailable,
)


# Mirrors the default in scripts/run_live.sh — the HF model id passed to
# faster-whisper, which resolves it from the local HF cache or downloads once.
DEFAULT_LOCAL_WHISPER_MODEL = "Systran/faster-distil-whisper-large-v3"


def _load_dotenv_if_present() -> None:
    """Load .env from the project root so OPENROUTER_API_KEY is picked up."""
    try:
        from dotenv import load_dotenv
        load_dotenv(_PROJECT_ROOT / ".env")
    except ImportError:
        pass


def _build_runner_lineup(args: argparse.Namespace) -> list[tuple[str, Runner]]:
    """Build (display_name, runner) pairs for every model the user asked for.

    Returning a list (not dict) preserves the order so the report mirrors the
    requested ordering (Model 1 → Model 6).

    Model 1 is the only LOCAL runner — matches the production stt_service config
    (faster-whisper at WHISPER_MODEL_PATH). Models 2–6 all route through OpenRouter.
    """
    lineup: list[tuple[str, Runner]] = []

    # Model 1: current STT — faster-whisper, local
    local_path = os.environ.get("WHISPER_MODEL_PATH") or DEFAULT_LOCAL_WHISPER_MODEL
    lineup.append((
        f"Model 1: current STT (faster-whisper, {local_path})",
        FasterWhisperRunner(model_path=local_path),
    ))

    # Models 2–6: hosted.
    #
    # Routing notes (verified 2026-05-08):
    #   Model 2: google/chirp-3            -> not on OpenRouter at all (it's a GCP STT v2 model);
    #                                         substituted with google/gemini-2.5-flash on OpenRouter
    #                                         (Google's flagship audio-capable chat model).
    #   Model 3: whisper-large-v3-turbo    -> NOT on OpenRouter (Whisper isn't a chat model);
    #                                         routed via Groq's /audio/transcriptions endpoint.
    #   Model 4: whisper-large-v3          -> same — routed via Groq.
    #   Model 5/6: stay on OpenRouter.
    lineup.append(("Model 2: google/gemini-2.5-flash (substitute for Chirp 3)",
                   OpenRouterAudioRunner(model_id="google/gemini-2.5-flash")))
    lineup.append(("Model 3: whisper-large-v3-turbo (Groq)",
                   GroqWhisperRunner(model_id="whisper-large-v3-turbo")))
    lineup.append(("Model 4: whisper-large-v3 (Groq)",
                   GroqWhisperRunner(model_id="whisper-large-v3")))
    lineup.append(("Model 5: nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free",
                   OpenRouterAudioRunner(model_id="nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free")))
    lineup.append(("Model 6: google/gemini-2.5-flash-lite",
                   OpenRouterAudioRunner(model_id="google/gemini-2.5-flash-lite")))

    return lineup


def _run_single_model(
    display_name: str,
    runner: Runner,
    samples: list[AudioSample],
    raw_path: Path,
) -> tuple[list[UtteranceResult], str | None]:
    """Run one runner across all samples. Returns (results, skip_reason)."""
    print(f"\n[{display_name}]")
    print(f"  -> setup: {runner.label}")

    # ---- Setup (cold-start timing happens on first transcribe, not here) ----
    t0 = time.perf_counter()
    try:
        runner.setup()
    except RunnerUnavailable as e:
        print(f"  [SKIP] {e}")
        return [], str(e)
    except Exception as e:
        print(f"  [SKIP] setup error: {e!r}")
        return [], f"setup error: {e!r}"
    setup_ms = (time.perf_counter() - t0) * 1000
    print(f"  -> setup done in {setup_ms:.0f}ms - running {len(samples)} utterance(s)")

    # ---- Run all samples ----
    results: list[UtteranceResult] = []
    is_first = True
    for i, s in enumerate(samples):
        t = time.perf_counter()
        err: str | None = None
        text = ""
        try:
            text = runner.transcribe(s.audio, s.sample_rate)
        except RunnerUnavailable as e:
            # First-call discovery that the model isn't available — abort this runner
            # cleanly and mark all already-run results as kept; remaining as skipped.
            print(f"  [SKIP] runner unavailable mid-run: {e}")
            runner.teardown()
            return results, str(e)
        except Exception as e:
            err = f"{type(e).__name__}: {e}"
        latency_ms = (time.perf_counter() - t) * 1000
        # First successful call doubles as cold-start; if first call errored, the
        # next one carries cold_start=True so we still capture init cost somewhere.
        cold = is_first and err is None
        if err is None:
            is_first = False
        ur = UtteranceResult(
            model=runner.name,
            sample_id=s.sample_id,
            reference=s.reference,
            hypothesis=text,
            audio_seconds=s.duration_s,
            latency_ms=latency_ms,
            cold_start=cold,
            error=err,
        )
        ur = score(ur)
        results.append(ur)
        # Stream-write so we don't lose progress on crash.
        write_raw_jsonl(raw_path, [ur])
        marker = "OK  " if err is None else "FAIL"
        wer_str = f"WER={ur.wer * 100:.1f}%" if err is None and ur.reference else "WER=n/a"
        cold_str = " (cold)" if cold else ""
        err_str = f" err={err}" if err else ""
        print(f"  {marker} {i + 1:>3}/{len(samples)} {s.sample_id}  "
              f"{latency_ms:6.0f}ms  rtf={ur.rtf:5.2f}  {wer_str}{cold_str}{err_str}")

    runner.teardown()
    return results, None


def main() -> int:
    parser = argparse.ArgumentParser(description="STT benchmark — multi-model accuracy + latency.")
    parser.add_argument("--num-samples", type=int, default=30,
                        help="Number of utterances to run through each model (default: 30).")
    parser.add_argument("--audio-dir", type=Path, default=None,
                        help="Optional local directory of WAVs + transcripts.tsv to use instead of HuggingFace.")
    parser.add_argument("--dataset-name", type=str, default=None,
                        help="HuggingFace dataset id (default: hf-internal-testing/librispeech_asr_dummy).")
    parser.add_argument("--chirp-model-id", type=str, default="google/chirp-3",
                        help="OpenRouter model id for Chirp 3. Override if OpenRouter renames it (default: google/chirp-3).")
    parser.add_argument("--output-dir", type=Path, default=None,
                        help="Where to write reports (default: bench_results/stt_<UTC-timestamp>/).")
    parser.add_argument("--only", type=str, default=None,
                        help="Comma-separated substrings — only runners whose name contains one are run. e.g. --only chirp,gemini")
    args = parser.parse_args()

    _load_dotenv_if_present()

    # ---- Output dir ----
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    out_dir = args.output_dir or (_PROJECT_ROOT / "bench_results" / f"stt_{ts}")
    out_dir.mkdir(parents=True, exist_ok=True)
    raw_path = out_dir / "raw.jsonl"
    print(f"Output directory: {out_dir}")

    # ---- Load audio ----
    print(f"\nLoading {args.num_samples} sample(s) "
          f"from {'local dir ' + str(args.audio_dir) if args.audio_dir else 'HuggingFace'}...")
    samples = load_samples(
        num_samples=args.num_samples,
        audio_dir=args.audio_dir,
        dataset_name=args.dataset_name,
    )
    if not samples:
        print("ERROR: no samples loaded. Aborting.", file=sys.stderr)
        return 2
    audio_total = sum(s.duration_s for s in samples)
    print(f"  Loaded {len(samples)} sample(s), {audio_total:.1f}s total audio")

    # ---- Build & filter the lineup ----
    lineup = _build_runner_lineup(args)
    if args.only:
        wanted = [w.strip().lower() for w in args.only.split(",") if w.strip()]
        lineup = [(d, r) for d, r in lineup
                  if any(w in d.lower() or w in r.name.lower() for w in wanted)]
        print(f"  --only filter: {len(lineup)} runner(s) selected")

    # ---- Run each model ----
    all_results: list[UtteranceResult] = []
    skipped: list[tuple[str, str]] = []
    summaries = []
    for display_name, runner in lineup:
        results, skip_reason = _run_single_model(display_name, runner, samples, raw_path)
        if skip_reason and not results:
            skipped.append((display_name, skip_reason))
            continue
        if skip_reason and results:
            # Partial run — still useful, but flag it.
            skipped.append((display_name, f"partial run aborted: {skip_reason}"))
        all_results.extend(results)
        s = summarize(runner.name, results)
        summaries.append(s)

    # ---- Write reports ----
    print("\nWriting reports...")
    write_per_utterance_csv(out_dir / "per_utterance.csv", all_results)
    write_summary_csv(out_dir / "summary.csv", summaries)
    write_markdown_report(
        out_dir / "report.md",
        summaries=summaries,
        skipped=skipped,
        dataset_info={
            "source": (str(args.audio_dir) if args.audio_dir
                       else (args.dataset_name or "hf-internal-testing/librispeech_asr_dummy")),
            "n_samples": len(samples),
            "audio_seconds_total": audio_total,
            "timestamp": ts,
        },
    )
    print(f"  -> {out_dir / 'report.md'}")
    print(f"  -> {out_dir / 'summary.csv'}")
    print(f"  -> {out_dir / 'per_utterance.csv'}")
    print(f"  -> {out_dir / 'raw.jsonl'}")

    # ---- Console rollup ----
    print("\n=== SUMMARY ===")
    print(f"{'Model':<55} {'n_ok':>7} {'WER':>8} {'CER':>8} {'Warm':>10} {'p95':>10} {'RTF':>6}")
    for s in summaries:
        wer = f"{s.wer_micro * 100:.2f}%" if s.n_ok else "—"
        cer = f"{s.cer_micro * 100:.2f}%" if s.n_ok else "—"
        warm = f"{s.latency_warm_mean_ms:.0f}ms" if s.n_ok else "—"
        p95 = f"{s.latency_warm_p95_ms:.0f}ms" if s.n_ok else "—"
        rtf = f"{s.rtf_mean:.2f}" if s.n_ok else "—"
        print(f"{s.model:<55} {s.n_ok:>3}/{s.n_total:<3} {wer:>8} {cer:>8} {warm:>10} {p95:>10} {rtf:>6}")
    if skipped:
        print(f"\nSkipped: {len(skipped)} model(s) — see report.md")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
