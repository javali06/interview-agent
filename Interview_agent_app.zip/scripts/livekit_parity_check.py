"""Parity check for the media transport (Phase 1F): a bot candidate takes a
real interview end to end and reports what a reviewer would otherwise judge by
ear. Run it once with the shards on the WebSocket path and once with
MEDIA_TRANSPORT=livekit, against the same kind of interview, and compare.

It behaves like the candidate page (ui/web/src/lib/candidateEngine.ts):
  * LiveKit offered by /session-info → POST /api/candidate/{token}/start with a
    tab id, join the room with the token it returns, publish its mic, listen to
    the AI's voice, and exchange every control message over the room's data
    channel ("attach", acks, "end") — no WebSocket at all (Phase 2);
  * otherwise → /ws/candidate with a tab id and {"type":"start"}, mic and
    control over the WebSocket, as before;
  * acks each AI utterance the way the page does on that transport.

It answers with real speech (Azure TTS), so speech-to-text is exercised for
real, and measures:
  * transcription: how many of the words it said the server transcribed;
  * response time: candidate stops talking -> candidate hears the AI;
  * the goodbye: was the last utterance heard out before the session ended;
  * server recording: did the LiveKit egress file land in Azure (LiveKit only).

Run inside the session image on the stack's network (it has livekit + the
Azure Speech SDK), with the stack's env file for the keys:

  docker run --rm --network <net> --env-file deploy/local/.env \\
      -e PYTHONPATH=/app -v "$PWD/scripts:/s" --entrypoint python \\
      interview-agent-session:local /s/livekit_parity_check.py <token>
"""
from __future__ import annotations

import argparse
import asyncio
import json
import math
import os
import re
import statistics
import struct
import time
import urllib.request
import uuid

import websockets

ANSWERS = [
    "Hi, thanks for having me. I'm doing well and I'm ready to start.",
    "In my last project I built a retrieval pipeline that indexed product manuals "
    "and answered support questions with citations.",
    "The hardest part was keeping answers grounded, so we added a reranker and "
    "refused to answer when no passage scored above a threshold.",
    "I would cache embeddings, batch the requests, and put a queue in front of "
    "the model so traffic spikes don't time out.",
    "We measured quality with a labelled test set and tracked precision and "
    "recall every release.",
    "No further questions from my side, thank you for your time.",
]

RATE = 16000
FRAME_BYTES = 640          # 20 ms of PCM16 mono, what the page's worklet sends
LOUD_RMS = 328             # ~-40 dBFS, the page's playout threshold
QUIET_MS = 600             # page: ack after this much quiet following audio_end


def rms(pcm: bytes) -> float:
    n = len(pcm) // 2
    if not n:
        return 0.0
    s = struct.unpack("<%dh" % n, pcm[: n * 2])
    return math.sqrt(sum(x * x for x in s) / n)


def words(text: str) -> list[str]:
    return re.findall(r"[a-z']+", text.lower())


def synthesize(texts: list[str]) -> list[bytes]:
    import azure.cognitiveservices.speech as speechsdk
    first = (os.environ.get("AZURE_SPEECH_KEYS") or os.environ.get("AZURE_SPEECH_KEY") or "").split(",")[0]
    key, _, region = first.strip().partition(":")
    region = region or os.environ.get("AZURE_SPEECH_REGION", "eastus")
    cfg = speechsdk.SpeechConfig(subscription=key, region=region)
    cfg.set_speech_synthesis_output_format(speechsdk.SpeechSynthesisOutputFormat.Raw16Khz16BitMonoPcm)
    cfg.speech_synthesis_voice_name = "en-US-GuyNeural"
    synth = speechsdk.SpeechSynthesizer(speech_config=cfg, audio_config=None)
    out = []
    for t in texts:
        res = synth.speak_text_async(t).get()
        if res.reason != speechsdk.ResultReason.SynthesizingAudioCompleted:
            raise RuntimeError(f"TTS failed: {res.reason}")
        out.append(bytes(res.audio_data))
    return out


class Bot:
    def __init__(self, gateway: str, token: str, speech: list[bytes], max_s: float):
        self.gw = gateway.rstrip("/")
        self.token = token
        self.speech = speech
        self.max_s = max_s
        self.t0 = time.monotonic()

        self.ws = None
        self.client = f"bot-{uuid.uuid4().hex[:8]}"
        self.room = None
        self.mic = None
        self.room_mode = False          # control over the room's data channel
        self.lk_live = False            # AI voice over LiveKit
        self.transport = "websocket"
        self.ws_frames = 0              # anything at all over a WebSocket

        self.speak_buf = bytearray()
        self.answer_i = 0
        self.speech_end_at: float | None = None
        self.said: list[str] = []
        self.heard_text: list[list[str]] = []   # stt_final per answer

        # AI audio, as the page experiences it
        self.ai_pending = 0
        self.utter_start = 0.0
        self.last_loud = 0.0
        self.ws_utter = bytearray()
        self.ws_tail = 0.0                      # emulated playback clock (WS path)
        self.ack_chain: asyncio.Future | None = None
        self.last_ack_at = 0.0
        self.acks: list[str] = []
        self.latencies: list[float] = []
        self.ai_spoke_since_answer = True

        self.ended_at: float | None = None
        self.goodbye_acked_before_end = None
        self.done = asyncio.Event()
        self.start_body: dict = {}
        self.rejoins = 0                # the AI left without a goodbye; we came back
        self.first_ai_at: float | None = None   # start -> the greeting begins
        self.timed_out = False
        self.quiet = False              # the load test runs many: no per-bot chatter

    def now(self) -> float:
        return time.monotonic()

    # ── setup ──
    async def run(self) -> dict:
        info = json.load(urllib.request.urlopen(f"{self.gw}/session-info?token={self.token}"))
        start = {"client": self.client, "visual_mode": "minimal",
                 "candidate": {"name": "Parity Bot", "role": "x"}}
        self.start_body = start
        tasks = []
        joined = False
        if (info.get("livekit") or {}).get("enabled"):
            res = await self.post_start()
            if res.get("transport") == "livekit":
                await self.join_room(res["url"], res["token"])
                joined = True
        if not joined:
            ws_url = self.gw.replace("http", "ws", 1)
            self.ws = await websockets.connect(
                f"{ws_url}/ws/candidate/{uuid.uuid4()}?token={self.token}&client={self.client}",
                max_size=None)
            await self.ws.send(json.dumps({"type": "start", **start}))
            tasks.append(asyncio.ensure_future(self.ws_reader()))
        tasks += [asyncio.ensure_future(self.mic_pump()), asyncio.ensure_future(self.turn_taker())]
        try:
            await asyncio.wait_for(self.done.wait(), self.max_s)
        except asyncio.TimeoutError:
            self.timed_out = True
            if not self.quiet:
                print("!! interview did not end within", self.max_s, "s")
            # End it, or it keeps running (and costing) on the server after we go.
            try:
                await self.send_control({"type": "end"})
                await asyncio.wait_for(self.done.wait(), 15)
            except Exception:
                pass
        for t in tasks:
            t.cancel()
        if self.room:
            await self.room.disconnect()
        if self.ws is not None:
            try:
                await self.ws.close()
            except Exception:
                pass
        return self.report()

    async def post_start(self) -> dict:
        req = urllib.request.Request(f"{self.gw}/api/candidate/{self.token}/start",
                                     data=json.dumps(self.start_body).encode(), method="POST",
                                     headers={"content-type": "application/json"})
        return await asyncio.to_thread(lambda: json.load(urllib.request.urlopen(req)))

    async def on_agent_left(self):
        # Like the page: a clean end sends session_end first. Otherwise the AI's
        # server went away (hand-off on drain, crash): come back, and another
        # replica resumes the interview from its checkpoint.
        await asyncio.sleep(3)
        if self.done.is_set():
            return
        for _ in range(20):
            try:
                res = await self.post_start()
            except Exception:
                res = {}
            if res.get("transport") == "livekit":
                old = self.room
                await self.join_room(res["url"], res["token"])
                try:
                    await old.disconnect()
                except Exception:
                    pass
                self.rejoins += 1
                self.ai_pending, self.last_ack_at, self.ai_spoke_since_answer = 0, 0.0, True
                if not self.quiet:
                    print(f"-- rejoined after the AI left (#{self.rejoins})", flush=True)
                return
            await asyncio.sleep(3)

    async def join_room(self, url: str, token: str):
        from livekit import rtc
        from engine.orchestrator.livekit.transport import CONTROL_TOPIC, ControlReassembler
        self.room = rtc.Room()
        self.mic = rtc.AudioSource(RATE, 1)
        reassembler = ControlReassembler()

        def on_track(track, pub, participant):
            if isinstance(track, rtc.RemoteAudioTrack):
                asyncio.ensure_future(self.listen_lk(track))

        def on_data(packet):
            if packet.topic != CONTROL_TOPIC:
                return
            whole = reassembler.feed(bytes(packet.data).decode())
            if whole is not None:
                asyncio.ensure_future(self.on_control(json.loads(whole)))
        room = self.room

        def on_left(participant):
            if participant.identity == "agent" and self.room is room:
                asyncio.ensure_future(self.on_agent_left())
        self.room.on("track_subscribed", on_track)
        self.room.on("data_received", on_data)
        self.room.on("participant_disconnected", on_left)
        await self.room.connect(url, token)
        await self.room.local_participant.publish_track(
            rtc.LocalAudioTrack.create_audio_track("mic", self.mic), rtc.TrackPublishOptions())
        self.room_mode = self.lk_live = True
        self.transport = "livekit"
        await self.send_control({"type": "attach"})

    async def send_control(self, msg: dict):
        if self.room_mode:
            from engine.orchestrator.livekit.transport import CONTROL_TOPIC, control_packets
            for p in control_packets(json.dumps(msg)):
                await self.room.local_participant.publish_data(p.encode(), reliable=True, topic=CONTROL_TOPIC)
        elif self.ws is not None:
            await self.ws.send(json.dumps(msg))

    async def listen_lk(self, track):
        from livekit import rtc
        async for ev in rtc.AudioStream(track, sample_rate=RATE, num_channels=1):
            if rms(bytes(ev.frame.data)) > LOUD_RMS:
                t = self.now()
                if self.speech_end_at and not self.ai_spoke_since_answer:
                    self.latencies.append(t - self.speech_end_at)
                    self.ai_spoke_since_answer = True
                self.last_loud = t

    # ── mic: 20 ms frames, paced in real time ──
    async def mic_pump(self):
        from livekit import rtc
        nxt = self.now()
        while True:
            if self.speak_buf:
                # The last piece of an answer is padded to a whole frame.
                frame = bytes(self.speak_buf[:FRAME_BYTES]).ljust(FRAME_BYTES, b"\0")
                del self.speak_buf[:FRAME_BYTES]
                if not self.speak_buf:
                    self.speech_end_at = self.now() + 0.02
                    self.ai_spoke_since_answer = False
            else:
                frame = bytes(FRAME_BYTES)
            if self.mic is not None:
                await self.mic.capture_frame(rtc.AudioFrame(frame, RATE, 1, FRAME_BYTES // 2))
            if not self.lk_live and self.ws is not None:
                try:
                    await self.ws.send(frame)
                except Exception:
                    pass
            nxt += 0.02
            await asyncio.sleep(max(0, nxt - self.now()))

    # ── answer when the AI has finished and a beat has passed ──
    async def turn_taker(self):
        while True:
            await asyncio.sleep(0.1)
            idle = (self.ai_pending == 0 and not self.speak_buf and self.last_ack_at
                    and self.now() - self.last_ack_at > 1.0)
            if idle and self.ai_spoke_since_answer:
                i = self.answer_i % len(self.speech)
                self.said.append(ANSWERS[i])
                self.heard_text.append([])
                self.speak_buf.extend(self.speech[i])
                self.answer_i += 1
                self.last_ack_at = 0.0

    # ── control messages, from either channel ──
    async def ws_reader(self):
        async for m in self.ws:
            self.ws_frames += 1
            if isinstance(m, bytes):
                if m[:1] == b"\x00":
                    self.ws_utter.extend(m[1:])
                continue
            await self.on_control(json.loads(m))

    async def on_control(self, msg: dict):
        t = self.now()
        typ = msg.get("type")
        if typ == "media_transport":
            self.transport = msg.get("transport")
        elif typ == "audio_start":
            if self.first_ai_at is None:
                self.first_ai_at = t
            self.ai_pending += 1
            self.utter_start = t
            self.ws_utter = bytearray()
        elif typ == "audio_end":
            self.schedule_ack(msg.get("sub_id", ""))
        elif typ == "audio_cancel":
            self.ai_pending = 0
        elif typ == "stt_final" and self.heard_text:
            self.heard_text[-1].append(msg.get("text", ""))
        elif typ in ("session_end", "session_ended"):
            self.ended_at = t
            # Was the last utterance heard out (acked) before the server hung up?
            self.goodbye_acked_before_end = self.ai_pending == 0
            self.done.set()

    def schedule_ack(self, sub_id: str):
        start, end_at = self.utter_start, self.now()
        if self.lk_live:
            async def wait():
                while True:
                    now = self.now()
                    heard = self.last_loud >= start
                    if heard and now - self.last_loud >= QUIET_MS / 1000:
                        return "livekit_playout"
                    if not heard and now - end_at >= 2.5:
                        return "livekit_unheard"
                    await asyncio.sleep(0.04)
        else:
            # The page buffers the utterance and plays it whole: emulate its clock.
            dur = len(self.ws_utter) / (RATE * 2)
            play_at = max(self.now(), self.ws_tail)
            self.ws_tail = play_at + dur
            if dur > 0:
                if self.speech_end_at and not self.ai_spoke_since_answer:
                    self.latencies.append(play_at - self.speech_end_at)
                    self.ai_spoke_since_answer = True
                self.last_loud = self.ws_tail

            async def wait():
                await asyncio.sleep(max(0, self.ws_tail - self.now()))
                return "onended"

        prev = self.ack_chain

        async def chain():
            if prev is not None:
                await prev
            via = await wait()
            try:
                await self.send_control({"type": "audio_playback_finished", "sub_id": sub_id,
                                         "grounded": True, "via": via})
            except Exception:
                pass
            self.acks.append(via)
            self.ai_pending = max(0, self.ai_pending - 1)
            self.last_ack_at = self.now()
        self.ack_chain = asyncio.ensure_future(chain())

    def report(self) -> dict:
        recalls = []
        for said, heard in zip(self.said, self.heard_text):
            sw, hw = words(said), set(words(" ".join(heard)))
            if sw and heard:
                recalls.append(sum(w in hw for w in sw) / len(sw))
        lat = sorted(self.latencies)
        return {
            "transport": self.transport,
            "rejoins_after_the_ai_left": self.rejoins,
            "control_channel": "livekit data channel" if self.room_mode else "websocket",
            "websocket_frames": self.ws_frames,
            "answers_given": len(self.said),
            "answers_transcribed": sum(bool(h) for h in self.heard_text),
            "word_recall_mean": round(statistics.mean(recalls), 3) if recalls else None,
            "response_s_median": round(statistics.median(lat), 2) if lat else None,
            "response_s_p95": round(lat[int(0.95 * (len(lat) - 1))], 2) if lat else None,
            "acks": {v: self.acks.count(v) for v in sorted(set(self.acks))},
            "first_ai_audio_s": round(self.first_ai_at - self.t0, 2) if self.first_ai_at else None,
            "ended_naturally": self.ended_at is not None and not self.timed_out,
            "goodbye_heard_before_end": self.goodbye_acked_before_end,
            "duration_s": round((self.ended_at or self.now()) - self.t0, 1),
        }


def egress_file(token: str, wait_s: float = 45) -> int | None:
    """Size of the LiveKit egress file in Azure, waiting for it to finalise."""
    from azure.storage.blob import BlobServiceClient
    name = os.environ.get("LIVEKIT_EGRESS_AZURE_ACCOUNT_NAME")
    key = os.environ.get("LIVEKIT_EGRESS_AZURE_ACCOUNT_KEY")
    container = os.environ.get("LIVEKIT_EGRESS_AZURE_CONTAINER")
    if not (name and key and container):
        return None
    svc = BlobServiceClient(f"https://{name}.blob.core.windows.net", credential={"account_name": name, "account_key": key})
    cc = svc.get_container_client(container)
    deadline = time.monotonic() + wait_s
    while time.monotonic() < deadline:
        # One file per runner: an interview handed off mid-way has several.
        sizes = [b.size for b in cc.list_blobs(name_starts_with=f"{token}/recording/livekit-audio")]
        if sizes and all(sizes):
            return sum(sizes)
        time.sleep(3)
    return None


async def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("token")
    ap.add_argument("--gateway", default="http://gateway:8080")
    ap.add_argument("--max-s", type=float, default=420)
    a = ap.parse_args()
    speech = await asyncio.to_thread(synthesize, ANSWERS)
    rep = await Bot(a.gateway, a.token, speech, a.max_s).run()
    if rep["transport"] == "livekit":
        rep["egress_file_bytes"] = await asyncio.to_thread(egress_file, a.token)
    print(json.dumps(rep, indent=2))


if __name__ == "__main__":
    asyncio.run(main())
