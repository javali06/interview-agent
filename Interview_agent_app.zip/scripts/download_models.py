"""Pre-download every model the orchestrator can need.

Run this once per machine after `uv sync`. After it finishes, the
HuggingFace cache + local model directory are populated, so the first
`./scripts/run_live_v2.sh` won't pay download latency.

Usage:
    python -m scripts.download_models           # download all
    python -m scripts.download_models --skip-whisper   # skip 1.2GB whisper model
    python -m scripts.download_models --hf-home /custom/cache

Models handled:
  1. Kokoro TTS — pulled via HF Hub on first `KPipeline()` construction
                   (~313 MB, lang_code='b' = British English).
  2. spaCy `en_core_web_sm` — Kokoro's phonemizer needs it.
  3. Silero VAD ONNX — downloaded from snakers4/silero-vad GitHub to
                        `engine/speech/models/silero_vad.onnx` (~2 MB).
  4. faster-whisper — only needed if you set `--stt-provider=streamA`.
                       Groq's REST STT (the default) doesn't need this.

Each step is idempotent — re-runs are fast no-ops once cached.
"""
from __future__ import annotations

import argparse
import os
import sys
import urllib.request
from pathlib import Path


def _print(msg: str) -> None:
    print(f"[download_models] {msg}", flush=True)


def download_kokoro(lang_code: str = "b") -> None:
    """Triggers HF download of hexgrad/Kokoro-82M into the HF cache.
    Constructing KPipeline once is enough — it fetches all required
    files on its own."""
    _print(f"Kokoro: ensuring hexgrad/Kokoro-82M is cached (lang_code={lang_code!r})...")
    try:
        from kokoro import KPipeline
    except ImportError:
        _print("  SKIP — `kokoro` not installed. `uv sync` first.")
        return
    KPipeline(lang_code=lang_code)
    _print("  ✓ Kokoro ready (subsequent KPipeline() will load from cache).")


def download_spacy_en() -> None:
    """spaCy `en_core_web_sm` is a Python package wheel. Kokoro's phonemizer
    imports it. Installs via `python -m spacy download` which is idempotent."""
    _print("spaCy: ensuring en_core_web_sm is installed...")
    try:
        import spacy  # noqa: F401
    except ImportError:
        _print("  SKIP — `spacy` not installed.")
        return
    try:
        import en_core_web_sm  # noqa: F401
        _print("  ✓ en_core_web_sm already installed.")
        return
    except ImportError:
        pass
    # Use spacy's CLI; subprocess to keep our import surface small.
    import subprocess
    res = subprocess.run(
        [sys.executable, "-m", "spacy", "download", "en_core_web_sm"],
        capture_output=False,
    )
    if res.returncode != 0:
        _print("  WARNING — spacy download failed; phonemizer may break at runtime.")
    else:
        _print("  ✓ en_core_web_sm installed.")


_SILERO_URL = (
    "https://github.com/snakers4/silero-vad/raw/master/"
    "src/silero_vad/data/silero_vad.onnx"
)


def download_silero_vad(target: Path) -> None:
    """Fetch silero_vad.onnx to the path Stream A's VAD service expects.
    Default target: <repo>/engine/speech/models/silero_vad.onnx."""
    _print(f"Silero VAD: target {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and target.stat().st_size > 100_000:
        _print(f"  ✓ already exists ({target.stat().st_size:,} bytes), skipping.")
        return
    _print(f"  downloading from {_SILERO_URL} ...")
    urllib.request.urlretrieve(_SILERO_URL, target)
    _print(f"  ✓ saved {target.stat().st_size:,} bytes.")


def download_faster_whisper(model_id: str = "Systran/faster-distil-whisper-large-v3") -> None:
    """Pulls the faster-whisper model into HF cache. Only needed if you
    run with `--stt-provider=streamA`. Default Groq path doesn't need this."""
    _print(f"faster-whisper: ensuring {model_id} is cached (~1.2 GB)...")
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        _print("  SKIP — `faster-whisper` not installed.")
        return
    # Construction with cpu_threads=1 keeps init quick; the side effect is
    # the model download.
    WhisperModel(model_id, device="cpu", compute_type="int8", cpu_threads=1)
    _print(f"  ✓ {model_id} ready.")


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--skip-kokoro", action="store_true")
    p.add_argument("--skip-spacy", action="store_true")
    p.add_argument("--skip-silero", action="store_true")
    p.add_argument("--skip-whisper", action="store_true",
                   help="Skip the 1.2GB faster-whisper download. Default ON "
                        "if your interview uses Groq STT (the default).")
    p.add_argument("--silero-target", type=Path,
                   default=Path(__file__).resolve().parent.parent
                            / "engine" / "speech" / "models" / "silero_vad.onnx",
                   help="Where to save silero_vad.onnx (must match "
                        "SILERO_MODEL_PATH at runtime).")
    p.add_argument("--hf-home", type=Path, default=None,
                   help="Override HF cache root (sets HF_HOME for the "
                        "duration of this script).")
    p.add_argument("--kokoro-lang", default="b",
                   help="Kokoro lang code ('b'=BrEn, 'a'=AmEn, 'h'=Hindi). "
                        "Match what the TTS service is configured for.")
    args = p.parse_args()

    if args.hf_home is not None:
        args.hf_home.mkdir(parents=True, exist_ok=True)
        os.environ["HF_HOME"] = str(args.hf_home)
        _print(f"HF_HOME set to {args.hf_home}")

    if not args.skip_kokoro:
        download_kokoro(lang_code=args.kokoro_lang)
    if not args.skip_spacy:
        download_spacy_en()
    if not args.skip_silero:
        download_silero_vad(args.silero_target)
    if not args.skip_whisper:
        download_faster_whisper()

    _print("All requested downloads complete.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
