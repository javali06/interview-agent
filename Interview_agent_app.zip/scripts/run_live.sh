#!/usr/bin/env bash
# Run the integrated interview using your microphone instead of a WAV fixture.
#
#   1. Boot Stream A's STT, VAD, TTS (same as run_integrated.sh).
#   2. Wait for /healthz.
#   3. Run orchestrator/live_main.py — captures from default mic, plays TTS
#      through default speakers, and (unless --no-filler is passed) fires a
#      speculative filler if the AI hasn't spoken within 1s of you stopping.
#
# Usage:
#   ./scripts/run_live.sh                                  # all defaults
#   ./scripts/run_live.sh --no-filler                      # skip filler
#   ./scripts/run_live.sh --filler-threshold-s 0.5         # tighter filler
#   ./scripts/run_live.sh --candidate-name "Ayush"         # ...etc
#
# Stop with Ctrl-C. The transcript prints at exit.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
INTEGRATION_ROOT="$(cd "$HERE/.." && pwd)"
STREAM_A_DIR="$INTEGRATION_ROOT/stream_a"
PARENT_REPO_ROOT="$(cd "$INTEGRATION_ROOT/.." && pwd)"

# Pick a venv: prefer integration's own .venv, fall back to parent repo's.
if [[ -x "$INTEGRATION_ROOT/.venv/bin/python" ]]; then
    PY="$INTEGRATION_ROOT/.venv/bin/python"
elif [[ -x "$PARENT_REPO_ROOT/.venv/bin/python" ]]; then
    PY="$PARENT_REPO_ROOT/.venv/bin/python"
else
    echo "ERROR: no .venv/bin/python in $INTEGRATION_ROOT or $PARENT_REPO_ROOT" >&2
    echo "       run the install steps in README.md first" >&2
    exit 2
fi

# OpenRouter key from any .env nearby.
KEY=""
for cand in \
    "$INTEGRATION_ROOT/.env" \
    "$PARENT_REPO_ROOT/.env" \
    "$PARENT_REPO_ROOT/STREAM_B/Interview_agent_app/.env" \
    "$INTEGRATION_ROOT/.env.example" \
    "$PARENT_REPO_ROOT/.env.example"
do
    if [[ -f "$cand" && -n "$(grep -E '^OPENROUTER_API_KEY=.+' "$cand" || true)" ]]; then
        KEY=$(grep '^OPENROUTER_API_KEY=' "$cand" | cut -d= -f2-)
        echo "OPENROUTER_API_KEY sourced from $cand"
        break
    fi
done
if [[ -z "$KEY" ]]; then
    echo "ERROR: OPENROUTER_API_KEY not found in any .env" >&2
    exit 2
fi

mkdir -p /tmp/integration_logs /tmp/integration
rm -f /tmp/integration_logs/*.log /tmp/integration/events.jsonl

# Kill stale processes on Stream A ports.
for port in 8010 8011 8012; do
    pids=$(lsof -ti tcp:$port 2>/dev/null || true)
    if [[ -n "$pids" ]]; then
        echo "killing stale process on :$port (pids: $pids)"
        kill -9 $pids 2>/dev/null || true
    fi
done

PIDS=()
cleanup() {
    echo ""
    echo "--- shutting down ---"
    for pid in "${PIDS[@]:-}"; do kill "$pid" 2>/dev/null || true; done
    wait 2>/dev/null || true
}
# Trap on EXIT only — NOT on INT/TERM. On Ctrl-C, bash forwards SIGINT to
# the foreground Python process which has its own clean-shutdown handler.
# Python finishes (prints the session summary, etc.), and the EXIT trap
# fires AFTER. This avoids killing Stream A's TTS/STT/VAD while Python is
# still mid-flush — that race produced the "1012 service restart"
# tracebacks we used to see on Ctrl-C.
trap cleanup EXIT

cd "$STREAM_A_DIR"

echo "--- starting STT (bundled Stream A) ---"
STREAM_A_FAKE_BACKENDS=0 \
KMP_DUPLICATE_LIB_OK=TRUE \
OPENROUTER_API_KEY="$KEY" \
WHISPER_MODEL_PATH="${WHISPER_MODEL_PATH:-Systran/faster-distil-whisper-large-v3}" \
"$PY" -m services.speech_io.stt_service.main > /tmp/integration_logs/stt.log 2>&1 &
PIDS+=($!)

echo "--- starting VAD (bundled Stream A) ---"
STREAM_A_FAKE_BACKENDS=0 \
SILERO_MODEL_PATH="$STREAM_A_DIR/models/silero_vad.onnx" \
"$PY" -m services.speech_io.vad_service.main > /tmp/integration_logs/vad.log 2>&1 &
PIDS+=($!)

echo "--- starting TTS (bundled Stream A — Kokoro local) ---"
STREAM_A_FAKE_BACKENDS=0 \
KMP_DUPLICATE_LIB_OK=TRUE \
"$PY" -m services.speech_io.tts_service.main > /tmp/integration_logs/tts.log 2>&1 &
PIDS+=($!)

echo "--- waiting for healthchecks (up to 15 min for first-time model downloads) ---"
START_TS=$(date +%s)
DEADLINE=$(( START_TS + 900 ))
NEXT_HEARTBEAT=$(( START_TS + 30 ))
until curl -sf http://127.0.0.1:8010/healthz >/dev/null && \
      curl -sf http://127.0.0.1:8011/healthz >/dev/null && \
      curl -sf http://127.0.0.1:8012/healthz >/dev/null; do
    NOW=$(date +%s)
    if (( NOW > DEADLINE )); then
        echo "ERROR: services failed to come up in 15 min"
        for s in stt vad tts; do
            echo "--- $s.log (last 20 lines) ---"
            tail -20 /tmp/integration_logs/$s.log 2>/dev/null
        done
        exit 3
    fi
    if (( NOW > NEXT_HEARTBEAT )); then
        DOWN=()
        curl -sf http://127.0.0.1:8010/healthz >/dev/null || DOWN+=("STT")
        curl -sf http://127.0.0.1:8011/healthz >/dev/null || DOWN+=("VAD")
        curl -sf http://127.0.0.1:8012/healthz >/dev/null || DOWN+=("TTS")
        echo "  [+$((NOW - START_TS))s] still waiting on: ${DOWN[*]}"
        NEXT_HEARTBEAT=$(( NOW + 30 ))
    fi
    sleep 1
done
echo "Stream A services ready (took $(( $(date +%s) - START_TS ))s)"

export OPENROUTER_API_KEY="$KEY"

echo ""
echo "--- running orchestrator (live mic mode) ---"
cd "$INTEGRATION_ROOT"
"$PY" -m orchestrator.live_main "$@"
