#!/usr/bin/env bash
# run_orchestrator.sh — per-session orchestrator launcher.
#
# Assumes Stream A is already running (booted once by run_app.sh at the start
# of the work session). Just executes orchestrator_new.live_main with the
# args passed through. Spawned by admin/spawner.py.
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
INTEGRATION_ROOT="$(cd "$HERE/.." && pwd)"

if [[ -x "$INTEGRATION_ROOT/.venv/bin/python" ]]; then
    PY="$INTEGRATION_ROOT/.venv/bin/python"
else
    echo "ERROR: no .venv/bin/python in $INTEGRATION_ROOT" >&2
    exit 2
fi

# Source LLM keys for any child diagnostic; live_main re-sources too.
GROQ_KEY=""
OR_KEY=""
if [[ -f "$INTEGRATION_ROOT/.env" ]]; then
    if grep -qE '^GROQ_API_KEY=.+' "$INTEGRATION_ROOT/.env"; then
        GROQ_KEY=$(grep '^GROQ_API_KEY=' "$INTEGRATION_ROOT/.env" | cut -d= -f2-)
    fi
    if grep -qE '^OPENROUTER_API_KEY=.+' "$INTEGRATION_ROOT/.env"; then
        OR_KEY=$(grep '^OPENROUTER_API_KEY=' "$INTEGRATION_ROOT/.env" | cut -d= -f2-)
    fi
fi
[[ -n "$GROQ_KEY" ]] && export GROQ_API_KEY="$GROQ_KEY"
[[ -n "$OR_KEY"   ]] && export OPENROUTER_API_KEY="$OR_KEY"

export PYTHONUNBUFFERED=1

echo ""
echo "============================================================"
echo "  ORCHESTRATOR STARTING (Stream A is assumed to be up)"
echo "============================================================"
echo ""

cd "$INTEGRATION_ROOT"
"$PY" -u -m engine.orchestrator.live_main "$@"
