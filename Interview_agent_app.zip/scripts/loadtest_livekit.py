"""Load test for LiveKit interviews: many bot candidates at once, ramped.

Each bot is the parity-check bot (scripts/livekit_parity_check.py): it starts
the interview the way the page does (POST /api/candidate/{token}/start, join
the room, control over the data channel), answers with real speech, and acks
each AI utterance like the page. This script runs N of them concurrently per
level, with staggered starts, and reports per level what a candidate would
feel and what an operator must know:

  * started / on LiveKit / fell back to the WebSocket / refused or errored;
  * ended naturally, and was the goodbye heard before the session ended;
  * transcription recall (words the server transcribed of what the bot said);
  * response time p50/p95 over every turn of every interview at that level
    (candidate stops talking -> candidate hears the AI);
  * time to the greeting p50/p95 (start -> first AI audio): this is where a
    full pool, a slow room join or a cold replica shows up first.

Every interview is REAL: it uses the LLM, Azure Speech and LiveKit minutes.
Start small (--levels 1,2,4) and watch the "LiveKit media & scaling" Grafana
row while it runs.

Tokens: either --token-file (one ready interview token per line, used in
order, each once) or --make-tokens --template <token>, which clones that
interview's row and cadence into fresh "ready" interviews (needs DATABASE_URL
and the shared sessions volume, i.e. run it inside a tier image on the stack's
network). --cleanup deletes the interviews it made when it finishes — their
post-interview evaluations then fail (and are retried until dead-lettered), so
leave it off when you want those evaluations too.

macOS / Linux (local stack; the session image has livekit + the Speech SDK):

  docker run --rm --network interview-scaled_default --env-file deploy/local/.env \\
      -e PYTHONPATH=/app -v "$PWD/scripts:/s" -v interview-scaled_sessions:/app/sessions \\
      --entrypoint python interview-agent-session:local \\
      /s/loadtest_livekit.py --make-tokens --template <TOKEN> --levels 1,2,4 --cleanup

Windows (PowerShell):

  docker run --rm --network interview-scaled_default --env-file deploy/local/.env `
      -e PYTHONPATH=/app -v "${PWD}/scripts:/s" -v interview-scaled_sessions:/app/sessions `
      --entrypoint python interview-agent-session:local `
      /s/loadtest_livekit.py --make-tokens --template <TOKEN> --levels 1,2,4 --cleanup

(The local compose project's network and sessions volume; `docker network ls`
/ `docker volume ls` show yours if the project is named differently.)
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import shutil
import statistics
import sys
import time
import uuid

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from livekit_parity_check import ANSWERS, Bot, synthesize  # noqa: E402


# ── tokens ────────────────────────────────────────────────────────────────────
def make_tokens(template: str, n: int, label: str) -> list[str]:
    """Clone ``template`` into ``n`` fresh ready interviews. Copies the row and
    what the runner reads from the session folder (cadence, evaluation plan,
    precomputed resume) — nothing the template's own interview produced."""
    from app import db
    from app.paths import session_dir

    row = db.get(template)
    if row is None:
        raise SystemExit(f"template interview {template} not found")
    src = session_dir(template)
    if not (src / "cadence.yaml").exists():
        raise SystemExit(f"template {template} has no cadence.yaml — approve it first")
    out = []
    for i in range(n):
        tok = str(uuid.uuid4())
        db.insert({**row, "token": tok, "status": "ready", "started_at": None,
                   "ended_at": None, "created_at": db.now_iso(),
                   "candidate_name": f"Load test {label} #{i + 1} (delete me)"})
        dst = session_dir(tok)
        dst.mkdir(parents=True, exist_ok=True)
        for name in ("cadence.yaml", "evaluation_plan.json"):
            if (src / name).exists():
                shutil.copy2(src / name, dst / name)
        if (src / "resume").is_dir():
            shutil.copytree(src / "resume", dst / "resume", dirs_exist_ok=True)
        out.append(tok)
    return out


def delete_tokens(tokens: list[str]) -> None:
    from app import db
    from app.paths import session_dir
    for tok in tokens:
        try:
            db.delete(tok)
            shutil.rmtree(session_dir(tok), ignore_errors=True)
        except Exception as e:
            print(f"  could not delete {tok}: {e!r}")


# ── one level ─────────────────────────────────────────────────────────────────
def pct(xs: list[float], q: float) -> float | None:
    if not xs:
        return None
    xs = sorted(xs)
    return round(xs[min(len(xs) - 1, int(q * (len(xs) - 1) + 0.5))], 2)


async def run_level(gateway: str, tokens: list[str], speech: list[bytes], *,
                    stagger_s: float, max_s: float) -> dict:
    bots: list[Bot] = []
    reports: list[dict | None] = []
    errors: list[str] = []

    async def one(i: int, tok: str):
        await asyncio.sleep(i * stagger_s)
        bot = Bot(gateway, tok, speech, max_s)
        bot.quiet = True
        bots.append(bot)
        try:
            reports.append(await bot.run())
        except Exception as e:  # refused (409/410), gateway down, room join failed
            errors.append(f"{tok[:8]}: {type(e).__name__}: {e}"[:200])
            reports.append(None)

    t0 = time.monotonic()
    await asyncio.gather(*(one(i, t) for i, t in enumerate(tokens)))
    ok = [r for r in reports if r]
    latencies = [x for b in bots for x in b.latencies]
    firsts = [r["first_ai_audio_s"] for r in ok if r.get("first_ai_audio_s") is not None]
    recalls = [r["word_recall_mean"] for r in ok if r.get("word_recall_mean") is not None]
    return {
        "concurrency": len(tokens),
        "wall_s": round(time.monotonic() - t0, 1),
        "started": len(ok),
        "errors": errors,
        "on_livekit": sum(r["transport"] == "livekit" for r in ok),
        "fell_back_to_websocket": sum(r["transport"] != "livekit" for r in ok),
        "ended_naturally": sum(bool(r["ended_naturally"]) for r in ok),
        "goodbye_heard": sum(bool(r["goodbye_heard_before_end"]) for r in ok),
        "rejoins": sum(r["rejoins_after_the_ai_left"] for r in ok),
        "word_recall_mean": round(statistics.mean(recalls), 3) if recalls else None,
        "response_s_p50": pct(latencies, 0.5),
        "response_s_p95": pct(latencies, 0.95),
        "turns_measured": len(latencies),
        "first_ai_audio_s_p50": pct(firsts, 0.5),
        "first_ai_audio_s_p95": pct(firsts, 0.95),
    }


def print_table(rows: list[dict]) -> None:
    cols = [("concurrency", "N"), ("started", "started"), ("on_livekit", "livekit"),
            ("fell_back_to_websocket", "ws-fallback"), ("ended_naturally", "ended"),
            ("goodbye_heard", "goodbye"), ("word_recall_mean", "recall"),
            ("response_s_p50", "resp p50"), ("response_s_p95", "resp p95"),
            ("first_ai_audio_s_p50", "greet p50"), ("first_ai_audio_s_p95", "greet p95")]
    print("  ".join(f"{h:>11}" for _, h in cols))
    for r in rows:
        print("  ".join(f"{'-' if r[k] is None else r[k]!s:>11}" for k, _ in cols))
    for r in rows:
        for e in r["errors"]:
            print(f"  [N={r['concurrency']}] {e}")


async def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--gateway", default="http://gateway:8080")
    ap.add_argument("--levels", default="1,2,4",
                    help="concurrent interviews per step, e.g. 1,2,4,8")
    ap.add_argument("--token-file", help="ready interview tokens, one per line")
    ap.add_argument("--make-tokens", action="store_true",
                    help="clone --template into as many fresh interviews as the levels need")
    ap.add_argument("--template", help="interview token to clone (with --make-tokens)")
    ap.add_argument("--cleanup", action="store_true",
                    help="delete the interviews --make-tokens created, at the end")
    ap.add_argument("--stagger-s", type=float, default=2.0,
                    help="seconds between starts within a level (0 = all at once)")
    ap.add_argument("--max-s", type=float, default=600,
                    help="end an interview that is still running after this long")
    ap.add_argument("--pause-s", type=float, default=20,
                    help="rest between levels so the last level's teardown settles")
    ap.add_argument("--json-out", help="also write the per-level results here")
    a = ap.parse_args()

    levels = [int(x) for x in a.levels.split(",") if x.strip()]
    need = sum(levels)
    made: list[str] = []
    if a.make_tokens:
        if not a.template:
            raise SystemExit("--make-tokens needs --template <token>")
        made = make_tokens(a.template, need, time.strftime("%H:%M"))
        tokens = list(made)
    elif a.token_file:
        tokens = [t.strip() for t in open(a.token_file) if t.strip()]
        if len(tokens) < need:
            raise SystemExit(f"levels {levels} need {need} tokens; the file has {len(tokens)}")
    else:
        raise SystemExit("give --token-file, or --make-tokens --template <token>")

    print(f"levels {levels}: {need} interviews against {a.gateway}", flush=True)
    speech = await asyncio.to_thread(synthesize, ANSWERS)
    rows = []
    try:
        for i, n in enumerate(levels):
            batch, tokens = tokens[:n], tokens[n:]
            print(f"-- level {n}: starting", flush=True)
            row = await run_level(a.gateway, batch, speech,
                                  stagger_s=a.stagger_s, max_s=a.max_s)
            rows.append(row)
            print(json.dumps(row), flush=True)
            if i < len(levels) - 1:
                await asyncio.sleep(a.pause_s)
    finally:
        if rows:
            print()
            print_table(rows)
        if a.json_out:
            with open(a.json_out, "w") as f:
                json.dump(rows, f, indent=2)
        if made and a.cleanup:
            # Give the post-interview jobs a moment to pick their inputs up.
            await asyncio.sleep(5)
            delete_tokens(made)
            print(f"deleted {len(made)} load-test interviews")


if __name__ == "__main__":
    asyncio.run(main())
