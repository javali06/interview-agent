@echo off
REM ---------------------------------------------------------------------------
REM run_orchestrator.bat - per-session orchestrator launcher.
REM
REM Assumes Stream A (STT/VAD/TTS on 8010/8011/8012) is ALREADY running
REM (booted once by run_app.bat at the start of the work session). This
REM script only runs orchestrator_new.live_main with the args passed through.
REM
REM Spawned by admin/spawner.py with --scheduled-token <uuid> --web ...
REM ---------------------------------------------------------------------------

setlocal
pushd "%~dp0.."
set "INTEGRATION_ROOT=%CD%"
popd

if not exist "%INTEGRATION_ROOT%\.venv\Scripts\python.exe" (
    echo ERROR: no .venv\Scripts\python.exe at %INTEGRATION_ROOT%
    exit /b 2
)
set "PY=%INTEGRATION_ROOT%\.venv\Scripts\python.exe"

REM Source LLM keys (live_main also re-sources but exporting here is safe)
for /f "usebackq tokens=1,* delims==" %%A in (`findstr /B /C:"GROQ_API_KEY=" /C:"OPENROUTER_API_KEY=" "%INTEGRATION_ROOT%\.env" 2^>nul`) do (
    set "%%A=%%B"
)

set "PYTHONUNBUFFERED=1"

echo.
echo ============================================================
echo   ORCHESTRATOR STARTING (Stream A is assumed to be up)
echo ============================================================
echo.

cd /d "%INTEGRATION_ROOT%"
"%PY%" -u -m engine.orchestrator.live_main %*

echo.
echo ============================================================
echo   ORCHESTRATOR EXITED - this window will stay open. Close it
echo   to release this session.
echo ============================================================
echo.
endlocal
