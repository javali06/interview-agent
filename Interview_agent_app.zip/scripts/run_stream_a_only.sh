#!/usr/bin/env bash
# run_stream_a_only.sh — boots STT/VAD/TTS on 8010/8011/8012, waits for
# /healthz, then sleeps forever. The admin web app spawns per-session
# orchestrators against these. Ctrl-C / window close stops everything.
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
INTEGRATION_ROOT="$(cd "$HERE/.." && pwd)"
STREAM_A_DIR="$INTEGRATION_ROOT/engine/speech"

if [[ -x "$INTEGRATION_ROOT/.venv/bin/python" ]]; then
    PY="$INTEGRATION_ROOT/.venv/bin/python"
else
    echo "ERROR: no .venv/bin/python in $INTEGRATION_ROOT" >&2
    exit 2
fi

# spaCy en_core_web_sm — Kokoro phonemizer needs it; install on first run.
if ! "$PY" -c "import en_core_web_sm" 2>/dev/null; then
    echo "--- installing spaCy en_core_web_sm (one-time, ~12MB) ---"
    "$PY" -m spacy download en_core_web_sm
fi

# Source LLM keys from .env so children inherit them (live_main re-sources too)
GROQ_KEY=""
OR_KEY=""
for cand in "$INTEGRATION_ROOT/.env"; do
    if [[ -f "$cand" ]]; then
        if [[ -z "$GROQ_KEY" ]] && grep -qE '^GROQ_API_KEY=.+' "$cand"; then
            GROQ_KEY=$(grep '^GROQ_API_KEY=' "$cand" | cut -d= -f2-)
        fi
        if [[ -z "$OR_KEY" ]] && grep -qE '^OPENROUTER_API_KEY=.+' "$cand"; then
            OR_KEY=$(grep '^OPENROUTER_API_KEY=' "$cand" | cut -d= -f2-)
        fi
    fi
done
[[ -n "$GROQ_KEY" ]] && export GROQ_API_KEY="$GROQ_KEY"
[[ -n "$OR_KEY"   ]] && export OPENROUTER_API_KEY="$OR_KEY"

mkdir -p /tmp/integration_logs
rm -f /tmp/integration_logs/*.log

for port in 8010 8011 8012; do
    pids=$(lsof -ti tcp:$port 2>/dev/null || true)
    if [[ -n "$pids" ]]; then
        echo "killing stale process on :$port (pids: $pids)"
        kill -9 $pids 2>/dev/null || true
    fi
done

PIDS=()
cleanup() {
    echo ""
    echo "--- shutting down Stream A subprocesses ---"
    for pid in "${PIDS[@]:-}"; do kill "$pid" 2>/dev/null || true; done
    wait 2>/dev/null || true
}
trap cleanup EXIT INT TERM

cd "$STREAM_A_DIR"

echo "--- starting STT (faster-whisper) ---"
STREAM_A_FAKE_BACKENDS=0 \
KMP_DUPLICATE_LIB_OK=TRUE \
WHISPER_MODEL_PATH="${WHISPER_MODEL_PATH:-Systran/faster-distil-whisper-large-v3}" \
"$PY" -m services.speech_io.stt_service.main > /tmp/integration_logs/stt.log 2>&1 &
PIDS+=($!)

echo "--- starting VAD (Silero) ---"
STREAM_A_FAKE_BACKENDS=0 \
SILERO_MODEL_PATH="$STREAM_A_DIR/models/silero_vad.onnx" \
"$PY" -m services.speech_io.vad_service.main > /tmp/integration_logs/vad.log 2>&1 &
PIDS+=($!)

echo "--- starting TTS (Kokoro) ---"
STREAM_A_FAKE_BACKENDS=0 \
KMP_DUPLICATE_LIB_OK=TRUE \
HF_HUB_OFFLINE=1 \
"$PY" -m services.speech_io.tts_service.main > /tmp/integration_logs/tts.log 2>&1 &
PIDS+=($!)

HEALTH_DEADLINE_S=900
HEALTH_URLS=( "http://127.0.0.1:8010/healthz" "http://127.0.0.1:8011/healthz" "http://127.0.0.1:8012/healthz" )
HEALTH_NAMES=( "STT" "VAD" "TTS" )
START_TS=$(date +%s)
DEADLINE=$(( START_TS + HEALTH_DEADLINE_S ))
NEXT_HEARTBEAT=$(( START_TS + 30 ))

echo "--- waiting for /healthz on 8010/8011/8012 ---"
while :; do
    all_up=1
    for url in "${HEALTH_URLS[@]}"; do
        curl -sf "$url" >/dev/null || { all_up=0; break; }
    done
    (( all_up == 1 )) && break
    NOW=$(date +%s)
    if (( NOW > DEADLINE )); then
        echo "ERROR: Stream A failed to come up in $HEALTH_DEADLINE_S s"
        for s in stt vad tts; do
            [[ -f /tmp/integration_logs/$s.log ]] || continue
            echo "--- $s.log (last 20 lines) ---"
            tail -20 /tmp/integration_logs/$s.log 2>/dev/null
        done
        exit 3
    fi
    if (( NOW > NEXT_HEARTBEAT )); then
        DOWN=()
        for i in "${!HEALTH_URLS[@]}"; do
            curl -sf "${HEALTH_URLS[$i]}" >/dev/null || DOWN+=("${HEALTH_NAMES[$i]}")
        done
        echo "  [+$((NOW - START_TS))s] still waiting on: ${DOWN[*]}"
        NEXT_HEARTBEAT=$(( NOW + 30 ))
    fi
    sleep 1
done

echo ""
echo "============================================================"
echo "  STREAM A READY (took $(( $(date +%s) - START_TS ))s)"
echo "  Admin app can now spawn per-session orchestrators."
echo "  Ctrl-C or close window to stop."
echo "============================================================"

# Stay alive so the start-and-forget children keep running.
while :; do sleep 3600; done
