@echo off
setlocal enabledelayedexpansion

REM ---------------------------------------------------------------------------
REM run_live_v2.bat - Windows equivalent of scripts/run_live_v2.sh
REM
REM Single-terminal mode: STT, VAD, TTS, and the orchestrator all run in this
REM one cmd window. Their stdouts interleave below. Each service's structlog
REM output already includes its module name (stt.*, vad.*, tts.*) so you can
REM tell which line came from where.
REM
REM Usage (from anywhere - paths resolve relative to this script):
REM     scripts\run_live_v2.bat
REM     scripts\run_live_v2.bat --candidate-name "Ayush" --role "Backend"
REM     scripts\run_live_v2.bat --resume-path resume.pdf --cadence-path cadence.yaml
REM     scripts\run_live_v2.bat --config path\to\system_config.yaml
REM
REM Tuning (models, providers, thresholds, STT/TTS, etc.) now lives in
REM config\system_config.yaml - edit that file, NOT CLI flags. Prompts live in
REM config\prompts.yaml. Secrets stay in .env. (This script always boots
REM Stream A's STT service; set stt.provider: streamA in the config to use it.)
REM
REM Stop: Ctrl+C. Goes to the orchestrator (foreground) and the background
REM Stream A services (they share the same console), so everything dies cleanly.
REM ---------------------------------------------------------------------------

REM ---- 1. Resolve paths ----
set "HERE=%~dp0"
pushd "%HERE%.."
set "INTEGRATION_ROOT=%CD%"
popd
set "STREAM_A_DIR=%INTEGRATION_ROOT%\stream_a"

REM ---- 2. Sanity checks ----
if not exist "%INTEGRATION_ROOT%\.venv\Scripts\python.exe" (
    echo ERROR: no .venv\Scripts\python.exe at %INTEGRATION_ROOT%
    echo        Build the venv first: uv venv .venv ^&^& uv pip install -e ".[dev]"
    exit /b 2
)
set "PY=%INTEGRATION_ROOT%\.venv\Scripts\python.exe"

if not exist "%INTEGRATION_ROOT%\.env" (
    echo ERROR: .env not found at %INTEGRATION_ROOT%\.env
    exit /b 2
)

where curl >nul 2>&1
if errorlevel 1 (
    echo ERROR: curl not found on PATH. Windows 10 1803+ ships curl built-in.
    exit /b 2
)

REM ---- 3. Load GROQ_API_KEY + OPENROUTER_API_KEY from .env ----
for /f "usebackq tokens=1,* delims==" %%A in (`findstr /B /C:"GROQ_API_KEY=" /C:"OPENROUTER_API_KEY=" "%INTEGRATION_ROOT%\.env"`) do (
    set "%%A=%%B"
)
if not defined GROQ_API_KEY if not defined OPENROUTER_API_KEY (
    echo ERROR: neither GROQ_API_KEY nor OPENROUTER_API_KEY found in .env
    exit /b 2
)
if defined GROQ_API_KEY        echo GROQ_API_KEY sourced from .env
if defined OPENROUTER_API_KEY  echo OPENROUTER_API_KEY sourced from .env

REM ---- 4. Log/event directories (mirrors /tmp/* from the .sh) ----
set "LOG_DIR=%TEMP%\integration_logs"
set "EVENT_DIR=%TEMP%\integration"
if not exist "%LOG_DIR%"   mkdir "%LOG_DIR%"
if not exist "%EVENT_DIR%" mkdir "%EVENT_DIR%"
del /q "%LOG_DIR%\*.log" 2>nul
del /q "%EVENT_DIR%\events.jsonl" 2>nul

REM ---- 5. Kill stale processes on Stream A ports ----
echo.
echo --- killing stale processes on Stream A ports (8010/8011/8012) ---
for %%P in (8010 8011 8012) do (
    for /f "tokens=5" %%I in ('netstat -ano ^| findstr ":%%P " ^| findstr "LISTENING"') do (
        echo   killing PID %%I on :%%P
        taskkill /F /PID %%I >nul 2>&1
    )
)

REM ---- 6. Common env vars for Stream A services ----
set "STREAM_A_FAKE_BACKENDS=0"
set "KMP_DUPLICATE_LIB_OK=TRUE"
set "PYTHONUNBUFFERED=1"
if not defined WHISPER_MODEL_PATH set "WHISPER_MODEL_PATH=Systran/faster-distil-whisper-large-v3"
set "SILERO_MODEL_PATH=%STREAM_A_DIR%\models\silero_vad.onnx"

REM ---- 7. Launch all 3 Stream A services in THIS console (background processes) ----
REM `start /B ""` launches into the current console without opening a new window.
REM stdout/stderr from all three flow into this terminal and interleave.
echo.
echo ============================================================
echo   STREAM A STARTING - STT/VAD/TTS logs interleave below
echo ============================================================
echo.
cd /d "%STREAM_A_DIR%"
start /B "" "%PY%" -u -m services.speech_io.stt_service.main
start /B "" "%PY%" -u -m services.speech_io.vad_service.main
start /B "" "%PY%" -u -m services.speech_io.tts_service.main
cd /d "%INTEGRATION_ROOT%"

REM ---- 8. Wait for /healthz on all three ----
set /a "ELAPSED=0"
set /a "DEADLINE=900"
set /a "NEXT_HEARTBEAT=30"

:waithealth
curl -sf http://127.0.0.1:8010/healthz >nul 2>&1
if errorlevel 1 goto notyet
curl -sf http://127.0.0.1:8011/healthz >nul 2>&1
if errorlevel 1 goto notyet
curl -sf http://127.0.0.1:8012/healthz >nul 2>&1
if errorlevel 1 goto notyet
goto allup

:notyet
if !ELAPSED! GEQ !DEADLINE! goto failed
if !ELAPSED! GEQ !NEXT_HEARTBEAT! call :heartbeat
timeout /t 1 /nobreak >nul
set /a "ELAPSED+=1"
goto waithealth

:heartbeat
set "DOWN="
curl -sf http://127.0.0.1:8010/healthz >nul 2>&1
if errorlevel 1 set "DOWN=!DOWN! STT"
curl -sf http://127.0.0.1:8011/healthz >nul 2>&1
if errorlevel 1 set "DOWN=!DOWN! VAD"
curl -sf http://127.0.0.1:8012/healthz >nul 2>&1
if errorlevel 1 set "DOWN=!DOWN! TTS"
echo.
echo [main] [+!ELAPSED!s] still waiting on:!DOWN!
echo.
set /a "NEXT_HEARTBEAT+=30"
goto :eof

:failed
echo.
echo ERROR: services failed to come up in 15 min. Scroll up for tracebacks.
exit /b 3

:allup
echo.
echo ============================================================
echo   STREAM A READY (took !ELAPSED!s) - starting orchestrator
echo ============================================================
echo.

REM ---- 9. Run orchestrator in the foreground of this same window ----
"%PY%" -u -m engine.orchestrator.live_main %*

endlocal
