# CLAUDE.md

Operating manual for AI coding agents working in this repo. Read this first — it
captures the non-obvious mental model, conventions, key files, and the deploy
flow so a fresh session is productive immediately. For full local setup see



[README.md](README.md); for the brain's design see [NEW_STREAM_B.md](NEW_STREAM_B.md).

> **MAINTENANCE RULE (do this every time): whenever you push code to the repo,
> first update THIS file to reflect what changed — new features, architecture
> deltas, new/renamed key files, new env vars, deploy changes — and include
> CLAUDE.md in the same commit as the code. Keep it accurate; a stale CLAUDE.md
> is worse than none. Update the "Recent work log" section at the bottom too.**

---

## What this is

A voice-driven AI interview agent. An admin schedules a candidate; the system
generates a tailored interview cadence, runs a real-time spoken conversation
between the candidate and an AI interviewer in the browser. **It is the AI and
the candidate only — no human joins or intervenes** (the live observer / TA
push-to-talk feature was removed). The AI takes the interview and clarifies
questions ONLY — it never coaches, corrects, answers, or hints to the candidate.

## Two run modes (important — don't confuse them)

1. **Local single-laptop** (README's model): three processes — admin FastAPI
   `:8000`, Stream A speech I/O (STT `:8010` / VAD `:8011` / TTS `:8012`), and a
   per-interview orchestrator subprocess (static UI `:8090` + WS `:9100`). Entry:
   `run_app.bat` / `run_app.sh`. Ports are FIXED → only one interview at a time.
2. **Cloud (this is what we deploy and where most feature work lands)**:
   `deploy/azure_app.py` is the gunicorn entry (`deploy.azure_app:app`) running
   with `CLOUD_MODE=1`. The orchestrator runs **in-process** (no `:8090/:9100`
   subprocess); the React SPA is served at `/app`; the candidate connects over a
   WebSocket on the single web port. Deployed to Azure App Service
   `interview-ai-backend` from branch **`demo-prod`**.

## Tiered scaling deploy (branch `interview-scaled-dev`)

A third deploy shape lives on **`interview-scaled-dev`** (cloned from `demo-prod`,
which stays the untouched rollback monolith). It splits the monolith by scaling
profile behind **Azure Front Door** on **Azure Container Apps**, coordinated by
**Redis**. See `docs/scaling-architecture-plan.md`. Distributed-only: Redis, the
job queue, Postgres, and the broker are HARD dependencies (no in-process fallback).

- **Gateway** (`deploy/gateway_app.py`, stateless, HTTP-scaled) — reuses
  `app.main` routes + reverse-proxies `/ws/*` to the owning session shard.
- **Session** (`deploy/azure_app.py`, stateful, pinned 1 replica/shard) — live
  interview; VAD-only Stream A (STT+TTS are Azure); claims token cluster-wide.
- **Worker** (`app/jobs/worker.py`, queue-scaled→0) — cadence-gen, eval-v2,
  shortlist, etc. off the request path.
- **Redis coordination** (`app/coordination/`) — registry (token→shard, replaces
  the `_token_sessions` dict), admission (Speech/LLM/session caps), locks, pub-sub.
- **Capacity broker** (`app/broker/`) — multi-key Azure Speech rotation, STT
  Azure↔Groq fallback, LLM timeout/backup.
- **Session tier glue** (`app/session_tier/`) — shard identity + claim/heartbeat/
  release. **Data** is Postgres-only (`DATABASE_URL` required) + Blob (artifacts).
- **Deploy**: per-tier images on a shared base (`deploy/Dockerfile.{base,gateway, worker,session}` + `deploy/requirements/*.txt`), `deploy/build_tiers.sh`,
  `deploy/local/docker-compose.yml` (Redis+Postgres+Azurite for local),
  `deploy/aca/main.bicep` + `provision.sh` + `RESOURCES.md`.
- **Tests**: `tests/test_{coordination,jobs,broker,session_tier,gateway}.py`
  (fakeredis; no Azure). Full stack runs via docker-compose.

Key new env: `REDIS_URL`, `DATABASE_URL`, `AZURE_STORAGE_CONNECTION_STRING`,
`AZURE_SPEECH_KEYS` (comma list, N×5 streams), `SHARD_ID`/`SHARD_FQDN`,
`SESSION_SHARDS`/`SESSION_SHARD_FQDNS`, `SPEECH_STREAMS_PER_KEY`,
`MAX_ACTIVE_SESSIONS`, `MAX_LLM_INFLIGHT`, `JOBS_QUEUE_NAME`, `JOBS_MAX_ATTEMPTS`.

## Architecture essentials

- **Real-time transport: WebSocket by default, LiveKit behind `MEDIA_TRANSPORT=livekit`**
  (gateway AND session shards; plan + status in `docs/media-server-scaling-plan.md`).
  Default: audio is PCM16 streamed over a single WebSocket through a central
  `WebBroadcaster`: candidate mic → brain, AI TTS → candidate (1-byte tag `0x00`).
  With LiveKit on, a voice interview needs NO WebSocket: the page calls
  `POST /api/candidate/{token}/start` (gateway → Redis placement → a session replica),
  gets ITS tab's room token, and then audio rides tracks (mic up, `ai-voice` down) and
  every control message (captions, phases, coding/scenario, the playback ack, start/end)
  rides the room's reliable data channel — same JSON shapes, large ones chunked. The
  shard waits until the candidate can hear before greeting. If LiveKit fails, the
  interview is HANDED OFF (runner stops, not marked completed, claim freed) and the page
  starts over on the WebSocket path on an addressable shard. Session replicas: the
  addressable shards (`session-N`, WebSocket path) plus an autoscaled `session-pool`
  (no ingress, LiveKit only). Leases are fenced; SIGTERM drains (LiveKit interviews
  finish in place up to `DRAIN_TIMEOUT_S`, then hand off); per-turn checkpoints let a
  resume continue mid-phase. Avatars (3D TalkingHead + photoreal Simli) work on both
  paths: on LiveKit the page taps the AI's track back into 16 kHz PCM and streams it to
  the avatar for the FACE only — the LiveKit element keeps playing the voice, so the ack,
  volume and recording are unchanged (`AvatarSink.stream`, `candidateEngine.onAiFrame`).
  Camera and screen are **not sent anywhere live** — they exist only as the
  candidate's local previews and the **recording**, done locally in the browser
  via `MediaRecorder` and uploaded incrementally as Azure append-blobs. (They used
  to be relayed as JPEG snapshots, but only ever to the removed observer.)
- **The brain** (`engine/brain`): a Director owns turn-taking; a Verifier (fast
  LLM) classifies each candidate reply; a CadenceTracker advances phases
  deterministically by time; the slow LLM produces substantive turns; TTS streams
  PCM. Cadence phases: warm_up → project_architecture → challenges_faced →
  scenario_based → genai_basics → wrap_up.
- **Stream A** (`engine/speech`): STT (Whisper via Groq), VAD (Silero), TTS
  (Kokoro). Heavy to boot; kept warm.
- **Observability**: Langfuse per-call generation traces, grouped by session_id;
  no-ops cleanly when keys are unset. See `engine/brain/observability/`.

## Key files (the ones you'll actually touch)

Backend / Python:

- `deploy/azure_app.py` — cloud entry: session runner, `/ws/candidate/...`,
  session lifecycle, `_token_sessions`.
- `app/main.py` — FastAPI routes, SPA mount at `/app`, recording upload/download.
- `app/blob_store.py` — Azure blob mirror (append-blob recording, ranged download).
- `app/db.py` — session CRUD (SQLAlchemy; SQLite local, Postgres if `DATABASE_URL`).
  Status values: `ready` | `in_progress` | `completed` | `cancelled`.
- `engine/orchestrator/web/broadcaster.py` — the WebSocket relay (audio tags,
  start/end, playback acks, coding/scenario dispatch). Wire format in its header.
- `engine/brain/core/director.py` — turn-taking + the AI dispatch gate.
- `engine/brain/runtime/interview_session.py` — top-level session coordinator.
- `engine/brain/observability/langfuse_client.py` — `observe_llm/stt/tts`,
  `log_event` (must be called ON the asyncio loop to attach to the trace).

Cadence editor ("Revise & Verify Cadence with AI") — see `docs/cadance&verify.md`:

- `app/cadence_service.py` — orchestration (`revise_cadence_conversational`), `_phase_catalog`,
  `_resolve_add_asks`, `CODE_DISCUSSION_PHASE` (the ONE definition of the code-review phase).
- `app/cadence_agents/phase_tools.py` — every deterministic tool + `plan_deterministic` (the
  zero-LLM pre-pass: structure, then durations, then whatever is genuinely a content ask).
- `app/cadence_agents/{router,phase_resolver,modifying,validating}_agent.py` — the four agents.
  The resolver runs ONLY for "add" clauses and decides WHICH phase by matching phase **intents**.
- `config/phase_blacklist.json` — phases the editor must never create, each with an `intent` (what
  the resolver matches on) and a `reason` (shown to the admin). No keyword/alias lists by design.

Access control + question-pool maker-checker:

- `app/rbac.py` — permissions (a closed vocabulary), `has_permission(user, perm, team)`,
  and the `require(...)` dependency every pool route is gated on. `app/rbac_seed.py` is the
  starting policy: teams, the 4 roles, the role→permission grid, the approval chain, and the
  seeded test accounts. It only adds missing rows. The grid is written only when empty.
- `app/access_service.py` + `app/access_routes.py` — the Access screens' rules and
  `/api/access` (People, Teams and that team's chain, Roles). A Platform Admin changes grants
  here. The seed is no longer the only way. Author and checker on the same team is refused,
  including a checker grant on `*` while the person authors any team. The last active
  Platform Admin cannot be removed. Sign-in is Microsoft, or the shared username/password,
  which signs in as a real Platform Admin account (`rbac_seed.shared_admin_user_id`). There is
  no development sign-in any more (no clickable accounts, no email + admin password).
  Interview pages follow the role in the menu, and the same permissions are checked on
  the server (`rbac.interview_permission` in the grant middleware): `interviews.view`
  for the list, transcript, and recording, `interviews.schedule` for creating and
  approving, `interviews.cancel` for archive and delete. A chain step may name only a
  role that holds `pools.approve`. Turning a team off keeps its grants and they stop
  working until it is turned back on. A new grant shows who added it. An older cookie
  with no user id is still let through.
- UI: `ui/web/src/lib/workspace.ts` is the one menu list (sidebar, Welcome, route guard).
  `pages/Access.tsx`, `components/Guard.tsx`, `components/AccountGate.tsx`. A person with no
  role sees one card and no menu. Reference: `docs/rbac-authentication-reference.pdf`.
  Pool workflow stays in `docs/question-pool-maker-checker-reference.pdf`.
- `app/approval_service.py` — the workflow, as pure functions over the DB. State is DERIVED
  from the append-only ledger and never stored, so a status and a history cannot disagree.
  `submit`/`approve`/`return_pool`/`withdraw`/`force_publish`, plus `review()` for
  per-question verdicts. The refusals live here (self-approval, wrong team, signing twice).
- `app/question_pools.py` — `question_pools/` (published) vs `question_pool_drafts/` (draft)
  as SIBLING blob prefixes. **That split is the control**: cadence reads only the published
  prefix, so an unapproved question is unreachable by construction, not by a permission check.
  `publish_approved()` merges the approved subset by id (a rejected edit never removes a live
  question) and leaves the rejected ones as the draft. Inside a transaction use
  `stage_draft`/`stage_approved`: they write the live pool and RETURN the draft cleanup, which
  the approval service runs only after the ledger commits.
- `app/constants.py` — the pool state / ledger action / verdict strings and `GLOBAL_TEAM="*"`,
  shared by the backend files above. Imports nothing, so anything can import it.
- UI: `ui/web/src/pages/PoolReview.tsx` (the checker's per-question screen),
  `PoolApprovals.tsx` (queue), `components/PoolWorkflow.tsx` (state pill + actions). Buttons
  are gated on the pool's STATE as well as the person's permission, which is why the same
  pool shows different actions to different people — and why a draft shows "Submit" where a
  pending pool shows "Approve".

Evaluation v2 (behind `EVAL_PLUGINS_ENABLED`):

- `features/eval/sectioner.py` — `events.jsonl` → phase→segment tree (the unit of
  scoring AND evidence). `app/plugin_evaluation.py` (`run_evaluation` dispatcher +
  `generate_evaluation_v2`) + `app/plugin_aggregate.py` (benchmark math + v1
  adapter). `features/eval/plugins/` (contract + builtins; see its `AUTHORING.md`)
  and `features/eval/plan.py`/`plan_storage.py` (per-phase plugin plan). UI:
  `ui/web/src/components/{EvalPlanPanel,BenchmarkPanel,SchemaForm}.tsx` +
  `eval-views/` (the `view_id` result-template catalog).
- `features/eval/plugins/export.py` — the **export contract**: the second audience
  for a plugin's verdict (a machine-readable JSON document that leaves the portal,
  as opposed to `view_id`/`view_payload`, which feed the UI). `ExportSectionModel`
  (the common envelope), `ExportSection` (a plugin's static descriptor — its
  pydantic model IS the declared schema), `envelope()`, and `GroundTruthExport`/
  `GroundTruthComparison`, the ONE expected-vs-actual shape shared by
  transcription/translation/image_description. Hooks: `EvalPlugin.
  export_descriptor()` + `.export_section()` (both default to None → that plugin
  contributes no section); `registry.export_schemas()` is the export's
  self-description. Two invariants are enforced by the MODEL, not by plugin
  discipline: a non-scored state carries a `not_scored_reason` and NEVER marks (so
  a 0 always means "earned zero", never "couldn't grade it"), and sections are
  closed (`extra="forbid"`) so the emitted JSON can't drift from its schema. What
  may go in an export is a recorded decision: `docs/eval-export-pii-decision.md`.

Frontend (React + Vite + TS + Tailwind, in `ui/web/`):

- `src/lib/candidateEngine.ts` — candidate WS/audio/recording state machine.
- `src/pages/{Candidate,Session}.tsx` — the candidate's live view + the admin's
  interview detail page.
- `src/components/VideoTiles.tsx` — AVA + candidate tiles, `ScreenSharePreview`.
- `src/lib/{videoCam,bgBlur,talkingHead}.ts` — camera/screen capture, MediaPipe blur, avatar.
- `src/lib/livekitMedia.ts` — the page's LiveKit side (mic publish, AI track); the
  playout-measured `audio_playback_finished` lives in `candidateEngine.ts`.
- `src/styles/{tokens,light}.css` — the shared light design system (Centific brand tokens +
  the admin component layer); `components/{PageHeader,LoadingBlock,ErrorBoundary,Logo}.tsx`
  are its shared pieces. New admin screens build on these rather than ad-hoc styles.
- `src/lib/{talkingHead,simliAvatar}.ts` — the two avatars behind one `AvatarSink`:
  `speak()` (WebSocket: whole utterances, the avatar plays them) and `stream`
  (LiveKit: a live feed for the face; TalkingHead's own speaker is muted).

LiveKit (server): `engine/orchestrator/livekit/{config,tokens,transport,egress}.py` —
switch + timeouts, room access (`livekit_offer` = the token-less offer BOTH `/session-info`
handlers return; `candidate_room_access` = the per-tab token only the shard mints, after
the one-tab check), the agent's room + audio source/sink + control data channel (the
sink honours the same playout-ack contract as `web/audio_sink.py`; the source self-heals
a stalled reader), and the server-side audio recording (egress, one file per runner).
Scaling: `app/session_tier/placement.py` (Redis start queue + per-replica inbox +
liveness + `/scaler/pool` demand), `app/session_tier/lifecycle.py` (fenced claim/renew/
release, dead-owner takeover), `deploy/azure_app.py` (`_room_start`, `_hand_off`,
`_finish_session`/`_supervise_session`, drain), `app/resume_collapse.py` (phase- and
turn-mode resume views, used by the trace, v1 transcript AND v2 eval).
`scripts/livekit_parity_check.py` — bot candidate that runs a whole interview on either
transport and reports transcription, response time, goodbye, egress (Phase 1F).
`scripts/loadtest_livekit.py` — N of those bots at once per level (LiveKit load test).
Operations: `app/coordination/metrics_push.py` (pool + worker publish /metrics to Redis; the
gateway serves them at `/metrics/pushed`), `engine/orchestrator/livekit/egress.py` part
manifests + the `recording_finalize` job in `app/jobs/jobs.py` (did the server recording land).

## Conventions (follow these)

- **Coding style (Karpathy-ish):** minimal, explicit, no premature abstraction.
  Match the surrounding code's idiom, naming, comment density. Comments explain
  **WHY**, not WHAT.
- **Cross-platform always:** when adding scripts/commands, give Windows
  (PowerShell/`.bat`) AND macOS/Linux (`bash`/`.sh`) equivalents. The operator is
  on Windows 11 + PowerShell + a `uv` venv (`.venv`).
- **Interviewer discipline:** the AI interviews + clarifies its own questions
  only — never correct, answer, hint, or coach the candidate.
- **Suggest before implementing** substantial features: share a short plan /
  clarifying questions first, then build.
- **One-command UX:** the operator wants minimal commands; per-session work
  auto-spawns its own terminal window for log visibility (local mode).

## Frontend build & gotchas

- Build/typecheck: `cd ui/web && npm run build` (= `tsc --noEmit && vite build`).
- **Node is often NOT on the local shell PATH here** — you may be unable to run
  `tsc`/`npm` locally. The `az acr build` deploy runs the SPA build in its Node
  stage, so **type errors fail the deploy build** — that's your safety net, but a
  failed deploy costs ~8 min. Review TS edits carefully.
- **JSX gotcha:** never put `//` or `{/* */}` comments *between JSX attributes*
  (the parser reads `{` as a spread → `TS1005`). Put comments inside an
  expression (`screen={ /* ... */ ... }`) or as element children.
- Git may warn `LF will be replaced by CRLF` on TS/Py files — harmless here.
- **No live video leaves the candidate's browser.** The camera self-view and the
  "Sharing your screen" preview are display only; there is no JPEG snapshot pump
  any more (it existed solely to feed the removed observer, and cost a 1080p
  JPEG encode every 400 ms on the candidate's machine plus the upload). Don't
  reintroduce one without a real receiver.
- **SPA cache discipline (load-bearing):** the shell `index.html` is served
  `Cache-Control: no-cache` and the content-hashed `/app/assets/*` are
  `immutable, max-age=31536000` (`_ImmutableAssets` + `_spa` in `app/main.py`).
  NEVER let the shell be cached — a stale `index.html` pins an old bundle hash, so
  browsers keep running old JS after a deploy (this is why deploys "didn't take"). `azure_app.py` copies these
  routes verbatim, so the cloud inherits the fix.

## Recording / proctoring notes

- **No observer.** The live observer (watch, push-to-talk, hints, chat, live
  notes) was removed: an interview is the AI and the candidate only. Old
  `/admin/sessions/{token}/live` and `/app/sessions/{token}/live` links redirect
  to the interview's detail page. **Past interviews stay readable**: TA turns
  (`Speaker.INTERVIEWER`, `observer_ptt` / `observer_hint_received` events) still
  render in the transcript, trace and evaluation, and `GET
  /api/sessions/{token}/notes` still lists notes from the `observer_notes` table —
  nothing creates new ones.
- **Session-end signals:** the runner emits `session_end`; admin-delete and the
  natural-end notice emit `session_ended`. The candidate engine treats both the
  same; the server also returns `session_ended` for a `completed`/`cancelled`
  token so a reopened link goes inactive instead of polling forever.
- **Recording audio mix:** the browser mixes candidate mic + AI TTS into the
  recorded track (taps raw PCM, so the AI is captured even in avatar mode).
  Recording download supports HTTP Range/206 for fast seek.
- **Mandatory entire-screen proctoring:** the candidate lobby gates Start on a
  `screen` check (alongside camera) — the candidate must share their ENTIRE
  monitor before starting. `videoCam.startScreen` hints `displaySurface:"monitor"`
  + `width/height ideal 1920×1080` (**1080p** so shared code/text is legible in
  the recording); `isEntireScreen()` validates `getSettings().displaySurface ===
  "monitor"` and the engine re-prompts if they picked a window/tab (the browser
  can't FORCE whole-screen). Once live, recording is forced on at WS open so the
  screen records start-to-end (`{token}/recording/screen.webm`); a mid-interview
  stop pops a blocking re-share prompt and APPENDS to the same blob
  (`screenRecStarted` guards the seq-0 overwrite).

## Deploy (cloud) — the operational checklist

Subscription: **AzureSimple Pactera** `da74e3ed-9c9a-4605-8fae-10f3492c0f5c`;
RG `AI-COE`; ACR `interviewagentacr`; App `interview-ai-backend`. Azure CLI is
pip-installed (on PATH in fresh PowerShell); device-code login.

```powershell
# 0. Always set these first (Windows log-stream crashes on a ✓ otherwise):
$env:PYTHONUTF8="1"; $env:PYTHONIOENCODING="utf-8"

# 1. Build (runs tsc --noEmit && vite build in the Node stage; ~8 min):
az acr build --registry interviewagentacr --image interview-agent:latest `
  --file deploy/Dockerfile --resource-group AI-COE .

# 2. GET THE NEW DIGEST (the webapp is pinned to a DIGEST, not :latest — a plain
#    restart re-pulls the OLD image). Take it from the build output, or:
az acr manifest list-metadata -r interviewagentacr -n interview-agent `
  --query "[?tags] | sort_by(@,&lastUpdateTime)[-1].digest" -o tsv

# 3. Repin + restart:
az webapp config container set -g AI-COE -n interview-ai-backend `
  --docker-custom-image-name "interviewagentacr.azurecr.io/interview-agent@sha256:<NEW_DIGEST>"
az webapp restart -g AI-COE -n interview-ai-backend

# 4. Verify it actually shipped: fetch /app/ and confirm the index-<hash>.js
#    bundle hash CHANGED.
```

Gotchas: (a) **digest pin** — must repin every deploy; (b) the `az acr build`
local stream can exit 1 with a transient `AuthenticationFailed` / Unicode crash
even when the **server-side run Succeeded** — verify via `az acr task list-runs`
and the new `:latest` digest before assuming failure; (c) **B-tier OOM** —
gunicorn is `--workers 1`; real fix is scaling the plan (cost decision, ask first).

## Testing

- Python: `pytest tests/` (suite targets `engine/brain`). For a quick syntax
  check without the venv: `python -m py_compile <files...>`.
- Frontend: `npm run build` in `ui/web` (or rely on the ACR build's tsc stage).
- Manual: a real browser run of the candidate page for any recording/media
  change — these are runtime/browser-behavior bugs the type build can't catch.

## Env vars

Required: `GROQ_API_KEY` (or `OPENROUTER_API_KEY`). Admin: `ADMIN_USERNAME`,
`ADMIN_PASSWORD_HASH`, `ADMIN_SECRET_KEY`. Eval: `EVAL_PLUGINS_ENABLED=1` switches
post-interview scoring to the v2 plugin pipeline (default off → v1 single-pass);
must be set in BOTH `.env` (local) and the App Service settings (cloud) to match.
Cadence editor: `CADENCE_VALIDATOR_MODEL` (+ optional `CADENCE_VALIDATOR_PROVIDER`)
makes the VALIDATING agent run on a different model from the one that made the edit;
unset, validation stays an independent call on the same model. The phase RESOLVER and the
MODIFYING agent share the editor's default model handle — no separate env vars.
Cloud: `CLOUD_MODE=1`,
`AZURE_SPEECH_KEY`/`AZURE_SPEECH_REGION` (Azure Speech),
`BLOB_ENABLED`+`AZURE_STORAGE_CONNECTION_STRING` (recording), `DATABASE_URL`
(Postgres), `LANGFUSE_*` (tracing — no-ops if unset). See `.env.example`.
LiveKit (optional): `MEDIA_TRANSPORT` (`websocket`|`livekit`), `LIVEKIT_URL`/`_API_KEY`/
`_API_SECRET`, egress `LIVEKIT_EGRESS_AZURE_ACCOUNT_NAME`/`_ACCOUNT_KEY`/`_CONTAINER`
(`LIVEKIT_EGRESS=0` = off), tuning `LIVEKIT_CONNECT_TIMEOUT_S`/`_CANDIDATE_JOIN_TIMEOUT_S`/
`_EGRESS_START_WAIT_S`/`_EGRESS_STOP_GRACE_S`/`LIVEKIT_MIC_STALL_S` — documented in
`deploy/local/.env.example`; in ACA they come from `main.bicep` (`mediaTransport`, `livekit*`
params). Scaling: `SESSION_POOL=1` (pool replica: hostname id, no address),
`PLACEMENT_MAX_SESSIONS` (interviews a replica takes from the queue; set from C),
`PLACEMENT_SHARED_QUEUE=0` (shard takes no new LiveKit interviews), `PLACEMENT_WAIT_S`
(gateway wait for a replica), `DRAIN_TIMEOUT_S` (540; ACA grace 600). Ops:
`METRICS_TOKEN` (bearer token for the gateway's `/metrics/pushed`; Bicep `metricsToken`),
`METRICS_PUSH_INTERVAL_S` (10), `RECORDING_FINALIZE_WAIT_S` (90).

## Git workflow

- **`main` is the main branch** (since 29 Oct 2026; it was an empty Azure DevOps template
  until `feature/livekit-media` was merged into it). Feature work lands on
  `feature/livekit-media` (or a branch off it) and is merged into `main`.
- **Deploy branch: `interview-scaled-dev`** — fast-forwarded to the release commit and tagged
  `vN`, then built and rolled out per `.claude/skills/deploy-prod/SKILL.md`. Production
  (tiered ACA) is built only from it. `demo-prod` is the retired single-app rollback.
- Commit only when asked; end commit messages with the `Co-Authored-By` trailer.
- **Per the Maintenance Rule above, update CLAUDE.md in the same push.**

---

## Recent work log (most recent first — keep this current on every push)

- **Safety check (guardrail) no longer fails on a quarter of turns — COMMITTED, tested, NOT
  deployed.** In the 3 Nov evening load test the guardrail failed on 61 of 257 turns (24%; morning
  53 of 194) with Groq errors "Tool choice is required, but model did not call a tool" and "Failed
  to parse tool call arguments as JSON", and each such turn went through unchecked (fail-open).
  Cause: `gpt-oss-safeguard-20b` is a reasoning model whose thinking counts as output tokens and
  comes BEFORE the ~25-token tool call; a good call used ~100 tokens (p90 116) against a cap of
  120, so a slightly longer think was cut before the call or mid-JSON. Fix in
  `engine/brain/agents/guardrail_agent.py`: `max_tokens` 120 → 512 and OpenRouter
  `reasoning.effort = "low"` (via `extra.extra_body`, merged with the provider lock by
  `LLMClient._merge_extra`). Replayed 50 real turns from the test: 29/50 ok before, 50/50 after
  (all 30 previously failed now pass), p50 0.47 s, max 1.5 s, ≤201 tokens; 4/4 deliberate attacks
  still caught with the right category, a genuine answer passed. Not related to the AI speaking
  its own notes ("We need to respond with the restated question…"): the guardrail reads only the
  candidate's words; that leak is the interviewer model (gpt-oss-120b) emitting invisible
  characters / dot runs and then its reasoning as content (5 of 300 replies) — fix designed
  (sanitise the stream before TTS, hold the tail after junk, drop note-like sentences, keep only
  spoken text in history), NOT built yet.

- **v47 DEPLOYED to production (29 Oct 2026, 16:50 UTC) · `main` is now the main branch.**
  Release = `interview-scaled-dev` @ `5ea958c`, tag `v47`: Access screens + role menus, the
  shared password login as a Platform Admin, dev sign-in removed, Access holes closed
  (interview APIs check `interviews.*`), Send/Resend invite email buttons, Safari allowed in
  the voice lobby, and the review fixes below. Rolled out worker → text → session-0 →
  gateway with zero live interviews; all four healthy on v47, page `index-CMUL6Cdm.js`,
  `/api/auth/methods` = `{"microsoft":true}`, 0 errors in logs. Rollback target: v46.
  `main` (an unrelated Azure DevOps template commit) was merged with
  `--allow-unrelated-histories`, keeping our README.

- **Pre-deploy review fixes (release v47) + a deploy procedure.** A review of everything
  not yet in production found two regressions, fixed here, each pinned by a test that fails
  on the old code. (1) **"Approve all" after a partial review dropped live questions**:
  after a partial review the draft holds only the rejected questions, and an all-approved
  review copied that draft over the live pool, so questions approved in the earlier cycle
  vanished from every interview. `question_pools.stage_approved` merges by id again, as
  production did. Trade-off, recorded as a strict `xfail`
  (`test_review_approve_all_publishes_what_approve_publishes`): an author's DELETION is not
  applied by "Approve all" (the queue's Approve still applies it); fixing both needs the
  draft to keep the whole pool. (2) **Roles removed on the Access page came back on every
  restart**: `seed_rbac` runs on every gateway and session startup and re-added any missing
  seeded grant. It now grants only when it creates the account (the shared-admin rule).
  Safe for production: the seeded accounts are identical to v46's, so all already exist
  with their roles. (3) Deleting a pool deleted the draft before checking `pools.publish`
  on the published copy; every permission is now checked first. Local note: the LLM client
  always sends OpenRouter's `usage.include` option, which Groq-direct rejects (HTTP 400,
  the AI never speaks); local `.env` is back on OpenRouter like production. New:
  `.claude/skills/deploy-prod/SKILL.md` (local, git-ignored) — the gated deploy procedure.
  Production apps run with the default 30 s shutdown grace (not Bicep's 600 s), so deploy
  only with no live interview. Files: `app/question_pools.py`, `app/rbac_seed.py`,
  `app/question_pool_routes.py`, `tests/test_pool_question_review.py`,
  `tests/test_access_admin.py`.

- **Access holes closed — a chain step must be able to review, a paused team stops
  its grants, interview APIs check the real permission, and a new grant names who
  added it. Tested, NOT deployed.** (1) Save chain refuses Author and HR; the step
  list offers only roles that hold `pools.approve` (Question Checker and Platform
  Admin). A step already saved under another role still shows, marked so it can be
  changed. (2) `grants_for` ignores a grant whose team is inactive, and so does the
  pool signing check. The row stays; turning the team back on restores it. A grant
  on `*` is unaffected because that team cannot be turned off. (3) The same
  middleware that refuses a person with no role now also requires `interviews.view`,
  `interviews.schedule`, or `interviews.cancel` on the interview, schedule, cadence,
  Shortlist, and session routes. The candidate recording upload and phase-asset
  download stay open. A cookie with no user id is still skipped, so the old
  shared-login tests keep working. (4) People shows "Added by {name}" on a grant
  an admin clicked in. Seeded grants have no granter, so they show nothing.
  Not done: a history of chain edits and role-grid ticks. Tests:
  `tests/test_access_admin.py` (21) plus the RBAC, pool, shortlist, and dashboard
  suites. Files: `app/{rbac,access_service,approval_service,main}.py`,
  `ui/web/src/pages/Access.tsx`, `ui/web/src/lib/auth.ts`.

- **Development sign-in REMOVED · the shared username/password login is a Platform Admin —
  local-docker verified, NOT deployed.** On top of the Access/RBAC work below (`5f9bdd2`). The
  login page now offers only **Sign in with Microsoft** and the **username/password** form.
  **Removed:** `GET /api/dev/accounts`, `POST /api/dev/login`, the email + admin-password path
  in `POST /api/login` (it made the shared password every seeded person's password),
  `rbac.dev_login_enabled()` / `DEV_LOGIN_ENABLED`, `rbac_seed.seed_users_summary()`, the `dev`
  key of `/api/auth/methods`, and `useDevAccounts`/`useDevLogin` + the chooser on `Login.tsx`.
  Deleted rather than switched off, so it cannot be turned back on by an env var.
  **Shared login → admin:** its cookie carried no `app_users` id, so it held no permissions (no
  question pools, no Access page). Both password routes (`POST /api/login`, `POST /admin/login`)
  now sign in as a real account keyed by `ADMIN_USERNAME` (`rbac_seed.shared_admin_user_id`,
  display name "Shared admin login"), created on first sign-in with `admin` on `*`. The grant is
  given only at CREATION, so an admin who later removes or deactivates it on the Access page is
  not overruled on the next sign-in; a DB failure falls back to the old id-less cookie rather
  than blocking sign-in. It appears on the Access page as a person. Anyone with the shared
  password is a full admin, incl. pool approval and Access. The seeded team accounts STAY: they
  carry everyone's roles, and Microsoft sign-in links a person to their row by email on first
  sign-in. Tests sign in by setting the same cookie Microsoft sign-in issues; new tests:
  `test_the_shared_password_login_is_an_admin`, `test_a_seeded_email_cannot_sign_in_with_the_
  admin_password`, `test_there_is_no_passwordless_dev_sign_in`. Full suite 914 passed, 1
  long-standing failure. Files: `app/main.py`, `app/rbac.py`, `app/rbac_seed.py`,
  `app/entra_auth.py`, `ui/web/src/pages/Login.tsx`, `ui/web/src/lib/auth.ts`,
  `tests/test_{rbac,access_admin,pool_approvals}.py`.

- **Manual "send invite email" buttons — Shortlist interviews list + the interview-ready
  screen — local-docker verified, NOT deployed.** Both reuse the existing `invite_dispatch`
  job and `build_invite_email` template unchanged — this is a UI/trigger-point addition only,
  no new email logic. (1) **Shortlist** (`features/shortlist/role_routes.py`): new
  `POST /api/roles/{id}/interviews/{token}/send-email`, a pink "Send email" button next to
  "Copy link" in `InterviewSetup.tsx`'s per-interview row (only shown once an interview has a
  real link). Reads the candidate's email from `_candidate_of(row)` — the CANDIDATE table, the
  same live source this screen's inline editor writes to — not `sessions.candidate_email`,
  which is set once at creation and would otherwise silently resend to a stale address if the
  admin corrected it afterward on this same screen. (2) **Interview-ready screen**
  (`app/main.py` + `CadenceReview.tsx`): new `POST /api/schedule/{token}/send-invite-email`.
  Replaces the old static "📧 Sending the invite to x@y.com now." line — which just asserted
  success with no way to confirm or retry — with a "Resend email" button (Sending…/Sent ✓/error
  states), available indefinitely after the automatic first send on approve. Verified:
  `tsc --noEmit` + `vite build` clean; both routes live-tested via the dev-login cookie (404 on
  a bad token with a clean error body, not a 500); the Shortlist button live-tested end-to-end
  against the real `ava.interviews@centific.com` mailbox. Files: `app/main.py`,
  `features/shortlist/role_routes.py`, `ui/web/src/lib/{cadenceReview,roles}.ts`,
  `ui/web/src/pages/{CadenceReview,InterviewSetup}.tsx`.

- **AVA orb, kept DEAD SIMPLE: AVA audible → "speaking", candidate mic active → "hearing",
  else rest. Blue "hearing" glow. Deployed (gateway) v45 then v46.** The orb state is now one
  rule, no turn/boundary tracking, per the user after two failed attempts at cleverness.
  (1) **"speaking" = LiveKit active-speaker on the AI track, with a HOLD.** `livekitMedia.ts`
  surfaces `RoomEvent.ActiveSpeakersChanged` for the `agent` participant via `onSpeakingChanged`;
  `candidateEngine.onLkAgentSpeaking` sets the orb "speaking" true the instant AVA's real decoded
  audio is detected and, when it goes quiet, HOLDS "speaking" for **1200 ms** (`armAiHold`) before
  dropping to rest. That hold is the whole trick: it bridges the gap between the AI's sentences AND
  between separate AI turns ("Got it." / "Tell me about yourself." are TWO turns), so the orb never
  blinks out mid-thought — whether it's one turn or several. A new active-speaker signal cancels the
  hold. `candidateEngine.lkAckAfterPlayout` now ONLY sends the per-utterance `audio_playback_finished`
  ack (server sink-drain/silence timer need it); it no longer touches the orb.
  (2) **"hearing" = the candidate's mic is active** (`s.candidateSpeaking`, STT/VAD-gated so AVA's
  echo on speakers doesn't trip it — those STT events are ignored while `aiSpeaking`). `Candidate.tsx`
  `orbMode` is now just: speaking → `speaking`; muted → `idle`; else mic active → `hearing`; else
  `listening` (rest). Dropped the "your turn"/"thinking"/"connecting" states and the "Your turn"/
  "Listening…" status text entirely.
  (3) **Visual: "hearing" is a soft diffuse BLUE glow** (`AiOrb.tsx` `hearingHue` 208), sharp 2 px
  ring removed, glow gradient feathered so the edge dilutes.
  **Two earlier attempts, abandoned (do NOT revive):** (a) grounding the speaking→listening flip on
  the per-chunk playout-ack loop flipped between the two turns; (b) an authoritative server
  `ai_turn_end` signal (emitted off `EventKind.AI_UTTERANCE`) ALSO flipped between them — because the
  two sentences are two separate turns, each firing its own completion. A time-hold on the audio
  signal is the only thing that's robust to the turn structure. The `ai_turn_end` backend emission
  was reverted (broadcaster/launcher/azure_app back to parent); the dead message may still be emitted
  by the live `session-0` until its next deploy — the page ignores unknown control types, so it's
  harmless. Verified: `tsc --noEmit` clean (only the pre-existing `simli-client/dist/client`
  local-resolution quirk, resolves in the deploy's fresh `npm ci`). **Gateway-only redeploy** (no
  backend change). Files: `ui/web/src/lib/{candidateEngine,livekitMedia}.ts`,
  `ui/web/src/pages/Candidate.tsx`, `ui/web/src/components/AiOrb.tsx`.

- **Mute now reaches the server on LiveKit too · candidate transcript starts closed — COMMITTED,
  local-docker verified, NOT deployed.** AB#34362's `{type:"mic_muted"}` was sent only over the
  WebSocket, which a LiveKit interview does not have, so on LiveKit the server learned of a mute
  only through the 5 s audio-starvation watchdog. `candidateEngine.toggleMic` now uses
  `sendControl` (the room's data channel in LiveKit mode, else the WebSocket); the server already
  routed it there (`broadcaster.handle_room_message` → `handle_inbound_json`). Also: the live
  transcript panel starts closed and opens from its dock button (user decision; the design-system
  merge had it open above 1100 px). Local-only, not in git: `deploy/local/.env` points the LLMs at
  Groq directly (`SLOW_PROVIDER=groq`, `FAST_MODEL=openai/gpt-oss-20b`, `FAST_BASE_URL`) because
  the OpenRouter key hit its $50 limit, and Groq no longer serves Llama 3.1 8B.

- **Least privilege: a signed-in person holding NO grants can reach nothing — AB#34522 —
  COMMITTED, local-docker verified with a real grantless account, NOT deployed.** The
  necessary companion to the Entra work below, and arguably the more important half.
  **The hole.** Signing in and being ALLOWED something were effectively the same thing,
  because the only doors were one shared password and a dev switch that is off in production
  — so "signed in" meant "an admin who was given the password". Entra breaks that assumption:
  ANY Centific employee can now authenticate. Meanwhile **only `app/question_pool_routes.py`
  checks permissions** — `app/main.py` has ZERO `Depends(require(...))`, and the shortlist /
  roles / pools routers are mounted behind `_api_require_user`, which is literally just
  `if auth.get_current_user(request) is None: 401` ("is ANYONE signed in"), repeated inline in
  ~20 places. So a brand-new employee with no role could open the dashboard, the interview
  list, transcripts, evaluations, recordings, and the Shortlist's resumes and candidate scores.
  Confirmed by signing in as an account with no grants BEFORE fixing it, not inferred.
  **The fix: ONE middleware** (`_require_some_grant` in `app/main.py`), not a dependency per
  route. The checks are scattered and inline, so anything per-route can be forgotten by the
  next person and **forgetting fails OPEN**; a middleware cannot be forgotten and covers routes
  added later for free. Rule: a person who HAS an `app_users` row but `grants_for()` is empty
  gets 403 `no_access` everywhere except `_NO_GRANT_ALLOWED` — the surfaces needed to be TOLD
  (`/api/me`, `/api/me/permissions`), to sign in/out, the SPA shell, and the candidate paths.
  Wrapped in try/except so a DB hiccup in the gate can never take the app down.
  **Deliberately narrow.** Anyone holding even ONE grant is untouched, so no existing role
  changes behaviour. `current_user_id` returns None for the LEGACY shared login (no row, so no
  grants to read), which therefore passes through rather than being locked out while it is
  still the fallback door — removing it is separate work. Candidates are unaffected: they are
  not signed in at all, their link is the credential.
  **UI**: `GatedLayout` in `App.tsx` renders a new `NoAccess` screen when authenticated with an
  empty `permissions` map — one card saying an administrator needs to grant a role, plus Sign
  out, and **deliberately no navigation** (links that all 403 are worse than saying so). It
  waits on `usePermissions().isPending` first: "not known yet" is not "denied", the same trap
  that locked authors out of the pool editor in `4877edd`.
  This leaves a new person in a KNOWN, harmless state — present in `app_users`, holding nothing
  — which is the starting point an admin elevates from (a "new users" group and the admin
  screens are later work, not this).
  Verified live: created a real zero-grant account → `/api/sessions`, `/api/question-pools`,
  `/api/roles` ALL 403 `no_access` (all three were reachable before), while `/api/me` +
  `/api/me/permissions` stay 200 so the person can be told why; admin reaches all three; **HR
  reaches `/api/sessions` 200 and is still refused `/api/question-pools` 403** — proving this is
  not all-or-nothing and the existing RBAC still does its own job. Test account deleted after.
  `tsc --noEmit` + `vite build` clean. **NOT done:** per-route permissions across `app/main.py`
  and the feature routers (the real end state — this gate only catches people holding NOTHING;
  someone with `pools.view` alone can still reach the dashboard), and no test.
  Files: `app/main.py`, `ui/web/src/App.tsx`.

- **Sign in with a Centific work account (Microsoft Entra ID) — AB#34519 — COMMITTED,
  local-docker verified against the REAL tenant, NOT deployed and NOT configured in
  Azure.** The platform had two ways in and NEITHER identified a person: one shared admin
  password, and `DEV_LOGIN_ENABLED`'s chooser (any account, no password). That makes the
  question-pool approval controls unenforceable in practice — no self-approval, no signing
  twice, every decision attributed — because one human can satisfy all three from a shared
  account and the ledger faithfully records it.
  **The one idea: Microsoft answers WHO; `app/rbac.py` still answers WHAT THEY MAY DO.**
  Roles are deliberately NOT driven from Entra security groups — that makes every role change
  an IT ticket, the opposite of why the permission grid is editable data. So the whole flow
  converges on `auth.issue_cookie(email, user_id)`, the SAME call `api_dev_login` already
  makes, and nothing downstream changes: no route, no permission check, no React component.
  **New `app/entra_auth.py`** holds everything Microsoft-facing, so deleting the dev chooser
  later is a removal rather than an untangling: `settings()`/`is_configured()` (the one switch
  both the routes and the SPA read), `start_login` (auth URL + the state/nonce pair),
  `finish_login` (the server-to-server code exchange, authenticated by the client secret),
  `find_or_create_user`. **Matching is `entra_oid` FIRST, email ONCE then stamp the oid on** —
  people change surnames and therefore email addresses, and matching on email forever makes a
  marriage silently create a second account holding none of their roles. The whole team is
  already seeded by email in `rbac_seed.py`, so their first sign-in links rather than
  duplicates. An unknown Centific employee is created with **zero grants**: signed in, able to
  do nothing until an administrator gives them a role — authenticated is not authorised.
  **Routes** (`app/main.py`): `GET /auth/login` (redirect out), `GET /auth/callback` (verify
  state → redeem code → match → issue OUR cookie → `/app/`), `GET /auth/logout` (front-channel:
  MICROSOFT telling us the person signed out elsewhere — NOT the platform's own Sign out, which
  is still `POST /api/logout` and involves Microsoft not at all), plus `GET /api/auth/methods`
  so the login page renders what this deploy actually offers instead of guessing.
  **`state` and `nonce` are load-bearing, not ceremony**: state proves the person arriving at
  the callback is finishing a sign-in WE started (without it someone can hand your browser a
  completed login as THEM, and you carry on in their account); nonce rides inside the id_token
  and proves it was minted for THIS sign-in, not replayed. Parked in a short-lived
  `entra_flow` cookie whose `secure` flag follows the redirect_uri's SCHEME — hardcoding it
  would silently break local development on http://localhost.
  **Fails safe, at TWO levels.** No credentials → `is_configured()` False → `/auth/*` return
  404 AND `{"microsoft": false}` hides the button. Hiding a button is courtesy; the 404 is the
  control (a stale tab, a bookmark or curl ignore the UI) — the same belt-and-braces the dev
  routes already use. **So the code is inert until someone supplies secrets, and a deploy
  without them behaves exactly as it does today.**
  **Deliberately NOT done:** the shared password and dev chooser still work — removing the only
  functioning door while proving a new one is how you lock yourself out. They come out once
  Entra sign-in has been used in anger. Also NOT done: `deploy/aca/main.bicep` has no `ENTRA_*`
  params, so production knows nothing about this yet; turning it on there needs four secrets
  plus `ENTRA_REDIRECT_URI` set to the Front Door `/auth/callback` (an EXACT string match at
  Microsoft's end, not a prefix). And no tests — the callback needs a real Microsoft round trip.
  **App registration** (IT, 2026-10-21): tenant `9b415834-…`, client `821c619a-…`, single
  tenant, delegated `openid profile email User.Read` only. **The client SECRET EXPIRES
  2027-04-13 — nothing in the code warns you; sign-in simply stops one morning.**
  Verified: `py_compile`; `tsc --noEmit` + `vite build` clean; `msal==1.31.1` installs into the
  base image; the module builds a correct authorize URL against the REAL tenant; live against
  the local stack — `/api/auth/methods` → `{"microsoft":true,"dev":true}`, `/auth/login` 302s to
  `login.microsoftonline.com/9b415834-…` and sets the flow cookie, a FORGED `state` is refused
  and bounced back with a readable reason, `/auth/logout` clears the session, and the button is
  in the served bundle. Files: `app/entra_auth.py` (new), `app/main.py`,
  `ui/web/src/pages/Login.tsx`, `ui/web/src/lib/auth.ts`, `deploy/requirements/base.txt`
  (+`msal`), `.env.example`, `deploy/local/.env.example`.

- **Muting the mic stranded the interview permanently — fixed, plus a watchdog for every
  other way audio can stop (AB#34362) — COMMITTED, local-docker verified, NOT deployed to
  Azure.** Found live by the operator: mute mid-answer and the AI never spoke again.
  **Root cause:** the VAD declares an utterance over by HEARING a tail of silence, and
  silence is still frames. Mute stops frames ENTIRELY, so the endpoint can never fire,
  `candidate_speaking` (= `vad_state in (SPEAKING, PAUSED)`) latches True, and
  `turn_taking.decide` returns NO on every tick for the rest of the interview — the AI is
  structurally forbidden from speaking. Proven from one session: `[WEB-MIC] packets_in=2823
  (in 100.6s wall, = 28.1 pkts/s)` = 56s of audio in a 101s interview, the VAD's `ts=` frozen
  across 42s of wall-clock, and no `→ DONE` after the mute. The silence prompt could not
  rescue it either: every VAD flap RESET its clock.
  **(1) The browser now says so** — `candidateEngine.toggleMic` sends `{type:"mic_muted"}`;
  `broadcaster` routes it (`set_mic_mute_callback`, same pattern as the playback ack and
  coding dispatch); `azure_app._wire_bus_to_broadcaster` wires it to the director. Mute was
  built wholly in the browser ("stop sending audio") and the server's only sense is the audio
  that just stopped — so it is told in words instead.
  **(2) `Director.on_mic_muted` treats a mute mid-utterance as an endpoint**, DELEGATING to
  `on_vad_event("endpoint_detected", …)` rather than reimplementing it, so noise rejection,
  the STT finalize, the barge-in cancel and the tracer event behave exactly as for a real one.
  **(3) An audio-starvation watchdog in `_tick`** (`AUDIO_STARVED_TIMEOUT_MS`, 5000) forces the
  same endpoint when `candidate_speaking` and no VAD event for N ms, from ANY cause — dropped
  socket, revoked mic permission, OS-suspended tab, or a cached old bundle that never sends the
  message. New `_last_vad_event_ms` means "the VAD is still talking to us at all", deliberately
  NOT `last_any_speech_ms` ("we heard speech"), which is the wrong question. This closes the
  class; (1) only closes the common case.
  **(4) The muted notice rides the SILENCE PROMPT, not the mute** — `_MUTED_THINK` via the same
  per-turn `<think>` channel as `_SILENCE_REASK_THINK`, with Rule 4 in `policy/turn_taking.py`
  gaining `mic_muted` + `muted_prompt_fired` (fire once per mute, then WAIT). **An earlier
  version announced it immediately and was WRONG**: `candidate_speaking` includes PAUSED, which
  is just the VAD's 600ms tail, so a candidate who finishes an answer and then mutes — the
  natural order — is always still "speaking". Observed: a complete 159-char question, muted
  465ms after the last word and 135ms before the endpoint would have fired by itself, got
  "you're muted" INSTEAD of an answer. On the silence prompt there is no reply to displace.
  **(5) UI**: the status read "Listening…" while the mic was off; now "Muted — AVA can't hear
  you" (and the orb drops to `idle`). "AVA is speaking" still outranks it — muting your own mic
  does not stop her talking.
  **Also fixed, a bug introduced by this work:** a synthesized endpoint stamped `_elapsed_ms()`
  (wall clock, cumulative across resumes) where the VAD's `ts_ms` (audio received, restarts at 0
  per connection) belongs — 135s apart after a resume, writing `ts=140787ms` into a stream of
  ~5000ms events and corrupting anything in events.jsonl that orders by it (transcript, trace,
  eval sectioner). New `_last_vad_ts_ms`; it is also the truer value — the utterance ended at
  the last audio actually received.
  Backward compatible: an old cached bundle sends nothing, the broadcaster ignores the absence,
  and the watchdog catches the latch 5s later. Verified: `py_compile` on all backend files;
  `tsc --noEmit` + `vite build` clean; images rebuilt and every change confirmed INSIDE the
  running container (not just the build log); exercised live — mute mid-sentence now yields
  `[MIC] muted mid-utterance` → `[VAD] → DONE` → `[DIRECTOR] dispatch trigger=endpoint` → the
  AI speaks. **NOT done:** no test on `policy/turn_taking.decide` — it is a pure function and
  the once-per-mute rule is the piece most likely to regress SILENTLY (nothing crashes; the
  only symptom is AVA nagging a muted candidate every 15s). Files: `engine/brain/core/
  director.py`, `engine/brain/core/policy/turn_taking.py`, `engine/orchestrator/web/
  broadcaster.py`, `deploy/azure_app.py`, `ui/web/src/lib/candidateEngine.ts`,
  `ui/web/src/pages/Candidate.tsx`.

- **`feature/ui-design-system` merged into `feature/livekit-media` (Harika's 16 commits, 12 Oct) —
  the whole app restyled onto one light design system.** Brought in: shared tokens + a light
  component layer (`ui/web/src/styles/{tokens,light}.css`), a light app shell with an in-shell 404
  and a crash screen (`ErrorBoundary`), and every admin page restyled (login, home, dashboard,
  Shortlist, role, interview set-up, schedule, session detail, question pools, approvals, pool
  review, cadence editor + phase modals). Her candidate transcript opened by default; we changed
  it back to closed until the candidate opens it from the dock (user decision).
  **Resolved against the observer removal:** her branch predates it, so `Observer.tsx/.css` and
  `ScorecardPanel.tsx` (restyled there) stay DELETED; the dashboard's re-added "Join live" /
  "Observer link" were dropped; the candidate side panel keeps her improvements (per-turn
  timestamps, consecutive lines grouped into one bubble, "Jump to latest")
  but NOT the Chat tab, unread badge, interviewer camera tile or remote-screen view;
  `TranscriptView` takes her light colours minus the live "interviewer" row type. Also removed a
  dead "Join live →" button on the session page that the observer removal had missed (it linked
  to the retired observer URL, which only redirects back). Verified: `tsc` + `vite build` clean;
  suite 894 passed, 1 long-standing failure.

- **Avatars on LiveKit (3D + Simli) · lobby probe no longer claims the interview · TTS
  truncation made visible — NOT COMMITTED, local-docker + real-Chrome verified, NOT deployed.**
  (1) **Avatars over LiveKit.** Both avatars lip-synced only from whole-utterance PCM, which a
  live WebRTC track never hands the page, so they were hidden when LiveKit was offered. Now the
  page taps the AI track with the mic worklet (→ 16 kHz PCM16, 20 ms frames) and streams it to
  the avatar (`AvatarSink.stream`: `feed`/`utterance`/`end`/`cut`) for the FACE only; the voice
  stays on the LiveKit element, so latency, volume, the playback ack and the recording do not
  change and there is no server or LiveKit cost. A "run" = one stretch of AI speech from its
  first audible frame until it is heard out (nothing is fed in silence); utterances inside a
  run start where the previous one ends (contiguous) or at the next audible frame (a gap).
  TalkingHead: its speaker muted (`setMixerGain(0)`) while streaming, word timings spread over
  the utterance length, which the server now sends: `audio_end.duration_ms` (the TTS client
  already computed it; the orchestrator's `TTS_AUDIO_END` event dropped it). Simli: the feed
  re-chunked into its 30 ms writes; its audio element was already muted by design. The
  WebSocket path is unchanged (`speak()` turns TalkingHead's voice back on). The "Photoreal"
  (Simli) lobby choice, dropped in the candidate redesign (`7b4c294`), is back; the dead
  `avatarAvailable` flag is gone. Simli NOT verified live: no `SIMLI_API_KEY` in any local env
  (it falls back to the orb). TalkingHead verified in real Chrome (Playwright, fake devices,
  system Chrome): on LiveKit, one peer connection, no interview WebSocket, the avatar fed only
  during speech, 36 / 64 visemes scheduled for 3.4 s / 5.3 s runs. Harmless, pre-existing:
  TalkingHead logs "Cannot resume a closed AudioContext" when it rebuilds its graph at 16 kHz.
  (2) **Bug: real browsers never used LiveKit.** The lobby's connection check opened a probe
  WebSocket to the REAL interview URL; the shard claimed the interview, leased a Speech slot and
  created an idle WebSocket-mode runner from the lobby, and Start then found that session and
  answered `{"transport":"websocket"}`. Bots skip the lobby, so every earlier LiveKit test
  missed it. The probe now carries `?probe=1` and is answered by the gateway (and the shard's
  own route, for the single-app deploy) without starting anything — which also stops every
  lobby holding a Speech + admission slot on the WebSocket path.
  (3) **Found, made visible, NOT auto-fixed: Azure cancels a streaming synthesis part-way,
  intermittently** — seen twice today on the same question (0.8 s of a 2.8 s sentence; the
  candidate hears it cut off). Not tied to the text (12/12 retries of that sentence were whole).
  `azure_tts_client` never checked the stream status, so the turn looked normal; it now logs
  the cancellation with Azure's error and counts `interview_tts_truncated_total{key_id}` (and a
  throttle when it is one). A retry would repeat what was already heard — needs a decision.
  Also noted, pre-existing, not changed: on the WebSocket path the page can keep showing "AVA is
  speaking" between turns. Verified: 2 new tests in `tests/test_livekit_ops.py` (duration on
  `audio_end`; the probe never reaches a shard); full suite **894 passed**, 1 long-standing
  failure; `tsc` + `vite build` clean.

- **LiveKit operations: Grafana row · pool/worker metrics through Redis · LiveKit load test ·
  `recording_finalize` job (branch `feature/livekit-media`) — NOT COMMITTED, local-docker verified,
  NOT deployed (no Azure work, as asked).** (1) **Metrics + dashboard row** "LiveKit media &
  scaling" (`deploy/observability/dashboards/interview.json`, panels 18–22): room-join time by stage
  (agent connect / candidate ready, measured from "the page may join" / recorder warm-up, from egress
  start), "finished playing" delay per transport (expected end of playback → the page's ack; the
  silence timer waits on it), egress outcomes (started/stopped/start_failed/stop_failed from the session,
  complete/failed from the worker), hand-offs by reason — counted ONCE per interview (the runner's own
  LiveKit failure and `_room_start`'s "no usable room" can both see the same one; the
  `broadcaster.handover` flag dedupes) — and resumes by mode, the placement queue, and mic
  self-heals. `_hand_off` now takes `reason=` (the metric label). (2) **Monitoring what Prometheus
  can't reach:** pool replicas and the worker have no ingress, so each publishes its own /metrics text
  to Redis (`metrics:pushed:{replica}`, every 10 s, expires after 3 missed pushes) and the gateway
  serves them merged at `/metrics/pushed` — re-grouped per family (concatenating would repeat HELP/
  TYPE, which Prometheus rejects), every sample labelled `instance`+`tier`, plus the placement queue
  depth and a replica count. Prometheus job `pushed` with `honor_labels: true` (local
  `prometheus.yml` + the ACA entrypoint, which writes the token to a file so the config dump it logs
  can't leak it). `azure_app`'s /metrics body is now `_render_metrics()`, shared by the scrape and the
  pool's publisher. Worker also counts `interview_jobs_total{type,outcome}`. Bicep: `metricsToken`
  (gateway + obs app), and the worker gets `livekitEnv` (finalize asks LiveKit). (3)
  **`scripts/loadtest_livekit.py`**: ramps N parity-check bots per level; the bot now ENDS an
  interview still running at `--max-s` (it used to walk away and leave it running) and reports time
  to the greeting. (4) **`recording_finalize`**: LiveKit uploads only after the stop and writes
  nothing if it fails, so the file can't say "uploading" or "failed" — a per-part manifest
  (`<part>.ogg.json`) does: session writes recording → processing and enqueues the job; the worker
  polls LiveKit (≤90 s, then queue retry) and writes ready (duration, size) / failed (error).
  `recording-parts` returns `livekit_parts`; the admin tab shows finishing / player / failed and polls
  while unsettled. "ready" but no file the app can see = `unavailable` (local stack: app blob = disk
  fallback, egress = real Azure, so locally the player never appears — in ACA both are the same
  account/container). Not an events.jsonl event on purpose: the eval job re-downloads events.jsonl from
  blob and would drop a line the worker appended locally. Verified: new `tests/test_livekit_ops.py`
  (14); full suite **892 passed**, 1 long-standing failure; `tsc` clean; local stack with 2 pool
  replicas — both + the worker reported through the gateway and Prometheus scraped them under their own
  instance labels; a 246 s bot interview on the pool fed every new series (join p50 ~1.2 s connect /
  ~1.2 s candidate / ~2.4 s recorder, ack lag p50 ~2.1 s over 24 acks, egress started/stopped/complete)
  and its finalize job wrote `ready`, 245.3 s. `scripts/loadtest_livekit.py --levels 1,2
  --make-tokens --cleanup`: 3/3 on LiveKit, ended naturally, goodbye heard, recall 0.84/0.89, response
  p50 4.3/4.7 s, greeting 6.4/7.5 s; 3 interviews deleted after. **Finding (NOT fixed, needs a browser
  check):** the "finished playing" lag is measured from when the audio should have ended (audio_end +
  the sink's remaining queue, not audio_end itself, which is just TTS generation end), and showed the
  page can ack an utterance BEFORE it plays: it counts "heard" from the `audio_start` message's
  arrival, so the previous sentence's tail plus a ≥600 ms gap acks both at once (11/26 acks early, up
  to 2.5 s). Early acks are counted apart (`interview_playback_ack_early_total`, "early share" on the
  panel), each ack's signed `lag_ms` is on its `audio_playback_finished` event; impact is small since
  the LiveKit sink stays busy while audio is queued. Proposed fix in the plan doc §12.

- **`feature/text-interview-mode` merged into `feature/livekit-media` up to `69cb7ff` (its tip) —
  this branch now INCLUDES RBAC.** Brought in: the question-pool maker-checker / RBAC work
  (`app/rbac.py`, `app/rbac_seed.py`, `app/approval_service.py`, `PoolApprovals`/`PoolReview`/
  `PoolWorkflow`; previously excluded from this branch on purpose) and the light candidate-UI
  redesign (`Candidate.tsx` rewrite, `AiOrb.tsx`, `CandidateLive.css`, Terms/Preparing/Dino polish).
  Conflicts: `/session-info` (both handlers) and `candidate_ws` kept this branch's resume-safe
  `interview_over` rule + the LiveKit offer (their side was the original reopen fix, already here as a
  cherry-pick + correction); `candidateEngine.ts` likewise; `tests/test_session_info_status.py` kept
  ours (their 4 tests + 8). **`Candidate.tsx`: their redesign kept, observer removed from it** — it
  was built before the observer removal, so it still had a Chat tab (two-way text with the observer),
  an Interviewer tile, a "watching" pill, "Interviewer is speaking", a remote shared-screen panel,
  and BOTH JPEG pumps (camera tile + screen thumbnail "because observers still read these frames").
  All removed; the camera tile and screen thumbnail are display-only; the side panel is the
  transcript only; "Having trouble?" (opened the chat) removed; lobby copy says "recorded"; avatar
  choices hidden when LiveKit is offered. Verified: 878 passed, 1 long-standing failure; `tsc` +
  `vite build` clean. Nothing is left on `feature/text-interview-mode` that this branch lacks.

- **Media-server scaling Phases 2–4: no WebSocket for LiveKit interviews · fenced leases · Redis
  placement · drain · autoscaled session pool · per-turn checkpoints (branch `feature/livekit-media`)
  — local-docker verified with a 2-replica pool, NOT deployed; `MEDIA_TRANSPORT` still defaults to
  `websocket`.** Plan + measurements: `docs/media-server-scaling-plan.md` §9–11.
  **Phase 2:** the page starts with `POST /api/candidate/{token}/start` and does everything through
  the LiveKit room (data channel, topic `ctl`, chunked > 2000 chars); `/session-info` only OFFERS
  LiveKit (no token — a token there let any tab join as the candidate); the shard mints a per-tab
  token after the one-tab check; `_finish_session` is the ONE teardown (WS handler and
  `_supervise_session` both use it); the orphan reaper counts "in the room" as connected.
  **Phase 3:** fenced registry lease (`reg:fence:{token}`; atomic renew/restore/LOST; release only
  our own entry; LOST → the runner stops as a hand-off); Redis placement (shared queue + per-replica
  inbox + 10 s liveness keys; dead fenced owner taken over at once); a room interview HANDS OFF
  instead of falling back in place (`broadcaster.handover` — the runner's `finally` AND the
  `attach_db_lifecycle` hook skip `completed`); SIGTERM drain; `session-pool` Bicep app (no ingress,
  KEDA `metrics-api` on `/scaler/pool`), `terminationGracePeriodSeconds: 600`, gunicorn
  `--graceful-timeout 600`; compose `--profile pool`. **Phase 4:** turn checkpoints at each AI
  dispatch (turns + tracker snapshot + phase time used; not for coding/scenario phases), mid-phase
  resume (`session_resumed mode=turn`, `_RESUME_MIDPHASE_THINK`, phase clock keeps its used time),
  turn-mode collapse by checkpoint `seq`, and the v2 eval now reads the collapsed view (it
  double-counted resumed phases). **Bugs found by the live runs, fixed:** LiveKit audio never resumed
  after the agent's connection was rebuilt (interview froze) → source self-heals a stalled reader +
  gained `mic_health/stats`; resumed replica's egress overwrote the first file → one file per runner;
  hand-off marked `completed` by the event hook + token helper refused the room → resume loop;
  `checkpoint_written` never recorded (a `kind=` kwarg collided with `tracer.event`'s first param).
  **Verified:** 809 passed, 1 long-standing failure; `tsc` clean; Bicep 0.48.1 compiles; live: 13/13
  room edge cases on the pool (owner inbox, second tab refused, refresh, takeover, hand-off to a
  shard in 0.2 s), full interviews with 0 WebSocket frames, SIGTERM drain → conversation continued
  60 s in place → resumed on the other replica `mode: turn` → natural end, 2 egress parts, collapse
  kept 7/7 answers; 3 simultaneous starts spread 2/1 over the pool. **Open:** C (sets
  `sessionPoolPerReplica`), KEDA ramp test + canary (Azure, needs go-ahead), by-ear browser checks,
  1H. New tests: `tests/test_livekit_control.py`, `tests/test_midphase_resume.py` (+ updates).

- **LiveKit media plane Phases 1C–1G + two fixes found on the way (branch `feature/livekit-media`)
  — COMMITTED + PUSHED, local-docker verified, NOT deployed to Azure; `MEDIA_TRANSPORT` defaults
  to `websocket`, so nothing changes until it's switched on.** Three commits:
  (1) **`claim()` adopts a token left by a dead runner** (`app/session_tier/lifecycle.py::_adopt`):
  after a shard restart, a reconnect within the registry TTL hit the "already mine" branch, got no
  Speech lease and crashed on `no azure_speech_key` — crash-resume after a shard restart was broken.
  (2) **One tab per live interview + recording parts**: the page sends `?client=<tab id>`
  (sessionStorage; the gateway forwards it); a different tab while the owner is connected gets
  `session_in_use` (no auto-reconnect — two tabs used to steal the session back and forth); a
  refresh/new device after the owner left may take over. Recording starts on `hello` (a refused tab
  never records), and `part=new` makes a refreshed page record `<kind>.partN.webm` instead of
  overwriting `<kind>.webm` from chunk 0 (it used to). Admin Recording tab plays every part.
  (3) **LiveKit**: 1C — `LiveKitAudioSink` gained `play_sync` (one feeder task, 20 ms frames) and the
  `expect_playout`/`mark_played`/`playout_done_event` ack contract (busy until sent AND acked);
  bounded agent connect; the shard announces `media_transport`. 1D — page joins on `hello`, server
  waits for the candidate (mic + AI subscribed) before greeting, else falls back; ack derived from
  the AI track going quiet 600 ms after `audio_end` (Ayush's fixed 350 ms timer replaced); mic-only
  publish of the lobby's own track; source follows the newest mic track (refresh); AI track mixed
  into the browser recording; avatars hidden when LiveKit may be used. 1E — audio-only
  room-composite egress → `<token>/recording/livekit-audio.ogg`, started before the greeting
  (greeting waits ≤`LIVEKIT_EGRESS_START_WAIT_S` for it), stopped 1.5 s after the goodbye; admin
  "Server recording" player. 1F — `scripts/livekit_parity_check.py`: WS vs LiveKit both ended
  naturally with the goodbye heard; 90% vs 88% words transcribed; response median 3.99 vs 4.74 s
  (≈0.4 s LLM variance, ≈0.3 s LiveKit Cloud round trip — local WS never leaves the machine); egress
  260 s of audio for a 263 s interview. Cost: first audio ~8 s after Start with LiveKit (recorder
  wait ~3.5 s). 1G — `main.bicep`/`provision.sh` take `mediaTransport`/`livekit*`; egress reuses the
  provisioned storage key (compiles, Bicep 0.48.1). **Open:** by-ear checks in a real browser
  (barge-in, captions, Wi-Fi drop), C with LiveKit on, Azure deploy + canary (needs go-ahead),
  avatars over LiveKit, camera/screen in egress (bandwidth/cost decision); 1H (remove the WS path)
  deliberately not done — it's the fallback. Verified: full suite 773 passed, 1 long-standing
  failure (`test_plan_from_cadence_assigns_sensible_plugins`); `tsc` + `vite build` clean; the
  middle commit (2) built and tested on its own. New tests: `tests/test_livekit_sink.py`,
  `tests/test_recording_parts.py` (`.gitignore` `tests` → `git add -f`).

- **Hasini's reopen-a-finished-link fix brought onto `feature/livekit-media` (cherry-pick of
  `0f0df6a` from `feature/text-interview-mode`), plus a correction so it can't block crash-resume —
  COMMITTED, NOT pushed/deployed.** Her guard (entry below) refused any `completed`/`cancelled`
  token. But the session runner's teardown `finally` in `deploy/azure_app.py` writes
  `status="completed"` on EVERY exit, crashes included, and a crashed runner KEEPS its resume
  checkpoint so the candidate's auto-reconnect can resume. Applied as-is, the guard would have sent
  that candidate to "interview over" instead of back into their interview. (Her note that
  `in_progress` stays resumable covers a whole-shard restart, where the `finally` never runs, but
  not a runner crash.) The rule now lives in ONE place,
  `app/coordination/interview_checkpoint.interview_over(token, status)`: `cancelled` → over;
  `completed` → over only when no checkpoint is left (it's cleared on every clean end, including the
  candidate pressing End); Redis unreachable → over (a resume needs Redis anyway). It's used by the
  `candidate_ws` gate and by BOTH `/session-info` handlers, which now return `interview_over`.
  `candidateEngine.ts` checks that instead of comparing `status` itself. (`app.main`'s handler is
  sync, so it hops to the loop with `anyio.from_thread.run`, and only for completed/cancelled.)
  Merge notes: `/session-info` keeps both `status` and `livekit`; the candidate engine already
  handled `session_ended` on this branch (added with the observer removal), so the two
  `case "session_ended"` additions were merged into one. Her entry's references to `observer_ws` /
  `observerEngine.ts` describe the source branch; both are gone here. Verified: 12 tests in
  `tests/test_session_info_status.py` (8 new: every status × checkpoint combination, Redis down,
  and the crashed-vs-finished split through the real `/session-info`); `tsc --noEmit` clean. Files:
  `app/coordination/interview_checkpoint.py`, `deploy/azure_app.py`, `app/main.py`,
  `ui/web/src/lib/candidateEngine.ts`, `tests/test_session_info_status.py`.

- **Access screens + menu by role — COMMITTED, local gateway checked, NOT deployed.** A signed-in
  person's menu comes from one list (`ui/web/src/lib/workspace.ts`): Question Author sees Question
  pools, Question Checker sees pools with Approvals, HR sees Shortlist / Dashboard / New interview,
  Platform Admin sees those plus Access. A real person with no role, or one switched off, gets a
  single card and no menu. Access (`/api/access`, `app/access_service.py`) edits people, teams, the
  approval chain and the role grid. The clickable development accounts stay, behind
  `DEV_LOGIN_ENABLED`; typing a seeded email uses the shared admin password and the same switch.
  A review verdict other than approved or rejected is refused before anything is written. Interview
  APIs are still cookie-only. Docs: `docs/rbac-authentication-reference.pdf` (sign-in and Access)
  and the pool reference now points there instead of saying there is no admin screen. The old
  `docs/rbac-and-entra-auth-plan.md` is removed. Not done: Microsoft sign-in, and `require()` on
  the interview routes.

- **Maker-checker / RBAC: clean-up + review-bug fixes — COMMITTED, tests verified, NOT
  deployed.** Clean-up with no behaviour change: new `app/constants.py` (state/action/verdict
  strings + `GLOBAL_TEAM`), repeated code turned into shared helpers, one-line docstrings,
  comments trimmed, across `app/{approval_service,rbac,rbac_seed,question_pools,
  question_pool_routes}.py`. Bugs fixed, each pinned by a test that fails on the old code:
  (1) **critical** — a partial per-question review published the approved questions BEFORE
  any refusal ran (an author or a wrong-team checker could put content live, and the ledger
  showed only "returned"). `review()` is now one transaction: all signing checks first, then
  verdicts, then approved + published + returned rows + `pool.published` audit; (2) an author
  could move another team's pool into their own chain by saving it with their team (the
  editor auto-filled it) — PUT now checks the pool's CURRENT team and the new one, and the
  editor fills the team only for new pools; (3) "Approve all" and queue "Approve" published
  different content — an all-approved review now publishes the draft as-is (`stage_draft`);
  (4) review/history leaked another team's drafts and comments to anyone with `pools.view`
  (now 403); (5) force publish is scoped to `pools.publish` on the pool's team; (6) a force
  publish after a return read as "draft" while live; (7) concurrent checkers could both sign
  (per-pool Postgres advisory lock `_lock`), and a failed commit could leave a pending pool
  with no draft (draft cleanup now runs only after commit); (8) a partial review at step 1 of
  a multi-step chain published immediately — nothing goes live before the last step; (9) a
  review must give a verdict for every question; (10) `PoolWorkflow.tsx` showed Submit/force
  publish for pools with no draft (new `hasDraft` prop from the real file state; no workflow
  bar on built-ins). NOT fixed (small): the editor still allows typing into a pending pool,
  some buttons the server refuses are still shown, and the editor doesn't refresh after an
  action. Verified: 177 pool/RBAC tests pass (10 new); `tsc --noEmit` + `vite build` clean.
  Files: `app/{approval_service,constants,main,question_pool_routes,question_pools,rbac,
  rbac_seed}.py`, `ui/web/src/components/PoolWorkflow.tsx`,
  `ui/web/src/pages/QuestionPoolEditor.tsx`, `tests/test_pool_{approvals,question_review}.py`.

- **Fix: reopening a candidate's link after their interview finished let them start a SECOND
  interview on the same token — COMMITTED, local-docker verified, NOT deployed to Azure.**
  Found live: a candidate who completed a voice interview could open the exact same link in a
  fresh tab and the Lobby would offer Start again, spinning up a brand-new `InterviewSession`
  from `warm_up`. Root cause: the server already marks `sessions.status="completed"` correctly
  on a natural end (`engine/orchestrator/scheduled_session.py::attach_db_lifecycle`), and clears
  the in-memory `_token_sessions` entry for that token right after — but **nothing re-checked
  that DB status on the next reconnect**. A reconnect with no live `_token_sessions` entry is
  the exact same signal whether the candidate "hasn't started yet" or "already finished", and
  `candidate_ws` (`deploy/azure_app.py`) treated it as the former unconditionally: it went
  straight to `session_lifecycle.claim()` + spawning a fresh `_session_runner()`. The observer
  link already had the right guard for this (`observer_ws`, same file) — re-reading the DB
  status on a dead handle and refusing with `session_ended` for `completed`/`cancelled` — it was
  simply never carried over to the candidate path. Three-part fix, voice/video only (the TEXT
  modality already does this correctly via `app/text_service.py`'s `ready`→`in_progress` gate +
  `ended` flag, untouched here):
  (1) **The actual gate** — `candidate_ws`'s "no live session" branch now re-reads
  `db.get(token)["status"]` before claiming; `completed`/`cancelled` → sends `session_ended` +
  closes instead of spawning. Deliberately does NOT block `in_progress` (the legitimate
  crash-resume case — a shard restart mid-interview still must be resumable) or `ready` (hasn't
  started yet) — same two-value condition the observer path already uses.
  (2) **The frontend didn't know how to react** — `candidateEngine.ts` only had a `case
  "session_end"` (live interview ending); added `case "session_ended"` alongside it (both route
  to the same Done-screen teardown), mirroring how `observerEngine.ts` already handles both
  signals identically.
  (3) **Cleaner UX, not just a refusal** — `/session-info` (both `app/main.py`'s and
  `deploy/azure_app.py`'s twin handlers, which an existing comment already requires to "agree")
  now also returns the session's `status` (the DB row was already being read for `role`/
  `record_enabled`; the field just wasn't surfaced). `candidateEngine.ts::loadSessionInfo()`
  checks it on page load and jumps straight to the Done screen for a `completed`/`cancelled`
  token — before ever showing the Lobby or attempting a WS connect. This is a courtesy early
  exit only; fix (1) is what actually prevents a restart, so skipping past the Lobby check
  can't itself let anyone through.
  Verified: 4 new tests in `tests/test_session_info_status.py` (status surfaces correctly for
  `completed`/`cancelled`/`ready`/no-token); full suite **786 passed**, same 17 pre-existing
  environment-gap failures (fakeredis `eval` unsupported — unrelated); `tsc --noEmit` +
  `vite build` clean; local stack rebuilt from a full base+tiers build (both `app/main.py` and
  `deploy/azure_app.py` are baked into `Dockerfile.base`, so a tier-only rebuild would have
  silently kept serving the old behavior) and verified via served bundle hash. The WS-level gate
  itself (`candidate_ws`) has no unit test — this repo has no existing test harness for
  `deploy/azure_app.py`'s websocket routes (they pull in the full session-tier/broker/Redis
  stack), so it's covered by the `/session-info` tests + manual verification instead. Files:
  `deploy/azure_app.py`, `app/main.py`, `ui/web/src/lib/candidateEngine.ts`,
  `tests/test_session_info_status.py` (new).

- **Live observer feature REMOVED — an interview is the AI and the candidate only (AB#34239, under
  scaling feature AB#34236; branch `feature/livekit-media`) — COMMITTED + PUSHED, local-docker
  verified, NOT deployed to Azure.** Business decision: no human joins or
  intervenes (no watching, push-to-talk, hints, chat or live notes). Decisions taken with the
  user: remove ALL of it; keep PAST interviews readable; do it on this branch.
  **Backend:** `/ws/observer` route (shard + gateway proxy, which now has no `kind` — candidate
  only — and no longer forwards admin cookies to shards, which existed only for observer auth);
  the whole observer pipeline in `azure_app.py` (hint callback, PTT gate, the SECOND Azure STT
  stream for the TA's voice, `OBSERVER_PTT_FORCE_RELEASE_MS`); in `broadcaster.py` the per-client
  roles/labels, presence roster, PTT lock, observer mic queue, the `0x01`/`0x02` audio tags, and the
  `video_frame`/`chat`/`record_control` relays (883 → 487 lines; `0x00` AI tag KEPT — the browser
  parses it); the director's PTT methods, dispatch gate and `observer_hint` injection (+ the
  `build_context` param); the latency engine's hold/discard/release of an AI turn and its
  `discarded` record guard (every removed branch only fired when push-to-talk set the flag, so
  normal interviews behave identically); `InterviewSession.barge_in_now`; three `SessionState`
  fields; `app/coordination/pubsub.py` (observer fan-out + hint relay — unused in production);
  `observer_link` in every approve/list response; `POST …/notes` (creation) and both chat-file
  routes; the dead Jinja `session_live.html` + `session_live.js` + their `admin.css` sections.
  **Kept for past data:** `Speaker.INTERVIEWER`, the event viewer / v1 transcript / sectioner
  handling of TA turns, the `observer_notes` table + `GET …/notes`, the Session page's "Observer
  (TA)" labels and read-only notes. Old `/admin/sessions/{token}/live` and
  `/app/sessions/{token}/live` links now REDIRECT to the interview's detail page.
  **Frontend:** deleted `Observer.tsx/.css`, `observerEngine.ts`, `ChatPanel.tsx`,
  `ScorecardPanel.tsx`; Dashboard "Join live →" + "Observer link"; the post-approve Observer link.
  `VideoTiles` lost the observer "stack" layout and remote tiles; `FrameCapture` became
  `ScreenSharePreview`. **Found while doing it:** the candidate's camera AND 1080p screen JPEG
  snapshots (encoded every 150–400 ms and uploaded) went ONLY to observers — so every candidate
  was paying that CPU + upload for nothing. Both pumps (and `grabJpeg`) are gone; the previews
  and the recording are unchanged. Bundle 664 → 615 KB. The lobby's "the interviewer will see your
  video / screen is visible to the interviewer" text was false without an observer (the AI sees
  neither) — now says "recorded". The candidate engine also handles `session_ended` now (only
  the observer engine did), so an admin deleting a live interview ends the candidate's session
  cleanly instead of a dropped socket. The legacy vanilla `ui/candidate/` page (reachable only via
  the old `/candidate/?token=` redirect) lost its observer lane/pill/tiles too.
  **NOT changed — needs a decision:** the Terms & Conditions (`interviewTerms.ts`) still say
  audio of "any human interviewer or proctor who joins" is recorded. Now moot rather than false,
  but it is versioned consent text — rewording means bumping `TERMS_VERSION`; left for legal.
  Verified: `tsc --noEmit` + `vite build` clean; full suite **744 passed, 1 failed** (the
  long-standing `test_plan_from_cadence_assigns_sensible_plugins`; 2 fewer tests = the deleted
  pubsub round-trip and observer-refusal tests); tests now ASSERT `observer_link` is absent.

- **LiveKit gaps fixed: the token package is in the tiered images, and the GATEWAY's
  `/session-info` now hands out the room (AB#34238) — COMMITTED + PUSHED on `feature/livekit-media`,
  NOT deployed; LiveKit still switched OFF.** (1) `livekit-api==1.2.0` moved into
  `deploy/requirements/base.txt` (it was only in the monolith's `deploy/requirements.txt`, which
  the tiered images never install, so minting crashed there). Base, because both the gateway
  (candidate token) and the session shard (agent token) mint; dry-run in both images adds only
  `PyJWT` + `livekit-protocol` and changes no installed version. (2) The candidate's
  `/session-info` is answered by the GATEWAY (`app.main`), but the `livekit` block existed only in
  `deploy/azure_app.py`'s copy — so the page could never learn the room and would silently stay on
  the WebSocket. The block is now ONE helper, `engine/orchestrator/livekit/tokens.py::
  candidate_join_info(room, row)`, called by BOTH handlers so they cannot drift again.
  **Also closed, found while fixing it:** `/session-info` is unauthenticated, and the original block
  minted a join token for ANY `token` string — i.e. free rooms on our per-minute LiveKit account for
  anyone who calls it. The helper now mints only for a real, LIVE interview: a sessions row with
  status `ready`/`in_progress` and not a role template (the same "active" definition `app/db.py`
  uses, and the same reasoning `/api/simli/token` is gated on a real interview). Verified: new
  `tests/test_livekit_session_info.py` (16; each fix proven by removing it — gateway 3 fail,
  package 1 fails, the live gate 6 fail); full suite **746 passed, 1 failed** (the long-standing
  `test_plan_from_cadence_assigns_sensible_plugins`); and LIVE: a token minted by the helper JOINED
  a real LiveKit Cloud room as `candidate-…`. **Still open for the cloud step:**
  `deploy/aca/main.bicep` has NO LiveKit settings (Ayush's note says the ACA secrets were "already
  wired", presumably by hand — a fresh template deploy would not have them).

- **`deploy/Dockerfile.base`: apt now fetches over HTTPS — COMMITTED + PUSHED on
  `feature/livekit-media`.** The office network blocks plain HTTP (port 80) to `deb.debian.org`,
  so `apt-get update` timed out and the WHOLE base build failed at step 2 — it had only ever worked
  from a warm layer cache, and Docker Hub publishing a new `python:3.12-slim` digest invalidated
  that cache. One `sed` rewrites `debian.sources` to `https://` before `apt-get update`; the slim
  image already ships `ca-certificates`, so HTTPS verifies before anything is installed. Harmless
  for Azure (`az acr build` reaches HTTPS fine). Also observed on this network and NOT fixed in code:
  PyPI is slow enough that pip's 15 s read timeout drops large index pages (it reported
  `pillow … (from versions: none)` — a fetch failure, not a version conflict), and Docker Hub pulls
  crawl at ~60 KB/s. If a full `deploy/build_tiers.sh local` fails that way, either retry on a
  better connection or overlay the current code onto the existing images (only dependency changes
  need the full build).

- **New branch `feature/livekit-media`: Ayush's LiveKit foundation brought forward onto current
  code, WITHOUT RBAC (AB#34237; scaling work is tracked under feature AB#34236) — merged + pushed, NOT built/deployed, LiveKit still switched OFF.**
  Composition: starts at `d0b7b16` (feature/text-interview-mode just before the RBAC work), then
  merges Hasini's Visual Scenario Analysis (`f9c2333`, built pre-RBAC so it has no dependency on
  it) and Ayush's `feature/phase1-livekit-media` (5 commits, authorship kept: Phase 0 mic-silence
  detector + per-shard cap; LiveKit config/tokens/audio adapters; server-side room join; the
  `livekitMedia.ts` browser module). The four RBAC commits (`136aa13`, `4877edd`, `8b58f50`,
  `b1cc36d`) are deliberately EXCLUDED — verified: none are ancestors, no `app/rbac*.py` /
  `approval_service.py` / pool-approval pages, and nothing imports them. WHY a fresh branch rather
  than finishing on Ayush's: his was 55 commits behind, and the files LiveKit touches
  (`azure_app.py`, `interview_session.py`, the candidate audio code) are the ones everyone else keeps
  changing, so one late merge would have been the riskiest possible kind.
  **Conflicts resolved:** `azure_app.py` `/session-info` — both sides added a field; kept BOTH
  (`modality` + `livekit`). `ui/web/package-lock.json` — kept `livekit-client` **2.22.3** (already
  present as a dependency of Md Azhar's Simli avatar, `simli-client`) over Ayush's 2.21.0: it
  satisfies his `^2.21.0`, keeps the avatar on the version it was tested with, and avoids two copies;
  root lock lists it as a direct dep so `npm ci` stays in sync. `CLAUDE.md` — every work-log entry
  from both sides kept. The auto-merged `interview_session.py` was checked line by line (every line
  either side added is present; no duplicated `def`, the silent auto-merge hazard noted below).
  **Verified:** `tsc --noEmit` + `vite build` clean; full suite **730 passed, 1 failed** (the
  long-standing `test_plan_from_cadence_assigns_sensible_plugins`, not this change). **Test-env
  note:** the Redis-coordination tests need `lupa` (fakeredis runs Lua with it — without it 17 of
  them fail with no code problem), and the suite must run where `livekit` (rtc) is installed, i.e.
  the SESSION image (the slim base image lacks it, so `test_scenario_director_glue.py` fails to
  import `engine.brain.core.director` → `aec_processor` → `livekit.rtc`).
  **Two gaps in Ayush's work, NOT yet fixed (next step on this branch):** (1) `livekit-api`
  (token minting) was added to `deploy/requirements.txt` — the MONOLITH's file — so the tiered
  images, which install `deploy/requirements/*.txt`, don't have it and minting a room token would
  crash; belongs in `deploy/requirements/base.txt` (gateway + session both mint). (2) the LiveKit
  block was added only to `deploy/azure_app.py`'s `/session-info`, but in the tiered deploy the
  browser's `/session-info` is answered by the GATEWAY (`deploy/gateway_app.py` reuses
  `app.main`, whose copy has no LiveKit block) — so the SPA would never learn the room details and
  would silently stay on the WebSocket. Credentials for LiveKit Cloud + recording storage
  (`LIVEKIT_*`, `LIVEKIT_EGRESS_AZURE_*` → `interviewagentdata`/`sessions`) are set and verified
  locally in `deploy/local/.env`. Plan: `docs/livekit-implementation-plan.md`.

- **New interview phase type: Visual Scenario Analysis (`scenario_analysis`) — schema, admin
  authoring, full runtime, and question-pool integration — COMMITTED, local-docker verified,
  NOT deployed to Azure.** Voice/video interviews only (text interviews are schema-refused —
  `CadencePlan._check_video_only_phases`); shows the candidate an image/video/audio clip per
  item and asks a question about it, with up to `max_followups` verifier-driven probes against
  `coverage_tags` — the same follow-up mechanics `question_pool` items already use.
  **(1) Schema** (`engine/brain/cadence/schema.py`): `ScenarioMedia` (kind/ref/filename/
  mime_type, kind↔mime_type cross-checked) + `ScenarioItem` (id/media/question/coverage_tags/
  max_followups) + `PhaseDef.scenario_items` / `.is_scenario_analysis`; mutually exclusive with
  coding/written_response/adaptive_difficulty. New `ASSET_RULES["video"]` in
  `question_types.py` (`.mp4/.mov/.m4v`, 100MB — `.webm` deliberately excluded, already claimed
  by the audio rule).
  **(2) Admin authoring** — `ScenarioPhaseModal.tsx` (new), mirroring `CodingPhaseModal`'s
  shell: per-item media upload (kind inferred from the file), question, coverage tags,
  reorder, add/remove. `cadence_service.{append,update,remove}_scenario_analysis_phase` +
  `app/main.py` routes (`add_scenario_phase`/`update_scenario_phase`/`remove_scenario_phase`),
  stateless YAML-mutation builders like every other phase-editor route.
  **(3) Runtime** — pure `engine/brain/core/scenario_cursor.py` (new, `ScenarioStage`/
  `ScenarioCursor`, fully decoupled from asyncio/LLM/WS for testability); `CadenceTracker`
  per-phase `ScenarioCursor` state + budget/exhaustion handling; `conversation_context.
  build_context()` injects the current item's question + follow-up tags into the rubric;
  `director.py` dispatches/acks media (`on_scenario_media_ack`), suppresses dispatch
  non-blockingly while media plays, and detects skip-phrases; WS plumbing end-to-end
  (`broadcaster.py` scenario event relay, `launcher.py` + `deploy/azure_app.py` outbound/inbound
  tables — BOTH needed identical edits, one for local/non-tiered mode and one for the tiered/
  cloud session tier this Docker setup actually runs); `candidateEngine.ts` scenario state +
  ack sender; `ScenarioMediaPanel.tsx` (new) — candidate-facing image/video/audio panel with
  its own fullscreen button, autoplay-block/manual-stop/error handling, resync-safe (never
  autoplays after a reconnect).
  **(4) Cadence-editor chat support** — `config/phase_blacklist.json` gained a `scenario_analysis`
  entry (chat can't attach media, so "add a scenario phase" is refused with a reason pointing at
  the admin UI instead of silently failing); `config/prompts.yaml`'s `cadence_phase_revise`
  prompt now documents the `scenario_items` shape and is told NEVER to invent/replace a `media`
  block (an already-uploaded file it cannot see) — it may only edit wording/tags/max_followups
  on an EXISTING item; `features/eval/sectioner.py::_cadence_phase_modes` recognizes
  `scenario_items` the same way it already recognizes `coding_question_ids`, so eval segments
  attribute the phase correctly instead of reading as generic.
  **(5) Bug found + fixed during follow-up testing:** "Add phases → Visual Scenario Analysis"
  always opened in CREATE mode even when a scenario phase already existed, silently appending a
  SECOND phase. Fixed by routing to the existing edit path (`CadenceReview.tsx`'s
  `onPickScenario` checks `existingScenarioPhaseId` first) plus a backend 400 guard in
  `cadence_service.append_scenario_analysis_phase` refusing a second phase outright. Deliberately
  did NOT add a schema-level "at most one scenario phase" validator — it would reject loading
  any cadence that already has two (a real, reachable state the UI now surfaces a warning banner
  for instead of crashing on).
  **(6) UI consistency pass** (candidate + admin), in response to screenshots of the shipped
  feature looking inconsistent with the rest of the app:
  - Candidate panel position: moved into the LEFT column directly below the AI/candidate video
    tiles (`Candidate.tsx`), ahead of the screen-share preview, so an active screen share doesn't
    push it further down.
  - **Real root cause of "the panel still shows up way down the page" (not the DOM order, which
    was already correct):** `VideoTiles.tsx`'s own wrapper sets `height:"100%"` internally (so it
    can fill an observer's full-height column); once the candidate page's outer shell was fixed
    from `minHeight:100vh` to a bounded `height:100vh` (to stop the whole page — header included —
    from scrolling past viewport height), that percentage FINALLY resolved against a definite
    ancestor height and `VideoTiles` started stretching to fill the ENTIRE left column, leaving a
    tall blank gap below the small tile row before the scenario panel (or anything else) appeared.
    Fixed by wrapping `<VideoTiles>` in a plain, non-flex, auto-height `<div>` in `Candidate.tsx` —
    an auto-height block isn't a definite containing block, so the percentage resolves to
    auto/no-effect and `VideoTiles` sizes to its actual content again. `ScenarioMediaPanel.tsx`'s
    own media cap also shrunk `56vh → 38vh` so it rarely needs the column's scrollbar at all.
  - "Add phases" dropdown: `AddPhasesMenu.tsx` was a bespoke `role="menu"` popup, then briefly a
    bare native `<select>` (matched the text interview's `<select className="input">` LOOK but
    its open state is an unstyleable native OS popup), and is now a proper MODAL mirroring
    `AddPhaseModal.tsx`'s exact shell (dialog overlay → `.card` → header+✕ → labelled "Phase
    type" select + helper line → Cancel/Continue footer). Its only job is routing to
    `CodingPhaseModal`/`ScenarioPhaseModal`, so the primary button reads "Continue", not "Save".
  - Saved scenario items in the cadence-review screen (`CadencePhaseBlock.tsx`) no longer render
    as a custom emoji-badged card (🖼/🎬/🎙) — they use the SAME plain `phase-pool`/`phase-q`/
    `phase-q-tag` list classes comprehension/translation/transcription/coding already render
    through, so every phase type now looks consistent.
  **(7) Question pools: `scenario_analysis` as a full pool kind** (`app/question_pools.py`) —
  parity with how comprehension/translation/transcription/coding are already integrated: new
  `SCENARIO_KIND`, a `ScenarioBlock` on `PoolQuestion` (reuses the cadence schema's own
  `ScenarioMedia` — a pooled question's media reference drops into a phase with no conversion),
  mutual exclusivity with `coding`/`written_response` enforced in `QuestionPool._finalise`. A 4th
  `list_kinds()` entry (`app/question_pool_routes.py`) with a new `asset_media` field kind
  (uploads any of image/video/audio, inferring which — one control instead of three) and a
  `count` field kind (plain 0–5 integer, unlike `duration`'s seconds↔minutes conversion); an
  asset-copy branch in `questions_for_phase()` (the "pool is a template" guarantee — applying a
  pooled scenario question copies its media into the target interview's own session folder).
  Frontend: `questionPools.ts` types/helpers, `QuestionPoolEditor.tsx` gained the `asset_media`/
  `count` renderers (mirrors `ScenarioPhaseModal.tsx`'s own upload-kind inference, duplicated
  locally rather than shared — same precedent as that file's own `FsButton`), and
  `ScenarioPhaseModal.tsx` gained an "Add from a question pool" dropdown mirroring
  `CodingPhaseModal`'s existing pool-import pattern.
  Verified: 108 new backend tests across the three original prompts
  (`test_scenario_{analysis,phase_endpoints,cursor,runtime,director_glue}.py`) + 8 new pool-kind
  tests in `tests/test_question_pools.py` (62 in that file now); full suite **684 passed**, same
  **19** pre-existing environment-gap failures (fakeredis `eval` unsupported, stale dashboard/
  eval-plan/jobs assertions — none touch any file this feature changed); `tsc --noEmit` +
  `vite build` clean throughout; local stack rebuilt repeatedly and verified via served bundle
  hash. `tests/` is `.gitignore`d (line 61) — the five scenario test files needed `git add -f`.
  Files: `engine/brain/cadence/schema.py`, `engine/brain/cadence/question_types.py`,
  `engine/brain/core/scenario_cursor.py` (new), `engine/brain/core/cadence_tracker.py`,
  `engine/brain/core/conversation_context.py`, `engine/brain/core/director.py`,
  `engine/orchestrator/web/broadcaster.py`, `engine/orchestrator/web/launcher.py`,
  `deploy/azure_app.py`, `app/main.py`, `app/cadence_service.py`, `app/question_pools.py`,
  `app/question_pool_routes.py`, `config/phase_blacklist.json`, `config/prompts.yaml`,
  `features/eval/sectioner.py`, `ui/web/src/components/{AddPhasesMenu,ScenarioPhaseModal,
  CadencePhaseBlock}.tsx`, `ui/web/src/pages/{ScenarioMediaPanel,Candidate,CadenceReview,
  QuestionPoolEditor}.tsx`, `ui/web/src/lib/{cadence,cadenceReview,candidateEngine,
  questionPools}.ts`, `ui/web/src/theme.css`, `tests/test_scenario_{analysis,phase_endpoints,
  cursor,runtime,director_glue}.py` (new), `tests/test_question_pools.py`.

- **Question pools: per-question approve/reject · read-only that is actually read-only ·
  built-in pools open again — COMMITTED + PUSHED (`4877edd`), local-docker verified, NOT
  deployed to Azure.** Extends the maker-checker flow landed in `136aa13` (Md Azhar: RBAC
  tables, `app/rbac.py`, `app/approval_service.py`, the draft/published blob split).
  **(1) A checker now judges each QUESTION, not the pool as a whole.** New
  `pool_question_reviews` ledger (append-only like the pool one, so a reviewer changing
  their mind supersedes rather than erases; latest row per cycle+question wins),
  `approval_service.review()`, and `POST`/`GET /api/question-pools/{id}/review`. The
  OUTCOME is derived from the verdicts rather than being a second choice the checker could
  forget to make — all approved → publish (the existing path, untouched); some approved →
  publish those and return the rest; none → a plain rejection. **"Approve all" is the same
  route** with every verdict set to approved, so the bulk button cannot drift from ticking
  every box by hand. `review()` DELEGATES to the existing `approve()`/`return_pool()`
  transitions, so the self-approval / wrong-team / signed-twice refusals apply automatically
  instead of being reimplemented beside them.
  **The rule that makes partial approval safe** (`question_pools.publish_approved`): approved
  questions are MERGED into the published pool **by id**, so rejecting an EDIT leaves the
  previously published version of that question exactly as it was — a candidate keeps getting
  the last reviewed wording, never nothing. The draft is rewritten to hold only the REJECTED
  questions, i.e. precisely the work outstanding; reject nothing and the draft is deleted,
  which is the pre-existing all-or-nothing behaviour as the special case rather than a second
  code path. Pinned by `test_a_rejected_edit_leaves_the_live_question_alone`.
  **(2) Read-only was COSMETIC.** `mayEdit` in `QuestionPoolEditor.tsx` guarded five
  decorative things (the heading, the Cancel/Back label, the Save button) while **35
  interactive controls stayed live** — so a checker could retype every question in a form that
  silently never saved. The whole form is now wrapped in ONE `<fieldset disabled>`
  (`.form-lock` in theme.css), which natively disables every control inside it *including ones
  added later*: read-only cannot drift out of sync with the markup the way 35 separate
  `disabled={!mayEdit}` props would. CSS keeps the text legible — a reviewer still has to READ
  the questions to approve them.
  **That change made a latent race consequential**: `usePermissions()` is a react-query hook,
  so `can()` answers "no" while it is in flight, and the page's loading gate waited only on the
  POOL. A brief `false` used to hide a button; once it drove a fieldset it locked the whole
  screen and told the author "editing belongs to its authors", which was untrue. The page now
  waits on permissions too — **"not known yet" is not "denied"**; fail-closed is right for
  authorization and wrong for a request still in flight.
  **(3) Built-in pools 404'd on open (PRE-EXISTING, not from the RBAC work).** `list_pools`
  advertises the shipped pools via `_builtin_pool_summaries`, but `get_pool` only ever searched
  Blob — and built-ins live inside the image, so the list offered something the detail route
  could not serve. The card's "Read-only" was also inert `<span>` text rather than a link, so a
  shipped pool could not be opened at all. `get_pool` now falls back to `_builtin_pool_load`
  and returns it read-only (`editable: false`, no workflow — the way to change a built-in is
  Duplicate, which produces an ordinary draft that goes through review like anything else).
  **UI**: new `ui/web/src/pages/PoolReview.tsx` — the checker's screen, one row per question
  with Approve/Reject, an Approve all button, a sticky counter (`8 approved · 2 rejected ·
  1 undecided`) because the actions would otherwise be a long scroll from the decision on a
  40-question pool, and a REQUIRED comment on rejection. Nothing is sent until "Submit review",
  so a half-finished pass is never visible to the author. Deliberately no editing on that
  screen — mixing review with authoring is what made the old flow confusing. The author's side
  shows each rejection **against the question it refers to** in the editor, not as one lump at
  the top. The Approvals queue's primary action is now "Review N questions" (Approve all
  demoted), since approving from a queue row means signing content you have not read.
  **Also fixed while here**: `question_reviews()` returned nothing once the cycle closed —
  which is exactly when the AUTHOR looks, because a return is what sent them there. It now
  falls back to the most recent cycle carrying verdicts, pinned by a test.
  Verified: **124 passed** (11 new); `tsc --noEmit` + `vite build` clean; exercised end to end
  against the local podman stack (submit → review 2 of 3 → approved half live, rejected one
  back with its comment, author reads it on that question). Confirmed unchanged: a checker is
  refused on all five write routes, cross-team approve, self-approval, HR on any pools route;
  and an author editing a pool mid-review is already refused with a 409 by the existing code.
  **NOT done**: admin screens for users/roles/teams (`admin.users`/`admin.teams`/
  `admin.permissions` are defined and enforced but nothing in the frontend calls them, so
  access still changes by editing `app/rbac_seed.py`), and notifications (a checker finds work
  only by opening the queue). Files: `app/approval_service.py`, `app/question_pool_routes.py`,
  `app/question_pools.py`, `db/models.py`, `tests/test_pool_question_review.py` (new),
  `ui/web/src/pages/PoolReview.tsx` (new), `ui/web/src/pages/{QuestionPoolEditor,QuestionPools,
  PoolApprovals}.tsx`, `ui/web/src/lib/questionPools.ts`, `ui/web/src/App.tsx`,
  `ui/web/src/theme.css`.

- **Shortlist: closed-role guard on new work + match/rank explanation — COMMITTED + PUSHED
  (`dfb456a`, merged with the invite-email work at `1008940`), local-docker verified, NOT
  deployed to Azure.** Closing a role is a decision that hiring for it has stopped, so it must
  refuse everything that STARTS new work — matching more resumes, creating/approving the
  cadence template, creating interviews, approving/generating links — while an interview already
  issued is left untouched (a candidate holding a link has been told they're being interviewed;
  reopening lifts the restriction). New `_require_open()` in `features/shortlist/role_routes.py`,
  enforced server-side (a hidden button doesn't stop a stale tab or a direct call) on all four
  write paths — `match_resumes`, `ensure_cadence_template`, `create_interviews`,
  `approve_interviews` — each returning 409 with the same remedy: *"this role is closed — reopen
  it to match more resumes or create interviews"*. Frontend mirrors it: `RoleDetail.tsx` disables
  the resume chooser, Match & rank, and Set up interviews with the reason shown inline;
  `InterviewSetup.tsx` disables Create + hides Approve & generate links the same way. Also two
  small chart components split out of the inline JSX (`StatesDonut.tsx` — the shared, validated
  donut primitive; `RoleInterviewsChart.tsx` — the per-role ring) so both the role-states chart and
  the per-role interviews chart share one rendering path, and `roles.ts` gained
  `invalidateRole(qc, id)` so every mutating hook (approve, create, remove-candidate, set-email)
  refreshes the role/interviews/roles queries the same way instead of each hook inventing its own
  invalidation list. Verified: 2 new tests (`test_a_closed_role_refuses_every_path_that_starts_new_work`,
  `test_closing_a_role_leaves_the_interviews_already_sent_alone` — 36 in the file); full suite
  **588 passed** post-merge, same pre-existing failure categories as baseline (redis/fakeredis-
  dependent coordination/broker/session_tier tests, the eval-plan coding-default, one stale
  coding_endpoints assertion) — no regressions; `tsc --noEmit` + `vite build` clean; base+gateway
  images rebuilt and exercised live against the running stack (200 while open, 409 on all four
  paths while closed, 200 again after reopening, all three new UI strings present in the served
  bundle). Also explained on request (not a code change): resume ranking is `HybridScorer.score()`
  — one LLM call PER resume, sequential (a `for` loop in `match_resumes`, not batched into one
  call and not parallelized with `asyncio.gather`), blended `0.65×llm_score + 0.35×keyword_coverage`
  (`SHORTLIST_LLM_WEIGHT`), on the `SLOW_PROVIDER`/`SLOW_MODEL` stack (currently
  `openai/gpt-oss-120b` via OpenRouter, Groq preferred) — the same slow-LLM handle the interview
  brain uses, not a dedicated ranking model. Flagged, not yet acted on: at real scale (dozens of
  resumes per role) the sequential loop means one slow call per resume serially — an
  `asyncio.gather`-with-semaphore change is a small win if batches grow. Files:
  `features/shortlist/role_routes.py`, `ui/web/src/pages/{RoleDetail,InterviewSetup}.tsx`,
  `ui/web/src/components/{StatesDonut,RoleInterviewsChart}.tsx` (new), `ui/web/src/lib/roles.ts`,
  `tests/test_roles_endpoints.py`, `docs/rbac-and-entra-auth-plan.md` (brainstorm doc, later removed; the working guide is `docs/rbac-authentication-current.md`),
  `docs/email-invites-plan.md` (new, brainstorm doc, superseded by the invite-email feature above).

- **Candidate invite email — automated send on approve, via SMTP (new `app/notifications/`
  package) — local-docker verified end to end with a real mailbox, NOT deployed to Azure.**
  When an admin clicks Approve and the interview has a candidate email, the app now emails
  them the interview link automatically — no extra click, no new UI flow beyond one optional
  form field. **New**: `app/notifications/email_client.py` (`send_email()` via `aiosmtplib`,
  reads `SMTP_HOST`/`PORT`/`USERNAME`/`PASSWORD`/`FROM_ADDRESS`/`USE_TLS` from the environment —
  same shape as the separate, NOT-part-of-this-repo `smtp-notification-service` reference
  project; `is_configured()` lets a dev/test box with no mailbox just skip sending rather than
  error) + `app/notifications/templates.py` (`build_invite_email()`, a pure function building the
  subject/HTML — inline-styled, no external CSS/fonts, since mail clients strip both; colors
  pulled from `ui/candidate/style.css`'s own tokens). **Wired into the job queue**, not sent
  inline: `app/jobs/jobs.py` gained `INVITE_DISPATCH` (`"invite_dispatch"`, a job type the
  registry's own comment had reserved for exactly this) + its handler; `app/main.py`'s
  `_maybe_enqueue_invite()` is called right after `candidate_link` is minted in every approve
  path (`cadence_approve`, `api_cadence_approve` → its now-shared `_approve_session()` helper,
  and therefore the Shortlist bulk-approve route too) — a no-op, not an error, when the email is
  blank. **Data**: `sessions.candidate_email` (nullable, mutable — unlike `record_enabled`/
  `modality` which are immutable after creation), via the existing `_ADDED_COLUMNS` pattern in
  `db/engine.py`, no Alembic needed. **Resume-email fallback**: if the admin leaves the field
  blank, `app/jobs/jobs.py::_resume_summary` now tries `engine.orchestrator.resume_parser.
  extract_email()` (a regex best-effort scan) on the parsed resume text and fills the column —
  runs right after parsing, before the slower LLM summarize call, so it's normally in place well
  before the admin reaches Approve; never overrides an email the admin actually typed in. **UI**:
  `Schedule.tsx` gained an optional "Candidate email" field; `CadenceReview.tsx`'s post-approval
  screen shows "Sending the invite to x@y.com now" or "No candidate email on file" next to the
  existing candidate/observer links. **Shortlist integration** (found while merging with
  `b687924`): the Shortlist bulk-create-interviews flow already resolved each candidate's email
  (`cand.get("email")`) but never passed it into `ScheduleForm` — fixed in
  `features/shortlist/role_routes.py` so Shortlist-sourced interviews get the automated email
  too, not just ad-hoc-scheduled ones. **Merge note**: that same upstream commit refactored the
  approve logic into a shared `_approve_session()` helper as a plain `def`; the auto-merge landed
  this feature's `await _maybe_enqueue_invite(...)` inside it, which doesn't parse — fixed by
  making the helper `async def` and updating both its call sites (`app/main.py`,
  `features/shortlist/role_routes.py`'s bulk-approve route). **Real send verified** against three
  actual mailboxes while researching the SMTP-provider question (see
  `docs/candidate-email-mailbox-requirements.md` for the full writeup): a personal Gmail account
  (works, via an app password — but only off networks that block `gmail.com` at the DNS level,
  which this org's office Wi-Fi does); an individual Centific M365 account (no self-service app
  password — Conditional-Access-only tenant, would need an Exchange admin to grant both
  Authenticated SMTP and an MFA exclusion); and a newly-created personal Outlook.com account
  (Microsoft disables SMTP AUTH by default on new consumer mailboxes too, `535 5.7.139`, no
  self-service toggle — the POP/IMAP "let devices and apps use POP" setting does NOT control
  this, confirmed by testing). **Conclusion, not yet actioned**: needs a real IT-provisioned
  M365 shared mailbox with Authenticated SMTP explicitly enabled (or the Microsoft Graph API as
  the alternative durable path) — see that doc for the exact ask. Verified: **17 new tests**
  (`tests/test_notifications.py` — template rendering/HTML-escaping, SMTP call args for both
  587/STARTTLS and 465/implicit-TLS, the not-configured no-op path; `tests/
  test_resume_email_fallback.py` — `extract_email()` found/absent/first-match/false-positive
  cases, plus the fill-when-blank / never-override-when-entered / stays-blank-when-nothing-found
  integration tests) — **NOTE: `.gitignore` line 61 is `tests`**, same pre-existing repo quirk
  noted on prior features; both new test files needed `git add -f`. Full suite **553 passed**,
  same ~19 pre-existing failures as baseline (redis/fakeredis-dependent coordination/broker/
  session_tier tests, the stale `active`→`active_count` dashboard assertion, the eval-plan
  coding-default, missing coding-UI static fixtures — all confirmed pre-existing, not
  regressions); `tsc --noEmit` + `vite build` clean. Files: `app/notifications/{__init__,
  email_client,templates}.py` (new), `app/jobs/jobs.py`, `app/main.py`, `app/sessions.py`,
  `db/models.py`, `db/engine.py`, `engine/orchestrator/resume_parser.py`,
  `features/shortlist/role_routes.py`, `ui/web/src/pages/{Schedule,CadenceReview}.tsx`,
  `ui/web/src/lib/cadenceReview.ts`, `deploy/requirements/base.txt` (+`aiosmtplib`), `.env.example`,
  `deploy/local/.env.example`, `tests/test_notifications.py` (new),
  `tests/test_resume_email_fallback.py` (new), `docs/candidate-email-mailbox-requirements.md` (new).

- **`default.yaml` no longer hardcodes a candidate's project in `resume_deep_dive` — NOT
  COMMITTED (user commits), not yet built/deployed.** Root cause of a reported "Generate Cadence
  gives everyone the same generic interview": scheduling a candidate with ONLY a resume (no JD, no
  cadence requirements) skips the LLM entirely (`app/sessions.py::create_draft`'s `needs_llm` gate
  — "resume alone isn't enough signal to bother generating", a deliberate, KEPT decision — see
  below) and falls back to the static built-in `default.yaml`. That file's `resume_deep_dive`
  phase told the AI to *"Pick the 'NVIDIA VSS – GenAI Video Intelligence Pipeline - Bozzutos' from
  the candidate's resume"* — a specific PAST candidate's project, left over from testing — so every
  candidate landing on the default got asked about a project that usually wasn't theirs, even
  though the AI already has THEIR real resume in context every turn via `resume_summary`
  (`CandidateProfile` → `ConversationContext`, unaffected by this file). Fixed by replacing it with
  a generic instruction — pick the candidate's own most substantial project from their resume
  (already in context) and probe it — so the phase now personalizes per-candidate at runtime with
  zero extra LLM cost, instead of naming a fixed project. **Deliberately NOT changed** (user
  decision, discussed first): the `needs_llm` trigger stays as-is — a resume-only schedule still
  uses the fast static default rather than paying for an LLM cadence-generation call; when a JD or
  cadence requirements IS supplied, `generate_cadence_yaml` already builds a bespoke,
  resume-specific cadence correctly (confirmed: `assemble_description` always includes the parsed
  resume, and the `cadence_converter` prompt already says "pick a project from the resume" rather
  than inventing one). `default_text.yaml` had no equivalent hardcoding (checked, left untouched).
  Verified: edited YAML re-parses + re-validates against `CadencePlan`; grepped the whole repo for
  the literal string — zero remaining references outside this file and an unrelated illustrative
  code comment in `director.py` (left alone, not a bug). No tests referenced the hardcoded text, so
  none broke. Files: `engine/brain/cadence/default.yaml`.

- **Role-stage chart recoloured · editable candidate email on the links screen — NOT COMMITTED
  (user commits), local-docker verified, NOT deployed.**
  **(1) Chart colours:** the ordinal ramp (one hue, light→dark) read as a single colour at donut
  size, so the three stages now use three DISTINCT hues from the categorical palette. Validated,
  not eyeballed, and with ALL pairs rather than just adjacent ones because in a donut any slice
  can be compared with any other: `validate_palette.js "#3987e5,#d95926,#199e70" --mode dark
  --pairs all` → lightness band, chroma floor, CVD ΔE 9.4 (≥8), normal-vision ΔE 20.9 (≥15), all
  ≥3:1 vs surface.
  **(2) Email instead of the URL, editable.** The created-interviews screen showed each
  candidate's full interview URL — long, unreadable, and already one click away on Copy. It now
  shows the candidate's EMAIL, editable in place (click → input → Enter/Save, Esc to cancel), with
  a "+ add email" affordance when blank. WHY editable: the address is extracted from the resume
  BY AN LLM, so it is a guess that is regularly wrong or missing, and it is the one field on that
  screen that decides whether a real person receives their interview. Blanking it is allowed — a
  missing address beats a wrong one. New `PUT /api/roles/{id}/candidates/{cid}/email` +
  `role_store.update_candidate_email` (trims). Needed a real link, so `sessions.candidate_public_id`
  was added alongside `role_public_id`: `sessions.candidate_name` is only a display copy taken at
  creation, and the email lives on the candidate row, so without it the screen could not say which
  person to update.
  **(3) Answered, no change needed — is the Shortlist's resume context the same as an interview's?**
  The EXTRACTION is identical: both call `engine.orchestrator.resume_parser.parse_resume()`, so
  the text is the same. What each does next differs BY DESIGN because they answer different
  questions — Shortlist feeds the raw text to the scorer, which returns
  `Candidate{name,email,phone}` plus the fit score and coverage; an interview feeds it to
  `summarize_resume()`, which returns `_ResumeSummary{name, projects[], tech_stack[]}` (titles
  only — details are probed live) and is stored as `sessions/{token}/resume/summary.txt`.
  Role-created interviews get that same summary: `create_interviews` writes the candidate's stored
  resume into the new session and `create_draft` enqueues the ordinary `resume_summary` job.
  Verified: 1 new test (26 in the file); full suite **559 passed**, same **20** pre-existing
  failures; `tsc --noEmit` + `vite build` clean; local stack rebuilt — column migrated, new colours
  and the email affordances present in the served bundle. Files: `db/models.py`, `db/engine.py`,
  `app/sessions.py`, `features/shortlist/{role_routes,role_store}.py`,
  `ui/web/src/components/RoleStatesChart.tsx`, `ui/web/src/lib/roles.ts`,
  `ui/web/src/pages/InterviewSetup.tsx`, `tests/test_roles_endpoints.py`.

- **Blank page after approving a role cadence · bulk "Approve & generate links" — NOT
  COMMITTED (user commits), local-docker verified, NOT deployed.**
  **(1) Blank page:** the post-approve redirect went to `/shortlist/{id}/interviews`; the route
  is `/shortlist/:roleId/interview` (SINGULAR), so React Router matched nothing and rendered an
  empty document. Fixed, and — because a path that matches nothing rendering NOTHING is what
  made a one-character typo read as a crash — `App.tsx` gained a `path="*"` fallback ("Page not
  found" + a way back). There was no catch-all before, so every mistyped or stale admin URL did
  this.
  **(2) Bulk approve.** New `POST /api/roles/{id}/interviews/approve` turns the role's created
  drafts into live interviews and returns a link per candidate; the created-interviews screen
  gained "Approve & generate links" and then renders a per-candidate row with Copy link + Edit.
  The approve CORE was EXTRACTED to `app.main._approve_session(request, token, row, yaml)` and
  both the single-interview route and the batch call it — the coding backfill, cadence validation
  and evaluation-plan gate are exactly the checks that must not be skipped at the moment a live
  link goes out, so there is one implementation, not two. Partial failure is reported per
  candidate rather than failing the batch (one bad plan must not deny links to everyone else),
  and a token belonging to another role is refused without launching it.
  **Trap found and closed while testing:** in LOCAL single-laptop mode the single-active guard
  cancels a previously-approved session when the next one launches (fixed orchestrator ports), so
  a batch approve there silently left every interview but the last `cancelled`. The batch now
  REFUSES with a clear message when `CLOUD_MODE != 1` and more than one token is passed — inert
  in every container deploy (the gateway runs `CLOUD_MODE=1`, verified). Also noted: the stub
  cadence used by the template test helper is not schema-valid, which is why the gate rejected
  it — the fixtures now use the real built-in cadence, i.e. the gate was right and the test was
  wrong. Verified: 4 new tests (25 in the file); full suite **558 passed**, same **20**
  pre-existing failures; `tsc --noEmit` + `vite build` clean; local stack rebuilt — route live
  and auth-gated, and all four new strings present in the served bundle. Files: `app/main.py`,
  `features/shortlist/role_routes.py`, `ui/web/src/App.tsx`, `ui/web/src/lib/roles.ts`,
  `ui/web/src/pages/{CadenceReview,InterviewSetup}.tsx`, `tests/test_roles_endpoints.py`.

- **Shortlist: role-level interview mode · three role states + donut · approving a template
  never mints a link — NOT COMMITTED (user commits), local-docker verified, NOT deployed.**
  Follow-up to the role-cadence-template work below.
  **(1) Mode belongs to the ROLE**, picked in the New role form on the Shortlist page (new
  `roles.modality`). Every candidate for a role takes the same interview, so it is not a
  per-template or per-interview choice; the cadence template and every interview created from it
  inherit it. The selector on the setup page is gone (it only ever appeared before a template
  existed, so it was invisible once one did) — that screen now shows a VOICE/TEXT pill.
  **(2) Approving a cadence template no longer generates a candidate link.** It went through the
  normal approve path, which spawns an orchestrator and returns candidate/observer links — i.e.
  it handed out a WORKING interview link for a session that is only ever meant to be a plan.
  `api_cadence_approve` now branches on `is_template`: persist + `status='ready'` (which means "a
  person reviewed this", the gate on creating interviews), no spawn, no links, and it returns
  `role_public_id` so the page navigates back to the role's setup screen. Button reads "Approve
  cadence". Pinned by a test asserting the response carries no `candidate_link`.
  **(3) Three role states + a donut.** `sourcing → interviewing → closed`, derived in
  `role_store.role_state()` so the chart, the cards and any future filter cannot disagree:
  closed is a DECISION (`roles.status`, admin-set — a role whose interviews are all done but
  where no offer is out is genuinely not closed), interviewing means ≥1 real interview exists,
  sourcing is everything else. That count needed a real link: `sessions.role` is a free-text
  TITLE that repeats and is edited, so it cannot answer "which interviews belong to this role" —
  new **`sessions.role_public_id`**, stamped by `create_interviews`. Templates are excluded from
  the count (a plan is not somebody being interviewed) — pinned by a test.
  **The chart** (`ui/web/src/components/RoleStatesChart.tsx`, inline SVG, no library) sits above
  the cards it summarises. The stages are ORDERED, so it uses an **ordinal ramp** (one hue,
  light→dark) rather than arbitrary categorical hues, and the three steps were VALIDATED, not
  eyeballed: `validate_palette.js "#86b6ef,#3987e5,#1c5cab" --mode dark --ordinal` → lightness
  monotone, adjacent ΔL ≥ 0.06, light end 2.63:1 vs surface, hue spread 3°. A donut's known
  weakness is comparing close values (1/1/1 arcs are indistinguishable), so every stage is also
  direct-labelled with its count and the hole carries the total; text stays in the theme's ink
  tokens with colour only on the swatch beside it. Role cards and the role header show the same
  stage with the same colour; "Close role"/"Reopen role" on the role header is the only thing
  that reaches `closed`. Verified: 6 new tests (21 in the file); full suite **554 passed**, same
  **20** pre-existing failures; `tsc --noEmit` + `vite build` clean; local stack rebuilt — both
  new columns migrated on boot, chart + states + close action all present in the served bundle.
  Files: `db/models.py`, `db/engine.py`, `app/sessions.py`, `app/main.py`,
  `features/shortlist/{role_routes,role_store}.py`, `ui/web/src/components/RoleStatesChart.tsx`
  (new), `ui/web/src/lib/{roles,cadenceReview}.ts`,
  `ui/web/src/pages/{Shortlist,RoleDetail,InterviewSetup,CadenceReview}.tsx`,
  `tests/test_roles_endpoints.py`.

- **One cadence per ROLE, authored before interviews exist · tests no longer write to the dev
  database · 109 fixture roles purged — NOT COMMITTED (user commits), local-docker verified,
  NOT deployed to Azure.**
  **(1) The Shortlist's 109 "jobs" were test pollution.** Six fixtures (`Senior AI Engineer`,
  `X`, `AI Eng`, `R`, `AI`, `NoJD`) repeated 18 times, all created 2026-08-08..08-13, each batch
  inside ~600ms. Root cause: `tests/test_roles_endpoints.py` + `tests/test_shortlist.py` isolate
  by setting `SESSIONS_DIR` and calling `reset_engine()`, which only falls back to a throwaway
  sqlite file **when `DATABASE_URL` is unset** — run the suite in any shell carrying the app env
  and they write to the live Postgres. Fixed for EVERY test at once with a new
  **`tests/conftest.py`** autouse fixture that unsets `DATABASE_URL` and fails any test that
  points itself at a non-sqlite URL (a per-file fix would need remembering by each new DB test,
  which this incident shows does not hold). Proven both ways: with an unreachable Postgres URL
  set, the two files now pass 16/16 against sqlite; with the conftest removed they produce 10
  connection errors reaching for that host. Then deleted all 109 roles + 57 scores + 15
  score_dimensions (backup dumped first). **`sessions.role` is a plain text label with no FK**,
  so the 36 interviews were provably untouched; candidates kept (they hold resumes).
  **(2) One cadence for the whole role, required before Create interviews.** `POST
  /api/roles/{id}/interviews` used to call `create_draft` per candidate, firing a separate
  cadence-gen LLM job from the JD + *that* candidate's resume — so everyone answered a different
  interview scored by a different plan, which quietly destroys the comparability the Shortlist's
  ranking depends on, and cost an LLM call per person. Now the role owns a **cadence template**:
  a real session row (`sessions.is_template`) pointed at by `roles.template_token`. It is a
  session ON PURPOSE — the cadence editor, the four revise-with-AI agents and the eval plugin
  panel are all session-token-keyed, so the template reuses every one of them unchanged instead
  of growing a parallel role-scoped copy. Status flows normally (generating → draft → ready), and
  the `is_template` flag is what keeps it out of `list_recent`, `count_active`, `count_scheduled`
  and `has_active_session` — filtered inside those four functions so a new caller cannot forget.
  `ScheduleForm.cadence_yaml` (new) makes `create_draft` use a supplied cadence **verbatim**: no
  LLM, no worker job, no per-candidate variation. `create_interviews` now **409s** unless the role
  has a template AND it is approved, then copies the YAML plus `evaluation_plan.json` into every
  new interview (the eval plan is the half that decides whether anything is scored at all — an
  interview created without it scores 0/0 with no error anywhere, a failure mode already shipped
  once). Endpoints: `POST`/`GET /api/roles/{id}/cadence-template` (get-or-create, idempotent so
  leaving and returning lands on the same plan). Also fixed while here: a template no longer
  enqueues a `resume_summary` job — its resume is a placeholder with no candidate behind it, so
  that was a wasted LLM call. UI: `InterviewSetup.tsx` is now two steps — Step 1 cadence card
  (author → review & approve → approved, polling while the worker generates) gating a dimmed
  Step 2 picker; per-candidate "Edit this candidate's cadence" is unchanged, so individual edits
  still work.
  **(3) Templates never wait on the LLM, and use the SAME default as a scheduled interview.** A template with a JD went through the normal
  `generating` path, so the cadence page — the screen the admin opens *to edit* — rendered an
  empty cadence as **"YAML parse error"** for as long as the worker ran (observed live; the job
  itself succeeded). `create_draft` now skips generation entirely when `is_template`, so the page
  opens instantly on a real plan. The JD is still stored, so Revise-with-AI on that page can use
  it. It opens on the **same built-in default a
  one-off scheduled interview uses** — `default_yaml_path_for(modality)`, one default per
  modality, user-directed. A bespoke "role template" default was built and then removed for this
  reason: two defaults drift apart silently. Pinned by a test asserting the template's PHASES are
  equal to that file's, not merely non-empty. **(FIXED — see the resume-deep-dive entry below:
  `default.yaml` no longer hardcodes one candidate's project name.)** **Mode is chosen per role**:
  `POST …/cadence-template` takes
  `modality` (voice|text, the same two the schedule form offers), which picks the default
  (`default.yaml` vs the untimed, pool-backed `default_text.yaml`), sets `record_enabled`
  (text has no camera/screen) and is **inherited by every interview created from the template** —
  a text role creating voice interviews would put an untimed cadence on the wall-clock path.
  It is immutable once the template exists (baked into the cadence and into interviews already
  created), so a second create call returns the existing one unchanged. Also: creating a SINGLE
  interview now lands
  straight on that candidate's cadence page (several still show the list, since picking one would
  hide the rest).
  **NOT done, deliberately:** created interviews are still `draft` and need approving
  individually. Auto-approving them means writing cadence to disk and setting `ready`, which
  touches the local-mode orchestrator-spawn path — a separate, riskier change than this one.
  Verified: 4 new tests + the existing batch test reworked (gate refuses with no template, refuses
  an unapproved one, template created once and reused, template absent from every interview list
  and count while still addressable by token, and the role cadence reaching `create_draft`
  verbatim) — `test_roles_endpoints` 14 passed; full suite **547 passed**, same **20** pre-existing
  failures; `tsc --noEmit` + `vite build` clean; local stack rebuilt and verified (both additive
  columns applied on boot, routes live + auth-gated, all four new UI strings in the served bundle,
  Shortlist empty, 36 interviews intact). Files: `tests/conftest.py` (new),
  `tests/test_roles_endpoints.py`, `db/models.py`, `db/engine.py`, `app/db.py`, `app/sessions.py`,
  `features/shortlist/{role_routes,role_store}.py`, `ui/web/src/lib/roles.ts`,
  `ui/web/src/pages/InterviewSetup.tsx`.

- **"Ava" orb redesign: the AI avatar is now a minimal white/lavender lens inside a
  magenta-core/violet-rim aura, not the old glossy magenta sphere — local-docker verified,
  NOT deployed to Azure.** Shared component (`.orb` 200px→112px for the AI tile,
  `.tile-orb` 92px for participant tiles) lives in `ui/web/src/theme.css`, rendered by
  `Stage()` in `ui/web/src/pages/Candidate.tsx` and `Orb()` in
  `ui/web/src/components/VideoTiles.tsx` — both markups must stay structurally identical
  (see the comment above `.orb` in theme.css) since they share every rule off `--size`.
  Layers, outer to inner: `.orb-aura` (new — a slow-rotating conic gradient, decorative,
  always animating, independent of `--glow-level`, for ambient life at rest) → three
  `.orb-breathe-N`/`.orb-halo-N` pairs (unchanged mechanism, recolored + heavier blur +
  higher base opacity so the glow reads even when `--glow-level` is near 0) → `.orb-core`
  (was a glossy magenta gradient ball, now a pale lens with a faint magenta rim and a
  centered "a." wordmark, `--orb-ink` on `#f3d9ec`-tinted white). The AI orb's `--size` was
  cut from 200px to 112px and the halo insets tightened (was up to ~1.96× spread, now
  ~1.6×) because the AI tile is only ~186px tall (`BOX_W=248`, 4:3) with `overflow:hidden`
  — the old halo spread was being clipped hard at the tile edge. "AI Interviewer" tile
  label renamed to "AVA" in all three `VideoTiles.tsx` layouts (default/spotlight/rail).
  `ui/candidate/` (a separate, NOT-currently-routed vanilla-JS candidate app — the live
  candidate page is the React one above, served under `/app/candidate`) got the same
  visual treatment for parity plus a real audio-reactive rewrite: `startOrbAnim()` no
  longer draws to a canvas, it writes `--level`/`--mix` CSS vars read off an `AnalyserNode`
  hung on the AI playback `AudioContext` (speaking) and the mic worklet's RMS (listening);
  its lobby now defaults to the orb (`visualMode="minimal"`) instead of the 3D TalkingHead
  avatar.

- **Human-editable evaluation: a reviewer can adjust marks and give feedback on the LLM's
  scorecard — NOT COMMITTED (user commits), local-docker verified, NOT deployed to Azure.**
  Design: `docs/human-review-schema.md`. **The one rule everything follows from: the AI's
  number is never overwritten.** `marks_earned` on an exported section keeps meaning *what
  the model said*, forever; the correction lives in `review.final_marks_earned` and that is
  what counts. Three reasons, and the third is the one that would have bitten us — audit ("the
  score was 8" and "the AI said 4, a recruiter raised it to 8" are different claims),
  measurement (each adjustment is a labelled example of where the model is wrong, and
  overwriting destroys the label), and **regenerate**, which rewrites every AI value and would
  silently erase every human correction stored in the same field.
  **Two stores, joined on read.** `evaluation_export.json` stays immutable (a test asserts a
  review never rewrites it); corrections go to a new append-only **`evaluation_reviews`**
  Postgres table (`db/models.py`, created by `create_all`). A table rather than a file in
  `sessions/<token>/` because the useful question is cross-session ("how far off is `role_fit`
  across 200 interviews?"), which a per-session file can only answer by scanning — and because
  we already lost per-session JSON once this month (the `evaluation_plan.json` path bug,
  `b8cb1a3`). `idx_reviews_target (section, item_label, status)` is the index that makes the
  calibration query one indexed read later. Append-only: a second verdict on a section
  SUPERSEDES that section's active rows, never UPDATEs — so "what does this section say now"
  has one answer and the history stays on disk.
  **What is editable is declared by the PLUGIN** (`AdjustableSpec` on `ExportSection`), the
  same way its schema is: the four rubric/coverage plugins expose per-item editing with a
  declared `recompute` (`conversational_rubric` → `mean_scaled`, verified against its real
  arithmetic: mean/10 × marks_possible; `rubric_marks`/`coverage_tags`/`dynamic_difficulty` →
  `sum_deltas`, each verified as literally the sum of its breakdown deltas), while `coding`
  and the three ground-truth plugins are **total-only** — overriding "3 of 5 tests passed" is
  not a rubric judgement, and if the harness was broken that is a total override carrying
  `reason_kind="evidence_missing"`, which reads as exactly that in the file. A reviewer moves
  the dimension they have an opinion about; the arithmetic stays the system's job.
  **`reason_kind` is mandatory** (`ai_misread`/`rubric_wrong`/`evidence_missing`/`calibration`/
  `other`) — each value routes to a different fix, and a free-text reason with no kind is
  readable but not aggregatable. **Invariants that survive human editing**: `SectionReview`
  carries the SAME validator as the envelope, so a non-scored segment still cannot be turned
  into a zero (changing the STATE is a separate, stated act); marks are clamped to
  `[0, marks_possible]`; `marks_possible` is not editable at all (two candidates scored out of
  different denominators aren't comparable — that's a cadence edit); the reviewer identity
  comes from the authenticated session, not the request body.
  **Regenerate**: each record freezes the `ai_value` it corrected — unchanged → the adjustment
  carries forward, changed → `review.stale=true` and the UI says "the AI's score moved since
  you adjusted this". Never silently dropped, never silently re-applied.
  **BUG FOUND + FIXED while building this (pre-existing, shipped):** `EvaluationReport.sections`
  was declared as `list[ExportSectionModel]` — pydantic serialises by the DECLARED type, so
  every plugin-specific key (`dimensions`, `criteria`, `tags`, per-plugin `rationale`) was
  silently dropped from `evaluation_export.json`. The stored document did NOT validate against
  the `section_schemas` travelling inside it, and the scorecard's `view_id` templates were
  rendering empty payloads. Fixed with `SerializeAsAny` out, plus a `mode="before"` validator
  that dispatches each section to its own plugin's declared model IN (`registry.export_models()`,
  `_UnknownSection` fallback so a retired plugin's old document stays readable) — "the document
  validates itself" is now true both directions. NOTE: exports written before this fix still
  carry only the envelope; review works on them, but per-plugin detail appears only after a
  regenerate.
  **API**: `POST /api/sessions/{token}/review` + `DELETE …/review?segment_id=&section=`
  (withdraw — still not a delete, rows are marked superseded). Both read routes
  (`/api/sessions/{token}/evaluation-view` and `/admin/sessions/{token}/evaluation-export.json`)
  now go through ONE `_evaluation_export_doc()` → `review_store.merge_into()`, so the screen and
  the download remain byte-identical — the existing verbatim test is re-asserted on the reviewed
  path. A review store that is down degrades to the AI's scores rather than taking the
  evaluation with it.
  **UI**: an "Adjust" button on each segment card in the Scorecard tab → inline editor (per-item
  number inputs prefilled from the AI's values with "AI n" shown beside each, an optional direct
  total, a REQUIRED reason kind + free text, an optional note, and "Remove adjustment"). The
  header shows the final mark with the AI's struck through beside it; an "Adjusted by a
  reviewer" block shows who/when/why and every line that moved; the grand total shows the
  reviewed number with "AI scored x / y" underneath. Every save REFETCHES rather than patching a
  local copy — the server owns the recompute, so a browser-derived mark can never disagree with
  the file a customer receives. Verified: **26 new tests** in `tests/test_eval_human_review.py`
  (merge arithmetic per recompute mode, AI value preserved, unreviewed doc returned untouched
  and identical, non-scored-is-not-zero on the reviewed path, denominator unchanged, clamping,
  staleness both ways, supersede-not-stack, withdraw, reviewer from session, and the
  screen==download round trip through the real FastAPI app); full suite **543 passed**, same
  **20** pre-existing failures as baseline; `tsc --noEmit` + `vite build` clean; local stack
  rebuilt and verified (table + both indexes in Postgres, routes live and auth-gated, the 5
  saved eval plans survived the rebuild, all four new UI strings in the served bundle).
  **Still open: `.gitignore` line 61 is `tests`** — `tests/test_eval_human_review.py` needs
  `git add -f`. Files: `features/eval/review.py` (new), `app/review_store.py` (new),
  `features/eval/plugins/export.py`, `features/eval/export.py`,
  `features/eval/plugins/registry.py`, `features/eval/plugins/builtins/{conversational_rubric,
  rubric_marks,coverage_tags,dynamic_difficulty}/__init__.py`, `db/models.py`, `app/main.py`,
  `ui/web/src/lib/evaluationExport.ts`, `ui/web/src/components/eval-views/{types.ts,index.tsx}`,
  `ui/web/src/components/BenchmarkPanel.tsx`, `ui/web/src/pages/Session.tsx`,
  `tests/test_eval_human_review.py` (new), `docs/human-review-schema.md` (new).

- **Eval plans were silently destroyed on every deploy — two path bugs, both fixed
  (found live: a configured interview regenerated to 0/0).** A regenerate on an
  interview that HAD assigned plugins came back `0 / 0 · 0 graded phases`, with no
  error anywhere. Not a scoring bug — the evaluation PLAN telling the pipeline what to
  grade was gone, and `plan_from_cadence`'s deliberate default is "every phase
  unassigned, only score what I pick", so the pipeline correctly skipped every phase
  and persisted that empty default. It fails silently by construction: an unassigned
  phase is a legitimate state, so nothing logs, nothing errors, no test catches it.
  **Cause 1 — the plan was written outside the volume.**
  `plan_storage._sessions_dir()` computed `Path(__file__).resolve().parent.parent`,
  which from `features/eval/plan_storage.py` is `<repo>/features`, NOT the repo root.
  Plans landed in `/app/features/sessions/<token>/` while every other artefact lives in
  `/app/sessions/<token>/` — and in a container that first path is INSIDE THE IMAGE
  while `/app/sessions` is the mounted volume (`/dev/vda1 on /app/sessions`, verified).
  So **every image rebuild deleted every saved evaluation plan**, cloud included, where
  `SESSIONS_DIR` was set for the app but this function ignored it in favour of its own
  broken calculation. Fixed by deferring to `app.paths.SESSIONS_DIR` — one definition of
  where session data lives — with the corrected three-level fallback kept so `features/`
  stays importable without `app/`.
  **Cause 2 — a cold session dir overwrote the blob backup.** `load_plan` read the local
  file only. With it missing (a restart, or a different replica on the tiered deploy,
  which is NORMAL there) it returned None, the caller derived the empty default, saved
  it, and the mirror pushed that default to blob — destroying the good copy. So the
  backup existed and was clobbered because nothing consulted it first. `load_plan` now
  falls back to blob before returning None. Both together mean a configured plan now
  survives a deploy AND a cold dir. Recovery for an already-hit session: re-pick the
  plugins on cadence-review and regenerate; the old plan is unrecoverable (destroyed
  before any blob copy existed). Also added the **"Export scorecard (.json)"** button to
  the Scorecard tab itself — the export download was only in Data & cost, which is not
  the screen someone is on when they want to export a scorecard; gated on the export
  existing so it is never a dead link. Verified: 4 regression tests (plan path sits beside
  the other artefacts and never contains `features`; `SESSIONS_DIR` override still wins;
  a cold dir restores from blob; nothing anywhere is still None) — full suite **517
  passed**, same 20 pre-existing failures; `tsc --noEmit` + `vite build` clean; deployed
  and verified in the local stack (`/app/sessions/TOK/evaluation_plan.json`). NOT deployed
  to Azure. **Still open: `.gitignore` line 61 is `tests`**, which silently hides every new
  test file from `git add` — force-added again here. Files:
  `features/eval/plan_storage.py`, `tests/test_eval_plan.py`, `ui/web/src/pages/Session.tsx`.

- **Eval export: one downloadable JSON per session (AB#34151) — COMPLETE, incl. the
  UI now rendering from the exported document.**
  `generate_evaluation_v2` now collects `(segment, evaluation)` pairs across the whole
  session and writes `sessions/<token>/evaluation_export.json` (mirrored to blob)
  beside `evaluation.json`, via `features.eval.export.build_report`. Deliberately a
  SEPARATE artefact: `evaluation.json` is an internal shape that changes whenever the
  UI does, and the export's whole point is a document that does not. The write is
  never fatal — a failure there must not lose a completed evaluation. New admin route
  `GET /admin/sessions/{token}/evaluation-export.json` (local file, blob fallback,
  `?inline=1` to render instead of download) follows the `events.jsonl` endpoint
  pattern, plus an "Evaluation (.json)" button in the session page's Downloads row.
  **The UI now renders from the export** (option 1 of the three weighed below).
  `GET /api/sessions/{token}/evaluation-view` returns two blocks: `export` — the stored
  artefact VERBATIM, byte-identical to what the download serves (a test asserts
  equality, so the screen and the file cannot drift) — and `evidence`, the transcript
  turns / question text / difficulty rebuilt from events.jsonl per request, served only
  to an authenticated admin and never written to a file. That split is what reconciles
  the AC with AB#34150's PII decision: the scorecard is DRIVEN by the export and merely
  decorated with evidence it is entitled to show. New `ui/web/src/lib/evaluationExport.ts`
  joins the two into the existing `Benchmark` shape, so `BenchmarkPanel` and every
  `view_id` template are UNCHANGED — the strongest no-visual-regression guarantee
  available with no JS test runner in the repo. Evaluations predating the export fall
  back to the stored `ev.benchmark`, so an old session renders exactly as before.
  `breakdown` was added to `ExportSectionModel` (additive, filled in `envelope()`, no
  plugin changes): the AC names it, it is scoring data rather than transcript, and a
  consumer given only a total cannot check the arithmetic. Rejected alternatives stand
  as recorded: an internal include-evidence flag (the decision doc rejects a switch
  that widens personal data without review) and putting transcript text in the export
  (reopens the privacy decision). Verified:
  12 tests in `tests/test_eval_export_aggregate.py` (one document collects every
  plugin's section, self-describing schemas, exported totals agree with the internal
  benchmark arithmetic, non-scored survives as a state not a 0, download headers /
  inline / 404 paths); full suite **513 passed**, same 20 pre-existing failures;
  `tsc --noEmit` + `vite build` clean. NOT deployed to Azure. Files:
  `app/plugin_evaluation.py`, `app/main.py`, `ui/web/src/pages/Session.tsx`,
  `tests/test_eval_export_aggregate.py` (new), `ui/web/src/lib/evaluationExport.ts` (new), `features/eval/plugins/export.py`.

- **Eval export: Rubric & Coverage family + the shared contract and report
  document (AB#34149) — MERGED with AB#34150, full suite 501 passed.** Both export
  stories landed independently and had to be converged: the Rubric & Coverage story
  (this one) was committed locally but never pushed, so the Ground-truth & Coding story
  built its own minimal contract in `features/eval/plugins/export.py`. **Harika's
  section contract won and is now the single one** — it enforces the load-bearing
  invariant in the MODEL (`ExportSectionModel`'s validator refuses to construct a
  non-scored section carrying marks, so "excluded from totals" is structural, not a
  filter someone must remember), uses `extra="forbid"` so an undeclared key is a
  validation error rather than a silent passenger, versions each section
  independently (`schema_version`), and its fill signature `export_section(segment,
  evaluation)` carries the Segment — which is where `question_id` lives and which the
  competing `to_export(evaluation)` could not reach. The four Rubric & Coverage plugins
  (`conversational_rubric` → `rubric_dimensions`, `rubric_marks` → `rubric_options`,
  `coverage_tags` → `coverage_tags`, `dynamic_difficulty` → `difficulty_breakdown`)
  were PORTED onto it; her four were untouched. **All 8 plugins now share one
  contract** (`registry.export_schemas()` returns 8 sections and raises on a duplicate
  key). What survived from this story is the layer she did not build: the DOCUMENT
  envelope in `features/eval/export.py` — `EvaluationReport` (versioned
  `report_version`, session metadata, sections in interview order, `section_schemas`
  so the document validates itself with nothing fetched from us) + `build_report()` /
  `build_totals()`. **The rule that matters: non-scored is never zero.** A phase that
  did not run exports `marks_earned: null`, not `0`, and shrinks the denominator — a
  candidate whose coding round never happened must not read as having failed it. Two
  merge hazards worth remembering: (1) git auto-merged `base.py` "cleanly" into TWO
  `export_descriptor()` definitions with Python silently taking the last, killing one
  export path with no conflict reported — a clean auto-merge of two independently
  designed contracts is not a safe merge; (2) **`.gitignore` line 61 is `tests`,
  ignoring the whole directory**, which is why `tests/test_eval_export_document.py`
  and `tests/test_question_pools.py` (55 pool tests) were invisible to `git add` and
  the question-pool feature shipped with no tests in VCS. Both force-added here; the
  rule is UNCHANGED and will keep swallowing new test files until someone narrows it.
  Also relaxed one assertion in `tests/test_eval_export.py` from `==` to `⊆` (it
  pinned exactly the Ground-truth four, so it necessarily broke when the other family
  landed); the whole-registry property now lives in `tests/test_eval_export_document.py`.
  NOT done — wiring the export into `app/plugin_evaluation.py` and a download endpoint
  is **AB#34151**, which both stories unblock. Files: `features/eval/export.py` (new),
  `features/eval/plugins/base.py`, `features/eval/plugins/registry.py`,
  `features/eval/plugins/builtins/{conversational_rubric,rubric_marks,coverage_tags,
  dynamic_difficulty}/__init__.py`, `tests/test_eval_export_document.py` (new),
  `tests/test_eval_export.py`, `tests/test_question_pools.py`.

- **Eval export: JSON definitions for the Ground-truth & Coding plugin family
  (work item #34150) — branch `feature/eval-export-ground-truth-coding-34150`,
  NOT merged/built/deployed.** Gives `coding`, `transcription_scoring`,
  `translation_scoring` and `image_description_scoring` a declared, versioned
  section in the machine-readable evaluation export. **Read this first if you own
  the Rubric & Coverage story**: that story is the nominal owner of the shared
  export contract and was expected to land it in `base.py`. It had not landed on
  ANY branch (verified: no `export`/`ExportSection`/`fill_export` anywhere in the
  repo or in any remote branch's `base.py`), so this story would otherwise have
  been blocked indefinitely. The minimal contract it needed lives in a NEW
  `features/eval/plugins/export.py` — deliberately NOT in `base.py`, so adopting
  the definitive version is an import swap in one file instead of a merge conflict
  in the file every plugin imports. `base.py` gains only the two default-None
  hooks (`export_descriptor`/`export_section`) and a `TYPE_CHECKING` import;
  export.py imports FROM base.py, so the dependency runs one way and there is no
  cycle.
  **Design.** A `SegmentEvaluation` is shaped for the UI; an export is read by
  something that has never seen our UI, so it needs a declared schema, a version,
  and an explicit "not scored". Every section subclasses `ExportSectionModel`, so
  the envelope (identity / method / state / marks / `evidence_refs`) is identical
  across the pipeline and only the payload differs — which is what makes the
  contract hold cleanly for BOTH the `method="python"` member (coding) and the
  three `llm_judge` ones. Two invariants are structural, not conventional:
  (1) a non-scored state (`not_observed` / `insufficient_evidence` /
  `assumptions_unmet` / `error`) carries a `not_scored_reason` and the model
  *rejects* marks alongside it, so a 0 in the export always means "earned zero"
  and never "we couldn't grade this" — `envelope()` is the single place that
  applies it, so no plugin has to remember; (2) `extra="forbid"` ⇒
  `additionalProperties: false`, so the emitted JSON cannot drift from
  `descriptor.json_schema()`.
  **The three ground-truth plugins export the SAME model** (`GroundTruthExport` /
  `GroundTruthComparison`), not three lookalikes — pinned by a test asserting the
  identical model object and an identical key set. Only `expected_kind` and the
  meaning of one item differ (diff / accepted reference / checklist element).
  `matched_count`/`total_count` are each plugin's score numerator+denominator in
  its own natural unit, and `items` is explicitly NOT required to be
  `total_count` long (transcription lists only the diffs, not all 9 words) —
  documented on the model, because that is the one place the shared shape is
  genuinely lossy. Translation is the odd one: its references are ALTERNATIVES,
  so the denominator is 1 ("did the translation land?"), not `len(references)`,
  which would read as a misleading 1/3.
  **Coding** keeps its test facts and the judge's opinion in SEPARATE fields, so a
  consumer can tell deterministic fact from LLM judgement; `judge is None` means
  the judge did not run (no LLM key / disabled), distinct from a judge that ran
  and scored badly. Its section is derived entirely from `(segment, evaluation)` —
  `evaluate()` was not touched — reading per-test rows off the submission turn's
  `final_test_results` meta, tolerating the legacy `pass` key alongside `passed`.
  **PII (the story required a recorded decision — `docs/eval-export-pii-decision.md`)**:
  integer `evidence_refs` ship, transcript text does not, with two named
  exceptions — the ground-truth `comparison.actual` (the graded artefact; "6 of 9
  words matched" is unverifiable without it) and the coding per-test rows (the
  graded facts). Submitted source code and test `stdout`/`stderr` are excluded.
  Enforced by a test, not a convention.
  Also: `registry.export_schemas()` (the export's self-description, raising on a
  duplicate section key) + an `export_section` key on `plugin_catalog()` entries
  (both existing catalog consumers select keys explicitly, so it is inert;
  `evalPlan.ts` gained the matching OPTIONAL field). AUTHORING.md §5b documents
  the hooks and the reuse-a-shape rule.
  Verified: new `tests/test_eval_export.py` — 12 tests driving ONE synthetic
  session through all four plugins (stubbed scoring LLM, offline coding path),
  validating every emitted section against its declared schema (`jsonschema` when
  installed, else the schema's structural checks + a strict model re-parse — the
  models are closed, so the two are equivalent; no new dependency added).
  `test_eval_plugins` (13), `test_sectioner` (10) still pass. `test_plugin_aggregate`
  and `test_phase_boundary_attribution` could not run in this environment (no
  `openai` module) and `test_eval_plan` fails on the coding-default assertion —
  all three confirmed IDENTICAL on a clean `git stash` baseline, i.e. pre-existing,
  not regressions. Frontend change is one optional type field; no local tsc (no
  node on PATH), so the deploy tsc stage is the net. Files: `features/eval/plugins/
  export.py` (new), `features/eval/plugins/{base,registry,__init__}.py`,
  `features/eval/plugins/builtins/{coding,transcription_scoring,translation_scoring,
  image_description_scoring}/__init__.py`, `features/eval/plugins/AUTHORING.md`,
  `docs/eval-export-pii-decision.md` (new), `ui/web/src/lib/evalPlan.ts`,
  `tests/test_eval_export.py` (new).

- **Text interview: named question modes · per-question languages · draft durability ·
  written-task LLM instructions · connection bar — COMMITTED + PUSHED (`0d0fd02`, branch
  `feature/text-interview-mode`), local-docker verified, NOT deployed to Azure.** Several rounds of
  text-mode work, plus a merge with the ground-truth/LLM-scoring work (`f4c78e9`, separate author).
  (1) **`question_mode` now NAMES the task for written phases** — a translation phase writes
  `question_mode: translation`, not `specific`. WHY: the mode is the one field every layer reads to
  know what a phase IS (tracker, director, verifier phase descriptor, eval sectioner, admin UI), so
  collapsing four tasks into "specific" forced each layer to re-derive the real kind from a
  side-channel — which is what coding phases still do via `coding_question_ids`, the same inference
  written five times over. Allowed values are NOT hardcoded: `question_mode` is a plain `str`
  validated against `{"generic","specific"} | qt.QUESTION_TYPE_IDS`, so a new written type is one
  entry in `question_types.py` and needs no schema edit. **All ~12 behavioural
  `question_mode == "specific"` checks became `PhaseDef.uses_question_pool`** (`!= "generic"`) —
  tracker ×4, director ×3, turn_engine ×2, conversation_context, confirmer. The load-bearing one is
  `cadence_tracker.py` POOL INITIALISATION: a named mode would have failed `!= "specific"` there and
  the phase would have been built with ZERO questions, silently. New `PhaseDef.written_question_type`
  recovers the type from the block for older cadences. A mode that disagrees with
  `written_response.question_type` is refused. **Backward compatible**: approved cadences saying
  `specific` load unchanged (`uses_question_pool` still True); editing one normalises it.
  Also fixed a self-contradiction: the interviewer's phase block hardcoded
  `operating_instructions (derived from question_mode=specific)` in its own text, which on a
  translation phase contradicted the `question_mode:` line directly above it.
  (2) **Language pair moved phase→QUESTION scope** (`FieldSpec.scope`), so one phase mixes pairs
  (en→es and fr→de side by side) and each question's instruction is synthesised from its OWN pair.
  The form/validation follow automatically (both render off `scope`). The old "one pair per phase"
  refusal in the merge path is gone. `translation` gained `prompt_hidden=True` — the admin never
  writes its instruction, it is always synthesised, so a stale sentence can't survive a language
  change and contradict what is graded.
  (3) **BUG (silent data loss), fixed + pinned**: `_WrittenQuestionBody` (app/main.py) never declared
  `source_language`/`target_language`, and **pydantic drops undeclared keys silently** — so the
  languages the admin picked vanished between browser and builder and the phase failed with
  "Transcription needs source language" pointing at a field that WAS filled in. New test walks every
  question-scoped field in the registry and asserts the request model declares it, so a future type
  can't drop data the same way.
  (4) **Written-task instructions to the interviewer LLM** — the task's MATERIAL (clip / passage /
  image) never passes through the LLM (that's what guarantees a translation's passage reaches the
  candidate exactly as authored), so left untold the model invented a passage and read it out
  (observed live). `cadence_tracker._written_response_brief()` now emits a WRITTEN RESPONSE TASK
  block into BOTH the `<phase_changed>` marker and the per-turn `<think>` directive (the latter
  matters: only the FIRST task of a phase arrives via a phase change), plus a clause on the final
  PHASE BOUNDARY message. Per-type wording (`material_label`, `self_answer_ban`) lives in the ONE
  table, so a fifth type needs no edit in the tracker.
  (5) **Draft + timer durability** — the candidate's UNSUBMITTED text lived only in React state, so a
  refresh lost it even right after Save (Save persists conversation state, which has no field for a
  half-typed answer). Now autosaved to `localStorage text:draft:{token}` every keystroke, AND folded
  into the SIGNED payload on explicit Save, which writes Redis **and mirrors to Blob**
  (`<token>/text_state.json`, no TTL). `/state` falls back to Blob when the 2h Redis copy expired —
  previously that returned `{started:false}` and the interview looked like it never happened. The
  merge is server-side because the payload is HMAC-signed (a browser can't add a field without
  failing verification — which is what stops a candidate editing `remaining_s`). Countdown holds on
  Save and resumes on the next keystroke; expiry auto-submits even when empty (an empty submit was
  being dropped by `sendAnswer`'s `!t` guard, stranding the panel at 0:00).
  (6) **Connection-quality signal bar** (`lib/connectionQuality.ts` + `components/ConnectionBar.tsx`)
  — Teams-style bars, bottom-left, on both candidate pages while live. Pings `GET /app/` (the ONE
  route mounted identically in every deploy shape — `/healthz*` only exists on the tiered
  containers), 5s interval, 3 consecutive misses = offline, pauses on hidden tab, and the voice page
  overrides with its own WS `reconnecting` flag. No backend change.
  (7) **Add-phase modal**: landing on an existing phase now loads its questions as EDITABLE cards
  plus a blank one, numbered 1..N, and saves through `/update_phase` (so edits to existing questions
  persist and their ids survive). Per-mode pill colours are CSS-only (`mode-<value>` interpolated;
  a mode with no rule falls back rather than rendering unstyled).
  Verified: **401 passed** (same 20 pre-existing fakeredis/livekit failures as baseline), `tsc
  --noEmit` + `vite build` clean, live end-to-end on a real model
  (`tests/_check_text_interview.py`), and both merged features confirmed coexisting
  (`question_mode: translation` + `ground_truth` on the same phase). Files:
  `engine/brain/cadence/{schema,question_types}.py`, `engine/brain/core/{cadence_tracker,director,
  conversation_context}.py`, `engine/brain/text/turn_engine.py`, `engine/brain/cadence/confirmer.py`,
  `app/{main,cadence_service,text_service}.py`, `ui/web/src/lib/{connectionQuality,textEngine,
  cadenceReview,cadence,questionTypes}.ts`, `ui/web/src/components/{ConnectionBar,AddPhaseModal,
  CadencePhaseBlock}.tsx`, `ui/web/src/pages/{Candidate,CandidateText}.tsx`, `ui/web/src/theme.css`,
  `tests/test_text_interview.py`.

- **"Add Essay" generalized into "Add Phase" — 4 question types, N questions per phase, editable
  (branch `feature/text-interview-mode`) — NOT COMMITTED (user commits), NOT built/deployed.** The
  text interview's essay authoring became a scalable written-response phase with a REQUIRED question
  type: **Comprehensive / Transcription / Translation / Image Description**. One generic phase
  model, one endpoint, one candidate renderer — a fifth type is one Python entry.
  **A phase holds N questions of ONE type** (user-directed): the admin adds / edits / deletes
  question cards and the cadence YAML follows. Per QUESTION: prompt, its material (clip / passage /
  image), character limit, countdown. Per PHASE: the question type + the language pair — encoded as
  `FieldSpec.scope` ("phase" | "question") in the central table, so the form, the schema and the
  builder all agree on where a field lives. Runtime needed NO turn-engine change: the untimed
  tracker only advances when the pool is drained, so a submission closes that QUESTION and the next
  one is dispatched (verified live end-to-end on a real model, 2-question translation phase).
  **Modal is two-step**: it opens on the Question type dropdown ALONE (every other field's identity
  depends on the type); choosing a type reveals the rest and seeds the phase name with the type's
  label (editable; the id is derived from it at creation). **Editing an existing phase** is
  `POST /api/cadence/{token}/update_phase` → `cadence_service.update_written_phase`, reached from an
  "Edit questions" button on written-response phase cards in the review screen. It keeps the phase
  `id` (the evaluation plan + events.jsonl reference it — a rename would orphan them, so the name
  field is read-only in edit mode) and keeps every question id the client echoes back; a DELETED
  question's id is never recycled, and a legacy word-limited question stays word-limited so an edit
  can't reinterpret "300 words" as 300 characters.
  **Central definition** — new `engine/brain/cadence/question_types.py` is the single source of
  truth: `QUESTION_TYPES` (per type: label, prompt label + whether it's required, phase slug,
  `intent`, and its own `fields` with a renderer/validator `kind`), the curated `LANGUAGES` catalog
  (40 codes; both language fields must pick from it), and `ASSET_RULES`/`check_asset` (extensions +
  25 MB audio / 10 MB image). `api_catalog()` serves the whole table to the SPA via new
  `GET /api/cadence/question-types`, so the authoring FORM renders from the same table the backend
  validates with — no duplicated TS list to drift.
  **Schema (same YAML key, by design)** — `WrittenResponse` keeps the phase-level `written_response`
  block and gains `question_type` (default `comprehensive`), `char_limit` (new canonical limit)
  alongside the LEGACY `word_limit`, and the type fields `source_text` / `source_language` /
  `target_language` / `audio_asset` / `image_asset`. New `WrittenQuestion` is the PER-QUESTION block
  on `QuestionPoolItem.written_response` (limits, countdown, material). `WrittenResponse.resolved_for
  (question)` layers a question's values over the phase's and re-validates by construction (so a
  question can't smuggle in material foreign to the phase's type); `missing_requirements()` is the
  shared "is this answerable yet" check used by both `PhaseDef` validation and the builder. Phase-level
  values act as DEFAULTS for a question that has no block — which is exactly the legacy essay shape.
  The validators drive entirely off the table: phase-scoped fields required on the phase block,
  question-scoped material + **exactly one** limit required on each RESOLVED question, languages
  on-list, foreign fields rejected, and a per-question block with no phase block refused (it would be
  silently ignored at runtime). New props `limit_kind` / `limit_value` / `asset_name`.
  **Backward compatibility is by construction**: a legacy essay block
  (`{word_limit, time_limit_s}`, no `question_type`) validates untouched, reads as comprehensive,
  and still counts WORDS in the candidate UI; `append_essay_phase` + `POST …/add_essay_phase`
  survive as thin shims (a browser on an immutably-cached old bundle keeps working), and the service
  still emits the legacy `essay` block for word-limited phases only (a char-limited/typed phase
  returns `null` there, so an old bundle degrades to the chat composer instead of showing a wrong
  limit).
  **Builder/API** — `cadence_service.append_written_phase(question_type=…, questions=[…])` (was
  `append_essay_phase`) inserts before `wrap_up` as before, per-type `intent`/slug, question ids
  `<phase>_qN`, and SYNTHESIZES a question's instruction from the language pair when the type's prompt
  is optional and blank (`default_prompt`, deterministic — never LLM-authored). `build_written_phase`
  is the shared phase-dict builder (append + update); `update_written_phase` replaces a phase's
  questions in place. New `POST /api/cadence/{token}/add_phase` + `/update_phase`. The flat
  single-question body (`prompt`/`char_limit`/`config`) is still accepted, distinguished by
  `questions is None` (an explicit `[]` is an authoring error, not a legacy call).
  **Uploads reuse the existing infra**: `POST /api/cadence/{token}/phase-asset?kind=audio|image`
  (admin-gated via `_api_require_user`) → `blob_store.upload_fileobj` → `<token>/phase_assets/<safe>`;
  `GET /api/sessions/{token}/phase-asset/{name}` serves it to the CANDIDATE with token-as-capability
  (the `chat-file` pattern) + Range/206 so a long clip can be scrubbed. cadence.yaml stores the
  asset NAME only — never bytes. `blob_store.upload_fileobj` gained the same disk fallback
  `append_chunk` already had, so uploads work with `BLOB_ENABLED=0`. `_safe_asset_name` hard-stops
  path traversal on both upload and download.
  **Runtime is UNCHANGED**: `turn_engine._is_written_response_phase` already covers every type, so
  every written question is one-shot (submission closes it, no verifier follow-up) and scores through
  the existing rubric plugins with no eval change. `text_service._essay_for_current` →
  `_question_for_current` resolves the CURRENT pool question's config over the phase's and returns it
  with `asset_url`, language LABELS, and `question_id` / `question_index` / `question_total`;
  type-specific MATERIAL travels in that payload, deliberately NOT through the LLM, so a translation's
  source text reaches the candidate exactly as authored.
  **Frontend** — `EssayPhaseModal.tsx` → `AddPhaseModal.tsx` (two-step type-first form, phase name
  seeded from the type, phase-level language fields, a list of question cards with + Add / Remove,
  audio/image upload on select with an inline player/preview, and an edit mode prefilled from the
  cadence), new `lib/questionTypes.ts` (catalog fetch + `DraftQuestion` + shared client-side
  validation that names the offending card), `cadenceReview.ts` `addPhase`/`updatePhase`/
  `uploadPhaseAsset`, `cadence.ts` parses the written blocks, `CadenceReview.tsx` "+ Add phase" plus
  a per-phase "Edit questions" button (still TEXT-only — voice keeps the coding picker). Candidate:
  `EssayPanel` → `ResponsePanel`, KEYED on `question_id` (so each question starts with a clean
  textarea + its own countdown), with ONE shared character/word counter + countdown + auto-submit for
  every type, an "n / N" progress pill, and a `QuestionMaterial` block (audio player / verbatim source
  passage / image).
  Verified: `npx tsc --noEmit` + `vite build` clean; new `tests/test_phase_question_types.py`
  (54 deterministic tests: catalog integrity + field scopes, phase-vs-question validation and
  resolution, legacy-essay load + model_dump round-trip + legacy builder/route/flat-body, builder for
  all four types with N questions, prompt synthesis, unique ids, add/edit/delete with stable +
  non-recycled ids, the multi-question tracker STAY→ADVANCE invariant, the per-turn payload incl.
  question index/total and asset-URL escaping, `check_asset` matrix, traversal guard, and a FastAPI
  TestClient pass over upload → add_phase → update_phase → candidate fetch → Range/206 → 401 when
  signed out). **Live-verified end-to-end on a real model** (`tests/_check_text_interview.py`, now
  carrying a 2-question translation phase): the phase holds through question 1, the payload switches
  to question 2 with its own limit + passage, then advances — and the events.jsonl still sections
  through the real eval sectioner. Full suite **416 passed / 3 failed**, the same 3 as the clean-HEAD
  baseline (362 passed / 3: stale `active`→`active_count` dashboard assertion, eval-plan
  coding-default, stale jobs registry) — zero regressions. NOT verified: the candidate panel in a
  real browser (no JS test runner in the repo, and none added). Files:
  `engine/brain/cadence/question_types.py` (new), `engine/brain/cadence/schema.py`,
  `app/cadence_service.py`, `app/main.py`, `app/text_service.py`, `app/blob_store.py`,
  `ui/web/src/components/AddPhaseModal.tsx` (new, replaces `EssayPhaseModal.tsx`),
  `ui/web/src/lib/questionTypes.ts` (new), `ui/web/src/lib/cadenceReview.ts`,
  `ui/web/src/lib/cadence.ts`, `ui/web/src/lib/textEngine.ts`,
  `ui/web/src/pages/CadenceReview.tsx`, `ui/web/src/pages/CandidateText.tsx`,
  `tests/test_phase_question_types.py` (new), `tests/test_text_interview.py`,
  `tests/_check_text_interview.py`.

- **Text-to-text interview modality — FOUNDATION on branch `feature/text-interview-mode` (off
  `interview-scaled-dev`), NOT built/deployed.** First slice of the OneForma text-interview
  workstream (WBS W1.1; full plan `docs/roadmaps/2026-text-interview-mode.md`). A typed/chat
  interview that reuses the interview brain (text-in/text-out) with NO STT/TTS/VAD/media, run as a
  stateless question-driven turn engine. Landed + LIVE-VERIFIED (scratch venv + real LLM), NOT yet
  committed to a shared branch, NOT deployed:
  (1) **Untimed cadence** — `CadencePlan.timed: bool = True` (`engine/brain/cadence/schema.py`);
  `_check_totals` skips the duration-sum check when untimed (per-phase `duration_s > 0` stays
  strict → untimed plans carry dummy durations). `CadenceTracker.check_phase_budget`
  (`engine/brain/core/cadence_tracker.py`) skips the wall-clock branch when `not plan.timed` →
  phases advance ONLY on question-pool exhaustion. Voice path provably unchanged (timed defaults
  True).
  (2) **Modality plumbing** (mirrors the `record_enabled` pattern end-to-end) — new `sessions.modality`
  column (`db/models.py` + additive migration `db/engine.py`), `apply_modality_flag` cadence stamp
  (`app/cadence_service.py`, text→`timed:false`), wired through `ScheduleForm`/`create_draft`/
  `update_draft` (`app/sessions.py`), the `_cadence_gen` worker job (`app/jobs/jobs.py`), both
  schedule endpoints + the edit endpoint + both `/session-info` twins (`app/main.py`,
  `deploy/azure_app.py`), and the `Schedule.tsx` "Interview mode: Voice / Text" selector (immutable
  after creation). New pool-backed, untimed `engine/brain/cadence/default_text.yaml` +
  `default_yaml_path_for(modality)` so a text interview always has an advanceable default (the no-JD
  paths pick it by modality).
  (3) **TextTurnEngine** (`engine/brain/text/turn_engine.py`) — audio-free discrete one-turn engine
  reusing `QuestionAgent`/`VerifierAgent`/`GuardrailAgent`/`CadenceTracker`/`build_context`
  UNMODIFIED. Verifier + guardrail run in parallel (priority guardrail>verifier); follow-up-cap →
  pool-pop → advance-on-exhaustion; the load-bearing `<think>` directive is persisted as an
  assistant Turn (as the Director does). NO override agent (question-driven, no wall clock to
  override). Emits the SAME eval events the sectioner consumes (session_started / stt_final[source
  text] / question_dispatched / ai_utterance / phase_changed[applied] / session_ended) → a text
  interview scores through the EXISTING pipeline unchanged (verified by feeding its events.jsonl to
  `features/eval/sectioner.build_segments`). Adds `wrap_up_complete`→end handling.
  (4) **Stateless state model** — `CadenceTracker.to_snapshot/restore_snapshot` (build-fresh +
  overlay mutable pool deltas; FIFO + adaptive), `engine/brain/text/state_codec.py`
  (`state_to_jsonable/from_jsonable` dropping audio/VAD fields + HMAC `sign_blob/verify_blob`),
  `TextTurnEngine.snapshot()` + `restore=` ctor. Design (user-directed): the BROWSER holds per-turn
  state and posts it each turn (tier stateless, Redis stays cool); Redis synced ONLY on phase
  transition / explicit Save / end; blob HMAC-signed (browser is a trust boundary). Resume verified
  live: snapshot→sign→verify(+tamper rejected)→restore into a fresh engine→interview completes.
  (5) **Text-tier HTTP service** (`app/text_service.py`, a mountable FastAPI `APIRouter`) — stateless
  `/text/{token}/{start,turn,state,save}`; every request builds a FRESH engine from the posted signed
  blob (nothing in module memory). Redis (`text:state:{token}`) is written ONLY at sync points (phase
  transition / /save / end); between syncs the un-flushed events ride in the signed blob as
  `pending_events` and flush to `sessions/{token}/events.jsonl` at the sync. Store + event-sink are
  injectable (`configure()`) so it tests without Redis/blob; timed cadence → 400 at /start, tampered
  blob → 401. Added `TextTurnEngine.open_turn()` + `_dispatch_ai_turn()` (behavior-preserving refactor)
  for the AI opener. Verified live over HTTP: full interview + resume-from-store + eval-parity sectioner
  tree + tamper/timed rejections; 3 store writes across a 4-turn interview (syncs only).
  (6) **Eval loop closed** — on `ended` the service mirrors artifacts to Blob + enqueues the same
  `eval_v2` worker job voice does (best-effort). (7) **Candidate text UI** — new `ui/web/src/lib/
  textEngine.ts` (HTTP-only store, opaque signed blob held privately + re-posted verbatim, Save→store
  +localStorage, resume prefers server-synced state) + `ui/web/src/pages/CandidateText.tsx` (Lobby with
  the no-recording TermsModal + no mic/camera → chat Live with TranscriptView + Enter-to-send composer
  + Save & finish later → Done); `App.tsx` gained a `CandidateEntry` dispatcher that renders
  `<CandidateText/>` for modality=text else `<Candidate/>` (defaults voice on load/error → voice never
  regresses). Voice `Candidate.tsx`/`candidateEngine.ts` untouched. FE not locally tsc'd (no node) —
  deploy build is the net. Committed on the branch in 4 commits (652fb78, 0a418ac, 1278f8f, c44f8c8).
  (8) **Timed essay phase** (`PhaseDef.written_response{word_limit,time_limit_s}`) — a ONE-SHOT timed
  written-response phase: the submission ends the phase (no verifier follow-up), client-enforced
  word-limit + countdown that auto-submits (`CandidateText.tsx` EssayPanel), service returns an `essay`
  block, essay scored by the usual rubric plugin. (9) **Text-tier ACA packaging (BUILD ONLY, NOT
  DEPLOYED)** — `deploy/text_app.py` (mounts `app.text_service.router` + `/healthz`), `deploy/
  Dockerfile.text` (slim, no audio), `deploy/requirements/text.txt`, `deploy/build_tiers.sh` (+`text`),
  gateway `/text/{path}` httpx reverse-proxy → `TEXT_TIER_URL` (stateless round-robin), `deploy/aca/
  main.bicep` text container app (internal :8080, HTTP-concurrency KEDA, reuses common/llm env +
  admin-secret) wired to the gateway. (10) **Tests** — `tests/test_text_interview.py` (8 deterministic,
  no-LLM: timed flag, written_response validation, tracker snapshot/restore, state codec, HMAC) +
  `tests/_check_text_interview.py` (live smoke). Regression: the full voice suite still passes bar 2
  pre-existing failures (test_eval_plan coding-default, test_jobs stale registry) — voice unaffected.
  Committed on the branch: 652fb78, 0a418ac, 1278f8f, c44f8c8, 4f52436, 228d395, ba924b3, 3a9ef69.
  REMAINING (deferred, NOT blocking a demo): actually deploying the text ACA app; a JD→pool-backed text
  cadence-gen prompt variant; and cadence-EDITOR UI to author an essay phase (both like coding today).
  Files: `engine/brain/cadence/schema.py`,
  `engine/brain/core/cadence_tracker.py`, `engine/brain/text/{__init__,turn_engine,state_codec}.py`,
  `engine/brain/cadence/default_text.yaml`, `app/text_service.py`, `db/models.py`, `db/engine.py`,
  `app/sessions.py`, `app/cadence_service.py`, `app/jobs/jobs.py`, `app/main.py`, `deploy/azure_app.py`,
  `ui/web/src/pages/Schedule.tsx`, `ui/web/src/pages/CandidateText.tsx`, `ui/web/src/lib/textEngine.ts`,
  `ui/web/src/App.tsx`, `deploy/text_app.py`, `deploy/Dockerfile.text`, `deploy/requirements/text.txt`,
  `deploy/build_tiers.sh`, `deploy/gateway_app.py`, `deploy/aca/main.bicep`,
  `tests/test_text_interview.py`, `tests/_check_text_interview.py`,
  `docs/roadmaps/2026-text-interview-mode.md`.

- **Prod-rearchitecture Phase 1 (LiveKit media) — FOUNDATION, on branch
  `feature/phase1-livekit-media`, NOT wired/deployed.** Media plane per the roadmap (plan file
  `hi-so-look-into-jiggly-petal.md`): move AUDIO to a WebRTC SFU (Opus/adaptive/CC/FEC/global edge +
  server-side recording); control/video/coding stay on the existing WebSocket. New package
  `engine/orchestrator/livekit/`: `config.py` (`MEDIA_TRANSPORT` flag, default `websocket` = no
  change; `livekit_settings()` reads `LIVEKIT_URL/API_KEY/API_SECRET` = ACA secretrefs already wired
  on gateway+session-0), `transport.py` (`LiveKitTransport` owns one `rtc.Room` per interview, room
  name = interview token; `LiveKitAudioSource` yields 16k/20ms PCM16 from the candidate track via
  `rtc.AudioStream(sample_rate=16000, frame_size_ms=20)` — LiveKit does the Opus-decode+resample;
  `LiveKitAudioSink` publishes AI PCM via `rtc.AudioSource.capture_frame`; both satisfy the existing
  `contracts/audio.py` Protocols so the brain is unchanged), `tokens.py` (room-scoped candidate +
  agent JWTs via `livekit-api`). Added `livekit-api==1.2.0` to base `deploy/requirements.txt` (rtc
  `livekit==1.1.8` already present). **Verified against the real SDK in a scratch venv:** protocol
  conformance, `play()`→capture (bytes_buffered 0→630 for a 20ms frame), `flush`/`stop`/`frames`
  behavior, and room-scoped token minting (`room` grant + TTL). NB `rtc.Room()`/`AudioSource` need a
  running loop at construction (py3.14) — built inside the async session runner, fine.
  **SERVER-SIDE JOIN NOW WIRED (flag-gated, default websocket = unchanged):** P1-3 — `_session_runner`
  (`azure_app.py` ~1632) constructs+`connect()`s a `LiveKitTransport` (agent token, room=scheduled
  token) and hands `transport.source/.sink` to `InterviewSession` when `MEDIA_TRANSPORT=livekit` +
  creds complete + scheduled token (else Browser source/sink; falls back to WS on connect failure);
  closes the room in the teardown `finally`. P1-4b — `/session-info` (azure_app cloud handler) returns
  `livekit:{url, token}` (room-scoped candidate JWT) when the flag is on, else `livekit:null` → SPA
  uses WS. REMAINING: P1-5 SPA joins via livekit-client (publish mic+camera+screen, subscribe AI
  voice, keep WS for control; handle the `audio_playback_finished` ack over WebRTC — the riskiest
  seam); P1-6 TRACK egress {ai/candidate audio, camera, screen} env-gated `LIVEKIT_EGRESS_TRACKS` →
  `sessions/{token}/recording/` + persist per-track start offsets; P1-6b later ffmpeg mux; P1-7 e2e.
  Files: `engine/orchestrator/livekit/{__init__,config,transport,tokens}.py`, `deploy/azure_app.py`,
  `deploy/requirements.txt`.

- **Prod-rearchitecture Phase 0 (stop-the-bleeding) — on branch `feature/prod-rearchitecture`, NOT
  built/deployed.** First slice of the 500/day-global scaling roadmap (full review in the plan file
  `hi-so-look-into-jiggly-petal.md`). Two low-risk, backward-compatible changes:
  (1) **Mic-silence detector** (the dead-air incident: 24,438 frames arrived at ~43/s yet zero
  speech transcribed). `BrowserMicAudioSource` now computes per-frame **RMS** (numpy, guarded) and
  exposes `mic_health()` + adds `mean_rms`/`voiced_ratio` to `mic_delivery_stats`. The session
  watchdog (`interview_session._check_mic_silence`, runs in `_watchdog_loop`) fires a **`mic_silent`**
  event ONCE when frames are arriving but no voiced energy for a sustained window (grace 20s / warn
  25s, env `MIC_SILENCE_{GRACE,WARN}_S`, floor `MIC_SILENCE_RMS_FLOOR=45`). Resolves silent-capture
  vs lost-in-transit for future incidents. Observability only — does NOT alter interview flow; a
  candidate-facing warning UX is a deliberate follow-up. Files: `engine/orchestrator/web/audio_source.py`,
  `engine/brain/runtime/interview_session.py`.
  (2) **Per-shard session cap** — `lifecycle.claim` acquired the shard counter with cap `None`
  (bookkeeping only). Now capped via `admission.max_shard_sessions()` (env `SHARD_MAX_SESSIONS`,
  **default None = uncapped, preserves today's behavior**); over-cap claims roll back the cluster
  counter and return `shard_at_capacity` (rejection path is generic → handled). Files:
  `app/coordination/admission.py`, `app/session_tier/lifecycle.py`, test `tests/test_session_tier.py`
  (`test_claim_shard_at_capacity`).
  **Deferred/decisions:** the "per-phase resume-budget reset" (`azure_app.py:1681` `resume_count:0`)
  is **documented as intentional** (per-phase fresh start), NOT changed — needs a user decision on
  per-interview vs per-phase capping. `MAX_ACTIVE_SESSIONS`/`MAX_LLM_INFLIGHT` are code-supported env
  caps (values are a deploy-time op decision, not baked to avoid surprising the live stress config).
  Verified: py_compile all; `tests/test_session_tier.py` (10) + `test_coordination.py` (8) green
  (scratch venv w/ pytest-asyncio+fakeredis+lupa). NOT deployed.

- **Cadence editor: two-turn create flow was unreachable (router clarification lost the verb) —
  NOT COMMITTED (user commits), verified live 3/3.** Found while tracing the add-a-new-phase
  feature as an actual CONVERSATION rather than a single message — the shape all prior testing
  missed. `add a system design round` correctly asked *"How long should it be, and what should it
  cover?"*, but answering `10 minutes, focus on scalability trade-offs and caching` **in a separate
  message** (as the question invites) came back *"There's no phase by that name in this plan. For
  the 10:00 you asked for, did you mean the technical-questions phase?"* — the plan never changed,
  so nothing was corrupted, but the feature only worked if the admin happened to put everything in
  ONE message. Root cause: router prompt rule 5 requires a clause's `text` to be the admin's own
  words for that instruction, so on a clarification turn it emitted the **answer alone** — which
  contains no `"add"`. Both `detect_structure_verb` and `cadence_service._resolve_add_asks` key off
  that verb (the resolver is only called for clauses whose verb is "add"), so turn 2 was classified
  as a DURATION ask against an existing phase and the RESOLVER never ran. Fix: new router prompt
  **rule 6** — a clarification's text is `"<original instruction> — <answer>"`, with the reason
  stated in the prompt (a later step inspects the text for the original verb, and the admin never
  repeats "add" when merely answering a question about duration and coverage). Verified live 3/3:
  turn 2 now yields `Added a new system-design phase, set to 10:00` + `Interview is now 25:00 (was
  15:00)`, with `system_design` at 600s and real generated prompts. Pinned by
  `test_regression_a_clarification_keeps_the_ORIGINAL_verb_in_its_text`, which asserts the
  CONSEQUENCE (verb survives → routes as an add → creates, with duration pinned and the brief
  reaching the modifier) rather than the prompt wording, so it fails if rule 6 is ever dropped.
  **141 cadence tests** (was 140). Also noted while verifying: one run hit a transient provider
  error inside the resolver and the turn came back as a QUESTION with the plan untouched — the
  fail-closed path working on an unstaged failure. Files: `config/prompts.yaml` (`cadence_router`
  rule 6), `tests/test_cadence_agents.py`, `docs/cadance&verify.md` (§3.6 rewritten with the
  full two-turn conversation trace + real generated YAML, new §4b add-routing diagram, §7 create
  loop, §11 round 4). **§2 subsequently rewritten** so every agent is identified by the name you
  grep for — class, file, Langfuse `name`, `stage`, prompt key — with a four-agent system diagram
  and a full `add a system design round` trace showing all four agents + the tools layer on one
  request (the create walkthrough now lives in §2; §3.6 points at it, §4b is the branch map).

- **Cadence editor: duration scope/preposition bugs · LLM phase resolver replaces keyword
  matching · create-a-new-phase flow — NOT COMMITTED (user commits), local images rebuilt +
  verified.** Three connected pieces of work on `docs/cadance&verify.md`'s system.
  **(1) Duration bugs (from a live admin session, numbers reproduced exactly).**
  `reduce the time of warm up to 30 seconds` on a 7:30 interview set the warm-up to **7:00** and
  made the interview LONGER; two more asks in the same session gave 4:00 and 9:30. Every result was
  `interview_total − 30` written onto the PHASE. Two independent root causes, both confirmed in
  code: (a) `plan_deterministic` resolved the number ONCE at the top of the duration step via
  `resolve_total_target(text, current_total)` — the INTERVIEW's total — and only afterwards worked
  out that the clause targeted a phase, so a phase-scoped relative ask got the interview's
  arithmetic. Fixed by resolving **scope before the number**; a relative ask is now measured
  against the phase's own `duration_s` (or the total for an ALL-scoped ask), with a guard that
  ASKS rather than writing a value at/below zero. (b) `" reduce"` is in
  `RELATIVE_DURATION_MARKERS`, so `"reduce … TO 30 seconds"` parsed as a delta — but the
  **preposition** carries that meaning, not the verb. New `_ABSOLUTE_TO_RE` makes an explicit
  `to <digit>` outrank a direction verb; `"to"` must be followed by a number so `"add 30 seconds
  to the warm-up"` stays relative. **Also fixed a PRE-EXISTING bug on `HEAD`** found while testing
  and verified by running HEAD's source in isolation: `detect_structure_verb` saw `"add"` and gave
  the clause to the STRUCTURE step before the duration step ran, so `"add 2 minutes to the warm
  up"` answered *"the warm-up phase is already in this plan"* and `"add 2 minutes to the whole
  interview"` answered *"I can't create a brand-new phase"* — neither added time. New
  `is_time_change_ask` (time verb directly followed by a number AND a parseable duration) keeps
  arithmetic out of the structure path, while `"add 2 questions about caching"` is neither and
  still reaches the content editor. Router `_normalize` now counts a RELATIVE duration as "a number
  the admin gave" too (was absolute-only), so such a clause is taken back from an ambiguity verdict.
  **(2) Keyword matching replaced by an LLM phase RESOLVER** (`app/cadence_agents/phase_resolver_agent.py`,
  prompt `cadence_phase_resolver`). WHY: code was measurably bad at this one — `"add a coding
  discussion"` scores **0.95** against `coding_round` in `resolve_phase_ref` ("round" is a stopword,
  so that id's only significant token is "coding"), so the discussion ask got the coding-picker
  refusal and added nothing. Alias lists would need hand-maintained spellings per phase and still
  land confidently wrong. The resolver matches on each candidate phase's **`intent`** across three
  sets (in-plan / available-from-catalog / blacklisted) or returns "none → a new phase", and
  `config/phase_blacklist.json` is now DATA with `intent` + `reason` and **no aliases**. Contract is
  `phase_ids: []` (a LIST) because one clause legitimately names several — `"add the wrap up and a
  coding phase"` arrives merged, and answering only the first silently lost the other half.
  **Fails CLOSED**: a failed call, malformed reply, or invented phase id all yield no resolution →
  the admin is asked, never a guessed phase. It runs ONLY for "add" clauses, so an ordinary edit
  costs the same calls as before. Live-measured 11/11 correct across 5 consecutive runs (incl.
  coding-round vs coding-discussion vs new-phase vs restore vs the two-phase clause); getting there
  needed the prompt to say explicitly that **returning a blocked id is required** — the model
  otherwise read "blocked" as "unavailable, so invent one" and fabricated `coding_exercise`/`coding`
  phases (failed 3/3 runs before that line).
  **(3) Creating a genuinely new phase** (`"add a system design round"`), previously refused. Now
  asks for the two things that can't be inferred — **duration** (code parses it; it changes the
  interview length and the schema demands `total == Σ phases`) and **coverage** (the resolver's
  `covers`, deliberately empty when they only named a phase, never filled from the name) — with
  **no clickable duration chips**, because a chip answers half the question and would author the
  content from a bare name; the question narrows instead when only one arrives. Id derived in code
  from the admin's words (`system_design`, uniquified, pattern-checked), a schema-valid SKELETON
  inserted **before wrap-up**, duration PINNED, then the MODIFYING agent authors `intent` +
  `generic_prompts` from the brief (so an LLM failure leaves a usable phase, not an unloadable
  plan). `code_discussion` is added from the ONE existing definition
  (`cadence_service.CODE_DISCUSSION_PHASE`, reached via the catalog — never generated) and lands
  AFTER the coding round it reviews; with no coding round present it CONFIRMS first, and a "no"
  answer is terminal so the chat can't loop. An "add" whose object is content
  (`"add 2 questions about caching to the technical round"`) is routed to the content editor
  instead of dead-ending on "that phase is already in this plan".
  Verified: **140 cadence tests** (was 112) incl. regression tests pinning every number from the
  reported session, to-vs-by, time-vs-phase, resolver fail-closed/hallucinated-id/malformed-reply,
  and the create gate; full `pytest tests/` diffed against a `git stash` baseline — **20 failures
  before and after, byte-identical, zero regressions**; live end-to-end through
  `revise_cadence_conversational` on the real model for all six duration cases and all six
  add/create cases. Files: `app/cadence_agents/phase_resolver_agent.py` (new),
  `config/phase_blacklist.json` (new), `app/cadence_agents/{phase_tools,router_agent,__init__}.py`,
  `app/cadence_service.py`, `config/prompts.yaml`, `tests/test_cadence_agents.py`,
  `docs/cadance&verify.md` (rewritten for the four-agent system: the resolver, the blacklist, the
  create flow, scope-before-number, and §11 round 3).

- **Coding-panel unmount handshake + interview-tagged AI audio — COMMITTED, NOT built/deployed
  (target: base rebuild → session + gateway; SPA via gateway).** Two fixes from a live-interview
  trace (`events-46d0513b.jsonl`) + a concurrent-interview report.
  (1) **Coding-panel dismount handshake.** The director advanced `coding_round → code_discussion`
  and dispatched the AI's discussion turn in the SAME tick it emitted `coding_phase_ended`, never
  waiting for the browser to unmount Monaco — so the editor stayed live (candidate still typing:
  `coding_code_edit` 66s AFTER `coding_phase_ended`) while the AI talked over it. Fix: a bounded
  client→server ack. `Director` gained `self._coding_close_event` (asyncio.Event) +
  `_coding_close_timeout_s` (env `CODING_PANEL_CLOSE_TIMEOUT_S`, default 2.5s) +
  `on_coding_panel_closed()`. In the apply block's coding-EXIT hook (`director.py` ~L751), on
  leaving a coding phase it `clear()`s the event before emitting `coding_phase_ended`, then
  `await asyncio.wait_for(self._coding_close_event.wait(), timeout=…)` (log + proceed on timeout)
  BEFORE the next phase's opening turn dispatches — pausing only the tick, on the same YES tick,
  so `coding_phase_ended` goes out, the client unmounts + acks, then the discussion dispatches.
  This covers EVERY coding exit (time budget, override advance, candidate-asks-to-end,
  all-submitted) because they all funnel through the one apply block. After the await it
  **re-anchors `self._tracker._phase_started_at_ms = self._elapsed_ms()`** so the next round's
  timer starts AFTER dismount (mirrors the resume-clock re-anchor). Client: `coding_panel.js
  unmount()` sends `{type:"coding_panel_closed", phase_id}` before disposing. Inbound: added
  `coding_panel_closed` to `_CODING_INBOUND` + `_on_coding_inbound` → `session._director.
  on_coding_panel_closed()` in BOTH `deploy/azure_app.py` and `engine/orchestrator/web/launcher.py`.
  Terminal-coding phase (submit → end, no next phase) skips the handshake — panel unmounts on
  session end, no round to time.
  (2) **Interview-tagged AI audio (fix cross-interview audio bleed).** A candidate ran two
  interviews at once (distinct tokens, two tabs, one device) and interview 2's recording had
  interview 1's AI voice (mic + video correct). Root finding: AI audio is UNTAGGED — the wire
  frame is `0x00 + pcm`, `audio_start` carried only text/sub_id/sample_rate; association was
  purely positional, and the **recording is assembled entirely in the browser** (MediaRecorder
  taps tag-0 PCM off the socket; no server-side merge). Every routing hop (gateway resolve, shard
  broadcaster/sink/bus) is per-token, so the static cause wasn't found — but a connection-level
  swap would cross mic+video too, and only AI crossed, so the tag is both fix + instrument. Fix:
  `WebBroadcaster.session_id` (new attr, set to the interview token in `azure_app.py` right after
  construction) is stamped onto `emit_audio_start` as `session_id`. The candidate + observer
  browsers (`candidateEngine.ts` / `observerEngine.ts` `audio_start` handler) DROP any utterance
  whose `session_id` ≠ their own token (don't open `activeRecv` → the following tag-0 PCM is
  neither played nor recorded) and `console.warn("[audio-guard]…")`. The gateway
  (`app/gateway/ws_proxy.py` `_pump`/`shard_to_client`, now passed `token`) logs a tripwire
  warning if a relayed `audio_start`'s `session_id` ≠ the connection's token (relay unchanged;
  browser enforces). Envelope tagging suffices because each `audio_start` + its PCM ride the same
  per-session queue; escalate to per-frame 4-byte ids only if a mismatch ever slips through with a
  correct envelope. **Future (separate initiative):** move recording/media to a LiveKit media
  server on an Azure VM — server-side per-session AI-audio recording (association by construction)
  + removes browser-recording gaps (no chunk retry; last-~3s loss on abrupt close). Verified:
  py_compile all 5 backend files; `tests/test_gateway.py` green (resolve_target unaffected).
  Files: `engine/brain/core/director.py`, `deploy/azure_app.py`,
  `engine/orchestrator/web/launcher.py`, `engine/orchestrator/web/broadcaster.py`,
  `app/gateway/ws_proxy.py`, `ui/web/src/coding/coding_panel.js`,
  `ui/web/src/lib/candidateEngine.ts`, `ui/web/src/lib/observerEngine.ts`.

- **Phase-boundary attribution fix: a candidate answer that straddles a phase change now
  stays in the phase it was answering — COMMITTED, NOT built/deployed (target: base rebuild →
  gateway + worker).** Root cause: the director emits `phase_changed` **twice** per transition
  — a QUEUED pre-announcement (`payload.queued=True`, `reason` in
  `time_budget`/`tracker_jump_to_terminal`/`llm_override_advance`/`llm_override_end_now`) fired
  the instant the phase clock expires, **ungated even mid-utterance** (director.py:2264/2277/
  1841/1864), then the real APPLIED marker (`reason="natural"`, no `queued` flag) once the
  candidate stops speaking (director.py:746 — gated on `not state.candidate_speaking`; all
  pending phases funnel through this one apply block). When the clock expires mid-answer the
  true order is `phase_changed(queued,→Q)` → `vad_endpoint` → `stt_final` (the answer to the
  OLD phase P, which carries NO phase label) → `phase_changed(applied,→Q)` →
  `question_dispatched(Q)`. Every positional parser switched buckets on the FIRST
  `phase_changed` (the queued one), so the answer landed in Q — and in the v2 sectioner it
  dropped into Q's `warmup` seed segment, which is discarded at seal, so the answer was silently
  lost from scoring. Fix (read-time, deterministic, **works on existing logs** since both
  markers are already recorded; **no director/emit/live-path change**): segment on the applied
  marker only — treat a `phase_changed` with `payload.get("queued") is True` as a non-boundary.
  Added the identical inline guard in all positional readers: `features/eval/sectioner.py`
  (`build_segments`, v2 benchmark — the eval-critical one), `app/event_viewer.py`
  (`group_by_phase`, admin trace timeline) + `annotate()` labels the queued row `"Phase
  (pending)"` so the flat trace doesn't show two identical Phase rows, `app/evaluation_service.py`
  (`_assemble_transcript`, v1 LLM transcript), and `app/resume_collapse.py` (walk-back skips
  queued markers so the crash-interrupted-phase anchor is the applied entry, not a
  pre-announcement for a different phase). Backward-compatible (old single-marker logs have no
  `queued` field → unchanged). NOTE (flagged, NOT fixed — separate change): the v2 sectioner path
  `app/plugin_evaluation.py:172` calls `build_segments` on RAW events and does NOT run
  `collapse_resumed_events` first (unlike the v1 transcript + trace viewer, which both collapse),
  so a crash-resumed interview's v2 benchmark can double-count the pre-crash partial phase.
  Verified: py_compile all 4 files; new `tests/test_phase_boundary_attribution.py` (6 tests:
  straddling answer stays in the prior phase across sectioner / group_by_phase / v1 transcript,
  the queued row is labeled distinctly, resume-collapse anchors on the applied entry, and an
  end-to-end collapse+bucket) all green; no regression — existing `test_sectioner` (10),
  `test_plugin_aggregate` (6), `test_eval_plugins` (13), `test_eval_plan` (14, excluding one
  pre-existing `plan_from_cadence` default-assignment failure unrelated to this change) all pass.
  Files: `features/eval/sectioner.py`, `app/event_viewer.py`, `app/evaluation_service.py`,
  `app/resume_collapse.py`, `tests/test_phase_boundary_attribution.py`.

- **Stress-test setup + upstream-429 throttle attribution (target v32: base + session-0 +
  grafana).** For a single-shard stress test: (a) **env-only, no rebuild** — gateway
  `SESSION_SHARDS=session-0` (+ matching `SESSION_SHARD_FQDNS`) so ALL new interviews route to
  session-0 (session-1 derouted, replica left running); session-0 `SPEECH_STREAMS_PER_KEY=50`
  (was default 5) lifts the Azure-Speech-pool gate that effectively capped concurrency at 5 (1
  key × 5). `MAX_ACTIVE_SESSIONS` stays unset (uncapped). With the pool cap at 50 the Groq STT
  fallback never engages under 50 concurrent, so it's a clean Azure-only test. (b) **NEW metric
  `interview_rate_limited_total{service,key_id}`** — one Counter, incremented at the three
  provider chokepoints when an upstream THROTTLES (429 / too-many-requests / quota): LLM
  (`llm/client.py` `_note_error` in both `except` paths, `service="llm"`, key_id = provider+hash),
  Azure STT (`azure_stt_client._on_canceled` — a throttle surfaces as a CANCELED event, not an
  exception; `service="stt"`), Azure TTS (`azure_tts_client._synthesize_and_stream` — a throttled
  synth returns a CANCELED result; `service="tts"`). STT/TTS `key_id` = `sha256(speech_key)[:8]`,
  the SAME id as the admission counter + `interview_speech_inflight` gauge, so a 429 lines up on
  its key's in-flight concurrency. Detection is a shared, broad, string-based
  `prom.is_throttle_error()` (status-code 429 OR markers: 429/too many requests/throttl/rate
  limit/quota/toomanyrequests) so it works across the OpenAI SDK + Azure Speech SDK cancellation
  codes without depending on provider exception types; all emit sites are guarded (metrics never
  break a call). Prometheus scrapes it automatically (no scrape-config change). (c) **Grafana**
  (`deploy/observability/dashboards/interview.json`) new row id=107 + panel id=17 "Upstream 429 /
  rate-limit vs concurrent interviews — the scale ceiling": BARS = `sum by (service,key_id)
  (rate(interview_rate_limited_total[1m]))` (per LLM key + per Speech key), LINE (right axis) =
  `max(interview_active_sessions)`; when a 429 bar lifts off zero, the concurrent-interviews line
  at that instant = the concurrency at which THAT key started throttling. Grafana image bakes the
  dashboard → grafana app must be redeployed for the panel. Verified: py_compile 4 files; dashboard
  json.load + panel-id uniqueness; is_throttle_error unit cases (429 exc / groq str / azure
  TooManyRequests / quota → True; timeout / validation / auth / 500 / None → False). Files:
  `engine/brain/observability/prom.py`, `engine/brain/llm/client.py`,
  `engine/brain/streamA_bridge/azure_stt_client.py`, `engine/brain/streamA_bridge/azure_tts_client.py`,
  `deploy/observability/dashboards/interview.json`.

- **Cadence editor: re-adding a REMOVED phase (restore, never generate) — NOT COMMITTED (user
  commits), local images rebuilt + verified.** Follow-up from a live session: dropping the wrap-up
  worked, but asking to add it back hit "I can't create a brand-new phase". Root cause: removal
  deletes the phase from the working YAML, so there was nothing to restore FROM — the only way to
  honour the ask would have been inventing a body, which is the thing the editor refuses.
  Fix: a **phase catalog** (`cadence_service._phase_catalog`) of phases we can legitimately put
  back, from three sources — the working plan at turn start (makes remove-then-re-add work inside
  ONE message), the SAVED plan for the interview (`db.cadence_yaml`, carries generated/custom
  phases with this interview's real durations), and `engine/brain/cadence/default.yaml`. Order
  comes from the saved plan first with the built-in only filling gaps (`setdefault`) — otherwise a
  restored `wrap_up` lands ahead of generated phases just because it's earlier in the built-in
  file. `plan_structure_op(text, phases, catalog)` resolves the add against phases that are
  MISSING (a present one → "already in this plan"), returns the real body on `StructureOp.phase_def`,
  and `_insert_by_catalog_order` places it: explicit before/after wins, then first/last, else its
  catalog position. Restoring is never generating: a name in no catalog is still refused, and a
  coding phase is never restorable (`_is_coding_phase`) because it needs question ids → picker.
  Three additional defects found and fixed while testing this, each a silent loss:
  (1) **split phrasal verbs** — `"put the wrap-up back"` never matched `"put back"` contiguously so
  it read as a REORDER; `detect_structure_verb` now recognises `back` + put/bring/get/restore,
  unless a positional word (`_POSITIONAL_RE`) means they really meant order.
  (2) **`"add … and make it 3 minutes"` dropped the number** — `" add "` is a RELATIVE duration
  marker, so the structure verb made the clause parse as relative and return nothing;
  `_strip_structure_verbs` runs before the duration parse, and a clause carrying BOTH a structure
  op and a duration now honours both (`"Added the wrap-up phase back, set to 3:00"`, pinned).
  (3) **`"add wrapup phase and coding phase"` lost the wrap-up** — the router reliably merges this
  into ONE clause (5/5 runs), and the coding check refused the whole clause; the coding test now
  runs only when no restorable phase is named, and `StructureOp.extra_refusal` lets one clause
  emit an applied outcome AND a refusal. Verified: 112 tests (12 new) + live e2e on all five
  shapes. Files: `app/cadence_agents/phase_tools.py`, `app/cadence_service.py`,
  `tests/test_cadence_agents.py`, `docs/cadance&verify.md` (rewritten as a plain-language guide to
  the whole system: agents, tools, pipeline diagram, extraction/patching, edge cases, examples).

- **Cadence editor v4: deterministic pre-pass owns structure+duration; validator owns the
  chat — NOT COMMITTED (user commits), local images rebuilt + verified.** Four defects from a
  live admin session on `remove the wrapup phase and make whole interview 15min and warumup
  2min30sec` — all three asks silently failed and all four phases were reported as edited.
  Root causes (each confirmed in code, not guessed):
  (1) **`_apply_remove` couldn't match "wrapup"**. It tried `phase_id.replace("_"," ")` →
  `"wrap up"`, absent from `"the wrapup phase"`; the difflib fallback scored the WHOLE
  instruction against the id (0.65) under a 0.7 gate. No match → the clause fell through to
  the ModifyingAgent, which can only rewrite a phase's questions, so it reported
  `wrap_up: questions updated` for a phase the admin asked to DELETE.
  (2) **the router asked to confirm a number it had already parsed** ("...exactly 15 minutes
  (900 seconds)?"), so `total_instructions` was empty, `_apply_total` never ran, and the total
  was merely recomputed as the phase sum (4:00 → 6:00).
  (3) **`_change_summaries` diffed raw YAML against a pydantic dump.** The dump injects
  `question_pool: []` / `coding_question_ids: []` / `adaptive_difficulty: false`, so
  `phase_content_view(before) != phase_content_view(after)` for EVERY phase → phantom
  "questions updated" on phases nobody mentioned.
  (4) **the validator only LLM-checked CONTENT clauses** (structure/duration never reached it)
  and shared the modifier's model handle — the same model grading its own homework.
  Changes: **`phase_tools.py` is now the deterministic layer** — `resolve_phase_ref` matches
  separator-insensitively (`_squash`: "wrapup"=="wrap up"=="Wrap-Up"=="wrap_up"), scores on a
  graded ladder (id-in-text 1.0 > all-id-tokens 0.95 > typo-on-name 0.85+ > partial tokens
  0.5+ > INTENT overlap 0.45+), and returns **no match** on a near-tie (<0.06 apart) or below
  `CONFIDENT_REF=0.9` so a guess is CONFIRMED, never applied — that is the "there's no HR
  round, did you mean warm-up?" behaviour, via `ask_which_phase` which names the guess.
  `plan_structure_op`/`apply_structure_op` do remove/reorder/move as LIST OPERATIONS with
  **zero LLM calls**, each carrying its own admin-facing sentence; "add" is refused with a
  reason ("add a coding phase" points at the coding-question picker, since it needs question
  ids). `plan_deterministic` is the new single decision point: structure → durations →
  whatever is genuinely left is the ONLY thing the modifier sees, and it detects
  same-scope duration conflicts. **The router is now a splitter only** — its `phase_id` is a
  HINT (an unusable id is blanked, not rejected), and code TAKES BACK any clause it marked
  ambiguous/beyond_capability that carries an explicit duration or a structure verb.
  `capability_message` now handles a full-SENTENCE reason (was emitting "I can't Creating a
  brand-new phase is not supported"). **The validating agent authors the chat**: one
  `ClauseOutcome` per INSTRUCTION (not per phase diff) with `verdicts:[{id,satisfied,summary}]`
  from its own prompt, running on its **own model handle** (`_build_cadence_llm(role="validate")`,
  `CADENCE_VALIDATOR_MODEL`/`_PROVIDER`); numbers re-pinned + total reconciled in code;
  structure verified by set membership; `_name_phase` GUARANTEES every line names the phase it
  touched (a prompt is a request, this is a requirement). Fails OPEN — no verdict never raises
  a shortfall, so a broken validator can't burn retries or invent a failure.
  `phase_content_view` collapses absent and empty-valued keys so normalisation can't read as
  an edit. Verified: 100 tests (6 new regression tests pinning each defect) + live e2e — the
  reported turn now yields exactly `Removed the wrap-up phase` / `Set the whole interview to
  15:00` / `Set the warm-up phase to 2:30`, plan `warm_up 150 + resume 390 + technical 360 =
  900`. Files: `app/cadence_agents/{phase_tools,router_agent,validating_agent,__init__}.py`,
  `app/cadence_service.py`, `config/prompts.yaml` (`cadence_router` + `cadence_validator`
  rewritten as readable block scalars), `tests/test_cadence_agents.py`.

- **phase_tools refactor: centralize duration/mutation/fuzzy-matching logic — COMMITTED, DEPLOYED, VERIFIED**.
  Consolidated all deterministic cadence edits into one `phase_tools.py` module, replacing the old
  `duration.py`: (1) **Duration arithmetic** (parse_absolute/relative, resolve_total, rescale_to_clean_minutes)
  ensures whole-minute allocations ("make the whole interview 15 minutes" → 2/4/7/2 min, not 1:53/3:45/7:30/1:52).
  (2) **Phase mutations** (detect_and_apply_phase_mutations, _apply_remove, _apply_reorder) — deterministic
  tools for remove/reorder operations, never sent to LLM. (3) **Fuzzy phase matching** (find_best_phase_match)
  uses Levenshtein distance on phase intents, works for any phase/text. (4) **Context precision**
  (extract_context_for_instruction) — context attached ONLY to instructions mentioning project/resume/skills,
  not indiscriminately to all instructions in a phase (fixes edge case where "make it friendlier" got resume
  context meant for "ask about their projects"). Updated ModifyingAgent to use the new function; all agents
  now import from phase_tools. Tests: 91 passing (+10 new for phase_tools functions). Verified in container:
  15-min target lands on whole minutes, context surgical, vague phase refs ask for clarity (not rejected).
  Files: new `app/cadence_agents/phase_tools.py` (209 lines, centralized + new functions), updated
  `modifying_agent.py` (context extraction), `router_agent.py` / `validating_agent.py` / `__init__.py`
  (imports), `tests/test_cadence_agents.py` (+10 tests).

- **Eval-plugin cadence-validation messages: real examples + phase attribution (branch
  `feature/optional-recording-gate`).** Extends the message-quality pattern first done for
  Dynamic Difficulty to every built-in evaluation plugin's `precheck_cadence` — validation
  logic/pass-fail is unchanged everywhere, only message text. Two categories: **cadence-fixable**
  rules (the remedy is content in cadence.yaml) get a single-line JSON example appended as its own
  `unmet` element — `dynamic_difficulty` (missing/wrong `question_pool`, real key names/nesting but
  necessarily placeholder content since nothing exists yet to source from), `coding` (missing
  `coding_question_ids`, id pulled live from `features.coding.questions.loader.load_library()`,
  placeholder fallback if the library fails to load), `coverage_tags` (missing `coverage_tags` on
  the phase's questions — real tag only when derivable, which for this specific rule it structurally
  never is, since the `any(...)` check above it already covers the case where some question DOES
  have one). **Config-fixable** rules (the remedy is plugin config in the eval plan, not the
  cadence) get a plain-English instruction sentence instead, naming the real allowed values and
  which UI card to use, no JSON — `conversational_rubric` (no `score_dimensions`, lists the real
  `CANONICAL_DIMS` keys), `rubric_marks` (no `criteria`, points at "+ Add option"), `coverage_tags`'s
  second half (no `required_tags` either, points at the Coverage Tags card). **Phase attribution**
  (`features/eval/plan.py::validate_plan_against_cadence`): every `unmet` string — including a
  rule's appended example line, and the `invalid config: {e}` path — is now prefixed with
  `"{phase_id} / {plugin_id}: "` in this ONE shared place, so a message copied out of its UI context
  (e.g. pasted into "Revise with AI") still says which phase it's about; two phases failing the
  identical rule previously produced byte-identical, unattributable strings (verified before the
  fix). `app/main.py::_eval_plan_gate` (the approval-gate's combined banner) no longer adds its own
  redundant copy of that prefix — would have doubled it now that `unmet` carries it natively; traced
  every other landing spot for that function's output first (the Jinja `cadence_review.html` call
  site is dead code, that template doesn't exist on disk) before touching it. `SchemaForm.tsx`
  (generic schema-driven plugin config form): the one shared "one per line" textarea placeholder
  (fed `score_dimensions`/`ignore_dimensions`/`required_tags` off the same line of code) and the
  previously-bare `purpose`/`seniority_bar` string inputs now show concrete, code-derived sample
  content via two small name-keyed maps, falling back to the old generic text for anything unlisted
  so a future plugin's field isn't left with nothing. New regression test
  (`tests/test_eval_plan.py`) iterates the plugin registry and fails if any plugin's
  `precheck_cadence` failure omits both an "Example:" line and an "Evaluation panel" reference — a
  sixth plugin can't silently ship a bare message. Verified: py_compile all touched backend files;
  `tsc --noEmit` + full `vite build` clean; full `pytest tests/` — 206 passed (the same 3
  pre-existing unrelated failures as the baseline, confirmed via a real diff comparison, not
  assumption); every JSON example round-tripped through `json.loads`; live-verified (not from
  cached bytecode) against the actual edited source inside `interview-agent-base:local`. Files:
  `features/eval/plan.py`, `app/main.py`, `features/eval/plugins/builtins/{dynamic_difficulty,
  coding,coverage_tags,conversational_rubric,rubric_marks}/__init__.py`,
  `ui/web/src/components/SchemaForm.tsx`, `tests/test_eval_plan.py`.

- **Optional per-interview recording gate (branch `feature/optional-recording-gate`) — NOT yet
  merged/built/deployed.** The "Record this interview" checkbox on the New Interview form
  existed end-to-end (DB `record_enabled` column → `/session-info`) but was a dead wire — the
  candidate frontend always forced camera+screen (a prior admin-configurable-proctoring attempt,
  commit `796baab`, was reverted wholesale in `febcfee` for an unrelated bundled bug). This
  revives it, with the flag kept in TWO places by design: `sessions.record_enabled` (DB,
  admin-facing, immutable after creation) AND a new `recording_enabled` key stamped into
  `cadence.yaml` at every generation/regeneration chokepoint (never LLM-authored — see
  `app.cadence_service.apply_recording_flag`, called from `app/sessions.py` create/update's
  no-LLM branches and from `app/jobs/jobs.py::_cadence_gen`, which covers both first-generation
  and "regenerate cadence" since both funnel through it). `CadencePlan` gained a real
  `recording_enabled: bool = True` field (`engine/brain/cadence/schema.py`) so it survives
  `model_dump()` round-trips (revise-with-feedback, coding-phase edits) instead of being
  silently dropped as an undeclared key. `/session-info` (`app/main.py` + `deploy/azure_app.py`,
  kept in sync) reads it from the approved cadence.yaml first, DB as pre-approval fallback;
  missing-key/NULL always reads as `True` (today's mandatory-camera+screen behavior, so every
  pre-existing interview is unaffected). **Immutable after creation, by construction**: the
  Schedule.tsx checkbox is `disabled` in edit mode (browsers exclude disabled inputs from
  `FormData`) *and* `app/sessions.py::update_draft` never writes `record_enabled` from the form
  at all — belt and suspenders. Also fixed a live bug found in discovery: `GET
  /api/schedule/{token}/edit` never returned `record_enabled`, so editing any interview
  silently reset it to unchecked unless the admin re-ticked it.
  **Candidate side** (`candidateEngine.ts`, `Candidate.tsx`): `refreshStartReady()` only
  requires camera+screen when `recordingEnabled`; `startRecording()` no-ops entirely when off
  (both `MediaRecorder`s + `buildRecMix()` skipped) — the mic `getUserMedia`/AudioWorklet path
  was already a separate call from camera, so this can't touch live audio-to-AI or the
  transcript (STT → `events.jsonl`, confirmed architecturally independent of any recording
  artifact). Camera/Blur/Screen lobby rows are unrendered (not disabled) when off; interviewer
  defaults to Minimal (orb) only when off AND the candidate hasn't already picked a mode
  themselves (`visualModeUserSet` guard). Top-bar Screen/Blur toggles hidden when off; the
  Camera toggle is disabled *while on* (candidate can't voluntarily switch it off) but
  re-enables if the camera track ends unexpectedly — which surfaced a real, unrelated gap: there
  was previously **no** `onended` handler on the camera track at all (only screen had one), so
  an unplugged camera / OS-revoked permission silently froze with no signal to anyone; added one
  (no auto-reacquire, matches the existing screen-drop pattern). **Consent**: recording-off
  interviews get their own Terms & Conditions text (`interviewTerms.ts`:
  `INTERVIEW_TERMS_NO_RECORDING` / `TERMS_INTRO_NO_RECORDING` / `TERMS_VERSION_NO_RECORDING =
  "2026-08-03-no-recording"`) that doesn't claim consent for camera/screen/recording that isn't
  happening — `TermsModal` now takes a `recordingEnabled` prop to pick the variant; the
  recording-ON text/version is untouched. Verified nothing server-side validates the accepted
  terms version (no enum/DB constraint), so adding a second version string was safe. Report
  tabs needed NO changes — confirmed in discovery that the Recording tab already degrades
  gracefully by status-independent 404→fallback, there's no automated proctoring job to crash,
  and "Integrity & Proctoring" is just the observer's manual notes (unrelated to media).
  Verified: `tsc --noEmit && vite build` clean; `py_compile` on all touched backend files clean;
  full `pytest tests/` run inside the `interview-agent-base:local` image — 187 passed, the 20
  failures all confirmed pre-existing (stale fakeredis Lua-`eval` support, missing `livekit` in
  the base image, two unrelated stale assertions) via `git stash` + re-run on unmodified
  `interview-scaled-dev`. Files: `db/models.py`, `app/sessions.py`, `app/main.py`,
  `app/jobs/jobs.py`, `app/cadence_service.py`, `engine/brain/cadence/schema.py`,
  `deploy/azure_app.py`, `ui/web/src/lib/candidateEngine.ts`, `ui/web/src/pages/Candidate.tsx`,
  `ui/web/src/pages/Schedule.tsx`, `ui/web/src/lib/interviewTerms.ts`,
  `ui/web/src/components/TermsModal.tsx`.

- **Crash-resume hardening: reconnect overlay · cumulative time · coherent resume trace/eval —
  COMMITTED, NOT built/deployed (target v24: base + gateway + session + worker).** Four connected
  fixes for the shard-restart-mid-interview experience (from a live resume test, token
  fcecdd47).
  ① **Client reconnect (frontend → gateway).** The old handler gave up after 3 attempts / ~9s then
  told the candidate to refresh — far too short for a ~60-90s shard restart. [candidateEngine.ts](ui/web/src/lib/candidateEngine.ts):
  `RECONNECT_MAX=30` with capped backoff (≤4s → ~2 min window), a new `reconnecting` snapshot flag
  (reset on WS open), and only the give-up modal after the full window. [Candidate.tsx](ui/web/src/pages/Candidate.tsx):
  a calm persistent "Reconnecting… your interview will resume automatically" overlay while
  `reconnecting`, so there's no silent dead air.
  ② **Resume announce (session).** [`_resume_bringup`](engine/brain/runtime/interview_session.py) already
  announced before rehydrate; strengthened announce-2 to explicitly say we're restoring the session
  and picking up where we left off.
  ③ **Cumulative time, fresh phase budget (session + checkpoint).** Checkpoint now stores
  `elapsed_ms_at_phase_entry` ([interview_checkpoint.py](app/coordination/interview_checkpoint.py) blob +
  `_write_checkpoint`); `InterviewSession._resume_elapsed_offset_ms` lifts `_elapsed_ms()` by that
  value on resume so the recorded TOTAL continues cumulatively instead of restarting at 0, while the
  per-phase clock still re-anchors to "now" (fresh budget). Pre-crash partial-phase seconds are
  intentionally dropped (no heartbeat, per decision).
  ④ **Coherent resume trace + eval (base + gateway + worker).** Root cause: `__aenter__` emitted a
  second `SESSION_STARTED(initial_phase=warm_up)` before the resume jumped to the real phase, so the
  events.jsonl/Langfuse looked like a fresh interview re-running the phase from scratch. Fixes: on
  resume, `SESSION_STARTED` records the resumed phase (+ `resumed`/`resume_count`) not warm_up; a new
  `EventKind.SESSION_RESUMED` marker is emitted as the interruption boundary (+ a Langfuse WARNING
  span for audit). New shared [app/resume_collapse.py](app/resume_collapse.py) `collapse_resumed_events()`
  is a read-time view that REPLACES the interrupted phase's pre-crash partial (and the phantom second
  session_started) with the resumed run, preserving completed earlier phases — wired into both
  `event_viewer.group_by_phase` (clean timeline) and `evaluation_service._assemble_transcript` (scores
  the right thing, renders an interruption marker). Raw events.jsonl untouched (fully auditable).
  Verified: py_compile all; collapse unit-tested (single/opening-phase/double-crash/no-resume).
  Files: `engine/brain/contracts/events.py`, `engine/brain/runtime/interview_session.py`,
  `deploy/azure_app.py`, `app/resume_collapse.py` (new), `app/evaluation_service.py`,
  `app/event_viewer.py`, `ui/web/src/lib/candidateEngine.ts`, `ui/web/src/pages/Candidate.tsx`.

- **Admin interview header: copyable Session ID chip — COMMITTED, NOT built/deployed (frontend →
  gateway rebuild).** The interview detail page ([ui/web/src/pages/Session.tsx](ui/web/src/pages/Session.tsx))
  header showed candidate/role/duration/cost but NOT the interview's UUID, and the Langfuse link was
  buried in the "Data & cost" tab's per-model table. Added a compact, copyable **Session ID** chip to
  the header showing `row.token` + a Copy button + a "View in Langfuse ↗" link (when `d.langfuse_url`
  is set). WHY it's one value: the interview **token** (`uuid4()` from `app/sessions.py:create_draft`)
  is used verbatim as `SessionState.session_id` (`deploy/azure_app.py` sets
  `session_id_override = UUID(scheduled_token)`), which is the **Langfuse session id**, the
  `events.jsonl` key, AND the blob-storage folder (`sessions/<token>/…`). So one chip pinpoints the
  interview across Langfuse, the events download (`events-<token[:8]>.jsonl`), and blob. Frontend-only
  → ships via a gateway rebuild.

- **Guardrail split into its own agent · VAD-gated Azure STT · STT-lag Grafana attribution —
  COMMITTED, NOT built/deployed (target v22: base + session-0/1 + grafana).** Three fixes from
  the v21 live test.
  (1) **Guardrail is now its own fast-LLM agent** (`engine/brain/agents/guardrail_agent.py`),
  run in parallel with the verifier + phase-override in `Director._run_post_stt_agents`
  (`asyncio.gather` of all three, same CODING gate as the verifier). Merge is by PRIORITY:
  **override > guardrail > verifier** — override always applies (phase change); a guardrail trip
  supersedes the verifier (scrub the adversarial turn via `_scrub_last_candidate_turn(reason=
  category)` + neutral re-ask `_GUARDRAIL_REASK_THINK`, verifier verdict DISCARDED so the same
  question re-asks); else the verifier applies normally. WHY: the verifier's tool carried a
  `reason` **enum** (`GuardrailReason`) that Groq's structured decoding emitted on EVERY call →
  pydantic `ValidationError` → verifier silently fell back to `default_answered` (7× in v21). The
  new guardrail tool uses a **free-string `category`** (same trick that keeps phase_override
  robust) — no enum, no failure. Stripped `guardrail_triggered` + `GuardrailReason` + the `reason`
  field/schema/event from `verifier_agent.py` (`classify_response` is now `{intent, missing_tags,
  confidence}`). `GUARDRAIL_TRIGGERED` event is now emitted by the guardrail agent (free-string
  `reason=category`; admin `event_viewer.py` reads it unchanged). `config/prompts.yaml`: moved the
  GUARDRAIL CATEGORIES block out of `verifier:` into a new `guardrail:` prompt (binary
  `classify_guardrail`); confidence gate (≥0.7) downgrades a shaky trip to not-triggered (fail
  open — a false positive scrubs a real answer). Wired in `interview_session.py`
  (`GuardrailAgent(llm=fast, model=fast_model)`, passed to `Director(guardrail_agent=...)`).
  (2) **Azure STT is now VAD-gated** (mirrors Groq) — `azure_stt_client.py` writes to the push
  stream ONLY between `speech_start` and `endpoint_detected`, seeding a `preroll_ms` ring at
  speech_start so the VAD-hysteresis head isn't clipped; the continuous recognizer stays running
  (no start/stop — avoids the `session_stopped` auto-restart collision). `preroll_ms` +
  `no_speech_threshold` now threaded from config in `interview_session.py` (were Groq-only). Cuts
  the noise-driven partial churn seen in v21 (62 speech-starts / 12 endpoints).
  (3) **STT-lag attribution in Grafana** — three histograms on the brain REGISTRY, all labelled
  `provider`, emitted from `director.on_stt_partial` + `_finalize_utterance_at_endpoint`:
  `interview_stt_partial_lag_ms` (the headline — PER-PARTIAL recognition lag: at each partial,
  wall-clock beyond the audio recognized so far = `(now−speech_start) − (partial.end_ms − stream
  offset at utterance start)`; fires on EVERY partial → shows the lag DISTRIBUTION, so a flat
  small lag = STT keeps pace, a rising p95 = it's falling behind while the candidate talks — the
  "captions lag" feeling), `interview_stt_first_partial_ms` (delay before the FIRST caption), and
  `interview_stt_spoken_ms` (spoken-duration baseline, still emitted; not on the panel). WHY
  per-partial: Azure is a STREAMING push recognizer — there is no per-partial request/response, so
  the honest lag signal is how far Azure's audio-offset trails wall-clock, sampled every partial
  (not one head-lag sample per utterance). `lag>=0` guard drops providers that give no per-phrase
  offset (Groq). Dashboard panel id=16 "STT recognition lag" plots partial-lag p95 (solid) + p50
  (dashed) + head-lag p95 + reused slow-LLM TTFT p95, so a slow turn is attributable to STT vs the
  model. NO finalize/tail metric — Azure has no reliable per-utterance `recognized`
  (director.py:1139); the Turn is built from partials at the VAD endpoint, and STT lag does NOT add
  to the post-endpoint response delay (it diagnoses the live-caption experience while speaking).
  Guardrail-agent tracing verified: full prompt+response in Langfuse (`observe_llm` input =
  system+messages, `apply_llm_result` output/cost) AND the admin trace viewer (llm_call_started
  carries system_prompt+user_messages, llm_call_completed carries response_text; correlated
  generically by agent name) — with its OWN distinct violet pill (`--cat-guardrail`) in
  `app/static/admin.css` (`.agent-pill-guardrail_agent` + `.llm-call-agent--guardrail_agent`) and
  `event_viewer._agent_color`, kept separate from the verifier everywhere. Verified: py_compile all; dashboard json.load; pydantic model shapes
  (free-string category parses, `guardrail_triggered` intent rejected); Azure gate state machine
  (preroll cap, seed-on-start, active-only writes, zero-preroll guard); merge priority. Files:
  `engine/brain/agents/guardrail_agent.py` (new), `engine/brain/agents/verifier_agent.py`,
  `engine/brain/agents/__init__.py`, `engine/brain/core/director.py`,
  `engine/brain/runtime/interview_session.py`, `engine/brain/observability/prom.py`,
  `engine/brain/streamA_bridge/azure_stt_client.py`, `config/prompts.yaml`,
  `deploy/observability/dashboards/interview.json`.

- **Definitive avatar playback-end via TalkingHead STREAMING `onAudioEnd` — COMMITTED, NOT
  built/deployed; frontend needs a build.** The backend keys its silence timer / VAD gating /
  wrap-up hold off "candidate finished hearing this utterance"; in avatar mode that was a
  wall-clock estimate / silent-shadow. Azure real-time avatar was evaluated and REJECTED on
  cost (~$17–25/interview, billed per session-minute incl. silence). Instead we take a real
  completion event from the CURRENT avatar (met4citizen TalkingHead v1.7): switched
  `ui/web/src/lib/talkingHead.ts` from the fire-and-forget `speakAudio` queue to the
  **streaming API** — `streamStart({sampleRate,lipsyncLang:"en",lipsyncType:"words"}, null,
  onAudioEnd, null)` once at boot; `speak()` now returns a `Promise<void>` that
  `streamAudio({audio:concatPCM, words,wtimes,wdurations})` + `streamNotifyEnd()` and resolves
  on `onAudioEnd` (verified in the pinned v1.7 source: streamStart@3465, onAudioEnd fires at
  3559 on drain and 3616 on interrupt, streamAudio@3763, streamNotifyEnd@3598,
  streamInterrupt@3607, streamStop@3624). Barge-in: `stop()` → `streamInterrupt()`;
  `dispose()` → `streamStop()`. **No engine change**: `kickPlayer`'s existing "sink returns a
  promise" branch awaits it → ack `via:"sink"`/`grounded:true` → the existing
  `audio_playback_finished` path grounds the silence timer at TRUE end-of-speech. The
  `!aiSpeaking` guard means interrupt-fired `onAudioEnd` sends no false ack. `kickPlayer`'s
  `durMs+5000` race remains the safety net (no hang/regression if onAudioEnd misfires).
  Backend/observers/recording untouched (recording still taps backend PCM via `recordMix`).
  Aligned `observerEngine` `AudioSink` type to `void|Promise<void>`. VERIFY AT BUILD/TEST:
  `lipsyncType:"words"` lip-sync quality, per-utterance session reuse after `streamNotifyEnd`.
  Files: `ui/web/src/lib/talkingHead.ts`, `ui/web/src/lib/observerEngine.ts`.

- **Grounded playback-finished ack + audio-timeline observability — COMMITTED, NOT built/
  deployed.** From an audio-timeline investigation (see the events.jsonl analysis): the
  "candidate finished hearing the AI" signal that the silence timer keys off was a browser
  WALL-CLOCK ESTIMATE (`durMs = bytes/2/sampleRate`, then `setTimeout`), not a real
  playback-complete event — and it was never logged, so unverifiable. Changes:
  (1) `ui/web/src/lib/candidateEngine.ts` — the `AudioSink` contract now MAY return a
  completion `Promise` (resolves at true playback end); `kickPlayer` awaits whatever grounds
  best per mode and the ack carries `via` (`onended`/`sink`/`avatar_shadow`/`estimate`) +
  `grounded`. Minimal mode → real `AudioBufferSourceNode.onended`. Avatar mode: if the sink
  returns a promise (future Azure Avatar → resolve from its client end-event) await THAT;
  else (TalkingHead, which exposes no completion — `speakAudio` is fire-and-forget) time
  completion on a SILENT shadow buffer scheduled on our own AudioContext (`playTimingShadow`)
  — audio-clock accurate + immune to setTimeout jank, no avatar-lib API. All paths raced
  against a `durMs`+margin safety net so timers can never hang. Wiring Azure Avatar later is
  a one-place change (return the promise); the engine + ack pipeline don't move. (2) `deploy/azure_app.py` `_on_audio_ack` — logs
  `audio_playback_finished{sub_id,grounded}` to the tracer so the silence-timer reference is
  auditable in events.jsonl (backend behaviour unchanged — it already waits on this ack via
  the ack-aware `bytes_buffered()`). (3) `engine/orchestrator/web/audio_source.py` +
  `interview_session.__aexit__` — emit `mic_delivery_stats` (packet-size histogram +
  arrival_rate_per_s + counts) to events.jsonl at session end, because ACA console logs
  aren't retained (env app-logs destination is unset) so the existing `[WEB-MIC]` drift
  warnings were unrecoverable. NEXT run's artifact will show whether `arrival_rate_per_s`
  >> ~50 / `dominant_packet_bytes` != 640 (the ~2x mic audio-rate drift confirmed
  circumstantially from ts_ms≈2×now_ms — degrades VAD + STT). Verified: py_compile (3 backend
  files); frontend needs a build (no local tsc). Open follow-ups from the same investigation
  (NOT done): fix the mic audio-rate drift (root cause of garbled STT + laggy VAD); make
  `candidate_speaking` STT-aware (today VAD-only → false during real speech); optionally
  VAD-gate the Azure STT path (Groq already does).

- **Durable phase-boundary checkpoint + resume (feature B) — COMMITTED, NOT yet built/deployed
  (others were mid-interview; build+deploy deferred to user).** Problem: the interview brain
  (`InterviewSession`) lived ONLY in the shard's process memory. If the runner was lost mid-
  interview (shard/container restart, runner crash, orphan-evict after a >180s WS gap), a
  reconnect spawned a fresh `InterviewSession` that always started at the cadence's FIRST phase
  — the interview visibly reset to the greeting on the same token/Langfuse session. Fix: durably
  checkpoint to Redis at each phase boundary and resume the phase on a fresh runner. Pieces:
  (1) NEW `app/coordination/interview_checkpoint.py` — `save/load/clear` a tiny JSON blob under
  `ckpt:interview:{token}` (TTL `CHECKPOINT_TTL_S`, default 2h), mirrors `registry.py`.
  (2) `session_state.py` — `turn_to_jsonable`/`turn_from_jsonable` (the one place that knows
  Turn's shape; `interruption` dropped). (3) `director.py` — new `on_checkpoint` callback fired
  RIGHT AFTER the phase-marker turn is appended in `_tick` (state.turns is then exactly
  `[anchor, <phase_changed> marker]` — the state the phase starts with); factored the
  `coding_phase_started` payload out to a shared `build_coding_phase_started_payload(phase_def)`;
  added `_resume_clock_pending` → on the first resume re-open dispatch the phase clock is
  re-anchored to `now_ms` right before the slow-LLM call. (4) `interview_session.py` — new
  `checkpoint_writer`/`resume_checkpoint` kwargs; `_checkpoint` serializes + writes;
  `_resume_bringup` runs at the TOP of `run_until_signal` (before the mic-pump starts, so
  candidate voice is naturally held off): speaks a fast-LLM apology composed from the phase
  `intent` + two canned lines (each awaits real browser playout via `_await_playout`),
  rehydrates `state.turns` + `tracker.jump_to(phase)`, sets `_has_greeted=False` +
  `_phase_intro_pending=True` (first tick = a `phase_transition` re-open, not a greeting),
  re-emits `coding_phase_started` for coding phases (editor re-mount), drains the mic, sets the
  safety clock anchor. (5) `azure_app._session_runner` — loads the checkpoint, resumes keyed on
  EXISTENCE (not DB status — the crash-`finally` can wrongly flip `completed`), passes writer +
  checkpoint into the session; clears the checkpoint ONLY on clean end (natural-end branch in
  `candidate_ws`), never on a crash path. (6) `prom.py` — `interview_resumes_total{phase}`.
  **Timing invariant:** the phase budget starts ONLY at the slow-LLM re-open dispatch — bring-up
  + the whole resume announce are excluded (a resumed phase gets its full time). **Decisions:**
  first/warm-up phase → re-greet fresh (checkpoint only from phase 2+); coding phase → re-mount
  editor + restart the question (in-progress code lost); repeated-crash cap = 2 attempts
  (`resume_count`, reset to 0 on each phase transition; 3rd detection → spoken apology + end).
  Orphan-evict deliberately does NOT clear the checkpoint (a >180s drop may still reconnect →
  resume; TTL is the backstop). New env: `CHECKPOINT_TTL_S` (7200), `RESUME_MAX_ATTEMPTS` (2),
  `RESUME_INTRO_TIMEOUT_S` (8). Verified: py_compile all 6 files + a standalone fakeless test
  (in-memory async Redis) covering checkpoint save/load/clear/malformed/TTL + Turn round-trip.
  NOTE: source lives in `Dockerfile.base` — shipping requires a full base rebuild
  (`TAG=vN bash deploy/build_tiers.sh acr`), then session-0/session-1 update. NOT done yet.

- **v20: real browser TTS-playback ack → honest silence timer + wrap-up teardown; silence
  re-ask via `<think>`; dashboard trim**. The server had NO signal for when TTS actually
  finished PLAYING on the candidate's speaker — `BrowserSpeakerAudioSink.bytes_buffered()`
  was hardwired to 0, so the turn finalized (AUDIO_DONE) at TTS *generation* end, which
  started the no-response silence clock too early AND cut off the wrap-up farewell. Fix:
  (1) the candidate browser now sends `{"type":"audio_playback_finished","sub_id":...}` per
  utterance (`ui/web/src/lib/candidateEngine.ts`, wall-clock estimate covering both avatar +
  minimal modes, barge-in-aware via `aiSpeaking`); (2) broadcaster routes it via a new
  `set_audio_ack_callback` + inbound dispatch branch; (3) `azure_app._wire_bus_to_broadcaster`
  calls `sink.expect_playout(sub_id)` at audio_start and `sink.mark_played(sub_id)` on the ack;
  (4) `BrowserSpeakerAudioSink.bytes_buffered()` is now ack-aware (non-zero until the ack) and
  exposes a `playout_done_event` — so the EXISTING `_finalize_after_sink_drain` waits for real
  playback end (AUDIO_DONE / silence clock now honest, ~no director change); (5)
  `InterviewSession.__aexit__` wrap-up hold now `await`s the real ack event (bounded by
  `WRAPUP_PLAYOUT_MAX_WAIT_S`), server estimate as fallback. **Silence re-ask:** removed
  `<silence_ms=N/>` entirely (director `_persist_runtime_tags`, `question_agent`, orchestrator
  recorded-turn re-emit, and the prompt doc); silence now injects a `<think>` per-turn briefing
  directive (`_SILENCE_REASK_THINK` via `verifier_instruction` → `build_context`, same channel
  as `_GUARDRAIL_REASK_THINK`) telling the AI to repeat/rephrase its last question. NOTE: this
  is still a SINGLE silence stage (~15s reiterate) — no distinct canned stage-1 yet. Also
  removed the redundant "STT latency vs running interviews" dashboard panel (widened the two
  audio-backpressure panels). Env: nothing new. Verified py_compile + gateway tsc (build) +
  live boot.

- **v18: precompute resume parse+summary at schedule time (off the interview hot path)**.
  The startup-breakdown metric (v16) proved the slow interview start was the resume
  parse+summarize LLM call running synchronously at candidate start (`resume_summarize`
  ~= the whole ~25s startup, low CPU = a network wait). Moved it off the hot path entirely,
  as **per-interview artifacts** (no interview-time parse or LLM — just a file load):
  (1) new **`resume_summary` worker job** (`app/jobs/jobs.py`) — at SCHEDULE time it
  parses the resume and writes `sessions/{token}/resume/parsed.txt`, then summarizes and
  writes `sessions/{token}/resume/summary.txt`, mirroring both to blob (`{token}/resume/...`,
  its own folder next to recordings). Uses `cadence_service._resolve_llm()`; enqueued
  **unconditionally for every schedule with a resume** (`app/sessions.py` `create_draft` +
  `update_draft` when the resume is replaced), independent of cadence-gen (which skips the
  no-JD case). (2) `summarize_resume` hardened (`engine/orchestrator/resume_parser.py`) —
  **retries until the JSON validates** against `_ResumeSummary` (feeds the format error back,
  nudges temperature), per-attempt timeout (`RESUME_SUMMARY_TIMEOUT_S`=45); new
  `fallback_to_raw=False` makes it return "" (not raw) when it can't produce a summary, so
  summary.txt cleanly means "the summary". (3) the runner (`deploy/azure_app.py`
  `_load_precomputed_resume`) **only PULLS** at interview start: summary.txt → parsed.txt
  TRUNCATED (`RESUME_FALLBACK_CHARS`=4000) → no resume; reads the shared session dir with a
  best-effort blob fallback; NO parse/LLM. NOTE: stored as files (session dir + blob), NOT
  a cadence.yaml field (pydantic drops unknown fields) nor a DB column (files match the
  existing per-interview artifact layout). **Build note (learned the hard way at v14-v16):**
  the app source is COPY'd in `Dockerfile.base`, NOT the tier Dockerfiles — so you MUST
  rebuild the BASE image (`build_tiers.sh acr` rebuilds base+tiers) for code changes to
  ship; reusing an old `--build-arg BASE_IMAGE` silently deploys stale code.

- **v16: diagnose slow 2nd-interview start + fix empty LLM-in-flight + non-blocking VAD**.
  Two prod issues on 2 concurrent interviews/shard: the 2nd took very long to start (low CPU
  + low loop-lag → a network-wait stall in the UNTIMED bring-up window), and the per-key LLM
  in-flight metric was always empty. Fixes: (1) **Bring-up is now fully timed** —
  `interview_stage_latency_ms{service="startup", action=...}` for every step
  (`claim`, `session_lock_wait`, `db_get`, `resume_parse`, `cadence_load`, `resume_summarize`,
  `session_construct`, `bringup_aenter`, and inside `InterviewSession.__aenter__`:
  `stt_connect`/`vad_connect`/`tts_connect`/`sink_start`/`source_start`); `startup_to_first_audio`
  now measures the WHOLE start-click→first-audio window (clock stashed on the broadcaster as
  `_startup_run_t0`, was previously started AFTER bring-up). New dashboard panel "Startup
  breakdown" makes a slow start attributable to the exact step. (2) **VAD made non-blocking +
  bounded**: `vad_service/main.py` now runs the per-frame Silero ONNX + pitch via
  `asyncio.to_thread` (was synchronous on the VAD's single event loop → head-of-line-blocked
  new connections as concurrency grew; ONNX releases the GIL so it parallelizes); and
  `vad_client.connect()` got `open_timeout` (`VAD_CONNECT_TIMEOUT_S`=10) + bounded retry
  (`VAD_CONNECT_ATTEMPTS`=3) + `interview_vad_connect_failures_total`, so a wedged/slow VAD
  fails fast+loud instead of a silent multi-minute stall (same failure mode as the earlier
  "never started" hang). (3) **LLM in-flight was a 5s-sampling artifact** (instantaneous gauge
  vs sub-second calls), not broken. Added, per (tier, model, key_id): `interview_llm_calls_total`
  (counter → calls/sec, immune to sampling) + `interview_llm_active_peak` (peak-since-scrape,
  published/reset by `prom.snapshot_llm_peaks()` in the `/metrics` handler). Concurrency
  bookkeeping (`llm_enter`/`llm_exit`/`snapshot_llm_peaks`) moved into `prom.py`; `client.py`
  calls it. Dashboard: per-key panel now shows **peak concurrency** + a new **calls/sec**
  panel. `--workers N` for the VAD is deferred (only helps on >1-vCPU shards; measure first).

- **Metrics rework for scale-bottleneck visibility + a CLOUD Grafana stack**. The
  Prometheus/Grafana story was local-compose-only; reworked it to answer "what
  gives out first at scale?" and to run against the REAL shards. (1) **New/closed
  signals on the session `/metrics`:** `interview_scheduled_sessions` (DB
  `status='ready'` backlog, off-loop via `to_thread`), `interview_mic_queue_depth`
  (deepest live mic queue on the shard — the leading audio-backpressure indicator)

  + `interview_mic_frames_dropped_total` (counter `.inc()`d at the broadcaster drop
    site) — the "STT can't keep up" pair. **LLM latency is timed at the client
    CHOKEPOINT** (`LLMClient._observe_call` → `interview_llm_ttft_ms{tier}` +
    `interview_llm_latency_ms{tier}`), so EVERY call is measured regardless of agent,
    labeled only by model tier (fast/slow) — request→TTFT and request→completion.
    This closes the old gap where verifier + phase_override (which gate every turn)
    were never timed, without any per-agent wiring. (2) **VAD metrics federated** onto the session `:8080` /metrics
    (the handler best-effort-fetches `127.0.0.1:8011/metrics/` and concatenates) —
    VAD `:8011` isn't reachable cross-app in ACA (one ingress port/app), so this is
    ONE scrape target that works identically local + cloud; the separate `vad` scrape
    job is gone. (3) **Dashboard redesigned** (`deploy/observability/dashboards/interview.json` — a shared source of truth, deliberately OUTSIDE `deploy/local/`
    which `.dockerignore` excludes from image builds; same uid) into read-top-down
    rows: Load → Service latency (STT/LLM/TTS round-trip) → Audio backpressure (queue
    depth / drops / STT vs concurrency) → Event loop → Resources → Startup+drill-down.
    Local compose bind-mounts it; the cloud Grafana image bakes it. (4) **Cloud stack
    (NEW, self-managed in ACA):** `deploy/aca/observability/` ships
    `Dockerfile.prometheus` (+`prometheus-entrypoint.sh` renders scrape targets from
    `ACA_ENV_DOMAIN`/`SESSION_SHARDS` at boot) and `Dockerfile.grafana` (bakes the
    SAME dashboard; datasource URL via `$__env{PROMETHEUS_URL}`). Deployed as ONE
    ACA app (`grafana`) running **both as sidecar containers** — a Bicep module
    `deploy/aca/observability/obs-app.bicep` (referenced by `main.bicep` AND
    standalone-deployable via `az deployment group create` so the obs stack rolls
    without a full provision). The two containers share localhost → Grafana queries
    `http://localhost:9090`, Prometheus is NEVER exposed; only Grafana's :3000 is
    EXTERNAL, password-gated via `grafanaAdminPassword` (anon off). `grafanaUrl`
    output; `build_tiers.sh acr` builds the two obs images; `provision.sh` requires
    `GRAFANA_ADMIN_PASSWORD`. Prometheus TSDB is ephemeral (live view, not archival —
    Azure Files is unsafe for a TSDB). Docs: `docs/reading/08-observability-and-stress-test.md`.
    **Shipped as v13**: all tiers + the obs app deployed to ACA; Grafana at
    `https://grafana.icyground-5601c163.eastus.azurecontainerapps.io` (admin pw in the
    `grafana-admin-password` secret). Note: `az containerapp create --yaml` rejects the
    multi-container spec (System.Boolean/$ error) — use the Bicep module deploy, not --yaml.
    Verified: py_compile, `az bicep build`, live deploy (prometheus rendered targets +
    scraping session-0/1, Grafana provisioned datasource+dashboard, 302 login gate).
- **v10: end-of-interview TTS cutoff + self-healing admission counters + working-set
  memory metric**. (1) **TTS cutoff (tiered regression)**: the AI's WRAP_UP farewell
  was cut off mid-sentence. Root cause (proven from a real interview's events.jsonl:
  `tts_audio_end` fires ~80µs after `tts_audio_start`, session torn down ~0.9s later):
  the browser sink's `bytes_buffered()` is hardwired to 0, so the wrap-up end gate
  treats the farewell as "played out" the instant Azure TTS *generates* it — but Azure
  generates far faster than real time, so teardown (cancel_all → broadcaster.stop → WS
  close) runs while the browser is seconds behind. All shared brain/broadcaster/sink
  code is byte-identical to `demo-prod` (which didn't cut off), so the regression is the
  tiered path's in-process Azure TTS timing, NOT that code. Fix (backend-only, no
  per-turn behaviour change): `BrowserSpeakerAudioSink` gained a passive playout clock
  (`remaining_playout_s()`, advanced per queued PCM chunk, reset on barge-in
  `flush()`); `InterviewSession.__aexit__` now, ONLY on a natural wrap-up end
  (`_end_via_wrapup` flag set by the director's `on_session_end_requested` callback, and
  `exc` clean), holds teardown for `remaining_playout_s()` + margin (bounded, env
  `WRAPUP_PLAYOUT_MARGIN_S`=0.6 / `WRAPUP_PLAYOUT_MAX_WAIT_S`=15). Browser-end /
  orphan-evict / crash tear down immediately as before. (2) **Admission-counter leak**:
  `adm:active_sessions` / `adm:shard:*` / `adm:speech:*` are plain INCR/DECR with no
  TTL, so a session ending without the graceful release (crash / redeploy / OOM /
  orphan) leaked phantom slots forever (observed: idle cluster reading 2/1/1 + a phantom
  Speech slot eating the 5/key Azure cap). New `admission.reconcile()` rebuilds the
  counters from the TTL-backed registry (`reg:session:*`, now carrying the leased
  `speech_key`) and heals leaks, gated on a leak persisting TWO consecutive passes at the
  same derived value (so an in-flight claim — which INCRs before writing its registry
  entry — is never mistaken for a leak). Idempotent SET, so every session replica can run
  it. Wired as a 30s background loop in `azure_app.lifespan`
  (`ADMISSION_RECONCILE_INTERVAL_S`, 0 disables). `registry.SessionLocation` +
  `claim()`/`heartbeat_loop()` gained `speech_key`. (3) **Memory metric**: the Grafana
  panel plotted `memory.current`, which includes reclaimable page cache (events.jsonl /
  recordings) and looks like a leak. Added `interview_container_memory_workingset_bytes`
  (= memory.current − inactive_file, the OOM-relevant heap) to `/metrics`; the local
  dashboard now plots working-set vs total. 22 tiered tests + 4 new reconcile tests green.
- **Shard-capacity observability + stale single-interview UI removed**: added a
  session `/metrics` Prometheus endpoint (`deploy/azure_app.py`) exporting the
  event-loop-lag gauge (`_event_loop_heartbeat` now feeds `interview_loop_lag_ms`,
  peak-since-scrape) + live Redis concurrency counters (`interview_active_sessions`,
  `_shard_sessions`, `_llm_inflight`, `_speech_inflight`); reuses `prometheus-client`
  (already in base.txt) + a dedicated registry. New **local observability stack**
  behind `--profile obs` in `deploy/local/docker-compose.yml` (Prometheus + Grafana

  + cAdvisor) scraping session `/metrics`, VAD `/metrics` (:8011), and per-container
    CPU/mem; config + a pre-built dashboard under `deploy/local/observability/`.
    Cloud stays on `scripts/dump_shard_metrics.py` (Azure Monitor) + the `[loop-lag]`
    logs. Docs: `docs/reading/08-observability-and-stress-test.md`. **UI fix:** the
    scaled system runs many interviews at once, so the stale "One interview can be
    active at a time" banner is gone — `/api/sessions` now returns `active_count`
    (`db.count_active()`), `Dashboard.tsx` shows "N interviews in progress", and the
    cadence-review `active_blocker` is removed (`CadenceReview.tsx` + `api_cadence_review`
    return a constant falsy). The `CLOUD_MODE`-gated approve-path guards in `app/main.py`
    are KEPT (they protect the local single-laptop port-collision case and are already
    inert in every container deploy). `scripts/dump_shard_metrics.py` (Azure Monitor
    CPU/mem CLI) also landed for cloud capacity checks.
- **Cadence-gen fully moved to the worker tier (async + poll)**: `create_draft`
  / `update_draft` (regenerate) no longer run the ~10s slow-LLM inline — when
  there's JD/requirements input they insert a `status="generating"` draft, enqueue
  a `cadence_gen` job, and return instantly (no-input still uses default.yaml
  inline). The worker's `_cadence_gen` writes the YAML and flips the row to
  `draft`. Frontend: `useCadenceContext` react-query `refetchInterval` polls
  `/api/schedule/{token}/cadence` every 2s while generating; `CadenceReview` shows
  a "Generating interview plan…" state; `StatusPill` gained a pulsing `generating`
  variant; `api_cadence_review` tolerates an empty (generating) cadence. Also
  removed the unbuilt job stubs (rubric_gen/webhook/bulk_export/invite_dispatch/
  recording_finalize) so every registered job is real (cadence_gen, eval_v2,
  shortlist_score). 37 new unit tests green.
- **Tiered scaling foundation (branch `interview-scaled-dev`, distributed-only)**:
  split the monolith into gateway / session / worker tiers behind Azure Front Door
  on Azure Container Apps, coordinated by Redis. New packages: `app/coordination/`
  (registry replacing the `_token_sessions` dict, admission counters, locks,
  pub-sub), `app/jobs/` (Azure Storage Queue worker: cadence-gen/eval-v2/shortlist
  moved off the request path), `app/broker/` (multi-key Azure Speech rotation +
  N×5 admission, STT Azure↔Groq fallback, LLM timeout/backup), `app/session_tier/`
  (shard identity + claim/heartbeat/release), `app/gateway/` (registry-aware WS
  reverse-proxy). `azure_app.py` now claims tokens cluster-wide, heartbeats the
  registry, releases on end/evict, injects the broker-leased Speech key per
  session, and runs **VAD-only** Stream A (STT+TTS Azure — Kokoro/Whisper dropped,
  ~1.5 GB off the image). Post-session eval is mirrored to Blob then enqueued to
  the worker (which hydrates from Blob); the gateway serves results read-through
  from Blob. Data is Postgres-only (`jobs` table added; `scripts/migrate_sqlite_to _postgres.py`). Deploy: per-tier Dockerfiles on a shared base + split
  requirements + `deploy/build_tiers.sh` + `deploy/local/docker-compose.yml` +
  `deploy/aca/main.bicep`/`provision.sh`/`RESOURCES.md`. 35 fakeredis unit tests
  green (`tests/test_{coordination,jobs,broker,session_tier,gateway}.py`). Plan:
  `docs/scaling-architecture-plan.md`. `demo-prod` is untouched (rollback).
- **Manual deploy for anyone — ADO pipeline + fixed deploy scripts**: added
  `azure-pipelines.yml` (repo root) — a **manual-only** (`trigger:none`/`pr:none`)
  Azure DevOps pipeline anyone can Run from the browser: it `az acr build`s
  `deploy/Dockerfile`, reads the new image **digest**, repins the webapp to that
  digest, restarts, and polls `/admin/login` for 200. It deploys **whichever
  branch you select** in the Run dialog (so a teammate pushes their branch and
  deploys it). It authenticates via the existing ARM **service connection**
  `textqualitysrvc` (set in the `azureServiceConnection` variable) and runs a
  **preflight** step first that fails fast if that connection can't see ACR
  `interviewagentacr` / webapp `interview-ai-backend` in RG `AI-COE` (i.e. it's
  scoped to the wrong subscription). One-time setup: create the pipeline from the
  existing YAML (steps in the file header).
  Also **fixed `deploy/deploy.sh`**: it used to `az webapp stop/start`, which
  ships NOTHING under a digest pin (restart re-pulls the OLD digest) — it now
  reads the new digest, repins, restarts, verifies. Added `deploy/deploy.ps1`
  (native PowerShell equivalent for the Windows operator, with the same
  `demo/`+`.venv` stash so the ACR upload stays small). All three follow the
  proven CLAUDE.md § Deploy flow (build → digest → repin → restart → verify).
- **Candidate start-gap UX (Terms + dino game) + screen-recording audio (UI-only)**:
  two frontend features, no brain/server changes. (1) Clicking **Start interview** now
  opens a blocking **Terms & Conditions** modal (`ui/web/src/components/TermsModal.tsx`,
  content in `ui/web/src/lib/interviewTerms.ts` w/ `TERMS_VERSION`); on accept the session
  starts AND a **"please wait" overlay with a self-contained canvas dino runner**
  (`PreparingOverlay.tsx` + `DinoGame.tsx`) covers the spin-up gap, auto-closing the instant
  the AI is about to speak (hooks `turn.state → "speaking"`; 60s safety timeout + 1.2s
  min-display). Wired via a local `flow` state in `Candidate.tsx` (`Lobby` now takes
  `onStart`); accepted terms version+timestamp ride the `{type:"start"}` WS payload
  (`terms_accepted*`, harmless if server ignores). (2) Re-added **all-personnel audio to the
  SCREEN recording** (was reverted in `febcfee` bundled w/ proctoring changes): `buildRecMix()`
  is now **idempotent** (camera+screen share ONE mix bus — a naive rebuild would silently drop
  AI/observer audio from the camera track) and `startScreenRecorder()` adds that mix track to
  the screen `MediaRecorder`. The mix bus is a **sink-only** node tapping raw AI/observer PCM —
  it never touches the playback path, so it can't echo/mute the AI (the earlier revert's
  concern). Node isn't on the local PATH → typecheck gated by the deploy tsc stage.
- **LLM provider routing locked to Groq + one named backup (no random fallback)**:
  OpenRouter `provider.order` is only a *preference* — without `allow_fallbacks:false`
  it silently routed the slow LLM to **DeepInfra** (8.7s TTFT → 5s filler fired) and the
  verifier to **WandB** (flaky forced-tool-calls), and was the likely cause of the
  gpt-oss reasoning-leak (some fallback providers dump reasoning into `content` instead
  of the reasoning channel). `interview_session.py` now sets `allow_fallbacks:false` on
  BOTH the slow + fast provider dicts, so the env order lists are authoritative. Prod env:
  `SLOW_PROVIDER_ORDER=Groq,Baseten`, `FAST_PROVIDER_ORDER=Groq,DeepInfra` (Groq primary,
  one named backup; if both are down the call errors → canned filler, instead of limping
  on a random slow provider). The provider **lists** stay env-tunable with no redeploy;
  only the no-fallback rule lives in code.
- **Eval v2 — rubric option editor, ungraded-phase handling, requirement clarity,
  full-width timeline**: (1) `rubric_marks` is now purely additive — the TA adds
  options one at a time (description + marks; +2/+1/-1), the LLM returns the
  applicable option NUMBERS, and a script sums them (dropped the present/absent
  `condition`). A new per-option row editor (`CriteriaEditor`) replaces the
  JSON-blob config; `SchemaForm` gained an `omit` prop so a parent can render one
  field custom. (2) Phases with NO plugin / not-scored no longer error on save or
  validate (`PluginAssignment.plugin_id` may be empty; validators skip
  empty/disabled). (3) Ungraded phases are excluded from the benchmark report
  tiles AND the strengths/weaknesses synthesis (`plugin_evaluation` skips phases
  with no enabled plugin; `BenchmarkPanel` also filters). (4) The plugin
  requirement list shows ONLY author-actionable items — runtime/dev preconditions
  (candidate-answer present, LLM key set) are flagged `author_actionable=False` on
  `Assumption` and hidden; heading is now "Needs to score this phase". (5) The
  cadence-review phase Timeline (Gantt) spans the full width now that the rubric
  column is gone. Also: "Revise with feedback" was a v1 carryover whose feedback
  the v2 pipeline ignored — replaced with a plain "Regenerate" for benchmark
  evals (feedback-revise kept only for legacy v1). Backend 44 tests pass;
  frontend tsc/vite verified via the ACR webbuild stage.
- **Eval v2 — configurable rubric + self-explanatory plugins + evidence-as-transcript**:
  (1) `rubric_marks` is now the general *author-your-own* rubric — the TA defines
  options `{description, condition present/absent, marks}` (+2/+1/-1), an LLM lists
  which apply per question, and code sums them (nothing hard-coded). It feeds the
  judge a STRUCTURED view via new `Segment.structured_qa()` (question / initial
  answer / follow-up rounds / verifier verdict) instead of a flat transcript.
  Removed the over-specified `coverage_rubric` (fixing the options defeated the
  purpose). (2) Every plugin now ships a `PluginHelp` (`help()`: summary /
  best_for / how_it_works / you_configure / evidence) rendered as a collapsible
  "ⓘ What this plugin does" box at the top of each plugin card, so a TA picks a
  plugin on purpose instead of guessing; `conversational_rubric` renamed
  "(free-form phases)" — the right pick for generic/open phases with no
  per-question boundaries. (3) Evidence in the report is the actual multi-party
  question transcript (speaker-labeled, cited turns highlighted), not event-index
  numbers — wired through `plugin_aggregate` + `eval-views`. (4) Cadence-review
  right column is per-phase plugin cards (scrollable) replacing the derived-rubric
  column; validation hints reset on cadence edits. `AUTHORING.md` documents
  `help()` + `structured_qa()` as requirements. Backend 42 tests pass; frontend
  tsc/vite verified via the ACR webbuild stage.
- **Eval v2 UX pass**: Performance tab now shows ONLY the benchmark view when an
  evaluation has a `benchmark` block (legacy /100 + dimensions + by-phase render
  only for old, pre-v2 evaluations; old ones get a "regenerate" prompt). The
  cadence-review evaluation config is the per-phase **plugin tiles**
  (`EvalPlanPanel`) — the rubric raw-JSON "Edit JSON" editor was removed. Added a
  deterministic **cadence-assumption validator**: each plugin implements
  `precheck_cadence(phase, config)` (e.g. dynamic_difficulty needs difficulty +
  coverage_tags on every question); `POST /api/eval/plan/{token}/validate` returns
  per-phase/per-plugin unmet hints shown in each card, and disabled (not-scored)
  phases are skipped by both validation paths. New eval-UI components are themed to
  the dark design tokens (.card/.pill/.muted/var(--*)), not light Tailwind.
- **Observer view overhaul**: (1) screen share bumped to **1080p** (capture ideal
  1920×1080, JPEG `maxW=1920 quality=0.72`) so code/text is readable when maximized
  — was 960px/q0.5 and blurry on upscale; (2) new observer layout via `VideoTiles variant="stack"` — left 60% big screen + 3-tile rail (AI/candidate/observer),
  right 40% transcript+chat+scorecard; (3) observer transcript now auto-scrolls —
  the bug was an unbounded flex chain, fixed by making the transcript the only
  growing child of `.obs-side` (status strip / chat / scorecard are `flex:0 0 auto`);
  `TranscriptView` itself was already correct.
- **Plugin-based v2 evaluation (`EVAL_PLUGINS_ENABLED`, default off)**: post-
  interview scoring can now run a segmented, plugin-based **benchmark** pipeline
  instead of the single whole-transcript LLM pass. `features/eval/sectioner.py`
  splits `events.jsonl` into phase→question segments (full multi-party transcript

  + `event_index`), driven by a new `question_dispatched` event emitted for ALL
    specific phases in `director.py` (was adaptive-only). Each phase is scored by
    configurable **plugins** (`features/eval/plugins/`: `rubric_marks`,
    `dynamic_difficulty`, `conversational_rubric`, `coding`, `coverage_tags`)
    chosen per phase in `sessions/<token>/evaluation_plan.json` (migrates from the
    rubric); `/api/eval/plugins` + `/api/eval/plan/{token}` back a per-phase tiles
    editor on cadence-review. `app/plugin_evaluation.py` orchestrates,
    `app/plugin_aggregate.py` sums marks and emits a v1-compatible shape (benchmark
    tree under `benchmark`, rendered via `view_id` templates in
    `ui/web/src/components/eval-views/`) so the Performance tab keeps working. v1
    stays default until parity. Scoring is marks-based ("score as high as
    possible"), NOT out-of-100. Also fixed the v1 `_assemble_transcript`
    phase-marker key bug. Backend tested (`tests/test_{sectioner,eval_plugins, eval_plan,plugin_aggregate}.py`); frontend build is gated by the deploy tsc stage.
- **Screen-to-observer REAL root cause fixed**: the candidate's screen JPEG pump
  never fired because `SelfVideo`/`FrameCapture` had `onFrame` in their grab-
  interval `useEffect` deps; the screen caller's inline closure changed every
  render, so the parent's frequent re-renders reset the 400ms interval before it
  could fire (camera worked because it passed a stable method). Fixed by holding
  `onFrame` in a ref. (The earlier cache + visible-preview work was necessary but
  not sufficient — this was the actual bug. Symptom: observer saw the candidate's
  camera but never their screen, even after a hard refresh.)
- **Screen share to observer — cache + capture + mandatory proctoring**: the
  observer "never sees the candidate's screen" was a **stale SPA bundle** (shell
  `index.html` had no `Cache-Control`, so browsers kept old JS after every
  deploy). Fixed with never-cache shell + immutable hashed assets
  (`_ImmutableAssets`/`_spa` in `app/main.py`). Made `FrameCapture` render a small
  VISIBLE preview (off-screen video was being decode-throttled). Added **mandatory
  entire-screen consent** in the candidate lobby (validates `displaySurface === "monitor"`, re-prompts on window/tab), auto-shares from the start, forces
  recording on so the **full screen records start-to-end**, re-prompts + appends on
  a mid-interview stop. Observer auto-spotlights the screen tile and widens its
  video column when a screen is live.
- **Observer link inactivation + candidate screen visible to observer**: observer
  WS returns `session_ended` for finished/cancelled tokens (link goes inactive);
  `FrameCapture` renders off-screen at real size so the candidate's shared screen
  actually streams to the observer.
- **Observer + recording bug sweep**: session-end notify (handle both
  `session_end`/`session_ended`), sticky transcript auto-scroll, observer
  background blur, candidate screen relay (headless capture), ranged blob
  recording playback, recording audio mix (mic+AI+observer), higher live snapshot
  cadence. Plus merged the observer-PTT "substitute AI turn" rework (9588b0f).
- Evaluated RunComfy `ai-avatar-video`: batch video gen, NOT usable for the live
  avatar (real-time streaming TalkingHead is the right approach).
