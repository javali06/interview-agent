import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

// The SPA is served by FastAPI from ui/web/dist in production. In dev, proxy
// API + legacy admin calls to the local admin app (port 8123) so cookies and
// same-origin requests work without CORS.
export default defineConfig({
  plugins: [react(), tailwindcss()],
  // Served by FastAPI under /app during the migration (coexists with the
  // legacy Jinja admin at /admin). Assets resolve to /app/assets/*.
  base: "/app/",
  build: { outDir: "dist", emptyOutDir: true },
  server: {
    port: 5173,
    proxy: {
      "/api": { target: "http://127.0.0.1:8123", changeOrigin: true },
      "/admin": { target: "http://127.0.0.1:8123", changeOrigin: true },
    },
  },
});
