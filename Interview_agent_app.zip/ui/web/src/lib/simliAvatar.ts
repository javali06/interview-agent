// Simli avatar adapter — a photorealistic alternative to the TalkingHead 3D
// model, behind the SAME AvatarSink contract (lib/talkingHead.ts). The engine's
// call sites do not change: it still calls setAudioSink(speak, stop) and awaits
// speak().
//
// ── THE DESIGN DECISION THAT MATTERS ────────────────────────────────────────
// The contract is that speak() resolves only when the candidate has ACTUALLY
// stopped hearing the utterance: the backend keys the no-response silence
// timer, VAD gating and wrap-up teardown off that moment.
//
// Simli cannot give us that. Its SDK does emit "speaking"/"silent", but those
// are relayed SERVER control messages — see simli-client
// lib/transports/BaseTransport.ts, `case "SILENT": transport.emit("silent")`.
// They mean "the server stopped sending", which happens BEFORE the audio has
// crossed the network and drained the client's jitter buffer. Resolving on
// that would fire the silence timer while the AI is still audibly talking.
// Resolving on send is worse, and a duration timer is the estimate v20
// deliberately moved away from.
//
// So we split the two jobs:
//
//     PCM ─┬─→ our own AudioContext   → the candidate HEARS this
//          │                           → real AudioBufferSourceNode.onended
//          │                           → THAT resolves speak()      (grounded)
//          └─→ Simli sendAudioData()  → drives the lip-sync VIDEO only
//                                       (its <audio> element stays muted)
//
// Why this is the safer shape, not just a workaround:
//   - the completion signal is local and exact — the same mechanism minimal
//     mode already uses (via:"onended"), which the engine already trusts;
//   - VAD behaviour is unchanged, because the AI's voice reaches the speaker
//     by exactly the path it does today;
//   - if Simli's video stalls or the stream drops, the candidate still HEARS
//     the whole interview. Video is decorative; audio is the interview.
//
// The trade-off bought: face and voice are driven independently and can DRIFT.
// Measuring that drift is the follow-up test story's job — it is the known
// cost of this design, not an oversight.
//
// Returns null on ANY boot failure so the caller falls back to the minimal orb,
// exactly as bootAvatar() does. An avatar must never be able to fail a lobby.

import type { AvatarSink } from "./talkingHead";

// Simli ingests PCM16 mono @ 16 kHz. Azure TTS is locked to
// Raw16Khz16BitMonoPcm and the engine defaults to 16000, so no resampling is
// needed — but assert rather than assume: a future TTS format change would
// otherwise surface as a face mouthing at the wrong speed, which reads as a
// product defect rather than a config error.
const SIMLI_SAMPLE_RATE = 16000;

// Simli's ingest prefers small regular writes over one large buffer.
// 30 ms of 16 kHz PCM16 = 960 bytes.
const CHUNK_BYTES = 960;

const CONNECT_TIMEOUT_MS = 20000;

// Simli's SDK default is 3000. It is the worklet's accumulation buffer, so it
// sits directly on the path between "we sent audio" and "the face moves" —
// smaller means the mouth starts sooner. 1024 is a compromise: low enough to
// cut visible lag, large enough not to spam tiny websocket frames.
const AUDIO_BUFFER_SIZE = 1024;

// A/V alignment. Simli's speech-to-video hop is ~300ms (their published figure),
// but we start local playback immediately — so by default the FACE lags the
// VOICE. Delaying our own playback by roughly Simli's latency lines them up.
//
// Left at 0 deliberately: the follow-up test story has to MEASURE true drift,
// and a pre-applied fudge factor would hide the thing being measured. Once you
// have watched a run and know the real lag, set this to it (try 200-300) — the
// contract is unaffected either way, because onended still fires at the true
// end of playback, just shifted later by this amount.
const AV_OFFSET_MS = 0;

type TokenResponse = { session_token: string; ice_servers?: RTCIceServer[] };

/** Mint a session server-side. The raw Simli key must never reach the browser —
 *  see the /api/simli/token handler in app/main.py for why. */
async function fetchSession(interviewToken: string): Promise<TokenResponse | null> {
  try {
    const r = await fetch(`/api/simli/token?token=${encodeURIComponent(interviewToken)}`);
    if (!r.ok) {
      // 503 = not configured / upstream down. Not an error worth shouting about:
      // the caller degrades to the orb.
      console.warn(`[simli] token endpoint returned ${r.status} — falling back to orb`);
      return null;
    }
    const j = (await r.json()) as TokenResponse;
    return j?.session_token ? j : null;
  } catch (err) {
    console.warn("[simli] token fetch failed", err);
    return null;
  }
}

function concatBuffers(chunks: ArrayBuffer[]): ArrayBuffer {
  let total = 0;
  for (const c of chunks) total += c.byteLength;
  const out = new Uint8Array(total);
  let off = 0;
  for (const c of chunks) {
    out.set(new Uint8Array(c), off);
    off += c.byteLength;
  }
  return out.buffer;
}

/** PCM16 LE → an AudioBuffer we can play locally. */
function toAudioBuffer(ctx: AudioContext, pcm: ArrayBuffer, sampleRate: number): AudioBuffer {
  const view = new DataView(pcm);
  const samples = Math.floor(pcm.byteLength / 2);
  const buf = ctx.createBuffer(1, samples, sampleRate);
  const ch = buf.getChannelData(0);
  for (let i = 0; i < samples; i++) ch[i] = view.getInt16(i * 2, true) / 32768;
  return buf;
}

export type SimliBootResult = {
  sink: AvatarSink;
  /** ms from boot start to the first video frame — reported for the comparison note. */
  timeToFirstFrameMs: number | null;
};

export async function bootSimli(
  container: HTMLElement,
  sampleRate: number,
  interviewToken: string,
  onFirstFrame?: (ms: number) => void,
): Promise<AvatarSink | null> {
  const t0 = performance.now();
  try {
    if (sampleRate !== SIMLI_SAMPLE_RATE) {
      console.warn(
        `[simli] needs ${SIMLI_SAMPLE_RATE}Hz PCM16, engine has ${sampleRate}Hz — falling back to orb`);
      return null;
    }

    const session = await fetchSession(interviewToken);
    if (!session) return null;

    // Dynamic import: keeps simli-client (and its livekit-client dependency) out
    // of the main bundle, so candidates who never pick this mode never download
    // it — the same reasoning as TalkingHead's runtime load.
    //
    // Deep import, NOT the package root, because simli-client@3.0.2 ships a
    // broken entry point: dist/index.js does require("./Client") but the file on
    // disk is dist/client.js. Case-insensitive filesystems (Windows, macOS)
    // resolve it; Linux does not, so the package root fails the container build
    // with `Could not resolve "./Client"`. dist/client.js is the real module and
    // exports everything index.js re-exports. Revisit if upstream fixes the case.
    const { SimliClient, LogLevel } = await import("simli-client/dist/client");

    // Simli renders into a <video>. Its <audio> element must exist (the
    // constructor requires one) but stays MUTED — we own playback. Both must be
    // in the DOM before start().
    const video = document.createElement("video");
    video.autoplay = true;
    video.playsInline = true;
    video.muted = true;
    // `contain`, NOT `cover`. Simli streams a roughly square portrait; our tile
    // is tall, so `cover` zooms in to fill and clips the edges — the avatar
    // reads as pressed against the lens, and it gets worse in fullscreen where
    // the aspect mismatch is larger. `contain` shows the whole frame at
    // every size. The framing beyond that is baked into the Simli face itself
    // (there is no camera/zoom control like TalkingHead's cameraView).
    video.style.cssText =
      "width:100%;height:100%;object-fit:contain;border-radius:18px;display:block;background:#0b0b14";
    const audio = document.createElement("audio");
    audio.autoplay = true;
    audio.muted = true; // ← the decision: Simli never produces sound
    container.appendChild(video);
    container.appendChild(audio);

    let firstFrameMs: number | null = null;
    video.addEventListener("loadeddata", () => {
      if (firstFrameMs === null) {
        firstFrameMs = Math.round(performance.now() - t0);
        onFirstFrame?.(firstFrameMs);
        console.info(`[simli] time-to-first-frame ${firstFrameMs}ms`);
      }
    }, { once: true });

    // LogLevel.ERROR, not the SDK's DEBUG default — DEBUG floods the console
    // during a live interview and buries our own [audio-guard]/[simli] lines.
    const client = new SimliClient(
      session.session_token,
      video,
      audio,
      session.ice_servers && session.ice_servers.length ? session.ice_servers : null,
      LogLevel.ERROR,
      "p2p",                 // SDK default; it escalates to livekit on retry
      "websockets",
      "wss://api.simli.ai",
      AUDIO_BUFFER_SIZE,     // smaller than the 3000 default → mouth starts sooner
    );

    // start() resolves on a successful connection and retries internally
    // (it escalates p2p → livekit after 2 attempts), throwing only once it has
    // genuinely given up. Bound it anyway: a hung connect must reach the orb,
    // not stall the lobby.
    let timer: number | undefined;
    const timeout = new Promise<never>((_, reject) => {
      timer = window.setTimeout(() => reject(new Error("connect timeout")), CONNECT_TIMEOUT_MS);
    });
    try {
      await Promise.race([client.start(), timeout]);
    } finally {
      if (timer !== undefined) window.clearTimeout(timer);
    }

    // Our context owns audible playback, and therefore the completion signal.
    const ctx = new AudioContext();
    let current: AudioBufferSourceNode | null = null;
    let settle: (() => void) | null = null;
    let pending = new Uint8Array(0);  // live feed: bytes short of one Simli write

    const finish = () => {
      current = null;
      if (settle) {
        const s = settle;
        settle = null;
        s();
      }
    };

    return {
      speak: (chunks, _text, _durMs) =>
        new Promise<void>((resolve) => {
          settle = resolve;
          const pcm = concatBuffers(chunks);

          // 1. Feed Simli for the FACE. Guarded on its own: a video failure must
          //    never stop the candidate hearing the answer.
          try {
            const bytes = new Uint8Array(pcm);
            for (let i = 0; i < bytes.length; i += CHUNK_BYTES) {
              client.sendAudioData(bytes.subarray(i, Math.min(i + CHUNK_BYTES, bytes.length)));
            }
          } catch (err) {
            console.error("[simli] sendAudioData failed — face may stall, audio continues", err);
          }

          // 2. Play locally for the AUDIO. onended is the grounded
          //    "they stopped hearing it" that resolves speak().
          //    AV_OFFSET_MS delays the start to compensate for Simli's
          //    speech-to-video latency; scheduled on the audio clock rather
          //    than setTimeout so it is immune to main-thread jank.
          try {
            if (ctx.state === "suspended") void ctx.resume();
            const src = ctx.createBufferSource();
            src.buffer = toAudioBuffer(ctx, pcm, sampleRate);
            src.connect(ctx.destination);
            src.onended = finish;
            current = src;
            src.start(ctx.currentTime + AV_OFFSET_MS / 1000);
          } catch (err) {
            console.error("[simli] local playback failed", err);
            finish(); // never hang the engine's player loop
          }
        }),

      // LiveKit: the page's LiveKit element plays the voice; the tapped track
      // only drives the face — exactly the split above, minus our own playback.
      // Lips trail the voice by Simli's speech-to-video hop (AV_OFFSET_MS can't
      // help here: delaying a live track would delay the whole conversation).
      stream: {
        feed: (pcm) => {
          // Re-chunk the 20 ms frames into the 30 ms writes Simli prefers.
          const b = new Uint8Array(pcm);
          const merged = new Uint8Array(pending.length + b.length);
          merged.set(pending, 0);
          merged.set(b, pending.length);
          let i = 0;
          try {
            for (; i + CHUNK_BYTES <= merged.length; i += CHUNK_BYTES) {
              client.sendAudioData(merged.subarray(i, i + CHUNK_BYTES));
            }
          } catch (err) {
            console.error("[simli] live sendAudioData failed — face may stall", err);
          }
          pending = merged.slice(i);
        },
        utterance: () => { /* Simli times the mouth from the audio itself */ },
        end: () => {
          try { if (pending.length) client.sendAudioData(pending); } catch { /* noop */ }
          pending = new Uint8Array(0);
        },
        cut: () => {
          pending = new Uint8Array(0);
          try { client.ClearBuffer(); } catch { /* noop */ }
        },
      },

      stop: () => {
        // Barge-in: drop Simli's queued audio so the face stops mouthing, and
        // kill local playback. Both best-effort; settling is not optional.
        try { client.ClearBuffer(); } catch { /* noop */ }
        try { current?.stop(); } catch { /* noop */ }
        finish();
      },

      dispose: () => {
        try { current?.stop(); } catch { /* noop */ }
        try { void client.stop(); } catch { /* noop */ }
        try { void ctx.close(); } catch { /* noop */ }
        container.replaceChildren();
        finish();
      },
    };
  } catch (err) {
    console.warn("[simli] boot failed — falling back to minimal orb", err);
    container.replaceChildren();
    return null;
  }
}
