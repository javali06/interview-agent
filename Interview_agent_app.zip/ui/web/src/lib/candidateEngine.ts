// candidateEngine — framework-agnostic port of ui/candidate/app.js (minimal
// mode). Owns the lobby readiness checks, the /ws/candidate WebSocket, AI-audio
// receive→queue→single-flight player loop (with caption sync), mic capture via
// the existing AudioWorklet, the candidate-STT lane, and the session timer.
//
// Scope of THIS increment: minimal visual (orb + captions). The TalkingHead 3D
// avatar (increment 3) and the Pyodide coding panel (increment 2) are deferred;
// coding messages set a `codingActive` flag for now. AI logic stays Python.
//
// Demo mode (?demo=1) drives the live screen with SpeechSynthesis and needs no
// backend — the one path that's locally verifiable without the audio stack.

import type { TranscriptRow } from "../components/TranscriptView";
import { pushLevel, registerAnalyser, resetSource, unregisterAnalyser } from "./orbGlow";
import { LiveKitMedia } from "./livekitMedia";
import type { AvatarStream } from "./talkingHead";

const MIC_WORKLET_URL = "/admin/static/mic-worklet.js?v=1";

export type Screen = "lobby" | "live" | "done";
export type CheckState = "pending" | "ok" | "warn" | "error";
export type TurnState = "listening" | "speaking" | "thinking";

// "avatar" = TalkingHead 3D (lib/talkingHead.ts); "simli" = Simli photoreal
// (lib/simliAvatar.ts); "minimal" = the orb, and the fallback both avatars
// degrade to when they can't boot.
export type VisualMode = "avatar" | "simli" | "minimal";

// An audio sink lets the player loop hand PCM somewhere other than the engine's
// own AudioContext — e.g. the TalkingHead avatar (which lip-syncs + plays
// through its own context). React registers one in avatar mode; default is the
// engine's minimal-mode AudioContext playback.
// An avatar/audio sink plays the AI audio (audible) + any lip-sync. It MAY
// return a Promise that resolves when playback ACTUALLY finishes on the speaker
// — the grounded "candidate stopped hearing the AI" signal the backend timers
// (silence / VAD gating / wrap-up) key off. Returning void means "no completion
// signal available" and the engine grounds timing on the audio clock instead
// (a silent shadow buffer). A real avatar service (e.g. Azure Avatar) should
// return the promise resolved from its client-side end-of-playback event.
export type AudioSink = (chunks: ArrayBuffer[], text: string, durMs: number, sampleRate: number) => void | Promise<void>;

// Visual Scenario Analysis — the server sends the WHOLE item on
// scenario_item_start (see engine/brain/core/director.py
// _emit_scenario_item_dispatch); `media.ref` is an asset NAME, never a raw
// path — the panel builds the fetch URL itself via the existing
// /api/sessions/{token}/phase-asset/{name} route (token-as-capability, same
// as image_description). `resync` is set only when this is a RESEED after a
// reconnect (see broadcaster.py's `_last_scenario_state`) — the panel must
// NOT autoplay video/audio in that case, only show a Play control.
export type ScenarioMediaMsg = { kind: "image" | "video" | "audio"; ref: string; filename: string; mime_type: string };
export type ScenarioItemMsg = {
  phase_id: string;
  item_id: string;
  item_index: number;
  item_total: number;
  media: ScenarioMediaMsg;
  question_text: string;
  coverage_tags: string[];
  max_followups: number;
  resync?: boolean;
};

export type CandidateSnapshot = {
  screen: Screen;
  name: string;
  role: string;
  visualMode: VisualMode;
  durationLabel: string;
  checks: { mic: CheckState; speaker: CheckState; browser: CheckState; connection: CheckState; screen: CheckState };
  browserLabel: string;
  connCheckLabel: string;
  micEnabled: boolean;
  micLevel: number; // 0..100
  speakerTested: boolean;
  startReady: boolean;
  conn: { state: "ok" | "warn" | "error" | "connecting"; label: string };
  // True while the live WS dropped and we're auto-reconnecting (shard restart /
  // network blip). Drives the calm full-screen "reconnecting" overlay so the
  // candidate knows the interview will resume rather than staring at dead air.
  reconnecting: boolean;
  turn: { state: TurnState; label: string };
  caption: string;
  rows: TranscriptRow[];  // unified live transcript (AI + candidate)
  count: number;          // turn counter shown in the transcript header
  candidateSpeaking: boolean;        // active-speaker ring for this candidate
  cameraOn: boolean;                 // this candidate's own camera
  screenOn: boolean;                 // this candidate is sharing their screen
  micMuted: boolean;                 // candidate muted self (AI can't hear)
  mutedNudge: boolean;               // talking while muted → show unmute nudge
  selectedCamId: string | null;      // lobby-picked camera deviceId (null = default)
  selectedMicId: string | null;      // lobby-picked mic deviceId (null = default)
  bgBlurOn: boolean;                 // background-blur the camera self-view + snapshots
  recordingEnabled: boolean;         // admin set this interview to record camera+screen (immutable per-interview setting, from cadence.yaml)
  recording: boolean;                // a MediaRecorder is capturing this session
  savingRecording: boolean;          // recording chunks still uploading (don't close yet)
  timer: string;
  codingActive: boolean;
  codingPhaseMsg: Record<string, unknown> | null;
  codingHint: string | null;
  // Visual Scenario Analysis — mirrors codingActive/codingPhaseMsg's shape.
  // Mutually exclusive with coding (a phase is one or the other).
  scenarioActive: boolean;
  scenarioItem: ScenarioItemMsg | null;
  modal: { title: string; body: string } | null;
  toast: string | null;
};

type RecvChunk = { subId: string; text: string; pcm: ArrayBuffer[]; sampleRate: number };

export type CandidateParams = {
  name: string;
  role: string;
  wsPort: string | null;
  demo: boolean;
  demoCoding: string | null;
  token: string | null;
};

export function readParams(search: string): CandidateParams {
  const p = new URLSearchParams(search);
  return {
    name: p.get("name") || "Candidate",
    role: p.get("role") || "the role",
    wsPort: p.get("ws"),
    demo: p.get("demo") === "1",
    demoCoding: p.get("demo_coding"),
    token: p.get("token"),
  };
}

export class CandidateEngine {
  private p: CandidateParams;
  private listeners = new Set<() => void>();
  private snap: CandidateSnapshot;

  private audioCtx: AudioContext | null = null;
  private micStream: MediaStream | null = null;
  private micWorklet: AudioWorkletNode | null = null;
  private ws: WebSocket | null = null;
  private reconnects = 0;
  // Max auto-reconnect attempts before giving up. With the capped backoff
  // (≤4s) this spans ~2 min — long enough to ride out a session-shard restart
  // (~60-90s) so the interview resumes without the candidate refreshing.
  private static readonly RECONNECT_MAX = 30;
  private destroyed = false;
  // Set when the server refused this tab because the interview is live in
  // another window — the socket's close must not trigger an auto-reconnect.
  private refused = false;
  // On a reconnect, keep the "reconnecting…" overlay up until the session is
  // actually live again (first inbound AI audio / transcript). Prevents the
  // open→crash→open flicker while a shard cold-starts and the resumed runner
  // fails bring-up a few times before it sticks.
  private awaitingLive = false;

  private sampleRate = 16000;
  private activeRecv: RecvChunk | null = null;
  private aiQueue: RecvChunk[] = [];
  private playerActive = false;
  private aiSpeaking = false;
  private playScheduledTail = 0;
  private volumeGain = 2.0;

  // ── LiveKit (MEDIA_TRANSPORT=livekit) ────────────────────────────────────
  // lkOffered comes from /session-info. Start then asks the server for this
  // tab's room token (POST /api/candidate/{token}/start); in the room, audio
  // rides tracks AND control rides the data channel (roomMode) — no WebSocket.
  // Anything that fails on the way falls back to the WebSocket path.
  private lkOffered = false;
  private lk: LiveKitMedia | null = null;
  private roomMode = false;
  private lkLive = false;          // the AI's voice arrives over LiveKit
  private roomRetries = 0;
  // The AI's remote voice, measured for the playback ack and fed to the
  // recording mix. lastAiLoudAt = last moment it was audible.
  private aiRemoteSrc: MediaStreamAudioSourceNode | null = null;
  private aiRemoteAnalyser: AnalyserNode | null = null;
  private aiMeterTimer: ReturnType<typeof setInterval> | null = null;
  private lastAiLoudAt = 0;
  // LiveKit's active-speaker signal for the "agent" participant — the robust,
  // playout-grounded "is AVA actually making sound right now" the orb keys off.
  private lkAgentSpeaking = false;
  private lkAgentLastSpeakAt = 0;
  private lkPending = 0;                         // utterances started, not yet acked
  private lkUtterStartAt = 0;
  private lkAckChain: Promise<void> = Promise.resolve();
  // Keeps the orb "speaking" for a beat after the AI's track goes quiet, so a
  // gap between the AI's sentences/turns doesn't blink it out (see armAiHold).
  private aiHoldTimer: ReturnType<typeof setTimeout> | null = null;
  private audioSink: AudioSink | null = null;
  private stopSink: (() => void) | null = null;
  // Avatar over LiveKit: the AI's voice track, tapped back into 16 kHz PCM
  // (the mic worklet does the conversion) and streamed to the avatar for its
  // face while the LiveKit element keeps playing the voice. A "run" is one
  // stretch of AI speech, from its first audible frame until it is heard out;
  // utterances inside it are placed by duration (contiguous sentences) or by
  // the next audible frame (a gap).
  private avatarStream: AvatarStream | null = null;
  private aiCapture: AudioWorkletNode | null = null;
  private avRun = false;
  private avFedMs = 0;
  private avNextAt = 0;                              // fed-ms where the next utterance may begin
  private avCur: { subId: string; startMs: number } | null = null;
  private avQueue: { subId: string; text: string; durMs: number | null }[] = [];
  private avMsPerChar = 65;                          // learned from real durations
  // Stops + unregisters whichever AI-source-level tap (see startAiSourceLevelTap)
  // is currently live, for either playback path. Set while an utterance's tap
  // is running; cleared when it ends naturally or is force-stopped on cancel.
  private aiTapStop: (() => void) | null = null;
  // Separate schedule tail for the avatar-path's silent level-tap buffers —
  // independent of playScheduledTail (real playback timing) and recAiTail
  // (recording mix), so back-to-back utterances' taps don't overlap.
  private aiTapTail = 0;

  private timer: ReturnType<typeof setInterval> | null = null;
  private toastTimer: ReturnType<typeof setTimeout> | null = null;
  private sessionStart = 0;

  // (E) background blur: when on, localStream is the blurred output; we keep the
  // raw camera + the blur pipeline's stop fn so we can tear down / fall back.
  private rawCameraStream: MediaStream | null = null;
  private blurStop: (() => void) | null = null;

  // (G) muted-nudge: track sustained speech-while-muted to raise/clear the flag.
  private mutedSpeechSince = 0;
  private mutedNudgeClearTimer: ReturnType<typeof setTimeout> | null = null;

  // (A) recording: on for candidate sessions configured to record (proctoring —
  // the candidate consented to entire-screen + recording in the lobby); a no-op
  // when this interview's recordingEnabled is false. Started at WS-open.
  // These hold the MediaRecorders + their captured blobs.
  private camRecorder: MediaRecorder | null = null;
  private screenRecorder: MediaRecorder | null = null;
  // Tracks whether the candidate has manually picked an interviewer visual
  // mode, so the recording-off default (Minimal/orb) only applies before they
  // touch the selector — never overriding an explicit choice.
  private visualModeUserSet = false;
  // True once the screen blob exists. Mandatory screen share can be stopped +
  // re-shared mid-interview; the FIRST recorder creates the blob (seq 0), later
  // re-shares APPEND (keep counting) so we never overwrite earlier footage.
  private screenRecStarted = false;

  constructor(params: CandidateParams) {
    this.p = params;
    this.snap = {
      screen: "lobby",
      name: params.name,
      role: params.role,
      visualMode: "avatar",
      durationLabel: "~30 minutes",
      checks: { mic: "pending", speaker: "pending", browser: "pending", connection: "pending", screen: "pending" },
      browserLabel: "checking…",
      connCheckLabel: "checking…",
      micEnabled: false,
      micLevel: 0,
      speakerTested: false,
      startReady: false,
      conn: { state: "connecting", label: "—" },
      reconnecting: false,
      turn: { state: "listening", label: "Connecting…" },
      caption: "",
      rows: [],
      count: 0,
      candidateSpeaking: false,
      cameraOn: false,
      screenOn: false,
      micMuted: false,
      mutedNudge: false,
      selectedCamId: null,
      selectedMicId: null,
      bgBlurOn: false,
      recordingEnabled: true,
      recording: false,
      savingRecording: false,
      timer: "00:00",
      codingActive: false,
      codingPhaseMsg: null,
      codingHint: null,
      scenarioActive: false,
      scenarioItem: null,
      modal: null,
      toast: null,
    };
  }

  // ── external store ────────────────────────────────────────────────────────
  subscribe = (cb: () => void) => {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  };
  getSnapshot = () => this.snap;
  private set(partial: Partial<CandidateSnapshot>) {
    this.snap = { ...this.snap, ...partial };
    this.listeners.forEach((l) => l());
  }
  private setCheck(name: keyof CandidateSnapshot["checks"], state: CheckState) {
    this.set({ checks: { ...this.snap.checks, [name]: state } });
    this.refreshStartReady();
  }
  private refreshStartReady() {
    const c = this.snap.checks;
    // Camera AND entire-screen share are COMPULSORY for candidates (proctoring)
    // when this interview is configured to record — can't start until the
    // camera is on and a full-monitor share is live. When recording is off,
    // only the mic/speaker/browser/connection checks apply.
    const ready = c.mic === "ok" && c.speaker === "ok" && c.browser === "ok"
      && c.connection !== "error" && c.connection !== "pending"
      && (!this.snap.recordingEnabled || (this.snap.cameraOn && c.screen === "ok"));
    if (ready !== this.snap.startReady) this.set({ startReady: ready });
  }

  // ── boot ────────────────────────────────────────────────────────────────
  init = () => {
    this.detectBrowser();
    void this.measureConnection();
    void this.loadSessionInfo();
  };

  private async loadSessionInfo() {
    try {
      const qs = this.p.token ? `?token=${encodeURIComponent(this.p.token)}` : "";
      const r = await fetch(`/session-info${qs}`, { cache: "no-store" });
      if (!r.ok) return;
      const data = (await r.json()) as {
        duration_min?: number; role?: string; record_enabled?: boolean; status?: string | null;
        interview_over?: boolean;
      };
      // Reopening a link whose interview already finished (or was cancelled)
      // must not offer the Lobby at all — go straight to Done. This is a
      // courtesy early-exit; the WS layer (candidate_ws) refuses it too, so
      // skipping this check can't let anyone actually restart an interview.
      // Not `status === "completed"`: a crashed interview is marked completed
      // too, and its candidate must land back in it, not on Done.
      if (data?.interview_over) {
        this.set({ screen: "done" });
        return;
      }
      const mins = Number(data?.duration_min);
      if (Number.isFinite(mins) && mins > 0) {
        this.set({ durationLabel: `~${mins} minute${mins === 1 ? "" : "s"}` });
      }
      // Role + duration are authoritative from the admin-approved cadence/session
      // (served by /session-info), NOT the URL — the ?role= param is only a
      // fallback ("the role") and the "~30 minutes" default is a last resort.
      const role = (data?.role || "").trim();
      if (role) this.set({ role });
      // Explicit default true: a missing/undefined field must mean "record",
      // never the inverted (and backwards-incompatible) reading of `!x`.
      const recordingEnabled = data?.record_enabled !== false;
      this.set({ recordingEnabled });
      const lk = (data as { livekit?: { enabled?: boolean } | null }).livekit;
      if (lk?.enabled) this.lkOffered = true;
      // Default the interviewer to Minimal (orb) when recording is off — but
      // only if the candidate hasn't already picked a mode themselves.
      if (!recordingEnabled && !this.visualModeUserSet) {
        this.set({ visualMode: "minimal" });
      }
      this.refreshStartReady();
    } catch {
      /* keep fallbacks */
    }
  }

  private detectBrowser() {
    const ua = navigator.userAgent;
    let name = "Unknown";
    let ok = false;
    if (/Edg\//.test(ua)) {
      name = "Edge";
      ok = true;
    } else if (/Chrome\//.test(ua)) {
      name = "Chrome";
      ok = true;
    } else if (/Firefox\//.test(ua)) {
      name = "Firefox";
      ok = true;
    } else if (/Safari\//.test(ua)) {
      name = "Safari";
      ok = true; // trial: allow Safari to test voice capture (revert: git checkout before-safari-change -- this file)
    }
    const version = (ua.match(/(?:Chrome|Edg|Firefox|Safari)\/(\d+)/) || [])[1] || "?";
    this.set({ browserLabel: `${name} ${version}` });
    this.setCheck("browser", ok ? "ok" : "error");
    if (!ok) {
      this.set({
        modal: {
          title: "Browser not supported",
          body: "Please open this page in Chrome or Edge — Safari/older browsers have AudioWorklet limits that break voice capture.",
        },
      });
    }
  }

  private wsUrl(): string {
    if (this.p.wsPort) {
      const host = window.location.hostname || "localhost";
      return `ws://${host}:${this.p.wsPort}`;
    }
    const sid = window.crypto?.randomUUID
      ? window.crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    const scheme = window.location.protocol === "https:" ? "wss" : "ws";
    const tq = this.p.token
      ? `?token=${encodeURIComponent(this.p.token)}&client=${encodeURIComponent(this.tabId())}`
      : "";
    return `${scheme}://${window.location.host}/ws/candidate/${sid}${tq}`;
  }

  // Identifies THIS browser tab to the server. sessionStorage survives a refresh
  // but not a new tab or another device, which is exactly how the server tells
  // "the candidate refreshed" (let them back in) from "the link was opened a
  // second time while the interview is live" (refuse it).
  private tabIdCache = "";
  private tabId(): string {
    if (this.tabIdCache) return this.tabIdCache;
    const key = `iv:tab:${this.p.token}`;
    try {
      this.tabIdCache = sessionStorage.getItem(key) || "";
    } catch { /* storage blocked → an id for this page load only */ }
    if (!this.tabIdCache) {
      this.tabIdCache = window.crypto?.randomUUID
        ? window.crypto.randomUUID()
        : `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
      try { sessionStorage.setItem(key, this.tabIdCache); } catch { /* noop */ }
    }
    return this.tabIdCache;
  }

  private async measureConnection() {
    if (this.p.demo) {
      this.set({ connCheckLabel: "Demo mode (no backend)" });
      this.setCheck("connection", "warn");
      return;
    }
    // ?probe=1: the server answers without starting anything. The real
    // interview URL would claim the interview from the lobby — holding a
    // Speech slot while the candidate reads the checks, and leaving a
    // WebSocket session that kept a LiveKit start off LiveKit.
    const url = this.p.wsPort
      ? this.wsUrl()
      : `${window.location.protocol === "https:" ? "wss" : "ws"}://${window.location.host}/ws/candidate/probe?probe=1`;
    const t0 = performance.now();
    try {
      const ws = await this.probeWs(url, 6000);
      const ms = Math.round(performance.now() - t0);
      // High latency must NOT block the interview — a slow-but-working link still
      // lets the candidate proceed (the AI just replies with more delay). So a
      // slow probe is a "warn" (start allowed), never "error". Only a probe that
      // never opens at all (the catch below) is a hard, start-blocking error.
      let state: CheckState = "ok";
      let label = `Healthy (${ms}ms)`;
      if (ms > 300) {
        state = "warn";
        label = `Elevated latency (${ms}ms) — the AI may respond with a slight delay`;
      }
      if (ms > 800) {
        state = "warn";
        label = `High latency (${ms}ms) — you can still start; the AI may respond with a noticeable delay`;
      }
      this.set({ connCheckLabel: label });
      this.setCheck("connection", state);
      ws.close();
    } catch {
      this.set({ connCheckLabel: "Cannot reach interview server" });
      this.setCheck("connection", "error");
    }
  }
  private probeWs(url: string, timeoutMs: number): Promise<WebSocket> {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(url);
      const to = setTimeout(() => {
        try {
          ws.close();
        } catch {
          /* noop */
        }
        reject(new Error("timeout"));
      }, timeoutMs);
      ws.addEventListener("open", () => {
        clearTimeout(to);
        resolve(ws);
      });
      ws.addEventListener("error", () => {
        clearTimeout(to);
        reject(new Error("error"));
      });
    });
  }

  // ── lobby actions ─────────────────────────────────────────────────────────
  enableMic = async () => {
    try {
      // Tear down a prior capture so a device switch fully re-acquires.
      this.micStream?.getTracks().forEach((t) => t.stop());
      const audio: MediaTrackConstraints = {
        echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1,
      };
      // (C) pin the lobby-picked mic when one is selected.
      if (this.snap.selectedMicId) audio.deviceId = { exact: this.snap.selectedMicId };
      this.micStream = await navigator.mediaDevices.getUserMedia({ audio, video: false });
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = this.audioCtx || new Ctor();
      if (this.audioCtx.state === "suspended") await this.audioCtx.resume();
      await this.audioCtx.audioWorklet.addModule(MIC_WORKLET_URL);
      const source = this.audioCtx.createMediaStreamSource(this.micStream);
      this.micWorklet = new AudioWorkletNode(this.audioCtx, "mic-capture");
      this.micWorklet.port.onmessage = (e) => this.onMicMessage(e.data);
      source.connect(this.micWorklet);
      this.set({ micEnabled: true });
      this.setCheck("mic", "ok");
    } catch (err) {
      console.error(err);
      this.setCheck("mic", "error");
      this.set({
        modal: {
          title: "Microphone access needed",
          body: "We can't run the interview without microphone access. Allow the mic in your browser and refresh.",
        },
      });
    }
  };

  private onMicMessage(msg: { type?: string; rms?: number; buffer?: ArrayBuffer }) {
    if (msg.type === "meter") {
      const level = Math.min(100, (msg.rms || 0) * 600);
      this.set({ micLevel: level });
      this.updateMutedNudge(level);
      // Muted must not react to audio at all, not just render dark — don't
      // even feed the level through while muted.
      if (this.snap.micMuted) resetSource("mic");
      else pushLevel("mic", level);
    } else if (msg.type === "pcm") {
      // micMuted = candidate muted themselves → stop sending frames (the AI
      // stops hearing them) until they unmute.
      if (this.snap.micMuted) return;
      if (this.lkLive) return;  // the mic is a published LiveKit track now
      if (this.ws && this.ws.readyState === WebSocket.OPEN && msg.buffer) {
        try {
          this.ws.send(msg.buffer);
        } catch {
          /* noop */
        }
      }
    }
  }

  // (G) "You're muted" nudge: when muted, sustained speech (~600ms above the
  // level threshold) raises the flag; it clears after ~2s of quiet. Only
  // meaningful while muted — unmuting clears immediately elsewhere isn't needed
  // since the banner is gated on micMuted in the UI, but we still clear state.
  private updateMutedNudge(level: number) {
    if (!this.snap.micMuted) {
      // Not muted → no nudge; reset tracking.
      if (this.snap.mutedNudge) this.set({ mutedNudge: false });
      this.mutedSpeechSince = 0;
      return;
    }
    const SPEECH = 25;       // micLevel above this counts as talking
    const SUSTAIN_MS = 600;  // must persist this long before nudging
    const CLEAR_MS = 2000;   // clear after this much quiet
    const now = Date.now();
    if (level > SPEECH) {
      if (this.mutedSpeechSince === 0) this.mutedSpeechSince = now;
      if (now - this.mutedSpeechSince >= SUSTAIN_MS && !this.snap.mutedNudge) {
        this.set({ mutedNudge: true });
      }
      if (this.mutedNudgeClearTimer) { clearTimeout(this.mutedNudgeClearTimer); this.mutedNudgeClearTimer = null; }
    } else {
      this.mutedSpeechSince = 0;
      // Schedule a clear once they stop talking.
      if (this.snap.mutedNudge && !this.mutedNudgeClearTimer) {
        this.mutedNudgeClearTimer = setTimeout(() => {
          this.mutedNudgeClearTimer = null;
          this.set({ mutedNudge: false });
        }, CLEAR_MS);
      }
    }
  }

  // ── active-speaker ring ───────────────────────────────────────────────────
  private speakingTimer: ReturnType<typeof setTimeout> | null = null;
  private markCandidateSpeaking() {
    if (!this.snap.candidateSpeaking) this.set({ candidateSpeaking: true });
    if (this.speakingTimer) clearTimeout(this.speakingTimer);
    this.speakingTimer = setTimeout(() => this.set({ candidateSpeaking: false }), 1200);
  }

  // ── optional camera (JPEG snapshots) ──────────────────────────────────────
  private localStream: MediaStream | null = null;
  getLocalStream = () => this.localStream;
  enableCamera = async (): Promise<boolean> => {
    if (this.localStream) return true;
    try {
      const { startCamera } = await import("./videoCam");
      // (C) pin the lobby-picked camera; (E) optionally run through blur.
      this.rawCameraStream = await startCamera(
        this.snap.selectedCamId ? { deviceId: this.snap.selectedCamId } : undefined,
      );
      const camTrack = this.rawCameraStream.getVideoTracks()[0];
      if (camTrack) camTrack.onended = () => this.onCameraEnded();  // unplugged / OS permission revoked
      this.localStream = await this.maybeBlur(this.rawCameraStream);
      this.set({ cameraOn: true });
      this.refreshStartReady();
      return true;
    } catch (err) {
      console.error("camera init failed", err);
      this.showToast("Couldn't access the camera. Check browser permissions.");
      return false;
    }
  };
  disableCamera = () => {
    this.tearDownBlur();
    this.rawCameraStream?.getTracks().forEach((t) => t.stop());
    this.rawCameraStream = null;
    this.localStream?.getTracks().forEach((t) => t.stop());
    this.localStream = null;
    this.set({ cameraOn: false });
    this.refreshStartReady();
  };
  toggleCamera = async () => { if (this.snap.cameraOn) this.disableCamera(); else await this.enableCamera(); };
  // The camera stopped unexpectedly (device unplugged, OS-level permission
  // revoked). Camera is mandatory once recording is on, so surface it rather
  // than silently leaving a frozen/black tile — no auto-reacquire (the device
  // may be gone, and re-granting permission needs a fresh user gesture
  // anyway); the top-bar toggle re-enables itself once cameraOn is false so
  // the candidate has a way back in.
  private onCameraEnded = () => {
    this.disableCamera();
    if (this.snap.screen === "live" && this.snap.recordingEnabled) {
      this.set({ modal: {
        title: "Camera disconnected",
        body: "Your camera stopped unexpectedly. This interview requires your camera to stay on — click “Camera off” in the top bar to reconnect it.",
      } });
    }
  };

  // (C) Lobby device pickers select a deviceId, then re-acquire that input so
  // the change takes effect immediately (and the self-view updates).
  selectCamera = async (deviceId: string) => {
    this.set({ selectedCamId: deviceId || null });
    if (!this.snap.cameraOn) return;
    this.disableCamera();
    await this.enableCamera();
  };
  selectMic = async (deviceId: string) => {
    this.set({ selectedMicId: deviceId || null });
    if (this.snap.micEnabled) await this.enableMic();
  };

  // (E) Background blur. maybeBlur returns the blurred stream when bgBlurOn (and
  // the pipeline boots), else the raw stream. Failures fall back to raw + a
  // toast. tearDownBlur stops the offscreen segmentation loop.
  private async maybeBlur(raw: MediaStream): Promise<MediaStream> {
    if (!this.snap.bgBlurOn) return raw;
    try {
      const { applyBlur } = await import("./bgBlur");
      const out = await applyBlur(raw);
      if (out) {
        this.blurStop = out.stop;
        return out.stream;
      }
    } catch (err) {
      console.error("blur failed", err);
    }
    this.showToast("Background blur unavailable — using your normal camera.");
    this.set({ bgBlurOn: false });
    return raw;
  }
  private tearDownBlur() {
    try { this.blurStop?.(); } catch { /* noop */ }
    this.blurStop = null;
  }
  // Toggle blur; if the camera is live, re-derive localStream from the raw
  // camera so the self-view + outgoing snapshots reflect the change at once.
  toggleBlur = async () => {
    const next = !this.snap.bgBlurOn;
    this.set({ bgBlurOn: next });
    if (!this.snap.cameraOn || !this.rawCameraStream) return;
    this.tearDownBlur();
    // Stop only the previous *output* tracks if they differ from the raw cam.
    if (this.localStream && this.localStream !== this.rawCameraStream) {
      this.localStream.getTracks().forEach((t) => t.stop());
    }
    this.localStream = await this.maybeBlur(this.rawCameraStream);
    // Nudge subscribers so the self-view re-reads getLocalStream().
    this.set({ cameraOn: true });
  };

  // ── screen share (getDisplayMedia) ────────────────────────────────────────
  private localScreenStream: MediaStream | null = null;
  getLocalScreenStream = () => this.localScreenStream;
  enableScreen = async (): Promise<boolean> => {
    if (this.localScreenStream) return true;
    try {
      const { startScreen, isEntireScreen } = await import("./videoCam");
      const stream = await startScreen();
      // Proctoring: must be the ENTIRE screen, not a window/tab. If the candidate
      // picked something narrower, drop it and ask them to re-share.
      if (!isEntireScreen(stream)) {
        stream.getTracks().forEach((t) => t.stop());
        this.setCheck("screen", "error");
        this.set({ modal: {
          title: "Share your entire screen",
          body: "Please choose your whole screen (the “Entire screen” tab), not a single window or browser tab. Click Enable and try again.",
        } });
        return false;
      }
      this.localScreenStream = stream;
      const t = stream.getVideoTracks()[0];
      if (t) t.onended = () => this.onScreenEnded();  // user hit browser "Stop sharing"
      this.set({ screenOn: true });
      this.setCheck("screen", "ok");
      this.startScreenRecorder();  // capture the screen if recording is active
      return true;
    } catch (err) {
      console.error("screen share failed", err);
      this.setCheck("screen", "error");
      return false;
    }
  };
  disableScreen = () => {
    // Stop the screen recorder FIRST (its onstop uploads the buffered webm)
    // before killing the source tracks.
    try { this.screenRecorder?.stop(); } catch { /* noop */ }
    this.screenRecorder = null;
    this.localScreenStream?.getTracks().forEach((t) => t.stop());
    this.localScreenStream = null;
    this.set({ screenOn: false });
    this.setCheck("screen", "pending");
  };
  // The candidate stopped sharing (browser "Stop sharing" or revoked). Screen
  // share is mandatory, so once the interview is live we block + prompt them to
  // re-share. In the lobby this just resets the check (Start re-disables itself).
  private onScreenEnded = () => {
    this.disableScreen();
    if (this.snap.screen === "live") {
      this.set({ modal: {
        title: "Screen sharing stopped",
        body: "Your entire screen must stay shared for the whole interview. Click “Re-share screen” to continue.",
      } });
    }
  };
  toggleScreen = async () => { if (this.snap.screenOn) this.disableScreen(); else await this.enableScreen(); };

  toggleMic = () => {
    const micMuted = !this.snap.micMuted;
    this.set({ micMuted });
    void this.lk?.setMicMuted(micMuted);
    // TELL THE SERVER. Muting stops the PCM frames, and the server decides an
    // utterance has ended by HEARING a tail of silence — which is itself made
    // of frames. So "no frames" reads as "still mid-sentence" forever: the VAD
    // never reaches DONE, candidate_speaking stays true, and turn-taking
    // refuses every AI turn for the rest of the interview. Muting is the one
    // end-of-utterance the server cannot observe, so we say it out loud —
    // on the room's data channel in LiveKit mode, where there is no WebSocket.
    this.sendControl({ type: "mic_muted", muted: micMuted });
    // Snap the glow off the instant mute engages, rather than waiting up to
    // ~50ms for the next meter tick to notice.
    if (micMuted) resetSource("mic");
  };

  // ── live transcript (AI + candidate) ─────────────────────────────────────
  // setPartial creates/updates the in-flight STT row; promotePartial finalizes
  // it into a permanent row.
  private rowSeq = 0;
  private partialId: number | null = null;
  private appendRow(role: string, text: string) {
    if (!text) return;
    this.set({
      rows: this.snap.rows.concat({ id: this.rowSeq++, role, meta: role, text }),
      count: this.snap.count + 1,
    });
  }
  private setPartial(text: string) {
    let rows = this.snap.rows;
    if (!text) {
      if (this.partialId != null) rows = rows.filter((r) => r.id !== this.partialId);
      this.partialId = null;
      this.set({ rows });
      return;
    }
    if (this.partialId == null) {
      const id = this.rowSeq++;
      this.partialId = id;
      rows = rows.concat({ id, role: "candidate", meta: "candidate (speaking…)", text: text + "…", partial: true });
    } else {
      rows = rows.map((r) => (r.id === this.partialId ? { ...r, text: text + "…" } : r));
    }
    this.set({ rows });
  }
  private promotePartial(text: string) {
    let rows = this.snap.rows;
    if (this.partialId != null) rows = rows.filter((r) => r.id !== this.partialId);
    this.partialId = null;
    this.set({ rows });
    if (text && text.trim()) this.appendRow("candidate", text);
  }

  testSpeaker = async () => {
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.audioCtx = this.audioCtx || new Ctor();
    if (this.audioCtx.state === "suspended") await this.audioCtx.resume();
    const now = this.audioCtx.currentTime;
    [523.25, 659.25, 783.99].forEach((f, i) => {
      const o = this.audioCtx!.createOscillator();
      const g = this.audioCtx!.createGain();
      o.frequency.value = f;
      o.type = "sine";
      g.gain.setValueAtTime(0, now + i * 0.12);
      g.gain.linearRampToValueAtTime(0.12, now + i * 0.12 + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.12 + 0.25);
      o.connect(g).connect(this.audioCtx!.destination);
      o.start(now + i * 0.12);
      o.stop(now + i * 0.12 + 0.3);
    });
    setTimeout(() => {
      this.set({ speakerTested: true });
      this.setCheck("speaker", "ok");
    }, 600);
  };

  setVolume = (v: number) => {
    if (!Number.isNaN(v)) this.volumeGain = v;
    // A media element can't amplify past 1.0, so over LiveKit "louder than
    // normal" is simply normal.
    if (!Number.isNaN(v)) this.lk?.setVolume(v);
  };
  dismissModal = () => this.set({ modal: null });
  setVisualMode = (m: VisualMode) => {
    this.visualModeUserSet = true;
    this.set({ visualMode: m });
  };

  // React registers an avatar sink (TalkingHead) + a stop fn before/at start;
  // the player loop routes PCM through the sink instead of the AudioContext.
  // Passing null reverts to minimal-mode AudioContext playback (the fallback
  // when the avatar fails to boot).
  setAudioSink = (sink: AudioSink | null, stop: (() => void) | null, stream: AvatarStream | null = null) => {
    this.audioSink = sink;
    this.stopSink = stop;
    this.avatarStream = stream;
    this.avReset();
  };
  getSampleRate = () => this.sampleRate;
  // The interview token — the Simli adapter needs it to mint a session token
  // server-side (/api/simli/token), which is how the Simli API key is kept out
  // of the browser.
  getToken = () => this.p.token;

  // Send a coding-panel message (code edit/run/submit/hint/anti-cheat) over
  // the candidate WS. No-op in demo mode / when the socket is closed.
  sendCoding = (m: Record<string, unknown>) => {
    this.sendControl(m);
  };

  // One control message to the server: through the room's data channel in
  // LiveKit mode, else over the WebSocket. No-op when neither is open.
  private sendControl(m: Record<string, unknown>) {
    if (this.roomMode && this.lk) {
      this.lk.sendControl(m).catch((err) => console.error("[livekit] control send failed", err));
      return;
    }
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      try {
        this.ws.send(JSON.stringify(m));
      } catch {
        /* noop */
      }
    }
  }

  // Report a Visual Scenario Analysis item's media playback state back to
  // the director (see Director.on_scenario_media_ack). "ended" = finished
  // naturally or the candidate manually stopped it after starting (both are
  // fine — the item can still be answered); "error" = failed to load.
  sendScenarioMediaAck = (kind: "ended" | "error" | "skipped") => {
    this.sendControl({ type: `scenario_media_${kind}` });
  };

  // ── start / live ────────────────────────────────────────────────────────
  // Consent captured from the T&C modal (see components/TermsModal). Held so it
  // can travel with the {type:"start"} payload as an auditable acceptance record.
  private termsConsent: { version: string; acceptedAt: string } | null = null;
  startInterview = async (consent?: { version: string; acceptedAt: string }) => {
    if (consent) this.termsConsent = consent;
    this.refused = false;
    this.set({ screen: "live", turn: { state: "listening", label: "Connecting…" }, caption: "Your interviewer is preparing to greet you…" });
    this.startTimer();
    try {
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = this.audioCtx || new Ctor();
      if (this.audioCtx.state === "suspended") await this.audioCtx.resume();
    } catch {
      /* noop */
    }
    if (this.p.demo) {
      void this.runDemoLoop();
      return;
    }
    if (this.lkOffered && this.p.token) void this.startRoom();
    else this.connect();
  };

  private startTimer() {
    this.sessionStart = Date.now();
    this.timer = setInterval(() => {
      const s = Math.floor((Date.now() - this.sessionStart) / 1000);
      const mm = String(Math.floor(s / 60)).padStart(2, "0");
      const ss = String(s % 60).padStart(2, "0");
      this.set({ timer: `${mm}:${ss}` });
    }, 1000);
  }

  private connect = () => {
    if (this.destroyed) return;
    const ws = new WebSocket(this.wsUrl());
    this.ws = ws;
    ws.binaryType = "arraybuffer";
    ws.addEventListener("open", () => {
      // Was this a RECONNECT (not the first connect)? Keep the "reconnecting…"
      // overlay up until the session is actually live again — the WS can open
      // then drop again while a shard cold-starts, so clearing on open made the
      // overlay flicker. markLive() clears it on the first live audio (the resume
      // apology) or transcript. The retry budget is reset either way.
      const wasReconnect = this.reconnects > 0;
      this.reconnects = 0;
      this.awaitingLive = wasReconnect;
      // Browsers suspend the AudioContext while the tab is disconnected. Resume it
      // on reconnect so the session's resume announce actually PLAYS and the
      // browser sends its playback-finished ack — the session waits on that ack
      // before continuing, so without this each announce line stalled ~20s.
      if (this.audioCtx && this.audioCtx.state === "suspended") void this.audioCtx.resume();
      this.set({
        conn: { state: "ok", label: "Connected" },
        reconnecting: wasReconnect,
        turn: wasReconnect
          ? { state: "thinking", label: "Reconnecting…" }
          : { state: "listening", label: "Listening…" },
      });
      ws.send(JSON.stringify({
        type: "start",
        visual_mode: this.snap.visualMode,
        candidate: { name: this.p.name, role: this.p.role },
        // Auditable consent record (harmless extra fields if the server ignores them).
        ...(this.termsConsent ? { terms_accepted: true, terms_version: this.termsConsent.version, terms_accepted_at: this.termsConsent.acceptedAt } : {}),
      }));
      // Recording starts on the server's "hello", not here: a socket the server
      // then refuses (interview over, or live in another window) must not record.
    });
    ws.addEventListener("message", (evt) => {
      if (typeof evt.data !== "string") {
        // Binary frame = 1-byte source tag + PCM. Only tag 0 (AI TTS) is sent:
        // buffer it into the active receive → avatar/minimal player.
        const ab = evt.data as ArrayBuffer;
        if (ab.byteLength < 2) return;
        const tag = new Uint8Array(ab, 0, 1)[0];
        if (tag === 0 && this.activeRecv) this.activeRecv.pcm.push(ab.slice(1));
        return;
      }
      try {
        this.handleControl(JSON.parse(evt.data));
      } catch {
        /* noop */
      }
    });
    ws.addEventListener("error", () => this.set({ conn: { state: "warn", label: "Connection issue" } }));
    ws.addEventListener("close", () => {
      if (this.destroyed || this.refused) return;
      this.set({ conn: { state: "error", label: "Reconnecting…" } });
      // A shard restart / crash can take ~60-90s to come back and resume, so we
      // retry patiently over a long window (not the old 3 attempts / ~9s) with a
      // calm persistent overlay — the interview resumes automatically once the
      // fresh runner is up. Only after the full window do we ask them to refresh.
      if (this.snap.screen === "live" && this.reconnects < CandidateEngine.RECONNECT_MAX) {
        this.reconnects += 1;
        // Capped backoff: quick first retries, then settle to ~4s.
        const delay = Math.min(1500 * this.reconnects, 4000);
        this.set({ reconnecting: true });
        setTimeout(this.connect, delay);
      } else if (this.snap.screen === "live") {
        this.set({
          reconnecting: false,
          modal: {
            title: "Lost connection",
            body: "We couldn't reconnect after a while. Reopen the same "
              + "interview link to pick up where you left off.",
          },
        });
      }
    });
  };

  // On a reconnect, drop the "reconnecting…" overlay the moment the session is
  // demonstrably live again — the first inbound AI audio (the resume apology) or
  // candidate transcript. Idempotent; a no-op on the first connect.
  private markLive() {
    if (!this.awaitingLive) return;
    this.awaitingLive = false;
    this.set({ reconnecting: false, turn: { state: "listening", label: "Listening…" } });
  }

  private handleControl(msg: Record<string, unknown>) {
    switch (msg.type as string) {
      case "hello":
        if (msg.sample_rate) this.sampleRate = msg.sample_rate as number;
        // (A) Proctoring: the server has attached this socket to the interview.
        // When it's configured to record, screen share is mandatory and the
        // candidate consented in the lobby, so record from the very start
        // (camera+audio mix AND the entire-screen track). startRecording() is a
        // no-op when recordingEnabled is false, and idempotent otherwise (a
        // reconnect won't double-start).
        void this.startRecording();
        break;
      case "media_transport":
        // In the room this confirms LiveKit. "websocket" there means the server
        // gave up waiting for us in the room: move to the WebSocket path.
        if (msg.transport === "websocket" && this.roomMode) void this.switchToWebSocket();
        break;
      case "session_in_use":
        // The interview is live in another tab or device. Stop here: no
        // auto-reconnect (it would fight the other window for the session).
        this.refused = true;
        try { this.ws?.close(); } catch { /* noop */ }
        if (this.timer) clearInterval(this.timer);
        this.set({
          screen: "lobby",
          reconnecting: false,
          conn: { state: "error", label: "In use elsewhere" },
          modal: {
            title: "Interview in progress",
            body: "This interview is already in progress in another window or on "
              + "another device. Continue it there. If that window was closed, wait "
              + "a minute and reopen this link.",
          },
        });
        break;
      case "audio_start": {
        // Cross-interview guard: only play/record AI audio stamped with THIS
        // interview's token. If a foreign session_id arrives (another interview's
        // TTS reaching this socket), drop the whole utterance — don't open a
        // receive buffer, so the following tag-0 PCM is neither played nor
        // recorded — and warn with both ids so the cross is caught. Empty/absent
        // session_id (legacy server) → no guard.
        const aud = msg.session_id as string | undefined;
        if (aud && this.p.token && aud !== this.p.token) {
          console.warn("[audio-guard] dropped foreign AI audio", { got: aud, mine: this.p.token });
          this.activeRecv = null;
          break;
        }
        this.markLive();  // first live AI audio after a reconnect → clear overlay
        if (msg.sample_rate) this.sampleRate = msg.sample_rate as number;
        this.activeRecv = { subId: (msg.sub_id as string) || "", text: (msg.text as string) || "", pcm: [], sampleRate: (msg.sample_rate as number) || this.sampleRate };
        this.aiSpeaking = true;
        this.set({ turn: { state: "speaking", label: "AI is speaking" } });
        if (this.lkLive) {
          // The voice is already streaming in over LiveKit, so caption it now
          // (the WebSocket path captions when its own playback starts).
          this.lkPending += 1;
          this.lkUtterStartAt = performance.now();
          // New audio ⇒ AVA is speaking; cancel any pending speaking→rest hold.
          this.clearAiHold();
          if (this.avatarStream) this.avQueue.push({ subId: this.activeRecv.subId, text: this.activeRecv.text, durMs: null });
          if (this.activeRecv.text) {
            this.set({ caption: this.activeRecv.text });
            this.appendRow("ai", this.activeRecv.text);
          }
        }
        break;
      }
      case "audio_end":
        if (this.lkLive && this.activeRecv) {
          this.avDuration(this.activeRecv.subId, this.activeRecv.text, msg.duration_ms as number | undefined);
          this.lkAckAfterPlayout(this.activeRecv.subId);
        } else if (this.activeRecv && this.activeRecv.pcm.length > 0) {
          this.aiQueue.push(this.activeRecv);
          this.kickPlayer();
        }
        this.activeRecv = null;
        break;
      case "audio_cancel":
        this.activeRecv = null;
        this.aiQueue.length = 0;
        this.aiSpeaking = false;
        this.lkPending = 0;
        this.clearAiHold();
        if (this.avRun) {
          try { this.avatarStream?.cut(); } catch { /* noop */ }
        }
        this.avReset();
        try {
          this.stopSink?.();
        } catch {
          /* noop */
        }
        // Barge-in: whichever AI-level tap is running (either path) keeps
        // sampling real audio otherwise, so the glow would linger after the
        // candidate cut the AI off. Stop it and zero explicitly rather than
        // waiting on its own onended, which may not fire for a while yet.
        try {
          this.aiTapStop?.();
        } catch {
          /* noop */
        }
        resetSource("ai");
        this.set({ turn: { state: "listening", label: "Your turn" }, caption: "" });
        break;
      case "stt_partial":
        this.markLive();  // transcript flowing after a reconnect → live
        if (this.aiSpeaking) break;
        this.setPartial((msg.text as string) || "");
        this.markCandidateSpeaking();
        break;
      case "stt_final":
        if (this.aiSpeaking) break;
        this.promotePartial((msg.text as string) || "");
        this.markCandidateSpeaking();
        break;
      // session_end: the runner hung up. session_ended: the server tore the
      // session down (an admin deleted it, or the natural-end notice), or
      // refused to start a NEW interview because this token is already over
      // (the candidate reopened a finished link). All mean the interview is
      // over; endInterview closes the socket on the first.
      case "session_end":
      case "session_ended":
        this.endInterview();
        break;
      case "coding_preload":
        // Pyodide preload during warm_up is an optimization; the panel's
        // ensureWorker() handles cold-start on mount. No-op here.
        break;
      case "coding_phase_start":
        // Hand the full phase payload to the React CodingPanel, which mounts
        // the reused Pyodide/editor widget.
        this.set({ codingActive: true, codingPhaseMsg: msg, codingHint: null });
        break;
      case "coding_phase_end":
        this.set({ codingActive: false, codingPhaseMsg: null });
        break;
      case "coding_hint":
        if (msg.hint_text) this.set({ codingHint: msg.hint_text as string });
        break;
      case "scenario_item_start":
        // A freshly-dispatched item (or a RESEED after reconnect — see
        // `resync` on the payload) — hand the whole descriptor to the
        // ScenarioMediaPanel, which builds its own asset URL and decides
        // whether to autoplay (never on a resync).
        this.set({ scenarioActive: true, scenarioItem: msg as unknown as ScenarioItemMsg });
        break;
      case "scenario_phase_end":
        this.set({ scenarioActive: false, scenarioItem: null });
        break;
      default:
        break;
    }
  }

  // single-flight player loop (caption synced to the chunk being heard)
  private sleep(ms: number): Promise<void> {
    return new Promise((r) => setTimeout(r, Math.max(0, ms)));
  }

  // Silent buffer scheduled on our own AudioContext, purely to obtain an
  // audio-clock-accurate "finished playing" event (onended) when the audible
  // audio is owned by an avatar that reports no completion (TalkingHead today).
  // A zero-filled buffer makes no sound; onended fires at start+duration on the
  // audio clock, so it's immune to setTimeout jank under a busy event loop.
  private playTimingShadow(totalSamples: number, sampleRate: number): Promise<void> {
    return new Promise<void>((resolve) => {
      try {
        if (!this.audioCtx || totalSamples <= 0) { resolve(); return; }
        const buf = this.audioCtx.createBuffer(1, totalSamples, sampleRate); // silent
        const src = this.audioCtx.createBufferSource();
        src.buffer = buf;
        src.connect(this.audioCtx.destination);
        src.onended = () => resolve();
        const start = Math.max(this.audioCtx.currentTime, this.playScheduledTail);
        src.start(start);
        this.playScheduledTail = start + buf.duration;
      } catch {
        resolve();
      }
    });
  }

  // Avatar-path AI-source-level tap: a silent buffer carrying the identical
  // PCM TalkingHead is (separately) playing audibly, connected through an
  // AnalyserNode to a permanently-muted gain node so it's part of the audio
  // graph (and therefore actually processed) without being heard. This reads
  // the source PCM, not the real speaker output — see ticket note on AC2.
  private aiTapSink: GainNode | null = null;
  private ensureAiTapSink(): GainNode | null {
    if (!this.audioCtx) return null;
    if (this.aiTapSink) return this.aiTapSink;
    try {
      const g = this.audioCtx.createGain();
      g.gain.value = 0;
      g.connect(this.audioCtx.destination);
      this.aiTapSink = g;
      return g;
    } catch {
      return null;
    }
  }
  private startAiSourceLevelTap(chunks: ArrayBuffer[], sampleRate: number) {
    if (!this.audioCtx || !chunks.length) return;
    const sink = this.ensureAiTapSink();
    if (!sink) return;
    try {
      const buf = this.toAudioBuffer(chunks, sampleRate);
      const src = this.audioCtx.createBufferSource();
      src.buffer = buf;
      const analyser = this.audioCtx.createAnalyser();
      analyser.fftSize = 1024;
      src.connect(analyser);
      analyser.connect(sink);
      registerAnalyser("ai", analyser);
      const stop = () => {
        try { src.stop(); } catch { /* noop */ }
        try { src.disconnect(); } catch { /* noop */ }
        try { analyser.disconnect(); } catch { /* noop */ }
        if (unregisterAnalyser("ai", analyser)) resetSource("ai");
        if (this.aiTapStop === stop) this.aiTapStop = null;
      };
      this.aiTapStop = stop;
      src.onended = stop;
      const start = Math.max(this.audioCtx.currentTime, this.aiTapTail);
      src.start(start);
      this.aiTapTail = start + buf.duration;
    } catch (err) {
      console.error("ai source-level tap failed", err);
    }
  }

  // ── LiveKit audio ────────────────────────────────────────────────────────
  // Start (or rejoin) the interview through the LiveKit room. One HTTP call:
  // the shard that runs the interview checks this tab may have it, starts it,
  // and answers with this tab's room token once the AI is in the room.
  private postStart = async (extra: Record<string, unknown> = {}) => {
    let res: Response | null = null;
    let body: Record<string, unknown> = {};
    try {
      res = await fetch(`/api/candidate/${encodeURIComponent(this.p.token || "")}/start`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          client: this.tabId(),
          visual_mode: this.snap.visualMode,
          candidate: { name: this.p.name, role: this.p.role },
          ...(this.termsConsent ? { terms_accepted: true, terms_version: this.termsConsent.version, terms_accepted_at: this.termsConsent.acceptedAt } : {}),
          ...extra,
        }),
      });
      body = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    } catch {
      /* network — the WebSocket path reports it properly */
    }
    return { res, body };
  };

  private startRoom = async () => {
    if (this.destroyed || !this.p.token) return;
    const { res, body } = await this.postStart();
    if (res?.status === 409 && body.reason === "session_in_use") {
      this.handleControl({ type: "session_in_use" });
      return;
    }
    if (res?.status === 410) {
      this.handleControl({ type: "session_ended", reason: "interview_over" });
      return;
    }
    if (!res || !res.ok || body.transport !== "livekit") {
      this.connect();  // the WebSocket path, with its own errors and retries
      return;
    }
    if (!(await this.joinRoom(body.url as string, body.token as string))) await this.fallBackToWebSocket();
  };

  // The room is unusable from here (blocked network, …): have the interview
  // handed off, so the WebSocket path can run it — the server running it in
  // the room may be one nothing can route a WebSocket to.
  private fallBackToWebSocket = async () => {
    await this.leaveLiveKit();
    await this.postStart({ fallback: "websocket" });
    this.connect();
  };

  private joinRoom = async (url: string, token: string): Promise<boolean> => {
    const micTrack = this.micStream?.getAudioTracks()[0];
    if (!micTrack || this.destroyed) return false;
    await this.leaveLiveKit();  // a stale room from before a rejoin
    const lk: LiveKitMedia = new LiveKitMedia({
      url, token, micTrack,
      onAiTrack: (track) => this.attachAiRemote(track),
      onControl: (m) => { if (this.lk === lk) this.handleControl(m); },
      onSpeakingChanged: (sp) => { if (this.lk === lk) this.onLkAgentSpeaking(sp); },
      onReconnecting: () => {
        if (this.lk === lk) this.set({ reconnecting: true, conn: { state: "warn", label: "Reconnecting…" } });
      },
      onReconnected: () => {
        if (this.lk !== lk) return;
        this.set({ reconnecting: false, conn: { state: "ok", label: "Connected" } });
        // Messages sent while we were away are gone: ask to be brought up to date.
        void lk.sendControl({ type: "attach" }).catch(() => {});
      },
      onAgentLeft: () => { if (this.lk === lk) void this.onAgentLeft(); },
      onDisconnected: () => { if (this.lk === lk) void this.onRoomLost(); },
      onError: (where, err) => console.error(`[livekit] ${where}`, err),
    });
    this.lk = lk;
    try {
      await lk.connect();
      this.roomMode = true;
      this.lkLive = true;
      if (this.snap.micMuted) await lk.setMicMuted(true);
      lk.setVolume(this.volumeGain);
      this.set({ reconnecting: false, conn: { state: "ok", label: "Connected" } });
      await lk.sendControl({ type: "attach" });  // → hello + current phase etc.
      this.roomRetries = 0;
      return true;
    } catch (err) {
      console.error("[livekit] join failed", err);
      if (this.lk === lk) await this.leaveLiveKit();
      return false;
    }
  };

  // The AI's participant left without a goodbye (a clean end sends
  // session_end first, which already ended the page): its server went away.
  // Rejoin — the shard resumes from the checkpoint — unless it's over.
  private onAgentLeft = async () => {
    await this.sleep(3000);
    if (!this.roomMode || this.snap.screen !== "live" || this.destroyed) return;
    this.set({ reconnecting: true });
    await this.resumeRoom();
  };

  // The SDK gave up reconnecting the room (network gone for a while).
  private onRoomLost = async () => {
    if (!this.roomMode || this.snap.screen !== "live" || this.destroyed) return;
    this.roomMode = false;
    this.lk = null;
    this.set({ reconnecting: true });
    await this.sleep(2000);
    await this.resumeRoom();
  };

  private resumeRoom = async () => {
    if (this.destroyed) return;
    if (this.roomRetries >= 20) {
      this.set({
        reconnecting: false,
        modal: {
          title: "Lost connection",
          body: "We couldn't reconnect after a while. Reopen the same "
            + "interview link to pick up where you left off.",
        },
      });
      return;
    }
    this.roomRetries += 1;
    try {
      const r = await fetch(`/session-info?token=${encodeURIComponent(this.p.token || "")}`, { cache: "no-store" });
      const d = (await r.json()) as { interview_over?: boolean };
      if (d?.interview_over) { this.endInterview(); return; }
    } catch { /* try rejoining anyway */ }
    await this.startRoom();
  };

  // The server gave up on the room (it already handed the interview off).
  private switchToWebSocket = async () => {
    await this.leaveLiveKit();
    this.connect();
  };

  private leaveLiveKit = async () => {
    const lk = this.lk;
    this.lk = null;
    this.lkLive = false;
    this.roomMode = false;
    this.clearAiHold();
    if (this.aiMeterTimer) { clearInterval(this.aiMeterTimer); this.aiMeterTimer = null; }
    if (this.aiRemoteAnalyser) {
      if (unregisterAnalyser("ai", this.aiRemoteAnalyser)) resetSource("ai");
      this.aiRemoteAnalyser = null;
    }
    try { this.aiRemoteSrc?.disconnect(); } catch { /* noop */ }
    this.aiRemoteSrc = null;
    try { this.aiCapture?.disconnect(); } catch { /* noop */ }
    this.aiCapture = null;
    if (this.avRun) {
      try { this.avatarStream?.cut(); } catch { /* noop */ }
    }
    this.avReset();
    await lk?.disconnect();
  };

  private attachAiRemote(track: MediaStreamTrack) {
    if (!this.audioCtx) return;
    try { this.aiRemoteSrc?.disconnect(); } catch { /* noop */ }
    if (this.aiRemoteAnalyser && unregisterAnalyser("ai", this.aiRemoteAnalyser)) resetSource("ai");
    const src = this.audioCtx.createMediaStreamSource(new MediaStream([track]));
    const analyser = this.audioCtx.createAnalyser();
    analyser.fftSize = 1024;
    // Observe only — the media element plays it. Connecting to the speakers
    // here too would play the AI twice.
    src.connect(analyser);
    if (this.recMixDest) src.connect(this.recMixDest);
    // The avatar's feed: the same track back as 16 kHz PCM16 frames. The mic
    // worklet's module is already loaded on this context (the mic opened it).
    try { this.aiCapture?.disconnect(); } catch { /* noop */ }
    this.aiCapture = null;
    try {
      const cap = new AudioWorkletNode(this.audioCtx, "mic-capture");
      cap.port.onmessage = (e) => {
        const m = e.data as { type?: string; buffer?: ArrayBuffer };
        if (m.type === "pcm" && m.buffer) this.onAiFrame(m.buffer);
      };
      src.connect(cap);
      this.aiCapture = cap;
    } catch (err) {
      console.warn("[livekit] AI track tap for the avatar unavailable", err);
    }
    registerAnalyser("ai", analyser);
    this.aiRemoteSrc = src;
    this.aiRemoteAnalyser = analyser;
    const data = new Float32Array(analyser.fftSize);
    if (this.aiMeterTimer) clearInterval(this.aiMeterTimer);
    this.aiMeterTimer = setInterval(() => {
      analyser.getFloatTimeDomainData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) sum += data[i] * data[i];
      // ~-40 dBFS: decoded Opus silence sits far below, speech far above.
      if (Math.sqrt(sum / data.length) > 0.01) this.lastAiLoudAt = performance.now();
    }, 40);
  }

  // ── Avatar over LiveKit ──────────────────────────────────────────────────
  private avReset() {
    this.avRun = false;
    this.avFedMs = 0;
    this.avNextAt = 0;
    this.avCur = null;
    this.avQueue = [];
  }

  private avEstimate(text: string): number {
    return Math.max(300, text.length * this.avMsPerChar);
  }

  // The server told us how long an utterance plays: use it for its lip timing
  // (if it hasn't started yet) or to place the next one (if it has), and learn
  // the voice's pace for utterances whose length isn't known in time.
  private avDuration(subId: string, text: string, durMs: number | undefined) {
    if (!this.avatarStream || !durMs || durMs <= 0) return;
    if (text.length >= 20) this.avMsPerChar = 0.8 * this.avMsPerChar + 0.2 * (durMs / text.length);
    const q = this.avQueue.find((u) => u.subId === subId);
    if (q) q.durMs = durMs;
    else if (this.avCur?.subId === subId) this.avNextAt = this.avCur.startMs + durMs;
  }

  // One 20 ms frame of the AI's voice, as the candidate hears it.
  private onAiFrame(buf: ArrayBuffer) {
    const stream = this.avatarStream;
    if (!stream || !this.lkLive) return;
    let sum = 0;
    const v = new Int16Array(buf);
    for (let i = 0; i < v.length; i++) sum += v[i] * v[i];
    // Same ~-40 dBFS line the playback ack uses.
    const loud = Math.sqrt(sum / Math.max(1, v.length)) > 328;
    if (!this.avRun) {
      // A run starts at the first audible frame of an announced utterance;
      // silence before it isn't fed (the avatar would sit "speaking").
      if (!loud || !this.avQueue.length || this.lkPending === 0) return;
      this.avRun = true;
      this.avFedMs = 0;
      this.avNextAt = 0;
    }
    // The next utterance begins here: right where the previous one ends when
    // they run together, else at the first audible frame after it.
    if (loud && this.avQueue.length && this.avFedMs >= this.avNextAt - 120) {
      const u = this.avQueue.shift()!;
      const dur = u.durMs ?? this.avEstimate(u.text);
      try { stream.utterance(u.text, dur); } catch { /* noop */ }
      this.avCur = { subId: u.subId, startMs: this.avFedMs };
      this.avNextAt = this.avFedMs + dur;
    }
    const ms = (buf.byteLength / 2 / 16000) * 1000;  // before feed(): it may transfer buf
    try { stream.feed(buf); } catch { /* noop */ }
    this.avFedMs += ms;
  }

  // LiveKit's active-speaker detection for the AI participant, grounded in the
  // decoded audio the browser is actually playing (post jitter buffer, with
  // smoothing). This is the orb's ONE source of truth for "AVA is speaking".
  // When the track goes quiet we HOLD speaking for a beat (see armAiHold) so a
  // gap between the AI's sentences or separate turns ("Got it." → "Tell me
  // about yourself.") doesn't blink the orb out. No turn-boundary tracking.
  private onLkAgentSpeaking(speaking: boolean) {
    this.lkAgentSpeaking = speaking;
    if (speaking) {
      this.lkAgentLastSpeakAt = performance.now();
      this.clearAiHold();
      this.aiSpeaking = true;
      if (this.snap.turn.state !== "speaking") {
        this.set({ turn: { state: "speaking", label: "AVA is speaking" } });
      }
    } else {
      this.armAiHold();
    }
  }

  // Keep "speaking" alive for a short beat after the AI's track goes quiet, so a
  // gap between sentences/turns doesn't flip the orb. A new active-speaker
  // signal (clearAiHold) cancels it; only sustained quiet actually ends it.
  private armAiHold() {
    if (this.aiHoldTimer) return;
    this.aiHoldTimer = setTimeout(() => {
      this.aiHoldTimer = null;
      if (this.lkAgentSpeaking) return;   // started speaking again — stay
      this.aiSpeaking = false;
      if (this.avRun) { try { this.avatarStream?.end(); } catch { /* noop */ } }
      this.avReset();
      if (this.snap.turn.state === "speaking") {
        this.set({ turn: { state: "listening", label: "" } });
      }
    }, 1200);
  }

  private clearAiHold() {
    if (this.aiHoldTimer) { clearTimeout(this.aiHoldTimer); this.aiHoldTimer = null; }
  }

  // The "finished playing" ack over LiveKit. The server sends audio_end when it
  // has GENERATED the utterance; the voice may still have seconds to play. So
  // wait until the candidate has actually heard it out — the AI's track has
  // gone quiet — then send the same audio_playback_finished the WebSocket path
  // sends. The silence timer and the goodbye hold key off this (v10/v20). This
  // loop ONLY sends the ack; the orb's speaking state is owned by the
  // active-speaker hold above, not by this loop.
  private lkAckAfterPlayout(subId: string) {
    const startAt = this.lkUtterStartAt;
    const endAt = performance.now();
    this.lkAckChain = this.lkAckChain.then(async () => {
      const QUIET_MS = 600;        // per-utterance playout-drain debounce
      const NEVER_HEARD_MS = 2500; // an utterance that never made a sound
      const CAP_MS = 20000;
      let via = "livekit_playout";
      for (;;) {
        if (!this.aiSpeaking) return;  // barge-in cancelled it: no ack
        const now = performance.now();
        // Prefer LiveKit's active-speaker signal (real playout); never call it
        // done while LiveKit still says the agent is speaking. The WebAudio
        // meter is a fallback for when that signal is absent.
        const lastActive = Math.max(this.lastAiLoudAt, this.lkAgentLastSpeakAt);
        const heard = lastActive >= startAt;
        if (heard && !this.lkAgentSpeaking && now - lastActive >= QUIET_MS) break;
        if (!heard && now - endAt >= NEVER_HEARD_MS) { via = "livekit_unheard"; break; }
        if (now - endAt >= CAP_MS) { via = "livekit_cap"; break; }
        await this.sleep(40);
      }
      this.sendControl({
        type: "audio_playback_finished", sub_id: subId,
        grounded: via === "livekit_playout", via,
      });
      this.lkPending = Math.max(0, this.lkPending - 1);
    });
  }

  private kickPlayer() {
    if (this.playerActive) return;
    this.playerActive = true;
    void (async () => {
      try {
        while (this.aiQueue.length > 0) {
          const item = this.aiQueue.shift()!;
          // Caption + transcript track the chunk currently being heard.
          this.set({ caption: item.text });
          if (item.text) this.appendRow("ai", item.text);
          const totalBytes = item.pcm.reduce((s, b) => s + b.byteLength, 0);
          const durMs = (totalBytes / 2 / item.sampleRate) * 1000;
          // Tap the raw AI PCM into the recording mix (captures AI in avatar
          // mode too, where it otherwise plays through the avatar's own ctx).
          this.recordMix(item.pcm, item.sampleRate);
          const amplified = this.amplify(item.pcm, this.volumeGain);
          // Play the utterance, then wait for it to ACTUALLY finish so the ack
          // reflects when the candidate really stopped hearing the AI — the
          // reference the backend's no-response silence timer + VAD gating + the
          // wrap-up hold all key off. `via` records HOW we learned it finished
          // (audited in events.jsonl); `grounded` = a real playback-completion
          // event vs a wall-clock estimate.
          const totalSamples = Math.floor(totalBytes / 2);   // PCM16 mono
          let via = "estimate";
          let waitDone: Promise<void>;
          if (this.audioSink) {
            // Avatar mode. The sink plays the audible audio + lip-sync. If it
            // returns a completion promise (e.g. Azure Avatar's real end event),
            // THAT is the grounded signal. If it returns void (TalkingHead, which
            // exposes none), time completion on a silent shadow buffer through our
            // own AudioContext — audio-clock accurate + jank-immune, no avatar
            // library API needed.
            let sinkDone: Promise<void> | null = null;
            try {
              const r = this.audioSink(amplified, item.text, durMs, item.sampleRate);
              if (r && typeof (r as Promise<void>).then === "function") sinkDone = r as Promise<void>;
            } catch (err) {
              console.error("avatar sink failed", err);
            }
            // AI-source-level glow: TalkingHead's internal graph is opaque (no
            // exposed nodes to splice an analyser into), so this is a parallel
            // silent tap of the identical PCM on the identical schedule — the
            // same approach recordMix already uses for the same problem. Runs
            // independent of sinkDone/shadow timing below, which only govern
            // the completion signal, not the level.
            this.startAiSourceLevelTap(amplified, item.sampleRate);
            if (sinkDone) {
              via = "sink";
              waitDone = Promise.race([sinkDone, this.sleep(durMs + 5000)]);
            } else if (this.audioCtx) {
              via = "avatar_shadow";
              waitDone = Promise.race([
                this.playTimingShadow(totalSamples, item.sampleRate),
                this.sleep(durMs + 5000),
              ]);
            } else {
              waitDone = this.sleep(durMs);
            }
          } else if (this.audioCtx) {
            // Minimal mode: real audible playback; finish on the REAL
            // buffer-ended event (the audio engine, not a stopwatch).
            try {
              const buf = this.toAudioBuffer(amplified, item.sampleRate);
              const src = this.audioCtx.createBufferSource();
              src.buffer = buf;
              // AI-source-level glow: we own this graph outright, so a true
              // in-line pass-through (audio unaffected, analyser just observes).
              const analyser = this.audioCtx.createAnalyser();
              analyser.fftSize = 1024;
              src.connect(analyser);
              analyser.connect(this.audioCtx.destination);
              registerAnalyser("ai", analyser);
              const stopTap = () => {
                try { analyser.disconnect(); } catch { /* noop */ }
                if (unregisterAnalyser("ai", analyser)) resetSource("ai");
                if (this.aiTapStop === stopTap) this.aiTapStop = null;
              };
              this.aiTapStop = stopTap;
              const start = Math.max(this.audioCtx.currentTime, this.playScheduledTail);
              src.start(start);
              this.playScheduledTail = start + buf.duration;
              via = "onended";
              const ended = new Promise<void>((resolve) => { src.onended = () => { stopTap(); resolve(); }; });
              // Safety net: never hang if onended doesn't fire (context suspended
              // / tab backgrounded) — cap the wait at the estimate + a margin.
              waitDone = Promise.race([ended, this.sleep(durMs + 500)]);
            } catch (err) {
              console.error("playback failed", err);
              waitDone = this.sleep(durMs);
            }
          } else {
            waitDone = this.sleep(durMs);
          }

          await waitDone;
          // Barge-in during playback (audio_cancel clears aiSpeaking + the queue):
          // don't ack a cancelled utterance, and stop the loop.
          if (!this.aiSpeaking) break;
          // Tell the server this utterance finished playing on the speaker — the
          // REAL signal the backend uses to start the no-response silence timer
          // and to hold wrap-up teardown until the farewell is done.
          this.sendControl({
            type: "audio_playback_finished",
            sub_id: item.subId,
            grounded: via === "onended" || via === "sink",
            via,
          });
        }
      } finally {
        this.playerActive = false;
        this.aiSpeaking = false;
      }
    })();
  }

  private amplify(chunks: ArrayBuffer[], gain: number): ArrayBuffer[] {
    if (!chunks.length || Math.abs(gain - 1.0) < 0.01) return chunks;
    return chunks.map((b) => {
      const inV = new DataView(b);
      const out = new ArrayBuffer(b.byteLength);
      const outV = new DataView(out);
      for (let i = 0; i < b.byteLength; i += 2) {
        let s = inV.getInt16(i, true) * gain;
        if (s > 32767) s = 32767;
        else if (s < -32768) s = -32768;
        outV.setInt16(i, s | 0, true);
      }
      return out;
    });
  }
  private toAudioBuffer(buffers: ArrayBuffer[], sampleRate: number): AudioBuffer {
    const total = buffers.reduce((s, b) => s + b.byteLength, 0) / 2;
    const buf = this.audioCtx!.createBuffer(1, total, sampleRate);
    const ch = buf.getChannelData(0);
    let off = 0;
    for (const b of buffers) {
      const v = new DataView(b);
      for (let i = 0; i < b.byteLength; i += 2) ch[off++] = v.getInt16(i, true) / 0x8000;
    }
    return buf;
  }

  // ── recording audio mix (mic + AI) ────────────────────────────────────────
  // A WebAudio mix bus so the camera recording's audio track contains both
  // voices. The AI plays through the avatar's OWN AudioContext (avatar mode),
  // so we can't tap a playback node — instead we feed the RAW AI PCM straight
  // into this destination, independent of how it's played to the candidate.
  private recMixDest: MediaStreamAudioDestinationNode | null = null;
  private recMicSource: MediaStreamAudioSourceNode | null = null;
  private recAiTail = 0;
  private buildRecMix(): MediaStreamTrack | null {
    if (!this.audioCtx) return null;
    // Idempotent: the camera AND screen recorders share ONE mix bus + track.
    // Rebuilding would orphan the camera recorder's track (recordMix would feed
    // a new destination), silently dropping AI audio from the camera
    // recording — so return the existing track when the bus is already built.
    if (this.recMixDest) return this.recMixDest.stream.getAudioTracks()[0] || null;
    try {
      this.recMixDest = this.audioCtx.createMediaStreamDestination();
      // Candidate mic → mix. Kept even while "muted" (mute only gates the
      // upstream STT send; the recording should still capture what was said).
      if (this.micStream) {
        this.recMicSource = this.audioCtx.createMediaStreamSource(this.micStream);
        this.recMicSource.connect(this.recMixDest);
      }
      // Over LiveKit the AI arrives as a track, not PCM chunks: mix the track.
      this.aiRemoteSrc?.connect(this.recMixDest);
      this.recAiTail = 0;
      return this.recMixDest.stream.getAudioTracks()[0] || null;
    } catch (err) {
      console.error("record mix init failed", err);
      this.recMixDest = null;
      return null;
    }
  }
  private teardownRecMix() {
    try { this.recMicSource?.disconnect(); } catch { /* noop */ }
    if (this.recMixDest) { try { this.aiRemoteSrc?.disconnect(this.recMixDest); } catch { /* noop */ } }
    this.recMicSource = null;
    this.recMixDest = null;
  }
  // Schedule raw PCM into the recording mix only (never to the speakers — that's
  // the live playback path's job). No-op when not recording.
  private recordMix(chunks: ArrayBuffer[], sampleRate: number) {
    const dest = this.recMixDest;
    if (!dest || !this.audioCtx || !chunks.length) return;
    try {
      const buf = this.toAudioBuffer(chunks, sampleRate);
      const src = this.audioCtx.createBufferSource();
      src.buffer = buf;
      src.connect(dest);
      const start = Math.max(this.audioCtx.currentTime, this.recAiTail);
      src.start(start);
      this.recAiTail = start + buf.duration;
    } catch (err) {
      console.error("record mix failed", err);
    }
  }

  // ── recording (candidate side) ────────────────────────────────────────────
  // Two independent MediaRecorders: "camera" = camera video + mixed audio,
  // "screen" = the shared screen track (when present). Each accumulates blobs
  // and uploads its webm on stop. Idempotent; no-op without MediaRecorder, a
  // token, or any tracks to capture.
  private startRecording = async () => {
    if (!this.snap.recordingEnabled) return;
    if (this.snap.recording) return;
    if (typeof MediaRecorder === "undefined") return;
    let any = false;

    // camera+mic recorder — combine the camera video track with the mic audio
    // track into one MediaStream. (localStream is the possibly-blurred output.)
    const camVideo = this.localStream?.getVideoTracks()[0];
    const micAudio = this.micStream?.getAudioTracks()[0];
    if (camVideo || micAudio) {
      const combined = new MediaStream();
      if (camVideo) combined.addTrack(camVideo);
      // Mix candidate mic + AI TTS into ONE audio track so the recording
      // captures both voices — not just the candidate's own mic. Falls back to the bare mic track if the mix bus can't build.
      const mixTrack = this.buildRecMix();
      if (mixTrack) combined.addTrack(mixTrack);
      else if (micAudio) combined.addTrack(micAudio);
      this.recSeq.camera = 0;
      try {
        const rec = new MediaRecorder(combined, { mimeType: "video/webm" });
        // Stream each chunk to blob as captured (incremental append) so the
        // recording survives a tab close / disconnect mid-interview.
        rec.ondataavailable = (e) => { if (e.data && e.data.size > 0) this.uploadChunk("camera", e.data); };
        rec.start(3000); // ~3s chunks → one append POST each
        this.camRecorder = rec;
        any = true;
      } catch (err) {
        console.error("camera recorder failed", err);
      }
    }

    if (any) this.set({ recording: true });
    // Screen is usually shared LATER (coding round), so also (re)start the
    // screen recorder here in case sharing is already active at record-start.
    this.startScreenRecorder();
  };

  // Start the screen recorder if we're recording AND currently screen-sharing
  // AND not already capturing screen. Called from startRecording and from
  // enableScreen (so a screen shared mid-interview is captured for analytics).
  private startScreenRecorder = () => {
    if (!this.snap.recording || this.screenRecorder) return;
    if (typeof MediaRecorder === "undefined") return;
    const screenVideo = this.localScreenStream?.getVideoTracks()[0];
    if (!screenVideo) return;
    // First recorder creates the blob (seq 0 → overwrite); a re-share after a
    // mid-interview stop keeps the sequence so its chunks APPEND to the existing
    // screen.webm rather than wiping the earlier footage.
    if (!this.screenRecStarted) { this.recSeq.screen = 0; this.screenRecStarted = true; }
    try {
      // Record the shared screen WITH the same mixed audio (candidate mic + AI)
      // the camera recorder uses, so the screen capture carries both voices —
      // not a silent video. buildRecMix() is idempotent, so this reuses
      // the one bus built by the camera path (or builds it if screen records
      // first). The mix bus is a sink only and never touches playback, so this
      // cannot affect what the candidate hears. Falls back to video-only if the
      // mix can't build.
      const screenTracks: MediaStreamTrack[] = [screenVideo];
      const mixTrack = this.buildRecMix();
      if (mixTrack) screenTracks.push(mixTrack);
      const rec = new MediaRecorder(new MediaStream(screenTracks), { mimeType: "video/webm" });
      rec.ondataavailable = (e) => { if (e.data && e.data.size > 0) this.uploadChunk("screen", e.data); };
      rec.start(3000);
      this.screenRecorder = rec;
    } catch (err) {
      console.error("screen recorder failed", err);
    }
  };

  private stopRecording = async () => {
    if (!this.snap.recording) return;
    this.set({ recording: false });
    // stop() flushes a final dataavailable then fires onstop → upload.
    try { this.camRecorder?.stop(); } catch { /* noop */ }
    try { this.screenRecorder?.stop(); } catch { /* noop */ }
    this.camRecorder = null;
    this.screenRecorder = null;
    this.teardownRecMix();
  };

  // Incremental upload: one MediaRecorder chunk per POST, appended in order to
  // the blob. Per-kind seq (seq=0 creates the append blob) + a per-kind promise
  // chain so chunks always append in capture order even if a POST is slow.
  private recSeq: Record<"camera" | "screen", number> = { camera: 0, screen: 0 };
  private recQueue: Record<"camera" | "screen", Promise<void>> = { camera: Promise.resolve(), screen: Promise.resolve() };
  // Which part each track is writing to; the server picks it on seq 0, so a
  // refreshed page starts a NEW part instead of overwriting the earlier one.
  private recPart: Record<"camera" | "screen", number> = { camera: 0, screen: 0 };
  private recInFlight = 0;  // pending chunk uploads → drives the "Saving…" indicator
  private uploadChunk(kind: "camera" | "screen", blob: Blob) {
    const token = this.p.token;
    if (!token) return;
    const seq = this.recSeq[kind]++;
    this.recInFlight++;
    if (!this.snap.savingRecording) this.set({ savingRecording: true });
    this.recQueue[kind] = this.recQueue[kind].then(async () => {
      try {
        const fd = new FormData();
        fd.append("file", blob, `${kind}.webm`);
        // Runs after the previous chunk's POST (the per-kind chain), so seq 0's
        // reply has set recPart before any later chunk reads it.
        const part = seq === 0 ? "new" : String(this.recPart[kind]);
        const r = await fetch(`/api/sessions/${encodeURIComponent(token)}/recording?kind=${kind}&seq=${seq}&part=${part}`,
          { method: "POST", body: fd, credentials: "same-origin" });
        if (seq === 0) {
          const j = (await r.json().catch(() => null)) as { part?: number } | null;
          if (typeof j?.part === "number") this.recPart[kind] = j.part;
        }
      } catch (err) {
        console.error(`recording chunk upload (${kind} seq=${seq}) failed`, err);
      } finally {
        this.recInFlight--;
        if (this.recInFlight === 0) this.set({ savingRecording: false });
      }
    });
  }

  // ── demo loop (no backend; locally verifiable) ────────────────────────────
  private async runDemoLoop() {
    this.set({ conn: { state: "warn", label: "Demo mode (no backend)" } });
    const script = [
      "Welcome to the interview. Let's start with a warm-up question.",
      "Tell me a little about yourself and what brought you here.",
      "Walk me through how you'd design a rate limiter for a public API.",
      "How do you think about trade-offs between consistency and availability?",
    ];
    let i = 0;
    const tick = async () => {
      if (this.snap.screen !== "live" || this.destroyed) return;
      const text = script[i % script.length];
      this.set({ turn: { state: "speaking", label: "AI is speaking" }, caption: "" });
      this.appendRow("ai", text);
      await this.speakDemo(text);
      if (this.snap.screen !== "live" || this.destroyed) return;
      this.set({ turn: { state: "listening", label: "Your turn" } });
      this.appendRow("candidate", "(you would answer here)");
      i++;
      setTimeout(tick, 3500);
    };
    setTimeout(tick, 800);
  }
  private speakDemo(text: string): Promise<void> {
    const words = text.trim().split(/\s+/).filter(Boolean).length;
    const estMs = Math.max(1500, words * 270);
    return new Promise((resolve) => {
      if (window.speechSynthesis) {
        const u = new SpeechSynthesisUtterance(text);
        u.rate = 0.95;
        u.onstart = () => this.set({ caption: text });
        u.onend = () => resolve();
        u.onerror = () => resolve();
        window.speechSynthesis.speak(u);
        setTimeout(resolve, estMs + 800); // safety cap
      } else {
        this.set({ caption: text });
        setTimeout(resolve, estMs);
      }
    });
  }

  private showToast(text: string, ms = 4000) {
    this.set({ toast: text });
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => this.set({ toast: null }), ms);
  }

  endInterview = () => {
    // (A) Flush + upload any in-progress recording before tearing down tracks.
    void this.stopRecording();
    if (this.roomMode && this.lk) {
      // The "end" must reach the server before we leave the room.
      const lk = this.lk;
      void lk.sendControl({ type: "end" }).catch(() => {}).finally(() => void this.leaveLiveKit());
    } else {
      void this.leaveLiveKit();
    }
    try {
      this.stopSink?.();
    } catch {
      /* noop */
    }
    try {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify({ type: "end" }));
    } catch {
      /* noop */
    }
    try {
      this.ws?.close();
    } catch {
      /* noop */
    }
    this.micStream?.getTracks().forEach((t) => t.stop());
    if (this.timer) clearInterval(this.timer);
    this.set({ screen: "done" });
  };

  destroy = () => {
    this.destroyed = true;
    void this.leaveLiveKit();
    try {
      this.ws?.close();
    } catch {
      /* noop */
    }
    try { this.camRecorder?.stop(); } catch { /* noop */ }
    try { this.screenRecorder?.stop(); } catch { /* noop */ }
    this.tearDownBlur();
    this.micStream?.getTracks().forEach((t) => t.stop());
    this.rawCameraStream?.getTracks().forEach((t) => t.stop());
    this.localStream?.getTracks().forEach((t) => t.stop());
    this.localScreenStream?.getTracks().forEach((t) => t.stop());
    this.audioCtx?.close().catch(() => {});
    if (this.timer) clearInterval(this.timer);
    if (this.toastTimer) clearTimeout(this.toastTimer);
    if (this.speakingTimer) clearTimeout(this.speakingTimer);
    if (this.mutedNudgeClearTimer) clearTimeout(this.mutedNudgeClearTimer);
  };
}
