// Auth hooks over the JSON cookie endpoints. The session is an httpOnly
// cookie, so there's nothing to store in JS — we just ask /api/me.
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { postJSON } from "./api";

type Me = { authenticated: boolean; user?: string };

export function useMe() {
  return useQuery<Me>({
    queryKey: ["me"],
    queryFn: async () => {
      const res = await fetch("/api/me", { credentials: "same-origin" });
      if (res.status === 401) return { authenticated: false };
      return (await res.json()) as Me;
    },
    staleTime: 60_000,
  });
}

export function useLogin() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (creds: { username: string; password: string }) =>
      postJSON<{ ok: boolean; user: string }>("/api/login", creds),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["me"] }),
  });
}

export function useLogout() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => postJSON<{ ok: boolean }>("/api/logout", {}),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["me"] }),
  });
}

// ── permissions ─────────────────────────────────────────────────────────────
// The server enforces every permission on every request. This hook exists so
// the UI can HIDE what a person cannot reach — which is convenience, not
// security: a hidden button and a missing permission are different things, and
// only the second one stops anybody.

/** {permission: [team keys]}. A list containing "*" means every team. */
export type Grants = Record<string, string[]>;

export type RoleGrant = {
  role: string;
  role_name: string;
  team: string;
  team_name?: string;
  /** Set when an admin clicked Add. Seeded grants have neither. */
  granted_by_name?: string | null;
  granted_at?: string | null;
};

export type MePermissions = {
  authenticated: boolean;
  /** True for the old shared login: signed in, but not a person we can
   *  authorise, so it holds nothing. */
  legacy?: boolean;
  /** The shared-password login stores a username, not a person. */
  user?: string;
  id?: number;
  email?: string;
  display_name?: string;
  is_active?: boolean;
  roles?: RoleGrant[];
  permissions?: Grants;
};

/** "Question Author · Backend Engineering". A `*` grant reads "every team". */
export function roleLine(role: RoleGrant): string {
  const team = role.team === "*" ? "every team" : (role.team_name || role.team);
  return `${role.role_name} · ${team}`;
}

export function usePermissions() {
  return useQuery<MePermissions>({
    queryKey: ["me", "permissions"],
    queryFn: async () => {
      const res = await fetch("/api/me/permissions", { credentials: "same-origin" });
      if (res.status === 401) return { authenticated: false };
      return (await res.json()) as MePermissions;
    },
    staleTime: 60_000,
  });
}

/** May this person do this, here? `team` omitted asks "anywhere", which is what
 *  a menu item needs; pass a team for a per-pool decision. Mirrors the server's
 *  `has_permission` exactly, including "*" meaning every team. */
export function can(
  me: MePermissions | undefined,
  permission: string,
  team?: string,
): boolean {
  const teams = me?.permissions?.[permission];
  if (!teams || teams.length === 0) return false;
  if (!team) return true;
  return teams.includes(team) || teams.includes("*");
}

/** Every team this person may exercise `permission` on. `["*"]` means all of
 *  them — a caller offering a team picker should expand it. */
export function teamsFor(me: MePermissions | undefined, permission: string): string[] {
  return me?.permissions?.[permission] ?? [];
}

// ── which sign-in methods this deploy offers ────────────────────────────────
// Read before anyone is signed in, so the login page renders what actually
// works here rather than guessing: no app registration, no Microsoft button.

export type AuthMethods = { microsoft: boolean };

export function useAuthMethods() {
  return useQuery<AuthMethods>({
    queryKey: ["auth", "methods"],
    queryFn: async () => {
      const res = await fetch("/api/auth/methods", { credentials: "same-origin" });
      if (!res.ok) return { microsoft: false };
      return (await res.json()) as AuthMethods;
    },
    staleTime: 300_000,
    retry: false,
  });
}
