// textEngine — framework-agnostic store for the CANDIDATE-FACING text interview.
// Mirrors candidateEngine's subscribe/getSnapshot/React-hook shape so the page
// consumes it the same way — but this engine is HTTP-only: NO WebSocket, NO
// mic/camera/audio. It drives the already-built, verified text service
// (app/text_service.py) over four plain same-origin POST/GET calls.
//
// The `state` blob returned by the service is an OPAQUE, HMAC-signed dict. The
// client MUST store it and re-post it verbatim each turn — it is never
// inspected or modified here (the interview's real state lives inside it,
// signed, on the server's terms).

import { getJSON, postJSON, ApiError } from "./api";
import type { TranscriptRow } from "../components/TranscriptView";

export type TextScreen = "lobby" | "live" | "done";

// The signed state blob. Opaque on purpose — never read a field out of it.
export type StateBlob = Record<string, unknown>;

// When the current phase is a one-shot written-response phase, the service
// returns this so the client renders the right material (question / audio clip /
// source passage / image) plus the shared character counter + countdown that
// auto-submits on expiry. null → the normal chat composer.
//
// `limit_kind` says what the shared counter counts: "chars" for anything
// authored with a character limit, "words" for a LEGACY essay phase.
export type QuestionConfig = {
  question_type: string;
  // Which question of the phase this is. `question_id` is the cadence question
  // id — the panel is KEYED on it so each question starts with an empty
  // textarea and its own countdown.
  question_id: string;
  question_index: number;
  question_total: number;
  limit_kind: "chars" | "words";
  limit: number;
  time_limit_s: number | null;
  source_text?: string;              // translation: shown verbatim
  source_language?: string;
  source_language_label?: string;
  target_language?: string;
  target_language_label?: string;
  asset_kind?: "audio" | "image";    // transcription / image description
  asset_url?: string;
};

// The pre-Add-Phase shape, still sent by the service for legacy word-limited
// phases (and all a pre-Add-Phase backend would send). Mapped to a
// QuestionConfig below so the renderer has ONE input shape.
type LegacyEssayConfig = { word_limit: number; time_limit_s: number | null };

function questionFromLegacy(essay?: LegacyEssayConfig | null): QuestionConfig | null {
  if (!essay) return null;
  return {
    question_type: "comprehensive",
    question_id: "legacy_essay",
    question_index: 1,
    question_total: 1,
    limit_kind: "words",
    limit: essay.word_limit,
    time_limit_s: essay.time_limit_s ?? null,
  };
}

export type TextSnapshot = {
  screen: TextScreen;
  name: string;
  role: string;
  durationLabel: string;
  phase: string;          // current cadence phase id (shown subtly)
  started: boolean;       // the interview has an opener (a live state blob exists)
  ended: boolean;         // the AI signalled the interview is over
  sending: boolean;       // a /start or /turn is in flight (guards double-send)
  saving: boolean;        // a /save is in flight
  resumable: boolean;     // a saved/synced state exists → offer "Resume interview"
  rows: TranscriptRow[];  // AI + candidate transcript rows
  count: number;          // turn counter shown in the transcript header
  streaming: string | null; // in-progress AI reply while tokens stream (null when idle)
  question: QuestionConfig | null; // set → render the written-response panel instead of chat
  error: string | null;   // last network error, surfaced to the page (never thrown)
  savedNote: string | null; // confirmation shown after a successful Save
  // Bumped on every successful Save. A timed written response watches this and
  // HOLDS its countdown: "save & finish later" means the candidate is stepping
  // away, so their remaining time must not drain while they're gone. Typing
  // again releases it. A counter (not a boolean) so two saves in a row each
  // re-pause, even if the candidate resumed typing in between.
  savePauseSeq: number;
};

// ── service response shapes ──────────────────────────────────────────────────
type StartResp = {
  ai_text: string;
  phase: string;
  ended: boolean;
  state: StateBlob;
  question?: QuestionConfig | null;
  essay?: LegacyEssayConfig | null;
};
type TurnResp = {
  ai_text: string;
  phase: string;
  ended: boolean;
  transitioned: boolean;
  state: StateBlob;
  question?: QuestionConfig | null;
  essay?: LegacyEssayConfig | null;
};
type SaveResp = { ok: boolean; state: StateBlob };
type DraftResp = {
  question_id: string;
  text?: string;
  remaining_s?: number | null;
  ts?: number | null;
};
type StateResp =
  | { started: false }
  | {
      state: StateBlob;
      transcript: { speaker: string; text: string }[];
      ended?: boolean;
      question?: QuestionConfig | null;
      essay?: LegacyEssayConfig | null;
      draft?: DraftResp | null;
    };

export type TextParams = {
  name: string;
  role: string;
  token: string | null;
};

export function readTextParams(search: string): TextParams {
  const p = new URLSearchParams(search);
  return {
    name: p.get("name") || "Candidate",
    role: p.get("role") || "the role",
    token: p.get("token"),
  };
}

// localStorage keys — the signed blob (so a reopened tab can offer resume) plus
// a display-only cache of the rendered rows (the blob is opaque, so it can't be
// mined for the transcript to redraw).
const BLOB_KEY = (token: string) => `text:state:${token}`;
const ROWS_KEY = (token: string) => `text:rows:${token}`;
// The written-response question on the table, so a reopened tab redraws the
// panel even when the server's synced state is unreachable.
const QUESTION_KEY = (token: string) => `text:question:${token}`;
// Seconds left on a timed written response. Stored as REMAINING (not a deadline)
// on purpose: a closed tab must FREEZE the countdown, not keep draining it —
// "save & finish later" is a pause, so wall-clock elapsed while away is not the
// candidate's time. LEGACY key, still read so an interview that was mid-question
// when this shipped doesn't get its clock reset; new writes go to DRAFT_KEY.
const TIMER_KEY = (token: string) => `text:timer:${token}`;
// The candidate's unsubmitted work on the current written question: the textarea
// contents AND the frozen countdown, together. Written on every keystroke and
// every tick, so a refresh or a browser crash costs nothing. Device-bound by
// nature — the same record is also folded into the SIGNED state blob on an
// explicit Save (see save()), which is what makes it survive a device change.
const DRAFT_KEY = (token: string) => `text:draft:${token}`;

export type QuestionDraft = {
  question_id: string;
  text: string;
  remaining_s: number | null;
  ts: number;
};

function errText(e: unknown): string {
  if (e instanceof ApiError) return e.message;
  if (e instanceof Error) return e.message;
  return "Network error — please check your connection and try again.";
}

// POST a JSON body and consume an NDJSON stream: `{delta}` lines as the AI reply
// generates token-by-token, then a final `{done, ...}` object (returned). Calls
// onDelta per token chunk. A pre-stream HTTP error (401/400/502) or an `{error}`
// line throws ApiError. Same-origin + cookie auth, like the other helpers.
async function streamPost<T>(
  url: string,
  body: unknown,
  onDelta: (chunk: string) => void,
): Promise<T> {
  const res = await fetch(url, {
    method: "POST",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok || !res.body) {
    let detail = `${res.status} ${res.statusText}`;
    try {
      const b = (await res.json()) as { error?: string; detail?: string };
      detail = b?.error || b?.detail || detail;
    } catch {
      /* non-JSON error body */
    }
    throw new ApiError(res.status, detail);
  }
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  let done: T | null = null;
  const handleLine = (line: string) => {
    const s = line.trim();
    if (!s) return;
    const obj = JSON.parse(s) as { delta?: string; error?: string; done?: boolean };
    if (obj.delta != null) onDelta(obj.delta);
    else if (obj.error) throw new ApiError(500, obj.error);
    else if (obj.done) done = obj as unknown as T;
  };
  for (;;) {
    const { value, done: rdone } = await reader.read();
    if (rdone) break;
    buf += decoder.decode(value, { stream: true });
    let nl = buf.indexOf("\n");
    while (nl >= 0) {
      handleLine(buf.slice(0, nl));
      buf = buf.slice(nl + 1);
      nl = buf.indexOf("\n");
    }
  }
  handleLine(buf); // trailing line with no newline
  if (done == null) throw new ApiError(500, "stream ended without a result");
  return done;
}

export class TextEngine {
  private p: TextParams;
  private listeners = new Set<() => void>();
  private snap: TextSnapshot;

  // The opaque signed state blob. Stored + re-posted verbatim; never inspected.
  private blob: StateBlob | null = null;
  private rowSeq = 0;
  // Latest autosaved draft for the question on screen — posted with /save so the
  // server can fold it into the signed blob (Redis + Blob).
  private draft: QuestionDraft | null = null;

  constructor(params: TextParams) {
    this.p = params;
    this.snap = {
      screen: "lobby",
      name: params.name,
      role: params.role,
      durationLabel: "",
      phase: "",
      started: false,
      ended: false,
      sending: false,
      saving: false,
      resumable: false,
      rows: [],
      count: 0,
      streaming: null,
      question: null,
      error: null,
      savedNote: null,
      savePauseSeq: 0,
    };
  }

  // ── external store (identical contract to candidateEngine) ─────────────────
  subscribe = (cb: () => void) => {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  };
  getSnapshot = () => this.snap;
  private set(partial: Partial<TextSnapshot>) {
    this.snap = { ...this.snap, ...partial };
    this.listeners.forEach((l) => l());
  }

  // ── boot ───────────────────────────────────────────────────────────────────
  init = () => {
    void this.loadSessionInfo();
    void this.resume();
  };
  destroy = () => {
    this.listeners.clear();
  };

  private async loadSessionInfo() {
    try {
      const qs = this.p.token ? `?token=${encodeURIComponent(this.p.token)}` : "";
      const data = await getJSON<{ duration_min?: number; role?: string }>(`/session-info${qs}`);
      const mins = Number(data?.duration_min);
      if (Number.isFinite(mins) && mins > 0) {
        this.set({ durationLabel: `~${mins} minute${mins === 1 ? "" : "s"}` });
      }
      // Role is authoritative from the admin-approved cadence/session, not the
      // URL (?role= is only a fallback).
      const role = (data?.role || "").trim();
      if (role) this.set({ role });
    } catch {
      /* keep fallbacks */
    }
  }

  // ── transcript rows ──────────────────────────────────────────────────────────
  private appendRow(role: "ai" | "candidate", text: string) {
    if (!text) return;
    const meta = role === "ai" ? "AI interviewer" : "You";
    this.set({
      rows: this.snap.rows.concat({ id: this.rowSeq++, role, meta, text }),
      count: this.snap.count + 1,
    });
  }
  // Commit the fully-streamed AI reply as a row AND clear the live `streaming`
  // bubble in one update (no flash), applying any extra snapshot fields.
  private commitAiRow(text: string, extra: Partial<TextSnapshot>) {
    const row: TranscriptRow = { id: this.rowSeq++, role: "ai", meta: "AI interviewer", text };
    this.set({
      rows: this.snap.rows.concat(row),
      count: this.snap.count + 1,
      streaming: null,
      ...extra,
    });
  }
  private rowsFromTranscript(transcript: { speaker: string; text: string }[]): TranscriptRow[] {
    return transcript
      .filter((r) => r.speaker === "ai" || r.speaker === "candidate")
      .map((r) => ({
        id: this.rowSeq++,
        role: r.speaker,
        meta: r.speaker === "ai" ? "AI interviewer" : "You",
        text: r.text || "",
      }));
  }

  // ── persistence (blob → localStorage so a reopened tab can resume) ──────────
  private persist() {
    const token = this.p.token;
    if (!token || !this.blob) return;
    try {
      localStorage.setItem(BLOB_KEY(token), JSON.stringify(this.blob));
      localStorage.setItem(ROWS_KEY(token), JSON.stringify(this.snap.rows));
      if (this.snap.question) {
        localStorage.setItem(QUESTION_KEY(token), JSON.stringify(this.snap.question));
      } else {
        localStorage.removeItem(QUESTION_KEY(token));
      }
    } catch {
      /* storage full / disabled — non-fatal, the server store is the source of truth */
    }
  }
  private loadPersistedBlob(): StateBlob | null {
    const token = this.p.token;
    if (!token) return null;
    try {
      const raw = localStorage.getItem(BLOB_KEY(token));
      return raw ? (JSON.parse(raw) as StateBlob) : null;
    } catch {
      return null;
    }
  }
  private loadPersistedQuestion(): QuestionConfig | null {
    const token = this.p.token;
    if (!token) return null;
    try {
      const raw = localStorage.getItem(QUESTION_KEY(token));
      return raw ? (JSON.parse(raw) as QuestionConfig) : null;
    } catch {
      return null;
    }
  }

  // ── in-progress draft: textarea text + frozen countdown, per question ─────
  // Held here rather than in the panel's React state so it survives the panel
  // unmounting: a refresh, a crash, or a resume must all put the candidate back
  // on the same words with the same time left, instead of an empty box and a
  // full allowance. `serverDraft` is what the last Save persisted (Redis+Blob);
  // whichever of the two is fresher wins, so a resume on a NEW device still
  // recovers the work even with nothing in that browser's localStorage.
  private serverDraft: QuestionDraft | null = null;

  private readLocalDraft(): QuestionDraft | null {
    const token = this.p.token;
    if (!token) return null;
    try {
      const raw = localStorage.getItem(DRAFT_KEY(token));
      if (raw) {
        const v = JSON.parse(raw) as QuestionDraft;
        if (v && typeof v.question_id === "string") return v;
      }
      // LEGACY: an interview already mid-question when the draft record shipped
      // only has the old timer key. Honour its clock so it isn't reset.
      const old = localStorage.getItem(TIMER_KEY(token));
      if (old) {
        const v = JSON.parse(old) as { id?: string; remaining?: number };
        if (v && typeof v.id === "string" && typeof v.remaining === "number") {
          return { question_id: v.id, text: "", remaining_s: v.remaining, ts: 0 };
        }
      }
    } catch {
      /* unreadable / disabled storage — fall through to "no draft" */
    }
    return null;
  }

  /** The draft for `questionId`, or null. Scoped to the question it was
   *  recorded for, so the next question in a phase can never inherit the
   *  previous one's text or leftover seconds. */
  loadQuestionDraft = (questionId: string): QuestionDraft | null => {
    const local = this.readLocalDraft();
    const server = this.serverDraft;
    const candidates = [local, server].filter(
      (d): d is QuestionDraft => !!d && d.question_id === questionId,
    );
    if (!candidates.length) return null;
    return candidates.reduce((a, b) => ((b.ts || 0) > (a.ts || 0) ? b : a));
  };

  /** Autosave. Called on every keystroke and every countdown tick. */
  saveQuestionDraft = (questionId: string, text: string, remaining: number | null) => {
    const token = this.p.token;
    if (!token) return;
    const rec: QuestionDraft = {
      question_id: questionId,
      text,
      remaining_s: remaining == null ? null : Math.max(0, Math.floor(remaining)),
      ts: Date.now(),
    };
    this.draft = rec;
    try {
      localStorage.setItem(DRAFT_KEY(token), JSON.stringify(rec));
    } catch {
      /* storage full / disabled — the in-memory copy still reaches /save */
    }
  };

  /** The question is closed (submitted or expired) — drop its draft so it can
   *  never be re-offered against a later question. */
  clearQuestionDraft = () => {
    const token = this.p.token;
    this.draft = null;
    this.serverDraft = null;
    if (!token) return;
    try {
      localStorage.removeItem(DRAFT_KEY(token));
      localStorage.removeItem(TIMER_KEY(token));
    } catch {
      /* nothing to do */
    }
  };

  private loadPersistedRows(): TranscriptRow[] {
    const token = this.p.token;
    if (!token) return [];
    try {
      const raw = localStorage.getItem(ROWS_KEY(token));
      if (!raw) return [];
      const parsed = JSON.parse(raw) as TranscriptRow[];
      // Re-seat the row sequence past the restored rows so new ids don't collide.
      for (const r of parsed) if (r.id >= this.rowSeq) this.rowSeq = r.id + 1;
      return parsed;
    } catch {
      return [];
    }
  }

  // ── start ────────────────────────────────────────────────────────────────────
  // Consent is captured/gated client-side (the no-recording TermsModal); the
  // service's /start takes no body, so the accepted terms are not posted.
  start = async () => {
    if (this.snap.sending || this.snap.started) return;
    if (!this.p.token) {
      this.set({ error: "Missing interview token in the link." });
      return;
    }
    this.set({ sending: true, error: null, screen: "live", streaming: null });
    let acc = "";
    try {
      const data = await streamPost<StartResp>(
        `/text/${encodeURIComponent(this.p.token)}/start`, {},
        (chunk) => { acc += chunk; this.set({ streaming: acc }); },
      );
      this.blob = data.state;
      this.commitAiRow(data.ai_text, {
        phase: data.phase, started: true, ended: false, sending: false,
        question: data.question ?? questionFromLegacy(data.essay),
      });
      this.persist();
    } catch (e) {
      // Fall back to the lobby so the candidate can retry rather than stare at a
      // dead live screen.
      this.set({ sending: false, screen: "lobby", error: errText(e), streaming: null });
    }
  };

  // ── one candidate turn ───────────────────────────────────────────────────────
  // `allowEmpty` is for the ONE caller that legitimately submits nothing: a timed
  // written response whose clock ran out. Running out of time IS the answer, so
  // refusing it would strand the candidate on a dead question — panel locked at
  // 0:00, textarea disabled, interview unable to move on. The chat composer and
  // the manual Submit button still require actual text.
  sendAnswer = async (text: string, opts?: { allowEmpty?: boolean }) => {
    const t = text.trim();
    if (!t && !opts?.allowEmpty) return;
    if (this.snap.sending || this.snap.ended || !this.blob || !this.p.token) return;
    // Optimistic: show the candidate's line immediately.
    this.appendRow("candidate", t);
    this.set({ sending: true, error: null, savedNote: null, streaming: null });
    let acc = "";
    try {
      const data = await streamPost<TurnResp>(
        `/text/${encodeURIComponent(this.p.token)}/turn`,
        { answer: t, state: this.blob },
        (chunk) => { acc += chunk; this.set({ streaming: acc }); },
      );
      this.blob = data.state;
      this.commitAiRow(data.ai_text, {
        phase: data.phase,
        ended: data.ended,
        sending: false,
        screen: data.ended ? "done" : "live",
        question: data.question ?? questionFromLegacy(data.essay),
      });
      this.persist();
    } catch (e) {
      // Keep the optimistic row (their answer isn't lost from view) but surface
      // the failure so they can resend.
      this.set({ sending: false, error: errText(e), streaming: null });
    }
  };

  // ── save & finish later ──────────────────────────────────────────────────────
  save = async () => {
    if (!this.blob || !this.p.token || this.snap.saving) return;
    this.set({ saving: true, error: null, savedNote: null });
    try {
      const data = await postJSON<SaveResp>(`/text/${encodeURIComponent(this.p.token)}/save`, {
        state: this.blob,
        // Makes the unsubmitted work durable: the server merges it into the
        // signed payload, writes Redis AND mirrors to Blob (no TTL), so this is
        // the point after which a resume works on a different device too.
        draft: this.draft,
      });
      this.blob = data.state;
      this.persist();
      this.set({
        saving: false,
        savedNote: "Progress saved. You can close this tab and resume later from the same link.",
        // Holds a timed written response's countdown — see savePauseSeq.
        savePauseSeq: this.snap.savePauseSeq + 1,
      });
    } catch (e) {
      this.set({ saving: false, error: errText(e) });
    }
  };

  // ── resume ───────────────────────────────────────────────────────────────────
  // On load: prefer the server's last SYNCED state (authoritative, carries the
  // transcript); else a localStorage blob (offline/expired-store fallback). Sets
  // `resumable` + stashes the blob/rows; the page shows a "Resume interview"
  // affordance and calls resumeInterview() to enter the live screen.
  resume = async () => {
    if (!this.p.token) return;
    try {
      const data = await getJSON<StateResp>(`/text/${encodeURIComponent(this.p.token)}/state`);
      if ("state" in data) {
        this.blob = data.state;
        const rows = this.rowsFromTranscript(data.transcript || []);
        if (data.ended) {
          // A reopened finished link → straight to Done, don't offer resume.
          this.set({ rows, count: rows.length, ended: true, started: true, screen: "done" });
        } else {
          // The draft the last Save persisted. Kept separate from localStorage
          // so loadQuestionDraft can pick whichever is fresher — this one is
          // the ONLY copy that exists on a device the candidate hasn't used
          // before.
          this.serverDraft = data.draft?.question_id
            ? {
                question_id: data.draft.question_id,
                text: data.draft.text || "",
                remaining_s: data.draft.remaining_s ?? null,
                ts: data.draft.ts ?? 0,
              }
            : null;
          this.set({
            rows, count: rows.length, resumable: true,
            // Without this a resume mid-written-question drops the candidate
            // into the chat composer — no textarea, no limit, no countdown.
            question: data.question ?? questionFromLegacy(data.essay) ?? null,
          });
        }
        this.persist();
        return;
      }
    } catch {
      /* server unreachable / no synced state → try the local fallback */
    }
    const blob = this.loadPersistedBlob();
    if (blob) {
      this.blob = blob;
      const rows = this.loadPersistedRows();
      this.set({
        rows, count: rows.length, resumable: true,
        question: this.loadPersistedQuestion(),
      });
    }
  };

  // Enter the live screen from a resumable state (the stashed blob is already set).
  resumeInterview = () => {
    if (!this.blob) return;
    this.set({ screen: "live", started: true, resumable: false, error: null });
  };

  dismissError = () => this.set({ error: null });
}
