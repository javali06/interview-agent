// LiveKit client for the candidate page.
//
// Audio (Phase 1): the candidate's mic goes up as a published track, the AI's
// voice comes down as a remote track. Control (Phase 2): captions, phases,
// coding/scenario events, the playback ack, start/end travel as JSON through
// the room's reliable data channel — the same shapes the WebSocket carried, so
// the page needs no server address. Camera and screen are NOT published (no
// live video leaves the candidate's browser); they stay local previews + the
// browser recording.
//
// The mic is the SAME MediaStreamTrack the lobby already opened (the level
// meter keeps reading it). It is never stopped from here: if the server falls
// back to the WebSocket, that same track carries the interview.
import {
  Room,
  RoomEvent,
  Track,
  type LocalTrackPublication,
  type Participant,
  type RemoteParticipant,
  type RemoteTrack,
} from "livekit-client";

// Must match engine/orchestrator/livekit/transport.py (CONTROL_TOPIC + chunks).
const CONTROL_TOPIC = "ctl";
const CHUNK_CHARS = 2000;  // ≤ ~12 KB per packet even fully \uXXXX-escaped

export interface LiveKitMediaOpts {
  url: string;
  token: string;
  micTrack: MediaStreamTrack;
  // The AI's voice arrived: `track` is for measuring/recording, `el` plays it.
  onAiTrack?: (track: MediaStreamTrack, el: HTMLAudioElement) => void;
  // One whole control message from the server.
  onControl?: (msg: Record<string, unknown>) => void;
  // The AI participant's live speaking state, from LiveKit's active-speaker
  // detection (grounded in the decoded audio actually being played out, with
  // built-in smoothing) — so the UI tracks AVA's real voice, not generate-time.
  onSpeakingChanged?: (speaking: boolean) => void;
  onReconnecting?: () => void;
  onReconnected?: () => void;
  // The AI's participant left: either the interview ended (a session_end
  // normally arrives first) or its server crashed — the caller decides.
  onAgentLeft?: () => void;
  onDisconnected?: () => void;
  onError?: (where: string, err: unknown) => void;
}

export class LiveKitMedia {
  private room: Room;
  private micPub: LocalTrackPublication | null = null;
  private aiEl: HTMLAudioElement | null = null;

  private chunks = new Map<string, (string | null)[]>();
  private enc = new TextEncoder();
  private dec = new TextDecoder();

  constructor(private opts: LiveKitMediaOpts) {
    this.room = new Room({ adaptiveStream: false, dynacast: false });
    this.room.on(RoomEvent.TrackSubscribed, this.onTrackSubscribed);
    this.room.on(RoomEvent.DataReceived, this.onData);
    this.room.on(RoomEvent.Reconnecting, () => this.opts.onReconnecting?.());
    this.room.on(RoomEvent.Reconnected, () => this.opts.onReconnected?.());
    this.room.on(RoomEvent.ParticipantDisconnected, (p: RemoteParticipant) => {
      if (p.identity === "agent") this.opts.onAgentLeft?.();
    });
    this.room.on(RoomEvent.Disconnected, () => this.opts.onDisconnected?.());
    this.room.on(RoomEvent.ActiveSpeakersChanged, (speakers: Participant[]) => {
      this.opts.onSpeakingChanged?.(speakers.some((p) => p.identity === "agent"));
    });
  }

  /** Send one control message to the AI's server (chunked if large). */
  async sendControl(msg: Record<string, unknown>): Promise<void> {
    const text = JSON.stringify(msg);
    const packets: string[] = [];
    if (text.length <= CHUNK_CHARS) {
      packets.push(text);
    } else {
      const id = Math.random().toString(36).slice(2, 14);
      const n = Math.ceil(text.length / CHUNK_CHARS);
      for (let i = 0; i < n; i++) {
        packets.push(JSON.stringify({ type: "__chunk", id, i, n, d: text.slice(i * CHUNK_CHARS, (i + 1) * CHUNK_CHARS) }));
      }
    }
    for (const p of packets) {
      await this.room.localParticipant.publishData(this.enc.encode(p), { reliable: true, topic: CONTROL_TOPIC });
    }
  }

  private onData = (payload: Uint8Array, participant?: RemoteParticipant, _kind?: unknown, topic?: string): void => {
    if (topic !== CONTROL_TOPIC || participant?.identity !== "agent") return;
    let text = this.dec.decode(payload);
    if (text.slice(0, 32).includes('"__chunk"')) {
      try {
        const c = JSON.parse(text) as { id: string; i: number; n: number; d: string };
        const buf = this.chunks.get(c.id) ?? new Array<string | null>(c.n).fill(null);
        buf[c.i] = c.d;
        this.chunks.set(c.id, buf);
        if (buf.some((x) => x === null)) return;
        this.chunks.delete(c.id);
        text = buf.join("");
      } catch {
        return;
      }
    }
    try {
      this.opts.onControl?.(JSON.parse(text) as Record<string, unknown>);
    } catch {
      /* not JSON — ignore */
    }
  };

  async connect(): Promise<void> {
    await this.room.connect(this.opts.url, this.opts.token);
    // The click on Start already unlocked audio; this covers a browser that
    // still holds remote playback back.
    try { await this.room.startAudio(); } catch { /* retried by the browser on next gesture */ }
    this.micPub = await this.room.localParticipant.publishTrack(this.opts.micTrack, {
      source: Track.Source.Microphone,
      name: "mic",
      // DTX would stop sending during silence; VAD on the server needs the
      // continuous stream to time pauses and endpoints, as over the WebSocket.
      dtx: false,
    });
  }

  /** Mute stops the AI hearing the candidate; the track keeps running locally. */
  async setMicMuted(muted: boolean): Promise<void> {
    try {
      if (muted) await this.micPub?.mute();
      else await this.micPub?.unmute();
    } catch (e) {
      this.opts.onError?.("mic", e);
    }
  }

  setVolume(v: number): void {
    if (this.aiEl) this.aiEl.volume = Math.max(0, Math.min(1, v));
  }

  private onTrackSubscribed = (track: RemoteTrack): void => {
    if (track.kind !== Track.Kind.Audio) return;
    const el = track.attach() as HTMLAudioElement;
    el.autoplay = true;
    // Chrome only feeds a remote WebRTC stream into WebAudio (our playout
    // meter + the recording mix) while it is also playing through a media
    // element — so the element must exist and play, not just the analyser.
    el.style.display = "none";
    document.body.appendChild(el);
    this.aiEl?.remove();
    this.aiEl = el;
    this.opts.onAiTrack?.(track.mediaStreamTrack, el);
  };

  async disconnect(): Promise<void> {
    try {
      this.aiEl?.remove();
      this.aiEl = null;
      // false: leave our mic track running — it's the lobby's, not ours.
      await this.room.disconnect(false);
    } catch (e) {
      this.opts.onError?.("disconnect", e);
    }
  }
}
