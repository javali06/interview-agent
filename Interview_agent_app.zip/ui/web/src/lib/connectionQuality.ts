// Connection-quality monitor for the candidate's live interview screen — the
// "signal bars" indicator mobile OSes and Teams show while a call/session is in
// progress. Ported here rather than per-page: both the voice (candidateEngine)
// and text (textEngine) candidate flows need it, and neither has a natural
// place to own it (the interview brain has no opinion on the browser's network).
//
// PING TARGET: `GET /app/` — the SPA shell route. Deliberately NOT a dedicated
// health endpoint: `/healthz*` only exists on the tiered gateway/text
// containers (deploy/gateway_app.py, deploy/text_app.py), but `/app/` is
// mounted identically in every deploy shape (local single-laptop, the cloud
// single-container azure_app.py, AND the tiered gateway — see CLAUDE.md's
// "Two run modes" + "Tiered scaling deploy" sections; azure_app.py mounts
// app.main's router verbatim, and gateway_app.py imports it directly). So this
// works everywhere with zero backend changes, at the cost of a slightly heavier
// probe (~1KB shell) than a bare 200 — negligible at a 5s interval. The shell is
// served `Cache-Control: no-cache` (see app/main.py _spa), so every probe is a
// REAL round trip, never a browser cache hit.
import { useEffect, useRef, useState } from "react";

export type ConnQualityState = "good" | "fair" | "poor" | "offline" | "reconnecting";

export type ConnQuality = {
  state: ConnQualityState;
  rttMs: number | null;
};

const PING_URL = "/app/";
const PING_INTERVAL_MS = 5000;
const PING_TIMEOUT_MS = 4000;
// Consecutive failed/timed-out pings before we call it "offline" rather than
// "poor" — a single dropped probe is noise (a GC pause, a slow tab), not a
// real outage; the bar shouldn't flap between states on every blip.
const OFFLINE_AFTER_MISSES = 3;

async function pingOnce(): Promise<number | null> {
  const t0 = performance.now();
  const ctrl = new AbortController();
  const to = window.setTimeout(() => ctrl.abort(), PING_TIMEOUT_MS);
  try {
    const res = await fetch(PING_URL, {
      method: "GET",
      cache: "no-store",
      credentials: "omit",   // pure network probe — never sends/needs cookies
      signal: ctrl.signal,
    });
    if (!res.ok) return null;
    return Math.round(performance.now() - t0);
  } catch {
    return null;
  } finally {
    window.clearTimeout(to);
  }
}

function bucket(rttMs: number | null, misses: number): ConnQualityState {
  if (!navigator.onLine || misses >= OFFLINE_AFTER_MISSES) return "offline";
  if (misses > 0 || rttMs == null) return "poor";
  if (rttMs > 600) return "poor";
  if (rttMs > 200) return "fair";
  return "good";
}

/** Polls connectivity/latency for as long as `active` is true. `forcedState`
 *  lets the caller override with a more precise, caller-owned signal — the
 *  voice page passes its own `reconnecting` flag (already tracked by
 *  candidateEngine off the live WS's own drop/retry) so a dead interview
 *  socket shows "Reconnecting…" immediately rather than waiting up to
 *  PING_INTERVAL_MS for the generic probe to notice. rttMs is preserved
 *  across the override so the label doesn't blank out mid-reconnect. */
export function useConnectionQuality(
  active: boolean,
  forcedState?: ConnQualityState | null,
): ConnQuality {
  const [quality, setQuality] = useState<ConnQuality>({ state: "good", rttMs: null });
  const missesRef = useRef(0);

  useEffect(() => {
    if (!active) return;
    let alive = true;

    const runPing = async () => {
      const rtt = await pingOnce();
      if (!alive) return;
      missesRef.current = rtt == null ? missesRef.current + 1 : 0;
      setQuality((prev) => ({
        state: bucket(rtt, missesRef.current),
        rttMs: rtt ?? prev.rttMs,   // keep the last known value through a blip
      }));
    };

    // Immediate first probe (don't make the candidate wait a full interval to
    // see an initial reading), then on a timer — paused while the tab is
    // hidden so a backgrounded interview tab doesn't spend battery/data
    // pinging for no one to see.
    void runPing();
    let intervalId: number | null = null;
    const startInterval = () => {
      if (intervalId != null) return;
      intervalId = window.setInterval(runPing, PING_INTERVAL_MS);
    };
    const stopInterval = () => {
      if (intervalId == null) return;
      window.clearInterval(intervalId);
      intervalId = null;
    };
    startInterval();

    const onVisibility = () => {
      if (document.hidden) stopInterval();
      else {
        void runPing();      // fresh reading immediately on return
        startInterval();
      }
    };
    // Instant offline/online signal between poll ticks — the browser knows the
    // instant its network interface drops, no need to wait for a timed-out probe.
    const onOnline = () => void runPing();
    const onOffline = () => {
      missesRef.current = OFFLINE_AFTER_MISSES;
      setQuality((prev) => ({ state: "offline", rttMs: prev.rttMs }));
    };
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);

    return () => {
      alive = false;
      stopInterval();
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
    };
  }, [active]);

  if (forcedState) return { state: forcedState, rttMs: quality.rttMs };
  return quality;
}
