// Small shared formatting helpers used across console screens.

// "2026-06-12T14:03:55..." → "2026-06-12 14:03:55" (second precision, matching
// the demo1-final Jinja `str[:19].replace('T',' ')`). Returns an em-dash for
// null/empty. We deliberately do NOT parse to a Date: these timestamps are
// stored naive (no tz), so slicing keeps them locale-stable instead of
// shifting by the viewer's UTC offset.
export function fmtTs(ts: string | null | undefined): string {
  if (!ts) return "—";
  return ts.slice(0, 19).replace("T", " ");
}

// Dark-theme .pill variant suffix for a 0..10 score. Use as `pill ${...}`.
export function score10Classes(n: number): string {
  if (n >= 8) return "mag";
  if (n >= 6) return "ok";
  if (n >= 4) return "warn";
  return "danger";
}

// Dark-theme .pill variant suffix for an evaluation band. Use as `pill ${...}`.
export function bandClasses(band: string): string {
  switch (band) {
    case "excellent":
      return "mag";
    case "good":
      return "ok";
    case "avg":
      return "warn";
    default:
      return "danger"; // poor / unknown
  }
}

// Format a phase duration in seconds as "Xh Ym Zs", dropping the hours part
// when it's zero. The leading unit is shown bare; lower units are zero-padded
// to two digits ("1h 02m 00s", "5m 00s", "30s").
export function formatPhaseDuration(seconds: number): string {
  const total = Math.max(0, Math.round(seconds));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  if (h > 0) return `${h}h ${pad(m)}m ${pad(s)}s`;
  if (m > 0) return `${m}m ${pad(s)}s`;
  return `${s}s`;
}
