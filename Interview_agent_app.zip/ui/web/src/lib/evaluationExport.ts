// Renders the evaluation UI FROM the exported document (AB#34151).
//
// The scorecard used to read `evaluation.json.benchmark` — an internal shape
// produced alongside the export, i.e. a second scoring path that could drift
// from the file we hand to customers. It now reads the EXPORT, so the screen
// and the download are the same numbers by construction.
//
// The export deliberately carries no transcript text (see
// docs/eval-export-pii-decision.md): it ships integer `evidence_refs`, not what
// anybody said. The admin view legitimately shows that content, so
// `/api/sessions/{token}/evaluation-view` returns the export VERBATIM plus an
// `evidence` sidecar rebuilt per request and never written to a file. This
// adapter joins the two into the `Benchmark` shape the existing panel and the
// view_id templates already render — so no renderer changes, and no visual
// regression.
import { deleteJSON, getJSON, postJSON } from "./api";
import type {
  AdjustableSpec, BenchPhase, Benchmark, BreakdownItem, EvidenceTurn, PluginResult,
  ReviewSubmission, SegResult, SegReview,
} from "../components/eval-views/types";

/** One section of the exported document — the plugin's own declared payload
 *  plus the envelope every section carries. */
type ExportSection = {
  section: string;
  schema_version: string;
  plugin_id: string;
  segment_id: string;
  phase_id: string;
  question_id: string | null;
  method: string;
  state: string;
  marks_earned: number | null;   // null — never 0 — when not scored
  marks_possible: number | null;
  not_scored_reason: string | null;
  evidence_refs: number[];
  breakdown: BreakdownItem[];
  // A human reviewer's correction, joined in server-side. The fields above are
  // untouched — `marks_earned` stays what the MODEL said and this is what counts.
  review?: SegReview | null;
  [k: string]: unknown;          // the plugin-specific payload
};

export type ExportDocument = {
  report_version: string;
  generated_at: string;
  session: { token: string; role: string; candidate_name: string; modality: string };
  sections: ExportSection[];
  section_schemas: Record<string, {
    title: string; version: string; plugin_id: string;
    // What the plugin declares a reviewer may edit on this section.
    adjustable?: AdjustableSpec;
  }>;
  totals: {
    marks_earned: number; marks_possible: number; pct: number | null;
    segments_total: number; segments_scored: number; segments_not_scored: number;
    by_state: Record<string, number>;
  };
  totals_after_review?: ExportDocument["totals"] | null;
  review_status?: "ai_only" | "human_reviewed";
};

/** In-portal only: the transcript and question material the export excludes. */
export type EvidenceEntry = {
  kind?: string;
  question_text?: string | null;
  difficulty?: string | null;
  turns?: { speaker: string; text: string; event_index: number }[];
};

export type EvaluationView = {
  ok: boolean;
  export: ExportDocument;
  evidence: Record<string, EvidenceEntry>;
};

export const fetchEvaluationView = (token: string) =>
  getJSON<EvaluationView>(`/api/sessions/${encodeURIComponent(token)}/evaluation-view`);

/** Record a human correction to one section. The server returns the merged
 *  document, but the caller refetches rather than patching a local copy — the
 *  screen must keep rendering from the same source the download serves. */
export const saveReview = (token: string, body: ReviewSubmission) =>
  postJSON<{ ok: boolean }>(`/api/sessions/${encodeURIComponent(token)}/review`, body);

/** Retire a section's review; the scorecard falls back to the AI's numbers. */
export const withdrawReview = (token: string, segmentId: string, section: string) =>
  deleteJSON<{ ok: boolean }>(
    `/api/sessions/${encodeURIComponent(token)}/review?segment_id=` +
    `${encodeURIComponent(segmentId)}&section=${encodeURIComponent(section)}`,
  );

// The envelope keys — everything else on a section is the plugin's own payload,
// which is what the view_id template renders.
const ENVELOPE_KEYS = new Set([
  "section", "schema_version", "plugin_id", "segment_id", "phase_id",
  "question_id", "method", "state", "marks_earned", "marks_possible",
  "not_scored_reason", "evidence_refs", "breakdown", "review",
]);

function payloadOf(sec: ExportSection): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(sec)) if (!ENVELOPE_KEYS.has(k)) out[k] = v;
  return out;
}

function phaseTitle(phaseId: string): string {
  return phaseId.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

function toSegResult(sec: ExportSection, ev: EvidenceEntry | undefined,
                     adjustable: AdjustableSpec | undefined): SegResult {
  const cited = new Set(sec.evidence_refs || []);
  const turns: EvidenceTurn[] = (ev?.turns || []).map((t) => ({
    speaker: t.speaker, text: t.text, event_index: t.event_index,
    cited: cited.has(t.event_index),
  }));
  const payload = payloadOf(sec);
  return {
    segment_id: sec.segment_id,
    kind: ev?.kind || "question",
    question_id: sec.question_id,
    question_text: ev?.question_text ?? null,
    difficulty: ev?.difficulty ?? null,
    state: sec.state,
    // The panel's `marks()` helper takes numbers; a non-scored segment renders
    // via its STATE label, so these are never read in that branch. 0 here is a
    // display placeholder, and `state` is what stops it being shown as a score.
    marks_earned: sec.marks_earned ?? 0,
    marks_possible: sec.marks_possible ?? 0,
    rationale: sec.not_scored_reason || (payload.rationale as string) || "",
    breakdown: sec.breakdown || [],
    sub_scores: (payload.dimensions as Record<string, number>) || {},
    grading: payload,
    evidence: turns,
    evidence_refs: sec.evidence_refs || [],
    question_type: null,
    source_text: null,
    audio_url: null,
    image_url: null,
    section: sec.section,
    review: sec.review ?? null,
    adjustable: adjustable ?? null,
  };
}

/** What a section is worth once a human has had their say: the reviewed value
 *  when one exists, the model's otherwise. Used for every sum on this screen,
 *  so a phase tile and the grand total agree with the card above them. */
function effective(sec: ExportSection): { earned: number; possible: number; scored: boolean } {
  const r = sec.review;
  const state = r?.final_state ?? sec.state;
  if (state !== "scored") return { earned: 0, possible: 0, scored: false };
  const earned = r?.final_marks_earned ?? sec.marks_earned ?? 0;
  const possible = r?.final_marks_possible ?? sec.marks_possible ?? 0;
  return { earned, possible, scored: true };
}

/** Export + evidence → the shape BenchmarkPanel and the view_id templates
 *  already render. Sections keep their interview order within each phase. */
export function benchmarkFromExport(view: EvaluationView): Benchmark {
  const doc = view.export;
  const byPhase = new Map<string, Map<string, ExportSection[]>>();
  for (const sec of doc.sections) {
    if (!byPhase.has(sec.phase_id)) byPhase.set(sec.phase_id, new Map());
    const plugins = byPhase.get(sec.phase_id)!;
    if (!plugins.has(sec.plugin_id)) plugins.set(sec.plugin_id, []);
    plugins.get(sec.plugin_id)!.push(sec);
  }

  const phases: BenchPhase[] = [];
  for (const [phaseId, plugins] of byPhase) {
    const results: PluginResult[] = [];
    let earned = 0, possible = 0;
    for (const [pluginId, secs] of plugins) {
      const segments = secs.map((s) => toSegResult(
        s, view.evidence[s.segment_id], doc.section_schemas[s.section]?.adjustable));
      const scored = secs.filter((s) => effective(s).scored);
      const pe = scored.reduce((a, s) => a + effective(s).earned, 0);
      const pp = scored.reduce((a, s) => a + effective(s).possible, 0);
      earned += pe; possible += pp;
      const difficulty_counts: Record<string, number> = {};
      for (const seg of segments) {
        if (seg.difficulty) difficulty_counts[seg.difficulty] = (difficulty_counts[seg.difficulty] || 0) + 1;
      }
      results.push({
        plugin_id: pluginId,
        // The section key IS the view_id: the plugin declares one identity for
        // both the exported section and the template that renders it.
        view_id: secs[0].section,
        config_used: {},
        summary: {
          total_questions: segments.length,
          scored_count: scored.length,
          marks_earned: Math.round(pe * 100) / 100,
          marks_possible: Math.round(pp * 100) / 100,
          difficulty_counts,
        },
        segments,
      });
    }
    phases.push({
      phase_id: phaseId,
      name: phaseTitle(phaseId),
      marks_earned: Math.round(earned * 100) / 100,
      marks_possible: Math.round(possible * 100) / 100,
      results,
    });
  }

  return {
    schema: `export/${doc.report_version}`,
    model: "",
    generated_at: doc.generated_at,
    plan_used: true,
    plan_fingerprint: "",
    // Straight from the document — the screen shows the file's own totals. When
    // a human has adjusted anything, the headline becomes the reviewed total and
    // the AI's own stays beside it, because both are true and only one is final.
    total: {
      marks_earned: (doc.totals_after_review ?? doc.totals).marks_earned,
      marks_possible: (doc.totals_after_review ?? doc.totals).marks_possible,
      pct: (doc.totals_after_review ?? doc.totals).pct ?? 0,
    },
    total_ai_only: doc.totals_after_review
      ? {
          marks_earned: doc.totals.marks_earned,
          marks_possible: doc.totals.marks_possible,
          pct: doc.totals.pct ?? 0,
        }
      : null,
    phases,
    dimensions: {},
    coding_quality: [],
  };
}
