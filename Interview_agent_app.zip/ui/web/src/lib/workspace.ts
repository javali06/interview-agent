// One list of workspace pages. The sidebar, the Welcome cards and the route
// guard all read it, so a new page is one entry here rather than three edits
// that can drift apart.
//
// The shared password login is not a person in the role tables. It keeps the
// pages it already opens, and it does not see Access, which is new and which
// the server would refuse.
import { can, type MePermissions } from "./auth";

export type WorkspaceItem = {
  to: string;
  label: string;
  icon: string;
  /** Show the item when the person holds any one of these, on any team. */
  anyOf: string[];
  home?: { num: string; title: string; desc: string; icon: string };
};

export const WORKSPACE: WorkspaceItem[] = [
  {
    to: "/shortlist",
    label: "Shortlist",
    icon: "users",
    anyOf: ["interviews.view"],
    home: {
      num: "01",
      title: "Shortlist",
      desc: "Match resumes to a role and rank the best-fit candidates.",
      icon: "users",
    },
  },
  {
    to: "/dashboard",
    label: "Dashboard",
    icon: "grid",
    anyOf: ["interviews.view"],
    home: {
      num: "02",
      title: "AI Interview",
      desc: "Run AI-led screening interviews and review scored results.",
      icon: "mic",
    },
  },
  {
    to: "/schedule",
    label: "New interview",
    icon: "calendar",
    anyOf: ["interviews.schedule"],
  },
  {
    to: "/question-pools",
    label: "Question pools",
    icon: "notes",
    anyOf: ["pools.view"],
    home: {
      num: "03",
      title: "Question Pools",
      desc: "Build your own bank of interview questions for any role.",
      icon: "notes",
    },
  },
  {
    to: "/access",
    label: "Access",
    icon: "settings",
    anyOf: ["admin.users", "admin.teams", "admin.permissions"],
    home: {
      num: "04",
      title: "Access",
      desc: "Assign roles and teams.",
      icon: "settings",
    },
  },
];

/** May this person open a page that asks for any of `anyOf`? */
export function allowed(me: MePermissions | undefined, anyOf: string[]): boolean {
  if (!me?.authenticated) return false;
  if (me.legacy) return anyOf.every((p) => !p.startsWith("admin."));
  return anyOf.some((p) => can(me, p));
}

export function visibleWorkspace(me: MePermissions | undefined): WorkspaceItem[] {
  return WORKSPACE.filter((item) => allowed(me, item.anyOf));
}
