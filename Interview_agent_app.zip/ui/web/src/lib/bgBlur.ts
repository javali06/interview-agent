// Background blur for the candidate camera. Runs the raw camera MediaStream
// through MediaPipe Selfie Segmentation (loaded from a CDN ESM at runtime —
// it's a large WASM model, not worth bundling and only needed when the
// candidate opts in) and composites a gaussian-blurred background behind the
// segmented person onto an offscreen <canvas>. The canvas's captureStream() is
// returned as a drop-in replacement video track.
//
// WHY a separate module + dynamic import: mirrors talkingHead.ts — keep the
// heavy CDN dependency out of the main bundle and degrade gracefully (return
// null) so a load/segmentation failure just falls back to the raw camera.

// MediaPipe tasks-vision ESM bundle (same CDN style as talkingHead.ts).
const TASKS_VISION_MODULE =
  "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.8";
// WASM + model assets the ImageSegmenter needs at runtime.
const WASM_ROOT =
  "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.8/wasm";
const SELFIE_MODEL =
  "https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_segmenter/float16/latest/selfie_segmenter.tflite";

// Minimal structural types for the bits of tasks-vision we touch (the CDN
// module is untyped here). Kept loose on purpose.
type FilesetResolver = {
  forVisionTasks: (wasmRoot: string) => Promise<unknown>;
};
type SegmentationResult = {
  categoryMask?: { getAsFloat32Array: () => Float32Array; close: () => void };
  close?: () => void;
};
type ImageSegmenter = {
  segmentForVideo: (video: HTMLVideoElement, ts: number) => SegmentationResult;
  close: () => void;
};
type ImageSegmenterCtor = {
  createFromOptions: (fileset: unknown, opts: Record<string, unknown>) => Promise<ImageSegmenter>;
};

export async function applyBlur(
  input: MediaStream,
): Promise<{ stream: MediaStream; stop: () => void } | null> {
  try {
    const mod = (await import(/* @vite-ignore */ TASKS_VISION_MODULE)) as {
      FilesetResolver: FilesetResolver;
      ImageSegmenter: ImageSegmenterCtor;
    };
    const vision = await mod.FilesetResolver.forVisionTasks(WASM_ROOT);
    const segmenter = await mod.ImageSegmenter.createFromOptions(vision, {
      baseOptions: { modelAssetPath: SELFIE_MODEL, delegate: "GPU" },
      runningMode: "VIDEO",
      outputCategoryMask: true,
      outputConfidenceMasks: false,
    });

    // Feed the raw camera into a hidden <video> so we can pull frames + pass
    // them to the segmenter and draw them to the output canvas.
    const video = document.createElement("video");
    video.muted = true;
    video.playsInline = true;
    video.srcObject = input;
    await video.play();

    // Wait for real dimensions (videoWidth is 0 until the first frame).
    if (!video.videoWidth) {
      await new Promise<void>((resolve) => {
        video.onloadedmetadata = () => resolve();
        // Safety cap so a never-loading video doesn't hang the lobby.
        setTimeout(resolve, 2000);
      });
    }
    const w = video.videoWidth || 480;
    const h = video.videoHeight || 360;

    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      segmenter.close();
      return null;
    }

    let running = true;
    let raf = 0;

    // Per-frame composite: blurred full frame as background, then the sharp
    // person punched back in via the segmentation mask.
    const render = () => {
      if (!running) return;
      raf = requestAnimationFrame(render);
      if (!video.videoWidth) return;
      let result: SegmentationResult | null = null;
      try {
        result = segmenter.segmentForVideo(video, performance.now());
      } catch {
        // Transient segmentation failure — just draw the raw frame this tick.
        ctx.filter = "none";
        ctx.drawImage(video, 0, 0, w, h);
        return;
      }
      const mask = result?.categoryMask?.getAsFloat32Array();
      if (!mask) {
        ctx.filter = "none";
        ctx.drawImage(video, 0, 0, w, h);
        result?.categoryMask?.close?.();
        result?.close?.();
        return;
      }

      // 1) Blurred background fills the canvas.
      ctx.filter = "blur(12px)";
      ctx.drawImage(video, 0, 0, w, h);
      ctx.filter = "none";

      // 2) Snapshot the blurred bg, draw the sharp frame over it, then per-pixel
      //    restore the blurred value wherever the mask says "background". (Pixel
      //    blend beats compositing tricks here — it's simple and fast enough at
      //    480x360.) selfie_segmenter: mask ~0 → person, ~1 → background.
      const blurred = ctx.getImageData(0, 0, w, h).data;
      ctx.drawImage(video, 0, 0, w, h);
      const sharpFrame = ctx.getImageData(0, 0, w, h);
      const sd = sharpFrame.data;
      for (let i = 0; i < mask.length; i++) {
        if (mask[i] > 0.5) {
          const p = i * 4;
          sd[p] = blurred[p];
          sd[p + 1] = blurred[p + 1];
          sd[p + 2] = blurred[p + 2];
          sd[p + 3] = blurred[p + 3];
        }
      }
      ctx.putImageData(sharpFrame, 0, 0);

      result?.categoryMask?.close?.();
      result?.close?.();
    };
    render();

    // captureStream gives us a MediaStream backed by the canvas — drop-in for
    // the raw camera track.
    const stream = (canvas as HTMLCanvasElement & {
      captureStream: (fps?: number) => MediaStream;
    }).captureStream(15);

    const stop = () => {
      running = false;
      if (raf) cancelAnimationFrame(raf);
      try { segmenter.close(); } catch { /* noop */ }
      try { video.srcObject = null; } catch { /* noop */ }
      stream.getTracks().forEach((t) => t.stop());
    };

    return { stream, stop };
  } catch (err) {
    console.error("background blur unavailable", err);
    return null;
  }
}
