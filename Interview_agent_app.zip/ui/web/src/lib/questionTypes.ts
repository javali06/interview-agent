// Question-type catalog for written-response phases, FETCHED from the backend
// (`GET /api/cadence/question-types` → engine/brain/cadence/question_types.py).
//
// WHY fetched and not a TS constant: the same table drives the schema
// validation, the YAML builder, this authoring form, and the candidate
// renderer. Duplicating the list here is exactly how the two sides drift, so a
// new question type is ONE Python entry (plus a renderer below only if it needs
// a genuinely new widget kind).

import { getJSON } from "./api";

// Renderer key for a type-specific field. Also what the backend validates on.
// "string_list" → an add/remove row list of plain strings (e.g. ground_truth
// for translation/image_description).
export type FieldKind = "text" | "long_text" | "language" | "asset_audio" | "asset_image" | "string_list";

// Where a field is authored: "phase" = once for the whole phase (the language
// pair), "question" = per question (the material). Mirrors FieldSpec.scope in
// engine/brain/cadence/question_types.py.
export type FieldScope = "phase" | "question";

export type QuestionField = {
  name: string;
  kind: FieldKind;
  label: string;
  required: boolean;
  // UI-only requiredness (Save is blocked without it) that does NOT hard-fail
  // the backend schema — for a field added after questions of this type
  // already existed, so old unedited questions keep validating. Effective UI
  // requiredness is `required || ui_required`. Mirrors FieldSpec.ui_required.
  ui_required: boolean;
  help: string;
  scope: FieldScope;
  asset_kind?: "audio" | "image";  // upload fields only
};

// A field's authored value: a plain string, or a string[] for "string_list".
export type FieldValue = string | string[];

export type QuestionTypeSpec = {
  id: string;
  label: string;
  description: string;
  prompt_label: string;
  prompt_required: boolean;
  prompt_placeholder: string;
  // True → this type's instruction is never hand-written; the backend
  // synthesises it from the question's language pair, so render no field.
  prompt_hidden: boolean;
  // This type's default phase id (used as the fallback when a typed name
  // doesn't produce a usable slug) — lets the Add-Phase form preview whether
  // it's about to land on an already-existing phase, before saving.
  slug: string;
  fields: QuestionField[];
};

export type AssetRule = { extensions: string[]; max_bytes: number };

export type QuestionTypeCatalog = {
  default_question_type: string;
  question_types: QuestionTypeSpec[];
  languages: { code: string; label: string }[];
  asset_rules: Record<string, AssetRule>;
};

export const fetchQuestionTypeCatalog = () =>
  getJSON<QuestionTypeCatalog>("/api/cadence/question-types");

// ── shared client-side validation ──────────────────────────────────────────
// Mirrors the backend's rules so the admin gets an inline message instead of a
// round-trip; the BACKEND remains authoritative (it re-checks everything).

/** An upload the admin picked, checked against the same rule the server uses.
 *  Returns an error message, or null when acceptable. */
export function checkAssetFile(rule: AssetRule | undefined, file: File): string | null {
  if (!rule) return "Unsupported file type.";
  const name = file.name.toLowerCase();
  if (!rule.extensions.some((ext) => name.endsWith(ext))) {
    return `Must be one of: ${rule.extensions.join(", ")}`;
  }
  if (file.size <= 0) return "The file is empty.";
  if (file.size > rule.max_bytes) {
    return `Must be at most ${Math.round(rule.max_bytes / (1024 * 1024))} MB`;
  }
  return null;
}

export const phaseFields = (spec: QuestionTypeSpec) => spec.fields.filter((f) => f.scope === "phase");
export const questionFields = (spec: QuestionTypeSpec) => spec.fields.filter((f) => f.scope === "question");

/** One authored question: its prompt, its material (keyed by the type's
 *  question-scoped field names), its character limit and its countdown. `id` is
 *  set only for a question that already exists in the cadence — echoing it back
 *  keeps its id (and therefore its eval/event references) stable across an edit.
 *  `key` is a client-only React key, never sent. */
export type DraftQuestion = {
  key: string;
  id?: string;
  prompt: string;
  /** The limit VALUE as typed. Its unit is `limitKind` — "chars" for anything
   *  authored now, "words" only for a legacy essay question being edited (so
   *  editing it can't silently reinterpret 300 words as 300 characters). */
  charLimit: string;
  limitKind: "chars" | "words";
  timed: boolean;
  timeLimitMin: string;
  /** Type-specific material, keyed by the type's question-scoped field names.
   *  A "string_list" field's value is a string[]; every other kind is a string. */
  values: Record<string, FieldValue>;
  /** Preview URLs for uploaded assets, keyed the same way (client-only). */
  previews: Record<string, string>;
};

/** Whether a field's authored value is empty — string_list-aware (an empty, or
 *  all-whitespace, list counts as unset, same as a blank string). */
function isFieldValueBlank(kind: FieldKind, value: FieldValue | undefined): boolean {
  if (kind === "string_list") {
    return !(Array.isArray(value) ? value : []).some((s) => s.trim());
  }
  return !String(value ?? "").trim();
}

/** Missing required inputs for the whole phase, as admin-facing labels. Mirrors
 *  the backend's rules (which stay authoritative) so the form can point at the
 *  exact question card that's incomplete. */
export function missingFields(
  spec: QuestionTypeSpec,
  phaseValues: Record<string, string>,
  questions: DraftQuestion[],
): string[] {
  const missing: string[] = [];
  for (const f of phaseFields(spec)) {
    if ((f.required || f.ui_required) && !(phaseValues[f.name] || "").trim()) missing.push(f.label);
  }
  if (!questions.length) missing.push("at least one question");
  questions.forEach((q, i) => {
    const where = `Question ${i + 1}`;
    if (spec.prompt_required && !q.prompt.trim()) missing.push(`${where}: ${spec.prompt_label}`);
    for (const f of questionFields(spec)) {
      if ((f.required || f.ui_required) && isFieldValueBlank(f.kind, q.values[f.name])) {
        missing.push(`${where}: ${f.label}`);
      }
    }
    if (!(Math.round(Number(q.charLimit)) > 0)) missing.push(`${where}: character limit`);
    if (q.timed && !(Math.round(Number(q.timeLimitMin)) > 0)) missing.push(`${where}: time limit`);
  });
  return missing;
}
