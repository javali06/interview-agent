// Client for the user-authored question pools (`/api/question-pools`).
//
// A pool is a reusable bank of interview questions the admin types by hand —
// NO LLM anywhere in this flow. The stored YAML is the same shape as the pools
// shipped in the image, so a pool authored here is injected into a cadence by
// the very same "Apply to cadence" customizer, addressed by `pool_file`.
import { deleteJSON, getJSON, postJSON, putJSON } from "./api";

export const DIFFICULTIES = ["easy", "medium", "hard"] as const;
export type Difficulty = (typeof DIFFICULTIES)[number];

/** The per-question material a WRITTEN pool carries — same shape the cadence
 *  stores, so a pooled question drops into a phase with no conversion. */
export type WrittenBlock = {
  char_limit?: number;
  word_limit?: number;
  time_limit_s?: number | null;
  source_text?: string;
  audio_asset?: string;
  image_asset?: string;
  source_language?: string;
  target_language?: string;
  /** Reference answer(s) for automated scoring. A LIST for translation and
   *  image description, a single string for transcription — the schema is
   *  strict about which, so the editor must render the right control. */
  ground_truth?: string | string[];
};

/** One test case for a coding question. `input` and `expected` are PYTHON
 *  SOURCE strings — the browser runner evals `fn(<input>)` and compares
 *  `repr(result)` to `expected`, the same contract the built-in library uses. */
export type CodingTestCase = { name: string; input: string; expected: string };

/** The material a CODING question carries. Mirrors the built-in coding library
 *  entry, so a pooled question drops into a phase with no conversion. */
export type CodingBlock = {
  language?: string;
  /** Human-readable name — what the picker lists and the candidate's tab shows. */
  title?: string;
  starter_code?: string;
  function_name?: string;
  test_cases?: CodingTestCase[];
  solution?: string;
  hints?: string[];
  estimated_time_s?: number;
  /** A LIST, like the library's `topic:` — the coding picker filters on these. */
  topics?: string[];
  role_fit?: string[];
};

/** An uploaded scenario media asset — the same shape the cadence schema's
 *  ScenarioMedia uses, so a pooled question's reference drops into a phase
 *  with no conversion. */
export type ScenarioMedia = {
  kind: "image" | "video" | "audio";
  ref: string;
  filename: string;
  mime_type: string;
};

/** The material a Visual Scenario Analysis question carries: the media
 *  reference + follow-up cap. `question` text and `coverage_tags` live on the
 *  envelope (PoolQuestion.text / .coverage_tags), like coding's topics live on
 *  its own block while text stays on the envelope. */
export type ScenarioBlock = {
  media?: ScenarioMedia | null;
  max_followups?: number;
};

export type PoolQuestion = {
  id?: string;
  /** Per QUESTION, not per pool — one pool can mix spoken, comprehension,
   *  translation… A phase then pulls only the kind it can use. */
  kind: string;
  text: string;
  topic: string;
  difficulty: Difficulty;
  coverage_tags: string[];
  written_response?: WrittenBlock | null;
  /** Only on a coding question. */
  coding?: CodingBlock | null;
  /** Only on a Visual Scenario Analysis question. */
  scenario?: ScenarioBlock | null;
};

/** One kind of question a pool can hold. Fetched from the backend rather than
 *  listed here, so a NEW question type (MCQ, say) is one entry in
 *  question_types.py and this form renders it with no TypeScript change. */
export type PoolKind = {
  id: string;
  label: string;
  description: string;
  written: boolean;
  prompt_label: string;
  prompt_required: boolean;
  prompt_hidden?: boolean;
  prompt_placeholder?: string;
  /** Which block on the question this kind's `fields` read and write:
   *  "written_response", "coding", or "" for a kind with no material at all.
   *  Sent by the backend so the form never hardcodes a block name. */
  block?: string;
  fields: {
    name: string;
    kind: "text" | "long_text" | "language" | "asset_audio" | "asset_image"
        | "string_list" | "code" | "test_cases" | "chips" | "duration"
        | "asset_media" | "count";
    label: string;
    required: boolean;
    /** Stricter than `required`: the schema tolerates a missing ground truth,
     *  the authoring form does not (without it the answer can't be scored). */
    ui_required?: boolean;
    help: string;
    asset_kind?: "audio" | "image";
    /** Syntax for a "code" field (python today). */
    language?: string;
    /** The allowed values for a "chips" multi-select (a curated vocabulary —
     *  the backend refuses anything off-list). */
    options?: string[];
  }[];
};

export const SPOKEN_KIND = "spoken";
export const CODING_KIND = "coding";
export const SCENARIO_KIND = "scenario";

export const listKinds = () =>
  getJSON<{ kinds: PoolKind[]; languages: { code: string; label: string }[] }>(
    "/api/question-pools/kinds");

/** Upload a clip/image for a written question. NOT scoped to a pool — the file
 *  must be attachable while the pool is still being composed and has no id, the
 *  same way Add Phase lets you upload straight away. */
export async function uploadPoolAsset(
  kind: "audio" | "image" | "video", file: File,
): Promise<{ name: string; url: string }> {
  const form = new FormData();
  form.append("file", file);
  const res = await fetch(
    `/api/question-pools/assets?kind=${kind}`,
    { method: "POST", credentials: "same-origin", body: form });
  if (!res.ok) {
    let detail = `${res.status} ${res.statusText}`;
    try { detail = (await res.json())?.detail || detail; } catch { /* non-JSON */ }
    throw new Error(detail);
  }
  return res.json();
}

/** List-view metadata. `counts` is the topic × difficulty matrix — the same
 *  thing the cadence customizer filters on, so it predicts whether a request
 *  like "5 hard questions on X" can actually be filled. */
export type PoolSummary = {
  pool_id: string;
  pool_file: string;          // what /customize is handed
  pool_name: string;
  description: string;
  pool_kind: string;
  /** What the pool actually holds — used to offer it only to phases whose type
   *  it can supply. */
  kinds: string[];
  question_count: number;
  topics: string[];
  counts: Record<string, Record<Difficulty, number>>;
  updated_at: string;
  source: "builtin" | "custom" | "draft";
  editable: boolean;
  /** Which team owns it, and therefore who reviews it. "*" = every team. */
  team?: string;
  created_by?: string;
  updated_by?: string;
  /** Where the FILE is: a draft is invisible to interviews, published is live. */
  state?: "draft" | "published";
  /** Where the APPROVAL stands. Distinct from `state` on purpose: a pool can be
   *  published AND have a new draft pending behind it. */
  workflow?: WorkflowState;
  next_step?: ChainStep | null;
  /** True when a draft is waiting behind the published version AND this person
   *  is allowed to see it. */
  has_draft?: boolean;
  /** Who opened the open cycle. Sent with the LIST so the row can decide
   *  whether to offer Approve without a second request per pool. */
  submitted_by?: number | null;
  steps?: ChainStep[];
};

/** Where a pool stands in the approval chain. Derived server-side from the
 *  append-only ledger, never stored — so it cannot disagree with the history. */
export type WorkflowState = "draft" | "pending" | "published";

export type ChainStep = { step_no: number; role: string; name: string };

export type PoolStatus = {
  state: WorkflowState;
  cycle_id: string | null;
  team: string | null;
  steps: ChainStep[];
  signed: { step_no: number; by: number; by_email: string; at: string | null }[];
  next_step: ChainStep | null;
  submitted_by: number | null;
  last_comment: string;
};

export type HistoryEntry = {
  action: "submitted" | "approved" | "returned" | "published" | "withdrawn";
  step_no: number | null;
  cycle_id: string;
  actor: string;
  actor_id: number | null;
  comment: string;
  at: string | null;
};

export type QueueItem = {
  pool_id: string;
  pool_name: string;
  question_count: number;
  team: string | null;
  step: ChainStep;
  submitted_by: string;
  cycle_id: string;
};

export type PoolDetail = PoolSummary & {
  questions: PoolQuestion[];
  last_comment?: string;
  has_published?: boolean;
};

export const listPools = () =>
  getJSON<{ pools: PoolSummary[] }>("/api/question-pools");

export const getPool = (poolId: string) =>
  getJSON<PoolDetail>(`/api/question-pools/${encodeURIComponent(poolId)}`);

export type PoolBody = {
  pool_name: string;
  description: string;
  pool_kind: string;
  questions: PoolQuestion[];
  /** Blank means "*" (every team) — the state of a pool nobody has assigned. */
  team?: string;
};

export const createPool = (body: PoolBody) =>
  postJSON<PoolSummary & { ok: boolean }>("/api/question-pools", body);

export const updatePool = (poolId: string, body: PoolBody) =>
  putJSON<PoolSummary & { ok: boolean }>(
    `/api/question-pools/${encodeURIComponent(poolId)}`, body);

export const deletePool = (poolId: string) =>
  deleteJSON<{ ok: boolean }>(`/api/question-pools/${encodeURIComponent(poolId)}`);

/** Copy a pool into a new, editable one. `source` is a custom pool id OR a
 *  built-in filename — duplicating is the only way to edit shipped content,
 *  since those files live in the image and an edit would vanish on redeploy. */
export const duplicatePool = (source: string, poolName?: string) =>
  postJSON<PoolSummary & { ok: boolean }>("/api/question-pools/duplicate", {
    source, pool_name: poolName,
  });

/** Where an uploaded pool asset can be previewed. */
export const poolAssetUrl = (name: string) =>
  `/api/question-pools/assets/${encodeURIComponent(name)}`;

export const exportPoolUrl = (poolId: string) =>
  `/api/question-pools/${encodeURIComponent(poolId)}/export`;

// ── maker–checker ───────────────────────────────────────────────────────────
// Saving a pool writes a DRAFT. Interviews read only published pools, so
// nothing an author types reaches a candidate until somebody else approves it.
// The server enforces every rule below; these calls just surface them.

const poolPath = (poolId: string, action: string) =>
  `/api/question-pools/${encodeURIComponent(poolId)}/${action}`;

/** Send a draft for approval. */
export const submitPool = (poolId: string, comment = "") =>
  postJSON<{ ok: boolean; status: PoolStatus }>(poolPath(poolId, "submit"), { comment });

/** Sign the next step. `published` is true when that was the last one. */
export const approvePool = (poolId: string, comment = "") =>
  postJSON<{ ok: boolean; status: PoolStatus; published: boolean }>(
    poolPath(poolId, "approve"), { comment });

/** Send it back to the author. The comment is REQUIRED — the server refuses a
 *  blank one, because a rejection nobody can act on wastes the round trip. */
export const returnPool = (poolId: string, comment: string) =>
  postJSON<{ ok: boolean; status: PoolStatus }>(poolPath(poolId, "return"), { comment });

/** Pull your own submission back out of the queue. */
export const withdrawPool = (poolId: string) =>
  postJSON<{ ok: boolean; status: PoolStatus }>(poolPath(poolId, "withdraw"), {});

/** Publish without the chain. Admin only, and recorded as an override. */
export const forcePublishPool = (poolId: string, comment = "") =>
  postJSON<{ ok: boolean; status: PoolStatus; published: boolean }>(
    poolPath(poolId, "publish"), { comment });

/** Pools waiting on a step THIS person can sign. Already filtered server-side
 *  by the same refusals `approve` applies, so every row is actionable. */
export const approvalsQueue = () =>
  getJSON<{ queue: QueueItem[] }>("/api/question-pools/approvals/queue");

// ── per-question review ─────────────────────────────────────────────────────

export type QuestionVerdict = "approved" | "rejected";

/** What a checker has decided about one question, within the current cycle. */
export type QuestionReview = { verdict: QuestionVerdict; comment: string; by: string };

export type PoolReview = {
  pool_id: string;
  pool_name: string;
  team: string;
  status: PoolStatus;
  questions: PoolQuestion[];
  /** Keyed by question id. Empty until the checker records something, so a
   *  half-finished review survives leaving the page. */
  reviews: Record<string, QuestionReview>;
};

export const poolReview = (poolId: string) =>
  getJSON<PoolReview>(poolPath(poolId, "review"));

/** Send every verdict at once. "Approve all" is this with every verdict set to
 *  approved — one route, so the bulk button cannot drift from the per-row one. */
export const reviewPool = (
  poolId: string,
  verdicts: { question_id: string; verdict: QuestionVerdict; comment?: string }[],
) =>
  postJSON<{ ok: boolean; status: PoolStatus; reviews: Record<string, QuestionReview> }>(
    poolPath(poolId, "review"), { verdicts },
  );

export const poolHistory = (poolId: string) =>
  getJSON<{ history: HistoryEntry[]; status: PoolStatus }>(poolPath(poolId, "history"));

/** How a pool's state should read in a list. One line, because "draft",
 *  "pending" and "published + a draft behind it" are three different things a
 *  person needs to tell apart at a glance. */
export function stateLabel(p: PoolSummary): string {
  if (p.source === "builtin") return "Built-in";
  if (p.workflow === "pending") return `Awaiting ${p.next_step?.name || "approval"}`;
  if (p.state === "draft") return "Draft";
  if (p.has_draft) return "Published · draft pending";
  return "Published";
}

/** The pill colour for that label. Amber means "someone must act". */
export function stateTone(p: PoolSummary): "neutral" | "amber" | "green" | "grey" {
  if (p.source === "builtin") return "grey";
  if (p.workflow === "pending") return "amber";
  if (p.state === "draft") return "neutral";
  return "green";
}

// ── shared helpers ──────────────────────────────────────────────────────────
export function blankQuestion(kind?: PoolKind): PoolQuestion {
  const q: PoolQuestion = {
    kind: kind?.id ?? SPOKEN_KIND,
    text: "", topic: "", difficulty: "medium", coverage_tags: [],
  };
  // A written question always carries a limit; the rest of its material comes
  // from the kind's own fields (rendered from the catalog).
  if (kind?.written) q.written_response = { char_limit: 1500 };
  // A coding question starts with one empty test-case row, so the shape the
  // author edits matches the shape that gets saved.
  if (kind?.id === CODING_KIND) {
    q.coding = {
      language: "python", title: "", starter_code: "", function_name: "",
      test_cases: [{ name: "", input: "", expected: "" }], solution: "", hints: [],
      topics: [], role_fit: [], estimated_time_s: 0,
    };
  }
  if (kind?.id === SCENARIO_KIND) {
    q.scenario = { max_followups: 2 };
  }
  return q;
}

/** Which editor fields a kind actually uses. A written task is scored by its
 *  own rubric plugin, not by verifier follow-ups, so category and answer points
 *  would be dead fields on the form — and dead fields read as required. */
export function showsTopicAndPoints(kind: PoolKind | null | undefined): boolean {
  return !kind?.written;
}

/** Answer points steer the VERIFIER's spoken follow-ups. A coding answer is
 *  graded by its TEST CASES instead — nothing probes it conversationally — so
 *  the field would be dead weight, and a dead field reads as required. */
export function showsAnswerPoints(kind: PoolKind | null | undefined): boolean {
  return !kind?.written && kind?.id !== CODING_KIND;
}

/** Mirrors the server's normalisation so the editor previews the topic exactly
 *  as it will be stored (the customizer's topic filter is slug-based). */
export function normaliseTopic(raw: string): string {
  return (raw || "")
    .trim().toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 48);
}

/** Client-side mirror of the server's rules, so the admin gets an inline
 *  message instead of a round-trip. The SERVER stays authoritative.
 *
 *  It has to be KIND-AWARE. Several kinds never take a hand-written question:
 *  translation's is hidden entirely, transcription's is optional — both are
 *  synthesised server-side from the question's own config. Demanding text for
 *  those flagged a complete question as empty and disabled Save with no way
 *  forward, which is exactly what this used to do. */
export function validatePool(
  name: string, questions: PoolQuestion[], kinds: PoolKind[] = [],
): string[] {
  const problems: string[] = [];
  if (!name.trim()) problems.push("Pool name is required.");
  if (!questions.length) problems.push("Add at least one question.");

  questions.forEach((q, i) => {
    const where = `Question ${i + 1}`;
    const kind = kinds.find((k) => k.id === (q.kind || SPOKEN_KIND));
    // No catalog (spoken-only fallback) → the classic rule.
    const writesOwnPrompt = !kind || (kind.prompt_required && !kind.prompt_hidden);
    if (writesOwnPrompt && !q.text.trim()) {
      problems.push(`${where}: ${kind?.prompt_label ?? "the question text"} is empty.`);
    }
    // A specific (spoken) question is scored by the verifier probing whatever
    // the answer misses — with no category it can't be filtered/counted by the
    // cadence customizer, and with no answer point there is nothing for the
    // interviewer to check against, so both are required, not merely offered.
    if (showsTopicAndPoints(kind) && !q.topic.trim()) {
      problems.push(`${where}: Category is required.`);
    }
    if (showsAnswerPoints(kind) && !q.coverage_tags.some((t) => t.trim())) {
      problems.push(`${where}: at least one answer point is required.`);
    }
    // The material the kind requires — checked here so a missing passage, clip
    // or test case is caught inline rather than as a 400 on Save. Which BLOCK
    // the fields live on comes from the catalog, so a kind with a different
    // shape (coding) needs no special case.
    const blockName = kind?.block || "written_response";
    const blk = ((q as unknown as Record<string, unknown>)[blockName] ?? {}) as Record<string, unknown>;
    for (const f of kind?.fields ?? []) {
      const v = blk[f.name];
      let empty: boolean;
      if (f.kind === "string_list") {
        empty = !Array.isArray(v) || !v.some((x) => String(x).trim());
      } else if (f.kind === "chips") {
        empty = !Array.isArray(v) || v.length === 0;
      } else if (f.kind === "duration" || f.kind === "count") {
        empty = false;   // blank is legitimate — it falls back to a default
      } else if (f.kind === "asset_media") {
        empty = !v || !(v as { ref?: string }).ref;
      } else if (f.kind === "test_cases") {
        // A row counts only once it has an expected value — an input alone
        // cannot be checked against anything.
        const rows = Array.isArray(v) ? (v as CodingTestCase[]) : [];
        empty = !rows.some((r) => String(r?.expected ?? "").trim());
      } else {
        empty = !String(v ?? "").trim();
      }
      if ((f.ui_required ?? f.required) && empty) {
        problems.push(
          f.kind === "test_cases"
            ? `${where}: at least one test case needs an expected value.`
            : `${where}: ${f.label} is required.`,
        );
      }
    }
    if (kind?.written && !(Number(blk.char_limit) > 0) && !(Number(blk.word_limit) > 0)) {
      problems.push(`${where}: a character limit is required.`);
    }
  });
  return problems;
}

/** Topic × difficulty matrix for the questions currently on screen — recomputed
 *  live so gaps are visible BEFORE saving rather than when a cadence request
 *  silently under-fills. */
export function countsFor(questions: PoolQuestion[]): Record<string, Record<Difficulty, number>> {
  const out: Record<string, Record<Difficulty, number>> = {};
  for (const q of questions) {
    const topic = normaliseTopic(q.topic) || "(none)";
    out[topic] ??= { easy: 0, medium: 0, hard: 0 };
    out[topic][q.difficulty] += 1;
  }
  return out;
}

/** Bulk import: one question per line, so someone with a list in a doc can
 *  paste it instead of typing rows. `Question | topic | difficulty | tag; tag`
 *  — every field after the question is optional. */
export function parseBulk(text: string, fallbackTopic = ""): PoolQuestion[] {
  const out: PoolQuestion[] = [];
  for (const line of text.split("\n")) {
    const raw = line.trim();
    if (!raw) continue;
    const [q, topic, diff, tags] = raw.split("|").map((p) => p.trim());
    if (!q) continue;
    const d = (diff || "").toLowerCase();
    out.push({
      kind: SPOKEN_KIND,
      text: q,
      topic: topic || fallbackTopic,
      difficulty: (DIFFICULTIES as readonly string[]).includes(d) ? (d as Difficulty) : "medium",
      coverage_tags: (tags || "").split(";").map((t) => t.trim()).filter(Boolean),
    });
  }
  return out;
}

/** A pool's questions prepared for an interview phase. Uploaded material is
 *  copied into that interview server-side, so the phase stops depending on the
 *  pool the moment it is applied. */
export type PoolForPhase = {
  ok: boolean;
  pool_kind: string;
  pool_name: string;
  questions: PoolQuestion[];
  assets_copied: number;
  assets_missing: string[];
};

export const poolForPhase = (poolId: string, token: string, kind?: string) =>
  getJSON<PoolForPhase>(
    `/api/question-pools/${encodeURIComponent(poolId)}/for-phase` +
    `?token=${encodeURIComponent(token)}` +
    (kind ? `&kind=${encodeURIComponent(kind)}` : ""));
