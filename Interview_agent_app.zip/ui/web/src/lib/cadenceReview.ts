// Types + API calls for the cadence + rubric review screen. The cadence
// validate/revise/customize and rubric generate/save endpoints were already
// JSON (built for the Jinja page's fetch calls); the SPA reuses them verbatim.
// Only the page-context GET and the approve POST are new JSON twins.
import { useQuery } from "@tanstack/react-query";
import { ApiError, getJSON, postJSON, putJSON } from "./api";

export type CadenceContext = {
  row: {
    token: string; candidate_name: string; role: string; status: string; cadence_yaml: string;
    // A role's cadence TEMPLATE rather than somebody's interview: approved,
    // not launched, so the page offers no candidate link.
    is_template?: boolean;
  };
  // The role this template belongs to, so the page can go back to it.
  role_public_id?: string;
  active_blocker: boolean;
  active: { token: string; candidate_name: string } | null;
  phase_ids: string[];
  default_phase_id: string;
  pool_files: string[] | null;
  pool_dir_missing: boolean;
  pool_topics: Record<string, string[]>;
  // Display name per pool reference. A user-authored pool's ref is a
  // generated id ("customer_support-a1b2c3"), which is not a label —
  // the picker shows the name the admin typed.
  pool_labels?: Record<string, string>;
  default_topics: string[];
  rubric_enabled: boolean;
};

export type RubricAnchor = { level: string; description: string };
export type RubricSection = {
  phase_id: string;
  purpose: string;
  weight: number;
  score_dimensions: string[];
  ignore_dimensions: string[];
  anchors: RubricAnchor[];
};
export type Rubric = {
  version?: string | number;
  seniority_bar: string;
  source: string;
  generated_at?: string;
  sections: RubricSection[];
};
export type Dims = Record<string, string>;

type OkYaml = { ok: boolean; yaml?: string; warnings?: string[]; error?: string };
type OkRubric = { ok: boolean; rubric?: Rubric; dims?: Dims; error?: string };

export function useCadenceContext(token: string) {
  return useQuery<CadenceContext>({
    queryKey: ["cadence-ctx", token],
    queryFn: () => getJSON<CadenceContext>(`/api/schedule/${token}/cadence`),
    // Cadence generation runs on the worker tier: a fresh draft starts as
    // "generating" with an empty cadence_yaml. Poll every 2s until the worker
    // flips it to "draft"; stop polling once it's ready.
    refetchInterval: (q) =>
      q.state.data?.row?.status === "generating" ? 2000 : false,
  });
}

export const validateCadence = (yaml: string) =>
  postJSON<{ ok: boolean; error?: string }>("/api/cadence/validate", { yaml });

// ── Revise & Verify: the three-agent conversational contract ────────────────
// One turn can end in a MIX of outcomes, so the response is not just a yaml
// string: clauses the ROUTER resolved are already applied to `yaml`, clauses it
// couldn't place come back as `questions`, and asks beyond the editor's
// capability come back as `out_of_scope`. `notes` is what couldn't be applied
// even after the VALIDATING agent's retries.
//
// `ok: false` means the turn couldn't be processed at all (cadence unreadable,
// or the router call failed) — show `error` and nothing else. A clause that
// merely failed to apply is a `note` on an `ok: true` response, so it can travel
// alongside the clauses that did apply.

/** A question the ROUTER agent asked, answered by the admin on a later turn.
 *  Replayed to the server (which stays stateless per call) as the loop context. */
export type ReviseClarification = {
  clause_id: string;
  text: string;
  question: string;
  answer: string;
};

export type ReviseQuestion = {
  clause_id: string;
  text: string;
  question: string;
  options: string[];
};

export type ReviseOutOfScope = { clause_id: string; text: string; message: string };
export type ReviseNote = { clause_id: string; text: string; why: string };

export type ReviseResult = {
  ok: boolean;
  error?: string;
  yaml?: string;
  /** False when nothing was resolvable this turn (pure clarification round). */
  changed?: boolean;
  /** Code-derived "what actually changed" lines, e.g. "warm_up: 0:30 → 3:00". */
  applied?: string[];
  questions?: ReviseQuestion[];
  out_of_scope?: ReviseOutOfScope[];
  notes?: ReviseNote[];
};

// `token` lets the server attach resume/JD context when the ask references it
// (e.g. "ask about a project from the candidate's resume"). `clarifications`
// carries the answered questions from earlier turns of this conversation.
export const reviseCadence = (
  yaml: string,
  feedback: string,
  token?: string,
  clarifications: ReviseClarification[] = [],
) => postJSON<ReviseResult>("/api/cadence/revise", { yaml, feedback, token, clarifications });

export type CustomizeArgs = {
  yaml: string;
  difficulty: string;
  phase: string;
  custom_phase_name?: string;
  anchor_phase?: string;
  pool_file: string;
  count: number;
  topics?: string;
};
export const customizeCadence = (token: string, args: CustomizeArgs) =>
  postJSON<OkYaml>(`/api/cadence/${token}/customize`, args);

export type AdaptiveArgs = {
  yaml: string;
  phase: string;
  custom_phase_name?: string;
  anchor_phase?: string;
  pool_file: string;
  start_difficulty?: string;
};
export const customizeAdaptive = (token: string, args: AdaptiveArgs) =>
  postJSON<OkYaml>(`/api/cadence/${token}/customize_adaptive`, args);

export const addCodingPhase = (token: string, yaml: string) =>
  postJSON<OkYaml>(`/api/cadence/${token}/add_coding_phase`, { yaml });

// Coding-question library picker. Powers the CodingPhaseModal.
export type CodingQuestionPick = {
  id: string;
  title: string;
  prompt: string;
  difficulty: string;
  topic: string[];
  role_fit: string[];
  hint_count: number;
};

export const listCodingQuestions = () =>
  getJSON<{ ok: boolean; questions: CodingQuestionPick[]; count: number }>(
    "/admin/coding/questions",
  );

// Single coding question — the detail twin of CodingQuestionPick. Adds the
// fields the cadence preview cards show (starter_code, test_case_count) plus
// the full hints/test_cases the list endpoint omits.
export type CodingQuestionDetail = CodingQuestionPick & {
  function_name?: string;
  starter_code: string;
  test_case_count: number;
  hints?: string[];
  test_cases?: unknown[];
};

export const getCodingQuestion = (qid: string) =>
  getJSON<{ ok: boolean; question: CodingQuestionDetail }>(
    `/admin/coding/question/${encodeURIComponent(qid)}`,
  );

/** A coding question COPIED into the cadence because it came from an authored
 *  pool rather than the built-in library. Same field names as the library entry,
 *  so the runtime resolves either source identically. */
export type InlineCodingQuestion = {
  title: string;
  prompt: string;
  starter_code: string;
  function_name: string;
  test_cases: { name: string; input: string; expected: string }[];
  solution?: string;
  hints?: string[];
  difficulty?: string;
  topic?: string[];
  role_fit?: string[];
  estimated_time_s?: number;
  language?: string;
};

export const setCodingPhase = (
  token: string,
  yaml: string,
  question_ids: string[],
  time_overrides: Record<string, number> = {},
  inline_questions: Record<string, InlineCodingQuestion> = {},
) =>
  postJSON<OkYaml>(`/api/cadence/${token}/set_coding_phase`, {
    yaml,
    question_ids,
    inline_questions: Object.keys(inline_questions).length ? inline_questions : null,
    time_overrides: Object.keys(time_overrides).length ? time_overrides : null,
  });

export const removeCodingPhase = (token: string, yaml: string) =>
  postJSON<OkYaml>(`/api/cadence/${token}/remove_coding_phase`, { yaml });

// VOICE/VIDEO-interview Visual Scenario Analysis phase. Each item pairs one
// already-uploaded media file (see uploadPhaseAsset) with an admin-written
// question and coverage tags — the runtime shows the media and asks the
// question live, then follows up per item's own max_followups. Media refs are
// never invented client- or server-side; see engine/brain/cadence/schema.py
// ScenarioMedia/ScenarioItem for the authoritative shape.
export type ScenarioMediaPayload = {
  kind: "image" | "video" | "audio";
  ref: string;
  filename: string;
  mime_type: string;
};

export type ScenarioItemPayload = {
  id?: string;                 // echo an existing item's id to keep it
  media: ScenarioMediaPayload;
  question: string;
  coverage_tags: string[];
  max_followups?: number;
};

export type AddScenarioPhaseArgs = {
  name?: string;
  duration_s?: number;
  items: ScenarioItemPayload[];
};
export const addScenarioPhase = (token: string, yaml: string, args: AddScenarioPhaseArgs) =>
  postJSON<OkYaml>(`/api/cadence/${token}/add_scenario_phase`, { yaml, ...args });

export type UpdateScenarioPhaseArgs = {
  phase_id: string;
  duration_s?: number;
  intent?: string;
  generic_prompts?: string[];
  items: ScenarioItemPayload[];
};
export const updateScenarioPhase = (token: string, yaml: string, args: UpdateScenarioPhaseArgs) =>
  postJSON<OkYaml>(`/api/cadence/${token}/update_scenario_phase`, { yaml, ...args });

export const removeScenarioPhase = (token: string, yaml: string, phase_id: string) =>
  postJSON<OkYaml>(`/api/cadence/${token}/remove_scenario_phase`, { yaml, phase_id });

// TEXT-interview written-response phase ("Add Phase"). Inserts a phase holding
// one or more written questions of ONE type before wrap_up, and returns the
// updated cadence YAML. `question_type` picks what the candidate gets (see
// lib/questionTypes.ts, whose catalog comes from the backend); the language pair
// is phase-level; each question carries its own prompt, material, character
// limit and (optional) countdown. `time_limit_s` null/omitted on a question =
// UNTIMED (submit when ready).
export type PhaseQuestionPayload = {
  id?: string;                       // echo an existing question's id to keep it
  prompt: string;
  // Exactly one limit: char_limit for anything authored now, word_limit only for
  // a legacy essay question being edited (so its unit isn't reinterpreted).
  char_limit?: number;
  word_limit?: number;
  time_limit_s?: number | null;
  source_text?: string;
  audio_asset?: string;
  image_asset?: string;
  // Question-scoped: one phase may mix pairs (translation/transcription).
  source_language?: string;
  target_language?: string;
  // transcription: exact reference transcript (string). translation /
  // image_description: accepted reference answers (string[]). Server-only —
  // never sent to the candidate.
  ground_truth?: string | string[];
};

export type AddPhaseArgs = {
  question_type: string;
  name?: string;
  source_language?: string;
  target_language?: string;
  questions: PhaseQuestionPayload[];
};
// What the backend actually did. Adding the SAME phase type under the same name
// again folds the questions into the phase that already exists rather than
// creating a near-identical second one, so `merged_into` is set and no new phase
// appears — the caller has to say so or the add looks like it did nothing.
export type AddPhaseResult = OkYaml & {
  created?: string;
  merged_into?: string;
  added?: number;
};
export const addPhase = (token: string, yaml: string, args: AddPhaseArgs) =>
  postJSON<AddPhaseResult>(`/api/cadence/${token}/add_phase`, { yaml, ...args });

// Replace an existing written-response phase's questions (add / edit / delete).
// The phase keeps its `id` (the evaluation plan + events reference it), and any
// question id echoed back keeps its own.
export type UpdatePhaseArgs = {
  phase_id: string;
  question_type?: string;
  source_language?: string;
  target_language?: string;
  questions: PhaseQuestionPayload[];
};
export const updatePhase = (token: string, yaml: string, args: UpdatePhaseArgs) =>
  postJSON<OkYaml>(`/api/cadence/${token}/update_phase`, { yaml, ...args });

// Upload the material a question type needs (audio clip / image / video).
// Returns the stored NAME to put in the phase config plus the
// candidate-facing URL — the bytes live in the existing blob mirror at
// <token>/phase_assets/<name>, never in the cadence YAML. Multipart,
// admin-gated, same-origin cookie auth. "video" backs Visual Scenario
// Analysis items (see engine/brain/cadence/question_types.py ASSET_RULES).
export async function uploadPhaseAsset(
  token: string,
  kind: "audio" | "image" | "video",
  file: File,
): Promise<{ ok: boolean; name: string; url: string }> {
  const form = new FormData();
  form.append("file", file);
  const res = await fetch(
    `/api/cadence/${token}/phase-asset?kind=${encodeURIComponent(kind)}`,
    { method: "POST", credentials: "same-origin", body: form },
  );
  if (!res.ok) {
    let detail = `${res.status} ${res.statusText}`;
    try {
      const b = (await res.json()) as { error?: string; detail?: string };
      detail = b?.error || b?.detail || detail;
    } catch {
      /* non-JSON error body */
    }
    throw new ApiError(res.status, detail);
  }
  return (await res.json()) as { ok: boolean; name: string; url: string };
}

// GET rubric — resolves to null on 404 (no rubric yet), throws ApiError on any
// other non-2xx so the caller can surface real failures instead of parsing an
// error body as a rubric.
export async function fetchRubric(token: string): Promise<OkRubric | null> {
  const res = await fetch(`/api/rubric/${token}`, { credentials: "same-origin" });
  if (res.status === 404) return null;
  if (!res.ok) throw new ApiError(res.status, `${res.status} ${res.statusText}`);
  return (await res.json()) as OkRubric;
}

export const generateRubric = (token: string, yaml: string) =>
  postJSON<OkRubric>(`/api/rubric/${token}/generate`, { yaml });

export const saveRubric = (token: string, rubric: Rubric) =>
  putJSON<OkRubric>(`/api/rubric/${token}`, { rubric });

export const approveCadence = (token: string, cadence_yaml: string) =>
  postJSON<{
    ok: boolean;
    candidate_link?: string;
    candidate_email?: string | null;
    error?: string;
    blocker?: boolean;
    needs_eval_validation?: boolean;
    // A role's cadence template is APPROVED, not launched — no candidate link.
    is_template?: boolean;
    // Set when the interview (or template) belongs to a Shortlist role.
    role_public_id?: string;
  }>(`/api/schedule/${token}/approve`, { cadence_yaml });

/** (Re)send the candidate their interview link by email — the same invite the
 *  approve step sends automatically, fired again on demand (confirming it
 *  went out, after a bounce, or because the candidate never saw it). */
export const sendInviteEmail = (token: string) =>
  postJSON<{ ok: boolean; email?: string; error?: string }>(
    `/api/schedule/${token}/send-invite-email`, {},
  );
