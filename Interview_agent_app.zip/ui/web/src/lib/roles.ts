// Data layer for the role-centric Shortlist (and AI Interview) flow. A Role is
// a job opening (title + JD + match threshold); resumes are matched against it
// and stored ranked. Backed by /api/roles.
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ApiError, deleteJSON, getJSON, postJSON, putJSON } from "./api";

export type Role = {
  public_id: string;
  title: string;
  jd_text: string;
  threshold: number;
  status: string;
  created_at: string | null;
  candidate_count: number | null;
  matched_count: number | null;
  // voice | text — chosen when the role is created; inherited by its cadence
  // template and by every interview created from it.
  modality: "voice" | "text";
  // sourcing → interviewing → closed. Derived server-side (see role_store.role_state)
  // so the chart, the cards and any future filter agree on one definition.
  state: "sourcing" | "interviewing" | "closed";
  interview_count: number;
  // Per-stage counts for this role's own chart.
  interview_states?: {
    ready_to_send?: number; in_progress?: number; completed?: number;
    awaiting_approval?: number; cancelled?: number; total?: number;
  };
  // The role's cadence-template session; "" until one is authored.
  template_token: string;
};

// The interview plan every candidate in this role will get. Authored once,
// applied verbatim — candidates who answered different questions can't be
// ranked against each other, which is what the Shortlist is for.
export type CadenceTemplate = {
  token: string;
  status: string;            // missing | draft | ready
  ready: boolean;            // reviewed and approved by a person
  modality?: "voice" | "text";  // absent until a template exists
};

export type RoleCandidate = {
  candidate_public_id: string;
  name: string;
  email: string;
  final_score: number;
  llm_score: number;
  coverage_score: number;
  recommendation: string;
  above_threshold: boolean;
  has_resume: boolean;
  source: string;
};

export type RoleDetail = Role & { candidates: RoleCandidate[] };

export type MatchResult = {
  processed: number;
  errors: { file: string; error: string }[];
  threshold: number;
  candidates: RoleCandidate[];
};

export function useRoles() {
  return useQuery<{ roles: Role[] }>({ queryKey: ["roles"], queryFn: () => getJSON("/api/roles") });
}

export function useRole(id: string) {
  return useQuery<RoleDetail>({ queryKey: ["role", id], queryFn: () => getJSON(`/api/roles/${id}`) });
}

export function useCreateRole() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (b: { title: string; jd_text?: string; threshold?: number; modality?: "voice" | "text" }) =>
      postJSON<Role>("/api/roles", b),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["roles"] }),
  });
}

export function useUpdateRole(id: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (b: Partial<Pick<Role, "title" | "jd_text" | "threshold" | "status">>) =>
      putJSON<Role>(`/api/roles/${id}`, b),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["role", id] });
      qc.invalidateQueries({ queryKey: ["roles"] });
    },
  });
}

export type CreatedInterview = {
  token: string; candidate_name: string;
  candidate_public_id?: string; candidate_email?: string;
};
export type InterviewsResult = { created: CreatedInterview[]; errors: { candidate: string; error: string }[] };

/** The role's cadence template, polled while the worker is generating it. */
export function useCadenceTemplate(id: string) {
  return useQuery({
    queryKey: ["role-template", id],
    queryFn: () => getJSON<CadenceTemplate>(`/api/roles/${id}/cadence-template`),
    enabled: !!id,
    // Poll only while the worker is still writing the plan.
    refetchInterval: (q) => (q.state.data?.status === "generating" ? 2000 : false),
    refetchOnWindowFocus: true,   // they approve it on another screen and come back
  });
}

/** Get-or-create the template. Idempotent — returns the existing one. */
export function useEnsureCadenceTemplate(id: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => postJSON<CadenceTemplate>(`/api/roles/${id}/cadence-template`, {}),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["role-template", id] });
      qc.invalidateQueries({ queryKey: ["role", id] });
    },
  });
}

export type ApprovedInterview = {
  token: string; candidate_name: string; candidate_link: string;
  candidate_public_id: string;
  // Extracted from the resume by an LLM, so regularly wrong or missing — and it
  // decides who actually receives the interview. Editable on the screen.
  candidate_email: string;
};

/** Drop a candidate from THIS role's shortlist. Their person record, resume,
 *  other roles and any interviews already created are untouched. */
export function useRemoveCandidate(roleId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (candidateId: string) =>
      deleteJSON<{ ok: boolean; removed: number }>(
        `/api/roles/${roleId}/candidates/${candidateId}`),
    onSuccess: () => invalidateRole(qc, roleId),
  });
}

/** Correct the address a candidate's interview link goes to. */
export function useSetCandidateEmail(roleId: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ candidateId, email }: { candidateId: string; email: string }) =>
      putJSON<{ public_id: string; name: string; email: string }>(
        `/api/roles/${roleId}/candidates/${candidateId}/email`, { email },
      ),
    onSuccess: () => invalidateRole(qc, roleId),
  });
}

/** (Re)send the candidate their interview link by email — the same invite the
 *  approve step sends automatically, fired again on demand (after fixing a
 *  wrong/blank email, or for a candidate who never got the first one). */
export function useSendInterviewEmail(roleId: string) {
  return useMutation({
    mutationFn: (token: string) =>
      postJSON<{ ok: boolean; email: string }>(
        `/api/roles/${roleId}/interviews/${token}/send-email`, {},
      ),
  });
}

/** Everything on a role's screens that a mutation can invalidate.
 *
 *  Kept in ONE place because the last three bugs here were all the same shape:
 *  a mutation refreshed some of the queries and the screen showed two different
 *  truths at once. The role query feeds the candidate picker AND the stage
 *  chart; the interviews query feeds the list; the roles query feeds the
 *  Shortlist overview. A write that changes a role's interviews changes all
 *  three, so no caller should have to remember which.
 */
function invalidateRole(qc: ReturnType<typeof useQueryClient>, id: string) {
  void qc.invalidateQueries({ queryKey: ["role", id] });
  void qc.invalidateQueries({ queryKey: ["role-interviews", id] });
  void qc.invalidateQueries({ queryKey: ["roles"] });
}

export type RoleInterview = {
  token: string; status: string;
  candidate_name: string; candidate_email: string; candidate_public_id: string;
  candidate_link: string; created_at: string;
};

/** The role's interviews, read from the server so they survive navigation. */
export function useRoleInterviews(id: string) {
  return useQuery({
    queryKey: ["role-interviews", id],
    queryFn: () => getJSON<{ interviews: RoleInterview[] }>(`/api/roles/${id}/interviews`),
    enabled: !!id,
  });
}

/** Turn the role's drafts into live interviews and get a link per candidate. */
export function useApproveInterviews(id: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (tokens: string[]) =>
      postJSON<{ approved: ApprovedInterview[]; errors: { candidate_name?: string; error: string }[] }>(
        `/api/roles/${id}/interviews/approve`, { tokens },
      ),
    onSuccess: () => invalidateRole(qc, id),
  });
}

export function useCreateInterviews(id: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (candidate_public_ids: string[]) =>
      postJSON<InterviewsResult>(`/api/roles/${id}/interviews`, { candidate_public_ids }),
    onSuccess: () => invalidateRole(qc, id),
  });
}

export function useMatchResumes(id: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (files: File[]) => {
      const fd = new FormData();
      for (const f of files) fd.append("resumes", f);
      const res = await fetch(`/api/roles/${id}/match`, {
        method: "POST",
        credentials: "same-origin",
        body: fd,
      });
      if (!res.ok) throw new ApiError(res.status, `${res.status} ${res.statusText}`);
      return (await res.json()) as MatchResult;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["role", id] }),
  });
}
