// Data hooks for the interview sessions dashboard. These hit the JSON twins
// of the Jinja /admin/dashboard data + archive/delete actions, all on the
// shared session cookie. The screens they don't cover yet (schedule, session
// detail, reopen) still live in the Jinja /admin app, so the
// UI deep-links out to those absolute paths during the migration.
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { deleteJSON, getJSON, postJSON } from "./api";

export type SessionStatus =
  | "draft"
  | "ready"
  | "in_progress"
  | "completed"
  | "cancelled";

// Mirrors the InterviewSession row the dashboard renders. Extra columns may
// be present on the wire; we only type what the table reads.
export type SessionRow = {
  token: string;
  candidate_name: string;
  role: string;
  status: SessionStatus | string;
  created_at: string;
  ended_at: string | null;
  ws_port: number | null;
};

export type SessionsPayload = {
  rows: SessionRow[];
  // Scaled system runs many interviews at once — a LIVE count of in-progress
  // sessions (replaces the old single-at-a-time `active` row).
  active_count: number;
  candidate_link_base: string;
};

export function useSessions() {
  return useQuery<SessionsPayload>({
    queryKey: ["sessions"],
    queryFn: () => getJSON<SessionsPayload>("/api/sessions"),
    refetchInterval: 15_000, // keep the live/in-progress rows fresh
  });
}

export function useArchiveSession() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (token: string) =>
      postJSON<{ ok: boolean }>(`/api/sessions/${token}/archive`, {}),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["sessions"] }),
  });
}

export function useDeleteSession() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (token: string) =>
      deleteJSON<{ ok: boolean }>(`/api/sessions/${token}`),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["sessions"] }),
  });
}

export type BulkDeleteResult = {
  ok: boolean;
  deleted: number;
  // tokens left intact because the session was in_progress (cannot delete a
  // live interview). The UI surfaces these so the operator knows why fewer
  // rows vanished than they selected.
  skipped: string[];
};

export function useBulkDeleteSessions() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (tokens: string[]) =>
      postJSON<BulkDeleteResult>("/api/sessions/bulk_delete", { tokens }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["sessions"] }),
  });
}
