// TalkingHead avatar adapter. Loads the 3D talking-head library from CDN at
// runtime (it's a large WebGL/Three.js module — not worth bundling, and only
// needed in avatar mode) and exposes a tiny sink the candidate engine drives.
//
// We use TalkingHead's STREAMING API (streamStart/streamAudio/streamNotifyEnd)
// rather than the fire-and-forget speakAudio queue, because streaming gives a
// real `onAudioEnd` callback — "audio playback concluded" — which is the honest
// signal the backend uses to start the no-response silence timer, gate VAD, and
// hold wrap-up teardown (the v20 requirement). `speak()` returns a Promise that
// resolves on that event, and the candidate engine's kickPlayer awaits it
// (grounded ack, via:"sink") — see ui/web/src/lib/candidateEngine.ts.
//
// Returns null if the avatar can't boot — the caller then falls back to the
// engine's minimal-mode AudioContext playback (which grounds on the real
// AudioBufferSourceNode.onended).

const TALKINGHEAD_MODULE =
  "https://cdn.jsdelivr.net/gh/met4citizen/TalkingHead@1.7/modules/talkinghead.mjs";
const DEFAULT_AVATAR =
  "https://cdn.jsdelivr.net/gh/met4citizen/TalkingHead@1.7/avatars/brunette.glb";

export type AvatarSink = {
  // Resolves when the utterance has ACTUALLY finished playing (TalkingHead's
  // streaming onAudioEnd) — the grounded "candidate stopped hearing it" signal.
  speak: (chunks: ArrayBuffer[], text: string, durMs: number, sampleRate: number) => Promise<void>;
  stop: () => void;
  dispose: () => void;
  // LiveKit: the AI's voice is a live track the page is already playing, so
  // there is no whole utterance to hand over. The engine taps that track and
  // streams it here as it is heard; the avatar renders the FACE only — the
  // voice, the playback ack and the recording stay on the LiveKit path.
  stream: AvatarStream;
};

export type AvatarStream = {
  // 16 kHz PCM16 mono, in real time, from the first audible frame of a run of
  // AI speech until the run has been heard out.
  feed: (pcm: ArrayBuffer) => void;
  // An utterance's audio starts with the frame fed next; spread its words over
  // durMs for the lip timing.
  utterance: (text: string, durMs: number) => void;
  // The run was heard out.
  end: () => void;
  // Barge-in: the candidate cut the AI off.
  cut: () => void;
};

// Spread a chunk's duration across its words by length — gives TalkingHead
// per-word viseme timings without a real forced-aligner. Same heuristic the
// vanilla client used.
function estimateWordTimings(text: string, durationMs: number) {
  const words = (text || "").trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return { words: [], wtimes: [], wdurations: [] };
  const weights = words.map((w) => Math.max(1, w.length));
  const total = weights.reduce((a, b) => a + b, 0);
  const wtimes: number[] = [];
  const wdurations: number[] = [];
  let cursor = 0;
  for (const w of weights) {
    const dur = (w / total) * durationMs;
    wtimes.push(cursor);
    wdurations.push(dur);
    cursor += dur;
  }
  return { words, wtimes, wdurations };
}

// Flatten the engine's ArrayBuffer[] PCM chunks into one 16-bit LE PCM buffer,
// which is what streamAudio expects for `audio`.
function concatBuffers(chunks: ArrayBuffer[]): ArrayBuffer {
  let total = 0;
  for (const c of chunks) total += c.byteLength;
  const out = new Uint8Array(total);
  let off = 0;
  for (const c of chunks) {
    out.set(new Uint8Array(c), off);
    off += c.byteLength;
  }
  return out.buffer;
}

// TalkingHead's own framing options (see its setView): which preset, plus a
// distance offset (m) and a vertical shift (fraction of the half-frame).
export type AvatarCamera = {
  cameraView: "full" | "mid" | "upper" | "head";
  cameraDistance?: number;
  cameraY?: number;
};

export async function bootAvatar(
  container: HTMLElement,
  sampleRate: number,
  avatarUrl: string = DEFAULT_AVATAR,
  camera: AvatarCamera = { cameraView: "upper" },
): Promise<AvatarSink | null> {
  try {
    const mod = (await import(/* @vite-ignore */ TALKINGHEAD_MODULE)) as {
      TalkingHead: new (el: HTMLElement, opts: Record<string, unknown>) => {
        showAvatar: (opts: Record<string, unknown>) => Promise<void>;
        // Streaming API (v1.7): streamStart opens a reusable session, streamAudio
        // feeds PCM, streamNotifyEnd marks an utterance done → onAudioEnd fires
        // once it finishes playing; streamInterrupt stops for barge-in.
        streamStart: (
          opt: Record<string, unknown>,
          onAudioStart: (() => void) | null,
          onAudioEnd: (() => void) | null,
          onSubtitles?: ((s: unknown) => void) | null,
          onMetrics?: ((m: unknown) => void) | null,
        ) => Promise<void>;
        streamAudio: (r: {
          audio?: ArrayBuffer;
          words?: string[];
          wtimes?: number[];
          wdurations?: number[];
        }) => void;
        streamNotifyEnd: () => void;
        streamInterrupt: () => void;
        streamStop: () => void;
        setMixerGain: (speech: number | null, background?: number | null, fadeSecs?: number) => void;
        audioCtx?: AudioContext;
      };
    };
    const head = new mod.TalkingHead(container, {
      ...camera,
      lipsyncModules: ["en"],
      modelPixelRatio: window.devicePixelRatio || 1,
      pcmSampleRate: sampleRate,
    });
    await head.showAvatar({
      url: avatarUrl,
      body: avatarUrl.toLowerCase().includes("brunette") ? "F" : "M",
      avatarMood: "neutral",
      lipsyncLang: "en",
    });

    // Live-feed state (LiveKit): ms of audio fed since TalkingHead's current
    // playback began. Word times are relative to that start, so an utterance
    // beginning now has its words offset by this much.
    let fedMs = 0;
    let streaming = false;

    // One pending resolver — utterances are serialized (the engine's kickPlayer
    // awaits each speak() before the next), so a single onAudioEnd unambiguously
    // belongs to the in-flight utterance.
    let pendingResolve: (() => void) | null = null;
    const settle = () => {
      // TalkingHead's playback ended (heard out, interrupted, or starved long
      // enough to time out): the next feed starts a new timeline.
      fedMs = 0;
      if (pendingResolve) {
        const r = pendingResolve;
        pendingResolve = null;
        r();
      }
    };

    // Open the streaming session. onAudioEnd is our grounded completion signal;
    // it fires when an utterance finishes playing AND (per v1.7) on
    // streamInterrupt while speaking — both correctly settle the pending promise.
    await head.streamStart(
      { sampleRate, lipsyncLang: "en", lipsyncType: "words" },
      /* onAudioStart */ null,
      /* onAudioEnd   */ settle,
      /* onSubtitles  */ null,
    );

    // Voice through TalkingHead (WebSocket path) or face only (LiveKit, where
    // the page's LiveKit element is already playing the voice — two copies
    // would echo).
    const setVoice = (on: boolean) => {
      try { head.setMixerGain(on ? 1 : 0); } catch { /* noop */ }
    };

    return {
      speak: (chunks, text, durMs) => {
        streaming = false;
        setVoice(true);
        return new Promise<void>((resolve) => {
          pendingResolve = resolve;
          try {
            if (head.audioCtx && head.audioCtx.state === "suspended") void head.audioCtx.resume();
            const { words, wtimes, wdurations } = estimateWordTimings(text, durMs);
            head.streamAudio({ audio: concatBuffers(chunks), words, wtimes, wdurations });
            head.streamNotifyEnd();
          } catch (err) {
            console.error("[avatar] streamAudio failed", err);
            // Never hang the player loop — settle now (engine's safety-net race
            // would otherwise wait out the timeout).
            if (pendingResolve === resolve) {
              pendingResolve = null;
              resolve();
            }
          }
        });
      },
      stream: {
        feed: (pcm) => {
          if (!streaming) {
            streaming = true;
            setVoice(false);
          }
          try {
            if (head.audioCtx && head.audioCtx.state === "suspended") void head.audioCtx.resume();
            // Measure first: streamAudio TRANSFERS the buffer to its worklet,
            // leaving it empty (the engine hands each frame over once).
            const ms = (pcm.byteLength / 2 / sampleRate) * 1000;
            head.streamAudio({ audio: pcm });
            fedMs += ms;
          } catch (err) {
            console.error("[avatar] live feed failed", err);
          }
        },
        utterance: (text, durMs) => {
          const { words, wtimes, wdurations } = estimateWordTimings(text, durMs);
          if (!words.length) return;
          try {
            head.streamAudio({ words, wtimes: wtimes.map((t) => t + fedMs), wdurations });
          } catch (err) {
            console.error("[avatar] live lip timing failed", err);
          }
        },
        end: () => {
          try { head.streamNotifyEnd(); } catch { /* noop */ }
        },
        cut: () => {
          try { head.streamInterrupt(); } catch { /* noop */ }
          settle();
        },
      },
      stop: () => {
        // Barge-in: stop current playback (keeps the session for reuse).
        // streamInterrupt fires onAudioEnd if it was speaking (→ settle); resolve
        // defensively in case nothing was playing.
        try {
          head.streamInterrupt();
        } catch {
          /* noop */
        }
        settle();
      },
      dispose: () => {
        try {
          head.streamStop();
        } catch {
          /* noop */
        }
        settle();
      },
    };
  } catch (err) {
    console.warn("[avatar] boot failed — falling back to minimal orb", err);
    return null;
  }
}
