// Types + API calls for the plugin-based evaluation plan (v2). Mirrors
// cadenceReview.ts: thin wrappers over the /api/eval/* routes added alongside
// the plugin framework. All routes are gated server-side by EVAL_PLUGINS_ENABLED
// and 404 when the feature is off — callers treat that as "feature disabled".
import { ApiError, postJSON, putJSON } from "./api";

// One plugin in the registry catalog (GET /api/eval/plugins).
// `author_actionable` is false for runtime/dev preconditions the TA can't act on
// (candidate-answer present, LLM key set) — the UI hides those.
export type PluginAssumption = { key: string; description: string; author_actionable?: boolean };
// Plain-language, author-facing help shown at the top of each plugin card so a
// TA knows what a plugin is for instead of guessing from its name.
export type PluginHelp = {
  summary: string;
  best_for: string;
  how_it_works: string[];
  you_configure: string[];
  evidence: string;
};
export type PluginCatalogEntry = {
  id: string;
  name: string;
  description: string;
  method: "llm_judge" | "python";
  view_id: string;
  config_json_schema: JsonSchema;
  default_config: Record<string, unknown>;
  assumptions: PluginAssumption[];
  help?: PluginHelp;
  // The section this plugin contributes to the evaluation export, or null when
  // it declares none. Nothing in the UI reads it yet; here so the type matches
  // what /api/eval/plugins actually returns.
  export_section?: string | null;
};

// Minimal JSON-schema shape the generic SchemaForm understands.
export type JsonSchema = {
  type?: string;
  properties?: Record<string, JsonSchemaProp>;
  required?: string[];
  [k: string]: unknown;
};
export type JsonSchemaProp = {
  type?: string | string[];
  title?: string;
  description?: string;
  default?: unknown;
  enum?: unknown[];
  items?: JsonSchemaProp;
  minimum?: number;
  maximum?: number;
  [k: string]: unknown;
};

// One rubric_marks option (mirrors the backend Criterion): a description + the
// marks to add when the option applies.
export type Criterion = { description: string; marks: number };

export type PluginAssignment = {
  plugin_id: string;
  config: Record<string, unknown>;
  enabled: boolean;
};
export type PhasePlan = { phase_id: string; plugins: PluginAssignment[] };
export type EvaluationPlan = {
  version?: string;
  source?: string;
  generated_at?: string;
  phases: PhasePlan[];
};

type OkPlugins = { ok: boolean; plugins?: PluginCatalogEntry[]; dims?: Record<string, string>; error?: string };
type OkPlan = { ok: boolean; plan?: EvaluationPlan; error?: string; ai_used?: boolean };

// GET catalog — resolves to null on 404 (feature disabled), throws on other
// non-2xx so the caller surfaces real failures.
export async function listEvalPlugins(): Promise<OkPlugins | null> {
  const res = await fetch("/api/eval/plugins", { credentials: "same-origin" });
  if (res.status === 404) return null;
  if (!res.ok) throw new ApiError(res.status, `${res.status} ${res.statusText}`);
  return (await res.json()) as OkPlugins;
}

export async function fetchEvalPlan(token: string): Promise<OkPlan | null> {
  const res = await fetch(`/api/eval/plan/${token}`, { credentials: "same-origin" });
  if (res.status === 404) return null;
  if (!res.ok) throw new ApiError(res.status, `${res.status} ${res.statusText}`);
  return (await res.json()) as OkPlan;
}

export const generateEvalPlan = (token: string, yaml: string) =>
  postJSON<OkPlan>(`/api/eval/plan/${token}/generate`, { yaml });

export const saveEvalPlan = (token: string, plan: EvaluationPlan) =>
  putJSON<OkPlan>(`/api/eval/plan/${token}`, { plan });

// Deterministic per-plugin assumption check against the current cadence YAML.
export type PluginValidation = { plugin_id: string; ok: boolean; unmet: string[] };
export type PhaseValidation = { phase_id: string; plugins: PluginValidation[] };
type OkValidate = { ok: boolean; all_ok?: boolean; results?: PhaseValidation[]; error?: string };

export const validateEvalPlan = (token: string, yaml: string, plan: EvaluationPlan) =>
  postJSON<OkValidate>(`/api/eval/plan/${token}/validate`, { yaml, plan });
