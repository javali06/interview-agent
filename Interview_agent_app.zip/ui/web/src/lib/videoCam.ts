// Optional camera tiles — capture + JPEG-snapshot helpers.
// Transport is periodic JPEG over the existing WebSocket (server relays via
// the `video_frame` / `video_stop` messages; see broadcaster `video_relay`).
// WebRTC was considered but snapshots keep zero new infra and let the server —
// which already sees every stream — fold video into the session recording later.

// Modest capture constraints: the snapshot is downscaled + JPEG-compressed
// before sending, so a big source resolution just wastes CPU. An optional
// deviceId pins a specific camera (from the lobby picker); omitted → default.
export async function startCamera(opts?: { deviceId?: string }): Promise<MediaStream> {
  const video: MediaTrackConstraints = {
    width: { ideal: 480 },
    height: { ideal: 360 },
    frameRate: { ideal: 15 },
  };
  if (opts?.deviceId) video.deviceId = { exact: opts.deviceId };
  return navigator.mediaDevices.getUserMedia({
    video,
    audio: false, // mic is a separate, always-on capture; camera is video-only
  });
}

// Enumerate available input/output devices grouped by kind, for the lobby
// device pickers. Labels are only populated after a getUserMedia permission
// grant, so callers should enable mic/camera first for meaningful names.
export async function listDevices(): Promise<{
  cameras: MediaDeviceInfo[];
  mics: MediaDeviceInfo[];
  speakers: MediaDeviceInfo[];
}> {
  const all = await navigator.mediaDevices.enumerateDevices();
  return {
    cameras: all.filter((d) => d.kind === "videoinput"),
    mics: all.filter((d) => d.kind === "audioinput"),
    speakers: all.filter((d) => d.kind === "audiooutput"),
  };
}

// Screen share. The browser shows its own picker + a "Stop sharing" control;
// callers should watch the track's `onended` to clear state when the user stops
// from that control.
//
// For proctoring we want the WHOLE monitor, not a window/tab. The browser won't
// let us *force* that — the candidate still chooses in the native dialog — so we
// only HINT it here (displaySurface:"monitor" preselects the monitor option and
// the *exclude switches drop the window/tab choices where supported). The caller
// must VALIDATE the granted surface via `isEntireScreen()` and re-prompt if not.
export async function startScreen(): Promise<MediaStream> {
  return navigator.mediaDevices.getDisplayMedia({
    // Ask for ~1080p so shared code/text stays sharp in the screen recording.
    // ideal (not exact) → native if the monitor is smaller, downscaled toward 1080p
    // if it's a 4K panel (also lighter on the candidate's CPU).
    video: { displaySurface: "monitor", frameRate: { ideal: 5 }, width: { ideal: 1920 }, height: { ideal: 1080 } },
    audio: false,
    // Non-standard but widely supported Chromium hints; ignored elsewhere.
    monitorTypeSurfaces: "include",
    surfaceSwitching: "exclude",
    selfBrowserSurface: "exclude",
  } as DisplayMediaStreamOptions);
}

// Did the candidate actually share their ENTIRE screen (a monitor), not a window
// or browser tab? Reads the granted track's displaySurface. Returns true when we
// can't tell (older browsers omit the field) so we never hard-block on a
// browser that simply doesn't report it.
export function isEntireScreen(stream: MediaStream): boolean {
  const track = stream.getVideoTracks()[0];
  if (!track) return false;
  const surface = (track.getSettings() as MediaTrackSettings & { displaySurface?: string }).displaySurface;
  return !surface || surface === "monitor";
}

export function stopStream(stream: MediaStream | null): void {
  stream?.getTracks().forEach((t) => t.stop());
}
