// Shared amplitude -> glow driver for every orb (candidate + AI). One rAF
// loop for all registered orbs; levels are written straight to a CSS custom
// property so audio-rate updates (~20Hz mic, ~60Hz AI) never touch React
// state or trigger a VideoTiles re-render.
export type GlowSource = "mic" | "ai";

// Fast rise / slow fall time constants (ms) for an exponential attack-decay
// envelope, so the glow doesn't strobe on individual audio packets but still
// feels immediate when someone starts talking.
export const GLOW_ATTACK_MS = 60;
export const GLOW_DECAY_MS = 260;

// Fixed glow shown for an active source under prefers-reduced-motion,
// instead of one that tracks amplitude.
const REDUCED_MOTION_LEVEL = 40;

// Same rms -> 0-100 scaling candidateEngine.ts uses for micLevel (app/static/
// mic-worklet.js), so equal loudness reads as equal glow on every orb
// regardless of source.
const LEVEL_SCALE = 600;

type OrbEntry = { el: HTMLElement; source: GlowSource };

const orbs = new Set<OrbEntry>();
const rawLevel: Record<GlowSource, number> = { mic: 0, ai: 0 };
const smoothLevel: Record<GlowSource, number> = { mic: 0, ai: 0 };
const analysers: Partial<Record<GlowSource, AnalyserNode>> = {};
let timeDomainScratch: Float32Array<ArrayBuffer> | null = null;

let reducedMotion = false;
try {
  const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
  reducedMotion = mq.matches;
  mq.addEventListener?.("change", (e) => { reducedMotion = e.matches; });
} catch {
  // matchMedia unavailable — default to full motion.
}

let rafId: number | null = null;
let lastTs = 0;

function ensureLoop() {
  if (rafId != null) return;
  lastTs = performance.now();
  rafId = requestAnimationFrame(tick);
}

function tick(ts: number) {
  const dt = Math.max(0, Math.min(200, ts - lastTs));
  lastTs = ts;

  // Analyser-backed sources (AI): sample fresh RMS every frame, straight into
  // rawLevel, same curve as mic's own scaling — overrides any pushLevel
  // caller for that source while an analyser is attached.
  (Object.keys(analysers) as GlowSource[]).forEach((source) => {
    const analyser = analysers[source];
    if (!analyser) return;
    if (!timeDomainScratch || timeDomainScratch.length !== analyser.fftSize) {
      timeDomainScratch = new Float32Array(analyser.fftSize);
    }
    analyser.getFloatTimeDomainData(timeDomainScratch);
    let sumSquares = 0;
    for (let i = 0; i < timeDomainScratch.length; i++) sumSquares += timeDomainScratch[i] * timeDomainScratch[i];
    const rms = Math.sqrt(sumSquares / timeDomainScratch.length);
    rawLevel[source] = Math.min(100, rms * LEVEL_SCALE);
  });

  let settled = true;

  (Object.keys(rawLevel) as GlowSource[]).forEach((source) => {
    const target = rawLevel[source];
    const prev = smoothLevel[source];
    const tau = target > prev ? GLOW_ATTACK_MS : GLOW_DECAY_MS;
    const alpha = 1 - Math.exp(-dt / tau);
    let next = prev + (target - prev) * alpha;
    if (Math.abs(next - target) < 0.05) next = target;
    smoothLevel[source] = next;
    // A live analyser can go quiet mid-utterance (a pause) and pick back up —
    // keep polling it, don't let the loop settle-stop just because this frame
    // happened to read ~0.
    if (next !== 0 || target !== 0 || analysers[source]) settled = false;
  });

  orbs.forEach(({ el, source }) => {
    const v = reducedMotion
      ? (rawLevel[source] > 0.5 || smoothLevel[source] > 0.5 ? REDUCED_MOTION_LEVEL : 0)
      : smoothLevel[source];
    el.style.setProperty("--glow-level", v.toFixed(1));
  });

  rafId = settled ? null : requestAnimationFrame(tick);
}

// Read a source's current smoothed level directly (0..1), no DOM involved.
// `tick()` above updates `smoothLevel` every frame regardless of whether any
// orb is registered, as long as the shared loop is running (any pushLevel/
// registerAnalyser call keeps it alive) — so this is always fresh for a
// consumer that just wants the number itself (e.g. a <canvas> orb), without
// the registerOrb+CSS-var+getComputedStyle round trip.
export function getLevel(source: GlowSource): number {
  return smoothLevel[source] / 100;
}

// Register an orb element to track a source's level. Pass source: null for
// an orb that should never react — it's simply
// never added to the loop and keeps rendering whatever it renders today.
export function registerOrb(el: HTMLElement | null, source: GlowSource | null): () => void {
  if (!el || !source) return () => {};
  const entry: OrbEntry = { el, source };
  orbs.add(entry);
  el.style.setProperty("--glow-level", smoothLevel[source].toFixed(1));
  return () => {
    orbs.delete(entry);
  };
}

// Push a fresh 0-100 level reading for a source. Safe to call at any rate —
// the envelope above does the smoothing.
export function pushLevel(source: GlowSource, level: number) {
  rawLevel[source] = Math.max(0, Math.min(100, level));
  ensureLoop();
}

// Hard-zero a source immediately, bypassing decay smoothing. For cases where
// lingering glow would be wrong, not just slow to fade: AI playback
// cancelled by a barge-in, mic muted.
export function resetSource(source: GlowSource) {
  rawLevel[source] = 0;
  smoothLevel[source] = 0;
  orbs.forEach(({ el, source: s }) => {
    if (s === source) el.style.setProperty("--glow-level", "0");
  });
}

// Attach an AnalyserNode as this source's level reading, sampled every frame
// of the shared loop above (not a second rAF loop). The caller owns the
// analyser's place in its audio graph — see candidateEngine.ts for why that
// differs between the two AI playback paths — this just reads it.
export function registerAnalyser(source: GlowSource, analyser: AnalyserNode) {
  analysers[source] = analyser;
  ensureLoop();
}

// Detach a source's analyser. Does NOT zero the level on its own — the
// caller should follow a `true` return with resetSource() for an immediate,
// grounded zero (the usual case). Pass the analyser you registered: if a
// newer one has already replaced it (e.g. utterance N+1's tap started
// registering just before utterance N's belatedly fires its own onended),
// this is a no-op and returns false — the caller must NOT then reset the
// source, or it would zero out N+1's in-progress glow.
export function unregisterAnalyser(source: GlowSource, analyser?: AnalyserNode): boolean {
  if (analyser && analysers[source] !== analyser) return false;
  delete analysers[source];
  return true;
}
