// Shared cadence parsing + the 6-color phase palette (ported from the legacy
// admin cadence visualization, brightened for the dark canvas). Used by the
// Session "Cadence" tab and the CadenceReview structured preview.
import jsyaml from "js-yaml";

// Per-question written-response config (a written-response phase's pool items
// carry one each — see engine/brain/cadence/schema.py WrittenQuestion). Read by
// the Add/Edit Phase modal to prefill an existing phase.
export type ParsedWrittenQuestion = {
  char_limit?: number;
  word_limit?: number;
  time_limit_s?: number | null;
  source_text?: string;
  audio_asset?: string;
  image_asset?: string;
  // Per question, so one phase can mix pairs. An older phase carries these at
  // phase level instead, where they act as the default (see ParsedWrittenResponse).
  source_language?: string;
  target_language?: string;
  // transcription: exact reference transcript (string). translation /
  // image_description: accepted reference answers (string[]). Server-only —
  // never sent to the candidate.
  ground_truth?: string | string[];
};

export type ParsedQuestion = {
  id?: string;
  text?: string;
  topic?: string;
  follow_ups?: string[];
  written_response?: ParsedWrittenQuestion;
};

// Phase-level written-response config: the question type + the language pair
// (plus, on legacy essay phases, the limits themselves).
export type ParsedWrittenResponse = ParsedWrittenQuestion & {
  question_type?: string;
  source_language?: string;
  target_language?: string;
};

// One Visual Scenario Analysis item (see engine/brain/cadence/schema.py
// ScenarioMedia/ScenarioItem). `media.ref` is an already-uploaded asset name —
// reuses the SAME phase-asset upload/serve routes as image_description.
export type ParsedScenarioMedia = {
  kind: "image" | "video" | "audio";
  ref: string;
  filename: string;
  mime_type: string;
};

export type ParsedScenarioItem = {
  id: string;
  media: ParsedScenarioMedia;
  question: string;
  coverage_tags: string[];
  max_followups?: number;
};

export type ParsedPhase = {
  id?: string;
  duration_s?: number;
  intent?: string;
  question_mode?: string;
  generic_prompts?: unknown[];
  question_pool?: unknown[];
  adaptive_difficulty?: boolean;
  coding_question_ids?: string[];
  /** Full coding-question definitions embedded in THIS cadence, keyed by the
   *  same id that appears in `coding_question_ids`. Present when the question
   *  came from an authored pool rather than the built-in library — the pool is
   *  a template, so its definition is copied in at apply time. */
  coding_questions_inline?: Record<string, ParsedInlineCodingQuestion>;
  written_response?: ParsedWrittenResponse;
  /** Non-empty marks this phase as Visual Scenario Analysis — orthogonal to
   *  question_mode, exactly like coding_question_ids marks a coding phase. */
  scenario_items?: ParsedScenarioItem[];
};

/** A pool-authored coding question as stored in the cadence. Same field names
 *  as the built-in library entry. */
export type ParsedInlineCodingQuestion = {
  title?: string;
  prompt?: string;
  starter_code?: string;
  function_name?: string;
  test_cases?: { name?: string; input?: string; expected?: string }[];
  hints?: string[];
  difficulty?: string;
  topic?: string[];
  role_fit?: string[];
  estimated_time_s?: number;
};

export type ParsedCadence = {
  total_duration_s?: number;
  // Top-level modality flag: voice cadences are timed (true / absent), a TEXT
  // interview's cadence carries `timed: false`. Carried straight through from
  // the loaded YAML (parseCadenceYaml casts the whole object), so `parsed?.timed
  // === false` reliably identifies a text interview on the review page.
  timed?: boolean;
  phases?: ParsedPhase[];
};

export function parseCadenceYaml(yaml: string): ParsedCadence | null {
  try {
    return (jsyaml.load(yaml) as ParsedCadence) ?? null;
  } catch {
    return null;
  }
}

// 6-color cycle (the old admin's magenta/teal/amber/purple/blue/red), tuned
// brighter so each reads as a left-border accent on the ink background.
const PHASE_COLORS = ["#ff5bbf", "#23c4b0", "#f0a830", "#a855f7", "#5b9cff", "#ff6b81"];

export function phaseColor(i: number): string {
  return PHASE_COLORS[((i % PHASE_COLORS.length) + PHASE_COLORS.length) % PHASE_COLORS.length];
}
