// Thin same-origin fetch helpers. Auth is the existing httpOnly session
// cookie, so every call sends credentials and no token is stored in JS.

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message);
    this.name = "ApiError";
  }
}

async function handle<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let detail = `${res.status} ${res.statusText}`;
    try {
      // Our JSON endpoints return { error: "..." }; FastAPI's own errors use
      // { detail: "..." }. Surface whichever is present so the message is real.
      const body = (await res.json()) as { error?: string; detail?: string };
      if (body?.error) detail = body.error;
      else if (body?.detail) detail = body.detail;
    } catch {
      /* non-JSON error body */
    }
    throw new ApiError(res.status, detail);
  }
  return (await res.json()) as T;
}

export function getJSON<T>(url: string): Promise<T> {
  return fetch(url, { credentials: "same-origin" }).then(handle<T>);
}

export function postJSON<T>(url: string, body: unknown): Promise<T> {
  return fetch(url, {
    method: "POST",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  }).then(handle<T>);
}

export function patchJSON<T>(url: string, body: unknown): Promise<T> {
  return fetch(url, {
    method: "PATCH",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  }).then(handle<T>);
}

export function putJSON<T>(url: string, body: unknown): Promise<T> {
  return fetch(url, {
    method: "PUT",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  }).then(handle<T>);
}

export function deleteJSON<T>(url: string): Promise<T> {
  return fetch(url, { method: "DELETE", credentials: "same-origin" }).then(handle<T>);
}
