// Data hooks + types for the Session-detail screen. The heavy lifting
// (event annotation, phase grouping, cost rollups, evaluation scoring) is done
// server-side in admin/event_viewer.py + admin/evaluation_service.py and
// surfaced verbatim by GET /api/sessions/{token}/detail — React is a pure
// renderer, no analysis logic reimplemented here.
import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { getJSON, postJSON } from "./api";
import type { Benchmark } from "../components/eval-views/types";

export type DimensionScore = { score: number; rationale: string };
export type QuestionScore = { id: string; text: string; score: number; rationale: string };
export type PhaseScore = {
  id: string;
  name: string;
  score: number;
  summary: string;
  questions: QuestionScore[];
};
export type Highlight = { title: string; detail: string };
export type Overall = { score: number; band: string; headline: string; summary: string };

export type Evaluation = {
  generated_at: string;
  model: string;
  overall: Overall;
  dimensions: Record<string, DimensionScore>;
  phases: PhaseScore[];
  strengths: Highlight[];
  weaknesses: Highlight[];
  rubric_used?: boolean;
  rubric_fingerprint?: string;
  // v2 plugin pipeline: present when EVAL_PLUGINS_ENABLED produced this eval.
  // The legacy fields above are derived from `benchmark` for back-compat.
  plan_used?: boolean;
  plan_fingerprint?: string;
  benchmark?: Benchmark;
} | null;

// One captured LLM call within a turn. The backend (event_viewer.py) already
// correlates llm_call_started (system_prompt + user_messages) with the matching
// _completed/_failed (tokens, output, latency) into this single record, plus a
// prebuilt langfuse_trace_url — React just renders it.
export type UserMessage = { role: string; content: string };
export type LlmCall = {
  agent: string;
  model: string | null;
  status: string; // "completed" | "failed" | "error"
  error_label: string | null;
  error_message: string | null;
  latency_ms: number | null;
  ttft_ms: number | null;
  latency_human: string;
  ttft_human: string;
  system_prompt: string | null;
  user_messages: UserMessage[] | null;
  response_text: string | null;
  langfuse_trace_id: string | null;
  langfuse_trace_url: string | null; // prebuilt server-side (S7)
};

export type Verifier = {
  intent?: string;
  confidence?: number | null;
  instruction?: string | null;
  reason?: string | null; // guardrail sub-category when intent=guardrail_triggered
  latency_ms?: number | null;
  langfuse_trace_id?: string | null;
  langfuse_trace_url?: string | null; // prebuilt server-side (S7)
};

export type PhaseOverride = {
  override?: string; // "stay" | "advance_now" | "end_now"
  reason?: string;
  confidence?: number | null;
  langfuse_trace_id?: string | null;
  langfuse_trace_url?: string | null; // prebuilt server-side (S7)
};

export type BargeIn = { kind?: string; ts?: string; reason?: string | null };

export type Turn = {
  ts: string;
  candidate_text: string | null;
  candidate_conf: number | null;
  ai_utterance: string | null;
  ai_filler: string | null;
  ai_apology: string | null;
  // True when this turn was spoken by the observer (TA) via push-to-talk
  // rather than the model. ai_utterance carries the observer's words (it is
  // the AI's turn for the LLM), and the UI labels it "Observer (TA)".
  observer?: boolean;
  barge_ins: BargeIn[];
  errors: unknown[];
  verifier: Verifier | null;
  phase_override: PhaseOverride | null;
  llm_calls: LlmCall[];
};

// Per-test verdict from the sandbox runner (shape is loose — keys vary by
// runner: pass/passed, got/actual).
export type CodingTestResult = {
  name?: string;
  passed?: boolean;
  pass?: boolean;
  expected?: unknown;
  got?: unknown;
  actual?: unknown;
  error?: string;
};
export type CodingQuestion = {
  question_id: string;
  question_prompt: string;
  function_name: string;
};
export type CodingSubmission = {
  question_id: string;
  code: string;
  runs_used: number;
  auto_submitted: boolean;
  test_results: CodingTestResult[];
  passed: number;
  total: number;
};
export type CodingHint = { level: number | null; text: string; ts?: string };
export type CodingAntiCheat = { reason: string; metadata?: unknown; ts?: string };

export type Phase = {
  id: string;
  duration_human: string;
  cost_human: string;
  cost_usd: number;
  turn_count: number;
  ai_turn_count: number;
  errors: unknown[];
  transition: string | null; // "advance_now" | "end_now" | null
  turns: Turn[];
  coding_questions?: CodingQuestion[];
  coding_submissions?: CodingSubmission[];
  coding_hints?: CodingHint[];
  coding_anti_cheat?: CodingAntiCheat[];
};

export type Totals = {
  duration_human: string;
  duration_ms: number;
  cost_human: string;
  cost_usd: number;
  phase_count: number;
  turn_count: number;
  ai_turn_count: number;
  llm_calls: number;
  llm_tokens_in: number;
  llm_tokens_out: number;
  error_count: number;
};

export type PerModelRow = {
  model: string;
  kind: string; // "llm" | "stt" | "tts"
  calls: number;
  cost_human: string;
  cost_usd: number;
  tokens_in: number;
  tokens_out: number;
  tokens_cached?: number;
  audio_ms?: number;
  chars?: number;
};
export type PerModel = {
  rows?: PerModelRow[];
  source?: string;
  total_cost_human?: string;
  total_cost_usd?: number;
  totals?: {
    tokens_in: number;
    tokens_out: number;
    tokens_cached: number;
    tokens_cache_write: number;
  };
};

// Cost for setting up the interview — cadence generation/revision + eval-
// plugin/rubric generation. Kept as a SEPARATE rollup from `PerModel` above
// (see `app/setup_cost_tracker.py`): these calls run before/independent of
// the live interview session under the same token, so they're never mixed
// into the live session's own per-model cost table.
export type SetupPerModelRow = {
  model: string;
  purpose: string; // "generate_cadence" | "revise_cadence_with_ai" | "generate_eval_plugin" | "generate_rubric"
  calls: number;
  cost_human: string;
  cost_usd: number;
  tokens_in: number;
  tokens_out: number;
  tokens_cached?: number;
};
export type SetupPerModel = {
  rows?: SetupPerModelRow[];
  total_cost_human?: string;
  total_cost_usd?: number;
};

// build_coding_performance() output (evaluation_service.py). Per-question
// submitted-vs-expected + LLM-judge rubric dims, joined server-side.
export type CodingPerfQuestion = {
  question_id: string;
  prompt: string | null;
  submitted: boolean;
  auto_submitted: boolean;
  passed: number;
  total: number;
  pass_rate_pct: number;
  composite_score: number;
  has_score: boolean;
  correctness: number | null;
  readability: number | null;
  idiomatic: number | null;
  edge_cases: number | null;
  rationale: string;
  runs_used: number;
  hints_used: number;
  time_to_submit_s: number;
  test_results: CodingTestResult[];
  code: string;
};
export type CodingPerfPhase = {
  id: string;
  name: string;
  submitted_count: number;
  expected_count: number;
  missing_count: number;
  auto_count: number;
  passed_tests: number;
  total_tests: number;
  questions: CodingPerfQuestion[];
};
export type CodingPerf = {
  phases: CodingPerfPhase[];
  overall: {
    total_submitted: number;
    total_expected: number;
    total_passed_tests: number;
    total_tests: number;
    avg_composite: number;
  };
};

export type SessionRow = {
  token: string;
  candidate_name: string;
  role: string;
  status: string;
  created_at: string;
  started_at: string | null;
  ended_at: string | null;
  ws_port: number | null;
  cadence_yaml: string | null;
  jd_text: string | null;
  resume_path?: string | null;
  jd_path?: string | null;
  cadence_requirements_path?: string | null;
};

export type SessionDetail = {
  row: SessionRow;
  events: unknown[];
  summary: Record<string, number>;
  evaluation: Evaluation;
  candidate_link_base: string;
  candidate_interview_link: string | null; // S5 — prebuilt, status-gated
  langfuse_url: string | null;
  langfuse_project_base: string | null;
  phases: Phase[];
  totals: Totals;
  mermaid_src: string;
  per_model: PerModel;
  setup_per_model?: SetupPerModel;
  coding_perf: CodingPerf | null;
  rubric_by_phase: Record<string, unknown>;
  eval_used_rubric: boolean;
  rubric_changed: boolean;
  eval_plugins_enabled?: boolean;
  plan_used?: boolean;
  plan_changed?: boolean;
};

type EvalResult = { ok: boolean; evaluation?: Evaluation; error?: string };

// ── Observer scorecard (B) ──────────────────────────────────────────────────
// GET /api/sessions/{token}/notes — the observer's read-only competency ratings
// + timestamped free-text notes captured during the live interview.
// Backend returns a FLAT list: each item is a "rating" (competency+score) or a
// free-text "note". The review tab groups them (latest rating per competency).
export type ScorecardItem = {
  created_at: string;
  author: string;
  kind: string;             // "note" | "rating"
  text: string;
  competency: string | null;
  score: number | null;
};
export type Scorecard = { notes: ScorecardItem[] };

export function useScorecard(token: string, enabled: boolean) {
  return useQuery<Scorecard>({
    queryKey: ["scorecard", token],
    queryFn: () => getJSON<Scorecard>(`/api/sessions/${token}/notes`),
    enabled,
  });
}

export function useSessionDetail(token: string) {
  return useQuery<SessionDetail>({
    queryKey: ["session", token],
    queryFn: () => getJSON<SessionDetail>(`/api/sessions/${token}/detail`),
  });
}

export function useEvaluate(token: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => postJSON<EvalResult>(`/api/sessions/${token}/evaluate`, {}),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["session", token] }),
  });
}

export function useReviseEval(token: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (feedback: string) =>
      postJSON<EvalResult>(`/api/sessions/${token}/evaluation/revise`, { feedback }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["session", token] }),
  });
}

// ── Mermaid phase-flow renderer (S2) ────────────────────────────────────────
// The backend ships `mermaid_src` (flowchart with health coloring). We load
// mermaid from a CDN ESM bundle at view-time — same runtime-import pattern the
// TalkingHead avatar uses — so the heavy bundle never enters our `npm ci`
// dependency tree (keeps the lockfile/Docker build clean) and a missing/failed
// load degrades gracefully (caller shows an ordered phase list instead).
// Mirrors the Jinja themeVariables so the two UIs look identical.
const MERMAID_MODULE = "https://esm.sh/mermaid@10";
// Minimal surface we use — avoids needing @types/mermaid at compile time.
type MermaidApi = {
  initialize: (cfg: Record<string, unknown>) => void;
  render: (id: string, src: string) => Promise<{ svg: string }>;
};
let mermaidModPromise: Promise<MermaidApi | null> | null = null;
function loadMermaid() {
  if (mermaidModPromise) return mermaidModPromise;
  mermaidModPromise = import(/* @vite-ignore */ MERMAID_MODULE)
    .then((m) => {
      const mermaid = (m.default ?? m) as MermaidApi;
      mermaid.initialize({
        startOnLoad: false,
        theme: "base",
        themeVariables: {
          fontFamily: "Inter, sans-serif",
          primaryColor: "#fcf9f6",
          primaryTextColor: "#1a0010",
          lineColor: "#80606e",
        },
        flowchart: { htmlLabels: true, curve: "basis" },
      });
      return mermaid;
    })
    .catch(() => null); // dep absent / failed → caller falls back
  return mermaidModPromise;
}

type MermaidState = "rendering" | "ok" | "failed";

/** Render `src` into an svg string. `active` gates work until the tab is shown
 *  (mermaid needs a visible, sized container — same reason the Jinja version
 *  defers render to the sx:tab event). */
export function useMermaid(src: string | undefined, active: boolean) {
  const [svg, setSvg] = useState<string | null>(null);
  const [state, setState] = useState<MermaidState>("rendering");
  const idRef = useRef(`mmd-${Math.random().toString(36).slice(2)}`);

  useEffect(() => {
    if (!active || !src) return;
    let cancelled = false;
    setState("rendering");
    loadMermaid().then(async (mermaid) => {
      if (cancelled) return;
      if (!mermaid) { setState("failed"); return; }
      try {
        const out = await mermaid.render(idRef.current, src);
        if (!cancelled) { setSvg(out.svg); setState("ok"); }
      } catch {
        if (!cancelled) setState("failed");
      }
    });
    return () => { cancelled = true; };
  }, [src, active]);

  return { svg, state };
}
