// The Access area. Each call matches one tab. A save returns the whole tab
// again, so the screen never keeps a copy that can disagree with the server.
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { deleteJSON, getJSON, patchJSON, postJSON, putJSON } from "./api";
import type { RoleGrant } from "./auth";

export type Person = {
  id: number;
  email: string;
  display_name: string;
  is_active: boolean;
  last_login_at: string | null;
  grants: RoleGrant[];
};

export type PeopleResponse = {
  people: Person[];
  roles: { key: string; name: string; scope: string }[];
  teams: { key: string; name: string }[];
};

export type TeamRow = {
  key: string;
  name: string;
  is_system: boolean;
  is_active: boolean;
  people: number;
  pools: number;
  steps: number;
};

export type ChainStep = { step_no: number; name: string; role: string; role_name: string };

export type ChainResponse = {
  key: string;
  name: string;
  is_system: boolean;
  chain: ChainStep[];
  roles: { key: string; name: string }[];
  warnings?: string[];
};

export type RoleGrid = {
  permissions: { key: string; group: string; label: string }[];
  roles: { key: string; name: string; permissions: string[] }[];
  locked: Record<string, string[]>;
};

function useAccess<T>(key: string, url: string, enabled = true) {
  return useQuery<T>({
    queryKey: ["access", key],
    queryFn: () => getJSON<T>(url),
    enabled,
  });
}

export function usePeople() {
  return useAccess<PeopleResponse>("people", "/api/access/people");
}

export function useTeams() {
  return useAccess<{ teams: TeamRow[] }>("teams", "/api/access/teams");
}

export function useChain(teamKey: string | null) {
  return useAccess<ChainResponse>(
    `chain:${teamKey ?? ""}`,
    `/api/access/teams/${encodeURIComponent(teamKey ?? "")}/chain`,
    !!teamKey,
  );
}

export function useRoleGrid() {
  return useAccess<RoleGrid>("roles", "/api/access/roles");
}

/** After a save, refresh the tab and the signed-in menu (the admin may have edited themselves). */
function useSave<T>(key: string, fn: (body: T) => Promise<unknown>) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: fn,
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["access", key] });
      void qc.invalidateQueries({ queryKey: ["me"] });
    },
  });
}

export function useSetActive() {
  return useSave("people", (body: { id: number; is_active: boolean }) =>
    patchJSON(`/api/access/people/${body.id}`, { is_active: body.is_active }));
}

export function useAddGrant() {
  return useSave("people", (body: { id: number; role: string; team: string }) =>
    postJSON(`/api/access/people/${body.id}/grants`, { role: body.role, team: body.team }));
}

export function useRemoveGrant() {
  return useSave("people", (body: { id: number; role: string; team: string }) =>
    deleteJSON(
      `/api/access/people/${body.id}/grants?role=${encodeURIComponent(body.role)}&team=${encodeURIComponent(body.team)}`,
    ));
}

export function useCreateTeam() {
  return useSave("teams", (body: { name: string; key: string }) =>
    postJSON("/api/access/teams", body));
}

export function useUpdateTeam() {
  return useSave("teams", (body: { key: string; name?: string; is_active?: boolean }) =>
    patchJSON(`/api/access/teams/${encodeURIComponent(body.key)}`, {
      name: body.name, is_active: body.is_active,
    }));
}

export function useDeleteTeam() {
  return useSave("teams", (key: string) =>
    deleteJSON(`/api/access/teams/${encodeURIComponent(key)}`));
}

export function useSaveChain(teamKey: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (steps: { name: string; role: string }[]) =>
      putJSON<ChainResponse>(`/api/access/teams/${encodeURIComponent(teamKey)}/chain`, { steps }),
    onSuccess: (data) => {
      qc.setQueryData(["access", `chain:${teamKey}`], data);
      void qc.invalidateQueries({ queryKey: ["access", "teams"] });
    },
  });
}

export function useSetPermission() {
  return useSave("roles", (body: { role: string; permission: string; enabled: boolean }) =>
    putJSON(`/api/access/roles/${encodeURIComponent(body.role)}`, {
      permission: body.permission, enabled: body.enabled,
    }));
}
