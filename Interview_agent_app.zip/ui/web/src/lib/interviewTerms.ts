// Terms & Conditions shown to the candidate immediately after they click
// "Start interview", before the live session begins. Kept as data (sections)
// so the modal can render + scroll them and so the accepted VERSION can travel
// with the session-start payload for an auditable consent record.
//
// WHY a version string: consent is meaningful only against the exact text the
// candidate saw. Bump TERMS_VERSION whenever the wording below changes so an
// accepted record can be tied to what was actually presented.

export const TERMS_VERSION = "2026-07-06";

export type TermsSection = { heading: string; body: string[] };

export const TERMS_INTRO =
  "Before your interview begins, please read and accept the terms below. This " +
  "interview is conducted by an automated AI interviewer and is recorded. By " +
  "continuing you confirm you understand how your audio, video, screen, and " +
  "related data are captured, processed, and used.";

export const INTERVIEW_TERMS: TermsSection[] = [
  {
    heading: "1. Consent to participate and to be recorded",
    body: [
      "This interview session is conducted, recorded, and analysed by an automated " +
        "AI interviewing system on behalf of the hiring organisation (“we”, " +
        "“us”). Your participation is voluntary, but recording is a mandatory " +
        "condition of taking this interview — if you do not consent, please close this " +
        "window and contact your recruiter instead of proceeding.",
      "By selecting “I agree” you give your informed, explicit consent to the " +
        "collection and processing described in these terms for the entire duration of the " +
        "session.",
    ],
  },
  {
    heading: "2. Audio recording",
    body: [
      "Your microphone is captured continuously for the full duration of the interview. " +
        "This includes your spoken answers and any other sound picked up by your microphone.",
      "Audio of all participants present in the session — you, the AI interviewer, and any " +
        "human interviewer or proctor who joins — is recorded together as a single " +
        "conversation record. Muting yourself within the app stops your audio from being sent " +
        "to the interviewer in real time but the session recording still reflects the " +
        "conversation.",
    ],
  },
  {
    heading: "3. Video / webcam recording",
    body: [
      "Your webcam is captured and recorded continuously throughout the interview for identity " +
        "verification and proctoring purposes. You must keep your camera on for the duration of " +
        "the session.",
      "Please ensure you are in an appropriate, well-lit, private environment. Other individuals " +
        "should not appear on camera during the interview.",
    ],
  },
  {
    heading: "4. Screen sharing and screen recording",
    body: [
      "You are required to share your entire screen (not a single window or browser tab) for the " +
        "full interview, and your shared screen is recorded together with its accompanying audio.",
      "Do not display passwords, private messages, financial information, or any other sensitive " +
        "personal content on your screen during the session, as it will be captured. Keep only " +
        "the interview and any expressly permitted materials open.",
    ],
  },
  {
    heading: "5. Use of data for fraud and integrity analytics",
    body: [
      "Recorded audio, video, screen activity, and derived signals are used for fraud detection " +
        "and interview-integrity analytics. This includes, without limitation: verifying your " +
        "identity, detecting impersonation or the presence of undisclosed third parties, " +
        "identifying the use of external assistance or unauthorised tools, and detecting anomalous " +
        "or suspicious behaviour during the session.",
      "This analysis may be automated (including machine-learning and behavioural models) and may " +
        "be performed both during and after the interview. Indicators of fraud or dishonest conduct " +
        "may result in your interview being flagged, paused, invalidated, or rejected, and may be " +
        "shared with the hiring organisation as part of your assessment.",
    ],
  },
  {
    heading: "6. Automated processing by AI",
    body: [
      "The interview is conducted by an AI interviewer. Your speech is transcribed automatically " +
        "and your responses are processed and evaluated by automated systems, which may include " +
        "large language models, to produce a structured assessment of your performance.",
      "The AI conducts and clarifies its own questions only; it does not make a final hiring " +
        "decision on its own. Outputs are provided to the hiring organisation to support a " +
        "human-reviewed decision.",
    ],
  },
  {
    heading: "7. Data storage, retention, and security",
    body: [
      "Recordings, transcripts, and analysis are stored on secure cloud infrastructure with " +
        "access controls and encryption in transit and at rest. Data is retained only as long as " +
        "necessary for the recruitment process, integrity review, and any applicable legal or " +
        "regulatory obligations, after which it is deleted or anonymised.",
    ],
  },
  {
    heading: "8. Who your data is shared with",
    body: [
      "Your interview data may be accessed by authorised personnel of the hiring organisation " +
        "(such as recruiters, interviewers, and evaluators) and by trusted service providers who " +
        "operate the platform on our behalf — for example speech-to-text, text-to-speech, " +
        "large-language-model, cloud hosting, and proctoring/analytics providers — under " +
        "appropriate confidentiality and data-protection obligations.",
      "We do not sell your personal data. Data is not shared for purposes unrelated to this " +
        "recruitment process except where required by law.",
    ],
  },
  {
    heading: "9. Your privacy rights",
    body: [
      "Depending on your jurisdiction, you may have rights to access, correct, delete, or restrict " +
        "the processing of your personal data, and to object to certain automated processing. To " +
        "exercise these rights, or for questions about how your data is handled, contact the " +
        "recruiter or data-protection contact provided by the hiring organisation.",
    ],
  },
  {
    heading: "10. Candidate conduct",
    body: [
      "You agree to complete the interview honestly and by yourself. You must not receive help " +
        "from another person, use unauthorised tools, applications, or reference material, record " +
        "or redistribute the interview content, or attempt to impersonate anyone or misrepresent " +
        "your identity or work.",
      "You agree not to interfere with, disrupt, or attempt to circumvent the proctoring, " +
        "recording, or evaluation mechanisms of the platform.",
    ],
  },
  {
    heading: "11. Acknowledgement and withdrawal of consent",
    body: [
      "By continuing, you confirm that you have read and understood these terms, that you are of " +
        "legal age to consent, and that you agree to the collection and processing of your audio, " +
        "video, screen, and related data as described above.",
      "You may withdraw your consent at any time by ending the interview and closing the session; " +
        "however, withdrawing consent means the interview cannot continue, and data already " +
        "lawfully processed up to that point may be retained as described in these terms.",
    ],
  },
];

// ── Recording-OFF variant ────────────────────────────────────────────────
// Shown instead of the terms above when this interview is configured NOT to
// record (no camera/screen, no media artifact) — the live conversation +
// transcript still happen and are still consented to, but this text must not
// claim consent for recording that isn't occurring. Own version string so an
// accepted record is tied to the exact text presented for THIS interview
// type; the recording-ON version above is untouched.
export const TERMS_VERSION_NO_RECORDING = "2026-08-03-no-recording";

export const TERMS_INTRO_NO_RECORDING =
  "Before your interview begins, please read and accept the terms below. This " +
  "interview is conducted by an automated AI interviewer. Your microphone is used " +
  "to carry the live conversation and produce a transcript — this interview is not " +
  "recorded on video or screen. By continuing you confirm you understand how your " +
  "audio and related data are captured, processed, and used.";

export const INTERVIEW_TERMS_NO_RECORDING: TermsSection[] = [
  {
    heading: "1. Consent to participate",
    body: [
      "This interview session is conducted and analysed by an automated AI interviewing " +
        "system on behalf of the hiring organisation (“we”, “us”). Your participation is " +
        "voluntary. By selecting “I agree” you give your informed, explicit consent to the " +
        "collection and processing described in these terms for the entire duration of the " +
        "session.",
    ],
  },
  {
    heading: "2. Live audio and transcript",
    body: [
      "Your microphone is used to carry your spoken answers to the AI interviewer in real " +
        "time and is transcribed automatically. Your audio is not saved as a recording. " +
        "Muting yourself within the app stops your audio from being sent to the interviewer " +
        "until you unmute.",
    ],
  },
  {
    heading: "3. Automated processing by AI",
    body: [
      "The interview is conducted by an AI interviewer. Your speech is transcribed " +
        "automatically and your responses are processed and evaluated by automated systems, " +
        "which may include large language models, to produce a structured assessment of " +
        "your performance.",
      "The AI conducts and clarifies its own questions only; it does not make a final hiring " +
        "decision on its own. Outputs are provided to the hiring organisation to support a " +
        "human-reviewed decision.",
    ],
  },
  {
    heading: "4. Conversation integrity",
    body: [
      "The transcript of your responses may be automatically reviewed for signs of dishonest " +
        "conduct, such as reciting answers verbatim from an external source or other " +
        "conversational anomalies. This analysis is based solely on the conversation " +
        "transcript — no video or screen data exists for this interview. Indicators of " +
        "concern may result in your interview being flagged for human review.",
    ],
  },
  {
    heading: "5. Data storage, retention, and security",
    body: [
      "Your transcript and the resulting assessment are stored on secure cloud " +
        "infrastructure with access controls and encryption in transit and at rest. Data is " +
        "retained only as long as necessary for the recruitment process and any applicable " +
        "legal or regulatory obligations, after which it is deleted or anonymised.",
    ],
  },
  {
    heading: "6. Who your data is shared with",
    body: [
      "Your interview transcript and assessment may be accessed by authorised personnel of " +
        "the hiring organisation (such as recruiters, interviewers, and evaluators) and by " +
        "trusted service providers who operate the platform on our behalf — for example " +
        "speech-to-text, large-language-model, and cloud hosting providers — under " +
        "appropriate confidentiality and data-protection obligations. We do not sell your " +
        "personal data.",
    ],
  },
  {
    heading: "7. Your privacy rights",
    body: [
      "Depending on your jurisdiction, you may have rights to access, correct, delete, or " +
        "restrict the processing of your personal data, and to object to certain automated " +
        "processing. To exercise these rights, or for questions about how your data is " +
        "handled, contact the recruiter or data-protection contact provided by the hiring " +
        "organisation.",
    ],
  },
  {
    heading: "8. Candidate conduct",
    body: [
      "You agree to complete the interview honestly and by yourself. You must not receive " +
        "help from another person, use unauthorised tools, applications, or reference " +
        "material, or attempt to impersonate anyone or misrepresent your identity or work.",
      "You agree not to interfere with, disrupt, or attempt to circumvent the evaluation " +
        "mechanisms of the platform.",
    ],
  },
  {
    heading: "9. Acknowledgement and withdrawal of consent",
    body: [
      "By continuing, you confirm that you have read and understood these terms, that you " +
        "are of legal age to consent, and that you agree to the collection and processing of " +
        "your audio and related data as described above.",
      "You may withdraw your consent at any time by ending the interview and closing the " +
        "session; however, withdrawing consent means the interview cannot continue, and data " +
        "already lawfully processed up to that point may be retained as described in these " +
        "terms.",
    ],
  },
];
