// The "Add phases" control that replaces the old standalone "+ Add coding
// phase" button on VOICE/VIDEO interviews. Two choices: Coding (unchanged
// behaviour — opens CodingPhaseModal) and Visual Scenario Analysis (opens
// ScenarioPhaseModal).
//
// Opens a small modal mirroring AddPhaseModal.tsx's shell exactly (dialog
// overlay, card, header + X, a labelled "Phase type" select, a helper line,
// Cancel/Continue footer) — the text interview's "Add phase" modal — rather
// than a bare dropdown, so picking a phase type looks and feels the same on
// both interview modes. The modal's only job is routing to the right
// full modal; it never saves anything itself, which is why its primary
// button reads "Continue" rather than "Save".
import { useState } from "react";
import type { CSSProperties } from "react";
import { createPortal } from "react-dom";

type Props = {
  onPickCoding: () => void;
  onPickScenario: () => void;
  hasCodingPhase: boolean;
  /** True when a Visual Scenario Analysis phase already exists — the menu
   *  option must say so and the click opens it in EDIT mode (the caller's
   *  onPickScenario decides that; this just changes the label so the
   *  behaviour isn't surprising). */
  hasScenarioPhase: boolean;
  disableScenario: boolean;
};

const labelStyle: CSSProperties = {
  display: "block", fontSize: 12, fontWeight: 600, color: "var(--text-2)", marginBottom: 6,
};

type Choice = "" | "coding" | "scenario";

export function AddPhasesMenu({
  onPickCoding, onPickScenario, hasCodingPhase, hasScenarioPhase, disableScenario,
}: Props) {
  const [open, setOpen] = useState(false);
  const [picked, setPicked] = useState<Choice>("");

  const close = () => { setOpen(false); setPicked(""); };

  const continueToModal = () => {
    close();
    if (picked === "coding") onPickCoding();
    else if (picked === "scenario") onPickScenario();
  };

  const description =
    picked === "coding" ? (hasCodingPhase
      ? "Opens the existing coding phase so you can add more questions."
      : "A live coding exercise — the candidate writes a function in the editor, checked against your test cases.")
    : picked === "scenario" ? (hasScenarioPhase
      ? "Opens the existing Visual Scenario Analysis phase so you can add more questions."
      : "Show the candidate an image, video, or audio clip and ask a question about it.")
    : "Pick which kind of phase to add; its settings open next.";

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="btn"
        style={{
          background: "var(--ds-lavender)", color: "var(--ds-accent-ink)",
          borderColor: "transparent", fontWeight: 700,
        }}
      >
        + Add phases
      </button>

      {open && createPortal(
        <div
          role="dialog"
      className="ds-light"
          aria-modal="true"
          onClick={close}
          style={{
            position: "fixed", inset: 0, background: "rgba(22,22,22,0.35)",
            zIndex: 5000, display: "flex", alignItems: "center",
            justifyContent: "center", padding: 20,
          }}
        >
          <div
            className="card"
            onClick={(e) => e.stopPropagation()}
            style={{
              width: "100%", maxWidth: 480, overflow: "hidden",
              display: "flex", flexDirection: "column", padding: 0,
              background: "var(--ink-2)", border: "1px solid var(--line-2)",
            }}
          >
            {/* Header */}
            <div style={{
              display: "flex", alignItems: "center", justifyContent: "space-between",
              padding: "14px 16px", borderBottom: "1px solid var(--line)",
            }}>
              <h2 style={{ fontSize: 16, fontWeight: 700, margin: 0 }}>Add phase</h2>
              <button
                type="button" onClick={close} className="btn btn-ghost btn-sm"
                aria-label="Close" style={{ padding: "4px 10px" }}
              >
                ✕
              </button>
            </div>

            {/* Body */}
            <div style={{ padding: "14px 16px", display: "flex", flexDirection: "column", gap: 14 }}>
              <div>
                <label style={labelStyle} htmlFor="phase-type-picker">Phase type</label>
                <select
                  id="phase-type-picker"
                  value={picked}
                  onChange={(e) => setPicked(e.target.value as Choice)}
                  className="input"
                  style={{ width: "100%" }}
                >
                  <option value="">Select a phase type…</option>
                  <option value="coding">{hasCodingPhase ? "Edit coding phase" : "Coding"}</option>
                  <option value="scenario" disabled={disableScenario}>
                    {hasScenarioPhase ? "Visual Scenario Analysis (edit)" : "Visual Scenario Analysis"}
                  </option>
                </select>
                <p className="muted-3" style={{ fontSize: 12, margin: "6px 0 0" }}>
                  {description}
                </p>
                {disableScenario && (
                  <p className="muted-3" style={{ fontSize: 11.5, margin: "4px 0 0" }}>
                    Visual Scenario Analysis needs a voice/video interview — this interview is text-only.
                  </p>
                )}
              </div>
            </div>

            {/* Footer */}
            <div style={{
              display: "flex", alignItems: "center", justifyContent: "flex-end",
              gap: 8, padding: "12px 16px", borderTop: "1px solid var(--line)",
            }}>
              <button type="button" onClick={close} className="btn btn-ghost btn-sm">
                Cancel
              </button>
              <button
                type="button"
                onClick={continueToModal}
                disabled={!picked}
                className="btn btn-sm"
                style={{
                  background: "var(--ds-lavender)", color: "var(--ds-accent-ink)",
                  borderColor: "transparent", fontWeight: 600,
                }}
              >
                Continue
              </button>
            </div>
          </div>
        </div>,
        document.body,
      )}
    </>
  );
}
