import { Component } from "react";
import type { ErrorInfo, ReactNode } from "react";

// Catches render errors anywhere in the app so a crash shows a friendly
// screen with a way out instead of a blank page.
export class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state: { error: Error | null } = { error: null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("Unhandled UI error", error, info.componentStack);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div
        className="ds-light"
        role="alert"
        style={{ position: "fixed", inset: 0, zIndex: 10000, display: "grid", placeItems: "center", padding: 24, background: "var(--ds-bg)" }}
      >
        <div className="card" style={{ maxWidth: 440, width: "100%", padding: "36px 32px", textAlign: "center" }}>
          <div style={{ width: 48, height: 48, margin: "0 auto", borderRadius: "50%", display: "grid", placeItems: "center", background: "var(--ds-danger-soft)", color: "#991b1b" }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="13" /><circle cx="12" cy="16.5" r="0.6" fill="currentColor" stroke="none" />
            </svg>
          </div>
          <h1 className="page-title" style={{ marginTop: 16, fontSize: 24 }}>Something went wrong</h1>
          <p className="muted" style={{ marginTop: 8, fontSize: 14.5, lineHeight: 1.55 }}>
            An unexpected error stopped this page. Reloading usually fixes it.
          </p>
          <button type="button" className="btn btn-primary" style={{ marginTop: 20 }} onClick={() => window.location.reload()}>
            Reload page
          </button>
        </div>
      </div>
    );
  }
}
