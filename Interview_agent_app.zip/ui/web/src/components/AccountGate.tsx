// The two pages that are not a workspace: no role yet, and a real page the
// person is not allowed to open. Both are one card, on purpose.
import { Link } from "react-router-dom";
import { roleLine, useLogout, type MePermissions } from "../lib/auth";
import { Logo } from "./Logo";

export function NoAccess() {
  return (
    <div className="screen-enter" style={{ maxWidth: 460 }}>
      <div className="card" style={{ padding: 28 }}>
        <h1 className="page-title" style={{ fontSize: 22 }}>You don't have access to this page</h1>
        <p className="muted" style={{ marginTop: 8 }}>Ask a platform administrator if you need it.</p>
        <Link to="/" className="btn btn-primary" style={{ marginTop: 16, display: "inline-block", textDecoration: "none" }}>
          Back to Welcome
        </Link>
      </div>
    </div>
  );
}

export function AccountGate({ person, turnedOff }: { person: MePermissions; turnedOff?: boolean }) {
  const logout = useLogout();
  return (
    <div className="ds-light" style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 24, background: "var(--ds-bg)" }}>
      <div className="card screen-enter" style={{ width: "100%", maxWidth: 440, padding: 30 }}>
        <Logo sub="Interview Agent" />
        <h1 className="page-title" style={{ fontSize: 22, marginTop: 14 }}>
          {person.display_name || person.email}
        </h1>
        <p className="muted" style={{ marginTop: 4 }}>{person.email}</p>
        <p style={{ marginTop: 16, lineHeight: 1.5 }}>
          {turnedOff
            ? "This account is turned off."
            : "Your account does not have access yet. Ask a platform administrator to assign your role and team."}
        </p>
        {(person.roles ?? []).length > 0 && (
          <p className="muted" style={{ marginTop: 8 }}>{person.roles!.map(roleLine).join(", ")}</p>
        )}
        <button
          type="button"
          className="btn btn-primary"
          style={{ marginTop: 18, width: "100%" }}
          onClick={() => logout.mutate()}
        >
          Sign out
        </button>
      </div>
    </div>
  );
}
