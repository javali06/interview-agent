// Per-phase evaluation-plan editor, split so the per-phase plugin card can sit
// INSIDE each cadence phase row (replacing the old rubric column) while shared
// state lives in one hook:
//   useEvalPlan(token, yaml)  — catalog + plan + handlers (one instance)
//   <EvalPlanToolbar api/>    — Generate / Validate / Save + status line
//   <EvalPhaseCard api phaseId/> — one phase's plugin picker + config + hints
//
// "Validate" runs each enabled plugin's declared assumptions against the live
// cadence and shows per-card hints; disabled (not-scored) phases are skipped.
// Themed to the app's dark design tokens. Cards scroll internally (configs can
// be long). Self-hides when the plugin feature is off (catalog GET 404s).
import { useEffect, useMemo, useState } from "react";
import SchemaForm from "./SchemaForm";
import CriteriaEditor from "./CriteriaEditor";
import {
  type Criterion,
  type EvaluationPlan,
  type PluginAssignment,
  type PluginCatalogEntry,
  type PluginHelp,
  type PluginValidation,
  fetchEvalPlan,
  generateEvalPlan,
  listEvalPlugins,
  saveEvalPlan,
  validateEvalPlan,
} from "../lib/evalPlan";

// Where the panel reports outcomes. Messages go to the app's bottom-right toast
// (NOT inline in the evaluation box) so the evaluation box never shows raw
// errors/warnings.
export type EvalNotify = { success: (s: string) => void; error: (s: string) => void };

export type EvalPlanApi = {
  catalog: PluginCatalogEntry[] | null;
  disabled: boolean;
  plan: EvaluationPlan | null;
  busy: boolean;
  valid: Record<string, Record<string, PluginValidation>>;
  byId: Record<string, PluginCatalogEntry>;
  assignmentFor: (phaseId: string) => PluginAssignment | undefined;
  setAssignment: (phaseId: string, next: Partial<PluginAssignment>) => void;
  onGenerate: () => Promise<void>;
  onValidate: () => Promise<void>;
  onSave: () => Promise<void>;
  // Approval gate. `hasChosen`: any phase has an enabled plugin picked.
  // `validatedOk`: null = not validated against the current plan/cadence yet;
  // true/false = last Validate result. `dirty`: edited since last Save (the
  // server gate reads the SAVED plan). `ready`: ok to approve — feature off, OR
  // nothing chosen, OR (chosen AND validated green AND saved).
  hasChosen: boolean;
  validatedOk: boolean | null;
  dirty: boolean;
  ready: boolean;
};

export function useEvalPlan(token: string, yaml: string, notify: EvalNotify): EvalPlanApi {
  const [catalog, setCatalog] = useState<PluginCatalogEntry[] | null>(null);
  const [disabled, setDisabled] = useState(false);
  const [plan, setPlan] = useState<EvaluationPlan | null>(null);
  const [busy, setBusy] = useState(false);
  const [valid, setValid] = useState<Record<string, Record<string, PluginValidation>>>({});
  // Approval gate (see EvalPlanApi). null until the operator runs Validate.
  const [validatedOk, setValidatedOk] = useState<boolean | null>(null);
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    listEvalPlugins()
      .then((res) => { if (!res) { setDisabled(true); return; } setCatalog(res.plugins || []); })
      .catch(() => setDisabled(true));
    fetchEvalPlan(token).then((res) => { if (res?.plan) setPlan(res.plan); }).catch(() => {});
  }, [token]);

  // Editing the cadence (yaml) invalidates any prior validation — clear the
  // hints so a stale "needs fixing" doesn't linger and read as "not reflected".
  // The user re-runs Validate against the now-current cadence. Assumptions may
  // now fail, so the approval gate must re-validate too.
  useEffect(() => { setValid({}); setValidatedOk(null); }, [yaml]);

  const byId = useMemo(() => {
    const m: Record<string, PluginCatalogEntry> = {};
    for (const p of catalog || []) m[p.id] = p;
    return m;
  }, [catalog]);

  const assignmentFor = (phaseId: string) =>
    plan?.phases.find((p) => p.phase_id === phaseId)?.plugins?.[0];

  const setAssignment = (phaseId: string, next: Partial<PluginAssignment>) => {
    setValid({});  // any edit invalidates the prior validation
    setValidatedOk(null);
    setDirty(true);  // edited since last save → must re-save before approve
    setPlan((prev) => {
      const base: EvaluationPlan = prev ? structuredClone(prev) : { phases: [] };
      let ph = base.phases.find((p) => p.phase_id === phaseId);
      if (!ph) { ph = { phase_id: phaseId, plugins: [] }; base.phases.push(ph); }
      const cur = ph.plugins[0] || { plugin_id: "", config: {}, enabled: true };
      ph.plugins[0] = { ...cur, ...next };
      return base;
    });
  };

  const onGenerate = async () => {
    setBusy(true); setValid({}); setValidatedOk(null);
    try {
      const res = await generateEvalPlan(token, yaml);
      // Generate persists server-side, so the plan is saved (not dirty).
      if (res.plan) {
        setPlan(res.plan); setDirty(false);
        notify.success(res.ai_used === false
          ? "Evaluation plan created (AI unavailable — pick plugins per phase, then Validate)."
          : "Auto-selected and configured the best-fit plugin per phase. Review, edit if needed, then Validate.");
      }
      else notify.error(res.error || "Couldn't generate the evaluation plan.");
    } catch (e) { notify.error((e as Error).message || "Couldn't generate the evaluation plan."); } finally { setBusy(false); }
  };

  const onValidate = async () => {
    if (!plan) return;
    setBusy(true);
    try {
      const res = await validateEvalPlan(token, yaml, plan);
      const idx: Record<string, Record<string, PluginValidation>> = {};
      for (const ph of res.results || []) {
        idx[ph.phase_id] = {};
        for (const pl of ph.plugins) idx[ph.phase_id][pl.plugin_id] = pl;
      }
      setValid(idx);
      setValidatedOk(!!res.all_ok);
      if (res.all_ok) notify.success("All chosen evaluation plugins pass validation.");
      else notify.error("Some evaluation plugins need attention — see the hints on each phase.");
    } catch (e) { setValidatedOk(false); notify.error((e as Error).message || "Couldn't validate the evaluation plan."); } finally { setBusy(false); }
  };

  const onSave = async () => {
    if (!plan) return;
    setBusy(true);
    try {
      const res = await saveEvalPlan(token, plan);
      if (res.plan) { setPlan(res.plan); setDirty(false); notify.success("Evaluation plan saved."); }
      else notify.error(res.error || "Couldn't save the evaluation plan.");
    } catch (e) { notify.error((e as Error).message || "Couldn't save the evaluation plan."); } finally { setBusy(false); }
  };

  // Any phase with an enabled plugin picked? (empty plugin_id / disabled = not
  // chosen). No plugin chosen anywhere → approval needs no validation.
  const hasChosen = (plan?.phases || []).some(
    (ph) => (ph.plugins || []).some((a) => a.enabled !== false && !!a.plugin_id),
  );
  const ready = disabled || !hasChosen || (validatedOk === true && !dirty);

  return {
    catalog, disabled, plan, busy, valid, byId, assignmentFor, setAssignment,
    onGenerate, onValidate, onSave, hasChosen, validatedOk, dirty, ready,
  };
}

export function EvalPlanToolbar({ api }: { api: EvalPlanApi }) {
  if (api.disabled) return <span className="muted-3" style={{ fontSize: 11 }}>disabled</span>;
  return (
    <div style={{ display: "flex", gap: 6 }}>
      <button type="button" disabled={api.busy} onClick={api.onGenerate} className="btn btn-ghost btn-sm">
        {api.plan ? "Regenerate" : "Generate"}
      </button>
      <button type="button" disabled={api.busy || !api.plan} onClick={api.onValidate} className="btn btn-ghost btn-sm">Validate</button>
      <button type="button" disabled={api.busy || !api.plan} onClick={api.onSave} className="btn btn-sm"
        style={{ background: "var(--ds-lavender)", color: "var(--ds-accent-ink)", borderColor: "transparent", fontWeight: 600 }}>
        Save
      </button>
    </div>
  );
}

// Plain-language "what is this plugin" help, shown at the top of the card so a
// TA picks a plugin on purpose instead of guessing from its name. Collapsible
// (open by default) so it gets out of the way once you know the plugin.
function PluginHelpBox({ help, method }: { help?: PluginHelp; method: string }) {
  if (!help) return null;
  const methodLabel = method === "llm_judge" ? "LLM judges, code scores" : "Deterministic (no LLM)";
  return (
    <details open style={{ marginBottom: 10 }}>
      <summary style={{ cursor: "pointer", fontSize: 12, fontWeight: 600, color: "var(--text)" }}>
        ⓘ What this plugin does
      </summary>
      <div className="card" style={{ marginTop: 6, padding: "10px 12px", fontSize: 12, lineHeight: 1.5 }}>
        <div style={{ marginBottom: 8 }}>{help.summary}</div>
        {help.best_for && (
          <div style={{ marginBottom: 8 }}>
            <span style={{ fontWeight: 600, color: "var(--text)" }}>Best for: </span>
            <span className="muted">{help.best_for}</span>
          </div>
        )}
        {help.how_it_works?.length > 0 && (
          <div style={{ marginBottom: 8 }}>
            <span style={{ fontWeight: 600, color: "var(--text)" }}>How it scores:</span>
            <ol style={{ margin: "3px 0 0", paddingLeft: 18 }}>
              {help.how_it_works.map((s, i) => <li key={i} className="muted" style={{ marginBottom: 2 }}>{s}</li>)}
            </ol>
          </div>
        )}
        {help.you_configure?.length > 0 && (
          <div style={{ marginBottom: 8 }}>
            <span style={{ fontWeight: 600, color: "var(--text)" }}>You configure:</span>
            <ul style={{ margin: "3px 0 0", paddingLeft: 18 }}>
              {help.you_configure.map((s, i) => <li key={i} className="muted" style={{ marginBottom: 2 }}>{s}</li>)}
            </ul>
          </div>
        )}
        {help.evidence && (
          <div className="muted-3" style={{ marginBottom: 6 }}>
            <span style={{ fontWeight: 600 }}>Evidence shown:</span> {help.evidence}
          </div>
        )}
        <div className="muted-3" style={{ fontSize: 11 }}>Method: {methodLabel}</div>
      </div>
    </details>
  );
}

export function EvalPhaseCard({ api, phaseId }: { api: EvalPlanApi; phaseId: string }) {
  if (api.disabled) return <p className="muted-3" style={{ fontSize: 13 }}>Evaluation plugins disabled.</p>;
  if (!api.catalog) return <p className="muted-3" style={{ fontSize: 13 }}>Loading plugins…</p>;

  const a = api.assignmentFor(phaseId);
  const entry = a ? api.byId[a.plugin_id] : undefined;
  const v = a ? api.valid[phaseId]?.[a.plugin_id] : undefined;
  // Default UNSCORED: a phase with no assignment starts unchecked so the
  // operator opts IN to scoring ("only score what I pick"), rather than every
  // phase silently defaulting to scored.
  const scored = a?.enabled ?? false;

  return (
    <div className="card" style={{ padding: 14, maxHeight: 460, overflowY: "auto" }}>
      <div style={{ marginBottom: 10, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
        <label className="muted" style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12 }}>
          <input type="checkbox" checked={scored}
            onChange={(e) => api.setAssignment(phaseId, { enabled: e.target.checked })} />
          scored
        </label>
        <select className="input" style={{ width: "auto", maxWidth: "100%" }}
          value={a?.plugin_id || ""}
          onChange={(e) => {
            const pe = api.byId[e.target.value];
            api.setAssignment(phaseId, { plugin_id: e.target.value, config: pe ? { ...pe.default_config } : {} });
          }}>
          <option value="">— choose plugin —</option>
          {api.catalog.map((p) => (
            <option key={p.id} value={p.id}>{p.name} ({p.method === "llm_judge" ? "LLM" : "Python"})</option>
          ))}
        </select>
      </div>

      {!entry ? (
        <p className="muted-3" style={{ fontSize: 12 }}>Pick a plugin to score this phase.</p>
      ) : (
        <>
          <PluginHelpBox help={entry.help} method={entry.method} />

          {/* What the AUTHOR must provide to score this phase. Runtime/dev-only
              preconditions (candidate answer present, LLM key set) are hidden —
              the TA can't act on those. Always visible so the requirements are
              clear before/after validation. */}
          {(() => {
            const needs = entry.assumptions.filter((x) => x.author_actionable !== false);
            return needs.length > 0 ? (
              <div className="muted-3" style={{ marginBottom: 8, fontSize: 11 }}>
                <span style={{ fontWeight: 600 }}>Needs to score this phase:</span>
                <ul style={{ margin: "2px 0 0", paddingLeft: 16 }}>
                  {needs.map((x, i) => <li key={i}>{x.description}</li>)}
                </ul>
              </div>
            ) : null;
          })()}

          {/* Validation result against the CURRENT cadence (re-run Validate
              after editing the cadence — hints reset on every cadence change). */}
          {scored && v && (v.ok ? (
            <div style={{ marginBottom: 10, fontSize: 12, color: "var(--ok)" }}>
              ✓ passes validation against the current cadence
            </div>
          ) : (
            <div className="card" style={{ marginBottom: 10, padding: "9px 12px", fontSize: 12,
              color: "#92400e", borderColor: "transparent", background: "var(--ds-warning-soft)" }}>
              <span style={{ fontWeight: 600 }}>Fix these, then re-validate:</span>
              <ul style={{ margin: "4px 0 0", paddingLeft: 18 }}>
                {v.unmet.map((u, i) => <li key={i}>{u}</li>)}
              </ul>
            </div>
          ))}

          {/* rubric_marks gets a dedicated per-option row editor for `criteria`
              (separate textboxes per option); the rest of its config + every
              other plugin's config render generically from the JSON-schema. */}
          {entry.id === "rubric_marks" ? (
            <>
              <CriteriaEditor
                value={(a?.config?.criteria as Criterion[]) || []}
                onChange={(criteria) => api.setAssignment(phaseId, { config: { ...(a?.config || {}), criteria } })}
              />
              <SchemaForm
                schema={entry.config_json_schema}
                value={a?.config || {}}
                onChange={(cfg) => api.setAssignment(phaseId, { config: cfg })}
                omit={["criteria"]}
              />
            </>
          ) : (
            <SchemaForm
              schema={entry.config_json_schema}
              value={a?.config || {}}
              onChange={(cfg) => api.setAssignment(phaseId, { config: cfg })}
            />
          )}
        </>
      )}
    </div>
  );
}
