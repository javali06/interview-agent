// Generic config form rendered from a plugin's JSON-schema (from
// GET /api/eval/plugins). Handles the field types the built-in plugin configs
// use — number/integer, string, boolean, enum (select), string[] (chips) — and
// falls back to a validated JSON textarea for complex shapes (objects,
// arrays-of-objects like rubric criteria, dicts like difficulty_marks). This is
// why adding a plugin needs no bespoke frontend: its config form is derived.
// Styled with the app's dark design tokens (.input + var(--*)).
import { useState, type ReactNode } from "react";
import type { JsonSchema, JsonSchemaProp } from "../lib/evalPlan";

type Props = {
  schema: JsonSchema;
  value: Record<string, unknown>;
  onChange: (next: Record<string, unknown>) => void;
  // Field names to NOT render here (a parent renders them with a custom editor,
  // e.g. rubric_marks' `criteria` row editor).
  omit?: string[];
};

const labelStyle = {
  marginBottom: 4, fontSize: 11, fontWeight: 600, letterSpacing: "0.06em",
  textTransform: "uppercase" as const, color: "var(--text-3)",
};

function typeOf(p: JsonSchemaProp): string {
  const t = Array.isArray(p.type) ? p.type.find((x) => x !== "null") : p.type;
  return t || "string";
}

// Concrete sample content for fields whose generic placeholder ("one per
// line", or nothing at all) gave no hint of what a valid entry looks like.
// Keyed by field name; anything not listed keeps the generic fallback so a
// new plugin's field still gets *something* rather than nothing.
const ARRAY_PLACEHOLDERS: Record<string, string> = {
  score_dimensions: "technical_depth\nrole_fit",
  ignore_dimensions: "filler words\nenergy",
  required_tags: "train vs validation gap\nscaled dot-product scores",
};

const STRING_PLACEHOLDERS: Record<string, string> = {
  purpose: "e.g. Assess depth of the candidate's system-design reasoning",
  seniority_bar: "e.g. Senior — expects independent design tradeoffs, not just a working answer",
};

function Field({ name, prop, value, onChange }: {
  name: string; prop: JsonSchemaProp; value: unknown; onChange: (v: unknown) => void;
}) {
  const label = prop.title || name;
  const t = typeOf(prop);

  let control: ReactNode;
  if (prop.enum && prop.enum.length) {
    control = (
      <select className="input" value={String(value ?? "")} onChange={(e) => onChange(e.target.value)}>
        {prop.enum.map((o) => <option key={String(o)} value={String(o)}>{String(o)}</option>)}
      </select>
    );
  } else if (t === "boolean") {
    control = (
      <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 14 }}>
        <input type="checkbox" checked={Boolean(value)} onChange={(e) => onChange(e.target.checked)} />
        <span className="muted">{prop.description || "enabled"}</span>
      </label>
    );
  } else if (t === "number" || t === "integer") {
    control = (
      <input
        type="number" className="input"
        value={value === undefined || value === null ? "" : String(value)}
        min={prop.minimum} max={prop.maximum}
        step={t === "integer" ? 1 : "any"}
        onChange={(e) => onChange(e.target.value === "" ? null : Number(e.target.value))}
      />
    );
  } else if (t === "array" && (!prop.items || typeOf(prop.items) === "string")) {
    const arr = Array.isArray(value) ? (value as unknown[]).map(String) : [];
    control = (
      <textarea
        className="input" rows={2} placeholder={ARRAY_PLACEHOLDERS[name] || "one per line"}
        value={arr.join("\n")}
        onChange={(e) => onChange(e.target.value.split("\n").map((s) => s.trim()).filter(Boolean))}
      />
    );
  } else if (t === "string") {
    control = (
      <input
        className="input" placeholder={STRING_PLACEHOLDERS[name]}
        value={String(value ?? "")} onChange={(e) => onChange(e.target.value)}
      />
    );
  } else {
    control = <JsonField value={value} onChange={onChange} />;
  }

  return (
    <div style={{ marginBottom: 12 }}>
      <div style={labelStyle}>{label}</div>
      {control}
      {prop.description && t !== "boolean" && (
        <div className="muted-3" style={{ marginTop: 4, fontSize: 11 }}>{prop.description}</div>
      )}
    </div>
  );
}

function JsonField({ value, onChange }: { value: unknown; onChange: (v: unknown) => void }) {
  const [text, setText] = useState(() => JSON.stringify(value ?? null, null, 2));
  const [err, setErr] = useState<string | null>(null);
  return (
    <div>
      <textarea
        className="input mono" rows={6} spellCheck={false} style={{ fontSize: 12 }}
        value={text}
        onChange={(e) => {
          setText(e.target.value);
          try { onChange(JSON.parse(e.target.value)); setErr(null); }
          catch (x) { setErr((x as Error).message); }
        }}
      />
      {err && <div style={{ marginTop: 4, fontSize: 11, color: "var(--danger)" }}>invalid JSON: {err}</div>}
    </div>
  );
}

export default function SchemaForm({ schema, value, onChange, omit }: Props) {
  const props = schema.properties || {};
  const skip = new Set(omit || []);
  return (
    <div>
      {Object.entries(props).filter(([name]) => !skip.has(name)).map(([name, prop]) => (
        <Field
          key={name} name={name} prop={prop}
          value={value[name] ?? prop.default}
          onChange={(v) => onChange({ ...value, [name]: v })}
        />
      ))}
    </div>
  );
}
