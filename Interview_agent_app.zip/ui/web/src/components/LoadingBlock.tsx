// Loading skeleton for light pages: shimmering placeholder rows plus the
// original "Loading…" text (kept for screen readers and as a plain cue).
export function LoadingBlock({ label, rows = 3 }: { label: string; rows?: number }) {
  return (
    <div className="ds-loading" role="status" aria-live="polite" style={{ marginTop: 20 }}>
      <span className="ds-loading-label">{label}</span>
      {Array.from({ length: rows }, (_, i) => (
        <span key={i} className="ds-skeleton" style={{ height: 44, width: i % 3 === 2 ? "70%" : "100%" }} />
      ))}
    </div>
  );
}
