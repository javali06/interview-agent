// The view-template catalog: view_id → { SummaryTile (per phase), DetailView
// (per plugin result) }. The evaluation UI OWNS these templates; a plugin only
// references one by `view_id` (a foreign key). Add a new visualization by adding
// a DetailView here and registering it — no changes to the evaluation page.
// Styled with the app's dark design tokens (var(--*) + .card/.muted/.pill).
import { useState } from "react";
import type { CSSProperties, ReactElement } from "react";
import EvidenceTurns from "./EvidenceTurns";
import { REASON_KINDS } from "./types";
import type {
  BenchPhase, DetailViewProps, PluginResult, ReasonKind, ReviewApi, SegResult,
} from "./types";

const fmt = (n: number) => (Number.isInteger(n) ? String(n) : n.toFixed(1));

export function marks(earned: number, possible: number): string {
  return `${fmt(earned)} / ${fmt(possible)}`;
}

const STATE_LABEL: Record<string, string> = {
  not_observed: "no data — not reached",
  insufficient_evidence: "insufficient evidence",
  assumptions_unmet: "plugin requirements unmet",
  error: "scoring error",
};

const cardStyle: CSSProperties = {
  border: "1px solid var(--line)", background: "var(--panel)", color: "var(--text)",
  borderRadius: "var(--radius-sm)", padding: 12,
};

function deltaColor(d: number): string {
  return d < 0 ? "var(--danger)" : "var(--ok)";
}

// The actual content a written-response question asked the candidate to work
// from (comprehensive / transcription / translation / image_description) —
// shown ABOVE the raw evidence transcript so the real question material is
// visible instead of relying on the AI's (LLM-paraphrased) dispatch line
// buried in that transcript. `evidence` itself is left untouched: nothing is
// removed, so the "jump to trace" affordance on every turn still works.
// `seg.question_type` is null for every other phase (coding, conversational
// rounds, etc.) — this renders nothing there, by construction.
const questionMaterialLabelStyle: CSSProperties = {
  fontSize: 11, fontWeight: 600, letterSpacing: "0.04em", textTransform: "uppercase",
  color: "var(--text-3)", marginBottom: 4,
};
const questionMaterialBoxStyle: CSSProperties = {
  marginTop: 8, padding: "8px 10px", borderRadius: 8,
  border: "1px solid var(--line)", background: "var(--ink-2)",
};

function QuestionMaterial({ seg }: { seg: SegResult }) {
  switch (seg.question_type) {
    case "comprehensive":
      if (!seg.question_text) return null;
      return (
        <div style={questionMaterialBoxStyle}>
          <div style={questionMaterialLabelStyle}>Question</div>
          <div style={{ fontSize: 13, whiteSpace: "pre-wrap" }}>{seg.question_text}</div>
        </div>
      );
    case "translation":
      if (!seg.source_text) return null;
      return (
        <div style={questionMaterialBoxStyle}>
          <div style={questionMaterialLabelStyle}>Source text to translate</div>
          <div style={{ fontSize: 13, whiteSpace: "pre-wrap" }}>{seg.source_text}</div>
        </div>
      );
    case "transcription":
      if (!seg.audio_url) return null;
      return (
        <div style={questionMaterialBoxStyle}>
          <div style={questionMaterialLabelStyle}>Audio</div>
          <audio controls src={seg.audio_url} style={{ width: "100%" }} />
        </div>
      );
    case "image_description":
      if (!seg.image_url) return null;
      return (
        <div style={questionMaterialBoxStyle}>
          <div style={questionMaterialLabelStyle}>Image</div>
          <img
            src={seg.image_url}
            alt="Question image"
            style={{ maxWidth: "100%", maxHeight: 260, borderRadius: 8, border: "1px solid var(--line)" }}
          />
        </div>
      );
    default:
      return null;
  }
}


// ── human review ───────────────────────────────────────────────────────────
// The LLM scores; a person corrects it. The model's number is never replaced —
// it stays on screen next to the final one, because "the AI said 2.8 and a
// recruiter raised it to 4.0" is the auditable truth and "4.0" alone is not.
// What is editable comes from the PLUGIN's own declaration (`adjustable`), so a
// reviewer is never offered a slider for a unit-test result.

const inputStyle: CSSProperties = {
  width: 64, padding: "2px 6px", borderRadius: 6, border: "1px solid var(--line)",
  background: "var(--ink-2)", color: "var(--text)", font: "inherit", fontSize: 12,
  fontVariantNumeric: "tabular-nums", textAlign: "right",
};
const fieldStyle: CSSProperties = {
  width: "100%", padding: "6px 8px", borderRadius: 6, border: "1px solid var(--line)",
  background: "var(--ink-2)", color: "var(--text)", font: "inherit", fontSize: 12,
};

/** The header number: the reviewed mark when there is one, with the model's own
 *  kept visible beside it rather than replaced. */
function SegmentMarks({ seg }: { seg: SegResult }) {
  const rev = seg.review;
  const state = rev?.final_state ?? seg.state;
  if (state !== "scored")
    return <span className="muted-3">{STATE_LABEL[state] || state}</span>;
  if (!rev || rev.final_marks_earned === null)
    return <>{marks(seg.marks_earned, seg.marks_possible)}</>;
  const changed = rev.final_marks_earned !== seg.marks_earned;
  return (
    <span style={{ display: "inline-flex", alignItems: "baseline", gap: 8 }}>
      {changed && (
        <span className="muted-3" style={{ fontSize: 11, fontWeight: 400, textDecoration: "line-through" }}>
          AI {marks(seg.marks_earned, seg.marks_possible)}
        </span>
      )}
      <span>{marks(rev.final_marks_earned, rev.final_marks_possible ?? seg.marks_possible)}</span>
    </span>
  );
}

function ReviewSummary({ seg }: { seg: SegResult }) {
  const rev = seg.review;
  if (!rev) return null;
  return (
    <div style={{
      marginTop: 8, padding: "8px 10px", borderRadius: 8,
      border: "1px solid rgba(124,196,255,0.35)", background: "rgba(124,196,255,0.07)",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", fontSize: 11 }}>
        <span className="pill" style={{ fontSize: 10, textTransform: "uppercase" }}>Adjusted by a reviewer</span>
        {rev.reason_kind && (
          <span className="muted-3">
            {REASON_KINDS.find((r) => r.value === rev.reason_kind)?.label || rev.reason_kind}
          </span>
        )}
        <span className="muted-3" style={{ marginLeft: "auto" }}>
          {rev.reviewer}{rev.reviewed_at ? ` · ${rev.reviewed_at.slice(0, 16).replace("T", " ")}` : ""}
        </span>
      </div>
      {rev.stale && (
        <div style={{ marginTop: 6, fontSize: 12, color: "var(--warn)" }}>
          The AI&rsquo;s score changed since this adjustment was recorded — confirm it or redo it.
        </div>
      )}
      {rev.reason && <div className="muted" style={{ marginTop: 6, fontSize: 13 }}>{rev.reason}</div>}
      {rev.items.length > 0 && (
        <ul style={{ marginTop: 6, fontSize: 12, listStyle: "none", padding: 0, display: "flex", flexDirection: "column", gap: 2 }}>
          {rev.items.map((it, i) => (
            <li key={i} className="muted" style={{ display: "flex", justifyContent: "space-between", gap: 8 }}>
              <span>{it.label}</span>
              <span style={{ fontVariantNumeric: "tabular-nums" }}>
                {it.ai_value !== null && <span className="muted-3">{fmt(it.ai_value)} → </span>}
                {fmt(it.human_value)}
              </span>
            </li>
          ))}
        </ul>
      )}
      {rev.notes.map((n, i) => (
        <div key={i} className="muted" style={{ marginTop: 6, fontSize: 13, fontStyle: "italic" }}>{n}</div>
      ))}
    </div>
  );
}

function ReviewEditor({ seg, api, onClose }: {
  seg: SegResult; api: ReviewApi; onClose: () => void;
}) {
  const adj = seg.adjustable;
  const rev = seg.review;
  const canItems = !!adj?.items && seg.breakdown.length > 0;
  // Prefill from the current state — the reviewer's own last values when they
  // have reviewed before, the model's otherwise. Editing an existing review is
  // a correction OF it, not a fresh one on top.
  const [items, setItems] = useState<Record<string, string>>(() => {
    const out: Record<string, string> = {};
    for (const b of seg.breakdown) {
      const prev = rev?.items.find((i) => i.label === b.label);
      out[b.label] = String(prev ? prev.human_value : b.delta);
    }
    return out;
  });
  const [total, setTotal] = useState<string>("");
  const [reasonKind, setReasonKind] = useState<ReasonKind>(rev?.reason_kind || "ai_misread");
  const [reason, setReason] = useState(rev?.reason || "");
  const [note, setNote] = useState("");

  // Only send what actually moved, so a record always means "a human changed
  // this" rather than "a human opened the form".
  const changedItems: Record<string, number> = {};
  if (canItems)
    for (const b of seg.breakdown) {
      const v = Number(items[b.label]);
      if (Number.isFinite(v) && v !== b.delta) changedItems[b.label] = v;
    }
  const totalNum = total.trim() === "" ? null : Number(total);
  const totalValid = totalNum === null || (Number.isFinite(totalNum) && totalNum >= 0 && totalNum <= seg.marks_possible);
  const somethingChanged =
    Object.keys(changedItems).length > 0 || totalNum !== null || note.trim() !== "";
  const canSave = somethingChanged && reason.trim() !== "" && totalValid && !api.busy;

  const submit = async () => {
    if (!canSave) return;
    await api.save({
      segment_id: seg.segment_id, section: seg.section || "",
      items: changedItems, marks_earned: totalNum,
      reason_kind: reasonKind, reason: reason.trim(), note: note.trim(),
    });
    onClose();
  };

  const scaleHi = adj?.item_scale?.[1];
  return (
    <div style={{
      marginTop: 8, padding: 10, borderRadius: 8,
      border: "1px solid var(--line)", background: "var(--ink-2)",
      display: "flex", flexDirection: "column", gap: 8,
    }}>
      {canItems && (
        <div>
          <div className="muted-3" style={{ fontSize: 11, marginBottom: 4 }}>
            Adjust each {adj?.item_label_noun || "item"}
            {scaleHi ? ` (0–${fmt(scaleHi)})` : ""}
            {adj?.recompute !== "none" && " — the marks recompute from these"}
          </div>
          <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 4 }}>
            {seg.breakdown.map((b) => (
              <li key={b.label} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12 }}>
                <span className="muted" style={{ flex: 1, minWidth: 0 }}>{b.label}</span>
                <span className="muted-3" style={{ fontSize: 11 }}>AI {fmt(b.delta)}</span>
                <input type="number" step="0.5" style={inputStyle} value={items[b.label] ?? ""}
                       onChange={(e) => setItems((o) => ({ ...o, [b.label]: e.target.value }))} />
              </li>
            ))}
          </ul>
        </div>
      )}

      {adj?.marks !== false && (
        <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12 }}>
          <span className="muted" style={{ flex: 1 }}>
            Or set the marks directly{canItems ? " (overrides the recompute)" : ""}
          </span>
          <span className="muted-3" style={{ fontSize: 11 }}>of {fmt(seg.marks_possible)}</span>
          <input type="number" step="0.5" min={0} max={seg.marks_possible} style={inputStyle}
                 value={total} placeholder={fmt(seg.marks_earned)}
                 onChange={(e) => setTotal(e.target.value)} />
        </label>
      )}
      {!totalValid && (
        <div style={{ fontSize: 12, color: "var(--danger)" }}>
          Marks must be between 0 and {fmt(seg.marks_possible)}. What a question is worth is a cadence
          change, not a review — two candidates scored out of different totals aren&rsquo;t comparable.
        </div>
      )}

      <label style={{ display: "flex", flexDirection: "column", gap: 4, fontSize: 12 }}>
        <span className="muted-3" style={{ fontSize: 11 }}>Why? (required)</span>
        <select style={fieldStyle} value={reasonKind}
                onChange={(e) => setReasonKind(e.target.value as ReasonKind)}>
          {REASON_KINDS.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
        </select>
        <textarea style={{ ...fieldStyle, minHeight: 54, resize: "vertical" }} value={reason}
                  placeholder="What did the AI get wrong, and how do you know?"
                  onChange={(e) => setReason(e.target.value)} />
      </label>

      <label style={{ display: "flex", flexDirection: "column", gap: 4, fontSize: 12 }}>
        <span className="muted-3" style={{ fontSize: 11 }}>Note for the record (optional)</span>
        <textarea style={{ ...fieldStyle, minHeight: 38, resize: "vertical" }} value={note}
                  onChange={(e) => setNote(e.target.value)} />
      </label>

      {api.error && <div style={{ fontSize: 12, color: "var(--danger)" }}>{api.error}</div>}
      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
        <button type="button" className="btn btn-sm btn-primary" disabled={!canSave} onClick={submit}>
          {api.busy ? "Saving…" : "Save adjustment"}
        </button>
        <button type="button" className="btn btn-sm" onClick={onClose}>Cancel</button>
        {rev && (
          <button type="button" className="btn btn-sm" style={{ marginLeft: "auto" }}
                  disabled={api.busy}
                  onClick={async () => {
                    await api.withdraw(seg.segment_id, seg.section || "");
                    onClose();
                  }}>
            Remove adjustment
          </button>
        )}
      </div>
      <div className="muted-3" style={{ fontSize: 11 }}>
        The AI&rsquo;s own score is kept and stays visible — your adjustment is recorded beside it,
        not over it.
      </div>
    </div>
  );
}

// ── shared per-segment card (used by every DetailView) ──────────────────────
function SegmentCard({ seg, onJump, extra, review }: {
  seg: SegResult; onJump?: DetailViewProps["onJump"]; extra?: ReactElement | null;
  review?: ReviewApi;
}) {
  const title = seg.question_text || seg.question_id || seg.segment_id;
  const [editing, setEditing] = useState(false);
  // Only offer the affordance where the plugin declared one and there is an
  // address to post to; a segment from a pre-review export has neither.
  const canReview = !!review && !!seg.section && (seg.adjustable?.marks !== false || !!seg.adjustable?.items);
  return (
    <div style={cardStyle}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12 }}>
        <div style={{ fontSize: 14, fontWeight: 600 }}>
          {title}
          {seg.difficulty && (
            <span className="pill" style={{ marginLeft: 8, fontSize: 10, textTransform: "uppercase" }}>{seg.difficulty}</span>
          )}
        </div>
        <div style={{ flexShrink: 0, display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ fontSize: 14, fontWeight: 700, fontVariantNumeric: "tabular-nums" }}>
            <SegmentMarks seg={seg} />
          </div>
          {canReview && (
            <button type="button" className="btn btn-sm" onClick={() => setEditing((v) => !v)}>
              {editing ? "Close" : seg.review ? "Edit adjustment" : "Adjust"}
            </button>
          )}
        </div>
      </div>
      {seg.rationale && <div className="muted" style={{ marginTop: 4, fontSize: 14 }}>{seg.rationale}</div>}
      <ReviewSummary seg={seg} />
      {editing && review && (
        <ReviewEditor seg={seg} api={review} onClose={() => setEditing(false)} />
      )}
      {extra}
      {seg.breakdown.length > 0 && (
        <ul style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 2, fontSize: 12, listStyle: "none", padding: 0 }}>
          {seg.breakdown.map((b, i) => (
            <li key={i} style={{ display: "flex", justifyContent: "space-between", gap: 8 }}>
              <span className="muted">{b.label}{b.detail ? ` — ${b.detail}` : ""}</span>
              {b.delta !== 0 && (
                <span style={{ fontVariantNumeric: "tabular-nums", color: deltaColor(b.delta) }}>
                  {b.delta > 0 ? "+" : ""}{fmt(b.delta)}
                </span>
              )}
            </li>
          ))}
        </ul>
      )}
      <QuestionMaterial seg={seg} />
      <EvidenceTurns evidence={seg.evidence} onJump={onJump} />
    </div>
  );
}

function CriteriaList({ seg }: { seg: SegResult }) {
  const criteria = (seg.grading?.criteria as Array<Record<string, unknown>>) || [];
  if (!criteria.length) return null;
  return (
    <ul style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 2, fontSize: 12, listStyle: "none", padding: 0 }}>
      {criteria.map((c, i) => (
        <li key={i} style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ color: c.selected ? "var(--ok)" : "var(--text-3)" }}>{c.selected ? "✓" : "✗"}</span>
          <span className="muted">{String(c.description)}</span>
          {typeof c.applied === "number" && c.applied !== 0 && (
            <span style={{ marginLeft: "auto", fontVariantNumeric: "tabular-nums", color: deltaColor(c.applied as number) }}>
              {(c.applied as number) > 0 ? "+" : ""}{fmt(c.applied as number)}
            </span>
          )}
        </li>
      ))}
    </ul>
  );
}

function makeDetailView(perSegmentExtra?: (seg: SegResult) => ReactElement | null) {
  return function DetailView({ result, onJump, review }: DetailViewProps) {
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {result.segments.map((seg) => (
          <SegmentCard key={seg.segment_id} seg={seg} onJump={onJump} review={review}
                       extra={perSegmentExtra ? perSegmentExtra(seg) : null} />
        ))}
      </div>
    );
  };
}

// ── per-view templates (one entry per view_id) ──────────────────────────────
const RubricOptionsView = makeDetailView((seg) => <CriteriaList seg={seg} />);
const TagChecklistView = makeDetailView();          // breakdown already lists tags
const DifficultyBreakdownView = makeDetailView();   // breakdown lists deductions
const DimensionCardView = makeDetailView();         // breakdown lists per-dimension scores
const CodingCardView = makeDetailView();            // breakdown lists pass-rate + dims
const DefaultView = makeDetailView();

const REGISTRY: Record<string, (p: DetailViewProps) => ReactElement> = {
  rubric_options: RubricOptionsView,
  tag_checklist: TagChecklistView,
  difficulty_breakdown: DifficultyBreakdownView,
  dimension_card: DimensionCardView,
  coding_card: CodingCardView,
};

export function getDetailView(viewId: string): (p: DetailViewProps) => ReactElement {
  return REGISTRY[viewId] || DefaultView;
}

// Shared per-PHASE summary tile (used for every view_id — the tile content is
// uniform: phase, score, question count, difficulty mix).
export function SummaryTile({ phase, expanded, onToggle }: {
  phase: BenchPhase; expanded: boolean; onToggle: () => void;
}) {
  const totalQs = phase.results.reduce((n, r) => n + r.summary.total_questions, 0);
  const diffs: Record<string, number> = {};
  for (const r of phase.results)
    for (const [k, v] of Object.entries(r.summary.difficulty_counts || {})) diffs[k] = (diffs[k] || 0) + v;
  const pct = phase.marks_possible > 0 ? Math.round((100 * phase.marks_earned) / phase.marks_possible) : null;
  const plugins = phase.results.map((r: PluginResult) => r.plugin_id).join(", ");
  return (
    <button
      type="button" onClick={onToggle} className="card"
      style={{
        width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between",
        gap: 16, padding: "13px 16px", textAlign: "left", cursor: "pointer",
        borderLeft: "4px solid var(--magenta)",
        // native <button> defaults to UA button colors — force the app theme so
        // the tile isn't unreadable (light text on a light UA button face).
        background: "var(--panel)", color: "var(--text)", font: "inherit",
      }}
    >
      <div style={{ minWidth: 0 }}>
        <div style={{ fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{phase.name}</div>
        <div className="muted-3" style={{ marginTop: 2, fontSize: 12 }}>
          {totalQs} question{totalQs === 1 ? "" : "s"}
          {Object.keys(diffs).length > 0 && " · " + Object.entries(diffs).map(([k, v]) => `${v} ${k}`).join(" · ")}
          {plugins && ` · via ${plugins}`}
        </div>
      </div>
      <div style={{ flexShrink: 0, display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontWeight: 700, fontVariantNumeric: "tabular-nums" }}>{marks(phase.marks_earned, phase.marks_possible)}</div>
          {pct !== null && <div className="muted-3" style={{ fontSize: 12 }}>{pct}%</div>}
        </div>
        <span className="muted-3">{expanded ? "▾" : "▸"}</span>
      </div>
    </button>
  );
}
