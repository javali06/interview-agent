// Renders a segment's evidence as the ACTUAL transcript it was scored on
// (the AI question, the candidate's answer + follow-ups, verifier notes) —
// readable content, not bare event-index numbers. Turns the plugin explicitly
// cited are highlighted; clicking a turn deep-links to its Interview-Trace row
// (by event_index) when an onJump handler is provided.
import type { EvidenceTurn, JumpToTrace } from "./types";

const SPEAKER_LABEL: Record<string, string> = {
  candidate: "Candidate",
  ai: "AI",
  interviewer_ta: "Interviewer (TA)",
  verifier: "Verifier",
  system: "System",
};

const SPEAKER_COLOR: Record<string, string> = {
  candidate: "var(--text)",
  ai: "var(--cadence)",
  interviewer_ta: "var(--magenta-soft)",
  verifier: "var(--warn)",
  system: "var(--text-3)",
};

export default function EvidenceTurns({ evidence, onJump }: { evidence: EvidenceTurn[]; onJump?: JumpToTrace }) {
  if (!evidence || evidence.length === 0) return null;
  return (
    <div style={{ marginTop: 8 }}>
      <div className="muted-3" style={{ fontSize: 11, marginBottom: 4 }}>Evidence — what was scored</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 4, maxHeight: 260, overflowY: "auto" }}>
        {evidence.map((t, i) => (
          <div
            key={i}
            onClick={() => onJump?.(t.event_index)}
            title={onJump ? "Open this row in the Interview Trace tab" : undefined}
            style={{
              fontSize: 12, padding: "5px 8px", borderRadius: 6,
              background: t.cited ? "rgba(255,66,187,0.08)" : "var(--panel)",
              border: t.cited ? "1px solid rgba(255,66,187,0.30)" : "1px solid var(--line)",
              cursor: onJump ? "pointer" : "default",
            }}
          >
            <span style={{ fontWeight: 700, color: SPEAKER_COLOR[t.speaker] || "var(--text-2)" }}>
              {SPEAKER_LABEL[t.speaker] || t.speaker}:{" "}
            </span>
            <span className="muted" style={{ whiteSpace: "pre-wrap" }}>{t.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
