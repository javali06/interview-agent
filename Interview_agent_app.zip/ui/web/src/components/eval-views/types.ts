// Shared shapes for the benchmark evaluation result (the `benchmark` object on
// evaluation.json, produced by app/plugin_aggregate.py). The UI is a pure
// renderer over this — no scoring logic here.

export type BreakdownItem = { label: string; delta: number; detail: string };

// One transcript turn the segment was scored on — the readable evidence.
export type EvidenceTurn = {
  speaker: string; // candidate | ai | interviewer_ta | verifier | system
  text: string;
  event_index: number;
  cited: boolean;  // true when the plugin explicitly pointed at this turn
};

export type SegResult = {
  segment_id: string;
  kind: string; // question | generic | coding | warmup
  question_id: string | null;
  question_text: string | null;
  difficulty: string | null;
  state: string; // scored | not_observed | insufficient_evidence | assumptions_unmet | error
  marks_earned: number;
  marks_possible: number;
  rationale: string;
  breakdown: BreakdownItem[];
  sub_scores: Record<string, number>;
  grading: Record<string, unknown>; // plugin-specific view_payload
  evidence: EvidenceTurn[];          // the transcript content (real evidence)
  evidence_refs: number[];           // event indices (deep-link/highlight)
  // Written-response question material (comprehensive / transcription /
  // translation / image_description) — the actual content the candidate was
  // asked to work from, from the cadence, distinct from the AI's spoken/typed
  // dispatch line already in `evidence`. question_type is null/absent for
  // every other phase type (regular conversational/coding segments).
  question_type?: string | null;
  source_text?: string | null;      // translation: the passage to translate
  audio_url?: string | null;        // transcription: the clip to transcribe
  image_url?: string | null;        // image_description: the image to describe
  // The exported section key this segment came from — the address a review
  // posts to, and the key the plugin's adjustable spec is stored under.
  section?: string;
  review?: SegReview | null;        // null/absent = nobody has reviewed it
  adjustable?: AdjustableSpec | null;
};

export type PluginResult = {
  plugin_id: string;
  view_id: string;
  config_used: Record<string, unknown>;
  summary: {
    total_questions: number;
    scored_count: number;
    marks_earned: number;
    marks_possible: number;
    difficulty_counts: Record<string, number>;
  };
  segments: SegResult[];
};

export type BenchPhase = {
  phase_id: string;
  name: string;
  marks_earned: number;
  marks_possible: number;
  results: PluginResult[];
};

export type Benchmark = {
  schema: string;
  model: string;
  generated_at: string;
  plan_used: boolean;
  plan_fingerprint: string;
  total: { marks_earned: number; marks_possible: number; pct: number };
  // The MODEL's own total, present only when a human has adjusted something
  // (in which case `total` above is the reviewed one). Absent = nothing was
  // reviewed, so `total` is already the AI's.
  total_ai_only?: { marks_earned: number; marks_possible: number; pct: number } | null;
  phases: BenchPhase[];
  dimensions: Record<string, { score: number; count: number }>;
  coding_quality: unknown[];
};

// Optional callback to deep-link an evidence ref to the Interview-Trace row.
export type JumpToTrace = (eventIndex: number) => void;

export type DetailViewProps = { result: PluginResult; onJump?: JumpToTrace; review?: ReviewApi };

// ── human review ───────────────────────────────────────────────────────────
// The LLM's score is never overwritten. `marks_earned` above stays what the
// model said; `review.final_marks_earned` is what counts. Keeping both is what
// makes a raised score auditable and what leaves every adjustment usable as a
// labelled example of where the model is wrong.

export type ReasonKind =
  | "ai_misread"        // the model misunderstood what was actually said
  | "rubric_wrong"      // rubric applied correctly; the rubric is wrong
  | "evidence_missing"  // real evidence the model never saw
  | "calibration"       // right judgement, wrong severity for this role
  | "other";

export const REASON_KINDS: { value: ReasonKind; label: string }[] = [
  { value: "ai_misread", label: "AI misread the answer" },
  { value: "rubric_wrong", label: "The rubric itself is wrong" },
  { value: "evidence_missing", label: "Evidence the AI never saw" },
  { value: "calibration", label: "Too harsh / too lenient for this role" },
  { value: "other", label: "Other" },
];

export type ReviewedItem = {
  label: string; ai_value: number | null; human_value: number; reason: string;
};

export type SegReview = {
  final_state: string;
  final_marks_earned: number | null;
  final_marks_possible: number | null;
  items: ReviewedItem[];
  reason_kind: ReasonKind | null;
  reason: string;
  notes: string[];
  reviewer: string;
  reviewed_at: string;
  // The AI's value changed after this was recorded (a regenerate) — the
  // correction is neither dropped nor silently re-applied; the reviewer decides.
  stale: boolean;
};

// What the PLUGIN says a reviewer may edit — a slider for a unit-test result
// would be nonsense, so the affordance is declared, not assumed.
export type AdjustableSpec = {
  marks: boolean;
  items: boolean;
  item_scale: [number, number] | null;
  item_label_noun: string;
  recompute: "none" | "mean_scaled" | "sum_deltas";
};

export type ReviewSubmission = {
  segment_id: string;
  section: string;
  items: Record<string, number>;
  marks_earned?: number | null;
  reason_kind: ReasonKind;
  reason: string;
  note?: string;
};

// Threaded down to the segment card so the editor can save without every
// intermediate component knowing about tokens or queries.
export type ReviewApi = {
  save: (s: ReviewSubmission) => Promise<void>;
  withdraw: (segmentId: string, section: string) => Promise<void>;
  busy: boolean;
  error: string;
};
