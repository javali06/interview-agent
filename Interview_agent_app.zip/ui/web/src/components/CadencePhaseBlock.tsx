import type { CSSProperties } from "react";
import { useQuery } from "@tanstack/react-query";
import { phaseColor, type ParsedPhase, type ParsedQuestion } from "../lib/cadence";
import { getCodingQuestion } from "../lib/cadenceReview";
import type { ParsedInlineCodingQuestion } from "../lib/cadence";
import { formatPhaseDuration } from "../lib/format";

// Color-coded cadence phase block (ported from the legacy admin viz). Renders a
// numbered, color-striped card per phase with a mode pill, duration, intent,
// and — in full mode — the generic prompts / question pool / coding questions.
// `compact` (default) shows just the header + intent; full shows the bodies.
export function CadencePhaseBlock({
  phase,
  index,
  compact = false,
  hovered,
  onHover,
}: {
  phase: ParsedPhase;
  index: number;
  compact?: boolean;
  // Optional cross-highlight wiring (used by CadenceReview's Timeline↔card
  // hover sync; omitted by other callers like the Session cadence tab).
  hovered?: number | null;
  onHover?: (i: number | null) => void;
}) {
  const color = phaseColor(index);
  const codingIds = Array.isArray(phase.coding_question_ids) ? phase.coding_question_ids : [];
  const isCoding = codingIds.length > 0;
  const scenarioItems = Array.isArray(phase.scenario_items) ? phase.scenario_items : [];
  const isScenario = scenarioItems.length > 0;
  const mode = isCoding ? "coding" : isScenario ? "scenario_analysis" : phase.question_mode || "generic";
  // THREE classes, so this component never enumerates the modes:
  //   1. a SOURCE fallback — "generic" improvises, everything else is
  //      pool-backed (mirrors PhaseDef.uses_question_pool), so an unrecognised
  //      or brand-new mode still renders as a readable pill.
  //   2. `mode-<value>`, interpolated straight from the mode. Per-mode colours
  //      live in theme.css and override the fallback purely by source order.
  // Adding a question type is therefore ONE css rule (or none — it falls back).
  // Coding and Visual Scenario Analysis both keep question_mode="generic" (see
  // schema.py PhaseDef docstring), so both need this same override — neither
  // would otherwise be distinguishable from an ordinary generic phase here.
  const modeFallback = isCoding || isScenario
    ? `mode-${mode}`
    : mode === "generic"
      ? "mode-generic"
      : "mode-specific";
  const modeClass = `${modeFallback} mode-${mode}`;
  const durLabel = phase.duration_s != null ? formatPhaseDuration(phase.duration_s) : null;
  const prompts = (phase.generic_prompts || []).filter(Boolean);
  const pool = (phase.question_pool || []) as ParsedQuestion[];

  const isHot = hovered != null && hovered === index;
  const stripeStyle: CSSProperties = {
    borderLeftColor: color,
    ["--phase-c" as string]: color,
    transition: "box-shadow 0.15s ease, border-color 0.15s ease",
    ...(isHot ? { borderColor: color, boxShadow: `0 0 0 1px ${color}, 0 6px 20px rgba(0,0,0,0.35)` } : null),
  } as CSSProperties;

  return (
    <div
      className="phase-block"
      style={stripeStyle}
      onMouseEnter={onHover ? () => onHover(index) : undefined}
      onMouseLeave={onHover ? () => onHover(null) : undefined}
    >
      <div className="phase-head">
        <span className="phase-badge" style={{ background: color }}>{index + 1}</span>
        <span className="phase-title">{(phase.id || "phase").replace(/_/g, " ")}</span>
        {durLabel != null && <span className="pill" style={{ padding: "2px 9px" }}>{durLabel}</span>}
        <span className={`pill ${modeClass}`} style={{ padding: "2px 9px" }}>{mode}</span>
        {phase.adaptive_difficulty && <span className="pill mag" style={{ padding: "2px 9px" }}>adaptive</span>}
        {isCoding && <span className="muted-3" style={{ fontSize: 12 }}>{codingIds.length} question{codingIds.length === 1 ? "" : "s"}</span>}
        {isScenario && <span className="muted-3" style={{ fontSize: 12 }}>{scenarioItems.length} item{scenarioItems.length === 1 ? "" : "s"}</span>}
        {!isCoding && !isScenario && pool.length > 0 && <span className="muted-3" style={{ fontSize: 12 }}>{pool.length} Qs</span>}
      </div>

      {phase.intent && <p className="phase-intent">{phase.intent}</p>}

      {!compact && prompts.length > 0 && (
        <div className="phase-sec">
          <div className="phase-sec-h">Prompts <span className="pill" style={{ padding: "1px 7px" }}>{prompts.length}</span></div>
          <ul className="phase-prompts">
            {prompts.map((p, i) => (
              <li key={i}>{typeof p === "string" ? p : JSON.stringify(p)}</li>
            ))}
          </ul>
        </div>
      )}

      {!compact && pool.length > 0 && (
        <div className="phase-sec">
          <div className="phase-sec-h">Question pool <span className="pill" style={{ padding: "1px 7px" }}>{pool.length}</span></div>
          <ol
            className="phase-pool"
            style={pool.length > 8 ? { maxHeight: 320, overflowY: "auto" } : undefined}
          >
            {pool.map((q, i) => {
              const text = typeof q === "string" ? q : q?.text || JSON.stringify(q);
              const topic = typeof q === "object" && q ? q.topic : undefined;
              const followUps = typeof q === "object" && q?.follow_ups ? q.follow_ups : [];
              return (
                <li key={i} className="phase-q">
                  <div className="phase-q-head">
                    {topic && <span className="phase-q-tag">{topic}</span>}
                  </div>
                  <div className="phase-q-text">{text}</div>
                  {followUps.length > 0 && (
                    <ul
                      className="phase-q-followups"
                      style={{
                        marginTop: 4,
                        marginLeft: 14,
                        paddingLeft: 12,
                        borderLeft: "2px solid var(--line)",
                        listStyle: "disc",
                      }}
                    >
                      {followUps.map((fu, j) => (
                        <li key={j} style={{ fontSize: 12.5, color: "var(--text-3)", lineHeight: 1.45 }}>
                          {fu}
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              );
            })}
          </ol>
        </div>
      )}

      {!compact && isCoding && (
        <div className="phase-sec">
          <div className="phase-sec-h">
            Coding questions <span className="pill" style={{ padding: "1px 7px" }}>{codingIds.length}</span>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {codingIds.map((id) => (
              <CodingQuestionPreview key={id} qid={id}
                                     inline={phase.coding_questions_inline?.[id]} />
            ))}
          </div>
        </div>
      )}

      {!compact && isScenario && (
        <div className="phase-sec">
          <div className="phase-sec-h">
            Scenario items <span className="pill" style={{ padding: "1px 7px" }}>{scenarioItems.length}</span>
          </div>
          <ol
            className="phase-pool"
            style={scenarioItems.length > 8 ? { maxHeight: 320, overflowY: "auto" } : undefined}
          >
            {scenarioItems.map((item, i) => {
              const followUps = item.coverage_tags || [];
              return (
                <li key={item.id || i} className="phase-q">
                  <div className="phase-q-head">
                    {item.media?.kind && <span className="phase-q-tag">{item.media.kind}</span>}
                  </div>
                  <div className="phase-q-text">{item.question}</div>
                  {followUps.length > 0 && (
                    <ul
                      className="phase-q-followups"
                      style={{
                        marginTop: 4,
                        marginLeft: 14,
                        paddingLeft: 12,
                        borderLeft: "2px solid var(--line)",
                        listStyle: "disc",
                      }}
                    >
                      {followUps.map((t, j) => (
                        <li key={j} style={{ fontSize: 12.5, color: "var(--text-3)", lineHeight: 1.45 }}>
                          {t}
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              );
            })}
          </ol>
        </div>
      )}
    </div>
  );
}

// Async preview card for a single coding question id. Fetches the full
// question via /admin/coding/question/{qid} and shows a prompt snippet,
// difficulty, topics, test/hint counts, and collapsible starter code —
// mirroring the legacy hydrateCodingPreviews output. Caching/dedupe is free
// via TanStack Query keyed on the qid, so the same question fetched in two
// phases hits the network once (staleTime: Infinity → never refetched while
// the review screen is mounted, since the library is static).
function CodingQuestionPreview({
  qid, inline,
}: {
  qid: string;
  /** The definition embedded in the cadence, when this question came from an
   *  authored pool. Present → render straight from it: a pooled question is
   *  deliberately NOT in the built-in library, so asking the library for it
   *  404s and the card used to read "not in library?". */
  inline?: ParsedInlineCodingQuestion;
}) {
  const { data, isLoading } = useQuery({
    queryKey: ["coding-question", qid],
    queryFn: () => getCodingQuestion(qid),
    staleTime: Infinity,
    retry: false,
    // Skip the lookup entirely when the cadence already carries the question.
    enabled: !inline,
  });

  const card: CSSProperties = {
    border: "1px solid var(--line)",
    borderRadius: 10,
    padding: 10,
    background: "rgba(255,66,187,0.04)",
  };

  if (isLoading && !inline) {
    return (
      <div style={card}>
        <span className="muted-3" style={{ fontSize: 12 }}>Loading <code>{qid}</code>…</span>
      </div>
    );
  }

  const q = inline
    ? {
        id: qid,
        title: inline.title || qid,
        prompt: inline.prompt ?? "",
        difficulty: inline.difficulty ?? "easy",
        topic: inline.topic ?? [],
        role_fit: inline.role_fit ?? [],
        function_name: inline.function_name ?? "",
        starter_code: inline.starter_code ?? "",
        test_case_count: (inline.test_cases ?? []).length,
        hint_count: (inline.hints ?? []).length,
        hints: inline.hints ?? [],
        test_cases: inline.test_cases ?? [],
      }
    : data?.ok ? data.question : null;
  // `q` is non-null whenever `inline` was supplied, so this covers both the
  // embedded path and a genuine library miss.
  if (!q) {
    return (
      <div style={card}>
        <span style={{ fontSize: 12, color: "var(--warn)" }}>
          Could not load <code>{qid}</code> — not in library?
        </span>
      </div>
    );
  }

  const prompt = q.prompt ?? "";
  const promptShort = prompt.length > 240 ? `${prompt.slice(0, 237)}…` : prompt;
  const topics = Array.isArray(q.topic) ? q.topic : [];

  return (
    <div style={card}>
      <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 6 }}>
        <code className="mono" style={{ fontSize: 12, color: "var(--magenta-soft)" }}>{qid}</code>
        <span className="pill mode-coding" style={{ padding: "1px 7px" }}>{q.difficulty || "?"}</span>
        {topics.slice(0, 4).map((t) => (
          <span
            key={t}
            className="pill"
            style={{ padding: "1px 7px", color: "var(--magenta-soft)", borderColor: "rgba(255,66,187,0.3)" }}
          >
            {t}
          </span>
        ))}
      </div>
      {promptShort && (
        <p className="muted-3" style={{ fontSize: 12, marginTop: 6, lineHeight: 1.45 }}>{promptShort}</p>
      )}
      <div className="muted-3" style={{ display: "flex", gap: 12, marginTop: 6, fontSize: 11.5 }}>
        <span>{q.test_case_count} test{q.test_case_count === 1 ? "" : "s"}</span>
        <span>{q.hint_count} hint{q.hint_count === 1 ? "" : "s"}</span>
      </div>
      <details style={{ marginTop: 6 }}>
        <summary className="muted-3" style={{ fontSize: 12, cursor: "pointer" }}>Starter code</summary>
        <pre
          className="mono"
          style={{
            marginTop: 6,
            padding: 8,
            fontSize: 11.5,
            lineHeight: 1.5,
            background: "var(--panel-2)",
            borderRadius: 8,
            overflowX: "auto",
            whiteSpace: "pre",
          }}
        >
          <code>{q.starter_code || "(empty)"}</code>
        </pre>
      </details>
    </div>
  );
}
