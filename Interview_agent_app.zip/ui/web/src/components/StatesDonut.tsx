// The shared donut. Two charts use it (roles by stage, a role's interviews by
// stage) so the rules live in ONE place rather than being re-decided per chart.
//
// THE THREE-SLICE CEILING, and why it is not arbitrary: in a donut any slice can
// be compared with any other, so every pair must be distinguishable. Checked
// exhaustively against the palette on this surface —
//   all 70 four-hue combinations FAIL the all-pairs check
//   (worst cases: magenta↔aqua ΔE 1.6 for deuteranopia, yellow↔orange ΔE 10.6
//    for normal vision, which is below the floor secondary encoding cannot excuse)
// so a fourth slice would be two colours a reader genuinely cannot tell apart.
// Callers merge stages or report the remainder in text instead.
//
// A donut is also bad at comparing CLOSE values (1/1/1 arcs look identical), so
// every segment is direct-labelled with its count and nothing depends on colour.
import { useState } from "react";

export type DonutSegment = {
  key: string;
  label: string;
  color: string;
  value: number;
  hint?: string;
};

const GAP = 2;   // surface gap between segments, per the mark spec

export default function StatesDonut({
  title, segments, unit, size = 132, stroke = 16, footnote, emptyHint,
}: {
  title: string;
  segments: DonutSegment[];
  unit: string;            // what the total counts, e.g. "roles" / "interviews"
  size?: number;
  stroke?: number;
  footnote?: string;       // e.g. "2 cancelled" — outside the pipeline, not a slice
  emptyHint?: string;      // shown at zero instead of "No <unit> yet."
}) {
  const [hover, setHover] = useState<string | null>(null);
  const total = segments.reduce((n, s) => n + s.value, 0);
  const c = size / 2;
  const r = (size - stroke) / 2;
  const circumference = 2 * Math.PI * r;

  if (total === 0) {
    return (
      <div className="card" style={{ padding: "14px 16px" }}>
        <div className="muted-3" style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.12em" }}>
          {title}
        </div>
        <div className="muted" style={{ marginTop: 6, fontSize: 13.5 }}>
          {emptyHint || `No ${unit} yet.`}
        </div>
      </div>
    );
  }

  let acc = 0;
  const arcs = segments
    .map((s) => {
      const len = (s.value / total) * circumference;
      const arc = { ...s, len, offset: acc };
      acc += len;
      return arc;
    })
    .filter((a) => a.value > 0);

  return (
    <div className="card" style={{ padding: "14px 16px" }}>
      <div className="muted-3" style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.12em" }}>
        {title}
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 18, marginTop: 10, flexWrap: "wrap" }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ flexShrink: 0 }}
             role="img"
             aria-label={`${title}: ${segments.map((s) => `${s.value} ${s.label}`).join(", ")}`}>
          <g transform={`rotate(-90 ${c} ${c})`}>
            {/* Track, so a single-stage ring still reads as part of a whole. */}
            <circle cx={c} cy={c} r={r} fill="none" stroke="var(--line)" strokeWidth={stroke} opacity={0.35} />
            {arcs.map((a) => {
              // One full segment needs no gap — subtracting one would leave a
              // visible notch in an otherwise complete ring.
              const visible = arcs.length === 1 ? a.len : Math.max(a.len - GAP, 0.5);
              return (
                <circle
                  key={a.key} cx={c} cy={c} r={r} fill="none"
                  stroke={a.color}
                  strokeWidth={hover === a.key ? stroke + 3 : stroke}
                  strokeDasharray={`${visible} ${circumference - visible}`}
                  strokeDashoffset={-a.offset}
                  strokeLinecap="butt"
                  style={{ transition: "stroke-width 120ms" }}
                  onMouseEnter={() => setHover(a.key)}
                  onMouseLeave={() => setHover(null)}
                />
              );
            })}
          </g>
          {/* The hole earns its keep: the total lives there. */}
          <text x={c} y={c - 2} textAnchor="middle" fill="var(--text)"
                style={{ fontSize: size * 0.2, fontWeight: 800, fontVariantNumeric: "tabular-nums" }}>
            {total}
          </text>
          <text x={c} y={c + 15} textAnchor="middle" fill="var(--text-3)"
                style={{ fontSize: 10, letterSpacing: "0.08em", textTransform: "uppercase" }}>
            {total === 1 ? unit.replace(/s$/, "") : unit}
          </text>
        </svg>

        {/* Legend AND counts — identity is never colour alone, and close values
            are read as numbers rather than compared as arcs. */}
        <ul style={{ listStyle: "none", padding: 0, margin: 0, minWidth: 0, flex: 1,
                     display: "flex", flexDirection: "column", gap: 6 }}>
          {segments.map((s) => (
            <li key={s.key}
                onMouseEnter={() => setHover(s.key)} onMouseLeave={() => setHover(null)}
                style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: "2px 8px", fontSize: 13,
                         opacity: hover && hover !== s.key ? 0.5 : 1, transition: "opacity 120ms" }}>
              <span aria-hidden style={{ width: 10, height: 10, borderRadius: 3, flexShrink: 0, background: s.color }} />
              <span style={{ color: "var(--text)" }}>{s.label}</span>
              {s.hint && <span className="muted-3" style={{ fontSize: 12 }}>{s.hint}</span>}
              <span style={{ marginLeft: "auto", fontVariantNumeric: "tabular-nums", fontWeight: 700 }}>{s.value}</span>
            </li>
          ))}
        </ul>
      </div>

      {footnote && (
        <div className="muted-3" style={{ marginTop: 10, fontSize: 12 }}>{footnote}</div>
      )}
    </div>
  );
}
