// The maker–checker controls for one question pool: where it stands, what you
// can do about it, and everything that has happened to it.
//
// Shared by the pool list and the pool editor so a person sees the same state
// and the same buttons in both places — a workflow that reads differently
// depending on the screen is one nobody trusts.
//
// Every button here is a convenience. The server refuses the same things
// regardless of what is rendered; hiding a button you cannot use is courtesy,
// not security.
import { useCallback, useEffect, useState } from "react";
import { ApiError } from "../lib/api";
import { can, usePermissions } from "../lib/auth";
import {
  approvePool, forcePublishPool, poolHistory, returnPool, stateLabel, stateTone,
  submitPool, withdrawPool,
  type HistoryEntry, type PoolStatus, type PoolSummary,
} from "../lib/questionPools";
import { useToast } from "./Toaster";

const TONE_COLOUR: Record<string, string> = {
  amber: "var(--warn, #d98324)",
  green: "var(--ok, #2f9e5f)",
  neutral: "var(--text-2)",
  grey: "var(--muted-3, #6a6a6a)",
};

/** The one-line state pill. Safe to render anywhere, including a dense list. */
export function PoolStatePill({ pool }: { pool: PoolSummary }) {
  const tone = stateTone(pool);
  return (
    <span
      className="pill"
      data-tone={tone}
      style={{ padding: "2px 9px", fontSize: 11, color: TONE_COLOUR[tone] }}
      title={
        pool.workflow === "pending"
          ? "Waiting for someone else to approve it — interviews are unaffected."
          : pool.state === "draft"
          ? "Not visible to any interview until it is approved."
          : pool.has_draft
          ? "Live, with an edit waiting for approval behind it."
          : undefined
      }
    >
      {stateLabel(pool)}
    </span>
  );
}

const ACTION_LABEL: Record<HistoryEntry["action"], string> = {
  submitted: "Submitted for approval",
  approved: "Approved",
  returned: "Returned to the author",
  published: "Published",
  withdrawn: "Withdrawn",
};

function when(iso: string | null): string {
  if (!iso) return "";
  try {
    return new Date(iso).toLocaleString();
  } catch {
    return iso;
  }
}

export function PoolHistory({ entries }: { entries: HistoryEntry[] }) {
  if (entries.length === 0) {
    return (
      <p className="muted" style={{ fontSize: 13, margin: 0 }}>
        No approval history — this pool predates review.
      </p>
    );
  }
  return (
    <ol style={{ margin: 0, padding: 0, listStyle: "none", display: "grid", gap: 10 }}>
      {entries.map((h, i) => (
        <li key={i} style={{ display: "grid", gap: 2 }}>
          <div style={{ display: "flex", gap: 8, alignItems: "baseline", flexWrap: "wrap" }}>
            <strong style={{ fontSize: 13 }}>{ACTION_LABEL[h.action] ?? h.action}</strong>
            {h.step_no != null && (
              <span className="muted-3" style={{ fontSize: 11 }}>step {h.step_no}</span>
            )}
            <span className="muted-3" style={{ fontSize: 11, marginLeft: "auto" }}>
              {when(h.at)}
            </span>
          </div>
          <div className="muted" style={{ fontSize: 12 }}>{h.actor || "—"}</div>
          {h.comment && (
            <div style={{ fontSize: 12, borderLeft: "2px solid var(--line)", paddingLeft: 8 }}>
              {h.comment}
            </div>
          )}
        </li>
      ))}
    </ol>
  );
}

type Props = {
  poolId: string;
  /** The pool's team, so permission checks are scoped the way the server's are. */
  team?: string;
  /** Called after any successful action, so the parent can refresh. */
  onChanged?: () => void;
  /** Hide the history block when the parent already shows one. Also stops this
   *  component fetching — see `summary`. */
  showHistory?: boolean;
  /** Hide "Submit for approval". The EDITOR passes false: saving there already
   *  returns the author to the pool list, which is where they submit from — so
   *  offering it mid-edit asks them to send work for review that they may not
   *  have saved yet, and puts the same action on two screens. */
  showSubmit?: boolean;
  /** State the parent ALREADY has, from the list endpoint.
   *
   *  A list renders one of these per row. Fetching history per card turns one
   *  page load into one request per pool, so when the parent can supply the
   *  state it does, and this component asks the server for nothing until
   *  somebody actually acts. */
  summary?: PoolSummary;
  /** Whether a draft FILE exists. The list knows it from `summary.has_draft`;
   *  the editor passes it from the pool it loaded. The approval state cannot
   *  answer this: a pool published before review existed has no history, so it
   *  reads as "draft" while having nothing to submit. */
  hasDraft?: boolean;
};

export function PoolWorkflow({
  poolId, team, onChanged, showHistory = true, showSubmit = true, summary,
  hasDraft: hasDraftProp,
}: Props) {
  const toast = useToast();
  const { data: me } = usePermissions();
  const [status, setStatus] = useState<PoolStatus | null>(
    summary
      ? {
          state: summary.workflow ?? "draft",
          cycle_id: null,
          team: summary.team ?? null,
          steps: summary.steps ?? [],
          signed: [],
          next_step: summary.next_step ?? null,
          submitted_by: summary.submitted_by ?? null,
          last_comment: "",
        }
      : null,
  );
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [busy, setBusy] = useState(false);
  const [loaded, setLoaded] = useState(false);

  const refresh = useCallback(async () => {
    try {
      const r = await poolHistory(poolId);
      setStatus(r.status);
      setHistory(r.history);
      setLoaded(true);
    } catch {
      setStatus((prev) => prev);  // a pool with no ledger yet is a normal state
    }
  }, [poolId]);

  useEffect(() => {
    // Only fetch when we are actually going to show history, or when the parent
    // gave us nothing to render from.
    if (showHistory || !summary) void refresh();
  }, [refresh, showHistory, summary]);

  const run = async (label: string, fn: () => Promise<unknown>) => {
    setBusy(true);
    try {
      await fn();
      toast.success(label);
      await refresh();       // the parent's summary is stale the moment we act
      onChanged?.();
    } catch (e) {
      // The server's refusals are written to be read by a person — show the
      // sentence it sent rather than a generic failure.
      toast.error((e as ApiError).message || "That did not work.");
    } finally {
      setBusy(false);
    }
  };

  const onReturn = () => {
    const comment = window.prompt(
      "Why are you sending this back? The author sees this.",
    );
    if (comment === null) return;                 // cancelled
    if (!comment.trim()) {
      toast.error("A reason is required — the author cannot act on a blank return.");
      return;
    }
    void run("Returned to the author.", () => returnPool(poolId, comment));
  };

  const pending = status?.state === "pending";
  const mine = status?.submitted_by != null && status.submitted_by === me?.id;
  // Submit and force-publish both send a DRAFT, so there has to be one —
  // otherwise the server answers 404. Read from the file state, not `status`.
  const hasDraft = hasDraftProp ?? summary?.has_draft === true;

  const mayApprove = can(me, "pools.approve", team ?? undefined) && pending && !mine;
  const maySubmit =
    showSubmit && can(me, "pools.submit", team ?? undefined) && !pending && hasDraft;
  const mayWithdraw = pending && mine;
  const mayForce = can(me, "pools.publish", team ?? undefined) && hasDraft;

  return (
    <div style={{ display: "grid", gap: 12 }}>
      {status && (
        <div className="muted" style={{ fontSize: 13 }}>
          {pending ? (
            <>
              Waiting for <strong>{status.next_step?.name || "approval"}</strong>
              {status.steps.length > 1 && (
                <> — step {status.next_step?.step_no} of {status.steps.length}</>
              )}
              .
            </>
          ) : status.state === "published" ? (
            <>Published and in use by interviews.</>
          ) : (
            <>A draft. No interview can see it until it is approved.</>
          )}
        </div>
      )}

      {status?.last_comment && !pending && (
        <div
          className="card"
          style={{ padding: 10, fontSize: 13, borderLeft: "3px solid var(--warn, #d98324)" }}
        >
          <strong>Returned:</strong> {status.last_comment}
        </div>
      )}

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {maySubmit && (
          <button type="button" className="btn btn-primary btn-sm" disabled={busy}
                  onClick={() => void run("Sent for approval.", () => submitPool(poolId))}>
            Submit for approval
          </button>
        )}
        {mayApprove && (
          <>
            <button type="button" className="btn btn-primary btn-sm" disabled={busy}
                    onClick={() => void run("Approved.", () => approvePool(poolId))}>
              Approve
            </button>
            <button type="button" className="btn btn-ghost btn-sm" disabled={busy}
                    onClick={onReturn}>
              Return with a comment
            </button>
          </>
        )}
        {mayWithdraw && (
          <button type="button" className="btn btn-ghost btn-sm" disabled={busy}
                  onClick={() => void run("Withdrawn.", () => withdrawPool(poolId))}>
            Withdraw
          </button>
        )}
        {pending && mine && !mayWithdraw && (
          <span className="muted-3" style={{ fontSize: 12, alignSelf: "center" }}>
            You submitted this, so somebody else has to approve it.
          </span>
        )}
        {mayForce && (
          <button
            type="button" className="btn btn-ghost btn-sm" disabled={busy}
            style={{ marginLeft: "auto", color: "var(--danger)" }}
            title="Publishes immediately, skipping review. Recorded as an override."
            onClick={() => {
              const reason = window.prompt(
                "Publishing without review. Why? This is recorded.",
              );
              if (reason === null) return;
              void run("Published, bypassing review.",
                       () => forcePublishPool(poolId, reason));
            }}
          >
            Publish without review
          </button>
        )}
      </div>

      {showHistory && (
        <details onToggle={() => { if (!loaded) void refresh(); }}>
          <summary className="muted" style={{ fontSize: 13, cursor: "pointer" }}>
            History{loaded ? ` (${history.length})` : ""}
          </summary>
          <div style={{ marginTop: 10 }}>
            <PoolHistory entries={history} />
          </div>
        </details>
      )}
    </div>
  );
}
