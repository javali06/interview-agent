import { useEffect, useState } from "react";
import { DinoGame } from "./DinoGame";
import AiOrb from "./AiOrb";
import "../pages/CandidateLive.css";

// No audio level applies here (the session hasn't started) — a constant
// zero keeps the orb in its gentle "thinking" breathing motion.
const NO_LEVEL = () => 0;

// Rotating status lines shown while the AI interviewer spins up. Each line types
// out fast, then holds (readable) while an animated "…" loading-dots cycle plays
// at the end — like Claude's processing indicator. Stored WITHOUT trailing dots;
// the dots are animated separately (see useTypewriter). Loops until the parent
// (Candidate.tsx) unmounts this overlay the instant the AI is about to speak.
const PREP_MESSAGES = [
  "Preparing your AI interviewer",
  "Analyzing your resume",
  "Understanding your skills and experience",
  "Generating personalized interview questions",
  "Matching questions to the job role",
  "Loading your interview session",
  "Getting everything ready for your interview",
  "Almost ready — just a few more seconds",
];
const TYPE_MS = 28; // per-character reveal speed (fast)
const HOLD_MS = 3200; // how long a finished line stays on screen (readable) before the next
const DOT_MS = 350; // loading-dots step while holding

// The dots cycle. Empty → one → two → three, repeating, so it reads as a live
// "working…" indicator rather than a static ellipsis.
const DOT_SEQ = ["", ".", "..", "..."];

// Typewriter over a looping list. Two phases per line:
//   typing  — reveal the line letter-by-letter (caret shown)
//   holding — line complete; animate the trailing dots for HOLD_MS, then advance
// `done` flips the phase; each effect owns its own timer and cleans up on unmount
// or phase change. Returns the base line (for width reservation), the portion
// typed so far, the current animated dots, and whether typing is done.
function useTypewriter(messages: string[], typeMs: number, holdMs: number, dotMs: number) {
  const [idx, setIdx] = useState(0);
  const [typed, setTyped] = useState("");
  const [dots, setDots] = useState("");
  const full = messages[idx];
  const done = typed.length >= full.length;

  // typing phase — one char at a time until the line is complete
  useEffect(() => {
    if (done) return;
    const t = setTimeout(() => setTyped(full.slice(0, typed.length + 1)), typeMs);
    return () => clearTimeout(t);
  }, [typed, done, full, typeMs]);

  // holding phase — animate the dots, then advance to the next line (wrapping)
  useEffect(() => {
    if (!done) return;
    let step = 0;
    const dotTimer = setInterval(() => {
      step = (step + 1) % DOT_SEQ.length;
      setDots(DOT_SEQ[step]);
    }, dotMs);
    const advance = setTimeout(() => {
      setDots("");
      setTyped("");
      setIdx((i) => (i + 1) % messages.length);
    }, holdMs);
    return () => {
      clearInterval(dotTimer);
      clearTimeout(advance);
    };
  }, [done, idx, messages, holdMs, dotMs]);

  return { full, typed, dots, done };
}

// Full-screen "please wait" overlay shown while the AI interviewer spins up
// (session boot + first LLM token + first TTS). Covers the live screen with a
// highlighted status banner + a playable dino mini-game so the candidate has
// something to do during the gap. The parent (Candidate.tsx) unmounts this the
// instant the AI is about to speak (turn.state → "speaking"), so it needs no
// close logic of its own.
//
// z-index sits ABOVE the live stage but BELOW error modals (z=50), so a
// lost-connection prompt still surfaces over the game if the session fails to
// start.
export function PreparingOverlay() {
  const { full, typed, dots, done } = useTypewriter(PREP_MESSAGES, TYPE_MS, HOLD_MS, DOT_MS);
  return (
    <div className="cl-root cl-page cl-prep-overlay">
      <div className="cl-prep-body">
        <div className="cl-prep-orb">
          <AiOrb mode="thinking" getLevel={NO_LEVEL} size={120} />
        </div>

        {/* highlighted status banner — dynamic, typed line by line */}
        <div className="cl-prep-status" role="status" aria-live="polite">
          <span className="prep-spinner" />
          {/* Hidden sizer reserves the full line + 3 dots of width so the pill
              stays a fixed size per line (no jitter as letters or dots appear);
              the live text overlays it, left-aligned. */}
          <span style={{ position: "relative", display: "inline-block", textAlign: "left" }}>
            <span style={{ visibility: "hidden", whiteSpace: "nowrap" }}>{full}...</span>
            <span style={{ position: "absolute", left: 0, top: 0, whiteSpace: "nowrap" }}>
              {typed}
              {done ? dots : <span className="prep-caret" />}
            </span>
          </span>
        </div>

        <p className="cl-prep-sub">
          This usually takes a few seconds. Here's a game to pass the time — we'll drop you
          into the interview automatically the moment your interviewer is ready.
        </p>

        <div className="cl-game-area">
          <DinoGame />
        </div>

        <p className="cl-prep-hint">
          Press <b>Space</b> or <b>tap</b> to jump over the cacti.
        </p>
      </div>

      {/* Local keyframes for the banner spinner + typing caret (self-contained). */}
      <style>{`
        .prep-spinner {
          width: 14px; height: 14px; flex: none;
          border: 2px solid var(--ds-accent-soft);
          border-top-color: var(--ds-accent);
          border-radius: 50%;
          animation: prep-spin 0.8s linear infinite;
        }
        @keyframes prep-spin { to { transform: rotate(360deg); } }
        .prep-caret {
          display: inline-block;
          width: 2px; height: 1em;
          margin-left: 2px;
          vertical-align: text-bottom;
          background: var(--ds-accent);
          animation: prep-blink 1s step-end infinite;
        }
        @keyframes prep-blink { 0%, 100% { opacity: 1; } 50% { opacity: 0; } }
      `}</style>
    </div>
  );
}
