import { createContext, useCallback, useContext, useMemo, useState } from "react";
import type { ReactNode } from "react";

// Tiny in-app toast system — no external lib. We deliberately keep this
// minimal: a context with a `push` callback + a fixed-position overlay that
// renders the current queue. Each toast auto-dismisses after 4.5s.
type Toast = { id: number; kind: "ok" | "err"; text: string };

const ToastCtx = createContext<{
  push: (kind: Toast["kind"], text: string) => void;
} | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const push = useCallback((kind: Toast["kind"], text: string) => {
    const id = Date.now() + Math.floor(Math.random() * 1000);
    setToasts((cur) => [...cur, { id, kind, text }]);
    setTimeout(() => setToasts((cur) => cur.filter((t) => t.id !== id)), 4500);
  }, []);
  return (
    <ToastCtx.Provider value={{ push }}>
      {children}
      <div
        style={{
          position: "fixed", bottom: 24, right: 24, zIndex: 9999,
          display: "flex", flexDirection: "column", gap: 8, maxWidth: 360,
        }}
      >
        {toasts.map((t) => (
          <div
            key={t.id}
            role={t.kind === "err" ? "alert" : "status"}
            style={{
              padding: "11px 14px", fontSize: 13.5, lineHeight: 1.45, fontFamily: "var(--ds-font)",
              color: "var(--ds-text)", background: "var(--ds-surface)",
              border: "1px solid var(--ds-border)", borderRadius: 12,
              borderLeft: `4px solid ${t.kind === "ok" ? "var(--ds-success)" : "#c81e1e"}`,
              boxShadow: "var(--ds-shadow)",
              animation: "toast-in 200ms ease-out",
            }}
          >
            {t.text}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastCtx);
  // MEMOISED, and that is load-bearing: this used to return a fresh object
  // literal on every call, so any `useEffect(..., [toast])` re-ran on EVERY
  // render. In the question-pool editor that meant the "load this pool" effect
  // refetched continuously and overwrote the admin's edits the moment they
  // typed — the page looked frozen. `push` is a stable useCallback, so keying
  // the memo on it makes the returned api stable for the component's lifetime.
  const push = ctx?.push;
  const api = useMemo(
    () => ({
      success: (text: string) => push?.("ok", text),
      error: (text: string) => push?.("err", text),
    }),
    [push],
  );
  if (!ctx) throw new Error("useToast outside ToastProvider");
  return api;
}
