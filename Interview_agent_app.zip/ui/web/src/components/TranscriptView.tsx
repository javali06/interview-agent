import { useEffect, useRef } from "react";
import "./TranscriptView.css";

// One line of the live interview transcript. role drives the row color + the
// CSS class; meta is the small label shown on the left (e.g. "candidate
// (speaking…)"). partial marks an in-flight STT row that's still updating.
export type TranscriptRow = {
  id: number;
  role: string; // ai | candidate | system | phase | coding
  meta: string;
  text: string;
  partial?: boolean;
};

// Role-label colors against the light transcript row tints.
const ROW_COLOR: Record<string, string> = {
  ai: "#1d4ed8",
  candidate: "#b00f77",
  system: "#4b4f63",
  phase: "#92400e",
  coding: "#6d28d9",
};

// The candidate's live transcript. Sticky auto-scroll: only follow new rows when the viewer is already
// near the bottom. If they've scrolled up to read earlier transcript, leave
// their position alone (otherwise the frequent stt_partial updates yank them
// back down and they can never read up).
export function TranscriptView({ rows }: { rows: TranscriptRow[] }) {
  const ref = useRef<HTMLUListElement>(null);
  const stick = useRef(true);
  const onScroll = () => {
    const el = ref.current;
    if (!el) return;
    stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
  };
  useEffect(() => {
    if (ref.current && stick.current) ref.current.scrollTop = ref.current.scrollHeight;
  }, [rows]);
  return (
    <ul ref={ref} className="transcript-list" onScroll={onScroll}>
      {rows.map((r) => (
        <li key={r.id} className={`trow trow-${r.role} ${r.partial ? "trow-partial" : ""}`}>
          <span className="trow-meta" style={{ color: ROW_COLOR[r.role] ?? "#4b4f63" }}>{r.meta}</span>
          <span className="trow-text">{r.text}</span>
        </li>
      ))}
    </ul>
  );
}
