// Route guard. The server still refuses the API; this only stops the page
// from opening and then failing.
import type { ReactNode } from "react";
import { usePermissions } from "../lib/auth";
import { allowed } from "../lib/workspace";
import { NoAccess } from "./AccountGate";

export function Guard({ anyOf, children }: { anyOf: string[]; children: ReactNode }) {
  const { data, isLoading } = usePermissions();
  if (isLoading || !data) return <p className="muted">Loading…</p>;
  if (!allowed(data, anyOf)) return <NoAccess />;
  return <>{children}</>;
}
