// Session status pill — shared by the Dashboard and Session-detail screens.
// Maps each status to a dark-theme .pill variant; `data-status` lets the light
// theme (styles/light.css) colour by status without changing dark pages.
const VARIANT: Record<string, string> = {
  draft: "",
  generating: "warn",
  ready: "warn",
  in_progress: "ok live",
  completed: "mag",
  cancelled: "danger",
};

export function StatusPill({ status }: { status: string }) {
  const variant = VARIANT[status] ?? "";
  const pulsing = status === "in_progress" || status === "generating";
  return (
    <span className={`pill ${variant}`} data-status={status}>
      {pulsing && <span className="pdot" />}
      {status.replace("_", " ")}
    </span>
  );
}
