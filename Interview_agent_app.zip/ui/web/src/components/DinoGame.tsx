import { useEffect, useRef } from "react";

// Self-contained Chrome-style offline dinosaur runner. No external deps, no
// assets — everything is drawn on a <canvas> with a rAF loop. Used as a
// "pass the time" distraction while the AI interviewer spins up. Jump with
// Space / ArrowUp / tap; run into a cactus → game over → same keys restart.
//
// Kept deliberately framework-light: all game state lives in refs inside the
// effect (never React state) so the loop never triggers a re-render, and the
// whole thing tears down cleanly (cancel rAF + remove listeners) on unmount so
// there's no leaked animation frame when the overlay closes.

const W = 600;      // internal backing resolution (CSS scales to container)
// Jump apex is ~108px above the ground (JUMP_V² / 2·GRAVITY) — the canvas must be
// tall enough that the head never leaves the top edge.
const H = 220;
const GROUND_Y = 190;
const DINO_X = 60;
const DINO_W = 44;
const DINO_H = 47;
const GRAVITY = 2400;      // px/s^2
const JUMP_V = -720;       // px/s
const START_SPEED = 320;   // px/s
// Candidate design tokens (CandidateLive.css) — drawn on a white play area.
const DINO = "#cd128a";
const DINO_CRASHED = "rgba(205,18,138,0.4)";
const CACTUS = "#4b4f63";
const GROUND = "#d9d6e8";
const DECOR = "#eceaf6";
const SCORE = "#707070";
const TEXT = "#161616";
const MONO = "600 14px 'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, Consolas, monospace";
const CLOUDS = [
  { x: 90, y: 46, s: 1 },
  { x: 330, y: 30, s: 0.8 },
  { x: 520, y: 62, s: 1.15 },
];

type Obstacle = { x: number; w: number; h: number };

export function DinoGame() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // ── game state ──
    let dinoY = GROUND_Y - DINO_H;   // top of the dino
    let vy = 0;
    let onGround = true;
    let obstacles: Obstacle[] = [];
    let speed = START_SPEED;
    let dist = 0;                    // ground scroll offset (decoration)
    let score = 0;
    let best = 0;
    let spawnIn = 0;                 // seconds until next obstacle
    let gameOver = false;
    let raf = 0;
    let last = 0;
    let legPhase = 0;

    const reset = () => {
      dinoY = GROUND_Y - DINO_H; vy = 0; onGround = true;
      obstacles = []; speed = START_SPEED; dist = 0; score = 0;
      spawnIn = 0.8; gameOver = false;
    };
    reset();

    const jump = () => {
      if (gameOver) { reset(); return; }
      if (onGround) { vy = JUMP_V; onGround = false; }
    };

    const spawn = () => {
      // Cactus of a random size; gap scales with speed so it stays fair.
      const h = 26 + Math.floor((legPhase * 997) % 22);   // pseudo-random-ish 26..47
      const w = 14 + (h % 3) * 6;
      obstacles.push({ x: W + 10, w, h });
      spawnIn = (0.9 + ((dist % 60) / 60) * 0.8) * (START_SPEED / speed);
    };

    const step = (t: number) => {
      const dt = last ? Math.min(0.05, (t - last) / 1000) : 0;
      last = t;

      if (!gameOver) {
        // physics
        vy += GRAVITY * dt;
        dinoY += vy * dt;
        if (dinoY >= GROUND_Y - DINO_H) { dinoY = GROUND_Y - DINO_H; vy = 0; onGround = true; }
        dist += speed * dt;
        legPhase += speed * dt;
        speed += 8 * dt;            // gradually harder
        score += speed * dt * 0.05;

        spawnIn -= dt;
        if (spawnIn <= 0) spawn();
        for (const o of obstacles) o.x -= speed * dt;
        obstacles = obstacles.filter((o) => o.x + o.w > -10);

        // collision (AABB with a small forgiveness inset)
        for (const o of obstacles) {
          const oy = GROUND_Y - o.h;
          if (DINO_X + 8 < o.x + o.w && DINO_X + DINO_W - 8 > o.x &&
              dinoY + 6 < GROUND_Y && dinoY + DINO_H - 2 > oy) {
            gameOver = true;
            best = Math.max(best, Math.floor(score));
          }
        }
      }

      // ── draw ──
      ctx.clearRect(0, 0, W, H);

      // clouds — slow parallax decoration, drawn first so everything sits on top
      ctx.fillStyle = DECOR;
      for (const c of CLOUDS) {
        const x = (((c.x - dist * 0.15 * c.s) % (W + 80)) + W + 80) % (W + 80) - 40;
        const s = c.s;
        ctx.fillRect(x, c.y, 46 * s, 10 * s);
        ctx.fillRect(x + 10 * s, c.y - 8 * s, 24 * s, 8 * s);
      }

      // ground
      ctx.strokeStyle = GROUND;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, GROUND_Y);
      ctx.lineTo(W, GROUND_Y);
      ctx.stroke();
      // dashes on the ground to convey motion
      ctx.fillStyle = GROUND;
      for (let i = 0; i < W / 40 + 1; i++) {
        const x = ((i * 40 - (dist % 40)) + W) % W;
        ctx.fillRect(x, GROUND_Y + 8, 14, 2);
      }

      // obstacles (cacti)
      ctx.fillStyle = CACTUS;
      for (const o of obstacles) {
        const oy = GROUND_Y - o.h;
        ctx.fillRect(o.x, oy, o.w, o.h);
        ctx.fillRect(o.x - 6, oy + o.h * 0.35, 6, 4);
        ctx.fillRect(o.x + o.w, oy + o.h * 0.5, 6, 4);
      }

      // dino (blocky T-rex)
      ctx.fillStyle = gameOver ? DINO_CRASHED : DINO;
      ctx.fillRect(DINO_X, dinoY, DINO_W - 16, DINO_H - 14);          // body
      ctx.fillRect(DINO_X + DINO_W - 20, dinoY - 4, 20, 20);          // head
      ctx.fillRect(DINO_X - 6, dinoY + 8, 10, 8);                     // tail
      // eye
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(DINO_X + DINO_W - 8, dinoY + 1, 3, 3);
      // legs — hang from the body so they move with the jump; alternate the
      // stride while running on the ground, tuck up while airborne / on crash.
      ctx.fillStyle = gameOver ? DINO_CRASHED : DINO;
      const bodyBottom = dinoY + (DINO_H - 14);
      if (onGround && !gameOver) {
        const stride = Math.floor(legPhase / 12) % 2 === 0;
        ctx.fillRect(DINO_X + 4, bodyBottom, 7, stride ? 14 : 7);
        ctx.fillRect(DINO_X + 16, bodyBottom, 7, stride ? 7 : 14);
      } else {
        ctx.fillRect(DINO_X + 4, bodyBottom, 7, 8);
        ctx.fillRect(DINO_X + 16, bodyBottom, 7, 8);
      }

      // score
      ctx.fillStyle = SCORE;
      ctx.font = MONO;
      ctx.textAlign = "right";
      ctx.fillText(String(Math.floor(score)).padStart(5, "0"), W - 12, 24);
      if (best > 0) {
        ctx.fillText("HI " + String(best).padStart(5, "0"), W - 72, 24);
      }

      if (gameOver) {
        ctx.fillStyle = TEXT;
        ctx.font = "600 18px 'DM Sans', Arial, system-ui, sans-serif";
        ctx.textAlign = "center";
        ctx.fillText("Game over", W / 2, H / 2 - 4);
        ctx.fillStyle = SCORE;
        ctx.font = "500 13px 'DM Sans', Arial, system-ui, sans-serif";
        ctx.fillText("Press Space or tap to try again", W / 2, H / 2 + 20);
      }

      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);

    // ── input ──
    const onKey = (e: KeyboardEvent) => {
      if (e.code === "Space" || e.code === "ArrowUp") { e.preventDefault(); jump(); }
    };
    const onPointer = (e: Event) => { e.preventDefault(); jump(); };
    window.addEventListener("keydown", onKey);
    canvas.addEventListener("pointerdown", onPointer);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("keydown", onKey);
      canvas.removeEventListener("pointerdown", onPointer);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      width={W}
      height={H}
      aria-label="Dinosaur mini-game — press Space or tap to jump"
      style={{
        width: "100%",
        maxWidth: W,
        height: "auto",
        display: "block",
        margin: "0 auto",
        background: "transparent",
        touchAction: "none",
        cursor: "pointer",
      }}
    />
  );
}
