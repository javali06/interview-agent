// Where this role's interviews have got to. Lives in the Interviews section it
// summarises, so the ring and the rows beneath it always agree.
//
// THREE stages, each meaning exactly one thing:
//   Ready to send — the link has been generated and not yet used
//   In progress   — the candidate has started the interview
//   Completed     — finished and scored
// Interviews still awaiting approval have no link yet, so calling them "ready
// to send" would be a lie; they and cancelled ones are reported UNDER the
// chart, because both sit outside that pipeline. It also keeps the ring at
// three colours, which is the ceiling — see StatesDonut.
import StatesDonut from "./StatesDonut";

export type RoleInterviewStates = {
  ready_to_send?: number;
  in_progress?: number;
  completed?: number;
  awaiting_approval?: number;
  cancelled?: number;
  total?: number;
};

export default function RoleInterviewsChart({ states }: { states: RoleInterviewStates }) {
  const pending = states.awaiting_approval || 0;
  const cancelled = states.cancelled || 0;

  const notes: string[] = [];
  if (pending) notes.push(`${pending} awaiting approval — no link issued yet`);
  if (cancelled) notes.push(`${cancelled} cancelled`);

  return (
    <StatesDonut
        title="Interviews by stage"
        unit="interviews"
        segments={[
          { key: "ready_to_send", label: "Ready to send", color: "#3987e5",
            value: states.ready_to_send || 0, hint: "link generated, not used yet" },
          { key: "in_progress", label: "In progress", color: "#d95926",
            value: states.in_progress || 0, hint: "candidate has started" },
          { key: "completed", label: "Completed", color: "#199e70",
            value: states.completed || 0, hint: "finished and scored" },
        ]}
        emptyHint={pending
          ? `${pending} interview${pending === 1 ? "" : "s"} created — approve to generate the links.`
          : "No interviews yet — use “Set up interviews” to create them."}
      footnote={notes.length ? `${notes.join(" · ")} — not in the stages above.` : undefined}
    />
  );
}
