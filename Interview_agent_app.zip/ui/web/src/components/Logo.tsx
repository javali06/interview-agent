// The one place the Centific logo is drawn (sidebar, login). Until the
// official logo file is in the repo this is the "C" mark + name; to switch,
// replace the mark/name below with <img src="…" alt="Centific" />.
export function Logo({ sub }: { sub?: string }) {
  return (
    <>
      <div className="brand-mark" aria-hidden="true">C</div>
      <div>
        <div className="brand-name">Centific</div>
        {sub && <div className="brand-sub">{sub}</div>}
      </div>
    </>
  );
}
