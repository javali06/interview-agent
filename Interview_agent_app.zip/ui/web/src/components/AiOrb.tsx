// The AI interviewer's main visual — a glowing gradient orb on a <canvas>
// with flowing sine waves, reacting to real audio level. `getLevel` is
// supplied by the caller (Candidate.tsx's Stage()) and should return the AI
// playback level while speaking, the mic level while hearing — both read
// from lib/orbGlow.ts's existing smoothed levels (getLevel there), which are
// fed by candidateEngine.ts's existing AnalyserNode taps. This component adds
// no audio tap of its own and never touches playback.
//
// State signatures (tuned on the orb-states bench):
//   speaking  — waves + a tight violet rim glow swelling with AVA's voice.
//   hearing   — the candidate is actively talking: a distinct-hue glow + a
//               pulsing attention ring (intent listening).
//   listening — the candidate's turn, but quiet: REST. Barely-moving waves;
//               a slow breathing rim glow is the only sign of life.
//   idle      — the brief pre-connect moment; same calm as rest.
//   thinking  — AVA is processing: a gentle violet pulse.
import { useEffect, useRef } from "react";

export type Mode = "idle" | "speaking" | "listening" | "hearing" | "thinking";

export default function AiOrb({
  getLevel,
  mode,
  size = 280,
  hearingHue = 208,
}: {
  getLevel: () => number;
  mode: Mode;
  size?: number;
  // Hue (deg) of the "hearing" glow. 208 = blue — reads on a white/light stage
  // and distinct from the violet "speaking" state.
  hearingHue?: number;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const modeRef = useRef(mode);
  const levelRef = useRef(getLevel);
  const hueRef = useRef(hearingHue);
  modeRef.current = mode;
  levelRef.current = getLevel;
  hueRef.current = hearingHue;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = size * dpr;
    canvas.height = size * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    const reduceMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)"
    ).matches;

    const waves = [
      { freq: 1.6, speed: 0.9, alpha: 0.75, width: 2.2 },
      { freq: 2.3, speed: -1.2, alpha: 0.5, width: 1.8 },
      { freq: 3.1, speed: 1.5, alpha: 0.35, width: 1.4 },
      { freq: 1.1, speed: -0.7, alpha: 0.25, width: 1.2 },
    ];

    // Rest/breathing constants.
    const REST_CALM = 0.04;      // idle wave size — barely moving
    const BREATH_DEPTH = 0.22;   // rest glow swell
    const BREATH_PERIOD = 4.8;   // seconds (t advances ~1/s)

    let raf = 0;
    let t = 0;        // breathing / time clock
    let wave = 0;     // wave phase — advances at a mode-dependent speed
    let amp = 0.08;   // smoothed wave amplitude

    const violet = (op: number) => `rgba(124, 92, 255, ${op})`;

    const draw = () => {
      const m = modeRef.current;
      const hue = hueRef.current;
      const raw = Math.max(0, Math.min(1, levelRef.current() || 0));
      const breathe = 0.5 + 0.5 * Math.sin((t * Math.PI * 2) / BREATH_PERIOD);

      // Per-state recipe: wave amplitude target, wave speed, a TIGHT rim glow
      // (glowScale ≈ how far past the orb edge the halo reaches — kept close),
      // and an optional attention ring for "hearing".
      let target: number;
      let waveSpeed: number;
      let glowRGBA: (op: number) => string;
      let glowOp: number;
      let glowScale: number;
      let ring = 0;

      if (m === "speaking") {
        target = 0.18 + raw * 0.9;
        waveSpeed = 1.0;
        glowRGBA = violet;
        glowOp = 0.14 + raw * 0.55 + 0.06 * breathe;
        glowScale = 1.12 + raw * 0.22 + 0.03 * breathe;
      } else if (m === "hearing") {
        // Soft, diffuse BLUE glow that gently pulses ("listening intently") — no
        // crisp ring, a wider radius so the edge dilutes instead of cutting off.
        const pulse = 0.5 + 0.5 * Math.sin(t * 3.2);
        target = 0.1 + raw * 0.45;
        waveSpeed = 0.8;
        glowRGBA = (op: number) => `hsla(${hue}, 85%, 52%, ${op})`;
        glowOp = (0.22 + raw * 0.42) * (0.78 + 0.22 * pulse);
        glowScale = 1.26 + raw * 0.26 + 0.06 * pulse;
        ring = 0;
      } else if (m === "thinking") {
        target = 0.14 + 0.05 * (0.5 + 0.5 * Math.sin(t * 2));
        waveSpeed = 0.5;
        glowRGBA = violet;
        glowOp = 0.1 + 0.05 * breathe;
        glowScale = 1.1 + 0.03 * breathe;
      } else {
        // idle (connecting) + listening (candidate's turn, quiet) = REST.
        target = REST_CALM;
        waveSpeed = 0.3;
        glowRGBA = violet;
        glowOp = 0.045 + BREATH_DEPTH * breathe;
        glowScale = 1.08 + 0.1 * BREATH_DEPTH * breathe;
      }

      amp += (target - amp) * 0.08; // smooth ~300ms transitions
      if (!reduceMotion) {
        t += 0.016;
        wave += 0.016 * waveSpeed;
      }

      const cx = size / 2;
      const cy = size / 2;
      const R = size * 0.3;

      ctx.clearRect(0, 0, size, size);

      // attention ring (hearing) — a thin pulsing circle just outside the rim
      if (ring > 0.01) {
        ctx.beginPath();
        ctx.arc(cx, cy, R * 1.16, 0, Math.PI * 2);
        ctx.strokeStyle = `hsla(${hue}, 85%, 48%, ${0.7 * ring})`;
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      // breathing glow — soft, gradually-diluted edge (no hard rim)
      const glowR = R * glowScale;
      const glow = ctx.createRadialGradient(cx, cy, R * 0.72, cx, cy, glowR);
      glow.addColorStop(0, glowRGBA(glowOp));
      glow.addColorStop(0.5, glowRGBA(glowOp * 0.6));
      glow.addColorStop(0.82, glowRGBA(glowOp * 0.18));
      glow.addColorStop(1, glowRGBA(0));
      ctx.fillStyle = glow;
      ctx.beginPath();
      ctx.arc(cx, cy, glowR, 0, Math.PI * 2);
      ctx.fill();

      // orb body
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.clip();

      const body = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R);
      body.addColorStop(0, "#7C5CFF");
      body.addColorStop(0.5, "#4084FF");
      body.addColorStop(1, "#22D3EE");
      ctx.fillStyle = body;
      ctx.fillRect(cx - R, cy - R, R * 2, R * 2);

      // flowing sine waves inside the orb
      waves.forEach((w, i) => {
        ctx.beginPath();
        let first = true;
        for (let x = -R; x <= R; x += 2) {
          const envelope = Math.cos(((x / R) * Math.PI) / 2); // flat at edges
          const y =
            Math.sin((x / R) * Math.PI * w.freq + wave * w.speed * 3 + i * 1.3) *
            R * 0.42 * amp * envelope;
          if (first) {
            ctx.moveTo(cx + x, cy + y);
            first = false;
          } else {
            ctx.lineTo(cx + x, cy + y);
          }
        }
        ctx.strokeStyle = `rgba(255, 255, 255, ${w.alpha})`;
        ctx.lineWidth = w.width;
        ctx.lineCap = "round";
        ctx.stroke();
      });

      // glossy highlight
      const shine = ctx.createRadialGradient(
        cx - R * 0.35, cy - R * 0.4, 0,
        cx - R * 0.35, cy - R * 0.4, R * 0.9
      );
      shine.addColorStop(0, "rgba(255, 255, 255, 0.35)");
      shine.addColorStop(1, "rgba(255, 255, 255, 0)");
      ctx.fillStyle = shine;
      ctx.fillRect(cx - R, cy - R, R * 2, R * 2);
      ctx.restore();

      raf = requestAnimationFrame(draw);
    };

    const onVisibility = () => {
      cancelAnimationFrame(raf);
      if (!document.hidden) raf = requestAnimationFrame(draw);
    };

    raf = requestAnimationFrame(draw);
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [size]);

  return (
    <canvas
      ref={canvasRef}
      style={{ width: size, height: size }}
      aria-hidden="true"
    />
  );
}
