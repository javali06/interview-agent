// Author a VOICE/VIDEO interview's Visual Scenario Analysis phase — the
// media-driven counterpart to AddPhaseModal (written-response, text-only) and
// CodingPhaseModal (coding, voice-only). Mirrors both shells/styling.
//
// One modal does both "add" and "edit": `editPhaseId` set → prefilled from
// that existing phase; omitted → author a new one. Each item pairs one
// uploaded media file (image / video / audio, via the SAME phase-asset
// upload route image_description uses) with an admin-written question and
// coverage tags. Reorder is up/down buttons — no drag-and-drop exists
// anywhere else in this admin app, so this doesn't introduce a new
// interaction pattern. Save posts the WHOLE ordered item list either way:
// /add_scenario_phase for a new phase, /update_scenario_phase for an existing
// one (which keeps the phase id, since the eval plan and events.jsonl
// reference it). Media refs are never invented here or on the server — an
// item without an upload simply can't be saved (see `validate` below).
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import {
  addScenarioPhase,
  removeScenarioPhase,
  updateScenarioPhase,
  uploadPhaseAsset,
  type ScenarioItemPayload,
} from "../lib/cadenceReview";
import { parseCadenceYaml, type ParsedPhase, type ParsedScenarioItem } from "../lib/cadence";
import { checkAssetFile, fetchQuestionTypeCatalog, type QuestionTypeCatalog } from "../lib/questionTypes";
import { listPools, poolForPhase, SCENARIO_KIND, type PoolSummary } from "../lib/questionPools";
import { useToast } from "./Toaster";
import { ApiError } from "../lib/api";

type Props = {
  open: boolean;
  onClose: () => void;
  yaml: string;
  token: string;
  onYamlChange: (newYaml: string) => void;
  /** Set to EDIT an existing scenario phase (prefilled from the cadence);
   *  omitted/null → author a new one. */
  editPhaseId?: string | null;
};

type MediaKind = "image" | "video" | "audio";
type ItemMedia = { kind: MediaKind; ref: string; filename: string; mime_type: string };

type ItemDraft = {
  key: string;
  id?: string;
  media: ItemMedia | null;
  uploading: boolean;
  uploadError: string | null;
  question: string;
  tagsInput: string;   // the raw text box; committed tags land in `tags`
  tags: string[];
  maxFollowups: string; // typed value; parsed/clamped on save
};

let seq = 0;
const nextKey = () => `si${++seq}`;

function blankItem(): ItemDraft {
  return {
    key: nextKey(), media: null, uploading: false, uploadError: null,
    question: "", tagsInput: "", tags: [], maxFollowups: "2",
  };
}

function itemFromExisting(item: ParsedScenarioItem): ItemDraft {
  return {
    key: nextKey(), id: item.id,
    media: item.media ? { ...item.media } : null,
    uploading: false, uploadError: null,
    question: item.question || "",
    tagsInput: "", tags: [...(item.coverage_tags || [])],
    maxFollowups: String(item.max_followups ?? 2),
  };
}

// Infer the media kind from the browser-reported MIME type, falling back to
// the extension when the browser doesn't set one. `.webm` is deliberately
// NOT treated as video here even though its MIME type says "video/webm" — the
// backend's video rule excludes it (it's already claimed by the audio rule;
// see engine/brain/cadence/question_types.py ASSET_RULES["video"]'s comment),
// so a .webm pick is caught explicitly below and shown a conversion hint.
function inferMediaKind(file: File): MediaKind | null {
  const type = (file.type || "").split("/")[0];
  if (type === "image" || type === "video" || type === "audio") return type as MediaKind;
  const name = file.name.toLowerCase();
  if (/\.(png|jpe?g|webp|gif)$/.test(name)) return "image";
  if (/\.(mp4|mov|m4v)$/.test(name)) return "video";
  if (/\.(mp3|wav|m4a|ogg|oga|webm|flac)$/.test(name)) return "audio";
  return null;
}

const labelStyle = {
  display: "block", fontSize: 12, fontWeight: 600, color: "var(--text-2)", marginBottom: 6,
} as const;

const mediaUrl = (token: string, ref: string) =>
  `/api/sessions/${token}/phase-asset/${encodeURIComponent(ref)}`;

export function ScenarioPhaseModal({ open, onClose, yaml, token, onYamlChange, editPhaseId }: Props) {
  const toast = useToast();
  const [catalog, setCatalog] = useState<QuestionTypeCatalog | null>(null);
  const [items, setItems] = useState<ItemDraft[]>([]);
  const [name, setName] = useState("Visual Scenario Analysis");
  const [durationMin, setDurationMin] = useState("");
  const [busy, setBusy] = useState<"save" | "remove" | null>(null);
  const [pools, setPools] = useState<PoolSummary[]>([]);
  const [importing, setImporting] = useState(false);

  // Seed-once-per-open (and per target phase) guard — mirrors CodingPhaseModal.
  const seeded = useRef<string | null>(null);

  const existingPhase: ParsedPhase | null = editPhaseId
    ? (parseCadenceYaml(yaml)?.phases ?? []).find((p) => p.id === editPhaseId) ?? null
    : null;

  useEffect(() => {
    if (!open) { seeded.current = null; return; }
    const seedKey = editPhaseId || "__new__";
    if (seeded.current === seedKey) return;
    seeded.current = seedKey;
    fetchQuestionTypeCatalog()
      .then(setCatalog)
      .catch(() => toast.error("Could not load upload rules from the server."));
    // Only pools that actually hold scenario questions are worth offering.
    listPools()
      .then((r) => setPools((r.pools ?? []).filter(
        (p) => (p.kinds ?? []).includes(SCENARIO_KIND))))
      .catch(() => { /* importing is optional — manual items still work */ });
    if (existingPhase && (existingPhase.scenario_items?.length ?? 0) > 0) {
      setItems(existingPhase.scenario_items!.map(itemFromExisting));
      setName(existingPhase.intent || "Visual Scenario Analysis");
      setDurationMin(existingPhase.duration_s ? String(Math.round(existingPhase.duration_s / 60)) : "");
    } else {
      setItems([blankItem()]);
      setName("Visual Scenario Analysis");
      setDurationMin("");
    }
    // toast is captured intentionally, same rationale as CodingPhaseModal.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, editPhaseId]);

  if (!open) return null;

  const updateItem = (key: string, patch: Partial<ItemDraft>) =>
    setItems((prev) => prev.map((it) => (it.key === key ? { ...it, ...patch } : it)));

  const addItem = () => setItems((prev) => [...prev, blankItem()]);
  const removeItem = (key: string) =>
    setItems((prev) => (prev.length > 1 ? prev.filter((it) => it.key !== key) : prev));
  const moveItem = (key: string, dir: -1 | 1) =>
    setItems((prev) => {
      const i = prev.findIndex((it) => it.key === key);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= prev.length) return prev;
      const next = [...prev];
      [next[i], next[j]] = [next[j], next[i]];
      return next;
    });

  const pickFile = async (key: string, file: File | undefined) => {
    if (!file) return;
    const kind = inferMediaKind(file);
    const lower = file.name.toLowerCase();
    if (kind === "video" && lower.endsWith(".webm")) {
      updateItem(key, {
        uploadError: "Video must be .mp4, .mov, or .m4v — convert this .webm file first.",
      });
      return;
    }
    if (!kind) {
      updateItem(key, { uploadError: "Unrecognized file type — use an image, video, or audio file." });
      return;
    }
    const err = checkAssetFile(catalog?.asset_rules[kind], file);
    if (err) { updateItem(key, { uploadError: err }); return; }
    updateItem(key, { uploading: true, uploadError: null });
    try {
      const r = await uploadPhaseAsset(token, kind, file);
      updateItem(key, {
        uploading: false,
        media: { kind, ref: r.name, filename: file.name, mime_type: file.type || `${kind}/octet-stream` },
      });
    } catch (e) {
      updateItem(key, { uploading: false, uploadError: (e as ApiError).message || "Upload failed." });
    }
  };

  // Pull every scenario question out of one pool. The server already copied
  // each question's media into THIS interview's own session (see
  // questions_for_phase), so the returned ref is ready to use as-is — no
  // second upload round-trip, mirroring CodingPhaseModal's import.
  const importFromPool = async (poolId: string) => {
    if (!poolId) return;
    setImporting(true);
    try {
      const r = await poolForPhase(poolId, token, SCENARIO_KIND);
      const imported: ItemDraft[] = [];
      for (const q of r.questions ?? []) {
        const block = q.scenario;
        if (!block?.media?.ref) continue;
        imported.push({
          key: nextKey(),
          media: {
            kind: block.media.kind, ref: block.media.ref,
            filename: block.media.filename, mime_type: block.media.mime_type,
          },
          uploading: false, uploadError: null,
          question: q.text || "",
          tagsInput: "", tags: [...(q.coverage_tags || [])],
          maxFollowups: String(block.max_followups ?? 2),
        });
      }
      if (!imported.length) {
        toast.error("That pool has no scenario questions with uploaded media.");
        return;
      }
      setItems((prev) => {
        // Replace the single still-blank starter card rather than leaving an
        // empty item alongside the imported ones.
        const onlyBlank = prev.length === 1 && !prev[0].media && !prev[0].question.trim();
        return onlyBlank ? imported : [...prev, ...imported];
      });
      toast.success(`Imported ${imported.length} question${imported.length === 1 ? "" : "s"}.`);
    } catch (e) {
      toast.error((e as ApiError).message || "Failed to import from pool.");
    } finally {
      setImporting(false);
    }
  };

  const commitTag = (key: string, raw: string) => {
    const t = raw.trim();
    setItems((prev) => prev.map((it) => {
      if (it.key !== key) return it;
      if (!t || it.tags.some((x) => x.toLowerCase() === t.toLowerCase())) {
        return { ...it, tagsInput: "" };
      }
      return { ...it, tags: [...it.tags, t], tagsInput: "" };
    }));
  };
  const removeTag = (key: string, tag: string) =>
    setItems((prev) => prev.map((it) => (
      it.key === key ? { ...it, tags: it.tags.filter((t) => t !== tag) } : it
    )));

  // Mirrors the backend's rules (which stay authoritative) so the admin gets
  // one inline message naming the offending item instead of a round-trip.
  const validate = (): string | null => {
    if (items.length === 0) return "Add at least one item.";
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      const where = `Item ${i + 1}`;
      if (it.uploading) return `${where}: wait for the upload to finish.`;
      if (!it.media) return `${where}: upload a media file.`;
      if (!it.question.trim()) return `${where}: add a question.`;
      if (it.tags.length === 0) return `${where}: add at least one coverage tag.`;
      const mf = Number(it.maxFollowups);
      if (!Number.isFinite(mf) || mf < 0 || mf > 5) return `${where}: max follow-ups must be 0-5.`;
    }
    return null;
  };

  const buildPayload = (): ScenarioItemPayload[] =>
    items.map((it) => ({
      id: it.id,
      media: it.media as ItemMedia,
      question: it.question.trim(),
      coverage_tags: it.tags,
      max_followups: Math.max(0, Math.min(5, Math.round(Number(it.maxFollowups) || 0))),
    }));

  const onSave = async () => {
    const problem = validate();
    if (problem) { toast.error(problem); return; }
    setBusy("save");
    try {
      const durationS = durationMin.trim()
        ? Math.max(1, Math.round(Number(durationMin) * 60))
        : undefined;
      const r = existingPhase
        ? await updateScenarioPhase(token, yaml, {
            phase_id: editPhaseId as string, items: buildPayload(),
            duration_s: durationS, intent: name.trim() || undefined,
          })
        : await addScenarioPhase(token, yaml, {
            items: buildPayload(), duration_s: durationS, name: name.trim() || undefined,
          });
      if (r.ok && r.yaml) {
        onYamlChange(r.yaml);
        toast.success(existingPhase ? "Scenario phase saved." : "Scenario phase added.");
        onClose();
      } else {
        toast.error(r.error || "Save failed.");
      }
    } catch (e) {
      toast.error((e as ApiError).message || "Save failed.");
    } finally {
      setBusy(null);
    }
  };

  const onRemove = async () => {
    if (!existingPhase) return;
    const ok = window.confirm(
      "Remove this Visual Scenario Analysis phase from the cadence? This can be undone via the YAML editor.",
    );
    if (!ok) return;
    setBusy("remove");
    try {
      const r = await removeScenarioPhase(token, yaml, editPhaseId as string);
      if (r.ok && r.yaml) {
        onYamlChange(r.yaml);
        toast.success("Scenario phase removed.");
        onClose();
      } else {
        toast.error(r.error || "Remove failed.");
      }
    } catch (e) {
      toast.error((e as ApiError).message || "Remove failed.");
    } finally {
      setBusy(null);
    }
  };

  const rules = catalog?.asset_rules;
  const acceptExts = rules
    ? [...rules.image.extensions, ...rules.video.extensions, ...rules.audio.extensions].join(",")
    : undefined;
  const mb = (bytes: number | undefined) => (bytes ? Math.round(bytes / (1024 * 1024)) : "?");

  // Portal to <body>, same rationale as CodingPhaseModal (a mount-animation
  // ancestor creates a containing block that would otherwise mispin `fixed`).
  return createPortal(
    <div
      role="dialog"
      className="ds-light"
      aria-modal="true"
      onClick={onClose}
      style={{
        position: "fixed", inset: 0, background: "rgba(22,22,22,0.35)", zIndex: 5000,
        display: "flex", alignItems: "center", justifyContent: "center", padding: 20,
      }}
    >
      <div
        className="card"
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%", maxWidth: 760, maxHeight: "90vh", overflow: "hidden",
          display: "flex", flexDirection: "column", padding: 0,
          background: "var(--ink-2)", border: "1px solid var(--line-2)",
        }}
      >
        {/* Header */}
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "14px 16px", borderBottom: "1px solid var(--line)",
        }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, margin: 0 }}>
            {existingPhase ? "Edit scenario questions" : "Add scenario questions"}
          </h2>
          <button type="button" onClick={onClose} className="btn btn-ghost btn-sm" aria-label="Close"
                  style={{ padding: "4px 10px" }}>
            ✕
          </button>
        </div>

        {/* Name + duration */}
        <div style={{
          padding: "12px 16px", borderBottom: "1px solid var(--line)",
          display: "flex", flexWrap: "wrap", gap: 16,
        }}>
          <div style={{ flex: "1 1 260px" }}>
            <label style={labelStyle} htmlFor="scenario-name">Phase name</label>
            <input id="scenario-name" type="text" value={name} onChange={(e) => setName(e.target.value)}
                   className="input" style={{ width: "100%" }} />
          </div>
          <div>
            <label style={labelStyle} htmlFor="scenario-duration">Duration (minutes)</label>
            <input
              id="scenario-duration" type="number" min={1} step={1} value={durationMin}
              onChange={(e) => setDurationMin(e.target.value)}
              placeholder={`~${3 * Math.max(1, items.length)}`}
              className="input" style={{ width: 90, padding: "4px 8px" }}
            />
            <p className="muted-3" style={{ fontSize: 11, margin: "4px 0 0" }}>Blank = ~3 min/item</p>
          </div>
        </div>

        {/* Pull items out of an authored pool — same pattern as the coding
            phase's pool import. Only pools holding scenario questions with
            uploaded media are listed. */}
        {pools.length > 0 && (
          <div style={{
            padding: "10px 16px", borderBottom: "1px solid var(--line)",
            display: "flex", alignItems: "center", gap: 8,
          }}>
            <span className="muted-3" style={{ fontSize: 12 }}>
              Add from a question pool:
            </span>
            <select
              className="input"
              style={{ fontSize: 12.5, padding: "4px 8px", maxWidth: 260 }}
              value=""
              disabled={importing}
              onChange={(e) => { void importFromPool(e.target.value); e.target.value = ""; }}
            >
              <option value="">{importing ? "Loading…" : "Choose a pool…"}</option>
              {pools.map((p) => (
                <option key={p.pool_id} value={p.pool_id}>{p.pool_name}</option>
              ))}
            </select>
          </div>
        )}

        {/* Body — item cards */}
        <div style={{
          overflowY: "auto", padding: "12px 16px", flex: 1,
          display: "flex", flexDirection: "column", gap: 12,
        }}>
          {items.map((it, i) => (
            <div key={it.key} style={{ border: "1px solid var(--line)", borderRadius: 10, padding: 12 }}>
              <div style={{
                display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 8,
              }}>
                <span style={{ fontWeight: 600, fontSize: 13 }}>Item {i + 1}</span>
                <div style={{ display: "flex", gap: 4 }}>
                  <button type="button" className="btn btn-ghost btn-sm" style={{ padding: "2px 8px" }}
                          disabled={i === 0} onClick={() => moveItem(it.key, -1)} aria-label="Move item up">
                    ↑
                  </button>
                  <button type="button" className="btn btn-ghost btn-sm" style={{ padding: "2px 8px" }}
                          disabled={i === items.length - 1} onClick={() => moveItem(it.key, 1)}
                          aria-label="Move item down">
                    ↓
                  </button>
                  <button type="button" className="btn btn-ghost btn-sm"
                          style={{ padding: "2px 8px", color: "var(--danger)" }}
                          disabled={items.length <= 1} onClick={() => removeItem(it.key)}
                          aria-label="Remove item">
                    Remove
                  </button>
                </div>
              </div>

              {/* Media upload */}
              <div style={{ marginBottom: 10 }}>
                <label style={labelStyle}>Media</label>
                <input
                  type="file" accept={acceptExts} disabled={it.uploading}
                  onChange={(e) => void pickFile(it.key, e.target.files?.[0])}
                  className="input" style={{ width: "100%" }}
                />
                <p className="muted-3" style={{ fontSize: 11, margin: "4px 0 0" }}>
                  Image ({rules?.image.extensions.join(", ") ?? "…"}, up to {mb(rules?.image.max_bytes)} MB) ·
                  {" "}video ({rules?.video.extensions.join(", ") ?? "…"}, up to {mb(rules?.video.max_bytes)} MB —
                  convert .webm to .mp4 first) · audio ({rules?.audio.extensions.join(", ") ?? "…"}, up to{" "}
                  {mb(rules?.audio.max_bytes)} MB).
                </p>
                {it.uploading && (
                  <p className="muted-3" style={{ fontSize: 12, margin: "6px 0 0" }}>Uploading…</p>
                )}
                {it.uploadError && (
                  <p style={{ fontSize: 12, margin: "6px 0 0", color: "var(--danger)" }}>{it.uploadError}</p>
                )}
                {it.media && !it.uploading && (
                  <div style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 6 }}>
                    <span style={{ fontSize: 12, color: "var(--ok)" }}>
                      Uploaded: {it.media.filename} ({it.media.kind})
                    </span>
                    {it.media.kind === "image" && (
                      <img src={mediaUrl(token, it.media.ref)} alt=""
                           style={{ maxWidth: "100%", maxHeight: 180, borderRadius: 8, border: "1px solid var(--line)" }} />
                    )}
                    {it.media.kind === "video" && (
                      <video controls src={mediaUrl(token, it.media.ref)}
                             style={{ maxWidth: "100%", maxHeight: 180, borderRadius: 8, border: "1px solid var(--line)" }} />
                    )}
                    {it.media.kind === "audio" && (
                      <audio controls src={mediaUrl(token, it.media.ref)} style={{ width: "100%" }} />
                    )}
                  </div>
                )}
              </div>

              {/* Question */}
              <div style={{ marginBottom: 10 }}>
                <label style={labelStyle} htmlFor={`q-${it.key}`}>Question</label>
                <textarea
                  id={`q-${it.key}`} value={it.question}
                  onChange={(e) => updateItem(it.key, { question: e.target.value })}
                  rows={2} className="input" style={{ width: "100%" }}
                  placeholder="e.g. What is missing from this architecture diagram?"
                />
              </div>

              {/* Coverage tags */}
              <div style={{ marginBottom: 10 }}>
                <label style={labelStyle}>Coverage tags</label>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 6 }}>
                  {it.tags.map((t) => (
                    <span key={t} className="pill"
                          style={{ padding: "2px 9px", display: "flex", alignItems: "center", gap: 4 }}>
                      {t}
                      <button
                        type="button" onClick={() => removeTag(it.key, t)} aria-label={`Remove tag ${t}`}
                        style={{ background: "none", border: "none", color: "inherit", cursor: "pointer", padding: 0, fontSize: 12 }}
                      >
                        ✕
                      </button>
                    </span>
                  ))}
                </div>
                <input
                  type="text" value={it.tagsInput}
                  onChange={(e) => updateItem(it.key, { tagsInput: e.target.value })}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === ",") {
                      e.preventDefault();
                      commitTag(it.key, it.tagsInput);
                    }
                  }}
                  onBlur={() => commitTag(it.key, it.tagsInput)}
                  placeholder="Type a keyword, press Enter or comma"
                  className="input" style={{ width: "100%" }}
                />
                <p className="muted-3" style={{ fontSize: 11, margin: "4px 0 0" }}>
                  Keywords a good answer should touch on. Not all are required; the AI judges whether the
                  answer is good enough.
                </p>
              </div>

              {/* Max follow-ups */}
              <div>
                <label style={labelStyle} htmlFor={`mf-${it.key}`}>Max follow-ups</label>
                <input
                  id={`mf-${it.key}`} type="number" min={0} max={5} step={1}
                  value={it.maxFollowups}
                  onChange={(e) => updateItem(it.key, { maxFollowups: e.target.value })}
                  className="input" style={{ width: 70, padding: "4px 8px" }}
                />
                <span className="muted-3" style={{ fontSize: 11, marginLeft: 8 }}>0-5, default 2</span>
              </div>
            </div>
          ))}
          <button type="button" onClick={addItem} className="btn btn-ghost btn-sm" style={{ alignSelf: "flex-start" }}>
            + Add item
          </button>
        </div>

        {/* Footer */}
        <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "12px 16px", borderTop: "1px solid var(--line)" }}>
          {existingPhase && (
            <button
              type="button" onClick={onRemove} disabled={busy !== null}
              className="btn btn-ghost btn-sm" style={{ color: "var(--danger)", borderColor: "rgba(255,84,112,0.4)" }}
            >
              {busy === "remove" ? "Removing…" : "Remove phase"}
            </button>
          )}
          <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
            <button type="button" onClick={onClose} className="btn btn-ghost btn-sm" disabled={busy !== null}>
              Cancel
            </button>
            <button
              type="button" onClick={onSave} disabled={busy !== null} className="btn btn-sm"
              style={{ background: "var(--ds-lavender)", color: "var(--ds-accent-ink)", borderColor: "transparent", fontWeight: 600 }}
            >
              {busy === "save" ? "Saving…" : existingPhase ? "Save changes" : "Add phase"}
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
}
