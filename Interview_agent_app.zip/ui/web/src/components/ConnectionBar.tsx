// The small "signal bars" pill shown at the bottom of a live interview —
// mirrors the connection-quality indicator mobile OSes and Teams show during a
// call: a bar-count icon + a short label, always visible but never in the way.
// Pure presentation; see lib/connectionQuality.ts for the polling/bucketing.
import type { ConnQuality } from "../lib/connectionQuality";
import "../pages/CandidateLive.css";

const CONFIG: Record<
  ConnQuality["state"],
  { bars: number; color: string; label: string; pulse?: boolean }
> = {
  good: { bars: 4, color: "var(--ds-success)", label: "Good connection" },
  fair: { bars: 3, color: "var(--ds-warning)", label: "Fair connection" },
  poor: { bars: 1, color: "var(--ds-danger)", label: "Poor connection" },
  offline: { bars: 0, color: "var(--ds-danger)", label: "No internet connection" },
  reconnecting: { bars: 0, color: "var(--ds-warning)", label: "Reconnecting…", pulse: true },
};

export function ConnectionBar({ quality }: { quality: ConnQuality }) {
  const cfg = CONFIG[quality.state];
  const showMs = quality.rttMs != null && quality.state !== "offline" && quality.state !== "reconnecting";
  const title =
    quality.state === "offline"
      ? "No internet connection detected — your answers may not be sent until it's back."
      : quality.state === "reconnecting"
        ? "The live connection dropped — reconnecting automatically."
        : `${cfg.label}${showMs ? ` — ${quality.rttMs}ms to the interview server` : ""}`;

  return (
    <div className="cl-root cl-conn-pill" title={title} role="status" aria-live="polite">
      <SignalBars bars={cfg.bars} color={cfg.color} pulse={cfg.pulse} />
      <span>
        {cfg.label}
        {showMs && <span style={{ opacity: 0.7 }}> · {quality.rttMs}ms</span>}
      </span>
    </div>
  );
}

function SignalBars({ bars, color, pulse }: { bars: number; color: string; pulse?: boolean }) {
  const heights = [4, 7, 10, 13];
  return (
    <svg
      width="16"
      height="13"
      viewBox="0 0 16 13"
      aria-hidden="true"
      style={pulse ? { animation: "conn-bar-pulse 1.1s ease-in-out infinite" } : undefined}
    >
      {pulse && (
        <style>{"@keyframes conn-bar-pulse{0%,100%{opacity:.35}50%{opacity:1}}"}</style>
      )}
      {heights.map((h, i) => (
        <rect
          key={i}
          x={i * 4.2}
          y={13 - h}
          width={3}
          height={h}
          rx={0.75}
          fill={i < bars ? color : "var(--ds-border)"}
        />
      ))}
    </svg>
  );
}
