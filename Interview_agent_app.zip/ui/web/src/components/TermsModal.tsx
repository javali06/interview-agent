import { useEffect, useRef, useState } from "react";
import "../pages/CandidateLive.css";
import {
  INTERVIEW_TERMS,
  INTERVIEW_TERMS_NO_RECORDING,
  TERMS_INTRO,
  TERMS_INTRO_NO_RECORDING,
  TERMS_VERSION,
  TERMS_VERSION_NO_RECORDING,
} from "../lib/interviewTerms";

// Blocking Terms & Conditions modal shown right after the candidate clicks
// "Start interview". They must scroll/read and tick the acknowledgement before
// "Agree & continue" enables; "Decline" backs out to the lobby without starting
// the session. On accept we hand back the accepted version + timestamp so the
// caller can attach an auditable consent record to the session-start payload.
export type TermsConsent = { version: string; acceptedAt: string };

export function TermsModal({
  recordingEnabled,
  onAccept,
  onDecline,
}: {
  recordingEnabled: boolean;
  onAccept: (consent: TermsConsent) => void;
  onDecline: () => void;
}) {
  const [agreed, setAgreed] = useState(false);
  const intro = recordingEnabled ? TERMS_INTRO : TERMS_INTRO_NO_RECORDING;
  const sections = recordingEnabled ? INTERVIEW_TERMS : INTERVIEW_TERMS_NO_RECORDING;
  const version = recordingEnabled ? TERMS_VERSION : TERMS_VERSION_NO_RECORDING;

  // Soft fade at the bottom of the scroll area while there's more to read;
  // removed once actually scrolled to the end (not just "modal opened").
  const [atEnd, setAtEnd] = useState(false);
  const onBodyScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const el = e.currentTarget;
    setAtEnd(el.scrollHeight - el.scrollTop - el.clientHeight < 4);
  };
  const bodyRef = useRef<HTMLDivElement>(null);
  // Short terms (no recording) may fit without scrolling at all — compute
  // the initial state once mounted rather than waiting for a scroll event
  // that may never come.
  useEffect(() => {
    const el = bodyRef.current;
    if (el) setAtEnd(el.scrollHeight - el.scrollTop - el.clientHeight < 4);
  }, []);

  return (
    <div
      className="cl-root cl-modal-backdrop"
      role="dialog"
      aria-modal="true"
      aria-label="Interview terms and conditions"
    >
      <div className="cl-modal-card">
        <div className="cl-modal-head">
          <h2 className="cl-modal-title">Terms &amp; Conditions</h2>
          <p className="cl-modal-sub">{intro}</p>
        </div>

        <div ref={bodyRef} className="cl-modal-body" onScroll={onBodyScroll}>
          {sections.map((sec) => (
            <section key={sec.heading}>
              <h3 className="cl-modal-section-h">{sec.heading}</h3>
              {sec.body.map((para, i) => (
                <p key={i} className="cl-modal-section-p">{para}</p>
              ))}
            </section>
          ))}
          <p className="cl-modal-version">Terms version {version}</p>
          <div className={`cl-modal-fade${atEnd ? " at-end" : ""}`} />
        </div>

        {/* sticky footer: acknowledgement + actions. The backdrop itself
            reserves ~96px at the bottom (padding) so a browser's "you are
            sharing your screen" bar never covers these buttons. */}
        <div className="cl-modal-footer">
          <label className="cl-modal-consent">
            <input
              type="checkbox"
              checked={agreed}
              onChange={(e) => setAgreed(e.target.checked)}
            />
            <span>
              {recordingEnabled
                ? "I have read and understood these terms, and I consent to the recording and processing of my audio, video, screen, and related data — including their use for fraud and integrity analytics — as described above."
                : "I have read and understood these terms, and I consent to the processing of my audio and related data — including automated review of my transcript — as described above."}
            </span>
          </label>
          <div className="cl-modal-actions">
            <button type="button" onClick={onDecline} className="cl-btn cl-btn-secondary cl-btn-sm">Decline</button>
            <button
              type="button"
              disabled={!agreed}
              onClick={() => onAccept({ version, acceptedAt: new Date().toISOString() })}
              className="cl-btn cl-btn-primary cl-btn-sm"
            >
              Agree &amp; continue
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
