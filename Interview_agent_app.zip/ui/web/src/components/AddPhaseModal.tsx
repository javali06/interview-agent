// Author a TEXT interview's written-response phase ("Add Phase") — and edit one
// that already exists. Mirrors CodingPhaseModal's shell/props/styling.
//
// Flow: the modal opens on ONE control, the Question type dropdown. Picking a
// type reveals the rest (phase name, the type's shared config, and the list of
// questions), because every other field's identity depends on the type.
//
// A phase holds N questions of ONE type: each question card carries its own
// prompt, material, character limit and countdown, and cards can be added,
// edited and removed. Save posts the whole list — /add_phase for a new phase,
// /update_phase for an existing one (which keeps the phase id and every echoed
// question id, since the evaluation plan and events reference them).
//
// The form is DRIVEN BY THE BACKEND CATALOG (lib/questionTypes.ts): the type
// list and each type's fields — including whether a field is authored once for
// the phase or per question — come from
// engine/brain/cadence/question_types.py, so adding a question type there shows
// up here with no edit unless it needs a new widget kind (the `Field` switch).
import { useEffect, useId, useMemo, useRef, useState } from "react";
import type { CSSProperties } from "react";
import { createPortal } from "react-dom";
import { addPhase, updatePhase, uploadPhaseAsset, type PhaseQuestionPayload } from "../lib/cadenceReview";
import { parseCadenceYaml, type ParsedPhase, type ParsedQuestion } from "../lib/cadence";
import {
  checkAssetFile,
  fetchQuestionTypeCatalog,
  missingFields,
  phaseFields,
  questionFields,
  type DraftQuestion,
  type FieldValue,
  type QuestionField,
  type QuestionTypeCatalog,
  type QuestionTypeSpec,
} from "../lib/questionTypes";
import { listPools, poolForPhase, type PoolSummary } from "../lib/questionPools";
import { useToast } from "./Toaster";
import { ApiError } from "../lib/api";

type Props = {
  open: boolean;
  onClose: () => void;
  yaml: string;
  token: string;
  onYamlChange: (newYaml: string) => void;
  /** Set to EDIT an existing written-response phase (prefilled from the cadence);
   *  omitted/null → author a new phase. */
  editPhase?: ParsedPhase | null;
};

const labelStyle: CSSProperties = {
  display: "block",
  fontSize: 12,
  fontWeight: 600,
  color: "var(--text-2)",
  marginBottom: 6,
};

const DEFAULT_CHAR_LIMIT = "1500";
let draftSeq = 0;
const nextKey = () => `q${++draftSeq}`;

// Preview, client-side, of the phase id the backend will derive from the admin's
// typed name — mirrors cadence_service._phase_slug exactly (same regex, same
// fallback-to-the-type's-own-slug rule). Used ONLY to detect, before saving,
// that "Add phase" is about to land on a phase that already exists (so its
// questions can be shown rather than saving blind into a merge) — the backend
// remains the authority on the real id.
function previewPhaseSlug(name: string, fallback: string): string {
  let s = (name || "").trim().toLowerCase().replace(/[^a-z0-9_]+/g, "_");
  s = s.replace(/_+/g, "_").replace(/^_+|_+$/g, "");
  if (!s || !/^[a-z]/.test(s)) s = fallback;
  return s.slice(0, 40);
}

function blankQuestion(): DraftQuestion {
  return {
    key: nextKey(),
    prompt: "",
    charLimit: DEFAULT_CHAR_LIMIT,
    timed: false,
    timeLimitMin: "10",
    limitKind: "chars",
    values: {},
    previews: {},
  };
}

// An existing pool question → a draft card. Limits/material fall back to the
// PHASE-level block (that's how a legacy essay phase is shaped), and a
// word-limited question stays word-limited so editing it can't silently turn
// "300 words" into "300 characters".
function draftFromQuestion(
  q: ParsedQuestion,
  phase: ParsedPhase,
  token: string,
): DraftQuestion {
  const own = q.written_response || {};
  const shared = phase.written_response || {};
  const pick = <K extends keyof typeof own>(key: K) => own[key] ?? shared[key];
  const word = pick("word_limit");
  const char = pick("char_limit");
  const timeLimit = pick("time_limit_s") ?? null;
  const values: Record<string, FieldValue> = {};
  const previews: Record<string, string> = {};
  for (const name of [
    "source_text", "audio_asset", "image_asset",
    // Per question now; an older phase holds these at phase level, and `pick`
    // falls back there — so editing such a phase prefills each card correctly.
    "source_language", "target_language",
  ] as const) {
    const value = pick(name);
    if (typeof value === "string" && value.trim()) {
      values[name] = value;
      // Only the UPLOAD fields have something to preview; a language code or a
      // source passage is not an asset and must not get an asset URL.
      if (name === "audio_asset" || name === "image_asset") {
        previews[name] = `/api/sessions/${token}/phase-asset/${encodeURIComponent(value)}`;
      }
    }
  }
  // ground_truth: a plain string (transcription) or a list (translation /
  // image_description) — never an uploaded asset, so no preview to set.
  const groundTruth = pick("ground_truth");
  if (typeof groundTruth === "string" && groundTruth.trim()) {
    values.ground_truth = groundTruth;
  } else if (Array.isArray(groundTruth)) {
    const cleaned = groundTruth.filter((s): s is string => typeof s === "string" && s.trim().length > 0);
    if (cleaned.length) values.ground_truth = cleaned;
  }
  return {
    key: nextKey(),
    id: q.id,
    prompt: q.text || "",
    charLimit: String(word ?? char ?? DEFAULT_CHAR_LIMIT),
    timed: !!timeLimit,
    timeLimitMin: timeLimit ? String(Math.max(1, Math.round(timeLimit / 60))) : "10",
    limitKind: word != null ? "words" : "chars",
    values,
    previews,
  };
}

export function AddPhaseModal({ open, onClose, yaml, token, onYamlChange, editPhase }: Props) {
  const toast = useToast();
  const isEdit = !!editPhase;
  const [catalog, setCatalog] = useState<QuestionTypeCatalog | null>(null);
  const [busy, setBusy] = useState(false);
  // "" until the admin picks a type — step 1 of the form.
  const [questionType, setQuestionType] = useState("");
  const [name, setName] = useState("");
  const nameTouched = useRef(false);
  // Which existing phase the question list was last loaded from (see the
  // prefill effect below). Cleared on open so reopening reloads.
  const prefilledFrom = useRef<string | null>(null);
  // Phase-scoped config (the language pair), shared by every question.
  const [phaseValues, setPhaseValues] = useState<Record<string, string>>({});
  const [questions, setQuestions] = useState<DraftQuestion[]>([]);
  // Pools the admin can pull questions from. Filtered to the CHOSEN type below:
  // a translation phase must not be offered a transcription pool, whose
  // questions carry the wrong material entirely.
  const [pools, setPools] = useState<PoolSummary[]>([]);
  const [loadingPool, setLoadingPool] = useState(false);

  // Reset (or prefill, when editing) each time the modal opens.
  useEffect(() => {
    if (!open) return;
    setBusy(false);
    nameTouched.current = false;
    prefilledFrom.current = null;
    setPhaseValues({});
    if (editPhase) {
      const shared = editPhase.written_response || {};
      setQuestionType(shared.question_type || "comprehensive");
      setName(editPhase.id || "");
      setPhaseValues({
        ...(shared.source_language ? { source_language: shared.source_language } : {}),
        ...(shared.target_language ? { target_language: shared.target_language } : {}),
      });
      setQuestions(
        ((editPhase.question_pool || []) as ParsedQuestion[]).map((q) =>
          draftFromQuestion(q, editPhase, token),
        ),
      );
    } else {
      setQuestionType("");
      setName("");
      setQuestions([]);
    }
  }, [open, editPhase, token]);

  // Load the catalog once (it's static config) the first time the modal opens.
  useEffect(() => {
    if (!open || catalog) return;
    let alive = true;
    void fetchQuestionTypeCatalog()
      .then((c) => {
        if (alive) setCatalog(c);
      })
      .catch((e) => toast.error((e as ApiError).message || "Could not load question types."));
    return () => {
      alive = false;
    };
  }, [open, catalog, toast]);

  useEffect(() => {
    if (!open) return;
    let alive = true;
    void listPools()
      .then((r) => { if (alive) setPools(r.pools); })
      .catch(() => { /* pools are optional — authoring by hand still works */ });
    return () => { alive = false; };
  }, [open]);

  const spec: QuestionTypeSpec | null = useMemo(
    () => catalog?.question_types.find((t) => t.id === questionType) ?? null,
    [catalog, questionType],
  );

  // While ADDING (never while editing — that already targets one specific
  // phase), preview whether the name+type on screen matches a phase already in
  // the cadence: saving would fold the new questions into it rather than create
  // a second one (see cadence_service._merge_target). Surfacing that BEFORE
  // save — with the questions already there — is the whole point: otherwise the
  // admin adds a question, sees a phase count that didn't move, and has no way
  // to tell whether it worked or where it went.
  const mergeTarget: ParsedPhase | null = useMemo(() => {
    if (isEdit || !spec) return null;
    const targetId = previewPhaseSlug(name, spec.slug);
    const phase = (parseCadenceYaml(yaml)?.phases ?? []).find((p) => p.id === targetId);
    if (!phase || !phase.written_response) return null;
    const currentType = phase.written_response.question_type || "comprehensive";
    return currentType === questionType ? phase : null;
  }, [isEdit, spec, name, questionType, yaml]);

  // Landing on an existing phase turns "Add phase" INTO that phase's editor:
  // its questions load as ordinary editable cards — so the admin can retitle
  // them or change a limit/countdown — plus one blank card at the end for the
  // question they came to add. One list, one save, instead of appending blind
  // to questions they can't see. Renaming away from the match (i.e. back to
  // authoring a NEW phase) drops them again, since carrying them over would
  // duplicate the phase's content.
  //
  // Keyed on the target's ID, not the object: the memo above rebuilds a fresh
  // object on every keystroke, so depending on the object would re-run this on
  // each one and wipe the admin's in-progress edits.
  const mergeTargetId = mergeTarget?.id ?? null;
  useEffect(() => {
    if (isEdit || !open) return;
    if (prefilledFrom.current === mergeTargetId) return;
    prefilledFrom.current = mergeTargetId;
    if (!mergeTarget) {
      setQuestions([blankQuestion()]);      // authoring a new phase again
      return;
    }
    const shared = mergeTarget.written_response || {};
    setPhaseValues({
      ...(shared.source_language ? { source_language: shared.source_language } : {}),
      ...(shared.target_language ? { target_language: shared.target_language } : {}),
    });
    setQuestions([
      ...((mergeTarget.question_pool || []) as ParsedQuestion[]).map((q) =>
        draftFromQuestion(q, mergeTarget, token),
      ),
      // "Add phase" means the admin came here to ADD, so end the list with a
      // ready blank card (numbered after the existing ones) instead of making
      // them hit "+ Add question" first. The existing questions sit above it,
      // editable; Remove drops this card if they only meant to edit.
      blankQuestion(),
    ]);
  }, [isEdit, open, mergeTargetId, mergeTarget, token]);

  // Picking a type is what reveals the rest of the form: it seeds the phase name
  // with the type's label (editable), starts the question list with one card, and
  // clears any material from a previously-selected type (its fields don't apply —
  // the backend rejects foreign fields for exactly this reason).
  const changeType = (id: string) => {
    setQuestionType(id);
    const label = catalog?.question_types.find((t) => t.id === id)?.label || "";
    if (!isEdit && !nameTouched.current) setName(label);
    setPhaseValues({});
    setQuestions((prev) => (prev.length ? prev.map(() => blankQuestion()) : [blankQuestion()]));
  };

  // Only pools of the SAME kind — a translation phase can't use a transcription
  // pool's questions, they carry different material.
  const matchingPools = useMemo(
    // By what a pool CONTAINS, not what it is: pools mix kinds now, so a pool
    // qualifies when it holds at least one question of this phase's type.
    () => (spec ? pools.filter((p) => (p.kinds ?? [p.pool_kind]).includes(spec.id)) : []),
    [pools, spec],
  );

  // EVERY hook must run before this early return — a useMemo placed after it is
  // a CONDITIONAL hook, so opening the modal changed the hook count and React
  // tore the whole tree down (the "Add phase" click went to a blank page).
  if (!open) return null;

  const loadFromPool = async (poolId: string) => {
    if (!poolId) return;
    setLoadingPool(true);
    try {
      // The server copies any clip/image into THIS interview on the way out, so
      // the phase never depends on the pool afterwards.
      // Ask for THIS phase's kind only — the server filters, so a phase can
      // never be handed a question whose material it has nowhere to put.
      const r = await poolForPhase(poolId, token, spec!.id);
      const drafts: DraftQuestion[] = r.questions.map((q) => {
        const wr = (q.written_response || {}) as Record<string, unknown>;
        const values: Record<string, FieldValue> = {};
        const previews: Record<string, string> = {};
        for (const f of questionFields(spec!)) {
          const v = wr[f.name];
          if (Array.isArray(v)) {
            // string_list fields (ground truth) arrive as arrays.
            if (v.length) values[f.name] = v.map(String);
          } else if (typeof v === "string" && v.trim()) {
            values[f.name] = v;
            // The server has ALREADY copied the clip/image into this interview,
            // so preview it from the interview's own asset route — otherwise a
            // pool-loaded question showed an upload box with no sign of the
            // file that is actually attached.
            if (f.kind === "asset_audio" || f.kind === "asset_image") {
              previews[f.name] = `/api/sessions/${token}/phase-asset/${encodeURIComponent(v)}`;
            }
          }
        }
        const secs = typeof wr.time_limit_s === "number" ? wr.time_limit_s : null;
        return {
          key: nextKey(),
          prompt: q.text || "",
          charLimit: String(wr.char_limit ?? wr.word_limit ?? DEFAULT_CHAR_LIMIT),
          limitKind: wr.word_limit != null ? "words" : "chars",
          timed: secs != null,
          timeLimitMin: secs != null ? String(Math.max(1, Math.round(secs / 60))) : "10",
          values,
          previews,
        };
      });
      if (!drafts.length) {
        toast.error("That pool has no questions of this type.");
        return;
      }
      // APPEND, so a pool load never silently discards questions already typed.
      setQuestions((prev) => [...prev.filter((q) => q.prompt.trim() || Object.keys(q.values).length), ...drafts]);
      if (r.assets_missing.length) {
        toast.error(`Couldn't copy: ${r.assets_missing.join(", ")} — re-attach before saving.`);
      } else {
        toast.success(`Added ${drafts.length} question${drafts.length === 1 ? "" : "s"} from “${r.pool_name}”.`);
      }
    } catch (e) {
      toast.error((e as ApiError).message || "Could not load that pool.");
    } finally { setLoadingPool(false); }
  };

  const patchQuestion = (key: string, patch: Partial<DraftQuestion>) =>
    setQuestions((prev) => prev.map((q) => (q.key === key ? { ...q, ...patch } : q)));

  const missing = spec ? missingFields(spec, phaseValues, questions) : [];

  const onSave = async () => {
    if (!spec) return;
    if (missing.length) {
      toast.error(`Fill in: ${missing.slice(0, 4).join(", ")}${missing.length > 4 ? "…" : ""}.`);
      return;
    }
    setBusy(true);
    try {
      const payload: PhaseQuestionPayload[] = questions.map((q) => {
        const limit = Math.max(1, Math.round(Number(q.charLimit)));
        return {
          ...(q.id ? { id: q.id } : {}),
          prompt: q.prompt.trim(),
          // A legacy word-limited question keeps its unit; everything new is
          // character-limited.
          ...(q.limitKind === "words" ? { word_limit: limit } : { char_limit: limit }),
          // Untimed → null; timed → MINUTES × 60 (min 1 min).
          time_limit_s: q.timed ? Math.max(1, Math.round(Number(q.timeLimitMin))) * 60 : null,
          // q.values is keyed dynamically by the type's field names (string for
          // most kinds, string[] for "string_list" fields like ground_truth) —
          // its shape matches PhaseQuestionPayload's per-field types by
          // construction (the Field renderer below only ever writes the kind
          // each field declares), which a plain Record type can't express.
          ...(q.values as unknown as Partial<PhaseQuestionPayload>),
        };
      });
      const shared = {
        question_type: spec.id,
        source_language: phaseValues.source_language,
        target_language: phaseValues.target_language,
        questions: payload,
      };
      // Targeting a phase that already exists (whether via the Edit button or by
      // naming it in the Add form) goes through /update_phase: it replaces the
      // phase's question list in place, so edits to EXISTING questions actually
      // persist, and every echoed question id is preserved — those ids are what
      // the evaluation plan and the interview transcript reference. /add_phase
      // can only append, so it would silently ignore those edits.
      const targetPhaseId = isEdit ? editPhase?.id || "" : mergeTarget?.id || "";
      const r = targetPhaseId
        ? await updatePhase(token, yaml, { ...shared, phase_id: targetPhaseId })
        : await addPhase(token, yaml, { ...shared, name: name.trim() || undefined });
      if (r.ok && r.yaml) {
        onYamlChange(r.yaml);
        const n = `${payload.length} question${payload.length === 1 ? "" : "s"}`;
        toast.success(
          targetPhaseId
            ? `“${targetPhaseId}” phase saved (${n}).`
            : `${spec.label} phase added (${n}).`,
        );
        onClose();
      } else {
        toast.error(r.error || "Save failed.");
      }
    } catch (e) {
      toast.error((e as ApiError).message || "Save failed.");
    } finally {
      setBusy(false);
    }
  };

  // Portal to <body> so position:fixed resolves against the viewport (same
  // reasoning as CodingPhaseModal — a transformed .screen-enter ancestor would
  // otherwise pin the overlay).
  return createPortal(
    <div
      role="dialog"
      className="ds-light"
      aria-modal="true"
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(22,22,22,0.35)",
        zIndex: 5000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
      }}
    >
      <div
        className="card"
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%",
          maxWidth: 640,
          maxHeight: "90vh",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          padding: 0,
          background: "var(--ink-2)",
          border: "1px solid var(--line-2)",
        }}
      >
        {/* Header */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "14px 16px",
            borderBottom: "1px solid var(--line)",
          }}
        >
          <h2 style={{ fontSize: 16, fontWeight: 700, margin: 0 }}>
            {isEdit ? `Edit phase · ${editPhase?.id}` : "Add phase"}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="btn btn-ghost btn-sm"
            aria-label="Close"
            style={{ padding: "4px 10px" }}
          >
            ✕
          </button>
        </div>

        {/* Body — form */}
        <div style={{ overflowY: "auto", padding: "14px 16px", flex: 1, display: "flex", flexDirection: "column", gap: 14 }}>
          {!catalog ? (
            <p className="muted-3" style={{ fontSize: 13, margin: 0 }}>Loading question types…</p>
          ) : (
            <>
              {/* STEP 1 — the only control until a type is chosen. */}
              <div>
                <label style={labelStyle} htmlFor="phase-question-type">Question type</label>
                <select
                  id="phase-question-type"
                  value={questionType}
                  onChange={(e) => changeType(e.target.value)}
                  className="input"
                  style={{ width: "100%" }}
                >
                  <option value="">Select a question type…</option>
                  {catalog.question_types.map((t) => (
                    <option key={t.id} value={t.id}>{t.label}</option>
                  ))}
                </select>
                <p className="muted-3" style={{ fontSize: 12, margin: "6px 0 0" }}>
                  {spec ? spec.description : "Pick the kind of written task; its settings appear next."}
                </p>
              </div>

              {/* STEP 2 — everything below depends on the chosen type. */}
              {spec && (
                <>
                  <div>
                    <label style={labelStyle} htmlFor="phase-name">Phase name</label>
                    <input
                      id="phase-name"
                      type="text"
                      value={name}
                      disabled={isEdit}
                      onChange={(e) => {
                        nameTouched.current = true;
                        setName(e.target.value);
                      }}
                      className="input"
                      style={{ width: "100%" }}
                    />
                    <p className="muted-3" style={{ fontSize: 12, margin: "6px 0 0" }}>
                      {isEdit
                        ? "The phase id can't change — the evaluation plan and the interview transcript reference it."
                        : mergeTarget
                          ? `Matches the existing “${mergeTarget.id}” phase — its questions are loaded below and saving updates them. Rename to create a separate phase instead.`
                          : "Defaults to the question type; edit it to name this phase."}
                    </p>
                  </div>

                  {/* Phase-scoped config (the language pair) — set once. */}
                  {phaseFields(spec).map((f) => (
                    <Field
                      key={f.name}
                      field={f}
                      catalog={catalog}
                      token={token}
                      value={phaseValues[f.name] || ""}
                      preview=""
                      // Phase-scoped fields are always "language" kind (a plain
                      // string) — String(v) is a no-op there, just keeps the type
                      // honest against Field's wider (string | string[]) value.
                      onValue={(v) => setPhaseValues((prev) => ({ ...prev, [f.name]: String(v) }))}
                    />
                  ))}

                  {/* Pull ready-made questions instead of typing them. Only
                      pools of this exact type are offered. */}
                  {matchingPools.length > 0 && (
                    <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                      <label className="lbl" style={{ margin: 0 }} htmlFor="pool-pick">
                        Load from a question pool
                      </label>
                      <select
                        id="pool-pick" className="input" defaultValue=""
                        style={{ padding: "6px 10px", flex: "1 1 220px" }}
                        disabled={loadingPool}
                        onChange={(e) => { void loadFromPool(e.target.value); e.currentTarget.value = ""; }}
                      >
                        <option value="">{loadingPool ? "Loading…" : "Choose a pool…"}</option>
                        {matchingPools.map((p) => (
                          <option key={p.pool_id} value={p.pool_id}>
                            {p.pool_name} · {p.question_count} question{p.question_count === 1 ? "" : "s"}
                          </option>
                        ))}
                      </select>
                      <span className="muted-3" style={{ fontSize: 12 }}>
                        Questions are copied in — you can edit them here without changing the pool.
                      </span>
                    </div>
                  )}

                  {/* One list, whether authoring a new phase or extending an
                      existing one — the existing questions are editable cards,
                      so a limit or countdown can be corrected in place and the
                      numbering runs 1..N across the whole phase. */}
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
                    <span style={{ fontSize: 13, fontWeight: 700 }}>
                      Questions
                      <span className="muted-3" style={{ fontWeight: 500 }}> · {questions.length}</span>
                    </span>
                    <span className="muted-3" style={{ fontSize: 12 }}>
                      Answered one at a time, in this order
                    </span>
                  </div>

                  {questions.map((q, i) => (
                    <QuestionCard
                      key={q.key}
                      index={i}
                      spec={spec}
                      catalog={catalog}
                      token={token}
                      draft={q}
                      canRemove={questions.length > 1}
                      onPatch={(patch) => patchQuestion(q.key, patch)}
                      onRemove={() => setQuestions((prev) => prev.filter((x) => x.key !== q.key))}
                    />
                  ))}

                  <button
                    type="button"
                    onClick={() => setQuestions((prev) => prev.concat(blankQuestion()))}
                    className="btn btn-ghost btn-sm"
                    style={{ alignSelf: "flex-start" }}
                  >
                    + Add question
                  </button>
                </>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            gap: 8,
            padding: "12px 16px",
            borderTop: "1px solid var(--line)",
          }}
        >
          {spec && missing.length > 0 && (
            <span className="muted-3" style={{ marginRight: "auto", fontSize: 12 }}>
              Missing: {missing.slice(0, 2).join(", ")}{missing.length > 2 ? ` +${missing.length - 2} more` : ""}
            </span>
          )}
          <button type="button" onClick={onClose} className="btn btn-ghost btn-sm" disabled={busy}>
            Cancel
          </button>
          <button
            type="button"
            onClick={onSave}
            disabled={!spec || missing.length > 0 || busy}
            className="btn btn-sm"
            style={{
              background: "var(--ds-lavender)",
              color: "var(--ds-accent-ink)",
              borderColor: "transparent",
              fontWeight: 600,
            }}
          >
            {busy ? "Saving…" : isEdit ? "Save changes" : "Save"}
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}

// One question in the phase: its prompt, its material, its limit, its countdown.
function QuestionCard({
  index,
  spec,
  catalog,
  token,
  draft,
  canRemove,
  onPatch,
  onRemove,
}: {
  index: number;
  spec: QuestionTypeSpec;
  catalog: QuestionTypeCatalog;
  token: string;
  draft: DraftQuestion;
  canRemove: boolean;
  onPatch: (patch: Partial<DraftQuestion>) => void;
  onRemove: () => void;
}) {
  const limitLabel = draft.limitKind === "words" ? "Word limit" : "Character limit";
  return (
    <div
      style={{
        border: "1px solid var(--line)",
        borderRadius: 10,
        padding: "12px 14px",
        display: "flex",
        flexDirection: "column",
        gap: 12,
        background: "var(--panel)",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span style={{ fontSize: 12.5, fontWeight: 700 }}>Question {index + 1}</span>
        {draft.id && (
          <span className="muted-3" style={{ fontSize: 11, fontFamily: "var(--mono)" }}>{draft.id}</span>
        )}
        <button
          type="button"
          onClick={onRemove}
          disabled={!canRemove}
          className="btn btn-ghost btn-sm"
          style={{ marginLeft: "auto", padding: "2px 10px" }}
          title={canRemove ? "Remove this question" : "A phase needs at least one question"}
        >
          Remove
        </button>
      </div>

      {/* Question-scoped material (audio clip / source passage / image). */}
      {questionFields(spec).map((f) => (
        <Field
          key={f.name}
          field={f}
          catalog={catalog}
          token={token}
          value={draft.values[f.name] ?? (f.kind === "string_list" ? [] : "")}
          preview={draft.previews[f.name] || ""}
          onValue={(v, previewUrl) =>
            onPatch({
              values: { ...draft.values, [f.name]: v },
              previews: { ...draft.previews, [f.name]: previewUrl || "" },
            })
          }
        />
      ))}

      {/* Instructions: hidden for transcription/translation/image_description —
          those types already have real material (audio/source text/image) plus
          a synthesized standard instruction, so a hand-typed one only risks
          drifting from what the candidate is actually graded against. Shown
          (and required) for comprehensive, where the instructions ARE the
          question with no other field to fall back on. Data-driven off the
          catalog (spec.prompt_hidden) so a type's own definition is the single
          source of truth, not a hardcoded id check here. */}
      {!spec.prompt_hidden && (
        <div>
          <label style={labelStyle} htmlFor={`prompt-${draft.key}`}>{spec.prompt_label}</label>
          <textarea
            id={`prompt-${draft.key}`}
            value={draft.prompt}
            onChange={(e) => onPatch({ prompt: e.target.value })}
            rows={4}
            placeholder={spec.prompt_placeholder}
            className="input"
            style={{ width: "100%" }}
          />
        </div>
      )}

      <div style={{ display: "flex", flexWrap: "wrap", alignItems: "flex-end", gap: 16 }}>
        <div>
          <label style={labelStyle} htmlFor={`limit-${draft.key}`}>{limitLabel}</label>
          <input
            id={`limit-${draft.key}`}
            type="number"
            min={1}
            value={draft.charLimit}
            onChange={(e) => onPatch({ charLimit: e.target.value })}
            className="input"
            style={{ width: 120 }}
          />
        </div>

        <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, color: "var(--text-2)", paddingBottom: 8 }}>
          <input
            type="checkbox"
            checked={draft.timed}
            onChange={(e) => onPatch({ timed: e.target.checked })}
          />
          Timed
        </label>

        {draft.timed && (
          <div>
            <label style={labelStyle} htmlFor={`time-${draft.key}`}>Time limit (min)</label>
            <input
              id={`time-${draft.key}`}
              type="number"
              min={1}
              value={draft.timeLimitMin}
              onChange={(e) => onPatch({ timeLimitMin: e.target.value })}
              className="input"
              style={{ width: 120 }}
            />
          </div>
        )}
      </div>

      <p className="muted-3" style={{ fontSize: 12, margin: 0 }}>
        {draft.timed
          ? "This question's countdown starts when it's shown and auto-submits at zero."
          : "Untimed — the candidate submits this question when they're ready."}
      </p>
    </div>
  );
}

// One config field, rendered by its `kind`. A new question type only needs code
// here if it introduces a kind that isn't already handled.
function Field({
  field,
  catalog,
  token,
  value,
  preview,
  onValue,
}: {
  field: QuestionField;
  catalog: QuestionTypeCatalog;
  token: string;
  value: FieldValue;
  preview: string;
  onValue: (value: FieldValue, previewUrl?: string) => void;
}) {
  const toast = useToast();
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const id = `phase-field-${field.name}-${useId()}`;
  // Every kind but "string_list" holds a plain string.
  const strValue = typeof value === "string" ? value : "";

  const help = field.help ? (
    <p className="muted-3" style={{ fontSize: 12, margin: "6px 0 0" }}>{field.help}</p>
  ) : null;

  if (field.kind === "string_list") {
    const items = Array.isArray(value) ? value : [];
    const update = (i: number, v: string) => {
      const next = items.slice();
      next[i] = v;
      onValue(next);
    };
    const remove = (i: number) => onValue(items.filter((_, j) => j !== i));
    const add = () => onValue([...items, ""]);
    return (
      <div>
        <label style={labelStyle}>{field.label}</label>
        {items.length === 0 && (
          <p className="muted-3" style={{ fontSize: 12, margin: "0 0 8px" }}>
            No entries yet. Add at least one.
          </p>
        )}
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {items.map((v, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <input
                className="input"
                style={{ flex: "1 1 auto", minWidth: 0 }}
                value={v}
                onChange={(e) => update(i, e.target.value)}
              />
              <button
                type="button"
                onClick={() => remove(i)}
                className="btn btn-ghost btn-sm"
                style={{ flexShrink: 0, padding: "4px 8px" }}
                title="Remove this entry"
              >
                ✕
              </button>
            </div>
          ))}
        </div>
        <button type="button" onClick={add} className="btn btn-ghost btn-sm" style={{ marginTop: 8 }}>
          + Add entry
        </button>
        {help}
      </div>
    );
  }

  if (field.kind === "language") {
    return (
      <div>
        <label style={labelStyle} htmlFor={id}>{field.label}</label>
        <select
          id={id}
          value={strValue}
          onChange={(e) => onValue(e.target.value)}
          className="input"
          style={{ width: "100%" }}
        >
          <option value="">Select a language…</option>
          {catalog.languages.map((l) => (
            <option key={l.code} value={l.code}>{l.label}</option>
          ))}
        </select>
        {help}
      </div>
    );
  }

  if (field.kind === "long_text") {
    return (
      <div>
        <label style={labelStyle} htmlFor={id}>{field.label}</label>
        <textarea
          id={id}
          value={strValue}
          onChange={(e) => onValue(e.target.value)}
          rows={6}
          className="input"
          style={{ width: "100%" }}
        />
        {help}
      </div>
    );
  }

  if (field.kind === "asset_audio" || field.kind === "asset_image") {
    const assetKind = field.asset_kind || (field.kind === "asset_audio" ? "audio" : "image");
    const rule = catalog.asset_rules[assetKind];
    // Uploaded on SELECT (not on Save) so the admin sees a real preview of what
    // the candidate will get. An abandoned modal leaves an unreferenced blob
    // under <token>/phase_assets/ — token-scoped and tiny, same as a replaced
    // resume upload.
    const pick = async (file: File | undefined) => {
      if (!file) return;
      const err = checkAssetFile(rule, file);
      if (err) {
        toast.error(`${field.label}: ${err}`);
        return;
      }
      setUploading(true);
      try {
        const r = await uploadPhaseAsset(token, assetKind, file);
        onValue(r.name, r.url);
      } catch (e) {
        toast.error((e as ApiError).message || "Upload failed.");
      } finally {
        setUploading(false);
        if (inputRef.current) inputRef.current.value = "";  // allow re-picking the same file
      }
    };
    return (
      <div>
        <label style={labelStyle} htmlFor={id}>{field.label}</label>
        <input
          id={id}
          ref={inputRef}
          type="file"
          accept={(rule?.extensions || []).join(",")}
          disabled={uploading}
          onChange={(e) => void pick(e.target.files?.[0])}
          className="input"
          style={{ width: "100%" }}
        />
        {uploading && (
          <p className="muted-3" style={{ fontSize: 12, margin: "6px 0 0" }}>Uploading…</p>
        )}
        {strValue && !uploading && (
          <div style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 8 }}>
            <span style={{ fontSize: 12, color: "var(--ok)" }}>Uploaded: {strValue}</span>
            {preview && assetKind === "audio" && (
              <audio controls src={preview} style={{ width: "100%" }} />
            )}
            {preview && assetKind === "image" && (
              <img
                src={preview}
                alt={field.label}
                style={{ maxWidth: "100%", maxHeight: 200, borderRadius: 8, border: "1px solid var(--line)" }}
              />
            )}
          </div>
        )}
        {help}
      </div>
    );
  }

  // "text" (and any unknown kind) → a plain single-line input.
  return (
    <div>
      <label style={labelStyle} htmlFor={id}>{field.label}</label>
      <input
        id={id}
        type="text"
        value={strValue}
        onChange={(e) => onValue(e.target.value)}
        className="input"
        style={{ width: "100%" }}
      />
      {help}
    </div>
  );
}
