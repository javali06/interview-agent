// Benchmark evaluation view (v2). Renders the `benchmark` object on
// evaluation.json as a grand total + a stack of per-phase summary tiles; each
// tile expands ("show more details") into the plugin's DetailView (chosen by
// view_id) with per-question marks, breakdown, and clickable evidence.
import { useState } from "react";
import { getDetailView, marks, SummaryTile } from "./eval-views";
import type { Benchmark, JumpToTrace, ReviewApi } from "./eval-views/types";

export default function BenchmarkPanel({ benchmark, onJump, review }: {
  benchmark: Benchmark; onJump?: JumpToTrace; review?: ReviewApi;
}) {
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const t = benchmark.total;
  // Only show graded phases (a plugin actually ran). Ungraded ones carry no
  // results and shouldn't appear as tiles.
  const phases = benchmark.phases.filter((p) => p.results.length > 0);
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div className="card" style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", padding: "16px 20px" }}>
        <div>
          <div className="muted-3" style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.12em" }}>Benchmark score</div>
          <div style={{ fontSize: 30, fontWeight: 800, fontVariantNumeric: "tabular-nums" }}>{marks(t.marks_earned, t.marks_possible)}</div>
          {/* When a reviewer has adjusted anything the headline is THEIR total,
              and the model's own stays visible — both are true, one is final. */}
          {benchmark.total_ai_only && (
            <div className="muted-3" style={{ fontSize: 12, marginTop: 2 }}>
              AI scored {marks(benchmark.total_ai_only.marks_earned, benchmark.total_ai_only.marks_possible)} · adjusted by a reviewer
            </div>
          )}
        </div>
        <div className="muted" style={{ textAlign: "right", fontSize: 14 }}>{t.pct}% · {phases.length} graded phase{phases.length === 1 ? "" : "s"}</div>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {phases.map((phase) => {
          const expanded = !!open[phase.phase_id];
          return (
            <div key={phase.phase_id}>
              <SummaryTile phase={phase} expanded={expanded}
                onToggle={() => setOpen((o) => ({ ...o, [phase.phase_id]: !o[phase.phase_id] }))} />
              {expanded && (
                <div style={{ marginTop: 8, paddingLeft: 8, display: "flex", flexDirection: "column", gap: 12 }}>
                  {phase.results.map((result, i) => {
                    const Detail = getDetailView(result.view_id);
                    return (
                      <div key={i}>
                        <div className="muted-3" style={{ marginBottom: 4, fontSize: 11 }}>
                          Plugin: <span style={{ fontFamily: "var(--mono)" }}>{result.plugin_id}</span>
                          {" · "}criteria saved for this phase
                        </div>
                        <Detail result={result} onJump={onJump} review={review} />
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
