import type { ReactNode } from "react";

// Light top header with the brand's two-tier title: a small bold category
// label above a regular-weight page title. Used by pages inside `.ds-light`.
export function PageHeader({
  category, title, sub, back, actions,
}: {
  category: string;
  title: ReactNode;
  sub?: ReactNode;
  back?: ReactNode;
  actions?: ReactNode;
}) {
  return (
    <header className="ds-page-header">
      <div className="ds-page-header-inner">
        <div style={{ minWidth: 0 }}>
          {back}
          <span className="ds-eyebrow">{category}</span>
          <h1 className="page-title">{title}</h1>
          {sub && <div className="page-sub">{sub}</div>}
        </div>
        {actions && <div className="ds-page-actions">{actions}</div>}
      </div>
    </header>
  );
}
