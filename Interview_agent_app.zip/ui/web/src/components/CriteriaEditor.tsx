// Row editor for the rubric_marks `criteria` field: the TA adds each option in
// its OWN textboxes (description + marks) and removes/reorders freely — instead
// of hand-editing a JSON blob. The LLM later returns which option NUMBERS apply
// and a script sums their marks, so the numbering shown here is exactly what the
// judge sees. Dark-themed (.input + var(--*)).
import type { Criterion } from "../lib/evalPlan";

export default function CriteriaEditor({ value, onChange }: {
  value: Criterion[];
  onChange: (next: Criterion[]) => void;
}) {
  const rows = Array.isArray(value) ? value : [];

  const update = (i: number, patch: Partial<Criterion>) =>
    onChange(rows.map((r, j) => (j === i ? { ...r, ...patch } : r)));
  const remove = (i: number) => onChange(rows.filter((_, j) => j !== i));
  const add = () => onChange([...rows, { description: "", marks: 1 }]);

  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ marginBottom: 6, fontSize: 11, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase", color: "var(--text-3)" }}>
        Rubric options
      </div>
      {rows.length === 0 && (
        <p className="muted-3" style={{ fontSize: 12, margin: "0 0 8px" }}>
          No options yet. Add each thing you want to reward or penalise, with its marks.
        </p>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        {rows.map((r, i) => (
          <div key={i} style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <span className="muted-3" style={{ width: 18, textAlign: "right", fontSize: 12, fontVariantNumeric: "tabular-nums" }}>{i + 1}.</span>
            <input
              className="input"
              style={{ flex: "1 1 auto", minWidth: 0 }}
              placeholder="e.g. Explains the time/space tradeoff"
              value={r.description ?? ""}
              onChange={(e) => update(i, { description: e.target.value })}
            />
            <input
              type="number"
              className="input"
              style={{ width: 72, flexShrink: 0 }}
              step="any"
              title="Marks to add when this option applies (may be negative)"
              value={r.marks === undefined || r.marks === null ? "" : String(r.marks)}
              onChange={(e) => update(i, { marks: e.target.value === "" ? 0 : Number(e.target.value) })}
            />
            <button
              type="button"
              onClick={() => remove(i)}
              className="btn btn-ghost btn-sm"
              style={{ flexShrink: 0, padding: "4px 8px" }}
              title="Remove this option"
            >
              ✕
            </button>
          </div>
        ))}
      </div>
      <button type="button" onClick={add} className="btn btn-ghost btn-sm" style={{ marginTop: 8 }}>
        + Add option
      </button>
      <div className="muted-3" style={{ marginTop: 6, fontSize: 11 }}>
        Use positive marks to reward (e.g. +2), negative to penalise (e.g. −1). The LLM picks which
        options apply per answer; their marks are summed.
      </div>
    </div>
  );
}
