// Picker for the cadence's coding phase. One modal does both "add" and "edit"
// flows — the only thing that changes is whether `selectedIds` starts empty
// or is seeded from the existing phase. Save calls /set_coding_phase which
// either creates the phase or updates it in place; Remove drops it.
import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { parseCadenceYaml } from "../lib/cadence";
import {
  listCodingQuestions,
  removeCodingPhase,
  setCodingPhase,
  type CodingQuestionPick,
  type InlineCodingQuestion,
} from "../lib/cadenceReview";
import { CODING_KIND, listPools, poolForPhase, type PoolSummary } from "../lib/questionPools";
import { useToast } from "./Toaster";
import { ApiError } from "../lib/api";

type Props = {
  open: boolean;
  onClose: () => void;
  yaml: string;
  token: string;
  onYamlChange: (newYaml: string) => void;
};

type Difficulty = "all" | "easy" | "medium" | "hard";

export function CodingPhaseModal({ open, onClose, yaml, token, onYamlChange }: Props) {
  const toast = useToast();
  const [library, setLibrary] = useState<CodingQuestionPick[]>([]);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState<"save" | "remove" | null>(null);
  const [filterDifficulty, setFilterDifficulty] = useState<Difficulty>("all");
  // Topic + role-fit filters. "" = all (the catch-all option). Options are
  // derived from the loaded library (distinct topic/role_fit values) so the
  // dropdowns only ever offer values that can actually match something.
  const [filterTopic, setFilterTopic] = useState("");
  const [filterRole, setFilterRole] = useState("");
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [timeOverrides, setTimeOverrides] = useState<Record<string, string>>({});
  // Questions pulled in from an admin-authored pool. Their full definitions are
  // held here and COPIED into the cadence on save (`inline_questions`), so the
  // interview never depends on a pool that may later be edited or deleted.
  const [poolDefs, setPoolDefs] = useState<Record<string, InlineCodingQuestion>>({});
  const [pools, setPools] = useState<PoolSummary[]>([]);
  const [importing, setImporting] = useState(false);

  // Seed-once-per-open guard: when `open` flips true we snapshot the existing
  // phase's ids/overrides; further yaml changes from outside (e.g. AI revise)
  // shouldn't blow away in-modal edits.
  const seeded = useRef(false);

  // Existing coding phase derived from yaml — read for the seed AND for the
  // "Remove" button visibility.
  const existing = useMemo(() => {
    const parsed = parseCadenceYaml(yaml);
    const phase = parsed?.phases?.find((p) => (p.coding_question_ids?.length ?? 0) > 0);
    if (!phase) return null;
    // time-overrides isn't typed on ParsedPhase; read defensively.
    const raw = (phase as unknown as { coding_question_time_overrides?: Record<string, number> })
      .coding_question_time_overrides;
    return {
      ids: phase.coding_question_ids ?? [],
      overrides: raw ?? {},
    };
  }, [yaml]);
  const hasCodingPhase = existing !== null;

  // Fetch the library + seed selection on open. Reset seed-guard on close.
  useEffect(() => {
    if (!open) {
      seeded.current = false;
      return;
    }
    if (seeded.current) return;
    seeded.current = true;
    setLoading(true);
    listCodingQuestions()
      .then((r) => setLibrary(r.questions ?? []))
      .catch((e) => toast.error((e as ApiError).message || "Failed to load coding library."))
      .finally(() => setLoading(false));
    // Only pools that actually hold coding questions are worth offering.
    listPools()
      .then((r) => setPools((r.pools ?? []).filter(
        (p) => (p.kinds ?? []).includes(CODING_KIND))))
      .catch(() => { /* the built-in library still works */ });
    setPoolDefs({});
    if (existing) {
      setSelectedIds(new Set(existing.ids));
      // YAML stores overrides in seconds; the input shows MINUTES. Convert
      // on seed so a user editing an existing phase sees friendly values.
      setTimeOverrides(
        Object.fromEntries(
          Object.entries(existing.overrides).map(([k, v]) => [k, String(Math.round(v / 60))]),
        ),
      );
    } else {
      setSelectedIds(new Set());
      setTimeOverrides({});
    }
    setFilterDifficulty("all");
    setFilterTopic("");
    setFilterRole("");
    // toast is captured intentionally — it's only used in the .catch branch and
    // a stale ref is fine. Including it would re-trigger every render because
    // useToast returns a fresh object.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, existing]);

  if (!open) return null;

  // Per-difficulty default time in MINUTES (UI unit). Users can edit.
  //   easy   → 2 min
  //   medium → 5 min
  //   hard   → 10 min
  const defaultMinsFor = (difficulty: string): string => {
    if (difficulty === "easy") return "2";
    if (difficulty === "medium") return "5";
    if (difficulty === "hard") return "10";
    return "";  // unknown difficulty → blank, falls back to library default
  };

  // Pull every coding question out of one pool and offer them alongside the
  // built-in library. The server filters by kind and hands back full
  // definitions; we keep them so Save can COPY them into the cadence.
  const importFromPool = async (poolId: string) => {
    if (!poolId) return;
    setImporting(true);
    try {
      const r = await poolForPhase(poolId, token, CODING_KIND);
      const picks: CodingQuestionPick[] = [];
      const defs: Record<string, InlineCodingQuestion> = {};
      for (const q of r.questions ?? []) {
        const c = q.coding ?? {};
        const qid = q.id ?? "";
        if (!qid) continue;
        // title / topics / role_fit are REAL fields on a pooled coding question
        // (the library's own template), so the picker's filters and labels work
        // identically for pooled and built-in questions.
        const title = c.title || (q.text || qid).split("\n")[0].slice(0, 80);
        const topics = c.topics ?? [];
        const roleFit = c.role_fit ?? [];
        picks.push({
          id: qid, title, prompt: q.text ?? "",
          difficulty: q.difficulty ?? "easy",
          topic: topics, role_fit: roleFit,
          hint_count: (c.hints ?? []).length,
        });
        defs[qid] = {
          title, prompt: q.text ?? "",
          starter_code: c.starter_code ?? "",
          function_name: c.function_name ?? "",
          test_cases: (c.test_cases ?? []).map((t) => ({
            name: t.name ?? "", input: t.input ?? "", expected: t.expected ?? "",
          })),
          solution: c.solution ?? "", hints: c.hints ?? [],
          difficulty: q.difficulty ?? "easy",
          topic: topics, role_fit: roleFit,
          estimated_time_s: c.estimated_time_s ?? 0,
          language: c.language ?? "python",
        };
      }
      if (!picks.length) {
        toast.error("That pool has no coding questions.");
        return;
      }
      setPoolDefs((prev) => ({ ...prev, ...defs }));
      // De-dupe by id so importing the same pool twice doesn't double the list.
      setLibrary((prev) => {
        const seen = new Set(prev.map((q) => q.id));
        return [...prev, ...picks.filter((q) => !seen.has(q.id))];
      });
      toast.success(`Added ${picks.length} question${picks.length === 1 ? "" : "s"} from “${r.pool_name}”.`);
    } catch (e) {
      toast.error((e as ApiError).message || "Could not load that pool.");
    } finally { setImporting(false); }
  };

  // Distinct topic/role_fit values across the whole library (not the filtered
  // view) so picking one filter never empties the other's option list.
  const topicOptions = [...new Set(library.flatMap((q) => q.topic ?? []))].sort();
  const roleOptions = [...new Set(library.flatMap((q) => q.role_fit ?? []))].sort();

  // Difficulty + topic + role all combine (AND). A question matches a topic /
  // role filter when its list CONTAINS the selected value.
  const filtered = library.filter((q) => {
    if (filterDifficulty !== "all" && q.difficulty !== filterDifficulty) return false;
    if (filterTopic && !(q.topic ?? []).includes(filterTopic)) return false;
    if (filterRole && !(q.role_fit ?? []).includes(filterRole)) return false;
    return true;
  });

  const toggle = (id: string) =>
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
        // Clear stale time override when un-picked.
        setTimeOverrides((to) => {
          if (!(id in to)) return to;
          const rest: Record<string, string> = {};
          for (const k of Object.keys(to)) if (k !== id) rest[k] = to[k];
          return rest;
        });
      } else {
        next.add(id);
        // Auto-seed the time-override with the difficulty-based default
        // (2 / 5 / 10 min) unless the user already typed something for this
        // qid (or it was seeded from existing yaml).
        const q = library.find((x) => x.id === id);
        if (q) {
          setTimeOverrides((to) => (
            id in to ? to : { ...to, [id]: defaultMinsFor(q.difficulty) }
          ));
        }
      }
      return next;
    });

  const onSave = async () => {
    if (selectedIds.size === 0) {
      toast.error("Pick at least one question, or use Remove coding phase.");
      return;
    }
    setBusy("save");
    try {
      const overrides: Record<string, number> = {};
      for (const [qid, raw] of Object.entries(timeOverrides)) {
        if (!selectedIds.has(qid)) continue;
        const mins = Number(raw);
        if (raw.trim() === "" || !Number.isFinite(mins)) continue;
        // Input is in MINUTES; YAML schema expects seconds. Convert + clamp
        // to [1 min, 60 min] (matches the schema's min-30s rule with margin).
        const clampedMins = Math.max(1, Math.min(60, Math.round(mins)));
        overrides[qid] = clampedMins * 60;
      }
      // Only the selected ids that came from a pool — a definition for an
      // unselected question would be rejected by the server anyway.
      const inline: Record<string, InlineCodingQuestion> = {};
      for (const id of selectedIds) {
        if (poolDefs[id]) inline[id] = poolDefs[id];
      }
      const r = await setCodingPhase(token, yaml, [...selectedIds], overrides, inline);
      if (r.ok && r.yaml) {
        onYamlChange(r.yaml);
        toast.success("Coding phase saved.");
        onClose();
      } else {
        toast.error(r.error || "Save failed.");
      }
    } catch (e) {
      toast.error((e as ApiError).message || "Save failed.");
    } finally {
      setBusy(null);
    }
  };

  const onRemove = async () => {
    if (!hasCodingPhase) return;
    const ok = window.confirm(
      "Remove the coding phase from this cadence? This can be undone via the YAML editor.",
    );
    if (!ok) return;
    setBusy("remove");
    try {
      const r = await removeCodingPhase(token, yaml);
      if (r.ok && r.yaml) {
        onYamlChange(r.yaml);
        toast.success("Coding phase removed.");
        onClose();
      } else {
        toast.error(r.error || "Remove failed.");
      }
    } catch (e) {
      toast.error((e as ApiError).message || "Remove failed.");
    } finally {
      setBusy(null);
    }
  };

  // Portal to <body> so position:fixed resolves against the viewport instead
  // of the .screen-enter ancestor — its mount animation sets `transform`,
  // which creates a containing block and pins fixed elements to it (was
  // putting the modal far below the scroll position the user clicked from).
  return createPortal(
    <div
      role="dialog"
      className="ds-light"
      aria-modal="true"
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(22,22,22,0.35)",
        zIndex: 5000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
      }}
    >
      <div
        className="card"
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%",
          maxWidth: 720,
          maxHeight: "90vh",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          padding: 0,
          // Why: --panel is rgba(...0.035) — fine when stacked on the page,
          // but on a 55%-dim overlay the modal body bleeds through. Force a
          // solid ink-ish background so the picker reads cleanly.
          background: "var(--ink-2)",
          border: "1px solid var(--line-2)",
        }}
      >
        {/* Header */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "14px 16px",
            borderBottom: "1px solid var(--line)",
          }}
        >
          <h2 style={{ fontSize: 16, fontWeight: 700, margin: 0 }}>Coding phase</h2>
          <button
            type="button"
            onClick={onClose}
            className="btn btn-ghost btn-sm"
            aria-label="Close"
            style={{ padding: "4px 10px" }}
          >
            ✕
          </button>
        </div>

        {/* Filter chips */}
        <div
          style={{
            display: "flex",
            flexWrap: "wrap",
            gap: 6,
            padding: "10px 16px",
            borderBottom: "1px solid var(--line)",
          }}
        >
          {/* Pull questions out of an authored pool and offer them beside the
              built-in ones. Only pools that actually hold coding questions are
              listed, so this never offers an import that yields nothing. */}
          {pools.length > 0 && (
            <div style={{ display: "flex", alignItems: "center", gap: 6,
                          width: "100%", marginBottom: 4 }}>
              <span className="muted-3" style={{ fontSize: 12 }}>
                Add from a question pool:
              </span>
              <select
                className="input"
                style={{ fontSize: 12.5, padding: "4px 8px", maxWidth: 260 }}
                value=""
                disabled={importing}
                onChange={(e) => { void importFromPool(e.target.value); e.target.value = ""; }}
              >
                <option value="">{importing ? "Loading…" : "Choose a pool…"}</option>
                {pools.map((p) => (
                  <option key={p.pool_id} value={p.pool_id}>{p.pool_name}</option>
                ))}
              </select>
              {Object.keys(poolDefs).length > 0 && (
                <span className="muted-3" style={{ fontSize: 11.5 }}>
                  {Object.keys(poolDefs).length} pool question
                  {Object.keys(poolDefs).length === 1 ? "" : "s"} available below
                </span>
              )}
            </div>
          )}
          {(["all", "easy", "medium", "hard"] as const).map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => setFilterDifficulty(d)}
              className={`chip ${filterDifficulty === d ? "on" : ""}`}
            >
              {d === "all" ? "All" : d.charAt(0).toUpperCase() + d.slice(1)}
            </button>
          ))}

          {/* Topic + role-fit dropdowns — combine (AND) with the difficulty
              chips above. Options come from the loaded library. */}
          <select
            value={filterTopic}
            onChange={(e) => setFilterTopic(e.target.value)}
            className="input"
            aria-label="Filter by topic"
            style={{ padding: "4px 8px", fontSize: 12 }}
          >
            <option value="">All topics</option>
            {topicOptions.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
          <select
            value={filterRole}
            onChange={(e) => setFilterRole(e.target.value)}
            className="input"
            aria-label="Filter by role fit"
            style={{ padding: "4px 8px", fontSize: 12 }}
          >
            <option value="">All roles</option>
            {roleOptions.map((r) => (
              <option key={r} value={r}>{r}</option>
            ))}
          </select>

          <span className="muted-3" style={{ marginLeft: "auto", fontSize: 12, alignSelf: "center" }}>
            {selectedIds.size} selected
          </span>
        </div>

        {/* Body — question list */}
        <div style={{ overflowY: "auto", padding: "8px 16px", flex: 1 }}>
          {loading ? (
            <p className="muted-3" style={{ fontSize: 13 }}>Loading questions…</p>
          ) : filtered.length === 0 ? (
            <p className="muted-3" style={{ fontSize: 13 }}>No questions match this filter.</p>
          ) : (
            <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", flexDirection: "column", gap: 8 }}>
              {filtered.map((q) => {
                const checked = selectedIds.has(q.id);
                return (
                  <li
                    key={q.id}
                    style={{
                      border: "1px solid var(--line)",
                      borderColor: checked ? "rgba(255,66,187,0.4)" : "var(--line)",
                      borderRadius: 10,
                      padding: 10,
                      background: checked ? "var(--ds-lavender)" : "transparent",
                    }}
                  >
                    <label style={{ display: "flex", gap: 10, alignItems: "flex-start", cursor: "pointer" }}>
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggle(q.id)}
                        style={{ marginTop: 3 }}
                      />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 6 }}>
                          <span style={{ fontWeight: 600 }}>{q.title}</span>
                          <span className="pill" style={{ padding: "1px 7px" }}>{q.difficulty}</span>
                          {poolDefs[q.id] && (
                            <span className="pill" style={{ padding: "1px 7px", fontSize: 10.5 }}
                                  title="Authored in a question pool — its definition is copied into this interview on save">
                              from pool
                            </span>
                          )}
                          {q.topic.slice(0, 3).map((t) => (
                            <span key={t} className="pill" style={{ padding: "1px 7px", color: "var(--magenta-soft)", borderColor: "rgba(255,66,187,0.3)" }}>
                              {t}
                            </span>
                          ))}
                        </div>
                        <p className="muted-3" style={{ fontSize: 12, marginTop: 4 }}>
                          {q.prompt.length > 140 ? `${q.prompt.slice(0, 140)}…` : q.prompt}
                        </p>
                      </div>
                    </label>
                    {checked && (
                      <div style={{ marginTop: 8, marginLeft: 26, fontSize: 12, color: "var(--text-2)" }}>
                        <label style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                          Time:
                          <input
                            type="number"
                            min={1}
                            max={60}
                            step={1}
                            value={timeOverrides[q.id] ?? ""}
                            onChange={(e) =>
                              setTimeOverrides((to) => ({ ...to, [q.id]: e.target.value }))
                            }
                            placeholder="default"
                            className="input"
                            style={{ width: 70, padding: "4px 8px" }}
                          />
                          min
                          <span className="muted-3" style={{ fontSize: 11 }}>
                            (1–60)
                          </span>
                        </label>
                      </div>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        {/* Footer */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            padding: "12px 16px",
            borderTop: "1px solid var(--line)",
          }}
        >
          {hasCodingPhase && (
            <button
              type="button"
              onClick={onRemove}
              disabled={busy !== null}
              className="btn btn-ghost btn-sm"
              style={{ color: "var(--danger)", borderColor: "rgba(255,84,112,0.4)" }}
            >
              {busy === "remove" ? "Removing…" : "Remove coding phase"}
            </button>
          )}
          <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
            <button type="button" onClick={onClose} className="btn btn-ghost btn-sm" disabled={busy !== null}>
              Cancel
            </button>
            <button
              type="button"
              onClick={onSave}
              disabled={busy !== null || selectedIds.size === 0}
              className="btn btn-sm"
              style={{
                background: "var(--ds-lavender)",
                color: "var(--ds-accent-ink)",
                borderColor: "transparent",
                fontWeight: 600,
              }}
            >
              {busy === "save" ? "Saving…" : "Save"}
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
}
