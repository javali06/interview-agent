// Teams/Zoom-style tiles for the candidate's live view: the AI interviewer
// (AVA) and the candidate — an interview is the two of them, nobody else joins.
// Each is a fixed head-and-shoulders box. With the camera on, the candidate's
// box shows their live self-view; with it off, an orb that BRIGHTENS while they
// speak. Boxes wrap to the available space (top-left), never stretch, so
// turning video on/off never compresses the transcript beside them.
import { useEffect, useRef, useState } from "react";
import type { ReactNode, CSSProperties } from "react";
import { registerOrb } from "../lib/orbGlow";
import type { GlowSource } from "../lib/orbGlow";

type ConnState = "ok" | "warn" | "error" | "connecting";

const DOT: Record<string, string> = {
  ok: "var(--ok)", warn: "var(--warn)", error: "var(--danger)", connecting: "var(--text-3)",
};

const BOX_W = 248;
const FILL: CSSProperties = { position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" };

// Request native browser fullscreen on a tile element. Prefixed fallback for
// Safari; swallow rejection (e.g. not user-activated) so a denied request is a
// no-op rather than an unhandled promise.
type FsElement = HTMLElement & { webkitRequestFullscreen?: () => void };
function requestFullscreen(el: HTMLElement | null) {
  if (!el) return;
  const e = el as FsElement;
  if (e.requestFullscreen) void e.requestFullscreen().catch(() => {});
  else if (e.webkitRequestFullscreen) e.webkitRequestFullscreen();
}

// Small ⛶ overlay button shared by every tile. stopPropagation so it doesn't
// also toggle spotlight (the tile body owns that click).
function FsButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      title="Fullscreen this tile"
      style={{
        position: "absolute", right: 7, top: 7, zIndex: 2, cursor: "pointer",
        width: 26, height: 26, borderRadius: 7, border: "none", lineHeight: 1,
        background: "rgba(0,0,0,0.55)", color: "#fff", fontSize: 14,
      }}
    >⛶</button>
  );
}

// The candidate's tile. `self.stream` is their local camera; when it has no
// pixels, an active-aware orb shows instead.
export type ParticipantTile = {
  name: string;
  active: boolean;                                    // active speaker → tile border ring (STT-driven)
  self?: { stream: MediaStream | null } | null;       // local camera (self-view)
  glowSource?: GlowSource | null;                     // orb's continuous amplitude source
  muted?: boolean;                                    // distinct "muted" look — orb ignores glowSource entirely while true
};

// `size` controls the spotlight layout: "spot" = the big spotlighted tile,
// "strip" = a shrunken thumbnail in the side strip, undefined = default wrap.
function Box({
  name, active, conn, children, size, onToggleSpotlight,
}: {
  name: string; active: boolean; conn: ConnState; children: ReactNode;
  size?: "spot" | "strip"; onToggleSpotlight?: () => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const dims: CSSProperties =
    size === "spot" ? { width: "100%", height: "100%", aspectRatio: "auto" }
    : size === "strip" ? { width: 150, aspectRatio: "4 / 3" }
    : { width: BOX_W, aspectRatio: "4 / 3" };
  return (
    <div
      ref={ref}
      onClick={onToggleSpotlight}
      title={onToggleSpotlight ? (size === "spot" ? "Click to un-spotlight" : "Click to spotlight") : undefined}
      style={{
        position: "relative", flex: "0 0 auto", cursor: onToggleSpotlight ? "pointer" : "default",
        borderRadius: 12, overflow: "hidden", background: "#160d1c",
        border: active ? "2px solid var(--magenta-bright)" : "1px solid var(--line)",
        boxShadow: active ? "0 0 0 3px rgba(255,66,187,0.32)" : "none",
        transition: "box-shadow 150ms, border-color 150ms",
        ...dims,
      }}
    >
      {children}
      <FsButton onClick={() => requestFullscreen(ref.current)} />
      <div style={{
        position: "absolute", left: 7, bottom: 7, display: "flex", alignItems: "center", gap: 6,
        padding: "2px 8px", borderRadius: 999, background: "rgba(0,0,0,0.58)", fontSize: 11.5, color: "#fff",
      }}>
        <span style={{ height: 7, width: 7, borderRadius: "50%", flex: "none", background: DOT[conn] ?? "var(--text-3)" }} />
        {name}
      </div>
    </div>
  );
}

// Camera-off placeholder: an orb that glows continuously with the tracked
// source's amplitude (registerOrb/orbGlow.ts writes --glow-level directly on
// the DOM node — no React re-render per level tick). glowSource omitted/null
// means it never registers, so --glow-level stays unset and every
// calc(var(--glow-level, 0)) falls back to 0 — the orb still renders its
// lit-core-and-halo resting look, just never animates beyond the ambient
// breathing. Registered on the OUTER .tile-orb element (same component as the
// AI orb in Candidate.tsx's Stage, just a smaller --size) so --glow-level
// cascades to every halo layer via normal CSS custom-property inheritance.
function Orb({ glowSource, muted }: { glowSource?: GlowSource | null; muted?: boolean }) {
  const glowRef = useRef<HTMLDivElement>(null);
  useEffect(() => registerOrb(glowRef.current, glowSource ?? null), [glowSource]);
  return (
    <div className="tile-orb-wrap">
      <div ref={glowRef} className={`tile-orb${muted ? " muted" : ""}`}>
        <div className="orb-aura" />
        <div className="orb-breathe-3"><div className="orb-halo-3" /></div>
        <div className="orb-breathe-2"><div className="orb-halo-2" /></div>
        <div className="orb-breathe-1"><div className="orb-halo-1" /></div>
        <div className="orb-core" />
        {muted && (
          <span className="tile-orb-mute-badge" title="Muted">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0" />
              <path d="M19 11a7 7 0 0 1-7 7 7 7 0 0 1-7-7" />
              <line x1="3" y1="3" x2="21" y2="21" />
            </svg>
          </span>
        )}
      </div>
    </div>
  );
}

// The candidate's mirrored camera self-view.
function SelfVideo({ stream }: { stream: MediaStream }) {
  const vref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const v = vref.current;
    if (v) { v.srcObject = stream; void v.play?.().catch(() => {}); }
  }, [stream]);
  return (
    <video ref={vref} muted playsInline autoPlay
      style={{ ...FILL, transform: "scaleX(-1)" }} />
  );
}

function ParticipantBox({
  tile, conn, size, onToggleSpotlight,
}: {
  tile: ParticipantTile; conn: ConnState;
  size?: "spot" | "strip"; onToggleSpotlight?: () => void;
}) {
  const inner = tile.self?.stream
    ? <SelfVideo stream={tile.self.stream} />
    : <Orb glowSource={tile.glowSource} muted={tile.muted} />;
  return (
    <Box name={tile.self ? `${tile.name} (you)` : tile.name} active={tile.active} conn={conn} size={size} onToggleSpotlight={onToggleSpotlight}>
      {inner}
    </Box>
  );
}

// A small visible "Sharing your screen" confirmation, so the candidate can see
// their mandatory entire-screen share is live. The screen itself is recorded by
// the engine's MediaRecorder; this is display only.
export function ScreenSharePreview({ stream, label = "Sharing your screen" }: { stream: MediaStream | null; label?: string }) {
  const vref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const v = vref.current;
    if (v && stream) { v.srcObject = stream; void v.play?.().catch(() => {}); }
  }, [stream]);
  if (!stream) return null;
  return (
    <div style={{
      position: "relative", marginTop: 10, width: 200, aspectRatio: "16 / 9",
      borderRadius: 10, overflow: "hidden", background: "#0c0c11",
      border: "1px solid var(--magenta)", flex: "0 0 auto",
    }}>
      <video ref={vref} muted playsInline autoPlay
        style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "contain" }} />
      <div style={{
        position: "absolute", left: 6, bottom: 6, display: "flex", alignItems: "center", gap: 5,
        padding: "2px 8px", borderRadius: 999, background: "rgba(0,0,0,0.62)", fontSize: 11, color: "#fff",
      }}>
        <span style={{ height: 6, width: 6, borderRadius: "50%", flex: "none", background: "var(--ok)" }} />
        {label}
      </div>
    </div>
  );
}

// Standalone self-preview for the lobby (before the call starts).
export function CamPreview({ stream, size = 120 }: { stream: MediaStream | null; size?: number }) {
  const vref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const v = vref.current;
    if (v) { v.srcObject = stream; void v.play?.().catch(() => {}); }
  }, [stream]);
  if (!stream) return null;
  return (
    <video ref={vref} muted playsInline autoPlay
      style={{ width: size, height: size, objectFit: "cover", borderRadius: 12, border: "1px solid var(--line)", transform: "scaleX(-1)" }} />
  );
}

export function VideoTiles({
  avatar, avatarActive, conn, tiles,
}: {
  avatar: ReactNode;
  avatarActive: boolean;
  conn: ConnState;
  tiles: ParticipantTile[];   // the candidate (the avatar is rendered separately)
}) {
  // Pin/spotlight. Local-only: a tile id ("avatar" | participant name); null =
  // the default wrap layout. Clicking a tile toggles it.
  const [spot, setSpot] = useState<string | null>(null);
  const toggle = (id: string) => setSpot((cur) => (cur === id ? null : id));
  const active = spot === "avatar" || tiles.some((t) => t.name === spot) ? spot : null;

  // ── Spotlight layout: one big tile + a small thumbnail strip of the rest ──
  if (active) {
    const avatarBox = (
      <Box name="AVA" active={avatarActive} conn={conn}
        size={active === "avatar" ? "spot" : "strip"} onToggleSpotlight={() => toggle("avatar")}>
        <div style={{ position: "absolute", inset: 0 }}>{avatar}</div>
      </Box>
    );
    const isBig = (id: string) => id === active;
    return (
      <div style={{ display: "flex", gap: 12, width: "100%", height: "100%", minHeight: 0 }}>
        {/* Big spotlighted tile */}
        <div style={{ flex: "1 1 auto", minWidth: 0, minHeight: 0 }}>
          {active === "avatar" && avatarBox}
          {tiles.filter((t) => isBig(t.name)).map((t) => (
            <ParticipantBox key={t.name} tile={t} conn={conn} size="spot" onToggleSpotlight={() => toggle(t.name)} />
          ))}
        </div>
        {/* Thumbnail strip — everything not spotlighted */}
        <div style={{ display: "flex", flexDirection: "column", gap: 10, flex: "0 0 auto", overflowY: "auto", padding: 2 }}>
          {active !== "avatar" && avatarBox}
          {tiles.filter((t) => !isBig(t.name)).map((t) => (
            <ParticipantBox key={t.name} tile={t} conn={conn} size="strip" onToggleSpotlight={() => toggle(t.name)} />
          ))}
        </div>
      </div>
    );
  }

  // ── Default layout: wrapping rail, top-left, never stretches ──
  return (
    <div style={{
      display: "flex", flexWrap: "wrap", gap: 12, alignContent: "flex-start",
      width: "100%", height: "100%", minHeight: 0, overflowY: "auto", padding: 2,
    }}>
      <Box name="AVA" active={avatarActive} conn={conn} onToggleSpotlight={() => toggle("avatar")}>
        <div style={{ position: "absolute", inset: 0 }}>{avatar}</div>
      </Box>
      {tiles.map((t) => <ParticipantBox key={t.name} tile={t} conn={conn} onToggleSpotlight={() => toggle(t.name)} />)}
    </div>
  );
}
