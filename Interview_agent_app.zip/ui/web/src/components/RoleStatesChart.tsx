// Where the roles are in the pipeline, at a glance.
//

import StatesDonut from "./StatesDonut";

export type RoleState = "sourcing" | "interviewing" | "closed";

export const ROLE_STATE_META: Record<RoleState, { label: string; color: string; hint: string }> = {
  sourcing:     { label: "Sourcing",     color: "#3987e5", hint: "matching resumes and setting the interview plan" },
  interviewing: { label: "Interviewing", color: "#d95926", hint: "interviews created for this role" },
  closed:       { label: "Closed",       color: "#199e70", hint: "closed by an admin" },
};

const ORDER: RoleState[] = ["sourcing", "interviewing", "closed"];

export default function RoleStatesChart({ counts }: { counts: Record<RoleState, number> }) {
  return (
    <StatesDonut
      title="Roles by stage"
      unit="roles"
      size={140}
      segments={ORDER.map((k) => ({
        key: k,
        label: ROLE_STATE_META[k].label,
        color: ROLE_STATE_META[k].color,
        value: counts[k] || 0,
        hint: ROLE_STATE_META[k].hint,
      }))}
    />
  );
}
