// Stroke icon set ported from the design reference (single SVG sprite-style
// component). Inherits color via currentColor; size via the .ico class or style.
import type { CSSProperties } from "react";

const P = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.7,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

const PATHS: Record<string, React.ReactNode> = {
  grid: (<><rect x="3" y="3" width="7" height="7" rx="1.5" {...P} /><rect x="14" y="3" width="7" height="7" rx="1.5" {...P} /><rect x="3" y="14" width="7" height="7" rx="1.5" {...P} /><rect x="14" y="14" width="7" height="7" rx="1.5" {...P} /></>),
  calendar: (<><rect x="3" y="4.5" width="18" height="16" rx="2.5" {...P} /><path d="M3 9h18M8 2.5v4M16 2.5v4" {...P} /></>),
  mic: (<><rect x="9" y="2.5" width="6" height="11" rx="3" {...P} /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" {...P} /></>),
  sparkle: (<><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z" {...P} /></>),
  notes: (<><rect x="4" y="3" width="16" height="18" rx="2.5" {...P} /><path d="M8 8h8M8 12h8M8 16h5" {...P} /></>),
  users: (<><circle cx="9" cy="8" r="3.4" {...P} /><path d="M3.5 19a6 6 0 0 1 11 0M16 5.2a3.2 3.2 0 0 1 0 6.1M15.5 19a6 6 0 0 1 4.8-3" {...P} /></>),
  user: (<><circle cx="12" cy="8" r="4" {...P} /><path d="M4.5 20a7.5 7.5 0 0 1 15 0" {...P} /></>),
  settings: (<><circle cx="12" cy="12" r="3" {...P} /><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2" {...P} /></>),
  link: (<><path d="M9 15l6-6M10.5 6.5l1.8-1.8a4 4 0 0 1 5.6 5.6L15.5 12M13.5 17.5l-1.8 1.8a4 4 0 0 1-5.6-5.6L8.5 12" {...P} /></>),
  arrow: (<><path d="M5 12h14M13 6l6 6-6 6" {...P} /></>),
  arrowL: (<><path d="M19 12H5M11 6l-6 6 6 6" {...P} /></>),
  plus: (<><path d="M12 5v14M5 12h14" {...P} /></>),
  check: (<><path d="M5 12.5 10 17l9-10" {...P} /></>),
  clock: (<><circle cx="12" cy="12" r="9" {...P} /><path d="M12 7.5V12l3 2" {...P} /></>),
  edit: (<><path d="M4 20h4L19 9l-4-4L4 16v4Z" {...P} /><path d="M14 6l4 4" {...P} /></>),
  send: (<><path d="M4 12l16-7-7 16-2.5-6.5L4 12Z" {...P} /></>),
  refresh: (<><path d="M20 11a8 8 0 1 0-.8 4.2M20 5v6h-6" {...P} /></>),
  star: (<><path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 17.9 6.8 19.6l1-5.8-4.3-4.1 5.9-.9L12 3.5Z" {...P} /></>),
  bolt: (<><path d="M13 2 4 14h7l-1 8 9-12h-7l1-8Z" {...P} /></>),
  upload: (<><path d="M12 16V4M7 9l5-5 5 5M5 20h14" {...P} /></>),
  file: (<><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5Z" {...P} /><path d="M14 3v5h5" {...P} /></>),
  trash: (<><path d="M4 7h16M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M6 7l1 13a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-13" {...P} /></>),
  logout: (<><path d="M15 12H4M8 8l-4 4 4 4M14 4h5a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-5" {...P} /></>),
  download: (<><path d="M12 4v12M7 11l5 5 5-5M5 20h14" {...P} /></>),
  briefcase: (<><rect x="3" y="7" width="18" height="13" rx="2.5" {...P} /><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 12h18" {...P} /></>),
};

export function Icon({ name, className = "ico", style }: { name: string; className?: string; style?: CSSProperties }) {
  return (
    <svg viewBox="0 0 24 24" className={className} style={style} aria-hidden="true">
      {PATHS[name] ?? PATHS.dot}
    </svg>
  );
}
