import { useEffect, useState } from "react";
import { Link, NavLink, Navigate, Outlet, Route, Routes, useParams } from "react-router-dom";
import { Home } from "./pages/Home";
import { Shortlist } from "./pages/Shortlist";
import { RoleDetail } from "./pages/RoleDetail";
import { InterviewSetup } from "./pages/InterviewSetup";
import { Dashboard } from "./pages/Dashboard";
import { Session } from "./pages/Session";
import { CadenceReview } from "./pages/CadenceReview";
import { QuestionPools } from "./pages/QuestionPools";
import { QuestionPoolEditor } from "./pages/QuestionPoolEditor";
import { PoolApprovals } from "./pages/PoolApprovals";
import { PoolReview } from "./pages/PoolReview";
import { Schedule } from "./pages/Schedule";
import { Candidate } from "./pages/Candidate";
import { CandidateText } from "./pages/CandidateText";
import { Login } from "./pages/Login";
import { Access } from "./pages/Access";
import { Icon } from "./components/Icon";
import { Logo } from "./components/Logo";
import { AccountGate } from "./components/AccountGate";
import { Guard } from "./components/Guard";
import { roleLine, useLogout, usePermissions } from "./lib/auth";
import { visibleWorkspace } from "./lib/workspace";

function Sidebar() {
  const { data: me } = usePermissions();
  const logout = useLogout();
  const name = me?.display_name || me?.email || me?.user || "Signed in";
  const initials = name.slice(0, 2).toUpperCase();
  const lines = me?.legacy
    ? ["Signed in"]
    : (me?.roles ?? []).map(roleLine);
  return (
    <aside className="sidebar ds-light">
      <NavLink to="/" className="brand">
        <Logo sub="Recruitment Platform" />
      </NavLink>

      <div className="nav-label">Workspace</div>
      {visibleWorkspace(me).map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
        >
          <Icon name={item.icon} className="ico" />
          <span>{item.label}</span>
        </NavLink>
      ))}

      <div className="side-spacer" />
      <button
        type="button"
        className="nav-item"
        style={{ width: "100%" }}
        onClick={() => logout.mutate()}
      >
        <Icon name="logout" className="ico" />
        <span>Sign out</span>
      </button>
      <div className="side-user" style={{ marginTop: 6 }}>
        <span className="avatar">{initials}</span>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 13.5, fontWeight: 600 }}>{me?.legacy ? (me.user || "Admin") : name}</div>
          {lines.map((line) => (
            <div key={line} style={{ fontSize: 11.5, color: "var(--text-3)" }}>{line}</div>
          ))}
        </div>
      </div>
    </aside>
  );
}

// Auth-gated console shell: ambient bg + sidebar + the matched screen via
// <Outlet/>. The candidate screen is a public sibling (no shell).
function GatedLayout() {
  const me = usePermissions();
  if (me.isLoading) {
    return (
      <div className="ds-light" style={{ position: "fixed", inset: 0, display: "grid", placeItems: "center", background: "var(--ds-bg)", color: "var(--ds-text-3)" }}>
        Loading…
      </div>
    );
  }
  if (!me.data?.authenticated) {
    return (
      <>
        <div className="app-bg" />
        <div style={{ position: "relative", zIndex: 1 }}>
          <Login />
        </div>
      </>
    );
  }
  // A real person with no grant, or one who was switched off, never sees the menu.
  // The shared password is not a person, so it keeps the console it already had.
  if (!me.data.legacy && me.data.is_active === false) {
    return (
      <>
        <div className="app-bg" />
        <AccountGate person={me.data} turnedOff />
      </>
    );
  }
  if (!me.data.legacy && (me.data.roles ?? []).length === 0) {
    return (
      <>
        <div className="app-bg" />
        <AccountGate person={me.data} />
      </>
    );
  }
  return (
    <>
      <div className="app-bg" />
      <div className="shell ds-shell">
        <Sidebar />
        <main className="main">
          <Outlet />
        </main>
      </div>
    </>
  );
}

function PoolPage() {
  const { poolId } = useParams();
  const anyOf = poolId === "new" ? ["pools.edit"] : ["pools.view"];
  return (
    <Guard anyOf={anyOf}>
      <QuestionPoolEditor />
    </Guard>
  );
}

// Public candidate entry: the SAME link (/candidate?token=T) serves BOTH voice
// and text interviews. Fetch /session-info and dispatch by modality WITHOUT
// touching Candidate.tsx. The voice path is behavior-unchanged: default and
// while loading we render <Candidate/> exactly as before (it mounts once and
// stays for a voice interview); only a resolved modality of "text" swaps in
// <CandidateText/>.
function CandidateEntry() {
  const [modality, setModality] = useState<"voice" | "text">("voice");
  useEffect(() => {
    let alive = true;
    const token = new URLSearchParams(window.location.search).get("token");
    const qs = token ? `?token=${encodeURIComponent(token)}` : "";
    fetch(`/session-info${qs}`, { cache: "no-store", credentials: "same-origin" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d: { modality?: string } | null) => {
        if (alive && d?.modality === "text") setModality("text");
      })
      .catch(() => {
        /* default stays voice — the voice path must never regress on a fetch error */
      });
    return () => { alive = false; };
  }, []);
  return modality === "text" ? <CandidateText /> : <Candidate />;
}

function NotFound() {
  return (
    <div className="ds-light screen-enter">
      <div className="ds-empty" style={{ maxWidth: 520, margin: "48px auto" }}>
        <h1 className="page-title">Page not found</h1>
        <p className="muted" style={{ marginTop: 8 }}>That link does not match any page.</p>
        <Link to="/dashboard" className="btn btn-primary" style={{ marginTop: 18 }}>
          Go to the dashboard
        </Link>
      </div>
    </div>
  );
}

export function App() {
  return (
    <Routes>
      {/* Public, full-screen candidate interview client — no shell, no gate.
          Dispatches to voice or text by the session's modality. */}
      <Route path="/candidate" element={<CandidateEntry />} />

      <Route element={<GatedLayout />}>
        <Route path="/" element={<Home />} />
        <Route path="/shortlist" element={<Guard anyOf={["interviews.view"]}><Shortlist /></Guard>} />
        <Route path="/shortlist/:roleId" element={<Guard anyOf={["interviews.view"]}><RoleDetail /></Guard>} />
        <Route path="/shortlist/:roleId/interview" element={<Guard anyOf={["interviews.schedule"]}><InterviewSetup /></Guard>} />
        <Route path="/dashboard" element={<Guard anyOf={["interviews.view"]}><Dashboard /></Guard>} />
        <Route path="/sessions/:token" element={<Guard anyOf={["interviews.view"]}><Session /></Guard>} />
        {/* The live observer is retired; old observer links land on the interview. */}
        <Route path="/sessions/:token/live" element={<Navigate to=".." relative="path" replace />} />
        <Route path="/schedule" element={<Guard anyOf={["interviews.schedule"]}><Schedule /></Guard>} />
        <Route path="/schedule/:token/cadence" element={<Guard anyOf={["interviews.schedule"]}><CadenceReview /></Guard>} />
        <Route path="/question-pools" element={<Guard anyOf={["pools.view"]}><QuestionPools /></Guard>} />
        {/* Before :poolId, or the param route swallows "approvals". */}
        <Route path="/question-pools/approvals" element={<Guard anyOf={["pools.approve"]}><PoolApprovals /></Guard>} />
        <Route path="/question-pools/:poolId/review" element={<Guard anyOf={["pools.approve"]}><PoolReview /></Guard>} />
        <Route path="/question-pools/:poolId" element={<PoolPage />} />
        <Route path="/access" element={<Guard anyOf={["admin.users", "admin.teams", "admin.permissions"]}><Access /></Guard>} />
        {/* A path that matches nothing rendered a blank screen, which reads
            as a crash. Say so instead, and offer the way back. */}
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
