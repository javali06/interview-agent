import { Link } from "react-router-dom";
import { Icon } from "../components/Icon";
import { PageHeader } from "../components/PageHeader";
import { usePermissions } from "../lib/auth";
import { visibleWorkspace } from "../lib/workspace";

export function Home() {
  const { data: me } = usePermissions();
  const tiles = visibleWorkspace(me).filter((item) => item.home);

  return (
    <div className="ds-light screen-enter">
      <PageHeader category="Workspace" title="Welcome" sub="Pick a workspace to get started." />

      {tiles.length === 0 ? (
        <div className="card" style={{ padding: 28 }}>
          <p className="muted">No workspace is assigned to this role.</p>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 18 }}>
          {tiles.map((tile) => (
            <Link key={tile.to} to={tile.to} className="card ds-tile" style={{ padding: 24, display: "block", textDecoration: "none", color: "var(--text)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                <span
                  style={{
                    width: 44, height: 44, borderRadius: 12, display: "grid", placeItems: "center",
                    background: "var(--ds-lavender)", color: "var(--ds-accent)",
                  }}
                >
                  <Icon name={tile.home!.icon} className="ico" style={{ width: 22, height: 22 }} />
                </span>
                <span className="mono" style={{ fontSize: 11, letterSpacing: "0.14em", color: "var(--text-3)" }}>{tile.home!.num}</span>
              </div>
              <h2 style={{ marginTop: 16, fontSize: 19, fontWeight: 600 }}>{tile.home!.title}</h2>
              <p className="muted" style={{ marginTop: 6, fontSize: 14 }}>{tile.home!.desc}</p>
              <div style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 7, color: "var(--magenta-soft)", fontSize: 13.5, fontWeight: 600 }}>
                Open <Icon name="arrow" className="ico" style={{ width: 16, height: 16 }} />
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
