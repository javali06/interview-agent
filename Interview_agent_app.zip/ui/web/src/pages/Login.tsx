import { useState } from "react";
import { useAuthMethods, useLogin } from "../lib/auth";
import { ApiError } from "../lib/api";
import { Logo } from "../components/Logo";

export function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const login = useLogin();
  const methods = useAuthMethods();
  // A failed Microsoft sign-in redirects back here with a readable reason
  // rather than surfacing as a 500 — a stale tab or the wrong account is
  // something the person can act on.
  const authError = new URLSearchParams(window.location.search).get("auth_error");

  return (
    <div
      className="ds-light"
      style={{
        minHeight: "100vh", display: "grid", placeItems: "center", padding: 24,
        background: "radial-gradient(640px 440px at 0% 0%, var(--ds-glow-1), transparent 70%), radial-gradient(700px 500px at 100% 100%, var(--ds-glow-2), transparent 70%), var(--ds-bg)",
      }}
    >
      <div className="card screen-enter" style={{ width: "100%", maxWidth: 400, padding: "34px 32px", boxShadow: "var(--ds-shadow)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 11, marginBottom: 24 }}>
          <Logo sub="Interview Agent" />
        </div>

        <h1 className="page-title" style={{ fontSize: 24 }}>Sign in</h1>
        <p className="page-sub" style={{ fontSize: 14, marginTop: 4 }}>
          Access the interview console.
        </p>

        {authError && (
          <p style={{
            fontSize: 13, color: "var(--danger)", marginTop: 14,
            padding: "9px 12px", borderRadius: 8,
            border: "1px solid var(--danger)",
          }}>
            {authError}
          </p>
        )}

        {methods.data?.microsoft && (
          <>
            {/* A plain link, NOT a fetch: signing in means the browser physically
                travels to Microsoft and comes back, which an XHR cannot do. */}
            <a
              href="/auth/login"
              className="btn btn-primary"
              style={{
                marginTop: 20, width: "100%", textDecoration: "none",
                display: "flex", alignItems: "center", justifyContent: "center", gap: 10,
              }}
            >
              <MicrosoftMark />
              Sign in with Microsoft
            </a>
            <p className="muted-3" style={{ fontSize: 12, marginTop: 9, lineHeight: 1.5 }}>
              Use your Centific work account.
            </p>
            <div style={{
              display: "flex", alignItems: "center", gap: 10,
              margin: "22px 0 4px", color: "var(--muted-3)", fontSize: 11.5,
            }}>
              <span style={{ flex: 1, height: 1, background: "var(--line)" }} />
              or
              <span style={{ flex: 1, height: 1, background: "var(--line)" }} />
            </div>
          </>
        )}

        <form
          style={{ marginTop: 22, display: "flex", flexDirection: "column", gap: 13 }}
          onSubmit={(e) => {
            e.preventDefault();
            login.mutate({ username, password });
          }}
        >
          <div>
            <label className="field-label" htmlFor="login-username">Username</label>
            <input
              id="login-username"
              className="input"
              placeholder="Username"
              autoComplete="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
          <div>
            <label className="field-label" htmlFor="login-password">Password</label>
            <input
              id="login-password"
              className="input"
              type="password"
              placeholder="Password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button
            className="btn btn-primary"
            style={{ marginTop: 6, width: "100%" }}
            disabled={!username || !password || login.isPending}
            type="submit"
          >
            {login.isPending ? "Signing in…" : "Sign in"}
          </button>
          {login.isError && (
            <p style={{ fontSize: 13, color: "var(--danger)" }}>
              {(login.error as ApiError).message || "Sign-in failed."}
            </p>
          )}
        </form>

      </div>
    </div>
  );
}

/** Microsoft's four-square mark. Inline rather than an image so it needs no
 *  network request on a page that may be the first thing a person loads. */
function MicrosoftMark() {
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true">
      <rect x="0" y="0" width="7" height="7" fill="#F25022" />
      <rect x="9" y="0" width="7" height="7" fill="#7FBA00" />
      <rect x="0" y="9" width="7" height="7" fill="#00A4EF" />
      <rect x="9" y="9" width="7" height="7" fill="#FFB900" />
    </svg>
  );
}
