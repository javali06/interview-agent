import { useEffect, useRef, useState } from "react";
import type { ScenarioItemMsg } from "../lib/candidateEngine";

// Candidate-facing panel for a Visual Scenario Analysis item — mounts in the
// LEFT column of Candidate.tsx, below the AI/candidate video tiles, where
// there's real vertical room for a large image/video/audio (the right
// column stays for transcript + chat + the coding panel, which is
// mutually exclusive with this one per phase).
//
// Click the media (or the ⛶ button) to view it fullscreen — the SAME native
// Fullscreen API + button styling VideoTiles.tsx uses for the AI/candidate
// tiles, reimplemented locally here rather than exported from that file, so
// this stays a self-contained, low-risk addition.
//
// Handles the runtime spec's playback edge cases itself (Director only knows
// about acks, not WHY one arrives):
//   - autoplay-blocked browsers → catch the rejected .play() promise, show a
//     manual Play button instead of silently never playing.
//   - candidate manually stops playback before it ends → ack "skipped" (the
//     item can still be answered; server treats this the same as "ended").
//   - media fails to load → ack "error" (server skips the item and briefly
//     acknowledges it on the next item's opening line).
//   - a RESYNC after reconnect (item.resync) never autoplays — the candidate
//     gets a Play button instead of an unexpected restart from zero.
const mediaUrl = (token: string, ref: string) =>
  `/api/sessions/${token}/phase-asset/${encodeURIComponent(ref)}`;

// Mirrors VideoTiles.tsx's requestFullscreen exactly (prefixed Safari
// fallback; swallow rejection so a denied request is a no-op).
type FsElement = HTMLElement & { webkitRequestFullscreen?: () => void };
function requestFullscreen(el: HTMLElement | null) {
  if (!el) return;
  const e = el as FsElement;
  if (e.requestFullscreen) void e.requestFullscreen().catch(() => {});
  else if (e.webkitRequestFullscreen) e.webkitRequestFullscreen();
}

// Same small overlay affordance as VideoTiles' FsButton, styled to match.
function FsButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      title="View fullscreen"
      style={{
        position: "absolute", right: 10, top: 10, zIndex: 2, cursor: "pointer",
        width: 30, height: 30, borderRadius: 8, border: "none", lineHeight: 1,
        background: "rgba(0,0,0,0.55)", color: "#fff", fontSize: 16,
      }}
    >⛶</button>
  );
}

export function ScenarioMediaPanel({
  item,
  token,
  onMediaAck,
}: {
  item: ScenarioItemMsg;
  token: string;
  onMediaAck: (kind: "ended" | "error" | "skipped") => void;
}) {
  const frameRef = useRef<HTMLDivElement | null>(null);
  const mediaRef = useRef<HTMLVideoElement | HTMLAudioElement | null>(null);
  const [autoplayBlocked, setAutoplayBlocked] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const ackedRef = useRef(false);

  const kind = item.media.kind;
  const url = mediaUrl(token, item.media.ref);

  useEffect(() => {
    ackedRef.current = false;
    setAutoplayBlocked(false);
    setLoadError(false);
    if (kind === "image") return;
    const el = mediaRef.current;
    // Never autoplay a RESEED after reconnect — the candidate would see the
    // clip unexpectedly restart from zero. Show the Play button instead.
    if (!el || item.resync) return;
    const p = el.play();
    if (p && typeof p.then === "function") {
      p.catch(() => setAutoplayBlocked(true));
    }
    // Re-run only when the item actually changes, not on every re-render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [item.item_id]);

  const ack = (k: "ended" | "error" | "skipped") => {
    if (ackedRef.current) return;
    ackedRef.current = true;
    onMediaAck(k);
  };

  const playManually = () => {
    setAutoplayBlocked(false);
    mediaRef.current?.play().catch(() => setAutoplayBlocked(true));
  };

  const onPause = () => {
    const el = mediaRef.current;
    // A pause AT the natural end also fires onPause — only treat an EARLY
    // manual stop as "skipped" so the item can still be answered.
    if (el && !el.ended && el.currentTime > 0) {
      ack("skipped");
    }
  };

  const onError = () => {
    setLoadError(true);
    ack("error");
  };

  const goFullscreen = () => requestFullscreen(frameRef.current);

  return (
    <div
      className="card"
      style={{
        marginTop: 10, padding: 16, background: "#160d1c",
        border: "1px solid var(--line)", borderRadius: 14,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
        <span
          className="muted-3"
          style={{
            fontSize: 11.5, fontFamily: "var(--mono)", textTransform: "uppercase",
            letterSpacing: "0.08em",
          }}
        >
          Scenario {item.item_index + 1} of {item.item_total}
        </span>
        <span
          className="muted-3"
          style={{ fontSize: 11, display: "flex", alignItems: "center", gap: 5 }}
        >
          <span style={{ fontSize: 13 }}>⛶</span> click to expand
        </span>
      </div>

      {loadError ? (
        <p style={{ fontSize: 13, color: "var(--warn)" }}>
          This item's media couldn't be loaded.
        </p>
      ) : (
        <>
          <div
            ref={frameRef}
            onClick={kind === "image" ? goFullscreen : undefined}
            style={{
              position: "relative", width: "100%",
              minHeight: 260, maxHeight: "38vh",
              display: "flex", alignItems: "center", justifyContent: "center",
              borderRadius: 10, overflow: "hidden", background: "#0b0710",
              cursor: kind === "image" ? "zoom-in" : "default",
            }}
          >
            {kind === "image" && (
              <img
                src={url}
                alt=""
                onError={onError}
                style={{ maxWidth: "100%", maxHeight: "38vh", objectFit: "contain" }}
              />
            )}
            {kind === "video" && (
              <video
                ref={mediaRef as React.RefObject<HTMLVideoElement>}
                src={url}
                controls
                playsInline
                style={{ maxWidth: "100%", maxHeight: "38vh", width: "100%", background: "#000" }}
                onEnded={() => ack("ended")}
                onPause={onPause}
                onError={onError}
              />
            )}
            {kind === "audio" && (
              <div style={{ width: "100%", padding: "28px 20px" }}>
                <div style={{ fontSize: 40, textAlign: "center", marginBottom: 14 }}>🎙</div>
                <audio
                  ref={mediaRef as React.RefObject<HTMLAudioElement>}
                  src={url}
                  controls
                  style={{ width: "100%" }}
                  onEnded={() => ack("ended")}
                  onPause={onPause}
                  onError={onError}
                />
              </div>
            )}
            <FsButton onClick={goFullscreen} />
          </div>

          {autoplayBlocked && kind !== "image" && (
            <button
              type="button"
              onClick={playManually}
              className="btn btn-sm"
              style={{
                marginTop: 10, background: "var(--magenta-soft)", color: "var(--magenta)",
                borderColor: "rgba(255,66,187,0.4)", fontWeight: 600,
              }}
            >
              ▶ Play
            </button>
          )}
        </>
      )}
    </div>
  );
}
