import { useEffect, useLayoutEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { CandidateEngine, readParams, type CheckState, type VisualMode } from "../lib/candidateEngine";
import { bootAvatar, type AvatarSink } from "../lib/talkingHead";
import { bootSimli } from "../lib/simliAvatar";
import { listDevices } from "../lib/videoCam";
import { CamPreview, ScreenSharePreview } from "../components/VideoTiles";
import { CodingPanel } from "./CodingPanel";
import { ScenarioMediaPanel } from "./ScenarioMediaPanel";
import type { CodingPhaseMsg } from "../coding";
import { TermsModal, type TermsConsent } from "../components/TermsModal";
import { PreparingOverlay } from "../components/PreparingOverlay";
import AiOrb, { type Mode as OrbMode } from "../components/AiOrb";
import { getLevel as readOrbLevel } from "../lib/orbGlow";
import { useConnectionQuality, type ConnQuality } from "../lib/connectionQuality";
import type { TranscriptRow } from "../components/TranscriptView";
import "./CandidateLive.css";

// Head-and-shoulders, webcam-style framing for the candidate's 4:5 avatar frame.
// TalkingHead frames off eye height: with the "head" preset this crop runs from
// mid-chest to ~6% headroom above the hair, eyes just under the upper third.
const CANDIDATE_AVATAR_CAMERA = { cameraView: "head", cameraDistance: 0.54, cameraY: 0.49 } as const;

// Gap-masking flow between clicking "Start interview" and the AI's first words:
//   "none"      → lobby / live as usual
//   "terms"     → blocking T&C modal (session NOT yet started)
//   "preparing" → dino-game overlay while the session spins up; auto-closes the
//                 instant the AI is about to speak (turn.state → "speaking").
type StartFlow = "none" | "terms" | "preparing";

// Standalone coding-panel preview (?demo_coding=1) — mounts Monaco + Pyodide
// with a fixed question, no backend. Lets the coding flow be verified locally.
const DEMO_CODING: CodingPhaseMsg = {
  phase_id: "demo",
  questions: [
    {
      question_id: "running_sum",
      title: "Running Sum",
      question_prompt:
        "Given a list `nums`, return its running sum where out[i] = nums[0] + … + nums[i].",
      starter_code: "def running_sum(nums):\n    # return the running sum\n    pass\n",
      function_name: "running_sum",
      test_cases: [
        { name: "basic", input: "[1, 2, 3, 4]", expected: "[1, 3, 6, 10]" },
        { name: "single", input: "[5]", expected: "[5]" },
        { name: "empty", input: "[]", expected: "[]" },
      ],
      time_budget_s: 600,
    },
  ],
};

// Standalone full-screen candidate interview UI (no admin shell, no auth gate).
// Minimal visual mode: orb + captions. Avatar (increment 3) + coding panel
// (increment 2) are deferred; ?demo=1 runs the live screen with no backend.
export function Candidate() {
  const params = useMemo(() => readParams(window.location.search), []);
  const engine = useMemo(() => new CandidateEngine(params), [params]);
  const s = useSyncExternalStore(engine.subscribe, engine.getSnapshot);

  // Terms → "please wait" game flow (see StartFlow). Local UI state: the engine
  // owns the session, this owns only the pre-greeting overlay sequence.
  const [flow, setFlow] = useState<StartFlow>("none");
  const preparingSince = useRef(0);

  useEffect(() => {
    engine.init();
    return () => engine.destroy();
  }, [engine]);

  useEffect(() => {
    document.body.classList.add("cl-body-bg");
    return () => document.body.classList.remove("cl-body-bg");
  }, []);

  // Signal-bars data for the top-bar connection icon, active once live. The
  // engine's own reconnecting flag overrides the generic probe so a dropped WS
  // shows immediately.
  const conn = useConnectionQuality(s.screen === "live", s.reconnecting ? "reconnecting" : null);

  // Safety net: never trap the candidate in the game. If the AI hasn't spoken
  // within 60s of the overlay opening, drop them into the live screen anyway.
  useEffect(() => {
    if (flow !== "preparing") return;
    preparingSince.current = Date.now();
    const safety = setTimeout(() => setFlow("none"), 60000);
    return () => clearTimeout(safety);
  }, [flow]);

  // Auto-close the game overlay the moment the AI is about to speak. turn.state
  // flips to "speaking" when the first audio_start arrives (candidateEngine).
  // A small minimum-display avoids a jarring flash when the gap is tiny.
  useEffect(() => {
    if (flow !== "preparing" || s.turn.state !== "speaking") return;
    const wait = Math.max(0, 1200 - (Date.now() - preparingSince.current));
    const t = setTimeout(() => setFlow("none"), wait);
    return () => clearTimeout(t);
  }, [flow, s.turn.state]);

  const acceptTerms = (consent: TermsConsent) => {
    setFlow("preparing");
    void engine.startInterview(consent);
  };

  // Warn before closing while a recording is in progress or still uploading, so
  // the candidate doesn't lose the recording by closing early. (Browsers only
  // allow a native confirm prompt here — a tab close can't be hard-blocked.)
  useEffect(() => {
    if (!s.recording && !s.savingRecording) return;
    const handler = (e: BeforeUnloadEvent) => { e.preventDefault(); e.returnValue = ""; };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [s.recording, s.savingRecording]);

  // Standalone coding-panel preview — bypasses lobby/live.
  if (params.demoCoding) {
    return (
      <>
        <div className="app-bg" />
        <div style={{ position: "relative", zIndex: 1, minHeight: "100vh", padding: 24 }}>
          <CodingPanel phaseStartMsg={DEMO_CODING} sendWS={() => {}} hint={null} />
        </div>
      </>
    );
  }

  return (
    <>
      {s.screen === "lobby" && <Lobby s={s} engine={engine} onStart={() => setFlow("terms")} />}
      {s.screen === "live" && <Live s={s} engine={engine} conn={conn} />}
      {s.screen === "done" && <Done name={s.name} saving={s.savingRecording} />}

      {flow === "terms" && (
        <TermsModal recordingEnabled={s.recordingEnabled} onAccept={acceptTerms} onDecline={() => setFlow("none")} />
      )}
      {flow === "preparing" && <PreparingOverlay />}

      {/* Calm reconnecting pill — the live WS dropped (e.g. a server restart)
          and we're auto-reconnecting. A small top pill, not a full-screen
          block, so it doesn't hide the live stage behind it. Auto-clears on
          reconnect; falls to the modal below only if we give up. */}
      {s.reconnecting && !s.modal && (
        <div className="cl-root" style={{ position: "fixed", top: 16, left: "50%", transform: "translateX(-50%)", zIndex: 55 }}>
          <span className="cl-pill" style={{ background: "var(--ds-warning-soft)", borderColor: "transparent", color: "var(--ds-warning)" }}>
            <span style={{ width: 7, height: 7, borderRadius: "50%", background: "var(--ds-warning)", animation: "cl-rec-pulse 1.3s ease-in-out infinite" }} />
            Reconnecting — hang tight, your interview will resume
          </span>
        </div>
      )}

      {/* Generic info/error modal (e.g. a blocked permission or a lost-
          connection dead-end) — engine-driven, unchanged logic, new look. */}
      {s.modal && (
        <div className="cl-root cl-modal-backdrop">
          <div className="cl-modal-card cl-modal-sm">
            <div className="cl-modal-head">
              <h2 className="cl-modal-title">{s.modal.title}</h2>
            </div>
            <div className="cl-modal-body">
              <p className="cl-modal-section-p" style={{ marginTop: 0 }}>{s.modal.body}</p>
            </div>
            <div className="cl-modal-footer" style={{ borderTop: "none", paddingTop: 0 }}>
              <div className="cl-modal-actions">
                <button type="button" onClick={engine.dismissModal} className="cl-btn cl-btn-primary cl-btn-sm">OK</button>
              </div>
            </div>
          </div>
        </div>
      )}
      {s.toast && (
        <div className="cl-root" style={{ position: "fixed", bottom: 16, left: "50%", zIndex: 40, transform: "translateX(-50%)" }}>
          <div style={{ background: "#fff", boxShadow: "var(--ds-shadow)", borderRadius: "var(--ds-radius-md)", padding: "10px 16px", fontSize: 14, color: "var(--ds-text)" }}>
            {s.toast}
          </div>
        </div>
      )}
    </>
  );
}

// Plain list row — icon + label + detail + an optional action link, no box.
// `required` renders a small red asterisk (camera/screen are mandatory).
function CheckRow({
  label,
  state,
  detail,
  action,
  required,
}: {
  label: string;
  state: CheckState;
  detail: string;
  action?: React.ReactNode;
  required?: boolean;
}) {
  return (
    <div className="cl-check-row">
      <span className={`cl-check-icon ${state}`}>
        {state === "ok" && (
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12" />
          </svg>
        )}
      </span>
      <div className="cl-check-body">
        <div className="cl-check-label">{label}{required && <span style={{ color: "var(--ds-danger)" }}> *</span>}</div>
        <div className="cl-check-detail">{detail}</div>
      </div>
      {action && <div className="cl-check-action">{action}</div>}
    </div>
  );
}

// Lobby tips/features copy, shown in the "Tips" modal. Kept as data so the
// modal markup stays tidy; any text before an " — " is rendered bold as a
// lead-in by <TipLi>.
const LOBBY_INSTRUCTIONS: string[] = [
  "Wait for the AI to finish, then answer.",
  "Speak in a natural, continuous flow — say your whole thought, then stop.",
  "Pause clearly when you're done — the system waits about a second of silence to be sure you've finished. A clean pause means a fast, correct response.",
  "Take a breath and think if you need to — short thinking pauses are fine.",
  "Give complete answers — it's a conversation; 2–5 sentences per point is a good rhythm.",
  "A brief delay of 1–3 seconds before the AI responds is normal — it's composing a thoughtful reply.",
];

const LOBBY_FEATURES: string[] = [
  "Mute button — you can mute your mic, but don't stay muted while trying to speak. If you talk while muted, you'll see a reminder to unmute — the AI genuinely can't hear you.",
  "Stay on the tab — don't refresh or close the browser, or you could interrupt the session. If you're disconnected, reopen the same link right away.",
];

// Only relevant when this interview is configured to record (camera+screen).
const LOBBY_FEATURES_RECORDING: string[] = [
  "Camera / Screen share / Blur — toggle as needed from the top bar.",
  "Screen share — if asked, choose \"Entire screen\" (not a single window or tab) when your browser prompts you.",
];

// One bullet in the Tips modal. Bolds the lead-in phrase before the first
// " — " for scannability.
function TipLi({ text }: { text: string }) {
  const dash = text.indexOf(" — ");
  const lead = dash > -1 ? text.slice(0, dash) : null;
  const rest = dash > -1 ? text.slice(dash + 3) : text;
  return (
    <li>
      {lead && <b>{lead} — </b>}
      {rest}
    </li>
  );
}

// "Tips" link opens this instead of a permanent side panel — same copy as
// before, just collapsed out of the way until asked for.
function TipsModal({ onClose, recordingEnabled }: { onClose: () => void; recordingEnabled: boolean }) {
  return (
    <div className="cl-root cl-modal-backdrop" onClick={onClose}>
      <div className="cl-modal-card" onClick={(e) => e.stopPropagation()}>
        <div className="cl-modal-head">
          <h2 className="cl-modal-title">Tips for a smooth interview</h2>
        </div>
        <div className="cl-modal-body">
          <div>
            <h3 className="cl-modal-section-h">How to talk with the AI</h3>
            <ul className="cl-tip-list" style={{ marginTop: 10 }}>
              {LOBBY_INSTRUCTIONS.map((t, i) => (<TipLi key={i} text={t} />))}
            </ul>
          </div>
          <div>
            <h3 className="cl-modal-section-h">Features</h3>
            <ul className="cl-tip-list" style={{ marginTop: 10 }}>
              {[...LOBBY_FEATURES, ...(recordingEnabled ? LOBBY_FEATURES_RECORDING : [])].map((t, i) => (<TipLi key={i} text={t} />))}
            </ul>
          </div>
        </div>
        <div className="cl-modal-footer" style={{ alignItems: "flex-end" }}>
          <div className="cl-modal-actions">
            <button type="button" className="cl-btn cl-btn-secondary cl-btn-sm" onClick={onClose}>Close</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Lobby({ s, engine, onStart }: { s: ReturnType<CandidateEngine["getSnapshot"]>; engine: CandidateEngine; onStart: () => void }) {
  // (C) Populate device pickers. Labels only fill in after a mic/camera
  // permission grant, so re-enumerate whenever the mic or camera turns on.
  const [devices, setDevices] = useState<{ cameras: MediaDeviceInfo[]; mics: MediaDeviceInfo[] }>({ cameras: [], mics: [] });
  useEffect(() => {
    let alive = true;
    void listDevices().then((d) => { if (alive) setDevices({ cameras: d.cameras, mics: d.mics }); }).catch(() => {});
    return () => { alive = false; };
  }, [s.micEnabled, s.cameraOn]);

  const [tipsOpen, setTipsOpen] = useState(false);

  // candidateEngine.ts has no "camera" entry in its checks record (only
  // mic/speaker/browser/connection/screen do) — a denied camera permission
  // only shows up as a toast today. This local flag is a pure UI read of
  // enableCamera()'s own existing return value, not a change to engine logic,
  // so the blocked-permission hint below can still work for camera too.
  const [cameraBlocked, setCameraBlocked] = useState(false);
  const tryCamera = async () => {
    setCameraBlocked(false);
    const ok = await engine.enableCamera();
    if (!ok) setCameraBlocked(true);
  };

  const hasRole = s.role.trim() && s.role !== "the role";

  return (
    <div className="cl-root cl-page cl-lobby screen-enter">
      <div className="cl-lobby-card">
        <h1 className="cl-lobby-title">Hi {s.name}</h1>
        <p className="cl-lobby-sub">
          {hasRole ? <>Interview for <b>{s.role}</b> · {s.durationLabel}</> : s.durationLabel}
        </p>

        <div className="cl-check-list">
          <div className="cl-check-item">
            <CheckRow
              label="Microphone"
              state={s.checks.mic}
              detail={s.micEnabled ? "Active — speak normally" : "We need your mic for the interview"}
              action={
                s.micEnabled ? (
                  <div className="cl-mic-meter-sm"><i style={{ width: `${s.micLevel}%` }} /></div>
                ) : s.checks.mic !== "error" ? (
                  <button type="button" onClick={() => void engine.enableMic()} className="cl-btn cl-btn-secondary cl-btn-sm">Enable</button>
                ) : null
              }
            />
            {/* (C) Mic device picker — changing re-acquires the worklet capture. */}
            {devices.mics.length > 1 && (
              <div className="cl-check-sub">
                <select className="cl-select" value={s.selectedMicId ?? ""} onChange={(e) => void engine.selectMic(e.target.value)}>
                  <option value="">Default microphone</option>
                  {devices.mics.map((m, i) => (
                    <option key={m.deviceId} value={m.deviceId}>{m.label || `Microphone ${i + 1}`}</option>
                  ))}
                </select>
              </div>
            )}
            {s.checks.mic === "error" && (
              <div className="cl-help-line">
                Microphone is blocked. Click the icon left of the address bar and allow microphone, then press Retry.
                <button type="button" onClick={() => void engine.enableMic()} className="cl-btn cl-btn-secondary cl-btn-sm">Retry</button>
              </div>
            )}
          </div>

          <div className="cl-check-item">
            <CheckRow
              label="Speaker"
              state={s.checks.speaker}
              detail={s.speakerTested ? "Did you hear the chime? ✓" : "Play a test tone"}
              action={<button type="button" onClick={() => void engine.testSpeaker()} className="cl-btn cl-btn-secondary cl-btn-sm">{s.speakerTested ? "Play again" : "Test"}</button>}
            />
          </div>
          <div className="cl-check-item"><CheckRow label="Browser" state={s.checks.browser} detail={s.browserLabel} /></div>
          <div className="cl-check-item"><CheckRow label="Connection" state={s.checks.connection} detail={s.connCheckLabel} /></div>

          {/* Camera + screen share only apply when this interview is configured to
              record (admin's choice at schedule time, immutable, carried on the
              cadence). When off, these rows aren't rendered at all — not
              disabled/greyed — and don't gate the Start button. */}
          {s.recordingEnabled && (
            <>
              <div className="cl-check-item">
                <CheckRow
                  label="Camera"
                  required
                  state={s.cameraOn ? "ok" : cameraBlocked ? "error" : "pending"}
                  detail={s.cameraOn ? "On — recorded with your interview." : "Required — turn it on to start."}
                  action={s.cameraOn
                    ? <CamPreview stream={engine.getLocalStream()} size={40} />
                    : !cameraBlocked ? <button type="button" onClick={() => void tryCamera()} className="cl-btn cl-btn-secondary cl-btn-sm">Enable</button> : null}
                />
                <div className="cl-check-sub">
                  {devices.cameras.length > 1 && (
                    <select className="cl-select" value={s.selectedCamId ?? ""} onChange={(e) => void engine.selectCamera(e.target.value)}>
                      <option value="">Default camera</option>
                      {devices.cameras.map((c, i) => (
                        <option key={c.deviceId} value={c.deviceId}>{c.label || `Camera ${i + 1}`}</option>
                      ))}
                    </select>
                  )}
                  <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 13, color: "var(--ds-text-2)", cursor: "pointer" }}>
                    <input type="checkbox" checked={s.bgBlurOn} onChange={() => void engine.toggleBlur()} style={{ accentColor: "var(--ds-accent)" }} />
                    Blur background
                  </label>
                </div>
                {cameraBlocked && (
                  <div className="cl-help-line">
                    Camera is blocked. Click the icon left of the address bar and allow camera, then press Retry.
                    <button type="button" onClick={() => void tryCamera()} className="cl-btn cl-btn-secondary cl-btn-sm">Retry</button>
                  </div>
                )}
              </div>

              {/* Entire-screen share is REQUIRED for candidates (proctoring) — gates
                  the Start button. The click is the user gesture getDisplayMedia
                  needs; the engine validates it's the whole monitor (not a window/tab). */}
              <div className="cl-check-item">
                <CheckRow
                  label="Share your entire screen"
                  required
                  state={s.checks.screen}
                  detail={
                    s.screenOn
                      ? "Sharing — your entire screen is recorded for the full interview."
                      : "Required — your whole screen is recorded for the duration of the interview."
                  }
                  action={!s.screenOn && s.checks.screen !== "error" && (
                    <button type="button" onClick={() => void engine.enableScreen()} className="cl-btn cl-btn-secondary cl-btn-sm">Share screen</button>
                  )}
                />
                {s.checks.screen === "error" && (
                  <div className="cl-help-line">
                    Please pick "Entire screen" (not a window or tab) when your browser prompts you, then press Retry.
                    <button type="button" onClick={() => void engine.enableScreen()} className="cl-btn cl-btn-secondary cl-btn-sm">Retry</button>
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        <div className="cl-segmented">
          {(["minimal", "avatar", "simli"] as const).map((m) => (
            <button
              key={m}
              type="button"
              className={s.visualMode === m ? "active" : ""}
              onClick={() => engine.setVisualMode(m)}
            >
              {m === "avatar" ? "3D avatar" : m === "simli" ? "Photoreal" : "Minimal (orb)"}
            </button>
          ))}
        </div>

        <p className="cl-lobby-tips">
          <button type="button" className="cl-btn cl-btn-ghost" onClick={() => setTipsOpen(true)}>Tips for a smooth interview</button>
        </p>

        <div className="cl-lobby-start">
          <button type="button" disabled={!s.startReady} onClick={onStart} className="cl-btn cl-btn-primary cl-btn-lg">
            {s.startReady ? "Start interview" : "Complete the checks above"}
          </button>
        </div>
      </div>

      {tipsOpen && <TipsModal recordingEnabled={s.recordingEnabled} onClose={() => setTipsOpen(false)} />}
    </div>
  );
}

function Live({ s, engine, conn }: { s: ReturnType<CandidateEngine["getSnapshot"]>; engine: CandidateEngine; conn: ConnQuality }) {
  const speaking = s.turn.state === "speaking";
  // Dead simple: AVA is speaking → "speaking"; otherwise the candidate's mic is
  // active → "hearing"; otherwise a calm rest. No "your turn"/"thinking" state.
  const hearing = !speaking && !s.micMuted && s.candidateSpeaking;
  const statusLabel = speaking ? "AVA is speaking"
    : s.micMuted ? "Muted — AVA can't hear you"
    : "";
  const orbMode: OrbMode = speaking
    ? "speaking"
    : s.micMuted
    ? "idle"
    : hearing
    ? "hearing"
    : "listening";

  const [settingsOpen, setSettingsOpen] = useState(false);
  // The transcript panel starts closed and opens from its button in the dock,
  // so the stage has the room by default. It is the transcript only: an
  // interview is the AI and the candidate, so there is no chat tab.
  const [panelOpen, setPanelOpen] = useState(false);
  const togglePanel = () => { setPanelOpen((v) => !v); setSettingsOpen(false); };

  // Transcript turn times — stamped with the interview timer the first time a
  // row is seen (rows carry no timestamp). Lives here, not in the panel, so rows
  // that arrive while the panel is collapsed still get the right time.
  const stamps = useTurnStamps(s.rows, s.timer);

  return (
    <div className="cl-root cl-page cl-live-root">
      <header className="cl-topbar">
        <div className="cl-logo">
          <span className="cl-logo-mark">a.</span>
          <span className="cl-logo-text">AVA</span>
        </div>

        {/* Phase progress — intentionally empty. The candidate snapshot has
            no phase list / current-phase field (candidateEngine.ts's
            CandidateSnapshot only carries feature-specific coding/scenario
            flags, not the general cadence), so there's nothing to drive a
            progress bar with. */}
        <div className="cl-topbar-center" />

        {/* Right side, in order: connection, screen share, timer, REC. */}
        <div className="cl-topbar-right">

          <ConnectionIcon quality={conn} ws={s.conn} />

          {/* Screen-share status — a small live thumbnail (display only; the
              screen is recorded by the engine, not sent anywhere live) + a dot
              + label. translateY cancels the preview's own 10px top margin so
              it fills the thumbnail. */}
          {s.recordingEnabled && s.screenOn && (
            <span className="cl-pill cl-share-chip" title="Your entire screen is shared and recorded">
              <span className="cl-share-thumb">
                <div style={{ width: 200, height: 112.5, transform: "scale(0.23) translateY(-10px)", transformOrigin: "top left" }}>
                  <ScreenSharePreview stream={engine.getLocalScreenStream()} label="" />
                </div>
              </span>
              <span className="cl-share-dot" />
              <span className="cl-chip-label">Sharing screen</span>
            </span>
          )}
          <span className="cl-pill" title="Time elapsed">{s.timer}</span>
          {s.recording && <span className="cl-pill cl-rec" title="This session is being recorded"><span /> REC</span>}
        </div>
      </header>

      <div className="cl-body">
        <div className="cl-stage-area">
          <main className="cl-main">
            <div className="cl-stage-stack">
              <div className="cl-center-group">
                <div className="cl-stage">
                  <Stage engine={engine} visualMode={s.visualMode} mode={orbMode} speaking={speaking} />
                </div>
                <div className="cl-caption-col">
                  <span className="cl-ava-label">AVA</span>
                  {/* key={s.caption} re-triggers the CSS fade-in whenever the
                      text actually changes, and nothing else — so the AI's
                      current/last utterance just stays on screen (ground
                      truth from the engine snapshot) until a new one replaces
                      it; no local state to drift out of sync. */}
                  <div className="cl-caption">
                    <span key={s.caption} className="cl-caption-text">{s.caption}</span>
                  </div>
                  <div className="cl-status-row" role="status" aria-live="polite">
                    <span className={`cl-status-pill${speaking ? " speaking" : ""}`}>
                      <i />
                      {statusLabel}
                    </span>
                  </div>

                  {s.mutedNudge && (
                    <div className="cl-muted-pill">
                      <MicIcon muted /> You're muted
                      <button type="button" onClick={() => engine.toggleMic()}>Unmute</button>
                    </div>
                  )}
                </div>
              </div>

              {/* Coding / Visual Scenario Analysis phases are graded interview
                  content, not chrome — they keep mounting exactly as before,
                  just full-width below the center group (Monaco/media need
                  more room than the caption column). */}
              {s.codingActive && s.codingPhaseMsg && (
                <div className="cl-wide-panel">
                  <CodingPanel phaseStartMsg={s.codingPhaseMsg as CodingPhaseMsg} sendWS={engine.sendCoding} hint={s.codingHint} />
                </div>
              )}
              {s.scenarioActive && s.scenarioItem && (
                <div className="cl-wide-panel">
                  <ScenarioMediaPanel item={s.scenarioItem} token={engine.getToken() || ""} onMediaAck={engine.sendScenarioMediaAck} />
                </div>
              )}
            </div>
          </main>

          <div className="cl-tiles">
            <CamTile
              stream={engine.getLocalStream()}
              micLevel={s.micLevel}
              muted={s.micMuted}
              name={s.name}
              speaking={s.candidateSpeaking && !s.micMuted}
            />
          </div>

          <div className="cl-dock-wrap">
            {settingsOpen && <SettingsPopover s={s} engine={engine} />}
            <div className="cl-dock">
              <button
                type="button"
                className={`cl-dock-btn${s.micMuted ? " muted" : ""}`}
                onClick={() => engine.toggleMic()}
                title={s.micMuted ? "You're muted — the AI can't hear you" : "Mute your mic"}
              >
                <MicIcon muted={s.micMuted} />
              </button>

              {/* Camera is mandatory once recording is on — locked while cameraOn,
                  re-enables only if it drops unexpectedly (engine.onCameraEnded). */}
              {s.recordingEnabled && (
                <button
                  type="button"
                  className={`cl-dock-btn${s.cameraOn ? " active" : ""}`}
                  onClick={() => void engine.toggleCamera()}
                  disabled={s.cameraOn}
                  title={s.cameraOn ? "Camera must stay on for this interview" : "Reconnect your camera (required)"}
                >
                  <CamIcon on={s.cameraOn} />
                </button>
              )}

              <button
                type="button"
                className={`cl-dock-btn${panelOpen ? " active" : ""}`}
                onClick={togglePanel}
                title="Transcript"
              >
                <TranscriptIcon />
              </button>

              <button
                type="button"
                className={`cl-dock-btn${settingsOpen ? " active" : ""}`}
                onClick={() => { setSettingsOpen((v) => !v); setPanelOpen(false); }}
                title="Settings"
              >
                <GearIcon />
              </button>

              {/* Screen sharing stays mandatory; shown as a small status icon
                  (tooltip carries the detail) + the one-click way back on if it
                  dropped (stopping is via the browser's own "Stop sharing"
                  control, which prompts a re-share). */}
              {s.recordingEnabled && (
                <>
                  <div className="cl-dock-sep" />
                  <button
                    type="button"
                    className={`cl-dock-btn ${s.screenOn ? "screen-on" : "screen-off"}`}
                    onClick={() => { if (!s.screenOn) void engine.enableScreen(); }}
                    style={s.screenOn ? { cursor: "default" } : undefined}
                    title={s.screenOn ? "Your entire screen is shared and recorded" : "Re-share your entire screen (required)"}
                  >
                    <ScreenIcon />
                  </button>
                </>
              )}

              <div className="cl-dock-sep" />
              <button type="button" className="cl-dock-btn end" onClick={engine.endInterview} title="End interview">
                <EndIcon />
              </button>
            </div>
          </div>
        </div>

        {panelOpen && (
          <SidePanel onClose={() => setPanelOpen(false)} rows={s.rows} stamps={stamps} count={s.count} />
        )}
      </div>
    </div>
  );
}

// Top-bar connection quality: the generic network probe (latency) combined
// with the interview socket's own state — whichever is worse sets the colour.
const CONN_LOOK: Record<ConnQuality["state"], { bars: number; color: string; label: string }> = {
  good: { bars: 4, color: "var(--ds-success)", label: "Good connection" },
  fair: { bars: 3, color: "var(--ds-warning)", label: "Fair connection" },
  poor: { bars: 1, color: "var(--ds-danger)", label: "Poor connection" },
  offline: { bars: 0, color: "var(--ds-danger)", label: "No internet connection" },
  reconnecting: { bars: 0, color: "var(--ds-warning)", label: "Reconnecting…" },
};
const CONN_RANK: ConnQuality["state"][] = ["good", "fair", "poor", "reconnecting", "offline"];
const WS_TO_QUALITY: Record<string, ConnQuality["state"]> = { ok: "good", connecting: "good", warn: "fair", error: "poor" };

function ConnectionIcon({ quality, ws }: { quality: ConnQuality; ws: { state: string; label: string } }) {
  const wsState = WS_TO_QUALITY[ws.state] ?? "good";
  const state = CONN_RANK.indexOf(wsState) > CONN_RANK.indexOf(quality.state) ? wsState : quality.state;
  const look = CONN_LOOK[state];
  const showMs = quality.rttMs != null && state !== "offline" && state !== "reconnecting";
  const parts = [look.label];
  if (showMs) parts.push(`${quality.rttMs} ms latency`);
  if (ws.state !== "ok" && ws.state !== "connecting" && ws.label) parts.push(ws.label);
  const title = parts.join(" · ");
  return (
    <span className="cl-pill icon-only" title={title} aria-label={title} role="img">
      <svg width="16" height="13" viewBox="0 0 16 13" aria-hidden="true">
        {[4, 7, 10, 13].map((h, i) => (
          <rect key={i} x={i * 4.2} y={13 - h} width={3} height={h} rx={0.75} fill={i < look.bars ? look.color : "var(--ds-border)"} />
        ))}
      </svg>
    </span>
  );
}

// Stamps each transcript row with the interview timer value at the moment the
// UI first sees it. A final STT row replaces its in-flight partial (new id), so
// it inherits the partial's stamp — the time the person started speaking.
function useTurnStamps(rows: TranscriptRow[], timer: string): Map<number, string> {
  const stamps = useRef(new Map<number, string>());
  const lastPartial = useRef(new Map<string, { id: number; stamp: string }>());
  const ids = new Set(rows.map((r) => r.id));
  const finished = new Map<string, string>();
  for (const [role, p] of lastPartial.current) {
    if (!ids.has(p.id)) {
      finished.set(role, p.stamp);
      lastPartial.current.delete(role);
    }
  }
  for (const r of rows) {
    if (stamps.current.has(r.id)) continue;
    let stamp = timer;
    if (!r.partial && finished.has(r.role)) {
      stamp = finished.get(r.role)!;
      finished.delete(r.role);
    }
    stamps.current.set(r.id, stamp);
    if (r.partial) lastPartial.current.set(r.role, { id: r.id, stamp });
  }
  return stamps.current;
}

// Consecutive rows from the same speaker read as one turn: AI audio arrives in
// chunks (one row each, appended as it's heard) and long answers can finalize in
// several STT segments.
type Turn = { key: number; role: string; stamp: string; parts: TranscriptRow[] };
function groupTurns(rows: TranscriptRow[], stamps: Map<number, string>): Turn[] {
  const turns: Turn[] = [];
  for (const r of rows) {
    const last = turns[turns.length - 1];
    if (last && last.role === r.role) last.parts.push(r);
    else turns.push({ key: r.id, role: r.role, stamp: stamps.get(r.id) ?? "", parts: [r] });
  }
  return turns;
}

const ROLE_LABEL: Record<string, string> = { ai: "AVA", candidate: "You", interviewer: "Interviewer" };

// Right side panel — the live transcript (read-only). "interviewer" rows only
// appear in past interviews (a human TA could join before the observer feature
// was removed); ROLE_LABEL keeps them reading right.
function SidePanel({
  onClose, rows, stamps, count,
}: {
  onClose: () => void;
  rows: TranscriptRow[];
  stamps: Map<number, string>;
  count: number;
}) {
  // Follow the newest line while the reader is at the bottom; once they scroll
  // up, stop following and offer "Jump to latest" instead.
  const bodyRef = useRef<HTMLDivElement>(null);
  const followRef = useRef(true);
  const [following, setFollowing] = useState(true);
  const scrollToEnd = () => {
    const el = bodyRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  };
  const follow = () => {
    followRef.current = true;
    setFollowing(true);
    scrollToEnd();
  };
  const onScroll = () => {
    const el = bodyRef.current;
    if (!el) return;
    const atEnd = el.scrollHeight - el.scrollTop - el.clientHeight < 48;
    followRef.current = atEnd;
    setFollowing(atEnd);
  };
  useLayoutEffect(() => {
    if (followRef.current) scrollToEnd();
  }, [rows]);

  const turns = groupTurns(rows, stamps);

  return (
    <aside className="cl-side-panel" aria-label="Transcript">
      <div className="cl-side-tabs">
        <span className="cl-side-tab active">
          Transcript<span className="cl-side-count" title={`${count} turns`}>{count}</span>
        </span>
        <button type="button" className="cl-side-close" onClick={onClose} title="Collapse panel" aria-label="Collapse panel">
          <CollapseIcon />
        </button>
      </div>

      <div className="cl-side-scroll">
        <div ref={bodyRef} className="cl-side-body" onScroll={onScroll}>
          {turns.length === 0 && <p className="cl-side-empty">The transcript will appear here as you and AVA talk.</p>}
          {turns.map((t) => (
            <div key={t.key} className={`cl-bubble-row ${t.role === "candidate" ? "me" : "them"}${t.role === "interviewer" ? " interviewer" : ""}`}>
              <span className="cl-bubble-meta">
                <b>{ROLE_LABEL[t.role] ?? t.role}</b>
                {t.stamp && <span className="cl-bubble-time">{t.stamp}</span>}
              </span>
              <div className="cl-bubble">
                {t.parts.map((p, i) => (
                  <span key={p.id} className={p.partial ? "cl-interim" : undefined}>
                    {i > 0 ? " " : ""}{p.text}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
        {!following && (
          <button type="button" className="cl-jump-latest" onClick={follow}>
            <ArrowDownIcon /> Jump to latest
          </button>
        )}
      </div>
    </aside>
  );
}

function CollapseIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <polyline points="13 17 18 12 13 7" /><polyline points="6 17 11 12 6 7" />
    </svg>
  );
}
function ArrowDownIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <line x1="12" y1="5" x2="12" y2="19" /><polyline points="19 12 12 19 5 12" />
    </svg>
  );
}

// Bottom-left candidate camera preview — display only (the camera is recorded
// by the engine; no live video leaves the browser).
function CamTile({
  stream, micLevel, muted, name, speaking,
}: { stream: MediaStream | null; micLevel: number; muted: boolean; name: string; speaking: boolean }) {
  const tileRef = useRef<HTMLDivElement>(null);
  const vref = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const v = vref.current;
    if (v && stream) { v.srcObject = stream; void v.play?.().catch(() => {}); }
  }, [stream]);

  return (
    <div ref={tileRef} className={`cl-tile${speaking ? " speaking-self" : ""}`}>
      {stream
        ? <video ref={vref} muted playsInline autoPlay />
        : <div className="cl-cam-off">Camera off</div>}
      {muted && <span className="cl-tile-label top"><MicIcon muted size={11} /> Muted</span>}
      <span className="cl-tile-label">{name} (you)</span>
      {!muted && <div className="cl-cam-mic-bar"><i style={{ width: `${micLevel}%` }} /></div>}
      <FullscreenButton target={tileRef} label="Fullscreen your camera" />
    </div>
  );
}

function FullscreenButton({ target, label }: { target: { current: HTMLElement | null }; label: string }) {
  const go = () => {
    const el = target.current as (HTMLElement & { webkitRequestFullscreen?: () => void }) | null;
    if (!el) return;
    if (el.requestFullscreen) void el.requestFullscreen().catch(() => {});
    else el.webkitRequestFullscreen?.();
  };
  return (
    <button type="button" className="cl-fs-btn" title={label} aria-label={label} onClick={(e) => { e.stopPropagation(); go(); }}>
      <FullscreenIcon />
    </button>
  );
}

// Tiny 5-bar level meter for the avatar name tag. Reads the same orbGlow level
// the orb uses (no new audio tap) once per frame and writes heights straight to
// the DOM, so audio-rate changes never re-render React.
function LevelMeter({ getLevel }: { getLevel: () => number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const levelRef = useRef(getLevel);
  levelRef.current = getLevel;
  useEffect(() => {
    const bars = Array.from(ref.current?.children ?? []) as HTMLElement[];
    const still = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let raf = 0;
    const draw = (t: number) => {
      const level = Math.max(0, Math.min(1, levelRef.current() || 0));
      const amp = 0.3 + 0.7 * Math.min(1, level * 1.6);
      bars.forEach((b, i) => {
        const wave = still ? 0.6 : 0.5 + 0.5 * Math.sin(t / 110 + i * 1.1);
        b.style.height = `${3 + 9 * amp * wave}px`;
      });
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);
  return (
    <span ref={ref} className="cl-level" aria-hidden="true">
      {[0, 1, 2, 3, 4].map((i) => <i key={i} />)}
    </span>
  );
}

// Settings popover — Blur, Volume AND device selection live here now (not
// just in the lobby): same engine.selectMic/selectCamera/toggleBlur/setVolume
// calls the lobby already uses, no engine changes needed, just a second place
// to reach them without a permanent top-bar control for each.
function SettingsPopover({ s, engine }: { s: ReturnType<CandidateEngine["getSnapshot"]>; engine: CandidateEngine }) {
  const [devices, setDevices] = useState<{ cameras: MediaDeviceInfo[]; mics: MediaDeviceInfo[] }>({ cameras: [], mics: [] });
  useEffect(() => {
    let alive = true;
    void listDevices().then((d) => { if (alive) setDevices({ cameras: d.cameras, mics: d.mics }); }).catch(() => {});
    return () => { alive = false; };
  }, []);

  return (
    <div className="cl-popover">
      {devices.mics.length > 1 && (
        <select className="cl-select" value={s.selectedMicId ?? ""} onChange={(e) => void engine.selectMic(e.target.value)}>
          <option value="">Default microphone</option>
          {devices.mics.map((m, i) => (<option key={m.deviceId} value={m.deviceId}>{m.label || `Microphone ${i + 1}`}</option>))}
        </select>
      )}
      {s.recordingEnabled && devices.cameras.length > 1 && (
        <select className="cl-select" value={s.selectedCamId ?? ""} onChange={(e) => void engine.selectCamera(e.target.value)}>
          <option value="">Default camera</option>
          {devices.cameras.map((c, i) => (<option key={c.deviceId} value={c.deviceId}>{c.label || `Camera ${i + 1}`}</option>))}
        </select>
      )}
      {s.recordingEnabled && (
        <div className="cl-toggle-row">
          <span>Blur background</span>
          <input type="checkbox" checked={s.bgBlurOn} onChange={() => void engine.toggleBlur()} />
        </div>
      )}
      <div className="cl-popover-row">
        <label className="cl-popover-label">Volume</label>
        <input type="range" min={1} max={3} step={0.1} defaultValue={2} onChange={(e) => engine.setVolume(parseFloat(e.target.value))} />
      </div>
    </div>
  );
}

function MicIcon({ muted, size = 19 }: { muted?: boolean; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 15a3 3 0 0 0 3-3V6a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3Z" />
      <path d="M19 11a7 7 0 0 1-14 0" /><line x1="12" y1="18" x2="12" y2="22" />
      {muted && <line x1="3" y1="3" x2="21" y2="21" />}
    </svg>
  );
}
function CamIcon({ on }: { on?: boolean }) {
  return (
    <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="6" width="14" height="12" rx="2" /><path d="M22 8.5 16 12l6 3.5v-7Z" />
      {!on && <line x1="2" y1="2" x2="22" y2="22" />}
    </svg>
  );
}
function TranscriptIcon() {
  return (
    <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M8 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-5-5h-2" />
      <path d="M13 3v5h5" />
      <line x1="7" y1="13" x2="15" y2="13" /><line x1="7" y1="17" x2="13" y2="17" />
    </svg>
  );
}
function GearIcon() {
  return (
    <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1Z" />
    </svg>
  );
}
function ScreenIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="4" width="20" height="13" rx="2" /><line x1="8" y1="21" x2="16" y2="21" /><line x1="12" y1="17" x2="12" y2="21" />
    </svg>
  );
}
function FullscreenIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M8 3H5a2 2 0 0 0-2 2v3" /><path d="M21 8V5a2 2 0 0 0-2-2h-3" /><path d="M3 16v3a2 2 0 0 0 2 2h3" /><path d="M16 21h3a2 2 0 0 0 2-2v-3" />
    </svg>
  );
}
function EndIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 9c-2.5 0-4.9.5-7 1.4a1.5 1.5 0 0 0-.9 1.6l.4 2.5a1.5 1.5 0 0 0 1.6 1.2c1-.1 2-.2 2.9-.2.5 0 .9-.3 1-.8l.3-1.4c1.1-.2 2.4-.2 3.4 0l.3 1.4c.1.5.5.8 1 .8.9 0 1.9.1 2.9.2a1.5 1.5 0 0 0 1.6-1.2l.4-2.5a1.5 1.5 0 0 0-.9-1.6C16.9 9.5 14.5 9 12 9Z" />
    </svg>
  );
}

// Visual stage: in avatar mode, boot TalkingHead into a container and register
// it as the engine's audio sink; fall back to the AiOrb if it can't boot (or
// in minimal mode). The orb shows until the avatar is ready — unchanged from
// before, just swapped from the old CSS .orb to the canvas AiOrb.
function Stage({
  engine,
  visualMode,
  mode,
  speaking,
}: {
  engine: CandidateEngine;
  visualMode: VisualMode;
  mode: OrbMode;
  speaking: boolean;
}) {
  const frameRef = useRef<HTMLDivElement>(null);
  const avatarRef = useRef<HTMLDivElement>(null);
  const [avatarReady, setAvatarReady] = useState(false);

  // getLevel: AI playback level while speaking, mic level while hearing —
  // both read from orbGlow.ts's existing smoothed levels (fed by
  // candidateEngine.ts's existing AnalyserNode taps), never a second tap.
  // "listening" (quiet rest) reacts to nothing — it just breathes.
  const getLevel = () => (mode === "speaking" ? readOrbLevel("ai") : mode === "hearing" ? readOrbLevel("mic") : 0);

  useEffect(() => {
    // "minimal" and any avatar that fails to boot both land on the orb — the
    // engine keeps its default sink and nothing else has to know.
    if (visualMode === "minimal" || !avatarRef.current) return;
    let alive = true;
    let sink: AvatarSink | null = null;

    // Both adapters honour the same contract and return null on failure, so the
    // success/failure handling below is identical for either.
    const boot =
      visualMode === "simli"
        ? bootSimli(avatarRef.current, engine.getSampleRate(), engine.getToken() || "")
        : bootAvatar(avatarRef.current, engine.getSampleRate(), undefined, CANDIDATE_AVATAR_CAMERA);

    void boot.then((s) => {
      if (!alive) {
        s?.dispose();
        return;
      }
      if (s) {
        sink = s;
        // WebSocket: PCM goes to the avatar to play. LiveKit: the avatar is fed
        // the live track for its face; the LiveKit element plays the voice.
        engine.setAudioSink(s.speak, s.stop, s.stream);
        setAvatarReady(true);
      }
      // null → keep the engine's default (minimal) sink + show the orb
    });
    return () => {
      alive = false;
      engine.setAudioSink(null, null);
      sink?.dispose();
      setAvatarReady(false);
    };
  }, [visualMode, engine]);

  // Both the frame and the fallback orb fill the same .cl-stage slot, so an
  // avatar that's still booting (or fails) swaps in place with no layout jump.
  return (
    <div className="cl-stage-inner">
      {visualMode !== "minimal" && (
        <div
          ref={frameRef}
          className={`cl-avatar-frame${speaking ? " speaking" : ""}`}
          style={avatarReady ? undefined : { display: "none" }}
        >
          <div ref={avatarRef} className="cl-avatar-canvas" />
          <span className="cl-avatar-tag">
            AVA <span className="muted">· AI interviewer</span>
            {speaking && <LevelMeter getLevel={getLevel} />}
          </span>
          <FullscreenButton target={frameRef} label="Fullscreen AVA" />
        </div>
      )}
      {!avatarReady && <AiOrb mode={mode} getLevel={getLevel} size={280} />}
    </div>
  );
}

function Done({ name, saving }: { name: string; saving: boolean }) {
  return (
    <div className="cl-root cl-page cl-notice-wrap screen-enter">
      <div className="cl-notice-card">
        <div className="cl-notice-icon success">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12" />
          </svg>
        </div>
        <h1 className="cl-notice-title">Thanks, {name}</h1>
        {saving ? (
          <p className="cl-notice-body" style={{ color: "var(--ds-warning)" }}>
            Saving your recording… please keep this tab open until it finishes.
          </p>
        ) : (
          <p className="cl-notice-body">Your interview is complete. You can close this window.</p>
        )}
      </div>
    </div>
  );
}
