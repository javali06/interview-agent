import { useEffect, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  useMatchResumes, useRemoveCandidate, useRole, useUpdateRole, type RoleCandidate,
} from "../lib/roles";
import { ROLE_STATE_META } from "../components/RoleStatesChart";
import { ApiError } from "../lib/api";
import { Icon } from "../components/Icon";
import { PageHeader } from "../components/PageHeader";
import { LoadingBlock } from "../components/LoadingBlock";
import "./RoleDetail.css";

export function RoleDetail() {
  const { roleId = "" } = useParams();
  const role = useRole(roleId);
  const update = useUpdateRole(roleId);
  const match = useMatchResumes(roleId);
  const removeCandidate = useRemoveCandidate(roleId);

  const [jd, setJd] = useState("");
  const [threshold, setThreshold] = useState(70);
  const [seeded, setSeeded] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (role.data && !seeded) {
      setJd(role.data.jd_text || "");
      setThreshold(role.data.threshold);
      setSeeded(true);
    }
  }, [role.data, seeded]);

  if (role.isLoading) return <div className="ds-light"><LoadingBlock label="Loading role…" /></div>;
  if (role.isError) {
    return (
      <div className="ds-light">
        <Link to="/shortlist" className="ds-back">← Back to roles</Link>
        <p style={{ marginTop: 16, fontSize: 14, color: "var(--danger)" }}>{(role.error as ApiError).message || "Failed to load."}</p>
      </div>
    );
  }
  const r = role.data!;
  // A closed role takes no new work — the server refuses it, so the UI must not
  // offer it. Reopening lifts both.
  const closed = r.status === "closed";
  const candidates = r.candidates || [];

  const runMatch = async () => {
    if (!files.length) return;
    setNotice(null);
    try {
      const res = await match.mutateAsync(files);
      setFiles([]);
      if (fileRef.current) fileRef.current.value = "";
      const errs = res.errors?.length ? ` ${res.errors.length} failed.` : "";
      setNotice(`Matched ${res.processed} resume${res.processed === 1 ? "" : "s"}.${errs}`);
    } catch (e) {
      setNotice(`Match failed: ${(e as ApiError).message}`);
    }
  };

  return (
    <div className="ds-light screen-enter">
      <PageHeader
        category="Shortlist"
        back={<Link to="/shortlist" className="ds-back">← Back to roles</Link>}
        title={<>
          {r.title}
          <span className="pill" style={{ marginLeft: 12, verticalAlign: "middle", fontSize: 11,
                                          display: "inline-flex", alignItems: "center", gap: 6 }}>
            <span aria-hidden style={{ width: 8, height: 8, borderRadius: 2,
                                       background: ROLE_STATE_META[r.state].color }} />
            {ROLE_STATE_META[r.state].label}
          </span>
        </>}
        actions={<>
          {/* Closing is a DECISION, not something derived from the interviews
              finishing: a role whose interviews are all done but where no offer
              is out is genuinely not closed. */}
          <button type="button" className="btn btn-sm" disabled={update.isPending}
                  onClick={() => update.mutate({ status: r.status === "closed" ? "open" : "closed" })}>
            {r.status === "closed" ? "Reopen role" : "Close role"}
          </button>
          {closed ? (
            <span className="btn btn-primary" aria-disabled="true"
                  title="Reopen this role to set up interviews"
                  style={{ pointerEvents: "none" }}>
              Set up interviews <Icon name="arrow" className="ico" />
            </span>
          ) : (
            <Link to={`/shortlist/${roleId}/interview`} className="btn btn-primary">
              Set up interviews <Icon name="arrow" className="ico" />
            </Link>
          )}
        </>}
      />

      <div style={{ display: "grid", gap: 16, gridTemplateColumns: "repeat(auto-fit, minmax(min(320px, 100%), 1fr))" }}>
        {/* JD + threshold */}
        <section className="card" style={{ padding: 20 }}>
          <h2 style={{ fontWeight: 600, fontSize: 15.5 }}>Job description &amp; threshold</h2>
          <textarea
            value={jd}
            onChange={(e) => setJd(e.target.value)}
            rows={8}
            placeholder="Paste the job description here…"
            className="input"
            style={{ marginTop: 14 }}
          />
          <div style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 12 }}>
            <label className="muted" style={{ fontSize: 13.5 }}>Threshold</label>
            <input
              type="number"
              min={0}
              max={100}
              value={threshold}
              onChange={(e) => setThreshold(Number(e.target.value))}
              className="input"
              style={{ width: 84 }}
            />
            <button type="button" disabled={update.isPending} onClick={() => update.mutate({ jd_text: jd, threshold })} className="btn btn-sm" style={{ marginLeft: "auto" }}>
              {update.isPending ? "Saving…" : "Save"}
            </button>
          </div>
        </section>

        {/* Resume upload + match */}
        <section className="card" style={{ padding: 20 }}>
          <h2 style={{ fontWeight: 600, fontSize: 15.5 }}>Resumes</h2>
          <div style={{ marginTop: 14, display: "flex", flexWrap: "wrap", gap: 8 }}>
            <button type="button" disabled={closed} onClick={() => fileRef.current?.click()} className="btn btn-sm">
              <Icon name="upload" className="ico" /> Choose files (local)
            </button>
            <button
              type="button"
              onClick={() => setNotice("SharePoint connector is coming soon — use local upload for now.")}
              className="btn btn-ghost btn-sm"
            >
              Connect SharePoint
            </button>
            <input
              ref={fileRef}
              type="file"
              multiple
              accept=".pdf,.docx,.txt,.md"
              style={{ display: "none" }}
              onChange={(e) => setFiles(Array.from(e.target.files || []))}
            />
          </div>
          <p className="muted-3" style={{ marginTop: 10, fontSize: 13 }}>
            {files.length ? `${files.length} file${files.length === 1 ? "" : "s"} ready` : "no files selected"}
          </p>
          <button type="button" disabled={closed || !files.length || match.isPending} onClick={runMatch} className="btn btn-primary" style={{ marginTop: 14 }}>
            {match.isPending ? "Matching… (LLM)" : "Match & rank"}
          </button>
          {closed && (
            <p className="muted-3" style={{ marginTop: 10, fontSize: 13 }}>
              This role is closed — reopen it to match more resumes.
            </p>
          )}
          {notice && <p className="muted" style={{ marginTop: 10, fontSize: 13.5 }}>{notice}</p>}

        </section>
      </div>

      {/* Ranked candidates */}
      <section style={{ marginTop: 24 }}>
        <h2 style={{ fontWeight: 600, fontSize: 15.5 }}>
          Ranked candidates {candidates.length > 0 && <span className="muted-3">({candidates.length})</span>}
        </h2>
        {candidates.length === 0 ? (
          <p className="muted-3" style={{ marginTop: 8, fontSize: 14 }}>No matches yet — upload resumes and run Match &amp; rank.</p>
        ) : (
          <div className="card" style={{ marginTop: 10, overflowX: "auto", padding: 0 }}>
            <table className="ui-table" style={{ minWidth: 560 }}>
              <thead>
                <tr>
                  <th>Candidate</th>
                  <th>Recommendation</th>
                  <th style={{ textAlign: "right" }}>Score</th>
                  <th style={{ width: 1 }}></th>
                </tr>
              </thead>
              <tbody>
                {candidates.map((c) => (
                  <CandidateRow key={c.candidate_public_id} c={c}
                                onRemove={() => removeCandidate.mutateAsync(c.candidate_public_id)} />
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}

function CandidateRow({ c, onRemove }: { c: RoleCandidate; onRemove: () => Promise<unknown> }) {
  // Drill-down is collapsed by default — the operator scans the ranked list,
  // then expands a single candidate to inspect how the score was reached.
  const [open, setOpen] = useState(false);
  const [removing, setRemoving] = useState(false);
  return (
    <>
      <tr
        className="score-row"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
      >
        <td>
          <div style={{ fontWeight: 600 }}>
            <span className={`score-caret ${open ? "open" : ""}`}>▶</span> {c.name}
          </div>
          {c.email && <div className="muted-3" style={{ fontSize: 12, paddingLeft: 22 }}>{c.email}</div>}
        </td>
        <td className="muted">{c.recommendation || "—"}</td>
        <td style={{ textAlign: "right" }}>
          <span className={`pill ${c.above_threshold ? "ok" : "warn"}`}>
            {c.final_score}
            {c.above_threshold ? " · fit" : " · below"}
          </span>
        </td>
        {/* Removing takes the candidate off THIS role only — their resume,
            their other roles and any interview already created survive. The
            row click toggles the drill-down, so this must not bubble. */}
        <td style={{ textAlign: "right" }} onClick={(e) => e.stopPropagation()}>
          <button
            type="button" className="btn btn-ghost btn-sm" disabled={removing}
            title="Remove this candidate from this role"
            onClick={() => {
              if (!window.confirm(
                `Remove ${c.name} from this role?\n\nTheir resume and any interview already created are kept.`
              )) return;
              setRemoving(true);
              void onRemove().catch(() => setRemoving(false));
            }}>
            {removing ? "Removing…" : "Remove"}
          </button>
        </td>
      </tr>
      {open && (
        <tr>
          {/* full-width detail panel; table has 3 columns */}
          <td colSpan={4} className="score-detail-cell">
            <ScoreDetail c={c} />
          </td>
        </tr>
      )}
    </>
  );
}

// Score breakdown for one candidate. Surfaces ONLY the fields the match/role
// response actually returns (see lib/roles.ts RoleCandidate). The backend also
// persists richer detail (strengths/gaps, matched/missing skills, per-dimension
// rationales) on the Score row, but list_candidates_for_role does not expose
// it — surfacing those would require a backend change.
function ScoreDetail({ c }: { c: RoleCandidate }) {
  const bars = [
    { label: "Final score", value: c.final_score, cls: c.above_threshold ? "ok" : "warn" },
    { label: "LLM (semantic)", value: c.llm_score, cls: "" },
    { label: "Skill coverage", value: c.coverage_score, cls: "" },
  ];
  return (
    <div className="score-detail">
      <div className="score-bars">
        {bars.map((b) => (
          <div key={b.label} className="score-bar-row">
            <span className="score-bar-label">{b.label}</span>
            <span className="score-bar-track">
              {/* scores are 0–100, so the percentage is the value itself */}
              <span
                className={`score-bar-fill ${b.cls}`}
                style={{ width: `${Math.max(0, Math.min(100, b.value))}%` }}
              />
            </span>
            <span className="score-bar-value">{b.value}</span>
          </div>
        ))}
      </div>

      <div className="score-meta">
        <div className="score-meta-item">
          <span className="score-meta-k">Recommendation</span>
          <span className="score-meta-v">{c.recommendation || "—"}</span>
        </div>
        <div className="score-meta-item">
          <span className="score-meta-k">Threshold</span>
          <span className="score-meta-v">
            <span className={`pill ${c.above_threshold ? "ok" : "warn"}`}>
              {c.above_threshold ? "Above threshold" : "Below threshold"}
            </span>
          </span>
        </div>
        <div className="score-meta-item">
          <span className="score-meta-k">Resume on file</span>
          <span className="score-meta-v">{c.has_resume ? "Yes" : "No"}</span>
        </div>
        {c.source && (
          <div className="score-meta-item">
            <span className="score-meta-k">Source</span>
            <span className="score-meta-v" title={c.source} style={{ wordBreak: "break-all" }}>{c.source}</span>
          </div>
        )}
      </div>
    </div>
  );
}
