// Question pool editor — create or edit a bank of interview questions by hand.
// NO LLM: every question is typed or pasted.
//
// Deliberately plain-language throughout, because a pool is just as useful for a
// support or nursing role as an engineering one. The stored fields are the same
// ones the runtime already uses; only the LABELS are friendly:
//   topic          → "Category"
//   difficulty     → "Level"
//   coverage_tags  → "What a good answer should mention"
// That last one is not decoration: the verifier checks the candidate's answer
// against each point and the interviewer probes only the ones still missing.
import { useCallback, useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { PageHeader } from "../components/PageHeader";
import { LoadingBlock } from "../components/LoadingBlock";
import { useNavigate, useParams } from "react-router-dom";
import { Icon } from "../components/Icon";
import { PoolWorkflow } from "../components/PoolWorkflow";
import { useToast } from "../components/Toaster";
import { ApiError } from "../lib/api";
import { can, teamsFor, usePermissions } from "../lib/auth";
import {
  blankQuestion, countsFor, createPool, DIFFICULTIES, getPool, poolReview,
  type QuestionReview,
  listKinds, normaliseTopic, parseBulk, poolAssetUrl, showsAnswerPoints,
  showsTopicAndPoints, SPOKEN_KIND, updatePool, uploadPoolAsset, validatePool,
  type CodingTestCase, type Difficulty, type PoolKind, type PoolQuestion,
  type ScenarioMedia,
} from "../lib/questionPools";

// The answer points for one question — "what a good answer should mention".
// Each point is its own plain text row with Add / Remove buttons, mirroring how
// QUESTIONS themselves are added on this page, so there is one interaction model
// to learn and no hidden "press Enter to commit" step.
//
// Each row is an INDEPENDENT input bound to its own array slot. That matters:
// the first version was a single comma-separated box whose value was re-derived
// from the array on every keystroke, so typing "a; " round-tripped back to "a"
// and erased the separator and space as they were typed. Here the text a user
// types is exactly what is stored — spaces, punctuation and all.
//
// Blank rows are kept while editing (so a freshly added row doesn't vanish
// under the cursor) and dropped at save; see onSave.
function AnswerPoints({
  inputId, points, onChange,
}: {
  inputId: string;
  points: string[];
  onChange: (points: string[]) => void;
}) {
  const rows = points.length ? points : [""];
  const set = (n: number, value: string) =>
    onChange(rows.map((p, i) => (i === n ? value : p)));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {rows.map((point, n) => (
        <div key={n} style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <span
            className="muted-3"
            style={{ fontSize: 11.5, fontFamily: "var(--mono)", width: 16, flexShrink: 0, textAlign: "right" }}
          >
            {n + 1}
          </span>
          <input
            id={n === 0 ? inputId : undefined}
            className="input"
            style={{ flex: 1, minWidth: 0 }}
            value={point}
            placeholder="e.g. acknowledges the customer's frustration"
            onChange={(e) => set(n, e.target.value)}
          />
          <button
            type="button"
            className="btn btn-ghost btn-sm"
            style={{ flexShrink: 0 }}
            disabled={rows.length <= 1 && !point.trim()}
            title="Remove this point"
            onClick={() => {
              const next = rows.filter((_, i) => i !== n);
              onChange(next.length ? next : [""]);
            }}
          >
            Remove
          </button>
        </div>
      ))}
      <button
        type="button"
        className="btn btn-ghost btn-sm"
        style={{ alignSelf: "flex-start" }}
        onClick={() => onChange([...rows, ""])}
      >
        <Icon name="plus" className="ico" style={{ width: 14, height: 14 }} /> Add point
      </button>
    </div>
  );
}

// "+ Add question" opens this: pick the KIND first, because it decides which
// fields the question even has. Rendered from the backend catalog, so a new
// question type (MCQ, say) appears here with no change to this file.
function KindPicker({
  kinds, onPick, onCancel,
}: {
  kinds: PoolKind[];
  onPick: (k: PoolKind) => void;
  onCancel: () => void;
}) {
  const list = kinds.length ? kinds : [];
  return createPortal(
    <div
      role="dialog" aria-modal="true"
      className="ds-light"
      onClick={onCancel}
      style={{
        position: "fixed", inset: 0, zIndex: 60, display: "grid",
        placeItems: "center", background: "rgba(22,22,22,0.35)",
        backdropFilter: "blur(4px)", padding: 16,
      }}
    >
      <div className="card" onClick={(e) => e.stopPropagation()}
           style={{ width: "min(520px, 100%)", padding: 22, background: "var(--panel)", boxShadow: "var(--ds-shadow)" }}>
        <h2 style={{ fontSize: 18, fontWeight: 600, margin: 0 }}>What kind of question?</h2>
        <p className="muted" style={{ fontSize: 13, margin: "6px 0 14px" }}>
          A pool can mix kinds — each question keeps its own.
        </p>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, maxHeight: "50vh", overflowY: "auto" }}>
          {list.length === 0 && <p className="muted-3" style={{ fontSize: 13 }}>Loading question types…</p>}
          {list.map((k) => (
            <button key={k.id} type="button" className="card"
                    onClick={() => onPick(k)}
                    style={{ textAlign: "left", padding: "12px 14px", cursor: "pointer",
                             background: "var(--panel)", border: "1px solid var(--line)" }}>
              <div style={{ fontSize: 14, fontWeight: 700 }}>{k.label}</div>
              <div className="muted" style={{ fontSize: 12.5, marginTop: 3 }}>{k.description}</div>
            </button>
          ))}
        </div>
        <button type="button" className="btn btn-ghost" style={{ marginTop: 14 }} onClick={onCancel}>
          Cancel
        </button>
      </div>
    </div>,
    document.body,
  );
}

// Test cases for a coding question — the thing that actually grades the answer.
// A repeating row of (name, input, expected), mirroring the "+ Add" pattern used
// everywhere else on this page so there is one interaction model to learn.
function TestCaseRows({
  rows, onChange,
}: {
  rows: CodingTestCase[];
  onChange: (rows: CodingTestCase[]) => void;
}) {
  const list = rows.length ? rows : [{ name: "", input: "", expected: "" }];
  const set = (n: number, patch: Partial<CodingTestCase>) =>
    onChange(list.map((r, i) => (i === n ? { ...r, ...patch } : r)));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      {list.map((row, n) => (
        <div key={n} className="card"
             style={{ padding: 10, display: "flex", flexDirection: "column", gap: 8,
                      background: "var(--panel)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span className="muted-3" style={{ fontSize: 11.5, fontFamily: "var(--mono)" }}>
              Test {n + 1}
            </span>
            <input
              className="input" style={{ flex: 1, minWidth: 0, fontSize: 12.5 }}
              value={row.name} placeholder="what this checks (optional), e.g. empty list"
              onChange={(e) => set(n, { name: e.target.value })}
            />
            <button type="button" className="btn btn-ghost btn-sm" style={{ flexShrink: 0 }}
                    title="Remove this test case"
                    onClick={() => {
                      const next = list.filter((_, i) => i !== n);
                      onChange(next.length ? next : [{ name: "", input: "", expected: "" }]);
                    }}>
              Remove
            </button>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <div style={{ flex: "1 1 220px" }}>
              <label className="lbl" style={{ fontSize: 11.5 }}>Input (arguments)</label>
              <input className="input" style={{ width: "100%", fontFamily: "var(--mono)", fontSize: 12.5 }}
                     value={row.input} placeholder="[1, 2, 3]"
                     onChange={(e) => set(n, { input: e.target.value })} />
            </div>
            <div style={{ flex: "1 1 220px" }}>
              <label className="lbl" style={{ fontSize: 11.5 }}>Expected result</label>
              <input className="input" style={{ width: "100%", fontFamily: "var(--mono)", fontSize: 12.5 }}
                     value={row.expected} placeholder="[1, 3, 6]"
                     onChange={(e) => set(n, { expected: e.target.value })} />
            </div>
          </div>
        </div>
      ))}
      <button type="button" className="btn btn-ghost btn-sm" style={{ alignSelf: "flex-start" }}
              onClick={() => onChange([...list, { name: "", input: "", expected: "" }])}>
        <Icon name="plus" className="ico" style={{ width: 14, height: 14 }} /> Add test case
      </button>
    </div>
  );
}

// One material field for a written question — a passage, a language, or an
// uploaded clip/image. Which fields exist comes from the backend catalog, so
// this switch is on the field's RENDER KIND, not on the question type: a new
// question type made of existing kinds needs no change here at all.
// Infer the media kind from the browser-reported MIME type, falling back to
// the extension — mirrors ScenarioPhaseModal.tsx's inferMediaKind, duplicated
// locally rather than shared, the same way that file keeps its own FsButton.
// `.webm` is deliberately NOT video here (claimed by the audio rule — see
// engine/brain/cadence/question_types.py ASSET_RULES["video"]'s comment).
function inferMediaKind(file: File): "image" | "video" | "audio" | null {
  const type = (file.type || "").split("/")[0];
  if (type === "image" || type === "video" || type === "audio") return type;
  const name = file.name.toLowerCase();
  if (/\.(png|jpe?g|webp|gif)$/.test(name)) return "image";
  if (/\.(mp4|mov|m4v)$/.test(name)) return "video";
  if (/\.(mp3|wav|m4a|ogg|oga|webm|flac)$/.test(name)) return "audio";
  return null;
}

function MaterialField({
  field, languages, value, onChange,
}: {
  field: PoolKind["fields"][number];
  languages: { code: string; label: string }[];
  /** Whatever this field stores — a string, a string[], or a test-case list.
   *  Generic so a new field kind needs no new prop. */
  value: unknown;
  onChange: (v: unknown) => void;
}) {
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const str = typeof value === "string" ? value : "";
  const label = (
    <label className="lbl">
      {field.label}{!(field.ui_required ?? field.required) && <span className="muted-3"> (optional)</span>}
    </label>
  );
  const help = field.help
    ? <p className="muted-3" style={{ fontSize: 11.5, margin: "6px 0 0" }}>{field.help}</p>
    : null;

  if (field.kind === "language") {
    return (
      <div>
        {label}
        <select className="input" style={{ width: "100%" }} value={str}
                onChange={(e) => onChange(e.target.value)}>
          <option value="">Select a language…</option>
          {languages.map((l) => <option key={l.code} value={l.code}>{l.label}</option>)}
        </select>
        {help}
      </div>
    );
  }

  if (field.kind === "code") {
    // A plain monospace textarea, deliberately not Monaco: this is the AUTHORING
    // screen, and pulling the editor in here would load megabytes for a box the
    // admin types ten lines into. The candidate still gets full Monaco.
    return (
      <div>
        {label}
        <textarea
          className="input" rows={6} spellCheck={false}
          style={{ width: "100%", fontFamily: "var(--mono)", fontSize: 12.5,
                   whiteSpace: "pre", overflowWrap: "normal", overflowX: "auto" }}
          value={str}
          placeholder={field.name === "solution"
            ? "def two_sum(nums, target):\n    ..."
            : "def two_sum(nums, target):\n    # your code here\n    pass"}
          onChange={(e) => onChange(e.target.value)}
        />
        {help}
      </div>
    );
  }

  if (field.kind === "chips") {
    // A curated vocabulary rendered as toggles — the backend REFUSES an
    // off-list value, so free text would only invite a rejected save. These
    // also drive the coding picker's filters, which is why they're multi-select.
    const picked = Array.isArray(value) ? (value as string[]) : [];
    const toggle = (opt: string) =>
      onChange(picked.includes(opt)
        ? picked.filter((x) => x !== opt)
        : [...picked, opt]);
    return (
      <div>
        {label}
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          {(field.options ?? []).map((opt) => (
            <button
              key={opt} type="button"
              className={`chip ${picked.includes(opt) ? "on" : ""}`}
              onClick={() => toggle(opt)}
            >
              {opt}
            </button>
          ))}
        </div>
        {help}
      </div>
    );
  }

  if (field.kind === "duration") {
    // Stored in SECONDS (the library's unit), edited in MINUTES — nobody
    // reasons about a coding budget in seconds.
    const secs = Number(value) || 0;
    return (
      <div>
        {label}
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <input
            type="number" min={0} className="input" style={{ width: 110 }}
            value={secs ? String(Math.round(secs / 60)) : ""}
            placeholder="default"
            onChange={(e) => {
              const mins = Number(e.target.value);
              onChange(mins > 0 ? Math.round(mins) * 60 : 0);
            }}
          />
          <span className="muted-3" style={{ fontSize: 12.5 }}>minutes</span>
        </div>
        {help}
      </div>
    );
  }

  if (field.kind === "test_cases") {
    const rows = Array.isArray(value) ? (value as CodingTestCase[]) : [];
    return (
      <div>
        {label}
        <TestCaseRows rows={rows} onChange={(r) => onChange(r)} />
        {help}
      </div>
    );
  }

  if (field.kind === "asset_audio" || field.kind === "asset_image") {
    const assetKind = field.asset_kind ?? (field.kind === "asset_audio" ? "audio" : "image");
    return (
      <div>
        {label}
        {/* Always available — assets are stored independently of the pool, so a
            file can be attached while the pool is still being composed (this
            used to appear only after a first save, which read as "no upload"). */}
        <input
          type="file" className="input" style={{ width: "100%" }} disabled={busy}
          accept={assetKind === "audio" ? "audio/*" : "image/*"}
          onChange={async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            setBusy(true);
            try {
              const up = await uploadPoolAsset(assetKind, file);
              onChange(up.name);
              toast.success(`Uploaded ${file.name}.`);
            } catch (err) {
              toast.error((err as Error).message || "Upload failed.");
            } finally { setBusy(false); }
          }}
        />
        {busy && <p className="muted-3" style={{ fontSize: 12, margin: "6px 0 0" }}>Uploading…</p>}
        {/* Preview it, so the author can confirm the RIGHT file landed — the
            same reassurance the Add Phase form gives. */}
        {str && !busy && (
          <div style={{ marginTop: 8 }}>
            <p className="muted-3" style={{ fontSize: 11.5, margin: "0 0 6px" }}>
              Uploaded: <span style={{ fontFamily: "var(--mono)" }}>{str}</span>
            </p>
            {assetKind === "audio" ? (
              <audio controls src={poolAssetUrl(str)} style={{ width: "100%" }} />
            ) : (
              <img
                src={poolAssetUrl(str)} alt=""
                style={{ maxWidth: 220, maxHeight: 160, borderRadius: 8,
                         border: "1px solid var(--line)" }}
              />
            )}
          </div>
        )}
      </div>
    );
  }

  if (field.kind === "count") {
    // A small bounded number (the scenario follow-up cap) — unlike "duration"
    // this is not a seconds-to-minutes conversion, just a plain integer.
    const n = Number(value);
    return (
      <div>
        {label}
        <input
          type="number" min={0} max={5} className="input" style={{ width: 90 }}
          value={Number.isFinite(n) && value !== "" && value != null ? String(n) : ""}
          placeholder="2"
          onChange={(e) => {
            const v = e.target.value;
            onChange(v === "" ? undefined : Math.max(0, Math.min(5, Math.round(Number(v)))));
          }}
        />
        {help}
      </div>
    );
  }

  if (field.kind === "asset_media") {
    // One upload control for all three scenario media kinds — the kind is
    // INFERRED from the file, same as ScenarioPhaseModal.tsx's upload flow,
    // rather than asking the admin to pick a kind up front.
    const media = (value && typeof value === "object" ? value : null) as ScenarioMedia | null;
    return (
      <div>
        {label}
        <input
          type="file" className="input" style={{ width: "100%" }} disabled={busy}
          accept="image/*,video/*,audio/*"
          onChange={async (e) => {
            const file = e.target.files?.[0];
            if (!file) return;
            const kind = inferMediaKind(file);
            if (kind === "video" && file.name.toLowerCase().endsWith(".webm")) {
              toast.error("Video must be .mp4, .mov, or .m4v — convert this .webm file first.");
              return;
            }
            if (!kind) {
              toast.error("Unrecognized file type — use an image, video, or audio file.");
              return;
            }
            setBusy(true);
            try {
              const up = await uploadPoolAsset(kind, file);
              onChange({
                kind, ref: up.name, filename: file.name,
                mime_type: file.type || `${kind}/octet-stream`,
              } as ScenarioMedia);
              toast.success(`Uploaded ${file.name}.`);
            } catch (err) {
              toast.error((err as Error).message || "Upload failed.");
            } finally { setBusy(false); }
          }}
        />
        {busy && <p className="muted-3" style={{ fontSize: 12, margin: "6px 0 0" }}>Uploading…</p>}
        {media?.ref && !busy && (
          <div style={{ marginTop: 8 }}>
            <p className="muted-3" style={{ fontSize: 11.5, margin: "0 0 6px" }}>
              Uploaded: <span style={{ fontFamily: "var(--mono)" }}>{media.filename || media.ref}</span>
              {" "}({media.kind})
            </p>
            {media.kind === "audio" && (
              <audio controls src={poolAssetUrl(media.ref)} style={{ width: "100%" }} />
            )}
            {media.kind === "image" && (
              <img
                src={poolAssetUrl(media.ref)} alt=""
                style={{ maxWidth: 220, maxHeight: 160, borderRadius: 8,
                         border: "1px solid var(--line)" }}
              />
            )}
            {media.kind === "video" && (
              <video
                controls src={poolAssetUrl(media.ref)}
                style={{ maxWidth: 320, maxHeight: 200, borderRadius: 8,
                         border: "1px solid var(--line)" }}
              />
            )}
          </div>
        )}
        {help}
      </div>
    );
  }

  if (field.kind === "string_list") {
    // A repeating row list, mirroring Add Phase's "+ Add entry". Falling
    // through to a plain text box here stored a STRING where the schema
    // requires a list, and the pool then failed to load with a pydantic error
    // the author had no way to act on.
    const listValue = Array.isArray(value) ? (value as string[]) : [];
    const rows = listValue.length ? listValue : [""];
    const setRow = (n: number, v: string) =>
      onChange(rows.map((x, i) => (i === n ? v : x)));
    return (
      <div>
        {label}
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {rows.map((row, n) => (
            <div key={n} style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <span className="muted-3" style={{ fontSize: 11.5, fontFamily: "var(--mono)", width: 16, textAlign: "right" }}>{n + 1}</span>
              <input className="input" style={{ flex: 1, minWidth: 0 }} value={row}
                     placeholder={field.help}
                     onChange={(e) => setRow(n, e.target.value)} />
              <button type="button" className="btn btn-ghost btn-sm" style={{ flexShrink: 0 }}
                      disabled={rows.length <= 1 && !row.trim()}
                      onClick={() => {
                        const next = rows.filter((_, i) => i !== n);
                        onChange(next.length ? next : [""]);
                      }}>
                Remove
              </button>
            </div>
          ))}
        </div>
        <button type="button" className="btn btn-ghost btn-sm" style={{ marginTop: 8 }}
                onClick={() => onChange([...rows, ""])}>
          <Icon name="plus" className="ico" style={{ width: 14, height: 14 }} /> Add entry
        </button>
        {help}
      </div>
    );
  }

  const Tag = field.kind === "long_text" ? "textarea" : "input";
  return (
    <div>
      {label}
      <Tag
        className="input"
        style={{ width: "100%" }}
        {...(field.kind === "long_text" ? { rows: 3 } : {})}
        value={str}
        placeholder={field.help}
        onChange={(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => onChange(e.target.value)}
      />
      {field.kind === "long_text" && help}
    </div>
  );
}

// A stable palette cycled by kind, so the same kind keeps the same colour as
// the mix of questions changes while editing.
const KIND_COLORS = ["#6366f1", "#ec4899", "#22c55e", "#f59e0b", "#06b6d4", "#a855f7", "#ef4444", "#84cc16"];

// How many of each KIND this pool holds, as a small pie + legend. Shown
// regardless of whether the coverage matrix below applies — a pool of only
// written questions still deserves to show what it actually contains.
function QuestionTypeBreakdown({
  questions, kinds,
}: {
  questions: PoolQuestion[];
  kinds: PoolKind[];
}) {
  const counts = useMemo(() => {
    const out: Record<string, number> = {};
    for (const q of questions) {
      const k = q.kind || SPOKEN_KIND;
      out[k] = (out[k] ?? 0) + 1;
    }
    return out;
  }, [questions]);
  const entries = Object.entries(counts);
  const total = questions.length;
  if (!total) return null;

  const labelOf = (id: string) =>
    kinds.find((k) => k.id === id)?.label ?? (id === SPOKEN_KIND ? "Specific question" : id);

  let acc = 0;
  const stops = entries.map(([, n], i) => {
    const start = acc;
    acc += (n / total) * 100;
    return `${KIND_COLORS[i % KIND_COLORS.length]} ${start}% ${acc}%`;
  });

  return (
    <div className="card" style={{ padding: 14 }}>
      <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>
        Question types
        <span className="muted-3" style={{ fontWeight: 500 }}>
          {" "}· {total} question{total === 1 ? "" : "s"}
        </span>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 18, flexWrap: "wrap" }}>
        <div
          aria-hidden
          style={{
            width: 84, height: 84, borderRadius: "50%", flexShrink: 0,
            background: entries.length > 1
              ? `conic-gradient(${stops.join(", ")})`
              : KIND_COLORS[0],
          }}
        />
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {entries.map(([id, n], i) => (
            <div key={id} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12.5 }}>
              <span style={{
                width: 10, height: 10, borderRadius: 3, flexShrink: 0,
                background: KIND_COLORS[i % KIND_COLORS.length],
              }} />
              <span>{labelOf(id)}</span>
              <span className="muted-3">· {n}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const STARTERS: { label: string; topic: string; hint: string }[] = [
  { label: "Customer support", topic: "de_escalation", hint: "An angry customer calls about a late delivery. How do you open the conversation?" },
  { label: "Sales", topic: "discovery", hint: "How do you find out what a prospect actually needs before pitching?" },
  { label: "Healthcare", topic: "patient_care", hint: "Describe how you'd explain a treatment plan to an anxious patient." },
  { label: "Engineering", topic: "debugging", hint: "Walk me through how you diagnosed a hard production bug." },
];

export function QuestionPoolEditor() {
  const { poolId } = useParams();
  const isNew = !poolId || poolId === "new";
  const nav = useNavigate();
  const toast = useToast();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  // Which team owns the pool, and therefore who reviews it. Offered from the
  // teams this person may actually author for, so the form cannot produce a
  // pool the server would then refuse.
  const [team, setTeam] = useState("");
  // The team the pool belongs to ON THE SERVER ("*" = every team). Kept apart
  // from `team`, which the picker changes: who may edit, and whose chain the
  // workflow bar shows, follows the saved owner, not an unsaved selection.
  const [ownerTeam, setOwnerTeam] = useState("*");
  // Whether a draft file exists behind this pool (what Submit would send).
  const [hasDraft, setHasDraft] = useState(false);
  // `isPending` matters as much as the data: until the permissions arrive,
  // `can()` answers "no" for EVERYONE, and the form below is locked by a single
  // fieldset. Treating "not known yet" as "denied" would lock an author out of
  // their own pool for the length of the request — and leave them looking at a
  // read-only banner that is simply untrue.
  const { data: me, isPending: permsPending } = usePermissions();
  const myTeams = teamsFor(me, "pools.edit");
  // Joined, so the effect below depends on the CONTENTS rather than on a new
  // array identity every render.
  const myTeamsKey = myTeams.join(",");
  // A checker opens this page to READ a pool before approving it, so the page
  // has to work in two modes. Scoped to the pool's own team: authoring for
  // `backend` says nothing about a `qa` pool. A new pool needs only the
  // permission somewhere, since the team picker then constrains the rest.
  // Set once the pool loads; a built-in is readable by anyone with pools.view
  // but writable by nobody, regardless of permission.
  const [isBuiltin, setIsBuiltin] = useState(false);
  // The checker's per-question verdicts from the last review, so a returned
  // pool tells the author exactly which questions to fix and why.
  const [reviews, setReviews] = useState<Record<string, QuestionReview>>({});
  const mayEdit = isNew
    ? myTeams.length > 0
    : !isBuiltin && can(me, "pools.edit", ownerTeam);
  // Starts EMPTY: a seeded card would silently pick "spoken" for the author,
  // and the first question deserves the same type picker as every other one.
  const [questions, setQuestions] = useState<PoolQuestion[]>([]);
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);
  const [bulk, setBulk] = useState("");
  const [showBulk, setShowBulk] = useState(false);
  // The catalog drives the whole form. Fetched, not hardcoded: a new question
  // type added in question_types.py appears here with no change to this file.
  const [kinds, setKinds] = useState<PoolKind[]>([]);
  const [languages, setLanguages] = useState<{ code: string; label: string }[]>([]);
  // "+ Add question" opens this picker so each question chooses its OWN kind.
  const [picking, setPicking] = useState(false);

  // Pick the first team the author may write for, rather than leaving the state
  // empty. A <select> with value="" and no matching <option> DISPLAYS its first
  // option while reporting nothing — so the form showed "backend", sent blank,
  // the server read blank as "every team", and refused an author who may only
  // write for one. Never let a control show one thing and report another.
  // NEW pools only: on an existing all-teams pool this silently moved it into
  // the author's own team on the next Save.
  useEffect(() => {
    if (isNew && !team && myTeamsKey && !myTeamsKey.split(",").includes("*")) {
      setTeam(myTeamsKey.split(",")[0]);
    }
  }, [isNew, team, myTeamsKey]);
  const kindOf = useCallback(
    (q: PoolQuestion) => kinds.find((k) => k.id === (q.kind || SPOKEN_KIND)) ?? null,
    [kinds],
  );

  useEffect(() => {
    let alive = true;
    void listKinds()
      .then((c) => { if (alive) { setKinds(c.kinds); setLanguages(c.languages); } })
      .catch(() => { /* the form still works for spoken pools */ });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (isNew) return;
    let alive = true;
    void getPool(poolId!)
      .then((p) => {
        if (!alive) return;
        setName(p.pool_name);
        setDescription(p.description);
        setTeam(p.team && p.team !== "*" ? p.team : "");
        setOwnerTeam(p.team || "*");
        setHasDraft(p.state === "draft");
        setQuestions(p.questions);
        // A shipped pool lives in the image, so there is nothing to save to —
        // the way to change one is Duplicate. Without this an admin (who holds
        // pools.edit everywhere) is shown a Save button that cannot work.
        setIsBuiltin(p.source === "builtin");
      })
      .then(() =>
        // Best-effort: feedback is an aid, so a pool that has never been
        // reviewed (or a request that fails) must not stop it loading.
        poolReview(poolId!)
          .then((r) => { if (alive) setReviews(r.reviews || {}); })
          .catch(() => {}),
      )
      .catch((e) => toast.error((e as ApiError).message || "Could not load this pool."))
      .finally(() => alive && setLoading(false));
    return () => { alive = false; };
    // `toast` is deliberately NOT a dependency: it is only used on the error
    // path, and depending on it made this effect re-run every render — the
    // refetch then clobbered whatever the admin had just typed or added.
    // (useToast is memoised now too; this keeps the effect correct regardless.)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isNew, poolId]);

  const patch = useCallback((i: number, p: Partial<PoolQuestion>) => {
    setQuestions((prev) => prev.map((q, n) => (n === i ? { ...q, ...p } : q)));
  }, []);

  const problems = validatePool(name, questions, kinds);
  // The coverage matrix is what the cadence customizer filters SPECIFIC
  // (spoken) questions by — a written question always carries topic="",
  // difficulty="medium", so counting it in here would show a fake "medium"
  // column for a pool that has no spoken questions at all.
  const specificQuestions = useMemo(
    () => questions.filter((q) => (q.kind || SPOKEN_KIND) === SPOKEN_KIND),
    [questions],
  );
  const counts = useMemo(() => countsFor(specificQuestions), [specificQuestions]);
  // Categories already used in this pool — offered as autocomplete so the admin
  // doesn't create "De-escalation" and "de escalation" as two categories.
  const knownTopics = useMemo(
    () => Array.from(new Set(questions.map((q) => normaliseTopic(q.topic)).filter(Boolean))).sort(),
    [questions],
  );

  const onSave = async () => {
    if (problems.length) { toast.error(problems[0]); return; }
    setSaving(true);
    try {
      const body = {
        pool_name: name.trim(),
        description: description.trim(),
        // Legacy pool-level default; each question now carries its own `kind`.
        pool_kind: SPOKEN_KIND,
        team,
        // Blank point rows are an editing artefact, not data.
        questions: questions.map((q) => ({
          ...q,
          coverage_tags: q.coverage_tags.map((t) => t.trim()).filter(Boolean),
        })),
      };
      const saved = isNew ? await createPool(body) : await updatePool(poolId!, body);
      // Saving writes a DRAFT — say so, rather than letting an author believe
      // their questions are live when no interview can see them yet.
      toast.success(
        `Saved “${saved.pool_name}” as a draft (${saved.question_count} questions). ` +
        `Submit it for approval when it is ready.`,
      );
      nav("/question-pools");
    } catch (e) {
      toast.error((e as ApiError).message || "Save failed.");
    } finally { setSaving(false); }
  };

  const applyBulk = () => {
    const parsed = parseBulk(bulk);
    if (!parsed.length) { toast.error("Nothing to import — put one question per line."); return; }
    setQuestions((prev) => {
      const kept = prev.filter((q) => q.text.trim());   // drop the empty starter row
      return [...kept, ...parsed];
    });
    setBulk(""); setShowBulk(false);
    toast.success(`Added ${parsed.length} question${parsed.length === 1 ? "" : "s"}.`);
  };

  // Waits for the PERMISSIONS as well as the pool. Rendering before they land
  // would show a read-only form to someone who may edit it, because the lock is
  // derived from `me` — so the honest thing is not to decide until we can.
  if (loading || permsPending) {
    return <div className="ds-light"><LoadingBlock label="Loading…" /></div>;
  }

  return (
    <div className="ds-light screen-enter">
      <PageHeader
        category="Question pools"
        title={isNew ? "New question pool" : mayEdit ? "Edit question pool" : "Question pool"}
        sub={mayEdit
          ? "Write the questions yourself — nothing here is AI-generated."
          : "You can read this pool. Editing belongs to its authors."}
        actions={<>
          <button type="button" className="btn" onClick={() => nav("/question-pools")}>
            {mayEdit ? "Cancel" : "Back"}
          </button>
          {/* A checker opens this page to READ the questions before approving.
              Offering them Save would only fail on submit, after they had typed. */}
          {mayEdit && (
            <button type="button" className="btn btn-primary" onClick={() => void onSave()}
                    disabled={saving || problems.length > 0}>
              {saving ? "Saving…" : "Save pool"}
            </button>
          )}
        </>}
      />

      {problems.length > 0 && (
        <div className="alert alert-danger" role="alert" style={{ marginBottom: 14, fontSize: 13 }}>
          {problems[0]}
        </div>
      )}

      {/* A built-in has no approval workflow: it ships in the image. */}
      {!isNew && !isBuiltin && (
        <div className="card" style={{ padding: 18, marginBottom: 16 }}>
          <h2 style={{ fontSize: 15, fontWeight: 700, margin: "0 0 10px" }}>Approval</h2>
          <PoolWorkflow poolId={poolId!} team={ownerTeam} hasDraft={hasDraft}
                        showSubmit={false} />
        </div>
      )}

      {!mayEdit && (
        <div className="card" style={{ padding: "10px 14px", marginBottom: 14 }}>
          <span style={{ fontSize: 13 }} className="muted">
            {isBuiltin
              ? "Read-only — this pool ships with the product. Duplicate it to make an editable copy."
              : "Read-only — you can review this pool, but editing belongs to its authors."}
          </span>
        </div>
      )}

      {/* Read-only is enforced by ONE attribute, not by disabling 35 controls.
          `fieldset[disabled]` natively disables every form control inside it —
          including any added later — so a reviewer cannot type into a field
          that will never save, and a future control cannot be forgotten. This
          is the browser's own mechanism; the server re-checks regardless. */}
      <fieldset className="form-lock" disabled={!mayEdit}>

      {/* ── pool-level fields ── */}
      <div className="card" style={{ padding: 18, display: "flex", flexDirection: "column", gap: 14, marginBottom: 16 }}>
        <div>
          <label className="lbl" htmlFor="pool-name">Pool name</label>
          <input id="pool-name" className="input" style={{ width: "100%" }} value={name}
                 placeholder="e.g. Customer Support — front line"
                 onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label className="lbl" htmlFor="pool-desc">Description <span className="muted-3">(optional)</span></label>
          <input id="pool-desc" className="input" style={{ width: "100%" }} value={description}
                 placeholder="Who this pool is for, and what it covers."
                 onChange={(e) => setDescription(e.target.value)} />
        </div>
        {myTeams.length > 0 && !myTeams.includes("*") ? (
          <div>
            <label className="lbl" htmlFor="pool-team">Team</label>
            <select id="pool-team" className="input" style={{ width: "100%" }} value={team}
                    onChange={(e) => setTeam(e.target.value)}>
              {myTeams.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
            <p className="muted-3" style={{ fontSize: 12, marginTop: 4 }}>
              Decides who reviews this pool before it can be used.
            </p>
          </div>
        ) : (
          <div>
            <label className="lbl" htmlFor="pool-team">Team <span className="muted-3">(optional)</span></label>
            <input id="pool-team" className="input" style={{ width: "100%" }} value={team}
                   placeholder="Leave blank for any team"
                   onChange={(e) => setTeam(e.target.value)} />
            <p className="muted-3" style={{ fontSize: 12, marginTop: 4 }}>
              Decides who reviews this pool before it can be used.
            </p>
          </div>
        )}
        {isNew && (
          <div>
            <span className="lbl">Not sure where to start?</span>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 4 }}>
              {STARTERS.map((s) => (
                <button key={s.label} type="button" className="btn btn-ghost btn-sm"
                        title={`Adds one example question in the "${s.topic}" category`}
                        onClick={() => setQuestions((prev) => {
                          const kept = prev.filter((q) => q.text.trim());
                          return [...kept, { ...blankQuestion(), text: s.hint, topic: s.topic, difficulty: "easy" as Difficulty }];
                        })}>
                  {s.label}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ── question-type breakdown + coverage matrix ──
          Coverage is category × level for SPECIFIC (spoken) questions only —
          it has nothing to say about a written task, so it's hidden entirely
          when the pool holds none. The type breakdown always shows, since a
          pool of only written questions still deserves to show what it holds. */}
      {questions.length > 0 && (
        <div style={{
          display: "grid",
          gridTemplateColumns: specificQuestions.length > 0 ? "repeat(auto-fit, minmax(min(300px, 100%), 1fr))" : "1fr",
          gap: 16, marginBottom: 16,
        }}>
          <QuestionTypeBreakdown questions={questions} kinds={kinds} />
          {specificQuestions.length > 0 && (
            <div className="card" style={{ padding: 14 }}>
              <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>
                Coverage
                <span className="muted-3" style={{ fontWeight: 500 }}>
                  {" "}· an interview pulls specific questions by category and level, so gaps here limit what it can ask
                </span>
              </div>
              <div style={{ overflowX: "auto" }}>
                <table style={{ borderCollapse: "collapse", fontSize: 12.5, minWidth: 320 }}>
                  <thead>
                    <tr>
                      <th style={{ textAlign: "left", padding: "4px 14px 4px 0", color: "var(--text-2)" }}>Category</th>
                      {DIFFICULTIES.map((d) => (
                        <th key={d} style={{ textAlign: "center", padding: "4px 12px", color: "var(--text-2)", textTransform: "capitalize" }}>{d}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(counts).map(([topic, row]) => (
                      <tr key={topic}>
                        <td style={{ padding: "4px 14px 4px 0", fontFamily: "var(--mono)" }}>{topic}</td>
                        {DIFFICULTIES.map((d) => (
                          <td key={d} style={{ textAlign: "center", padding: "4px 12px", color: row[d] ? "var(--text)" : "var(--text-3)" }}>
                            {row[d]}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── questions ── */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
        <span style={{ fontSize: 14, fontWeight: 700 }}>
          Questions <span className="muted-3" style={{ fontWeight: 500 }}>· {questions.length}</span>
        </span>
        <button type="button" className="btn btn-ghost btn-sm" onClick={() => setShowBulk((v) => !v)}>
          {showBulk ? "Close paste import" : "Paste a list"}
        </button>
      </div>

      {showBulk && (
        <div className="card" style={{ padding: 14, marginBottom: 14 }}>
          <label className="lbl" htmlFor="bulk">One question per line. Optionally add category, level and answer points with <span style={{ fontFamily: "var(--mono)" }}>|</span></label>
          <textarea id="bulk" className="input" rows={5} style={{ width: "100%", fontFamily: "var(--mono)", fontSize: 12.5 }}
                    value={bulk} onChange={(e) => setBulk(e.target.value)}
                    placeholder={"How do you handle an angry customer? | de_escalation | easy | stays calm; offers a fix\nDescribe a time you said no."} />
          <button type="button" className="btn btn-primary btn-sm" style={{ marginTop: 10 }} onClick={applyBulk}>
            Add to pool
          </button>
        </div>
      )}

      {questions.length === 0 && (
        <div className="ds-empty" style={{ padding: 28 }}>
          <p className="muted" style={{ fontSize: 13.5, margin: 0 }}>
            No questions yet — add your first one below and pick what kind it is.
          </p>
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {questions.map((q, i) => (
          <div key={i} className="card" style={{ padding: 16, display: "flex", flexDirection: "column", gap: 12 }}>
            <div style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: 10 }}>
              <span style={{ fontSize: 12.5, fontWeight: 700 }}>Question {i + 1}</span>
              <span className="pill" style={{ padding: "2px 9px", fontSize: 10.5 }}>
                {kindOf(q)?.label ?? "Specific question"}
              </span>
              {q.id && <span className="muted-3" style={{ fontSize: 11, fontFamily: "var(--mono)" }}>{q.id}</span>}
              <button type="button" className="btn btn-ghost btn-sm" style={{ marginLeft: "auto" }}
                      title="Remove this question"
                      onClick={() => setQuestions((prev) => prev.filter((_, n) => n !== i))}>
                Remove
              </button>
            </div>

            {/* What the checker said about THIS question. Shown against the
                question itself rather than as one lump at the top of the page:
                a rejection the author has to match back to a question by
                reading ids is feedback they will act on slowly, or not at all. */}
            {q.id && reviews[q.id]?.verdict === "rejected" && (
              <div style={{
                padding: "8px 10px", borderRadius: 8, fontSize: 12.5,
                borderLeft: "3px solid var(--danger)", background: "rgba(255,84,112,0.07)",
              }}>
                <strong style={{ color: "var(--danger)" }}>Needs work</strong>
                {" — "}{reviews[q.id].comment}
                <span className="muted-3"> · {reviews[q.id].by}</span>
              </div>
            )}

            {!kindOf(q)?.prompt_hidden && (
              <div>
                <label className="lbl" htmlFor={`q-${i}`}>
                  {kindOf(q)?.prompt_label || "The question"}
                </label>
                <textarea id={`q-${i}`} className="input" rows={2} style={{ width: "100%" }}
                          value={q.text}
                          placeholder={kindOf(q)?.prompt_placeholder || "What should the interviewer ask?"}
                          onChange={(e) => patch(i, { text: e.target.value })} />
              </div>
            )}

            {/* Material this KIND requires, rendered from the catalog — so a
                new question type needs no change here. WHICH block the values
                live on also comes from the catalog (`block`), so a coding
                question writes `coding` and a written one `written_response`
                with no branch in this file. */}
            {(kindOf(q)?.fields.length ?? 0) > 0 && kindOf(q)!.fields.map((f) => {
              const blockName = kindOf(q)!.block || "written_response";
              const blk = ((q as unknown as Record<string, unknown>)[blockName]
                          ?? {}) as Record<string, unknown>;
              return (
                <MaterialField
                  key={f.name}
                  field={f}
                  languages={languages}
                  value={blk[f.name]}
                  onChange={(v) => patch(i, {
                    [blockName]: { ...blk, [f.name]: v },
                  } as unknown as Partial<PoolQuestion>)}
                />
              );
            })}

            {kindOf(q)?.written && (
              <div style={{ flex: "0 0 180px" }}>
                <label className="lbl" htmlFor={`lim-${i}`}>Character limit</label>
                <input
                  id={`lim-${i}`} type="number" min={1} className="input"
                  style={{ width: 180 }}
                  value={String(q.written_response?.char_limit ?? 1500)}
                  onChange={(e) => patch(i, {
                    written_response: {
                      ...(q.written_response || {}),
                      char_limit: Math.max(1, Number(e.target.value) || 1),
                    },
                  })}
                />
              </div>
            )}

            {/* Category, level and answer points steer the VERIFIER's
                follow-up probing, which only happens on a spoken exchange. A
                written task is one-shot and scored by its rubric plugin, so
                these would be dead fields — and a dead field reads as required. */}
            {showsTopicAndPoints(kindOf(q)) && (<>
            <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              <div style={{ flex: "1 1 200px" }}>
                <label className="lbl" htmlFor={`t-${i}`}>Category <span className="muted-3">(required)</span></label>
                <input id={`t-${i}`} className="input" style={{ width: "100%" }} list={`topics-${i}`}
                       value={q.topic} placeholder="e.g. de-escalation"
                       onChange={(e) => patch(i, { topic: e.target.value })} />
                <datalist id={`topics-${i}`}>
                  {knownTopics.map((t) => <option key={t} value={t} />)}
                </datalist>
                {q.topic && normaliseTopic(q.topic) !== q.topic && (
                  <p className="muted-3" style={{ fontSize: 11.5, margin: "4px 0 0" }}>
                    Saved as <span style={{ fontFamily: "var(--mono)" }}>{normaliseTopic(q.topic)}</span>
                  </p>
                )}
              </div>
              <div style={{ flex: "0 0 150px" }}>
                <label className="lbl" htmlFor={`d-${i}`}>Level</label>
                <select id={`d-${i}`} className="input" style={{ width: "100%", textTransform: "capitalize" }}
                        value={q.difficulty}
                        onChange={(e) => patch(i, { difficulty: e.target.value as Difficulty })}>
                  {DIFFICULTIES.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
            </div>

            {showsAnswerPoints(kindOf(q)) && (
            <div>
              <label className="lbl" htmlFor={`c-${i}`}>What a good answer should mention <span className="muted-3">(required)</span></label>
              <AnswerPoints
                inputId={`c-${i}`}
                points={q.coverage_tags}
                onChange={(coverage_tags) => patch(i, { coverage_tags })}
              />
              <p className="muted-3" style={{ fontSize: 11.5, margin: "6px 0 0" }}>
                Add at least one point. The interviewer follows up on whichever ones
                the candidate's answer misses.
              </p>
            </div>
            )}
            </>)}
          </div>
        ))}
      </div>

      <button type="button" className="btn btn-ghost" style={{ marginTop: 12 }}
              onClick={() => setPicking(true)}>
        <Icon name="plus" className="ico" style={{ width: 15, height: 15 }} /> Add question
      </button>

      </fieldset>

      {picking && (
        <KindPicker
          kinds={kinds}
          onCancel={() => setPicking(false)}
          onPick={(k) => {
            setPicking(false);
            setQuestions((prev) => [...prev, blankQuestion(k)]);
          }}
        />
      )}
    </div>
  );
}
