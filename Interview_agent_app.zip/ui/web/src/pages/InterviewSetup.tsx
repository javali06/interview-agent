import { useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  useApproveInterviews, useCadenceTemplate, useCreateInterviews, useEnsureCadenceTemplate,
  useRemoveCandidate, useRole, useRoleInterviews, useSendInterviewEmail, useSetCandidateEmail,
  type RoleInterview,
} from "../lib/roles";
import { useArchiveSession, useDeleteSession } from "../lib/sessions";
import { ApiError } from "../lib/api";
import RoleInterviewsChart from "../components/RoleInterviewsChart";
import { PageHeader } from "../components/PageHeader";
import { LoadingBlock } from "../components/LoadingBlock";

// Planning and running a role's interviews. The role page does the other half
// (match and rank CVs); NO list appears on both, which is what stopped the two
// screens reading as the same thing twice.
//
// Three sections, in the order the work happens:
//   1. Plan       — one cadence + evaluation for the whole role
//   2. Pick who   — everyone gets that plan, verbatim
//   3. Interviews — what exists, and what to do with each
//
// Step 1 is required, and that is the point. This flow used to generate a
// cadence per candidate from their own resume, so everyone answered a different
// interview scored by a different plan — and the Shortlist exists to RANK people
// against each other, which that quietly made impossible.
//
// "This role's interviews" is the single place those interviews are managed:
// status, the address the link goes to, and the actions that make sense for
// where each one has got to. There used to be a SEPARATE post-create screen
// showing the same interviews, which meant the same thing lived in two places
// and only one of them survived a page load.
export function InterviewSetup() {
  const { roleId = "" } = useParams();
  const role = useRole(roleId);
  const template = useCadenceTemplate(roleId);
  const ensureTemplate = useEnsureCadenceTemplate(roleId);
  const create = useCreateInterviews(roleId);
  const existing = useRoleInterviews(roleId);
  const removeCandidate = useRemoveCandidate(roleId);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [seeded, setSeeded] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  const roleInterviews = existing.data?.interviews ?? [];
  // Somebody who already has an interview for this role must not be offered
  // again — creating a second one for the same person is almost always a
  // mistake, and the row below shows the one they have.
  const alreadyHasInterview = new Set(
    roleInterviews.map((iv) => iv.candidate_public_id).filter(Boolean),
  );

  const r = role.data;
  const allCands = r?.candidates ?? [];
  const cands = allCands.filter((c) => !alreadyHasInterview.has(c.candidate_public_id));

  // Preselect candidates above the role threshold once data loads. Deliberately
  // NOT everyone: auto-ticking people who failed the bar would interview them by
  // default. When nobody clears it this ticks nothing, hence the note below.
  useEffect(() => {
    if (r && !seeded && !existing.isLoading) {
      setSelected(new Set(cands.filter((c) => c.above_threshold).map((c) => c.candidate_public_id)));
      setSeeded(true);
    }
  }, [r, seeded, existing.isLoading, cands]);

  if (role.isLoading) return <div className="ds-light"><LoadingBlock label="Loading role…" /></div>;
  if (role.isError || !r) {
    return (
      <div className="ds-light">
        <Link to="/shortlist" className="ds-back">← Back to roles</Link>
        <p style={{ marginTop: 16, fontSize: 14, color: "var(--danger)" }}>
          {(role.error as ApiError)?.message || "Failed to load."}
        </p>
      </div>
    );
  }

  const toggle = (id: string) =>
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const tpl = template.data;
  // A closed role takes no new work; the server refuses it, so do not offer it.
  const closed = r.status === "closed";
  const cadenceReady = !!tpl?.ready && !closed;
  const mode = (tpl?.modality || r.modality) === "text" ? "text" : "voice";
  const noneAboveBar = cands.length > 0 && cands.every((c) => !c.above_threshold);

  const startCadence = async () => {
    setNotice(null);
    try {
      const t = await ensureTemplate.mutateAsync();
      if (t.token) window.location.assign(`/app/schedule/${t.token}/cadence`);
    } catch (e) {
      setNotice(`Could not start the cadence: ${(e as ApiError).message}`);
    }
  };

  const run = async () => {
    setNotice(null);
    try {
      const res = await create.mutateAsync([...selected]);
      setSelected(new Set());
      const errs = res.errors?.length ? ` ${res.errors.length} failed.` : "";
      setNotice(`Created ${res.created.length} interview${res.created.length === 1 ? "" : "s"}.${errs}`);
    } catch (e) {
      setNotice(`Failed: ${(e as ApiError).message}`);
    }
  };

  return (
    <div className="ds-light screen-enter">
      <PageHeader
        category="Shortlist"
        back={<Link to={`/shortlist/${roleId}`} className="ds-back">← Back to role</Link>}
        title={<>Set up interviews · {r.title}</>}
        sub="Set one interview plan, pick who takes it, then send their links."
      />

      {/* Step 1 — the plan, authored once */}
      <div className="card" style={{ padding: "16px 18px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{ fontWeight: 600 }}>
              1 · Interview plan
              <span className="pill" style={{ marginLeft: 8, fontSize: 10, textTransform: "uppercase" }}>
                {mode === "text" ? "Text" : "Voice"}
              </span>
              {cadenceReady && (
                <span className="pill ok" style={{ marginLeft: 8, fontSize: 10, textTransform: "uppercase" }}>
                  Approved
                </span>
              )}
            </div>
            <div className="muted-3" style={{ marginTop: 3, fontSize: 12.5 }}>
              {!tpl || tpl.status === "missing"
                ? "Set the questions, phases and scoring plugins once. Every candidate for this role gets the same interview, so their scores are comparable."
                : cadenceReady
                ? `Every candidate gets this exact ${mode} interview. You can still edit an individual one after it is created.`
                : "The plan is ready to review. Approve it to unlock creating interviews."}
            </div>
          </div>
          {(!tpl || tpl.status === "missing") ? (
            <button type="button" className="btn btn-primary" disabled={ensureTemplate.isPending} onClick={startCadence}>
              {ensureTemplate.isPending ? "Preparing…" : "Set the interview cadence →"}
            </button>
          ) : (
            <a href={`/app/schedule/${tpl.token}/cadence`} className={`btn btn-sm ${cadenceReady ? "" : "btn-primary"}`}>
              {cadenceReady ? "Edit cadence" : "Review & approve →"}
            </a>
          )}
        </div>
      </div>

      {/* Step 2 — who takes it */}
      {/* Locked until the plan is approved: a muted surface rather than lowered
          opacity, so its text and link keep AA contrast. */}
      <div className="card" style={{ marginTop: 16, overflow: "hidden", padding: 0, background: cadenceReady ? undefined : "var(--panel-2)" }}>
        <div style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: 10, padding: "12px 16px", borderBottom: "1px solid var(--line)" }}>
          <span style={{ fontSize: 13.5, fontWeight: 600 }}>2 · Who takes this interview</span>
          {noneAboveBar && (
            <span className="muted-3" style={{ fontSize: 12 }}>
              — nobody scored above the role&rsquo;s threshold of {r.threshold}, so none were
              pre-selected. Tick anyone you still want to interview.
            </span>
          )}
          {cands.length > 0 && (
            <button type="button" className="btn btn-ghost btn-sm" style={{ marginLeft: "auto" }}
                    onClick={() => setSelected(
                      selected.size === cands.length
                        ? new Set()
                        : new Set(cands.map((c) => c.candidate_public_id)),
                    )}>
              {selected.size === cands.length ? "Clear all" : "Select all"}
            </button>
          )}
        </div>

        {cands.length === 0 ? (
          <p className="muted" style={{ padding: "16px", fontSize: 14, margin: 0 }}>
            {allCands.length === 0
              ? <>No matched candidates yet. <Link to={`/shortlist/${roleId}`} className="link">Match resumes first →</Link></>
              : "Everyone matched to this role already has an interview."}
          </p>
        ) : cands.map((c) => (
          <label key={c.candidate_public_id} style={{ display: "flex", flexWrap: "wrap", cursor: "pointer", alignItems: "center", gap: "8px 12px", padding: "13px 16px", borderBottom: "1px solid var(--line)" }}>
            <input type="checkbox" checked={selected.has(c.candidate_public_id)} onChange={() => toggle(c.candidate_public_id)} />
            <span style={{ flex: 1, fontWeight: 600 }}>{c.name}</span>
            <span className={`pill ${c.above_threshold ? "ok" : "warn"}`}>
              {c.final_score}{c.above_threshold ? " · fit" : " · below"}
            </span>
            <span className="muted-3" style={{ fontSize: 12 }}>{c.has_resume ? "resume on file" : "no resume"}</span>
            {/* Removing takes them off THIS role only. The whole row is a
                <label>, so a click here would otherwise toggle the box. */}
            <button
              type="button" className="btn btn-ghost btn-sm"
              title="Remove this candidate from this role"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                if (!window.confirm(
                  `Remove ${c.name} from this role?\n\nTheir resume and any interview already created are kept.`
                )) return;
                setSelected((prev) => {
                  const next = new Set(prev);
                  next.delete(c.candidate_public_id);
                  return next;
                });
                void removeCandidate.mutateAsync(c.candidate_public_id);
              }}>
              Remove
            </button>
          </label>
        ))}
      </div>

      <div style={{ marginTop: 18, display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
        <button type="button" disabled={!selected.size || !cadenceReady || create.isPending} onClick={run} className="btn btn-primary">
          {create.isPending ? "Creating…" : `Create ${selected.size || ""} interview${selected.size === 1 ? "" : "s"}`}
        </button>
        {closed ? (
          <span className="muted-3" style={{ fontSize: 13 }}>
            This role is closed — reopen it from the role page to create interviews.
          </span>
        ) : !cadenceReady ? (
          <span className="muted-3" style={{ fontSize: 13 }}>Approve the interview cadence above first.</span>
        ) : !selected.size && cands.length > 0 ? (
          <span className="muted-3" style={{ fontSize: 13 }}>Select at least one candidate above.</span>
        ) : null}
        {notice && <span className="muted" style={{ fontSize: 13.5 }}>{notice}</span>}
      </div>

      {/* 3 · The interviews themselves — the one place they are managed. */}
      <ExistingInterviews rows={roleInterviews} roleId={roleId} onNotice={setNotice}
                          states={r.interview_states ?? {}} closed={closed} />
    </div>
  );
}

/** An interview that has RUN: its plan can no longer change, so it is managed
 *  rather than edited. `cancelled` counts — archiving sets it. */
const finished = (status: string) => status === "completed" || status === "cancelled";

const STATUS_LABEL: Record<string, string> = {
  draft: "Awaiting approval",
  generating: "Preparing",
  ready: "Ready to send",
  in_progress: "In progress",
  completed: "Completed",
  cancelled: "Cancelled",
};

/** This role's interviews: status, who the link goes to, and the actions that
 *  make sense for where each one has got to.
 *
 *  Read from the server rather than from the batch a browser happens to
 *  remember creating, so it is the same list on every visit. */
function ExistingInterviews({ rows, roleId, onNotice, states, closed }: {
  rows: RoleInterview[]; roleId: string; onNotice: (s: string | null) => void;
  states: Record<string, number>; closed: boolean;
}) {
  const [copied, setCopied] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [sendingToken, setSendingToken] = useState<string | null>(null);
  const [sentToken, setSentToken] = useState<string | null>(null);
  const qc = useQueryClient();
  const archive = useArchiveSession();
  const del = useDeleteSession();
  const approve = useApproveInterviews(roleId);
  const setEmail = useSetCandidateEmail(roleId);
  const sendEmail = useSendInterviewEmail(roleId);

  // The role's own mutations invalidate their queries themselves (see
  // invalidateRole in lib/roles). Archive and delete come from lib/sessions,
  // which only knows about the dashboard's list — so those two still need the
  // role's queries refreshed here, or a row vanishes from one place and
  // lingers in another.
  const refresh = () => {
    void qc.invalidateQueries({ queryKey: ["role-interviews", roleId] });
    void qc.invalidateQueries({ queryKey: ["role", roleId] });
  };
  const run = async (token: string, fn: () => Promise<unknown>) => {
    setBusy(token);
    try { await fn(); refresh(); } finally { setBusy(null); }
  };

  const pending = rows.filter((iv) => iv.status === "draft");

  return (
    <div style={{ marginTop: 22 }}>
      {/* The ring summarises exactly the rows beneath it, so the two agree. */}
      <RoleInterviewsChart states={states} />

      {rows.length > 0 && (
      <div className="card" style={{ marginTop: 10, overflow: "hidden", padding: 0 }}>
      <div style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: 10, padding: "12px 16px", borderBottom: "1px solid var(--line)" }}>
        <span style={{ fontSize: 13.5, fontWeight: 600 }}>3 · Interviews ({rows.length})</span>
        {pending.length > 0 && !closed && (
          <button type="button" className="btn btn-primary btn-sm" style={{ marginLeft: "auto" }}
                  disabled={approve.isPending}
                  onClick={() => {
                    onNotice(null);
                    approve.mutate(pending.map((iv) => iv.token), {
                      onSuccess: (res) => {
                        if (res.errors?.length) {
                          onNotice(`${res.errors.length} could not be approved: ` +
                            res.errors.map((e) => `${e.candidate_name || "?"} — ${e.error}`).join("; "));
                        }
                      },
                      onError: (e) => onNotice(`Approve failed: ${(e as ApiError).message}`),
                    });
                  }}>
            {approve.isPending ? "Approving…" : `Approve & generate ${pending.length} link${pending.length === 1 ? "" : "s"}`}
          </button>
        )}
      </div>

      {rows.map((iv) => (
        <div key={iv.token} style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: "8px 12px", padding: "11px 16px", borderBottom: "1px solid var(--line)" }}>
          <span style={{ fontWeight: 600, minWidth: "min(170px, 100%)" }}>{iv.candidate_name}</span>
          <span className="pill" data-status={iv.status} style={{ fontSize: 10, textTransform: "uppercase" }}>
            {STATUS_LABEL[iv.status] || iv.status}
          </span>

          {/* The address the link goes to. Extracted from the resume by an LLM,
              so regularly wrong or missing — and it is the one field here that
              decides whether a real person receives their interview. */}
          <CandidateEmail
            value={iv.candidate_email}
            onSave={(email) =>
              setEmail.mutateAsync({ candidateId: iv.candidate_public_id, email })}
          />

          {finished(iv.status) ? (
            <>
              <Link to={`/sessions/${iv.token}`} className="btn btn-ghost btn-sm">View →</Link>
              {iv.status !== "cancelled" && (
                <button type="button" className="btn btn-ghost btn-sm" disabled={busy === iv.token}
                        onClick={() => {
                          if (!window.confirm(
                            `Archive ${iv.candidate_name}'s interview?\n\nThe transcript and scorecard stay viewable.`
                          )) return;
                          void run(iv.token, () => archive.mutateAsync(iv.token));
                        }}>
                  {busy === iv.token ? "Working…" : "Archive"}
                </button>
              )}
              <button type="button" className="btn btn-ghost btn-sm" disabled={busy === iv.token}
                      style={{ color: "var(--danger)" }}
                      onClick={() => {
                        if (!window.confirm(
                          `Delete ${iv.candidate_name}'s interview?\n\nThis removes the transcript and scorecard permanently and cannot be undone.`
                        )) return;
                        void run(iv.token, () => del.mutateAsync(iv.token));
                      }}>
                Delete
              </button>
            </>
          ) : (
            <>
              {/* A link only exists once approved — offering Send/Copy on a
                  draft would hand out a URL that does not work yet. */}
              {iv.candidate_link ? (
                <>
                  <button type="button" className="btn btn-primary btn-sm"
                          disabled={sendingToken === iv.token}
                          onClick={() => {
                            onNotice(null);
                            setSendingToken(iv.token);
                            sendEmail.mutate(iv.token, {
                              onSuccess: () => {
                                setSentToken(iv.token);
                                setTimeout(() => setSentToken((c) => (c === iv.token ? null : c)), 1500);
                              },
                              onError: (e) => onNotice(`Could not send: ${(e as ApiError).message}`),
                              onSettled: () => setSendingToken(null),
                            });
                          }}>
                    {sendingToken === iv.token ? "Sending…" : sentToken === iv.token ? "Sent" : "Send email"}
                  </button>
                  <button type="button" className="btn btn-sm"
                          onClick={() => {
                            void navigator.clipboard.writeText(iv.candidate_link);
                            setCopied(iv.token);
                            setTimeout(() => setCopied((c) => (c === iv.token ? null : c)), 1500);
                          }}>
                    {copied === iv.token ? "Copied" : "Copy link"}
                  </button>
                </>
              ) : (
                <span className="muted-3" style={{ fontSize: 12 }}>no link yet</span>
              )}
              <Link to={`/schedule/${iv.token}/cadence`} className="btn btn-ghost btn-sm">Edit</Link>
            </>
          )}
        </div>
      ))}
      </div>
      )}
    </div>
  );
}

/** The candidate's email, editable in place.

    It is extracted from the resume by an LLM, so it is a guess — sometimes
    wrong, often missing — and it is the one field on this screen that decides
    whether a real person receives their interview. Blank reads as a prompt to
    add one rather than as empty space. */
function CandidateEmail({ value, onSave }: {
  value: string; onSave: (email: string) => Promise<unknown>;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const [busy, setBusy] = useState(false);

  if (!editing) {
    return (
      <button type="button"
              onClick={() => { setDraft(value); setEditing(true); }}
              title="Edit the candidate's email"
              style={{ flex: 1, minWidth: 0, textAlign: "left", background: "none",
                       border: "none", padding: 0, font: "inherit", fontSize: 13,
                       cursor: "pointer", color: value ? "var(--text-2)" : "var(--magenta-soft)",
                       overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
        {value || "+ add email"}
      </button>
    );
  }
  const commit = async () => {
    setBusy(true);
    try { await onSave(draft.trim()); setEditing(false); } finally { setBusy(false); }
  };
  return (
    <span style={{ flex: 1, minWidth: 0, display: "flex", gap: 6 }}>
      <input
        autoFocus type="email" value={draft} disabled={busy}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") void commit();
          if (e.key === "Escape") setEditing(false);
        }}
        placeholder="name@example.com"
        style={{ flex: 1, minWidth: 0, padding: "4px 8px", borderRadius: 6, fontSize: 13,
                 border: "1px solid var(--field-line, var(--line))", background: "var(--ink-2)", color: "var(--text)" }}
      />
      <button type="button" className="btn btn-sm" disabled={busy} onClick={() => void commit()}>
        {busy ? "Saving…" : "Save"}
      </button>
      <button type="button" className="btn btn-ghost btn-sm" disabled={busy}
              onClick={() => setEditing(false)}>Cancel</button>
    </span>
  );
}
