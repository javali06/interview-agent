import { useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties, ReactNode } from "react";
import { Link, useParams } from "react-router-dom";
import { CadencePhaseBlock } from "../components/CadencePhaseBlock";
import { CodingPhaseModal } from "../components/CodingPhaseModal";
import { ScenarioPhaseModal } from "../components/ScenarioPhaseModal";
import { AddPhasesMenu } from "../components/AddPhasesMenu";
import { AddPhaseModal } from "../components/AddPhaseModal";
import { EvalPhaseCard, EvalPlanToolbar, useEvalPlan } from "../components/EvalPlanPanel";
import { useToast } from "../components/Toaster";
import { parseCadenceYaml, phaseColor, type ParsedCadence, type ParsedPhase } from "../lib/cadence";
import { formatPhaseDuration } from "../lib/format";
import {
  approveCadence,
  customizeAdaptive,
  customizeCadence,
  reviseCadence,
  sendInviteEmail,
  useCadenceContext,
  validateCadence,
  type CadenceContext,
  type ReviseClarification,
  type ReviseQuestion,
} from "../lib/cadenceReview";
import { StatusPill } from "../components/StatusPill";
import { PageHeader } from "../components/PageHeader";
import { LoadingBlock } from "../components/LoadingBlock";
import { ApiError } from "../lib/api";

const sectionLabel: CSSProperties = {
  fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase", color: "var(--text-3)",
};

// The cadence's total time is, by definition, the SUM of its phase durations —
// the backend schema validates `total_duration_s == Σ phase duration_s`, so for
// any saved cadence the two agree. We derive from the phases anyway so the
// timeline stays correct even when the declared top-level `total_duration_s` is
// stale (e.g. a raw-YAML edit before a save recomputes it).
function sumPhaseDurations(phases?: ParsedPhase[]): number {
  return (phases ?? []).reduce((s, p) => s + (p.duration_s ?? 0), 0);
}

export function CadenceReview() {
  const { token = "" } = useParams();
  const ctxq = useCadenceContext(token);
  const toast = useToast();

  const [yaml, setYaml] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [approved, setApproved] = useState<{ candidate: string; email: string | null } | null>(null);
  // A role's cadence TEMPLATE, not somebody's interview: it is approved rather
  // than launched, so there is no candidate link and no orchestrator.
  const isTemplate = !!ctxq.data?.row?.is_template;
  const [copied, setCopied] = useState<string | null>(null);
  const [sendState, setSendState] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [sendError, setSendError] = useState<string | null>(null);

  // Shared hover index so the Timeline segments and the phase cards below
  // highlight each other (hover a segment → its card lights up, and vice versa).
  const [hoveredPhase, setHoveredPhase] = useState<number | null>(null);

  // Editor visibility (cadence raw yaml / rubric raw JSON) and the rubric
  // JSON draft. Moved up from the panels so the top Controls bar can toggle
  // both, and the editors render above the per-phase tile list.
  const [showRawYaml, setShowRawYaml] = useState(false);

  // Explicit save/cancel for the raw YAML editor. Keystrokes flow into
  // `rawDraft` only — `yaml` (the global state Approve/Validate/Revise read)
  // only updates when the user clicks Save. `rawSnapshot` is the value the
  // editor opened with, used to detect "no changes" → disable Save.
  const [rawDraft, setRawDraft] = useState("");
  const rawSnapshot = useRef("");

  // Coding-phase modal (Add / Edit / Remove all live here).
  const [codingModalOpen, setCodingModalOpen] = useState(false);
  // Visual Scenario Analysis modal (Add / Edit / Remove) — VOICE interviews
  // only, same as coding. `editScenarioPhaseId` set → prefilled from that
  // phase; both are reached through the "Add phases" menu.
  const [scenarioModalOpen, setScenarioModalOpen] = useState(false);
  const [editScenarioPhaseId, setEditScenarioPhaseId] = useState<string | null>(null);
  // Add/Edit-phase modal (written-response question types) — TEXT interviews
  // only (coding is voice-only). `editPhaseId` set → the same modal opens
  // prefilled from that phase, so questions can be added/edited/removed on a
  // phase that already exists.
  const [addPhaseOpen, setAddPhaseOpen] = useState(false);
  const [editPhaseId, setEditPhaseId] = useState<string | null>(null);

  // Why: seed YAML ONCE. The query data reference can change (refetch, cache
  // invalidation), and re-firing setYaml on every change clobbers local edits
  // (e.g. a fresh Revise/Customize/Add-coding result) with the still-stale
  // server copy.
  const seeded = useRef(false);
  useEffect(() => {
    if (!seeded.current && ctxq.data) {
      setYaml(ctxq.data.row.cadence_yaml || "");
      seeded.current = true;
    }
  }, [ctxq.data]);

  const parsed = useMemo(() => parseCadenceYaml(yaml), [yaml]);

  // A TEXT interview's cadence carries top-level `timed: false` (voice =
  // true/absent). Coding is voice-only, so text interviews swap the coding
  // button for the written-response phase authoring button.
  const isText = parsed?.timed === false;

  // A cadence holds AT MOST ONE Visual Scenario Analysis phase — it's a
  // single container for many items, not one phase per "Add phases" click
  // (mirrors coding, which also has exactly one phase). `existingIds` in
  // ORDER, so `[0]` is always "the" scenario phase the menu/tile edit; any
  // beyond that are a pre-existing data anomaly (e.g. hand-edited YAML) the
  // UI surfaces as a warning rather than silently hiding or auto-deleting.
  const scenarioPhaseIds = (parsed?.phases ?? [])
    .filter((p) => (p.scenario_items?.length ?? 0) > 0)
    .map((p) => p.id as string);
  const existingScenarioPhaseId = scenarioPhaseIds[0] ?? null;
  const extraScenarioPhaseIds = scenarioPhaseIds.slice(1);

  // Plugin-based evaluation plan (replaces the old derived rubric). One shared
  // instance; per-phase plugin cards render in each cadence phase row below.
  // Outcomes surface as the bottom-right toast (never inline in the eval box).
  const evalPlan = useEvalPlan(token, yaml, toast);

  async function run<T>(name: string, fn: () => Promise<T>): Promise<T | undefined> {
    setBusy(name);
    try {
      return await fn();
    } catch (e) {
      toast.error((e as ApiError).message || "Request failed.");
    } finally {
      setBusy(null);
    }
  }

  const copy = (key: string, text: string) =>
    void navigator.clipboard.writeText(text).then(() => {
      setCopied(key);
      window.setTimeout(() => setCopied((c) => (c === key ? null : c)), 1500);
    });

  // Toggle the raw-YAML editor. Opening = snapshot current yaml into the
  // draft; closing acts like Cancel (draft is discarded silently).
  const toggleRawYaml = () => {
    if (showRawYaml) {
      setShowRawYaml(false);
      return;
    }
    setRawDraft(yaml);
    rawSnapshot.current = yaml;
    setShowRawYaml(true);
  };

  const saveRawYaml = () => {
    setYaml(rawDraft);
    setShowRawYaml(false);
    toast.success("YAML saved.");
  };

  if (ctxq.isLoading) return <div className="ds-light"><LoadingBlock label="Loading cadence…" rows={4} /></div>;
  if (ctxq.isError) {
    return (
      <div className="ds-light">
        <Link to="/dashboard" className="ds-back">← Back to interviews</Link>
        <p style={{ marginTop: 16, fontSize: 14, color: "var(--danger)" }}>
          {(ctxq.error as ApiError).message || "Failed to load."}
        </p>
      </div>
    );
  }

  const ctx = ctxq.data as CadenceContext;
  const { row } = ctx;

  // Cadence is still being generated on the worker tier (empty cadence_yaml).
  // The context query auto-polls every 2s (see useCadenceContext) and this
  // screen swaps to the editor as soon as the worker flips status to "draft".
  if (row.status === "generating") {
    return (
      <div className="ds-light screen-enter" style={{ maxWidth: 560, margin: "0 auto" }}>
        <Link to="/dashboard" className="ds-back">← Back to interviews</Link>
        <div className="card" style={{ padding: 24, textAlign: "center" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
            <StatusPill status="generating" />
          </div>
          <h1 style={{ marginTop: 12, fontSize: 20, fontWeight: 600 }}>Generating interview plan…</h1>
          <p className="muted-3" style={{ marginTop: 6, fontSize: 14 }}>
            Building the cadence for <b>{row.candidate_name}</b> ({row.role}) in the
            background. This usually takes a few seconds.
          </p>
          <p className="muted-3" style={{ marginTop: 10, fontSize: 13 }}>
            This page updates automatically when it's ready.
          </p>
        </div>
      </div>
    );
  }

  if (approved) {
    return (
      <div className="ds-light screen-enter" style={{ maxWidth: 560, margin: "0 auto" }}>
        <div className="card" style={{ padding: 24, textAlign: "center", borderColor: "transparent", background: "var(--ds-success-soft)" }}>
          <h1 style={{ fontSize: 22, fontWeight: 600, color: "#166534" }}>Interview ready ✓</h1>
          <p style={{ marginTop: 4, fontSize: 14, color: "#166534" }}>
            Share the candidate link. The interview launches when they click Start.
          </p>
        </div>
        <div style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 12 }}>
          <LinkRow label="Candidate link" url={approved.candidate} copied={copied === "c"} onCopy={() => copy("c", approved.candidate)} />
        </div>

        {approved.email ? (
          <div className="card" style={{ marginTop: 10, padding: "10px 14px", textAlign: "left", display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
            <span style={{ fontSize: 12.5, color: "var(--text-3)" }}>
              Invite emailed to <strong style={{ color: "var(--text-1)" }}>{approved.email}</strong>
            </span>
            <button
              type="button"
              className="btn btn-primary btn-sm"
              style={{ marginLeft: "auto" }}
              disabled={sendState === "sending"}
              onClick={() => {
                setSendState("sending");
                setSendError(null);
                sendInviteEmail(token)
                  .then((r) => {
                    if (r.ok) {
                      setSendState("sent");
                      setTimeout(() => setSendState((s) => (s === "sent" ? "idle" : s)), 2000);
                    } else {
                      setSendState("error");
                      setSendError(r.error || "Could not send.");
                    }
                  })
                  .catch((e: ApiError) => {
                    setSendState("error");
                    setSendError(e.message);
                  });
              }}
            >
              {sendState === "sending" ? "Sending…" : sendState === "sent" ? "Sent ✓" : "Resend email"}
            </button>
            {sendState === "error" && (
              <span style={{ fontSize: 12, color: "var(--danger)", width: "100%" }}>{sendError}</span>
            )}
          </div>
        ) : (
          <p style={{ marginTop: 10, fontSize: 12.5, color: "var(--text-3)" }}>
            No candidate email on file — share the link above manually.
          </p>
        )}

        {/* Session details — mirrors the Jinja cadence_approved meta block so
            the operator can confirm what was just launched at a glance. */}
        <div className="card" style={{ marginTop: 12, padding: 14, textAlign: "left" }}>
          <div style={sectionLabel}>Session details</div>
          <ul style={{ listStyle: "none", margin: "8px 0 0", padding: 0, display: "flex", flexDirection: "column", gap: 6, fontSize: 13 }}>
            <li><span className="muted-3">Candidate:</span> <b>{row.candidate_name}</b></li>
            <li><span className="muted-3">Role:</span> {row.role}</li>
            <li style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span className="muted-3">Status:</span> <StatusPill status={row.status} />
            </li>
            <li>
              <span className="muted-3">Token:</span>{" "}
              <code className="mono" style={{ fontSize: 12 }}>{row.token}</code>
            </li>
          </ul>
        </div>

        <div style={{ marginTop: 16, display: "flex", flexWrap: "wrap", justifyContent: "center", gap: 10 }}>
          <Link to="/dashboard" className="btn btn-ghost btn-sm">← Back to interviews</Link>
          {/* Edit this interview — full-page POST into the Jinja reopen route.
              It stops the orchestrator and reverts the row to draft, so confirm
              first (same copy/behaviour as the Dashboard "Edit" action). */}
          <form
            method="post"
            action={`/admin/schedule/${token}/reopen`}
            style={{ display: "inline" }}
            onSubmit={(e) => {
              if (
                !window.confirm(
                  "Edit this interview? The orchestrator will be stopped and the candidate link will only work again after you re-approve.",
                )
              )
                e.preventDefault();
            }}
          >
            <button type="submit" className="btn btn-ghost btn-sm">← Edit this interview</button>
          </form>
          <Link to={`/sessions/${token}`} className="btn btn-primary btn-sm">View session →</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="ds-light screen-enter">
      <PageHeader
        category="Interview plan"
        back={<Link to="/dashboard" className="ds-back">← Back to interviews</Link>}
        title={<span style={{ display: "inline-flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
          {row.candidate_name}
          <StatusPill status={row.status} />
        </span>}
        sub={row.role}
        actions={<>
          <Link to={`/schedule?token=${token}`} className="btn btn-sm">Edit details</Link>
          <button
            type="button"
            disabled={busy === "approve"}
            onClick={() => {
              // If plugins were chosen but not validated (green), don't start the
              // interview — pop a bottom-right toast telling the operator to
              // validate. No plugin chosen → approval proceeds (no scoring).
              if (!evalPlan.ready) {
                toast.error("Validate the evaluation plugins before starting the interview (Evaluation → Validate).");
                return;
              }
              void run("approve", async () => {
                const r = await approveCadence(token, yaml);
                // A role's cadence template has no candidate, so there is no
                // link to hand out — approving it means "a person reviewed this
                // plan", which unlocks creating the role's interviews. Go back
                // to the role rather than showing an interview-link screen.
                if (r.ok && r.is_template) {
                  window.location.assign(
                    // NB: the route is /interview (singular) — /interviews
                    // matches nothing and renders a blank page.
                    r.role_public_id ? `/app/shortlist/${r.role_public_id}/interview` : "/app/shortlist",
                  );
                  return;
                }
                // An interview created from a Shortlist role goes back to that
                // role, which lists every candidate and every link — a single
                // link screen would strand the admin outside the flow they
                // were in. A one-off scheduled interview has no role, so it
                // still shows its own links below.
                if (r.ok && r.candidate_link && r.role_public_id) {
                  window.location.assign(`/app/shortlist/${r.role_public_id}/interview`);
                  return;
                }
                if (r.ok && r.candidate_link) {
                  setApproved({
                    candidate: r.candidate_link,
                    email: r.candidate_email ?? null,
                  });
                } else if (r.needs_eval_validation) {
                  // Server backstop (e.g. saved plan differs from the edited one).
                  toast.error(r.error || "Validate the evaluation plugins before starting.");
                } else {
                  toast.error(r.error || "Approve failed.");
                }
              });
            }}
            className="btn btn-primary"
          >
            {busy === "approve"
              ? (isTemplate ? "Approving…" : "Launching…")
              : (isTemplate ? "Approve cadence" : "Approve & generate link")}
          </button>
        </>}
      />

      {/* ── Standalone add-phase control (center, magenta). TEXT interviews
          author a written-response phase (comprehensive / transcription /
          translation / image description); VOICE interviews get the
          "Add phases" menu (Coding, Visual Scenario Analysis) — both are
          voice/video-only, so text interviews never see either. ──────────── */}
      <div style={{ display: "flex", justifyContent: "center" }}>
        {isText ? (
          <button
            type="button"
            onClick={() => setAddPhaseOpen(true)}
            className="btn"
            style={{
              background: "var(--ds-lavender)",
              color: "var(--ds-accent-ink)",
              borderColor: "transparent",
              fontWeight: 700,
            }}
          >
            + Add phase
          </button>
        ) : (
          <AddPhasesMenu
            onPickCoding={() => setCodingModalOpen(true)}
            onPickScenario={() => {
              // Reuse the SAME edit path "Edit items" on the tile already
              // uses — never open a fresh create-mode modal when one exists,
              // or saving would append a SECOND scenario phase.
              if (existingScenarioPhaseId) {
                setEditScenarioPhaseId(existingScenarioPhaseId);
              } else {
                setScenarioModalOpen(true);
              }
            }}
            hasCodingPhase={(parsed?.phases ?? []).some((p) => (p.coding_question_ids?.length ?? 0) > 0)}
            hasScenarioPhase={existingScenarioPhaseId != null}
            disableScenario={isText}
          />
        )}
      </div>

      {extraScenarioPhaseIds.length > 0 && (
        <p style={{ marginTop: 8, textAlign: "center", fontSize: 12.5, color: "var(--warn)" }}>
          {extraScenarioPhaseIds.length} extra Visual Scenario Analysis phase
          {extraScenarioPhaseIds.length === 1 ? "" : "s"} found ({extraScenarioPhaseIds.join(", ")}) —
          "Add phases" only edits the first one ({existingScenarioPhaseId}). Remove the extra
          {extraScenarioPhaseIds.length === 1 ? " one" : "s"} from its own tile below if it
          shouldn't be there.
        </p>
      )}

      {/* ── Tile: Customize questions ────────────────────────────────────── */}
      <CustomizeQuestionsCard
        ctx={ctx}
        yaml={yaml}
        setYaml={setYaml}
        busy={busy}
        run={run}
      />

      {/* ── Tile: Revise & Verify Cadence with AI ────────────────────────── */}
      <ReviseVerifyChat token={token} yaml={yaml} setYaml={setYaml} busy={busy} run={run} />

      {/* Cadence raw YAML editor (full-width, above the tile list). Explicit
          save/cancel — keystrokes only touch `rawDraft`; `yaml` (the global
          source Approve/Validate/Revise read) updates only on Save. */}
      {showRawYaml && (() => {
        const draftParsed = parseCadenceYaml(rawDraft);
        const parseOk = draftParsed !== null;
        const dirty = rawDraft !== rawSnapshot.current;
        return (
          <div className="card" style={{ marginTop: 16, padding: 16 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <span style={sectionLabel}>Cadence YAML</span>
            </div>
            <textarea
              value={rawDraft}
              onChange={(e) => setRawDraft(e.target.value)}
              rows={18}
              className="input mono"
              style={{ marginTop: 8, fontSize: 12 }}
              spellCheck={false}
            />
            {!parseOk && (
              <p style={{ marginTop: 4, fontSize: 12, color: "var(--warn)" }}>
                YAML parse error — fix before saving.
              </p>
            )}
            <div style={{ marginTop: 8, display: "flex", gap: 8 }}>
              <button
                type="button"
                disabled={!dirty || !parseOk}
                onClick={saveRawYaml}
                className="btn btn-sm"
                style={{ background: "var(--ds-lavender)", color: "var(--ds-accent-ink)", borderColor: "transparent", fontWeight: 600 }}
              >
                Save changes
              </button>
              <button type="button" onClick={() => setShowRawYaml(false)} className="btn btn-ghost btn-sm">
                Cancel
              </button>
            </div>
          </div>
        );
      })()}

      {/* Add-phase modal. Mounted at page level so it overlays the entire
          review screen. TEXT → written-response authoring; VOICE → coding
          picker. */}
      {isText ? (
        <AddPhaseModal
          open={addPhaseOpen || editPhaseId != null}
          onClose={() => {
            setAddPhaseOpen(false);
            setEditPhaseId(null);
          }}
          yaml={yaml}
          token={token}
          onYamlChange={setYaml}
          editPhase={
            editPhaseId != null
              ? (parsed?.phases ?? []).find((p) => p.id === editPhaseId) ?? null
              : null
          }
        />
      ) : (
        <>
          <CodingPhaseModal
            open={codingModalOpen}
            onClose={() => setCodingModalOpen(false)}
            yaml={yaml}
            token={token}
            onYamlChange={setYaml}
          />
          <ScenarioPhaseModal
            open={scenarioModalOpen || editScenarioPhaseId != null}
            onClose={() => {
              setScenarioModalOpen(false);
              setEditScenarioPhaseId(null);
            }}
            yaml={yaml}
            token={token}
            onYamlChange={setYaml}
            editPhaseId={editScenarioPhaseId}
          />
        </>
      )}

      {/* ── 2-column split: CADENCE (teal) on the left, EVALUATION RUBRIC
          (magenta) on the right. Sticky column headers ride the viewport so
          the columns stay distinguishable while scrolling long phase lists.
          Each tile element below carries its column's accent stripe. */}
      {parsed?.phases ? (
        <div className="cr-grid" style={{ marginTop: 20, display: "grid", gridTemplateColumns: "minmax(0, 1fr) minmax(0, 1fr)", gap: 16 }}>
          {/* Column header — CADENCE */}
          <div
            className="card cr-colhead"
            style={{
              position: "sticky", top: 0, zIndex: 10,
              padding: "10px 14px",
              background: "var(--ink-2)",
              borderLeft: "4px solid var(--cadence)",
              display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{
                fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.18em",
                textTransform: "uppercase", fontWeight: 700, color: "var(--cadence)",
              }}>Cadence</span>
              <span className="muted-3" style={{ fontSize: 11 }}>
                {sumPhaseDurations(parsed.phases) > 0 && `${formatPhaseDuration(sumPhaseDurations(parsed.phases))} · `}
                {parsed.phases.length} phases
              </span>
            </div>
            <button
              type="button"
              onClick={toggleRawYaml}
              className="btn btn-ghost btn-sm"
              style={{ borderColor: showRawYaml ? "var(--cadence)" : undefined, color: showRawYaml ? "var(--cadence)" : undefined }}
            >
              {showRawYaml ? "Hide raw YAML" : "Edit raw YAML"}
            </button>
          </div>

          {/* Column header — EVALUATION RUBRIC */}
          <div
            className="card cr-colhead"
            style={{
              position: "sticky", top: 0, zIndex: 10,
              padding: "10px 14px",
              background: "var(--ink-2)",
              borderLeft: "4px solid var(--magenta)",
              display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12,
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{
                fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.18em",
                textTransform: "uppercase", fontWeight: 700, color: "var(--ds-accent-ink)",
              }}>Evaluation</span>
              {/* Outcomes (errors/warnings/success) go to the bottom-right toast,
                  never inline here — the evaluation box stays clean. */}
            </div>
            <EvalPlanToolbar api={evalPlan} />
          </div>

          {/* Phase timeline — spans BOTH columns (the old rubric column was
              removed, so the Gantt fills the full width for a cleaner header
              row). The per-phase plugin cards live in the rows below. */}
          {parsed.phases.length > 0 && (
            <div style={{ gridColumn: "1 / -1" }}>
              <CadenceGantt parsed={parsed} hoveredPhase={hoveredPhase} onHover={setHoveredPhase} />
            </div>
          )}

          {/* Per-phase rows: cadence block (left) + its evaluation plugin card
              (right), row-aligned by the 2-column grid. The plugin card scrolls
              internally so a long config never blows up the row height. */}
          {parsed.phases.map((p, i) => (
            <PhaseTile
              key={`${p.id || "phase"}-${i}`}
              phase={p}
              index={i}
              hoveredPhase={hoveredPhase}
              onHover={setHoveredPhase}
              evalCard={<EvalPhaseCard api={evalPlan} phaseId={p.id || ""} />}
              // Written-response phases (TEXT) and Visual Scenario Analysis
              // phases (VOICE) are editable in place (add / modify / delete /
              // reorder their questions or items); everything else stays
              // raw-YAML/AI-editor.
              onEdit={
                isText && p.written_response && p.id
                  ? () => setEditPhaseId(p.id as string)
                  : !isText && (p.scenario_items?.length ?? 0) > 0 && p.id
                    ? () => setEditScenarioPhaseId(p.id as string)
                    : undefined
              }
              editKind={isText ? "written" : "scenario"}
            />
          ))}
        </div>
      ) : (
        <p style={{ marginTop: 16, fontSize: 14, color: "var(--warn)" }}>
          YAML parse error — fix it in the raw editor above (toggle "Edit raw YAML").
        </p>
      )}
    </div>
  );
}

// ── Controls bar ─────────────────────────────────────────────────────────────

// ── Customize questions card — standalone tile with heading ──────────────────
// Hosts the static/adaptive Customizer; teal left border = cadence-side.
function CustomizeQuestionsCard({
  ctx,
  yaml,
  setYaml,
  busy,
  run,
}: {
  ctx: CadenceContext;
  yaml: string;
  setYaml: (y: string) => void;
  busy: string | null;
  run: <T>(name: string, fn: () => Promise<T>) => Promise<T | undefined>;
}) {
  return (
    <section className="card" style={{
      marginTop: 16, padding: 16,
      borderLeft: "3px solid var(--cadence)",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
        <h2 style={{ fontSize: 14.5, fontWeight: 700, margin: 0, color: "var(--text)" }}>
          Customize questions
        </h2>
        <span className="muted-3" style={{ fontSize: 11.5 }}>
          Pick a pool, set difficulty, count + topics, then apply
        </span>
      </div>
      <CustomizerInline ctx={ctx} yaml={yaml} setYaml={setYaml} busy={busy} run={run} />
    </section>
  );
}

// ── Revise & Verify Cadence with AI ──────────────────────────────────────────
// A chat, not a one-shot input, because the ROUTER agent can answer a turn with
// a QUESTION instead of an edit (ambiguous ask) or a capability note (ask beyond
// what cadence editing does). Those need somewhere to live, and answering one
// needs to carry the `clause_id` it belongs to — see `ReviseResult` in
// lib/cadenceReview.ts. Teal left border: still a cadence-side action.

// Written without `id` so the union stays discriminable — `Omit<Union, "id">`
// does NOT distribute over a union, it collapses it to the shared keys.
type ChatMsgBody =
  | { role: "admin"; text: string }
  // Resolved clauses: the yaml is ALREADY updated; these are the code-derived
  // change lines, so the bubble can never disagree with the plan.
  | { role: "applied"; lines: string[] }
  // A ROUTER question. `clauseId` is what an answer must be tagged with.
  | { role: "question"; clauseId: string; text: string; question: string; options: string[] }
  | { role: "info"; text: string }        // out-of-capability note
  | { role: "note"; text: string }        // VALIDATING agent shortfall
  | { role: "error"; text: string };

type ChatMsg = ChatMsgBody & { id: number };

function ReviseVerifyChat({
  token,
  yaml,
  setYaml,
  busy,
  run,
}: {
  token: string;
  yaml: string;
  setYaml: (y: string) => void;
  busy: string | null;
  run: <T>(name: string, fn: () => Promise<T>) => Promise<T | undefined>;
}) {
  const toast = useToast();
  const [feedback, setFeedback] = useState("");
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  // Questions still awaiting an answer, keyed by clause_id. A plain typed reply
  // answers the OLDEST open one; a chip answers the question it belongs to.
  const [open, setOpen] = useState<ReviseQuestion[]>([]);
  const nextId = useRef(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  // Standard chat-scroll manners: only auto-scroll if the admin is already at
  // the bottom, so a new message can't yank them out of something they're reading.
  const stick = useRef(true);

  const push = (msgs: ChatMsgBody[]) =>
    setMessages((prev) => [...prev, ...msgs.map((m) => ({ ...m, id: nextId.current++ }))]);

  useEffect(() => {
    if (stick.current && scrollRef.current) {
      scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
    }
  }, [messages]);

  // One turn: send `text` (plus any answered clarifications) and fold the
  // mixed-outcome response into the transcript.
  const send = (text: string, answeringClauseId?: string) => {
    const body = text.trim();
    if (!body) return;

    // An answer consumes the question it belongs to; a fresh instruction
    // leaves open questions open (they're independent clauses).
    const answered: ReviseClarification[] = [];
    let stillOpen = open;
    const target = answeringClauseId
      ? open.find((q) => q.clause_id === answeringClauseId)
      : open[0];
    if (target) {
      answered.push({
        clause_id: target.clause_id,
        text: target.text,
        question: target.question,
        answer: body,
      });
      stillOpen = open.filter((q) => q.clause_id !== target.clause_id);
      setOpen(stillOpen);
    }

    push([{ role: "admin", text: body }]);
    setFeedback("");
    stick.current = true;

    void run("revise", async () => {
      // When this message is purely an answer, `feedback` is empty — the router
      // re-classifies the clause from the clarification instead.
      const r = await reviseCadence(yaml, target ? "" : body, token, answered);
      if (!r.ok) {
        push([{ role: "error", text: r.error || "Revise failed." }]);
        toast.error(r.error || "Revise failed.");
        return;
      }

      const out: ChatMsgBody[] = [];
      if (r.changed && r.yaml) {
        setYaml(r.yaml);
        out.push({
          role: "applied",
          lines: r.applied?.length ? r.applied : ["Updated the plan"],
        });
      }
      for (const q of r.questions ?? []) {
        out.push({
          role: "question", clauseId: q.clause_id, text: q.text,
          question: q.question, options: q.options ?? [],
        });
      }
      for (const o of r.out_of_scope ?? []) out.push({ role: "info", text: o.message });
      for (const n of r.notes ?? []) {
        out.push({ role: "note", text: `“${n.text}” — ${n.why}` });
      }
      if (!out.length) out.push({ role: "info", text: "No change was needed." });
      push(out);

      if (r.questions?.length) setOpen([...stillOpen, ...r.questions]);
      if (r.changed) toast.success("Cadence revised.");
    });
  };

  const thinking = busy === "revise";
  const placeholder = open.length
    ? `Answer: ${open[0].question}`
    : "e.g. make the warm-up 3 minutes, or ask about a project from the candidate's resume";

  return (
    <section className="card" style={{
      marginTop: 16, padding: 16,
      borderLeft: "3px solid var(--cadence)",
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
        <h2 style={{ fontSize: 14.5, fontWeight: 700, margin: 0, color: "var(--text)" }}>
          Revise &amp; Verify Cadence with AI
        </h2>
        {open.length > 0 && (
          <span className="pill" style={{ fontSize: 11 }}>
            {open.length} question{open.length > 1 ? "s" : ""} open
          </span>
        )}
      </div>

      {/* Transcript. Grows with the conversation (min-height 0 while empty, so
          the tile stays compact until there's something to show) and starts
          scrolling instead of pushing the page down past maxHeight. */}
      {(messages.length > 0 || thinking) && (
        <div
          ref={scrollRef}
          onScroll={(e) => {
            const el = e.currentTarget;
            stick.current = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
          }}
          style={{
            maxHeight: 340, overflowY: "auto", display: "flex", flexDirection: "column",
            gap: 8, marginBottom: 10, paddingRight: 4,
          }}
        >
          {messages.map((m) => <ReviseBubble key={m.id} msg={m} onAnswer={send} busy={thinking} />)}
          {thinking && (
            <div className="muted-3" style={{ fontSize: 12, fontStyle: "italic" }}>
              Working through your request…
            </div>
          )}
        </div>
      )}

      <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8 }}>
        <input
          value={feedback}
          onChange={(e) => setFeedback(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              send(feedback);
            }
          }}
          placeholder={placeholder}
          className="input"
          style={{ flex: "1 1 280px", minWidth: 200 }}
        />
        <button
          type="button"
          disabled={!feedback.trim() || thinking}
          onClick={() => send(feedback)}
          className="btn btn-sm"
        >
          {thinking ? "Working…" : open.length ? "Answer" : "Revise with AI"}
        </button>
        <button
          type="button"
          disabled={busy === "validate"}
          onClick={() =>
            run("validate", async () => {
              const r = await validateCadence(yaml);
              if (r.ok) toast.success("Cadence is valid.");
              else toast.error(r.error || "Invalid cadence.");
            })
          }
          className="btn btn-ghost btn-sm"
        >
          {busy === "validate" ? "Validating…" : "Validate"}
        </button>
      </div>
    </section>
  );
}

// One transcript row. Each outcome gets its own visual weight: an applied edit
// reads as a done list, a question as something needing input (with its options
// as one-click answers), a capability note as neutral info, a validator
// shortfall as a warning that the edit landed only partly.
function ReviseBubble({
  msg,
  onAnswer,
  busy,
}: {
  msg: ChatMsg;
  onAnswer: (text: string, clauseId?: string) => void;
  busy: boolean;
}) {
  const base: CSSProperties = {
    fontSize: 12.5, lineHeight: 1.5, padding: "7px 10px", borderRadius: 8,
    border: "1px solid var(--border)", maxWidth: "92%",
  };

  if (msg.role === "admin") {
    return (
      <div style={{ ...base, alignSelf: "flex-end", background: "var(--bg-2)", color: "var(--text)" }}>
        {msg.text}
      </div>
    );
  }

  if (msg.role === "applied") {
    return (
      <div style={{ ...base, borderLeft: "3px solid var(--cadence)" }}>
        <div style={{ fontWeight: 600, marginBottom: msg.lines.length ? 4 : 0 }}>Applied</div>
        <ul style={{ margin: 0, paddingLeft: 16 }}>
          {msg.lines.map((l, i) => <li key={i} style={{ fontFamily: "var(--mono)", fontSize: 11.5 }}>{l}</li>)}
        </ul>
      </div>
    );
  }

  if (msg.role === "question") {
    return (
      <div style={{ ...base, borderLeft: "3px solid var(--warn, #d9a13b)" }}>
        <div style={{ marginBottom: msg.options.length ? 6 : 0 }}>{msg.question}</div>
        {msg.options.length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {msg.options.map((o) => (
              <button
                key={o}
                type="button"
                disabled={busy}
                // A chip is just a pre-filled reply — same path a typed answer
                // takes, tagged with the clause it belongs to.
                onClick={() => onAnswer(o, msg.clauseId)}
                className="btn btn-ghost btn-sm"
                style={{ fontSize: 11.5, padding: "3px 8px" }}
              >
                {o}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  if (msg.role === "note") {
    return (
      <div style={{ ...base, borderLeft: "3px solid var(--warn, #d9a13b)", color: "var(--text-2)" }}>
        <span style={{ fontWeight: 600 }}>Couldn't fully apply: </span>{msg.text}
      </div>
    );
  }

  if (msg.role === "error") {
    return (
      <div style={{ ...base, borderLeft: "3px solid var(--danger, #d05a5a)", color: "var(--text)" }}>
        {msg.text}
      </div>
    );
  }

  return <div style={{ ...base, color: "var(--text-2)" }}>{msg.text}</div>;
}

// ── Customizer (inline form used inside CustomizeQuestionsCard) ──────────────

function CustomizerInline({
  ctx,
  yaml,
  setYaml,
  busy,
  run,
}: {
  ctx: CadenceContext;
  yaml: string;
  setYaml: (y: string) => void;
  busy: string | null;
  run: <T>(name: string, fn: () => Promise<T>) => Promise<T | undefined>;
}) {
  const toast = useToast();
  const pools = ctx.pool_files ?? [];
  const [mode, setMode] = useState<"static" | "adaptive">("static");
  const [difficulty, setDifficulty] = useState("medium");
  const [startDifficulty, setStartDifficulty] = useState("easy");
  const [phase, setPhase] = useState(ctx.default_phase_id);
  const [pool, setPool] = useState(pools[0] || "");
  const [count, setCount] = useState(3);
  const [topics, setTopics] = useState<Set<string>>(new Set());

  if (ctx.pool_dir_missing || !pools.length) {
    return (
      <p className="muted-3" style={{ fontSize: 12 }}>
        No question pools available — add YAML pools to enable the customizer.
      </p>
    );
  }

  const poolTopics = ctx.pool_topics[pool] ?? ctx.default_topics;
  const toggleTopic = (t: string) =>
    setTopics((prev) => {
      const next = new Set(prev);
      if (next.has(t)) next.delete(t);
      else next.add(t);
      return next;
    });

  const applyResult = (r: { ok: boolean; yaml?: string; warnings?: string[]; error?: string }) => {
    if (r.ok && r.yaml) {
      setYaml(r.yaml);
      toast.success(r.warnings?.length ? `Applied. ${r.warnings.join(" ")}` : "Questions applied to cadence.");
    } else {
      toast.error(r.error || "Customize failed.");
    }
  };

  return (
    <div>
      <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8 }}>
        <div style={{ display: "flex", gap: 6 }}>
          {(["static", "adaptive"] as const).map((m) => (
            <button key={m} type="button" onClick={() => setMode(m)} className={`chip ${mode === m ? "on" : ""}`}>
              {m === "static" ? "Fixed difficulty" : "Adaptive"}
            </button>
          ))}
        </div>
        <label className="field-label" style={{ marginBottom: 0, display: "flex", alignItems: "center", gap: 6, fontSize: 12 }}>
          Phase
          <select value={phase} onChange={(e) => setPhase(e.target.value)} className="input" style={{ padding: "4px 8px" }}>
            {ctx.phase_ids.map((p) => (
              <option key={p} value={p}>{ctx.pool_labels?.[p] ?? p}</option>
            ))}
          </select>
        </label>
        <label className="field-label" style={{ marginBottom: 0, display: "flex", alignItems: "center", gap: 6, fontSize: 12 }}>
          Pool
          <select value={pool} onChange={(e) => setPool(e.target.value)} className="input" style={{ padding: "4px 8px" }}>
            {pools.map((p) => (
              <option key={p} value={p}>{ctx.pool_labels?.[p] ?? p}</option>
            ))}
          </select>
        </label>
      </div>

      {mode === "static" ? (
        <>
          <div className="muted" style={{ marginTop: 10, display: "flex", flexWrap: "wrap", alignItems: "center", gap: 12, fontSize: 13 }}>
            <span>Difficulty:</span>
            {["easy", "medium", "hard"].map((d) => (
              <label key={d} style={{ display: "flex", alignItems: "center", gap: 5 }}>
                <input type="radio" name="difficulty" checked={difficulty === d} onChange={() => setDifficulty(d)} />
                {d}
              </label>
            ))}
            <label style={{ display: "flex", alignItems: "center", gap: 5 }}>
              Count
              <input
                type="number"
                min={1}
                max={10}
                value={count}
                onChange={(e) => setCount(Number(e.target.value) || 1)}
                className="input"
                style={{ width: 56, padding: "5px 8px" }}
              />
            </label>
          </div>
          {poolTopics.length > 0 && (
            <div style={{ marginTop: 8, display: "flex", flexWrap: "wrap", gap: 6 }}>
              {poolTopics.map((t) => (
                <button key={t} type="button" onClick={() => toggleTopic(t)} className={`chip ${topics.has(t) ? "on" : ""}`}>
                  {t}
                </button>
              ))}
            </div>
          )}
          <button
            type="button"
            disabled={busy === "customize"}
            onClick={() =>
              run("customize", async () => {
                const r = await customizeCadence(ctx.row.token, {
                  yaml,
                  difficulty,
                  phase,
                  pool_file: pool,
                  count,
                  topics: [...topics].join(",") || undefined,
                });
                applyResult(r);
              })
            }
            className="btn btn-sm"
            style={{ marginTop: 10 }}
          >
            {busy === "customize" ? "Applying…" : "Apply to cadence"}
          </button>
        </>
      ) : (
        <>
          <div className="muted" style={{ marginTop: 10, display: "flex", flexWrap: "wrap", alignItems: "center", gap: 12, fontSize: 13 }}>
            <span>Start difficulty:</span>
            {["easy", "medium", "hard"].map((d) => (
              <label key={d} style={{ display: "flex", alignItems: "center", gap: 5 }}>
                <input type="radio" name="startDifficulty" checked={startDifficulty === d} onChange={() => setStartDifficulty(d)} />
                {d}
              </label>
            ))}
          </div>
          <p className="muted-3" style={{ marginTop: 4, fontSize: 12 }}>
            Loads the whole pool; difficulty escalates/de-escalates from the verifier's read of each answer.
          </p>
          <button
            type="button"
            disabled={busy === "adaptive"}
            onClick={() =>
              run("adaptive", async () => {
                const r = await customizeAdaptive(ctx.row.token, {
                  yaml,
                  phase,
                  pool_file: pool,
                  start_difficulty: startDifficulty,
                });
                applyResult(r);
              })
            }
            className="btn btn-sm"
            style={{ marginTop: 10 }}
          >
            {busy === "adaptive" ? "Enabling…" : "Enable adaptive questions"}
          </button>
        </>
      )}
    </div>
  );
}

// ── Gantt: stacked horizontal bar of phase durations ─────────────────────────
// Pure derivation from `parsed`, so any yaml mutation flows here for free.
// Each segment width is `(phase.duration_s / total) * 100%`. Total falls back
// to the sum of phase budgets when the top-level field is missing (e.g.
// mid-edit yaml). Segments narrower than ~8% drop their inline label rather
// than rendering ellipsed text.

function CadenceGantt({
  parsed,
  hoveredPhase,
  onHover,
}: {
  parsed: ParsedCadence;
  hoveredPhase: number | null;
  onHover: (i: number | null) => void;
}) {
  const phases = parsed.phases ?? [];
  // Total = Σ phase durations (NOT the declared total_duration_s, which can be
  // stale) so the headline minutes and the segment widths (dur/total) agree.
  const total = sumPhaseDurations(phases);

  // `tipSeg` = the segment the pointer is physically over; it drives ONLY the
  // tooltip fade. Kept local (not the lifted hoveredPhase) so hovering a phase
  // card — which sets the shared hoveredPhase — doesn't pop the timeline tooltip
  // with stale text. `tip` holds the label + center so it stays put on fade-out.
  const [tipSeg, setTipSeg] = useState<number | null>(null);
  const [tip, setTip] = useState<{ left: number; label: string } | null>(null);

  if (!total || phases.length === 0) return null;

  // Precompute each segment's width and its center offset (both as % of the
  // bar) so the tooltip can be centered above the hovered segment.
  let acc = 0;
  const segs = phases
    .map((p, i) => {
      const dur = p.duration_s ?? 0;
      const pct = (dur / total) * 100;
      const left = acc + pct / 2;
      acc += pct;
      return { p, i, dur, pct, left };
    })
    .filter((s) => s.pct > 0);

  return (
    <div className="card" style={{ marginTop: 16, padding: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <span style={sectionLabel}>Timeline</span>
        <span className="muted-3" style={{ fontSize: 11, fontFamily: "var(--mono)" }}>
          {formatPhaseDuration(total)} · {phases.length} phase{phases.length === 1 ? "" : "s"}
        </span>
      </div>

      {/* The bar (relative so the hover tooltip can float above it) */}
      <div style={{ position: "relative" }}>
        <div style={{
          display: "flex",
          height: 24,
          borderRadius: 6,
          overflow: "hidden",
          border: "1px solid var(--line)",
        }}>
          {segs.map(({ p, i, dur, pct, left }) => {
            const label = (p.id || "phase").replace(/_/g, " ");
            const isCoding = Array.isArray(p.coding_question_ids) && p.coding_question_ids.length > 0;
            const isScenario = Array.isArray(p.scenario_items) && p.scenario_items.length > 0;
            const kindSuffix = isCoding ? " (coding)" : isScenario ? " (scenario)" : "";
            return (
              <div
                key={`${p.id || "phase"}-${i}-seg`}
                onMouseEnter={() => {
                  setTipSeg(i);
                  onHover(i);
                  setTip({
                    left,
                    label: `${label} — ${formatPhaseDuration(dur)}${kindSuffix}`,
                  });
                }}
                onMouseLeave={() => {
                  setTipSeg(null);
                  onHover(null);
                }}
                style={{
                  width: `${pct}%`,
                  background: phaseColor(i),
                  cursor: "default",
                  filter: hoveredPhase === i ? "brightness(1.35)" : undefined,
                  transition: "filter 0.15s ease",
                }}
              />
            );
          })}
        </div>

        {/* Custom hover tooltip — floats centered above the hovered segment.
            Opaque --ink-2 surface (translucent --panel would show the bar
            through it); subtle --line border + soft shadow read as a card. */}
        <div
          style={{
            position: "absolute",
            left: `${tip?.left ?? 50}%`,
            bottom: "calc(100% + 8px)",
            transform: "translateX(-50%)",
            padding: "5px 9px",
            borderRadius: 8,
            border: "1px solid var(--line)",
            background: "var(--ink-2)",
            color: "var(--text)",
            fontSize: 11.5,
            fontWeight: 600,
            whiteSpace: "nowrap",
            boxShadow: "0 4px 14px rgba(0,0,0,0.35)",
            opacity: tipSeg != null ? 1 : 0,
            transition: "opacity 0.15s ease",
            pointerEvents: "none",
            zIndex: 20,
          }}
        >
          {tip?.label}
        </div>
      </div>

      {/* Per-segment labels under the bar (truncate gracefully when narrow) */}
      <div style={{ display: "flex", marginTop: 6, gap: 2 }}>
        {phases.map((p, i) => {
          const dur = p.duration_s ?? 0;
          const pct = (dur / total) * 100;
          if (pct <= 0) return null;
          return (
            <div
              key={`${p.id || "phase"}-${i}-lbl`}
              style={{
                width: `${pct}%`,
                fontSize: 10.5,
                color: "var(--text-3)",
                textAlign: "center",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {(p.id || "phase").replace(/_/g, " ")}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── Per-phase tile (cadence block on the left, evaluation card on the right) ─

// PhaseTile renders TWO sibling slots (cadence left, evaluation right) directly
// into the parent 2-column grid. The left slot is the cadence phase block; the
// right slot is this phase's evaluation plugin card (passed in as `evalCard`),
// row-aligned with the cadence block. The outer 3px stripe (teal / magenta)
// carries the column identity.
function PhaseTile({
  phase,
  index,
  evalCard,
  hoveredPhase,
  onHover,
  onEdit,
  editKind = "written",
}: {
  phase: ParsedPhase;
  index: number;
  evalCard: ReactNode;
  hoveredPhase: number | null;
  onHover: (i: number | null) => void;
  /** Provided only for phases this screen can edit in place (written-response
   *  or Visual Scenario Analysis). */
  onEdit?: () => void;
  /** Which "Edit …" label/caption to show — see `onEdit`. */
  editKind?: "written" | "scenario";
}) {
  const questionCount = (phase.question_pool || []).length;
  const scenarioCount = (phase.scenario_items || []).length;
  return (
    <>
      <div style={{
        minWidth: 0,
        borderLeft: "3px solid var(--cadence)",
        paddingLeft: 10,
      }}>
        <CadencePhaseBlock phase={phase} index={index} hovered={hoveredPhase} onHover={onHover} />
        {onEdit && editKind === "written" && (
          <div style={{ marginTop: 6, display: "flex", alignItems: "center", gap: 8 }}>
            <button type="button" onClick={onEdit} className="btn btn-ghost btn-sm">
              Edit questions
            </button>
            <span className="muted-3" style={{ fontSize: 11.5 }}>
              {questionCount} written question{questionCount === 1 ? "" : "s"} ·{" "}
              {phase.written_response?.question_type?.replace(/_/g, " ") || "comprehensive"}
            </span>
          </div>
        )}
        {onEdit && editKind === "scenario" && (
          <div style={{ marginTop: 6, display: "flex", alignItems: "center", gap: 8 }}>
            <button type="button" onClick={onEdit} className="btn btn-ghost btn-sm">
              Edit items
            </button>
            <span className="muted-3" style={{ fontSize: 11.5 }}>
              {scenarioCount} scenario item{scenarioCount === 1 ? "" : "s"}
            </span>
          </div>
        )}
      </div>
      <div style={{
        minWidth: 0,
        borderLeft: "3px solid var(--magenta)",
        paddingLeft: 10,
      }}>
        {evalCard}
      </div>
    </>
  );
}

// ── Shared bits ──────────────────────────────────────────────────────────────

function LinkRow({ label, url, copied, onCopy }: { label: string; url: string; copied: boolean; onCopy: () => void }) {
  return (
    <div className="card" style={{ padding: 12 }}>
      <div style={sectionLabel}>{label}</div>
      <div style={{ marginTop: 6, display: "flex", alignItems: "center", gap: 8 }}>
        <code className="mono" style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", borderRadius: 8, background: "var(--panel-2)", padding: "5px 8px", fontSize: 12, color: "var(--text-2)" }}>{url}</code>
        <button type="button" onClick={onCopy} className="btn btn-ghost btn-sm">{copied ? "Copied ✓" : "Copy"}</button>
      </div>
    </div>
  );
}

