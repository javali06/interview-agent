// The approvals queue — question pools waiting on a step this person can sign.
//
// The server has already filtered it by the same refusals `approve` applies
// (you submitted it, wrong team, you signed an earlier step), so every row here
// is actionable. A queue you cannot act on is worse than an empty one.
import { useCallback, useEffect, useState } from "react";
import { PageHeader } from "../components/PageHeader";
import { LoadingBlock } from "../components/LoadingBlock";
import { Link } from "react-router-dom";
import { useToast } from "../components/Toaster";
import { ApiError } from "../lib/api";
import { can, usePermissions } from "../lib/auth";
import {
  approvalsQueue, approvePool, returnPool, type QueueItem,
} from "../lib/questionPools";

export function PoolApprovals() {
  const toast = useToast();
  const { data: me } = usePermissions();
  const [queue, setQueue] = useState<QueueItem[] | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      setQueue((await approvalsQueue()).queue);
    } catch (e) {
      toast.error((e as ApiError).message || "Could not load the queue.");
      setQueue([]);
    }
  }, [toast]);

  useEffect(() => { void refresh(); }, [refresh]);

  const act = async (item: QueueItem, label: string, fn: () => Promise<unknown>) => {
    setBusy(item.pool_id);
    try {
      await fn();
      toast.success(label);
      await refresh();
    } catch (e) {
      toast.error((e as ApiError).message || "That did not work.");
    } finally {
      setBusy(null);
    }
  };

  const onReturn = (item: QueueItem) => {
    const comment = window.prompt("Why are you sending this back? The author sees this.");
    if (comment === null) return;
    if (!comment.trim()) {
      toast.error("A reason is required — the author cannot act on a blank return.");
      return;
    }
    void act(item, "Returned to the author.", () => returnPool(item.pool_id, comment));
  };

  if (me && !can(me, "pools.approve")) {
    return (
      <div className="ds-light screen-enter">
        <PageHeader category="Question pools" title="Approvals" sub="You are not a checker for any team." />
      </div>
    );
  }

  return (
    <div className="ds-light screen-enter">
      <PageHeader
        category="Question pools"
        title="Approvals"
        sub={<>
          Question pools waiting on you. Nothing here is visible to a candidate
          yet — approving is what makes a pool live.
        </>}
      />

      {queue === null ? (
        <LoadingBlock label="Loading…" />
      ) : queue.length === 0 ? (
        <div className="ds-empty">
          <h2 style={{ fontSize: 17, fontWeight: 600, color: "var(--text)" }}>Nothing waiting</h2>
          <p className="muted" style={{ marginTop: 8, fontSize: 14 }}>
            When someone submits a pool for a team you check, it appears here.
          </p>
        </div>
      ) : (
        <div style={{ display: "grid", gap: 12 }}>
          {queue.map((item) => (
            <div key={item.pool_id} className="card"
                 style={{ padding: 16, display: "grid", gap: 10 }}>
              <div style={{ display: "flex", gap: 10, alignItems: "baseline", flexWrap: "wrap" }}>
                <Link to={`/question-pools/${item.pool_id}`}
                      className="link" style={{ fontSize: 16, fontWeight: 600 }}>
                  {item.pool_name}
                </Link>
                <span className="pill" style={{ padding: "2px 9px", fontSize: 11 }}>
                  {item.team === "*" ? "All teams" : item.team}
                </span>
                <span className="muted-3" style={{ fontSize: 12, marginLeft: "auto" }}>
                  {item.question_count} question{item.question_count === 1 ? "" : "s"}
                </span>
              </div>

              <div className="muted" style={{ fontSize: 13 }}>
                Submitted by <strong>{item.submitted_by}</strong> · waiting on{" "}
                <strong>{item.step.name || `step ${item.step.step_no}`}</strong>
              </div>

              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {/* The primary action is now REVIEW, not approve: judging 40
                    questions from a queue row means approving content you have
                    not read. The review screen is where the decision belongs;
                    Approve stays for the case where you already know. */}
                <Link to={`/question-pools/${item.pool_id}/review`}
                      className="btn btn-primary btn-sm" style={{ textDecoration: "none" }}>
                  Review {item.question_count} question{item.question_count === 1 ? "" : "s"}
                </Link>
                <button type="button" className="btn btn-ghost btn-sm"
                        disabled={busy === item.pool_id}
                        onClick={() => void act(item, "Approved.",
                                                () => approvePool(item.pool_id))}>
                  Approve all
                </button>
                <button type="button" className="btn btn-ghost btn-sm"
                        disabled={busy === item.pool_id}
                        onClick={() => onReturn(item)}>
                  Return
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
