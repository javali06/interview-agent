import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  useEvaluate,
  useMermaid,
  useReviseEval,
  useScorecard,
  useSessionDetail,
  type CodingPerf,
  type CodingTestResult,
  type Evaluation,
  type LlmCall,
  type Phase,
  type PerModel,
  type SetupPerModel,
  type Scorecard,
  type SessionDetail,
  type SessionRow,
  type Totals,
  type Turn,
} from "../lib/sessionDetail";
import { useArchiveSession, useDeleteSession } from "../lib/sessions";
import { StatusPill } from "../components/StatusPill";
import { PageHeader } from "../components/PageHeader";
import { LoadingBlock } from "../components/LoadingBlock";
import { bandClasses, fmtTs, score10Classes } from "../lib/format";
import { ApiError, getJSON } from "../lib/api";
import { parseCadenceYaml } from "../lib/cadence";
import { CadencePhaseBlock } from "../components/CadencePhaseBlock";
import BenchmarkPanel from "../components/BenchmarkPanel";
import type { ReviewApi } from "../components/eval-views/types";
import { benchmarkFromExport, fetchEvaluationView, saveReview, withdrawReview } from "../lib/evaluationExport";
import "./Session.css";

const DIM_LABELS: Record<string, string> = {
  communication_clarity: "Communication & clarity",
  technical_depth: "Technical depth",
  problem_solving: "Problem solving",
  problem_solving_process: "Problem-solving process",
  ownership_specificity: "Ownership & specificity",
  role_fit: "Role fit",
  code_quality: "Code quality",
};
const dimLabel = (k: string) =>
  DIM_LABELS[k] ?? k.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

type TabKey = "summary" | "candidate" | "trace" | "performance" | "recording" | "scorecard" | "cadence" | "observability" | "data";
const TABS: { key: TabKey; label: string }[] = [
  { key: "summary", label: "Summary" },
  { key: "candidate", label: "Candidate" },
  { key: "trace", label: "Interview Trace" },
  { key: "performance", label: "Scorecard" },
  { key: "recording", label: "Recording" },
  { key: "scorecard", label: "Integrity & Proctoring" },
  { key: "cadence", label: "Cadence" },
  { key: "observability", label: "Observability" },
  { key: "data", label: "Data & cost" },
];

// Shared prompt-drawer state lives at the Session root so any LLM call in the
// trace can open it (S4). null = closed.
export type PromptDrawerData = {
  agent: string;
  model: string | null;
  system_prompt: string | null;
  user_messages: { role: string; content: string }[] | null;
  response_text: string | null;
};

const sectionLabel: React.CSSProperties = {
  fontFamily: "var(--font)", fontSize: 11.5, fontWeight: 600, letterSpacing: "0.06em", textTransform: "uppercase", color: "var(--text-3)",
};

export function Session() {
  const { token = "" } = useParams();
  const navigate = useNavigate();
  const detail = useSessionDetail(token);
  const archive = useArchiveSession();
  const del = useDeleteSession();
  const [tab, setTab] = useState<TabKey>("summary");
  const [actionError, setActionError] = useState<string | null>(null);
  // S4 — prompt drawer (shared across all turns in the trace tab)
  const [prompt, setPrompt] = useState<PromptDrawerData | null>(null);
  // Header session-id chip: copied-state flash.
  const [copiedId, setCopiedId] = useState(false);

  if (detail.isLoading) {
    return <div className="ds-light"><LoadingBlock label="Loading session…" rows={4} /></div>;
  }
  if (detail.isError) {
    return (
      <div className="ds-light">
        <Link to="/dashboard" className="ds-back">← Back to interviews</Link>
        <p style={{ marginTop: 16, fontSize: 14, color: "var(--danger)" }}>
          {(detail.error as ApiError).message || "Failed to load session."}
        </p>
      </div>
    );
  }

  const d = detail.data as SessionDetail;
  const { row } = d;

  return (
    <div className="ds-light screen-enter">
      {/* Header */}
      <PageHeader
        category="Interviews"
        back={<Link to="/dashboard" className="ds-back">← Back to interviews</Link>}
        title={<span style={{ display: "inline-flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
          {row.candidate_name}
          <StatusPill status={row.status} />
        </span>}
        sub={<>
          <p style={{ margin: 0 }}>
            {row.role} · started {fmtTs(row.started_at || row.created_at)} · {d.totals.duration_human} · {d.totals.cost_human}
          </p>
          {/* Session ID — the ONE UUID that identifies this interview
              everywhere: Langfuse session id, events.jsonl key, and the
              blob-storage folder. Shown copyable so it's easy to pinpoint. */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 6, flexWrap: "wrap" }}>
            <span style={sectionLabel}>Session ID</span>
            <code
              className="mono"
              title="Same UUID used as the Langfuse session id, the events.jsonl key, and the blob-storage folder for this interview."
              style={{ fontSize: 12, color: "var(--text-2)", background: "var(--panel-2)", padding: "2px 8px", borderRadius: 6 }}
            >
              {row.token}
            </code>
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              onClick={() => {
                void navigator.clipboard?.writeText(row.token);
                setCopiedId(true);
                window.setTimeout(() => setCopiedId(false), 1500);
              }}
            >
              {copiedId ? "Copied ✓" : "Copy"}
            </button>
            {d.langfuse_url && (
              <a href={d.langfuse_url} target="_blank" rel="noreferrer" className="link" style={{ fontSize: 12.5 }}>
                View in Langfuse ↗
              </a>
            )}
          </div>
        </>}
        actions={<>
          {row.status !== "cancelled" && (
            <button
              type="button"
              disabled={archive.isPending}
              onClick={async () => {
                if (!window.confirm("Archive this session? It stays viewable but is hidden from active interviews.")) return;
                setActionError(null);
                try {
                  await archive.mutateAsync(token);
                  detail.refetch();
                } catch (e) {
                  setActionError(`Archive failed: ${(e as ApiError).message}`);
                }
              }}
              className="btn btn-ghost btn-sm"
            >
              {archive.isPending ? "Archiving…" : "Archive"}
            </button>
          )}
          <button
            type="button"
            disabled={del.isPending}
            onClick={async () => {
              if (!window.confirm("PERMANENTLY DELETE this session and all its data? This cannot be undone.")) return;
              setActionError(null);
              try {
                await del.mutateAsync(token);
                navigate("/dashboard");
              } catch (e) {
                setActionError(`Delete failed: ${(e as ApiError).message}`);
              }
            }}
            className="btn btn-ghost btn-sm"
            style={{ color: "var(--danger)" }}
          >
            {del.isPending ? "Deleting…" : "Delete"}
          </button>
        </>}
      />
      {actionError && (
        <div className="alert alert-danger" role="alert" style={{ marginBottom: 12 }}>
          {actionError}
        </div>
      )}

      {/* Tabs */}
      <div className="ds-tabs" role="tablist">
        {TABS.map((t) => {
          const active = tab === t.key;
          return (
            <button
              key={t.key}
              type="button"
              role="tab"
              aria-selected={active}
              className="ds-tab"
              onClick={() => setTab(t.key)}
            >
              {t.label}
              {t.key === "performance" && d.evaluation && (
                <span className="pill mag" style={{ padding: "2px 8px" }}>{d.evaluation.overall.score}</span>
              )}
            </button>
          );
        })}
      </div>

      <div style={{ marginTop: 24 }}>
        {tab === "summary" && <SummaryTab d={d} />}
        {tab === "candidate" && <CandidateTab d={d} />}
        {tab === "trace" && <TraceTab d={d} active={tab === "trace"} onOpenPrompt={setPrompt} />}
        {tab === "performance" && <PerformanceTab token={token} d={d} />}
        {tab === "recording" && <RecordingTab token={token} d={d} />}
        {tab === "scorecard" && <ScorecardTab token={token} active={tab === "scorecard"} />}
        {tab === "cadence" && <CadenceTab yaml={row.cadence_yaml} />}
        {tab === "observability" && <ObservabilityTab d={d} />}
        {tab === "data" && <DataTab token={token} d={d} />}
      </div>

      {prompt && <PromptDrawer data={prompt} onClose={() => setPrompt(null)} />}
    </div>
  );
}

// ── Summary ──────────────────────────────────────────────────────────────

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="stat">
      <div className="stat-label">{label}</div>
      <div className="stat-value">{value}</div>
    </div>
  );
}

function SummaryTab({ d }: { d: SessionDetail }) {
  const t: Totals = d.totals;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(120px, 1fr))" }}>
        <Stat label="Duration" value={t.duration_human} />
        <Stat label="Cost" value={t.cost_human} />
        <Stat label="Turns" value={t.turn_count} />
        <Stat label="AI turns" value={t.ai_turn_count} />
        <Stat label="Phases" value={t.phase_count} />
        <Stat label="Errors" value={t.error_count} />
      </div>

      <PhaseFlow phases={d.phases} />
      <PerModelTable per_model={d.per_model} langfuse_url={d.langfuse_url} />
      <SetupCostTable setup_per_model={d.setup_per_model} />
    </div>
  );
}

// S2 fallback: ordered phase list, also shown while mermaid loads. Always
// rendered so the operator sees per-phase rollups even if the diagram can't.
function PhaseFlow({ phases }: { phases: Phase[] }) {
  if (!phases.length) return null;
  return (
    <section>
      <h2 style={sectionLabel}>Phase flow</h2>
      <ol style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 8 }}>
        {phases.map((p, i) => (
          <li key={`${p.id}-${i}`} className="phase-row">
            <span className="phase-num">{i + 1}</span>
            <span style={{ fontWeight: 600 }}>{p.id.replace(/_/g, " ")}</span>
            <span className="muted-3" style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 14, fontSize: 12.5 }}>
              <span>{p.turn_count} turns</span>
              <span style={{ fontVariantNumeric: "tabular-nums" }}>{p.duration_human}</span>
              <span style={{ fontVariantNumeric: "tabular-nums" }}>{p.cost_human}</span>
              {Array.isArray(p.errors) && p.errors.length > 0 && (
                <span style={{ color: "var(--danger)" }}>{p.errors.length} err</span>
              )}
            </span>
          </li>
        ))}
      </ol>
    </section>
  );
}

// S8 — adds Cached / Audio·chars columns + a token totals row. STT rows show
// audio minutes, TTS rows show char counts, LLM rows show token usage (the
// `kind` discriminator decides which cell is meaningful), mirroring Jinja.
function PerModelTable({ per_model, langfuse_url }: { per_model: PerModel; langfuse_url?: string | null }) {
  const rows = per_model?.rows ?? [];
  if (!rows.length) return null;
  const num = (n: number | undefined) => (n ?? 0).toLocaleString();
  const numCell: React.CSSProperties = { textAlign: "right", fontVariantNumeric: "tabular-nums" };
  return (
    <section>
      <h2 style={sectionLabel}>
        Cost by model{per_model.source ? ` · ${per_model.source}` : ""}
        {langfuse_url && (
          <a href={langfuse_url} target="_blank" rel="noreferrer" className="sd-trace-link" style={{ marginLeft: 10 }}>
            ↗ per-call detail in Langfuse
          </a>
        )}
      </h2>
      <div className="card" style={{ marginTop: 12, overflow: "auto", padding: 0 }}>
        <table className="ui-table" style={{ minWidth: 640 }}>
          <thead>
            <tr>
              <th>Model</th>
              <th>Kind</th>
              <th style={numCell}>Calls</th>
              <th style={numCell}>Tokens in</th>
              <th style={numCell}>Tokens out</th>
              <th style={numCell}>Cached</th>
              <th style={numCell}>Audio / chars</th>
              <th style={numCell}>Cost</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={`${r.model}-${r.kind}-${i}`}>
                <td style={{ fontWeight: 600 }}>{r.model}</td>
                <td className="muted-3">{r.kind}</td>
                <td style={numCell}>{r.calls}</td>
                <td className="muted-3" style={numCell}>{r.kind === "llm" ? num(r.tokens_in) : "—"}</td>
                <td className="muted-3" style={numCell}>{r.kind === "llm" ? num(r.tokens_out) : "—"}</td>
                <td className="muted-3" style={numCell}>{r.kind === "llm" && r.tokens_cached ? num(r.tokens_cached) : "—"}</td>
                <td className="muted-3" style={numCell}>
                  {r.kind === "stt"
                    ? `${((r.audio_ms ?? 0) / 60000).toFixed(1)} min`
                    : r.kind === "tts"
                      ? `${num(r.chars)} chars`
                      : "—"}
                </td>
                <td style={numCell}>{r.cost_human}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr style={{ fontWeight: 600 }}>
              <td colSpan={3} style={{ padding: "12px 14px", borderTop: "1px solid var(--line)" }}>Total</td>
              <td style={{ ...numCell, padding: "12px 14px", borderTop: "1px solid var(--line)" }}>{num(per_model.totals?.tokens_in)}</td>
              <td style={{ ...numCell, padding: "12px 14px", borderTop: "1px solid var(--line)" }}>{num(per_model.totals?.tokens_out)}</td>
              <td style={{ ...numCell, padding: "12px 14px", borderTop: "1px solid var(--line)" }}>{num(per_model.totals?.tokens_cached)}</td>
              <td style={{ ...numCell, padding: "12px 14px", borderTop: "1px solid var(--line)" }}>—</td>
              <td style={{ ...numCell, padding: "12px 14px", borderTop: "1px solid var(--line)" }}>{per_model.total_cost_human ?? ""}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </section>
  );
}

// Human-readable labels for each setup-time LLM call's purpose tag (set
// server-side in app/setup_cost_tracker.py call sites). Unmapped values fall
// back to the raw tag so a new purpose never renders blank.
const SETUP_PURPOSE_LABELS: Record<string, string> = {
  generate_cadence: "Generate cadence",
  revise_cadence_with_ai: "Revise cadence with AI",
  generate_eval_plugin: "Generate eval plugin",
  generate_rubric: "Generate rubric",
};

// Cost for SETTING UP the interview — cadence generation/revision + eval-
// plugin/rubric generation (app/setup_cost_tracker.py). Mirrors PerModelTable's
// layout but swaps "Kind" for "Purpose" (what the call was FOR, not its
// tts/stt/llm type — these are all LLM calls) and drops the Audio/chars
// column (no speech calls happen at setup time). Renders nothing when the
// interview predates this feature or never had a setup-time LLM call.
function SetupCostTable({ setup_per_model }: { setup_per_model?: SetupPerModel }) {
  const rows = setup_per_model?.rows ?? [];
  if (!rows.length) return null;
  const num = (n: number | undefined) => (n ?? 0).toLocaleString();
  const numCell: React.CSSProperties = { textAlign: "right", fontVariantNumeric: "tabular-nums" };
  return (
    <section>
      <h2 style={sectionLabel}>Cost for setting up interview</h2>
      <div className="card" style={{ marginTop: 12, overflow: "auto", padding: 0 }}>
        <table className="ui-table" style={{ minWidth: 640 }}>
          <thead>
            <tr>
              <th>Model</th>
              <th>Purpose</th>
              <th style={numCell}>Calls</th>
              <th style={numCell}>Tokens in</th>
              <th style={numCell}>Tokens out</th>
              <th style={numCell}>Cached</th>
              <th style={numCell}>Cost</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={`${r.model}-${r.purpose}-${i}`}>
                <td style={{ fontWeight: 600 }}>{r.model}</td>
                <td className="muted-3">{SETUP_PURPOSE_LABELS[r.purpose] ?? r.purpose}</td>
                <td style={numCell}>{r.calls}</td>
                <td className="muted-3" style={numCell}>{num(r.tokens_in)}</td>
                <td className="muted-3" style={numCell}>{num(r.tokens_out)}</td>
                <td className="muted-3" style={numCell}>{r.tokens_cached ? num(r.tokens_cached) : "—"}</td>
                <td style={numCell}>{r.cost_human}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr style={{ fontWeight: 600 }}>
              <td colSpan={6} style={{ padding: "12px 14px", borderTop: "1px solid var(--line)" }}>Total</td>
              <td style={{ ...numCell, padding: "12px 14px", borderTop: "1px solid var(--line)" }}>{setup_per_model?.total_cost_human ?? ""}</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </section>
  );
}

// ── Candidate info (S5) ─────────────────────────────────────────────────────

function CandidateTab({ d }: { d: SessionDetail }) {
  const r: SessionRow = d.row;
  const [copied, setCopied] = useState(false);
  // resume/JD/cadence files live under the session dir — show the same
  // server-relative path the Jinja "Candidate" tab renders.
  const sessPath = (p?: string | null) => (p ? `sessions/${r.token}/${p}` : null);
  return (
    <div className="card" style={{ padding: 20, maxWidth: 720 }}>
      <h3 style={sectionLabel}>Candidate</h3>
      <ul style={{ marginTop: 14, display: "flex", flexDirection: "column", gap: 10, fontSize: 14, listStyle: "none", padding: 0 }}>
        <InfoRow label="Name" value={r.candidate_name} />
        <InfoRow label="Role" value={r.role} />
        <li style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <span className="muted-3" style={{ width: 130, flex: "none" }}>Status</span>
          <StatusPill status={r.status} />
        </li>
        <InfoRow label="Token" value={r.token} mono />
        {sessPath(r.resume_path) && <InfoRow label="Resume" value={sessPath(r.resume_path)!} mono />}
        {sessPath(r.jd_path) && <InfoRow label="JD file" value={sessPath(r.jd_path)!} mono />}
        {sessPath(r.cadence_requirements_path) && (
          <InfoRow label="Cadence req" value={sessPath(r.cadence_requirements_path)!} mono />
        )}
        <InfoRow label="Created" value={fmtTs(r.created_at)} />
        {r.ended_at && <InfoRow label="Ended" value={fmtTs(r.ended_at)} />}
        {d.candidate_interview_link && (
          <li style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <span className="muted-3" style={{ width: 130, flex: "none" }}>Candidate link</span>
            <button
              type="button"
              className="btn btn-sm"
              onClick={() => {
                navigator.clipboard?.writeText(d.candidate_interview_link!);
                setCopied(true);
                window.setTimeout(() => setCopied(false), 1500);
              }}
            >
              {copied ? "Copied ✓" : "Copy link"}
            </button>
          </li>
        )}
      </ul>
    </div>
  );
}

function InfoRow({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <li style={{ display: "flex", gap: 10, alignItems: "baseline" }}>
      <span className="muted-3" style={{ width: 130, flex: "none" }}>{label}</span>
      <span className={mono ? "mono" : undefined} style={mono ? { fontSize: 12.5, color: "var(--text-2)", wordBreak: "break-all" } : undefined}>
        {value}
      </span>
    </li>
  );
}

// ── Interview Trace (S3 + S4 + S7 + S2 diagram) ──────────────────────────────

const NO_CANDIDATE = "(no candidate turn yet)";

function TraceTab({
  d,
  active,
  onOpenPrompt,
}: {
  d: SessionDetail;
  active: boolean;
  onOpenPrompt: (p: PromptDrawerData) => void;
}) {
  const { phases, totals } = d;
  if (!phases.length) {
    return (
      <p className="muted-3" style={{ fontSize: 14 }}>
        No interview flow yet. The phase-by-phase trace appears once the interview starts and events are recorded.
      </p>
    );
  }
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <p className="muted-3" style={{ fontSize: 13 }}>
        {totals.phase_count} phases · {totals.turn_count} candidate turns · {totals.ai_turn_count} AI turns · {totals.duration_human}
        {totals.error_count > 0 && (
          <span style={{ color: "var(--danger)", marginLeft: 8 }}>· {totals.error_count} error(s)</span>
        )}
      </p>

      <MermaidFlow src={d.mermaid_src} active={active} phases={phases} />

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {phases.map((p, pi) => (
          <PhaseCard
            key={`${p.id}-${pi}`}
            phase={p}
            defaultOpen={pi === 0 || (Array.isArray(p.errors) && p.errors.length > 0)}
            onOpenPrompt={onOpenPrompt}
          />
        ))}
      </div>
    </div>
  );
}

// S2 — mermaid diagram with graceful fallback. While loading or on failure we
// show nothing extra here (the Summary tab already lists phases); we surface a
// small note so the operator knows the diagram couldn't render.
function MermaidFlow({ src, active, phases }: { src: string; active: boolean; phases: Phase[] }) {
  const { svg, state } = useMermaid(src, active);
  if (!src || !phases.length) return null;
  return (
    <section>
      <h2 style={sectionLabel}>Phase-flow diagram</h2>
      {state === "ok" && svg ? (
        <>
          <div className="sd-mermaid" style={{ marginTop: 12 }} dangerouslySetInnerHTML={{ __html: svg }} />
          <p className="sd-legend">
            <span><span className="sd-legend-chip" style={{ color: "var(--ok)" }}>●</span> healthy</span>
            <span><span className="sd-legend-chip" style={{ color: "var(--warn)" }}>●</span> forced transition</span>
            <span><span className="sd-legend-chip" style={{ color: "var(--danger)" }}>●</span> contains errors</span>
          </p>
        </>
      ) : state === "failed" ? (
        // Fallback — the ordered phase list below (and on Summary) still conveys flow.
        <p className="muted-3" style={{ marginTop: 8, fontSize: 13 }}>
          Diagram unavailable — see the phase cards below.
        </p>
      ) : (
        <p className="muted-3" style={{ marginTop: 8, fontSize: 13 }}>Rendering diagram…</p>
      )}
    </section>
  );
}

function PhaseCard({
  phase,
  defaultOpen,
  onOpenPrompt,
}: {
  phase: Phase;
  defaultOpen: boolean;
  onOpenPrompt: (p: PromptDrawerData) => void;
}) {
  const errCount = Array.isArray(phase.errors) ? phase.errors.length : 0;
  const forced = phase.transition === "advance_now" || phase.transition === "end_now";
  const tone = errCount > 0 ? "error" : forced ? "warn" : "healthy";
  const hasCoding = (phase.coding_questions?.length || phase.coding_submissions?.length) ? true : false;
  return (
    <details className={`sd-phase sd-phase--${tone}`} open={defaultOpen}>
      <summary>
        <span className="sd-phase-name">{phase.id.replace(/_/g, " ")}</span>
        <span style={{ display: "flex", gap: 6, marginLeft: "auto" }}>
          <span className="sd-chip">{phase.turn_count} turns</span>
          <span className="sd-chip">{phase.duration_human}</span>
          {errCount > 0 && <span className="sd-chip sd-chip--fail">⚠ {errCount}</span>}
          {phase.transition === "advance_now" && <span className="sd-chip sd-chip--warn">Forced advance</span>}
          {phase.transition === "end_now" && <span className="sd-chip sd-chip--warn">Forced end</span>}
        </span>
      </summary>
      <div className="sd-phase-body">
        {hasCoding && <CodingTraceBlock phase={phase} />}
        {!phase.turns.length && <p className="muted-3" style={{ fontSize: 13 }}>No turns recorded in this phase.</p>}
        {phase.turns.map((turn, ti) => (
          <TurnCard key={ti} turn={turn} index={ti + 1} onOpenPrompt={onOpenPrompt} />
        ))}
      </div>
    </details>
  );
}

function TurnCard({
  turn,
  index,
  onOpenPrompt,
}: {
  turn: Turn;
  index: number;
  onOpenPrompt: (p: PromptDrawerData) => void;
}) {
  const errCount = Array.isArray(turn.errors) ? turn.errors.length : 0;
  const v = turn.verifier;
  const po = turn.phase_override;
  const showOverride = po && po.override && po.override !== "stay";
  const ts = turn.ts ? turn.ts.slice(11, 19) : "";
  return (
    <article className={`sd-turn${errCount ? " sd-turn--error" : ""}`}>
      <header className="sd-turn-head">
        <span>Turn {index}</span>
        {ts && <span>{ts}</span>}
        {errCount > 0 && <span style={{ color: "var(--danger)" }}>⚠ {errCount} error(s)</span>}
      </header>

      {turn.candidate_text && turn.candidate_text !== NO_CANDIDATE && (
        <div className="sd-row">
          <div className="sd-row-label">
            <span className="sd-dot sd-dot--cand" /> Candidate
            {turn.candidate_conf != null && (
              <span className="muted-3" style={{ fontWeight: 400 }}>· conf {turn.candidate_conf.toFixed(2)}</span>
            )}
          </div>
          <p className="sd-text">“{turn.candidate_text}”</p>
        </div>
      )}

      {v && (
        <div className="sd-row">
          <div className="sd-row-label">
            <span className="sd-dot sd-dot--verifier" /> Verifier
            {v.latency_ms != null && <span className="muted-3" style={{ fontWeight: 400 }}>· {v.latency_ms}ms</span>}
          </div>
          <div>
            <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8 }}>
              {v.intent && <span className={`sd-intent sd-intent--${v.intent}`}>{v.intent}</span>}
              {v.reason && <span className="sd-chip sd-chip--fail" title="Guardrail sub-category">{v.reason}</span>}
              {v.confidence != null && <span className="muted-3" style={{ fontSize: 12 }}>conf {v.confidence.toFixed(2)}</span>}
              {v.langfuse_trace_url && (
                <a href={v.langfuse_trace_url} target="_blank" rel="noreferrer" className="sd-trace-link" title="Open this verifier call in Langfuse">↗</a>
              )}
            </div>
            {v.instruction && <p className="sd-text sd-text--muted" style={{ marginTop: 4 }}>→ “{v.instruction}”</p>}
          </div>
        </div>
      )}

      {showOverride && (
        <div className="sd-row">
          <div className="sd-row-label"><span className="sd-dot sd-dot--override" /> Phase override</div>
          <div>
            <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8 }}>
              <span className="sd-chip sd-chip--warn">{po!.override}</span>
              {po!.confidence != null && <span className="muted-3" style={{ fontSize: 12 }}>conf {po!.confidence.toFixed(2)}</span>}
              {po!.langfuse_trace_url && (
                <a href={po!.langfuse_trace_url} target="_blank" rel="noreferrer" className="sd-trace-link" title="Open this override decision in Langfuse">↗</a>
              )}
            </div>
            {po!.reason && <p className="sd-text sd-text--muted" style={{ marginTop: 4 }}>→ “{po!.reason}”</p>}
          </div>
        </div>
      )}

      {turn.ai_filler && (
        <div className="sd-row">
          <div className="sd-row-label"><span className="sd-dot sd-dot--filler" /> AI filler</div>
          <p className="sd-text">“{turn.ai_filler}”</p>
        </div>
      )}
      {turn.ai_apology && (
        <div className="sd-row">
          <div className="sd-row-label"><span className="sd-dot sd-dot--filler" /> AI apology</div>
          <p className="sd-text">“{turn.ai_apology}”</p>
        </div>
      )}
      {turn.ai_utterance && (
        <div className="sd-row">
          <div className="sd-row-label">
            <span className="sd-dot sd-dot--ai" /> {turn.observer ? "Observer (TA)" : "AI"}
          </div>
          <p className="sd-text">“{turn.ai_utterance}”</p>
        </div>
      )}

      {turn.barge_ins?.length > 0 && (
        <div className="sd-row">
          <div className="sd-row-label"><span className="sd-dot sd-dot--override" /> Barge-in</div>
          <span className="muted-3" style={{ fontSize: 12.5 }}>
            {turn.barge_ins.length} event(s){turn.barge_ins[0]?.reason ? ` — ${turn.barge_ins[0].reason}` : " — candidate spoke"}
          </span>
        </div>
      )}

      {turn.llm_calls?.length > 0 && (
        <details className="sd-llm-wrap">
          <summary>LLM calls ({turn.llm_calls.length})</summary>
          {turn.llm_calls.map((call, ci) => (
            <LlmCallCard key={ci} call={call} onOpenPrompt={onOpenPrompt} />
          ))}
        </details>
      )}
    </article>
  );
}

// S4 — one captured LLM call. "View prompt" hands the call's system/user/output
// to the shared drawer. The langfuse trace url is prebuilt server-side (S7).
function LlmCallCard({ call, onOpenPrompt }: { call: LlmCall; onOpenPrompt: (p: PromptDrawerData) => void }) {
  const isError = call.status === "error" || call.status === "failed";
  return (
    <div className={`sd-llm${isError ? " sd-llm--error" : ""}`}>
      <div className="sd-llm-head">
        <span className="sd-llm-agent">{call.agent}</span>
        <span className="muted-3" style={{ fontSize: 12 }}>{call.model || "—"}</span>
        {isError && call.error_label && <span className="sd-chip sd-chip--fail">{call.error_label}</span>}
        <button
          type="button"
          className="sd-prompt-btn"
          onClick={() =>
            onOpenPrompt({
              agent: call.agent,
              model: call.model,
              system_prompt: call.system_prompt,
              user_messages: call.user_messages,
              response_text: call.response_text,
            })
          }
          title="Show the full system + user prompt sent to this LLM"
        >
          ⌘ View prompt
        </button>
        {call.langfuse_trace_url && (
          <a href={call.langfuse_trace_url} target="_blank" rel="noreferrer" className="sd-trace-link" title="Open this call in Langfuse">↗ trace</a>
        )}
      </div>
      <div className="sd-llm-metrics">
        <span>latency {call.latency_human}</span>
        <span>ttft {call.ttft_human}</span>
      </div>
      {call.error_message && (
        <details>
          <summary className="muted-3" style={{ fontSize: 12, cursor: "pointer", marginTop: 6 }}>Error message</summary>
          <pre className="sd-pre">{call.error_message}</pre>
        </details>
      )}
      {call.response_text && (
        <details>
          <summary className="muted-3" style={{ fontSize: 12, cursor: "pointer", marginTop: 6 }}>Output</summary>
          <pre className="sd-pre">{call.response_text}</pre>
        </details>
      )}
    </div>
  );
}

// S4 — prompt drawer. Slides in from the right (Session.css), Esc / backdrop
// closes. Renders the exact system prompt + user messages + response captured
// for the chosen call.
function PromptDrawer({ data, onClose }: { data: PromptDrawerData; onClose: () => void }) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);
  return (
    <>
      <div className="sd-drawer-backdrop" onClick={onClose} />
      <aside className="sd-drawer" role="dialog" aria-modal="true">
        <header className="sd-drawer-head">
          <div>
            <div className="sd-drawer-eyebrow">Prompt sent to LLM</div>
            <div style={{ fontWeight: 700, marginTop: 2 }}>
              {data.agent}
              {data.model && <span className="muted-3" style={{ fontWeight: 400, fontSize: 13 }}> · {data.model}</span>}
            </div>
          </div>
          <button type="button" className="sd-drawer-close" onClick={onClose} title="Close (Esc)">✕</button>
        </header>
        <div className="sd-drawer-body">
          <div className="sd-pv-h">System prompt</div>
          <pre className="sd-pre">{data.system_prompt || "(no system prompt captured for this call)"}</pre>

          <div className="sd-pv-h">User messages ({data.user_messages?.length ?? 0})</div>
          {data.user_messages?.length ? (
            data.user_messages.map((m, i) => (
              <div key={i}>
                <span className="sd-pv-role">{m.role}</span>
                <pre className="sd-pre">{m.content}</pre>
              </div>
            ))
          ) : (
            <pre className="sd-pre muted-3">(no user messages captured for this call)</pre>
          )}

          {data.response_text && (
            <>
              <div className="sd-pv-h">Response</div>
              <pre className="sd-pre">{data.response_text}</pre>
            </>
          )}
        </div>
      </aside>
    </>
  );
}

// ── Coding-round trace block (inside a phase card) ───────────────────────────
// Renders the raw per-phase coding fields (questions + submissions + hints +
// anti-cheat) the backend stamps on each phase. The Performance tab has a
// richer, evaluation-joined view (CodingPerfSection); this one is the trace-side
// rollup mirroring the Jinja coding-trace-block.
function CodingTraceBlock({ phase }: { phase: Phase }) {
  const qs = phase.coding_questions ?? [];
  const subs = phase.coding_submissions ?? [];
  const subByQid = new Map(subs.filter((s) => s.question_id).map((s) => [s.question_id, s]));
  const passed = subs.reduce((a, s) => a + s.passed, 0);
  const total = subs.reduce((a, s) => a + s.total, 0);
  const auto = subs.filter((s) => s.auto_submitted).length;
  const missing = Math.max(0, qs.length - subs.length);
  return (
    <details className="sd-phase sd-phase--healthy" open style={{ background: "var(--panel-2)" }}>
      <summary>
        <span>{"{ }"} Coding round</span>
        <span style={{ display: "flex", gap: 6, marginLeft: "auto", flexWrap: "wrap" }}>
          <span className="sd-chip">{subs.length}/{qs.length} submitted</span>
          {total > 0 && (
            <span className={`sd-chip ${passed === total ? "sd-chip--pass" : "sd-chip--fail"}`}>{passed}/{total} tests</span>
          )}
          {auto > 0 && <span className="sd-chip sd-chip--warn">⏱ {auto} auto-submitted</span>}
          {missing > 0 && <span className="sd-chip sd-chip--fail">{missing} not submitted</span>}
          {phase.coding_hints?.length ? <span className="sd-chip">{phase.coding_hints.length} hint(s)</span> : null}
          {phase.coding_anti_cheat?.length ? <span className="sd-chip sd-chip--warn">⚠ {phase.coding_anti_cheat.length} anti-cheat</span> : null}
        </span>
      </summary>
      <div className="sd-phase-body">
        {qs.map((q, i) => {
          const sub = q.question_id ? subByQid.get(q.question_id) : subs[i];
          return (
            <div key={q.question_id || i} style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8 }}>
                <strong style={{ fontSize: 13 }}>
                  {qs.length > 1 ? `Q${i + 1} · ` : ""}<code className="mono">{q.question_id || "(unknown)"}</code>
                </strong>
                {q.function_name && <span className="muted-3" style={{ fontSize: 12 }}>fn <code className="mono">{q.function_name}</code></span>}
                {sub ? (
                  <>
                    <span className={`sd-chip ${sub.passed === sub.total && sub.total > 0 ? "sd-chip--pass" : "sd-chip--fail"}`}>{sub.passed}/{sub.total} tests</span>
                    <span className="sd-chip">{sub.runs_used} run(s)</span>
                    {sub.auto_submitted && <span className="sd-chip sd-chip--warn">auto-submitted</span>}
                  </>
                ) : (
                  <span className="sd-chip sd-chip--fail">no submission</span>
                )}
              </div>
              {q.question_prompt && <pre className="sd-pre">{q.question_prompt}</pre>}
              {sub && (
                <>
                  <details>
                    <summary className="muted-3" style={{ fontSize: 12, cursor: "pointer" }}>Submitted code</summary>
                    <pre className="sd-pre">{sub.code}</pre>
                  </details>
                  <TestResultList results={sub.test_results} />
                </>
              )}
            </div>
          );
        })}
        {phase.coding_hints?.length ? (
          <div>
            <div className="sd-pv-h">Hints delivered ({phase.coding_hints.length})</div>
            <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13 }}>
              {phase.coding_hints.map((h, i) => (
                <li key={i}><span className="muted-3">level {h.level}:</span> {h.text}</li>
              ))}
            </ul>
          </div>
        ) : null}
        {phase.coding_anti_cheat?.length ? (
          <div>
            <div className="sd-pv-h" style={{ color: "var(--warn)" }}>Anti-cheat signals</div>
            <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13 }}>
              {phase.coding_anti_cheat.map((ac, i) => (
                <li key={i}><strong>{ac.reason}</strong> <span className="muted-3">{ac.ts ? ac.ts.slice(11, 19) : ""}</span></li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>
    </details>
  );
}

// Shared per-test verdict list (used by trace + performance).
function TestResultList({ results }: { results: CodingTestResult[] }) {
  if (!results?.length) return null;
  return (
    <ul style={{ listStyle: "none", padding: 0, margin: 0 }}>
      {results.map((tc, i) => {
        const passed = tc.passed ?? tc.pass ?? false;
        const got = tc.got !== undefined ? tc.got : tc.actual;
        return (
          <li key={i} className={`sd-test ${passed ? "sd-test--pass" : "sd-test--fail"}`}>
            <span style={{ flex: 1 }}>{tc.name || "(unnamed)"}</span>
            <span className="sd-test-verdict">{passed ? "PASS" : "FAIL"}</span>
            {!passed && (
              <pre className="sd-pre" style={{ flexBasis: "100%", marginTop: 4 }}>
                {`expected: ${fmtVal(tc.expected)}\ngot:      ${fmtVal(got)}${tc.error ? `\nerror:    ${tc.error}` : ""}`}
              </pre>
            )}
          </li>
        );
      })}
    </ul>
  );
}

function fmtVal(v: unknown): string {
  if (v === undefined || v === null) return String(v);
  if (typeof v === "string") return v;
  try {
    return JSON.stringify(v);
  } catch {
    return String(v);
  }
}

// ── Performance ──────────────────────────────────────────────────────────

function ScorePill({ score, max }: { score: number; max: number }) {
  return (
    <span className={`pill ${score10Classes(max === 100 ? score / 10 : score)}`}>
      {score}/{max}
    </span>
  );
}

function PerformanceTab({ token, d }: { token: string; d: SessionDetail }) {
  const evaluate = useEvaluate(token);
  const revise = useReviseEval(token);
  const [feedback, setFeedback] = useState("");
  const ev: Evaluation = d.evaluation;

  // The scorecard renders from the EXPORTED document, so the screen and the
  // downloadable file are the same numbers by construction. 404 is normal and
  // silent: evaluations produced before the export existed fall back to the
  // stored benchmark below, and an un-evaluated session has neither.
  const { data: exportView } = useQuery({
    queryKey: ["evaluation-view", token],
    queryFn: () => fetchEvaluationView(token),
    enabled: !!ev,
    retry: false,
    staleTime: Infinity,
  });

  // Human review of the LLM's scores. Every save REFETCHES rather than patching
  // a local copy: the screen has to keep rendering from the same document the
  // download serves, and the server owns the recompute (a mark derived in the
  // browser could disagree with the file a customer receives).
  const qc = useQueryClient();
  const [reviewError, setReviewError] = useState("");
  const [reviewBusy, setReviewBusy] = useState(false);
  const runReview = async (fn: () => Promise<unknown>) => {
    setReviewBusy(true); setReviewError("");
    try {
      await fn();
      await qc.invalidateQueries({ queryKey: ["evaluation-view", token] });
    } catch (e) {
      setReviewError((e as ApiError).message || "Could not save the adjustment.");
      throw e;
    } finally {
      setReviewBusy(false);
    }
  };
  const reviewApi: ReviewApi = {
    busy: reviewBusy,
    error: reviewError,
    save: (body) => runReview(() => saveReview(token, body)).then(() => undefined),
    withdraw: (segmentId, section) =>
      runReview(() => withdrawReview(token, segmentId, section)).then(() => undefined),
  };

  const rubricStale =
    Object.keys(d.rubric_by_phase || {}).length > 0 &&
    (!d.eval_used_rubric || d.rubric_changed);

  if (!ev) {
    return (
      <div className="card" style={{ padding: 40, textAlign: "center", borderStyle: "dashed" }}>
        <p className="muted">No evaluation generated yet.</p>
        <button type="button" disabled={evaluate.isPending} onClick={() => evaluate.mutate()} className="btn btn-primary" style={{ marginTop: 16 }}>
          {evaluate.isPending ? "Generating… (LLM)" : "Generate evaluation"}
        </button>
        {evaluate.isError && (
          <p style={{ marginTop: 12, fontSize: 14, color: "var(--danger)" }}>{(evaluate.error as ApiError).message}</p>
        )}
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      {/* v2 benchmark view (plugin pipeline). When present it REPLACES the
          legacy /100 + dimensions + by-phase view entirely. */}
      {exportView ? (
        <>
          {/* Download the scorecard AS the document it is rendered from. Shown
              here (not only in Data & cost) because this is the screen someone
              is looking at when they want to export it. Gated on the export
              actually existing, so the button is never dead: an evaluation run
              before the export feature has none until it is regenerated. */}
          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            <a href={`/admin/sessions/${token}/evaluation-export.json`}
               className="btn btn-sm"
               title="The whole evaluation as one machine-readable JSON — the same numbers shown here, plus each plugin's declared schema">
              Export scorecard (.json)
            </a>
          </div>
          {/* Driven by the EXPORTED document — same numbers as the downloaded
              file, decorated with in-portal evidence the export excludes. */}
          <BenchmarkPanel benchmark={benchmarkFromExport(exportView)} review={reviewApi} />
        </>
      ) : ev.benchmark ? (
        // Pre-export evaluations: render the stored benchmark as before, so an
        // old session still shows exactly what it showed yesterday.
        <BenchmarkPanel benchmark={ev.benchmark} />
      ) : (
        <div className="card" style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 16px", fontSize: 14, color: "#92400e", borderColor: "transparent", background: "var(--ds-warning-soft)" }}>
          <span>This evaluation predates the plugin pipeline — regenerate to see the benchmark breakdown.</span>
          <button type="button" disabled={evaluate.isPending} onClick={() => evaluate.mutate()} className="btn btn-sm" style={{ marginLeft: "auto" }}>
            {evaluate.isPending ? "Regenerating…" : "Regenerate"}
          </button>
        </div>
      )}

      {d.plan_changed && (
        <div className="card" style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 16px", fontSize: 14, color: "#92400e", borderColor: "transparent", background: "var(--ds-warning-soft)" }}>
          <span>The evaluation plan changed since this evaluation was generated.</span>
          <button type="button" disabled={evaluate.isPending} onClick={() => evaluate.mutate()} className="btn btn-sm" style={{ marginLeft: "auto" }}>
            {evaluate.isPending ? "Regenerating…" : "Regenerate"}
          </button>
        </div>
      )}

      {/* Legacy v1 view — shown ONLY for old evaluations with no benchmark. */}
      {!ev.benchmark && (
        <>
          <div className="card" style={{ padding: 24 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <div style={{ fontSize: 38, fontWeight: 800, fontVariantNumeric: "tabular-nums" }}>{ev.overall.score}</div>
              <div className="muted-3">/100</div>
              <span className={`pill ${bandClasses(ev.overall.band)}`}>{ev.overall.band}</span>
            </div>
            <h2 style={{ marginTop: 12, fontSize: 18, fontWeight: 700 }}>{ev.overall.headline}</h2>
            <p className="muted" style={{ marginTop: 4, fontSize: 14 }}>{ev.overall.summary}</p>
          </div>

          {rubricStale && (
            <div className="card" style={{ display: "flex", alignItems: "center", gap: 12, padding: "13px 16px", fontSize: 14, color: "#92400e", borderColor: "transparent", background: "var(--ds-warning-soft)" }}>
              <span>
                This evaluation {d.eval_used_rubric ? "predates the current rubric" : "was generated without the rubric"}.
              </span>
              <button type="button" disabled={evaluate.isPending} onClick={() => evaluate.mutate()} className="btn btn-sm" style={{ marginLeft: "auto" }}>
                {evaluate.isPending ? "Regenerating…" : "Regenerate with rubric"}
              </button>
            </div>
          )}

          <section>
            <h3 style={sectionLabel}>Dimensions</h3>
            <div style={{ marginTop: 12, display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))" }}>
              {Object.entries(ev.dimensions).map(([key, dim]) => (
                <div key={key} className="card" style={{ padding: 16 }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <span style={{ fontWeight: 600 }}>{dimLabel(key)}</span>
                    <ScorePill score={dim.score} max={10} />
                  </div>
                  <p className="muted" style={{ marginTop: 6, fontSize: 14 }}>{dim.rationale}</p>
                </div>
              ))}
            </div>
          </section>

          <section>
            <h3 style={sectionLabel}>By phase</h3>
            <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 12 }}>
              {ev.phases.map((p) => (
                <div key={p.id} className="card" style={{ padding: 16 }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <span style={{ fontWeight: 600 }}>{p.name}</span>
                    <ScorePill score={p.score} max={10} />
                  </div>
                  <p className="muted" style={{ marginTop: 6, fontSize: 14 }}>{p.summary}</p>
                  {p.questions?.length > 0 && (
                    <ul style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 8, borderTop: "1px solid var(--line)", paddingTop: 12 }}>
                      {p.questions.map((q) => (
                        <li key={q.id} style={{ fontSize: 14 }}>
                          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12 }}>
                            <span className="muted">{q.text}</span>
                            <ScorePill score={q.score} max={10} />
                          </div>
                          <p className="muted-3" style={{ marginTop: 2, fontSize: 12 }}>{q.rationale}</p>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </section>

          {d.coding_perf && <CodingPerfSection perf={d.coding_perf} />}
        </>
      )}

      {/* Strengths / weaknesses — shown for both v1 and benchmark. */}
      <div style={{ display: "grid", gap: 16, gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))" }}>
        <HighlightList title="Strengths" items={ev.strengths} tone="ok" />
        <HighlightList title="Weaknesses" items={ev.weaknesses} tone="danger" />
      </div>

      {/* Regenerate / Revise. For the v2 benchmark pipeline, scores are computed
          per-phase by the configured plugins — there is no free-text "revise"
          (the feedback wasn't used), so we offer a plain Regenerate that re-runs
          the plan. Legacy v1 single-pass evals keep the feedback-driven revise. */}
      {ev.benchmark ? (
        <section className="card" style={{ padding: 16 }}>
          <h3 style={sectionLabel}>Regenerate</h3>
          <p className="muted-3" style={{ marginTop: 4, fontSize: 12 }}>
            Re-runs the plugin pipeline with the current evaluation plan. Edit the per-phase plugins on
            the cadence-review page to change how a phase is scored.
          </p>
          <div style={{ marginTop: 8, display: "flex", alignItems: "center", gap: 12 }}>
            <button type="button" disabled={evaluate.isPending} onClick={() => evaluate.mutate()} className="btn btn-sm">
              {evaluate.isPending ? "Regenerating…" : "Regenerate evaluation"}
            </button>
            <span className="muted-3" style={{ fontSize: 12 }}>{ev.model} · {fmtTs(ev.generated_at)}</span>
          </div>
          {evaluate.isError && (
            <p style={{ marginTop: 8, fontSize: 14, color: "var(--danger)" }}>{(evaluate.error as ApiError).message}</p>
          )}
        </section>
      ) : (
        <section className="card" style={{ padding: 16 }}>
          <h3 style={sectionLabel}>Revise with feedback</h3>
          <p className="muted-3" style={{ marginTop: 4, fontSize: 12 }}>
            Describe what to reconsider; the model re-scores using your note plus the prior evaluation.
          </p>
          <textarea
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            rows={3}
            placeholder="e.g. weight the system-design phase more heavily; the candidate's depth there was underrated."
            className="input"
            style={{ marginTop: 8 }}
          />
          <div style={{ marginTop: 8, display: "flex", alignItems: "center", gap: 12 }}>
            <button type="button" disabled={!feedback.trim() || revise.isPending} onClick={() => revise.mutate(feedback)} className="btn btn-sm">
              {revise.isPending ? "Revising…" : "Revise evaluation"}
            </button>
            <span className="muted-3" style={{ fontSize: 12 }}>{ev.model} · {fmtTs(ev.generated_at)}</span>
          </div>
          {revise.isError && (
            <p style={{ marginTop: 8, fontSize: 14, color: "var(--danger)" }}>{(revise.error as ApiError).message}</p>
          )}
        </section>
      )}
    </div>
  );
}

function HighlightList({
  title,
  items,
  tone,
}: {
  title: string;
  items: { title: string; detail: string }[];
  tone: "ok" | "danger";
}) {
  const dotColor = tone === "ok" ? "var(--ok)" : "var(--danger)";
  return (
    <section className="card" style={{ padding: 16 }}>
      <h3 style={sectionLabel}>{title}</h3>
      {items?.length ? (
        <ul style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 12 }}>
          {items.map((h, i) => (
            <li key={i} style={{ display: "flex", gap: 8 }}>
              <span style={{ marginTop: 6, height: 6, width: 6, flex: "none", borderRadius: "50%", background: dotColor }} />
              <div>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{h.title}</div>
                <div className="muted" style={{ fontSize: 14 }}>{h.detail}</div>
              </div>
            </li>
          ))}
        </ul>
      ) : (
        <p className="muted-3" style={{ marginTop: 8, fontSize: 14 }}>None noted.</p>
      )}
    </section>
  );
}

// ── Coding-round performance (S1) ────────────────────────────────────────
// Renders build_coding_performance(): per-question submitted-vs-expected, test
// pass results, rubric dims, runs/hints/time-to-submit, collapsible code.
function CodingPerfSection({ perf }: { perf: CodingPerf }) {
  const o = perf.overall;
  return (
    <section className="card" style={{ padding: 20 }}>
      <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 12 }}>
        <h3 style={sectionLabel}>Coding round</h3>
        <span className="sd-chip">{o.total_submitted} / {o.total_expected} submitted</span>
        {o.total_tests > 0 && (
          <span className={`sd-chip ${o.total_passed_tests === o.total_tests ? "sd-chip--pass" : "sd-chip--fail"}`}>
            {o.total_passed_tests} / {o.total_tests} tests passed
          </span>
        )}
        <span className="sd-chip">Avg score {o.avg_composite}/10</span>
      </div>

      {perf.phases.map((cp) => (
        <div key={cp.id} style={{ marginTop: 16 }}>
          <div style={{ fontWeight: 600, fontSize: 14 }}>
            {cp.name}
            <span className="muted-3" style={{ fontWeight: 400, fontSize: 12.5, marginLeft: 8 }}>
              ({cp.submitted_count} of {cp.expected_count} submitted
              {cp.auto_count ? `, ${cp.auto_count} auto-submitted` : ""}
              {cp.missing_count ? `, ${cp.missing_count} missing` : ""})
            </span>
          </div>
          <div style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 8 }}>
            {cp.questions.map((q, i) => (
              <details key={q.question_id || i} className={`sd-coding-q${q.submitted ? "" : " sd-coding-q--missing"}`}>
                <summary>
                  <code className="mono">{q.question_id || "(unknown)"}</code>
                  {q.submitted ? (
                    <>
                      <span className={`sd-chip ${q.passed === q.total && q.total > 0 ? "sd-chip--pass" : "sd-chip--fail"}`}>
                        {q.passed} / {q.total} tests{q.total ? ` · ${q.pass_rate_pct}%` : ""}
                      </span>
                      {q.auto_submitted && <span className="sd-chip sd-chip--warn">auto-submitted</span>}
                    </>
                  ) : (
                    <span className="sd-chip sd-chip--fail">not submitted</span>
                  )}
                  {q.has_score && <span className="sd-chip">Score {q.composite_score}/10</span>}
                </summary>
                <div style={{ padding: "0 12px 12px", display: "flex", flexDirection: "column", gap: 10 }}>
                  {q.prompt && <p className="muted-3" style={{ fontSize: 13, margin: 0 }}>{q.prompt}</p>}

                  {q.has_score && (
                    <div style={{ display: "grid", gap: 8, gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))" }}>
                      <DimBar label="Correctness" val={q.correctness} />
                      <DimBar label="Readability" val={q.readability} />
                      <DimBar label="Idiomatic" val={q.idiomatic} />
                      <DimBar label="Edge cases" val={q.edge_cases} />
                    </div>
                  )}
                  {q.has_score && q.rationale && <p className="muted" style={{ fontSize: 13, margin: 0 }}>{q.rationale}</p>}
                  {q.has_score && (
                    <p className="muted-3" style={{ fontSize: 12, margin: 0 }}>
                      {q.runs_used} run(s)
                      {q.hints_used ? ` · ${q.hints_used} hint(s) used` : ""}
                      {q.time_to_submit_s ? ` · ${Math.round(q.time_to_submit_s)}s to submit` : ""}
                    </p>
                  )}

                  {q.submitted && (
                    <>
                      <div className="sd-pv-h">Test cases</div>
                      <TestResultList results={q.test_results} />
                      {q.code && (
                        <details>
                          <summary className="muted-3" style={{ fontSize: 12, cursor: "pointer" }}>View submitted code</summary>
                          <pre className="sd-pre">{q.code}</pre>
                        </details>
                      )}
                    </>
                  )}
                </div>
              </details>
            ))}
          </div>
        </div>
      ))}
    </section>
  );
}

function DimBar({ label, val }: { label: string; val: number | null }) {
  if (val == null) return null;
  const tier = val >= 8 ? "high" : val >= 5 ? "mid" : "low";
  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 3 }}>
        <span className="muted-3">{label}</span>
        <span style={{ fontVariantNumeric: "tabular-nums" }}>{val}/10</span>
      </div>
      <div className="sd-bar">
        <div className={`sd-bar-fill sd-bar-fill--${tier}`} style={{ width: `${val * 10}%` }} />
      </div>
    </div>
  );
}

// ── Recording playback (A) ───────────────────────────────────────────────────
// <video> players for the camera + screen tracks the backend streams (webm), with
// the interview transcript beside them so a reviewer can read along. A track that
// 404s is hidden (onError) and a "no recording" note is shown if neither loads.

// Flatten the per-phase turns into a simple speaker-tagged transcript — the same
// candidate/AI utterances the Trace tab renders, minus the verifier/LLM detail.
type TranscriptLine = { ts: string; who: "Candidate" | "AI" | "Observer (TA)"; text: string };
function deriveTranscript(d: SessionDetail): TranscriptLine[] {
  const lines: TranscriptLine[] = [];
  for (const p of d.phases) {
    for (const t of p.turns) {
      if (t.candidate_text && t.candidate_text !== NO_CANDIDATE) {
        lines.push({ ts: t.ts, who: "Candidate", text: t.candidate_text });
      }
      if (t.ai_utterance) lines.push({ ts: t.ts, who: t.observer ? "Observer (TA)" : "AI", text: t.ai_utterance });
    }
  }
  return lines;
}

function RecordingPlayer({ label, src }: { label: string; src: string }) {
  // A missing track 404s — hide the player on error and show "no recording".
  const [missing, setMissing] = useState(false);
  if (missing) {
    return (
      <div>
        <h3 style={sectionLabel}>{label}</h3>
        <p className="muted-3" style={{ marginTop: 8, fontSize: 13 }}>No {label.toLowerCase()} recording.</p>
      </div>
    );
  }
  return (
    <div>
      <h3 style={sectionLabel}>{label}</h3>
      <video
        controls
        src={src}
        onError={() => setMissing(true)}
        style={{ marginTop: 8, width: "100%", borderRadius: 12, background: "#000", border: "1px solid var(--line)" }}
      />
    </div>
  );
}

// A track is split into parts when the candidate refreshed (or reopened the
// link on another device) mid-interview: each page load records a new part
// rather than overwriting the earlier one. One part = the usual single player.
type ServerPart = {
  part: number | null; // index for /recording/livekit?part=i; null while there's no file
  status: "recording" | "processing" | "ready" | "failed" | "unavailable";
  duration_s: number | null;
  error: string;
};
type RecordingParts = {
  camera: number[]; screen: number[]; livekit?: number[]; livekit_parts?: ServerPart[];
};

const SERVER_PART_NOTE: Record<ServerPart["status"], string> = {
  recording: "Recording now…",
  processing: "Finishing up — the media server is still uploading this part.",
  ready: "",
  failed: "This part could not be saved",
  unavailable: "The media server saved this part, but it isn't in this deployment's storage.",
};

function ServerRecording({ token, parts }: { token: string; parts: ServerPart[] }) {
  return (
    <div>
      <h3 style={sectionLabel}>Server recording (both voices)</h3>
      <p className="muted-3" style={{ marginTop: 4, fontSize: 12 }}>
        Recorded by the media server, independent of the candidate's browser.
        {parts.length > 1 && " The interview moved between servers, so it is in parts, in order."}
      </p>
      {parts.map((p, i) => (
        <div key={i} style={{ marginTop: 8 }}>
          {parts.length > 1 && (
            <div className="muted-3" style={{ fontSize: 12 }}>
              Part {i + 1} of {parts.length}
              {p.duration_s ? ` · ${Math.round(p.duration_s)} s` : ""}
            </div>
          )}
          {p.status === "ready" && p.part !== null ? (
            <audio controls src={`/api/sessions/${token}/recording/livekit?part=${p.part}`} style={{ width: "100%" }} />
          ) : (
            <p className="muted" style={{ fontSize: 13, color: p.status === "failed" ? "var(--danger)" : undefined }}>
              {SERVER_PART_NOTE[p.status]}
              {p.status === "failed" && (p.error ? `: ${p.error}` : ".")}
              {p.status === "failed" && " The browser recording below still has this part of the interview."}
            </p>
          )}
        </div>
      ))}
    </div>
  );
}

function TrackPlayers({ token, kind, label, parts }: {
  token: string; kind: "camera" | "screen"; label: string; parts: number[] | undefined;
}) {
  const list = parts && parts.length ? parts : [0];
  return (
    <>
      {list.map((p, i) => (
        <RecordingPlayer
          key={p}
          label={list.length > 1 ? `${label} — part ${i + 1} of ${list.length}` : label}
          src={`/api/sessions/${token}/recording/${kind}${p ? `?part=${p}` : ""}`}
        />
      ))}
    </>
  );
}

function RecordingTab({ token, d }: { token: string; d: SessionDetail }) {
  const transcript = deriveTranscript(d);
  const { data: parts } = useQuery({
    queryKey: ["recording-parts", token],
    queryFn: () => getJSON<RecordingParts>(`/api/sessions/${token}/recording-parts`),
    retry: false,
    // A server recording is uploaded a few seconds after the interview ends;
    // keep asking until every part has settled.
    refetchInterval: (q) =>
      q.state.data?.livekit_parts?.some((p) => p.status === "recording" || p.status === "processing")
        ? 5000
        : false,
  });
  // Older backends send only the playable indices.
  const serverParts: ServerPart[] =
    parts?.livekit_parts ??
    (parts?.livekit ?? []).map((p) => ({ part: p, status: "ready" as const, duration_s: null, error: "" }));
  const split = (parts?.camera.length ?? 0) > 1 || (parts?.screen.length ?? 0) > 1;
  return (
    <div style={{ display: "grid", gap: 20, gridTemplateColumns: "minmax(0, 1.4fr) minmax(0, 1fr)", alignItems: "start" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
        {split && (
          <p className="muted-3" style={{ fontSize: 13 }}>
            The candidate refreshed or reopened the interview, so the recording is in parts, in order.
          </p>
        )}
        {serverParts.length > 0 && <ServerRecording token={token} parts={serverParts} />}
        <TrackPlayers token={token} kind="camera" label="Camera" parts={parts?.camera} />
        <TrackPlayers token={token} kind="screen" label="Screen" parts={parts?.screen} />
      </div>
      <section className="card" style={{ padding: 16, maxHeight: "70vh", overflowY: "auto" }}>
        <h3 style={sectionLabel}>Transcript</h3>
        {transcript.length ? (
          <div style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 10 }}>
            {transcript.map((l, i) => (
              <div key={i} style={{ fontSize: 13.5 }}>
                <span className="muted-3" style={{ fontSize: 11.5, fontVariantNumeric: "tabular-nums" }}>
                  {l.ts ? l.ts.slice(11, 19) : ""}
                </span>{" "}
                <span style={{ fontWeight: 600, color: l.who === "AI" ? "var(--text-2)" : "var(--magenta-soft)" }}>{l.who}:</span>{" "}
                <span className="muted">{l.text}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="muted-3" style={{ marginTop: 8, fontSize: 13 }}>No transcript yet.</p>
        )}
      </section>
    </div>
  );
}

// ── Scorecard (B) ─────────────────────────────────────────────────────────────
// Read-only view of the observer's competency ratings + timestamped notes,
// fetched from GET /api/sessions/{token}/notes (gated to when the tab is shown).
function ScorecardTab({ token, active }: { token: string; active: boolean }) {
  const q = useScorecard(token, active);
  if (q.isLoading) return <p className="muted-3" style={{ fontSize: 14 }}>Loading scorecard…</p>;
  if (q.isError) {
    return <p style={{ fontSize: 14, color: "var(--danger)" }}>{(q.error as ApiError).message || "Failed to load scorecard."}</p>;
  }
  const sc = q.data as Scorecard;
  const items = sc?.notes ?? [];
  // Group the flat list: latest rating per competency + the free-text notes.
  const ratingMap = new Map<string, (typeof items)[number]>();
  for (const it of items) if (it.kind === "rating" && it.competency) ratingMap.set(it.competency, it);
  const ratings = [...ratingMap.values()];
  const notes = items.filter((it) => it.kind === "note");
  if (!ratings.length && !notes.length) {
    return <p className="muted-3" style={{ fontSize: 14 }}>No observer scorecard recorded for this interview.</p>;
  }
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      {ratings.length > 0 && (
        <section>
          <h3 style={sectionLabel}>Competency ratings</h3>
          <div style={{ marginTop: 12, display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))" }}>
            {ratings.map((r, i) => (
              <div key={`${r.competency}-${i}`} className="card" style={{ padding: 16 }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
                  <span style={{ fontWeight: 600 }}>{r.competency}</span>
                  <span className="pill mag">{r.score != null ? `${r.score}/5` : "—"}</span>
                </div>
                {r.text && <p className="muted" style={{ marginTop: 6, fontSize: 14 }}>{r.text}</p>}
              </div>
            ))}
          </div>
        </section>
      )}
      {notes.length > 0 && (
        <section>
          <h3 style={sectionLabel}>Notes</h3>
          <ul style={{ marginTop: 12, display: "flex", flexDirection: "column", gap: 10, listStyle: "none", padding: 0 }}>
            {notes.map((n, i) => (
              <li key={i} style={{ display: "flex", gap: 10, alignItems: "baseline", fontSize: 14 }}>
                <span className="muted-3" style={{ flex: "none", fontSize: 12, fontVariantNumeric: "tabular-nums" }}>{fmtTs(n.created_at)}</span>
                <span className="muted">{n.text}{n.author ? <span className="muted-3" style={{ fontSize: 12 }}> — {n.author}</span> : null}</span>
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}

// ── Cadence (read-only) ──────────────────────────────────────────────────

function CadenceTab({ yaml }: { yaml: string | null }) {
  if (!yaml) return <p className="muted-3" style={{ fontSize: 14 }}>No cadence on record.</p>;
  const parsed = parseCadenceYaml(yaml);
  const phases = parsed?.phases;
  if (!phases || !phases.length) {
    // Unparseable / phase-less cadence — fall back to the raw YAML.
    return (
      <pre className="card mono" style={{ overflowX: "auto", padding: 16, fontSize: 12, lineHeight: 1.6, color: "var(--text-2)", background: "var(--panel-2)" }}>
        {yaml}
      </pre>
    );
  }
  const totalMin = parsed?.total_duration_s != null ? Math.round(parsed.total_duration_s / 60) : null;
  return (
    <div>
      {totalMin != null && (
        <p className="muted-3" style={{ fontSize: 12, marginBottom: 12 }}>
          Total {totalMin} min · {phases.length} phase{phases.length === 1 ? "" : "s"}
        </p>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {phases.map((p, i) => (
          <CadencePhaseBlock key={`${p.id}-${i}`} phase={p} index={i} />
        ))}
      </div>
    </div>
  );
}

// ── Observability ───────────────────────────────────────────────────────────
// Dedicated home for the Langfuse session trace (the full LLM call tree, costs,
// latencies live there). Per-call ↗ links also sit inline in the Trace tab; this
// tab is the one-click "open the whole session in Langfuse" entry point.
function ObservabilityTab({ d }: { d: SessionDetail }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <section className="card" style={{ padding: 16 }}>
        <h3 style={sectionLabel}>Langfuse session trace</h3>
        <p className="muted-3" style={{ marginTop: 6, fontSize: 13 }}>
          Full LLM call tree for this interview — every prompt, model, latency and token cost.
        </p>
        <div style={{ marginTop: 12 }}>
          {d.langfuse_url ? (
            <a href={d.langfuse_url} target="_blank" rel="noreferrer" className="btn btn-primary btn-sm">
              Open Langfuse session ↗
            </a>
          ) : (
            <p className="muted-3" style={{ fontSize: 13 }}>
              No Langfuse trace for this session (tracing was disabled or the session predates it).
            </p>
          )}
        </div>
      </section>
    </div>
  );
}

// ── Data & cost ────────────────────────────────────────────────────────────

function DataTab({ token, d }: { token: string; d: SessionDetail }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      <section className="card" style={{ padding: 16 }}>
        <h3 style={sectionLabel}>Downloads</h3>
        <div style={{ marginTop: 12, display: "flex", flexWrap: "wrap", gap: 8 }}>
          <a href={`/admin/sessions/${token}/download`} className="btn btn-sm">Session bundle (.zip)</a>
          <a href={`/admin/sessions/${token}/events.jsonl`} className="btn btn-sm">events.jsonl</a>
          {/* ONE file for the whole evaluation — every plugin's section plus the
              schema each conforms to, so it validates itself. Carries event-index
              pointers, not transcript text (docs/eval-export-pii-decision.md). */}
          <a href={`/admin/sessions/${token}/evaluation-export.json`} className="btn btn-sm"
             title="The full evaluation as one machine-readable JSON — scores, per-plugin sections and their schemas">
            Evaluation (.json)
          </a>
          {d.langfuse_url && (
            <a href={d.langfuse_url} target="_blank" rel="noreferrer" className="btn btn-sm">Open in Langfuse ↗</a>
          )}
        </div>
      </section>
      <PerModelTable per_model={d.per_model} />
      <SetupCostTable setup_per_model={d.setup_per_model} />
    </div>
  );
}
