import { useCallback, useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import type { ReactNode } from "react";
import { TextEngine, readTextParams, type TextSnapshot, type QuestionConfig, type QuestionDraft } from "../lib/textEngine";
import type { TranscriptRow } from "../components/TranscriptView";
import { TermsModal, type TermsConsent } from "../components/TermsModal";
import { ConnectionBar } from "../components/ConnectionBar";
import { useConnectionQuality } from "../lib/connectionQuality";
import "./CandidateLive.css";

// Candidate-facing TEXT interview UI (no admin shell, no auth gate). HTTP-only:
// a lightweight lobby (role headline + Start + the no-recording terms gate — NO
// mic/camera/screen checks), a chat-style live screen (transcript + composer +
// "Save & finish later"), and a Done screen. Mirrors Candidate.tsx's
// Lobby → Live → Done structure but drives the HTTP TextEngine instead of the
// voice WS engine.
type StartFlow = "none" | "terms";

export function CandidateText() {
  const params = useMemo(() => readTextParams(window.location.search), []);
  const engine = useMemo(() => new TextEngine(params), [params]);
  const s = useSyncExternalStore(engine.subscribe, engine.getSnapshot);

  // Terms gate is local UI state; the engine owns the interview. (Text has no
  // recording, so we use the no-recording terms variant and there's no
  // "preparing" overlay — the AI opener is a single fast HTTP call.)
  const [flow, setFlow] = useState<StartFlow>("none");

  useEffect(() => {
    engine.init();
    return () => engine.destroy();
  }, [engine]);

  useEffect(() => {
    document.body.classList.add("cl-body-bg");
    return () => document.body.classList.remove("cl-body-bg");
  }, []);

  // Text mode has no persistent socket to watch for a drop — the generic
  // network probe (see lib/connectionQuality) is the whole signal here.
  const conn = useConnectionQuality(s.screen === "live");

  const acceptTerms = (_consent: TermsConsent) => {
    setFlow("none");
    void engine.start();
  };

  return (
    <div className="cl-root">
      {s.screen === "lobby" && <Lobby s={s} engine={engine} onStart={() => setFlow("terms")} />}
      {s.screen === "live" && <Live s={s} engine={engine} />}
      {s.screen === "live" && <ConnectionBar quality={conn} />}
      {s.screen === "done" && <Done name={s.name} />}

      {flow === "terms" && (
        <TermsModal recordingEnabled={false} onAccept={acceptTerms} onDecline={() => setFlow("none")} />
      )}
    </div>
  );
}

function Lobby({ s, engine, onStart }: { s: TextSnapshot; engine: TextEngine; onStart: () => void }) {
  return (
    <div className="cl-page cl-lobby screen-enter">
      <div className="cl-lobby-card">
        <h1 className="cl-lobby-title">Hi {s.name}</h1>
        <p className="cl-lobby-sub">
          Text interview for <b>{s.role}</b>
          {s.durationLabel ? <> · estimated {s.durationLabel}</> : null}
        </p>

        <div className="cl-howto-list">
          <div className="cl-howto-item" style={{ paddingBottom: 10, borderBottom: "none" }}>
            <span style={{ fontSize: 16, fontWeight: 600, color: "var(--ds-text)" }}>How this works</span>
          </div>
          {[
            "This is a typed conversation with an AI interviewer — no microphone, camera, or screen sharing.",
            "Read each question, type your answer, and press Enter (or Send) to reply.",
            "Give complete answers — 2–5 sentences per point is a good rhythm.",
            "You can Save & finish later at any time and resume from this same link.",
          ].map((t, i) => (
            <div key={i} className="cl-howto-item">
              <span className="cl-howto-dot" />
              <span>{t}</span>
            </div>
          ))}
        </div>

        {s.error && (
          <div style={{ marginTop: 20 }}>
            <ErrorBanner error={s.error} onDismiss={engine.dismissError} />
          </div>
        )}

        {/* A previously started/saved interview → offer to pick up where it left
            off (server-synced or local fallback). Otherwise the terms-gated Start. */}
        {s.resumable ? (
          <div className="cl-lobby-start">
            <button type="button" onClick={engine.resumeInterview} className="cl-btn cl-btn-primary cl-btn-lg">
              Resume interview
            </button>
            <p className="cl-lobby-resume-note">We found an interview in progress for this link.</p>
          </div>
        ) : (
          <div className="cl-lobby-start">
            <button type="button" disabled={s.sending} onClick={onStart} className="cl-btn cl-btn-primary cl-btn-lg">
              {s.sending ? "Starting…" : "Start interview"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function Live({ s, engine }: { s: TextSnapshot; engine: TextEngine }) {
  return (
    <div className="cl-page" style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      <header className="cl-topbar">
        <div className="cl-logo">
          <span className="cl-logo-mark">a.</span>
          AVA
        </div>
        {s.phase && (
          <span className="cl-pill" title="Current section of the interview">
            {prettyPhase(s.phase)}
          </span>
        )}
        <div style={{ marginLeft: "auto" }}>
          <button
            type="button"
            onClick={() => void engine.save()}
            disabled={s.saving || !s.started}
            className="cl-btn cl-btn-ghost"
            title="Save your progress and resume later from this same link"
          >
            {s.saving ? "Saving…" : "Save & finish later"}
          </button>
        </div>
      </header>

      <main className="cl-text-main">
        <div className="cl-text-col">
          {s.savedNote && <div className="cl-note-banner success">{s.savedNote}</div>}
          {s.error && <ErrorBanner error={s.error} onDismiss={engine.dismissError} />}

          <div className="cl-conv-card">
            <header className="cl-conv-head">
              <span className="cl-conv-title">Conversation</span>
              <span className="cl-conv-count">{s.count} turns</span>
            </header>
            <ChatMessages rows={s.rows} pending={s.sending} streaming={s.streaming} />
          </div>

          {s.question ? (
            <ResponsePanel
              // Keyed on the question id: a phase can hold several written
              // questions, and each must start with a clean textarea + its own
              // countdown (a bare re-render would keep the previous answer and
              // the already-submitted flag).
              key={s.question.question_id}
              question={s.question}
              sending={s.sending}
              onSubmit={(t, opts) => void engine.sendAnswer(t, opts)}
              // Draft (text + frozen countdown) lives in the engine so it
              // survives this panel unmounting: a refresh or a resume puts the
              // candidate back on the same words with the same time left,
              // instead of an empty box and a full allowance.
              loadDraft={engine.loadQuestionDraft}
              onDraftChange={engine.saveQuestionDraft}
              onDone={engine.clearQuestionDraft}
              // Bumped by "Save & finish later" → hold the clock.
              pauseSeq={s.savePauseSeq}
            />
          ) : (
            <Composer sending={s.sending} onSend={(t) => void engine.sendAnswer(t)} />
          )}
        </div>
      </main>
    </div>
  );
}

// One-shot written-response panel, shared by EVERY question type: the material
// the type supplies (audio clip / source passage / image — nothing extra for a
// plain question), then a limited textarea with a live counter and an optional
// countdown that AUTO-SUBMITS on expiry (client-enforced, so the tier stays
// stateless). Submitting ends the phase server-side in one shot.
//
// The countdown does NOT start on mount. It starts on the candidate's FIRST
// keystroke, so they can read the source passage / replay the audio clip with no
// clock pressure before committing to an answer. Clearing the textarea does not
// stop it, and a candidate who never types never starts it (deliberate: no idle
// auto-start, so nothing fires unasked).
//
// It DOES stop on "Save & finish later" (`pauseSeq`) — that means the candidate
// is stepping away, so the remaining time must not drain while they're gone —
// and resumes on the next keystroke. The remaining seconds are handed to the
// caller to persist, so closing the tab freezes the clock rather than ending the
// question, and reopening resumes it where it stopped.
//
// The MATERIAL comes straight from the phase config (never through the LLM), so
// a translation's source text reaches the candidate exactly as authored.
function ResponsePanel({
  question,
  sending,
  onSubmit,
  loadDraft,
  onDraftChange,
  onDone,
  pauseSeq,
}: {
  question: QuestionConfig;
  sending: boolean;
  onSubmit: (text: string, opts?: { allowEmpty?: boolean }) => void;
  loadDraft: (questionId: string) => QuestionDraft | null;
  onDraftChange: (questionId: string, text: string, remaining: number | null) => void;
  onDone: () => void;
  pauseSeq: number;
}) {
  const timed = question.time_limit_s != null && question.time_limit_s > 0;
  const countsWords = question.limit_kind === "words";  // legacy essay phases
  // Resume this question's saved draft if there is one — the words AND the
  // frozen clock — else an empty box and the full allowance. Lazy initialisers
  // so storage is read once on mount, not on every render.
  const restored = useRef<QuestionDraft | null>(null);
  if (restored.current === null) restored.current = loadDraft(question.question_id);
  const [text, setText] = useState(() => restored.current?.text || "");
  const [remaining, setRemaining] = useState(
    () => restored.current?.remaining_s ?? question.time_limit_s ?? 0,
  );
  // Latched on the first typed character; gates the countdown below. Cleared
  // only by a save (stepping away) — deleting the text can't stop the clock.
  const [started, setStarted] = useState(false);
  const submittedRef = useRef(false);

  const used = useMemo(
    () => (countsWords ? text.trim().split(/\s+/).filter(Boolean).length : text.length),
    [text, countsWords],
  );
  const overLimit = used > question.limit;
  const unit = countsWords ? "words" : "characters";

  // Hold the latest text/handler in a ref so the 1s countdown can auto-submit
  // without re-creating the interval on every keystroke (repo gotcha: unstable
  // effect deps tear down + recreate the interval so it never fires).
  const latest = useRef({ text, onSubmit, onDraftChange, onDone });
  latest.current = { text, onSubmit, onDraftChange, onDone };

  const doSubmit = useCallback(() => {
    if (submittedRef.current || sending || overLimit) return;
    submittedRef.current = true;
    onDone();   // this question is closed — drop its stored clock
    onSubmit(text.trim());
  }, [sending, overLimit, text, onSubmit, onDone]);

  // "Save & finish later" → hold the clock. The candidate is stepping away, so
  // their remaining time must not drain; the next keystroke starts it again.
  // Skips the first run (pauseSeq's initial value is not a save).
  const seenPause = useRef(pauseSeq);
  useEffect(() => {
    if (pauseSeq === seenPause.current) return;
    seenPause.current = pauseSeq;
    setStarted(false);
  }, [pauseSeq]);

  useEffect(() => {
    if (!timed) return;    // untimed: no countdown, submit when ready
    if (!started) return;  // not begun (or held by a save): waits for a keystroke
    const id = window.setInterval(() => {
      setRemaining((r) => {
        const next = r <= 1 ? 0 : r - 1;
        if (r <= 1) {
          window.clearInterval(id);
          if (!submittedRef.current) {
            submittedRef.current = true;
            const { text: t, onSubmit: send, onDone: done } = latest.current;
            done();
            // On expiry, submit whatever's there, truncated to the limit —
            // INCLUDING nothing at all. The candidate may have typed and then
            // cleared the box; an empty answer is still the answer time ran out
            // on, and dropping it would leave the panel stuck at 0:00 forever.
            send(truncateToLimit(t, question.limit, countsWords), { allowEmpty: true });
          }
        }
        return next;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [question.limit, question.question_id, timed, countsWords, started]);

  // Persist the clock as it drains — kept out of the setRemaining updater so
  // that stays pure. An abrupt close (no unmount, no save) then still freezes
  // the countdown at the right second instead of handing back a full allowance.
  // Writes the CURRENT text alongside it so the two can never disagree.
  useEffect(() => {
    if (!timed || submittedRef.current) return;
    const { text: t, onDraftChange: save } = latest.current;
    save(question.question_id, t, remaining);
  }, [remaining, timed, question.question_id]);

  const mm = Math.floor(remaining / 60);
  const ss = String(remaining % 60).padStart(2, "0");
  // Time already spent on this question → the clock is HELD (saved / reopened),
  // not merely un-started, so the copy says "resumes" rather than "starts".
  const held = timed && !started && remaining < (question.time_limit_s ?? 0);
  const low = (started || held) && remaining <= 30;

  return (
    <div className="cl-resp-card">
      <QuestionMaterial question={question} />

      <div className="cl-resp-row">
        <span className="cl-resp-type">
          {timed ? `Timed ${questionTypeLabel(question)}` : questionTypeLabel(question)}
        </span>
        {question.question_total > 1 && (
          <span className="cl-resp-badge" title="Questions in this section are answered one at a time">
            {question.question_index} / {question.question_total}
          </span>
        )}
        <span className="cl-resp-note">
          {question.target_language_label
            ? `Write in ${question.target_language_label} · one submission per question`
            : "Answer the question above · one submission per question"}
        </span>
        <span
          className={`cl-resp-count${overLimit ? " over" : ""}`}
          title={`The ${unit} limit is enforced; going over disables submit`}
        >
          {used} / {question.limit} {unit}
        </span>
        {timed && (
          <span
            className={`cl-resp-timer${started ? " running" : ""}${low ? " low" : ""}`}
            title={
              started
                ? "Time remaining — the response auto-submits when it reaches zero"
                : held
                  ? "Paused — the timer resumes when you start writing again"
                  : "Not started — the timer begins when you type your first character, then auto-submits at zero"
            }
          >
            {mm}:{ss}
          </span>
        )}
      </div>
      {timed && !started && (
        <span className="cl-resp-hint">
          {held
            ? "Your timer is paused. It resumes when you start writing again."
            : `The timer starts when you begin writing in the box below — take as long as you need to ${reviewMaterialHint(question)} first.`}
        </span>
      )}
      <textarea
        className="cl-textarea"
        value={text}
        onChange={(e) => {
          const v = e.target.value;
          setText(v);
          // Autosave every keystroke. Cheap (one small localStorage write) and
          // it's what makes a refresh or a browser crash cost nothing — the
          // draft is otherwise only in React state and dies with the page.
          onDraftChange(question.question_id, v, timed ? remaining : null);
          // Start the clock on the first REAL character — whitespace alone
          // isn't "writing", and starting on it would burn time on a stray
          // space. setStarted is idempotent once latched.
          if (timed && !started && v.trim().length > 0) setStarted(true);
        }}
        placeholder="Write your response here…"
        rows={9}
        disabled={sending || submittedRef.current}
        style={{ minHeight: 180 }}
      />
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        {overLimit && (
          <span className="cl-resp-over">
            Over the {question.limit}-{countsWords ? "word" : "character"} limit — trim{" "}
            {used - question.limit} to submit.
          </span>
        )}
        <button
          type="button"
          onClick={doSubmit}
          disabled={sending || !text.trim() || overLimit || submittedRef.current}
          className="cl-btn cl-btn-primary"
          style={{ marginLeft: "auto", padding: "11px 20px" }}
        >
          {sending ? "Submitting…" : "Submit response"}
        </button>
      </div>
    </div>
  );
}

// What the candidate is invited to review before the clock starts — named after
// whatever material the question type actually supplies, so the "take your time"
// hint points at the thing on screen rather than a generic "the question".
function reviewMaterialHint(question: QuestionConfig): string {
  if (question.asset_kind === "audio") return "replay the clip";
  if (question.asset_kind === "image") return "study the image";
  if (question.source_text) return "read the passage";
  return "read the question";
}

// The type-specific material shown above the composer. A plain question type
// supplies none (the prompt is already the AI's message in the transcript); the
// others add an audio player, the source passage, or the image.
function QuestionMaterial({ question }: { question: QuestionConfig }) {
  const { asset_kind, asset_url, source_text } = question;
  if (!asset_url && !source_text) return null;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
      {asset_url && asset_kind === "audio" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <span className="cl-material-label">
            Audio to transcribe
            {question.source_language_label ? ` (${question.source_language_label})` : ""}
            {" "}· you can replay it as many times as you need
          </span>
          <audio controls src={asset_url} style={{ width: "100%" }} />
        </div>
      )}
      {asset_url && asset_kind === "image" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <span className="cl-material-label">Image to describe</span>
          <img src={asset_url} alt="The image to describe" className="cl-resp-image" />
        </div>
      )}
      {source_text && (
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <span className="cl-material-label">
            Source text
            {question.source_language_label ? ` (${question.source_language_label})` : ""}
          </span>
          <div className="cl-source-box">{source_text}</div>
        </div>
      )}
    </div>
  );
}

// "image_description" → "Image description". Falls back to a generic label so an
// unknown (newer backend) question type still renders sensibly.
function questionTypeLabel(question: QuestionConfig): string {
  const t = (question.question_type || "").replace(/_/g, " ").trim();
  if (!t || t === "comprehensive") return "written response";
  return t;
}

// Cut `text` down to `limit` words or characters — used when the countdown
// expires and we submit whatever the candidate has.
function truncateToLimit(text: string, limit: number, countsWords: boolean): string {
  const t = text.trim();
  if (countsWords) return t.split(/\s+/).filter(Boolean).slice(0, limit).join(" ");
  return t.slice(0, limit);
}

// A single left-aligned AI bubble (interviewer). Reused for committed AI turns,
// the live streaming reply, and the typing indicator.
function AiBubble({ children }: { children: ReactNode }) {
  return (
    <div className="cl-bubble-row them">
      <span className="cl-bubble-label">AVA</span>
      <div className="cl-bubble" style={{ whiteSpace: "pre-wrap" }}>{children}</div>
    </div>
  );
}

// Wave-style 3-dot "typing…" indicator shown while the AI's reply is still being
// generated (before the first streamed token arrives).
function TypingDots() {
  return (
    <div className="cl-typing-dots">
      {[0, 1, 2].map((i) => (
        <span key={i} style={{ animationDelay: `${i * 0.16}s` }} />
      ))}
    </div>
  );
}

// Chat-style message list: candidate bubbles RIGHT (neutral, "You"), AI
// interviewer bubbles LEFT (cadence accent), like a messaging app. The AI's reply
// streams token-by-token into a live bubble; a typing indicator shows before the
// first token. Auto-scrolls to the newest message. (Only ai/candidate rows exist
// here; the TranscriptView stays a log for the voice interview.)
function ChatMessages({
  rows,
  pending,
  streaming,
}: {
  rows: TranscriptRow[];
  pending: boolean;
  streaming: string | null;
}) {
  const scrollRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [rows.length, streaming, pending]);
  return (
    <div ref={scrollRef} className="cl-conv-body">
      {rows.length === 0 && !pending && streaming == null && (
        <span className="cl-conv-empty">The interviewer will begin the conversation…</span>
      )}
      {rows.map((r) =>
        r.role === "ai" ? (
          <AiBubble key={r.id}>{r.text}</AiBubble>
        ) : (
          <div key={r.id} className="cl-bubble-row me">
            <span className="cl-bubble-label">You</span>
            <div className="cl-bubble" style={{ whiteSpace: "pre-wrap" }}>
              {r.text || <span style={{ fontStyle: "italic", color: "var(--ds-text-3)" }}>No response</span>}
            </div>
          </div>
        ),
      )}
      {streaming != null && <AiBubble key="streaming">{streaming || "…"}</AiBubble>}
      {pending && streaming == null && (
        <AiBubble key="typing">
          <TypingDots />
        </AiBubble>
      )}
    </div>
  );
}

// Dedicated composer: multi-line textarea, Enter-to-send (Shift+Enter = newline),
// Send button, both disabled while a turn is in flight (guards double-send).
function Composer({ sending, onSend }: { sending: boolean; onSend: (text: string) => void }) {
  const [text, setText] = useState("");
  const submit = () => {
    const t = text.trim();
    if (!t || sending) return;
    onSend(t);
    setText("");
  };
  return (
    <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
      <textarea
        className="cl-textarea"
        value={text}
        onChange={(e) => setText(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            submit();
          }
        }}
        placeholder="Type your answer… (Enter to send, Shift+Enter for a new line)"
        rows={3}
        disabled={sending}
        style={{ flex: 1, minHeight: 60 }}
      />
      <button
        type="button"
        onClick={submit}
        disabled={sending || !text.trim()}
        className="cl-btn cl-btn-primary"
        style={{ padding: "12px 20px" }}
      >
        {sending ? "Sending…" : "Send"}
      </button>
    </div>
  );
}

function ErrorBanner({ error, onDismiss }: { error: string; onDismiss: () => void }) {
  return (
    <div className="cl-note-banner danger">
      <span style={{ flex: 1 }}>{error}</span>
      <button type="button" onClick={onDismiss} className="cl-btn cl-btn-ghost cl-btn-sm">Dismiss</button>
    </div>
  );
}

// "warm_up" → "Warm up" — a subtle, human phase label for the header pill.
function prettyPhase(phase: string): string {
  const s = phase.replace(/_/g, " ").trim();
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : phase;
}

function Done({ name }: { name: string }) {
  return (
    <div className="cl-page cl-notice-wrap screen-enter">
      <div className="cl-notice-card">
        <div className="cl-notice-icon success">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12" />
          </svg>
        </div>
        <h1 className="cl-notice-title">Interview submitted</h1>
        <p className="cl-notice-body">Thanks, {name}. You can close this tab now.</p>
      </div>
    </div>
  );
}
