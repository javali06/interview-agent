import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  useArchiveSession,
  useBulkDeleteSessions,
  useDeleteSession,
  useSessions,
  type SessionRow,
} from "../lib/sessions";
import { ApiError } from "../lib/api";
import { StatusPill } from "../components/StatusPill";
import { Icon } from "../components/Icon";
import { fmtTs } from "../lib/format";
import { PageHeader } from "../components/PageHeader";
import { LoadingBlock } from "../components/LoadingBlock";
import "./Dashboard.css";

// Status filter options. "all" is the default; the rest mirror SessionStatus.
const STATUS_FILTERS = [
  "all",
  "draft",
  "ready",
  "in_progress",
  "completed",
  "cancelled",
] as const;
type StatusFilter = (typeof STATUS_FILTERS)[number];

type SortKey = "created_at" | "status";
type SortDir = "asc" | "desc";

export function Dashboard() {
  const sessions = useSessions();
  const archive = useArchiveSession();
  const del = useDeleteSession();
  const bulkDelete = useBulkDeleteSessions();
  const [copied, setCopied] = useState<string | null>(null);

  // D1 bulk-select: tokens the operator has checked. Held in a Set so toggling
  // is O(1); we prune stale tokens against the live rows when deriving state.
  const [selected, setSelected] = useState<Set<string>>(new Set());

  // D3 client-side controls over the already-fetched rows.
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  // Default sort: newest first — same order the API already returns, but now
  // the operator can flip it or sort by status.
  const [sortKey, setSortKey] = useState<SortKey>("created_at");
  const [sortDir, setSortDir] = useState<SortDir>("desc");

  const copy = (key: string, text: string) => {
    void navigator.clipboard.writeText(text).then(() => {
      setCopied(key);
      window.setTimeout(() => setCopied((c) => (c === key ? null : c)), 1500);
    });
  };

  const allRows = sessions.data?.rows ?? [];

  // Filter → sort, all over the fetched rows (cheap; lists are small).
  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    let out = allRows.filter((r) => {
      if (statusFilter !== "all" && r.status !== statusFilter) return false;
      if (q) {
        const hay = `${r.candidate_name} ${r.role}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
    out = [...out].sort((a, b) => {
      const av = String(a[sortKey] ?? "");
      const bv = String(b[sortKey] ?? "");
      const cmp = av < bv ? -1 : av > bv ? 1 : 0;
      return sortDir === "asc" ? cmp : -cmp;
    });
    return out;
  }, [allRows, query, statusFilter, sortKey, sortDir]);

  // Selection is scoped to the currently-visible rows so "select all" never
  // silently picks rows hidden by a filter.
  const visibleTokens = rows.map((r) => r.token);
  const selectedVisible = visibleTokens.filter((t) => selected.has(t));
  const allChecked = visibleTokens.length > 0 && selectedVisible.length === visibleTokens.length;
  const someChecked = selectedVisible.length > 0 && !allChecked;

  const toggleOne = (token: string) =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(token)) next.delete(token);
      else next.add(token);
      return next;
    });

  const toggleAll = () =>
    setSelected((prev) => {
      const next = new Set(prev);
      if (allChecked) visibleTokens.forEach((t) => next.delete(t));
      else visibleTokens.forEach((t) => next.add(t));
      return next;
    });

  const sortBy = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else {
      setSortKey(key);
      setSortDir("desc");
    }
  };

  const onBulkDelete = () => {
    const tokens = selectedVisible;
    if (tokens.length === 0) return;
    const msg =
      `PERMANENTLY DELETE ${tokens.length} session(s) and all their data ` +
      `(resume, cadence, transcript, evaluation)? This cannot be undone.`;
    if (!window.confirm(msg)) return;
    bulkDelete.mutate(tokens, {
      // Clear selection on success so the bar collapses and stale tokens don't
      // linger. (invalidate refetches the list via the hook's onSuccess.)
      onSuccess: () => setSelected(new Set()),
    });
  };

  const nSel = selectedVisible.length;
  const skipped = bulkDelete.data?.skipped ?? [];

  return (
    <div className="ds-light screen-enter">
      <PageHeader
        category="Interviews"
        title="Scheduled sessions"
        sub="Scheduled and completed AI screening sessions."
        actions={
          <Link to="/schedule" className="btn btn-primary">
            <Icon name="plus" className="ico" /> Schedule
          </Link>
        }
      />

      {/* Live concurrency indicator — the scaled system runs many at once. */}
      {!!sessions.data?.active_count && (
        <div
          className="card"
          style={{
            display: "flex", alignItems: "center", gap: 10, padding: "13px 16px", marginBottom: 18,
            borderColor: "transparent", background: "var(--ds-success-soft)",
          }}
        >
          <span style={{ fontWeight: 600 }}>
            {sessions.data.active_count} interview{sessions.data.active_count === 1 ? "" : "s"} in progress
          </span>
          <span className="muted" style={{ marginLeft: "auto", fontSize: 12.5 }}>
            Running concurrently across shards.
          </span>
        </div>
      )}

      {sessions.isLoading && <LoadingBlock label="Loading sessions…" rows={5} />}
      {sessions.isError && (
        <p style={{ marginTop: 28, fontSize: 14, color: "var(--danger)" }}>
          {(sessions.error as ApiError).message || "Failed to load sessions."}
        </p>
      )}

      {sessions.data && sessions.data.rows.length === 0 && (
        <div className="empty">No interviews yet. Schedule one to get started.</div>
      )}

      {sessions.data && sessions.data.rows.length > 0 && (
        <>
          {/* D3 — client-side search + status filter. */}
          <div className="dash-controls">
            <input
              className="input dash-search"
              type="search"
              placeholder="Search candidate or role…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search sessions"
            />
            <div className="dash-filter-chips">
              {STATUS_FILTERS.map((s) => (
                <button
                  key={s}
                  type="button"
                  className={`chip ${statusFilter === s ? "on" : ""}`}
                  onClick={() => setStatusFilter(s)}
                >
                  {s === "all" ? "All" : s.replace("_", " ")}
                </button>
              ))}
            </div>
          </div>

          {/* D1 — bulk-actions bar. Hidden entirely when nothing is selected. */}
          {nSel > 0 && (
            <div className="dash-bulkbar">
              <span className="dash-bulkbar-count">{nSel} selected</span>
              <button
                type="button"
                className="btn btn-danger btn-sm"
                disabled={nSel === 0 || bulkDelete.isPending}
                onClick={onBulkDelete}
              >
                {bulkDelete.isPending ? "Deleting…" : `Delete ${nSel} selected`}
              </button>
            </div>
          )}

          <div className="card" style={{ marginTop: 8, overflowX: "auto", padding: 0 }}>
          <table className="ui-table dash-table">
            <thead>
              <tr>
                <th className="dash-check">
                  <input
                    type="checkbox"
                    aria-label="Select all"
                    checked={allChecked}
                    ref={(el) => {
                      // indeterminate isn't an attribute — set it imperatively.
                      if (el) el.indeterminate = someChecked;
                    }}
                    onChange={toggleAll}
                  />
                </th>
                <th>Candidate</th>
                <th>Role</th>
                <th className="dash-sort-th" onClick={() => sortBy("status")}>
                  Status
                  {sortKey === "status" && (
                    <span className="dash-sort-caret">{sortDir === "asc" ? "▲" : "▼"}</span>
                  )}
                </th>
                <th className="dash-sort-th" onClick={() => sortBy("created_at")}>
                  Created
                  {sortKey === "created_at" && (
                    <span className="dash-sort-caret">{sortDir === "asc" ? "▲" : "▼"}</span>
                  )}
                </th>
                <th>Ended</th>
                <th style={{ textAlign: "right" }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <Row
                  key={r.token}
                  r={r}
                  base={sessions.data!.candidate_link_base}
                  copied={copied}
                  onCopy={copy}
                  checked={selected.has(r.token)}
                  onToggle={() => toggleOne(r.token)}
                  busy={archive.isPending || del.isPending}
                  onArchive={() => {
                    if (
                      window.confirm(
                        "Archive this session? It will be hidden from active interviews so you can schedule a new one. The transcript and evaluation stay viewable.",
                      )
                    )
                      archive.mutate(r.token);
                  }}
                  onDelete={() => {
                    if (
                      window.confirm(
                        "PERMANENTLY DELETE this session and all its data (resume, cadence, transcript, evaluation)? This cannot be undone.",
                      )
                    )
                      del.mutate(r.token);
                  }}
                />
              ))}
              {rows.length === 0 && (
                <tr>
                  <td colSpan={7} className="muted-3" style={{ textAlign: "center", padding: 28 }}>
                    No sessions match your search / filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
          </div>

          {/* Surface in_progress sessions the backend refused to hard-delete. */}
          {skipped.length > 0 && (
            <p className="dash-skipnote">
              Skipped {skipped.length} in-progress session{skipped.length === 1 ? "" : "s"} —
              live interviews can't be deleted. End or archive them first.
            </p>
          )}
        </>
      )}

      {(archive.isError || del.isError || bulkDelete.isError) && (
        <p style={{ marginTop: 12, fontSize: 14, color: "var(--danger)" }}>
          Action failed:{" "}
          {((archive.error || del.error || bulkDelete.error) as ApiError)?.message ??
            "unknown error"}
        </p>
      )}
    </div>
  );
}

function ActionButton({
  onClick,
  children,
  danger,
  disabled,
}: {
  onClick: () => void;
  children: React.ReactNode;
  danger?: boolean;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="btn btn-ghost btn-sm"
      style={danger ? { color: "var(--danger)" } : undefined}
    >
      {children}
    </button>
  );
}

function Row({
  r,
  base,
  copied,
  onCopy,
  checked,
  onToggle,
  busy,
  onArchive,
  onDelete,
}: {
  r: SessionRow;
  base: string;
  copied: string | null;
  onCopy: (key: string, text: string) => void;
  checked: boolean;
  onToggle: () => void;
  busy: boolean;
  onArchive: () => void;
  onDelete: () => void;
}) {
  const editable = r.status === "draft" || r.status === "ready";
  const liveish = r.status === "ready" || r.status === "in_progress";

  return (
    <tr>
      <td className="dash-check">
        <input
          type="checkbox"
          aria-label={`Select ${r.candidate_name}`}
          checked={checked}
          onChange={onToggle}
        />
      </td>
      <td>
        <Link to={`/sessions/${r.token}`} className="link" style={{ fontWeight: 600, color: "var(--text)" }}>
          {r.candidate_name}
        </Link>
      </td>
      <td className="muted">{r.role}</td>
      <td><StatusPill status={r.status} /></td>
      <td className="muted-3" style={{ fontVariantNumeric: "tabular-nums" }}>{fmtTs(r.created_at)}</td>
      <td className="muted-3" style={{ fontVariantNumeric: "tabular-nums" }}>{fmtTs(r.ended_at)}</td>
      <td>
        <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "flex-end", gap: 6 }}>
          {/* Edit / reopen — full-page nav into the Jinja schedule flow. For
              `ready` the reopen route stops the orchestrator first, so confirm. */}
          {editable && (
            <form
              method="post"
              action={`/admin/schedule/${r.token}/reopen`}
              style={{ display: "inline" }}
              onSubmit={(e) => {
                if (
                  r.status === "ready" &&
                  !window.confirm(
                    "Edit this interview? The orchestrator will be stopped and the candidate link will only work again after you re-approve.",
                  )
                )
                  e.preventDefault();
              }}
            >
              <button type="submit" className="btn btn-ghost btn-sm">Edit</button>
            </form>
          )}

          {liveish && (
            <ActionButton onClick={() => onCopy(`cand:${r.token}`, `${base}/app/candidate?token=${r.token}`)}>
              {copied === `cand:${r.token}` ? "Copied ✓" : "Copy link"}
            </ActionButton>
          )}

          <Link to={`/sessions/${r.token}`} className="btn btn-ghost btn-sm">View →</Link>

          {r.status !== "cancelled" && (
            <ActionButton onClick={onArchive} disabled={busy}>Archive</ActionButton>
          )}
          <ActionButton onClick={onDelete} danger disabled={busy}>Delete</ActionButton>
        </div>
      </td>
    </tr>
  );
}
