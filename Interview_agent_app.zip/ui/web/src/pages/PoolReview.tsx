// The checker's screen: one question, one decision.
//
// The whole design follows from what a checker actually does — read a question,
// judge it, move on — so the page is a list of decisions and nothing else. No
// editing, no pool settings, no tabs. The editor already exists for the author;
// mixing the two is what made the old flow confusing.
//
// Nothing is sent until "Submit review", so a checker can change their mind
// mid-pass without the author seeing half a verdict.
import { useCallback, useEffect, useMemo, useState } from "react";
import { PageHeader } from "../components/PageHeader";
import { LoadingBlock } from "../components/LoadingBlock";
import { Link, useNavigate, useParams } from "react-router-dom";
import {
  poolReview, reviewPool,
  type PoolReview as PoolReviewData, type QuestionVerdict,
} from "../lib/questionPools";
import type { ApiError } from "../lib/api";
import { useToast } from "../components/Toaster";

type Decision = { verdict: QuestionVerdict | null; comment: string };

export function PoolReview() {
  const { poolId } = useParams();
  const nav = useNavigate();
  const toast = useToast();

  const [data, setData] = useState<PoolReviewData | null>(null);
  const [decisions, setDecisions] = useState<Record<string, Decision>>({});
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const r = await poolReview(poolId!);
      setData(r);
      // Seed from anything already recorded, so leaving the page and coming
      // back does not cost the checker their pass over 40 questions.
      const seeded: Record<string, Decision> = {};
      for (const q of r.questions) {
        const qid = q.id ?? "";
        if (!qid) continue;      // unsaved question: nothing to review yet
        const prior = r.reviews[qid];
        seeded[qid] = {
          verdict: prior?.verdict ?? null,
          comment: prior?.comment ?? "",
        };
      }
      setDecisions(seeded);
    } catch (e) {
      toast.error((e as ApiError).message || "Could not load this pool.");
    }
    // `toast` is intentionally not a dependency — it is only used on the error
    // path, and depending on it re-runs this effect on every render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [poolId]);

  useEffect(() => { void load(); }, [load]);

  const set = (id: string, patch: Partial<Decision>) =>
    setDecisions((prev) => ({ ...prev, [id]: { ...prev[id], ...patch } }));

  const counts = useMemo(() => {
    const vals = Object.values(decisions);
    return {
      approved: vals.filter((d) => d.verdict === "approved").length,
      rejected: vals.filter((d) => d.verdict === "rejected").length,
      undecided: vals.filter((d) => d.verdict === null).length,
    };
  }, [decisions]);

  // Mirrors the server's rule rather than hoping the checker remembers it: a
  // rejection the author cannot act on wastes the round trip.
  const missingReason = useMemo(
    () => Object.entries(decisions)
      .filter(([, d]) => d.verdict === "rejected" && !d.comment.trim())
      .map(([id]) => id),
    [decisions],
  );

  const approveAll = () =>
    setDecisions((prev) => {
      const next: Record<string, Decision> = {};
      for (const [id, d] of Object.entries(prev)) next[id] = { ...d, verdict: "approved" };
      return next;
    });

  async function send() {
    if (counts.undecided > 0) {
      toast.error(`${counts.undecided} question${counts.undecided > 1 ? "s have" : " has"} no decision yet.`);
      return;
    }
    if (missingReason.length > 0) {
      toast.error("Every rejected question needs a reason — the author has to know what to fix.");
      return;
    }
    setBusy(true);
    try {
      const r = await reviewPool(poolId!, Object.entries(decisions).map(([question_id, d]) => ({
        question_id, verdict: d.verdict!, comment: d.comment,
      })));
      toast.success(
        counts.rejected === 0
          ? `Approved — ${counts.approved} question${counts.approved > 1 ? "s" : ""} published.`
          : `${counts.approved} published, ${counts.rejected} sent back to the author.`,
      );
      if (r.status.state !== "pending") nav("/question-pools/approvals");
      else void load();
    } catch (e) {
      toast.error((e as ApiError).message || "Could not submit the review.");
    } finally {
      setBusy(false);
    }
  }

  if (data === null) return <div className="ds-light"><LoadingBlock label="Loading…" /></div>;

  const pending = data.status.state === "pending";

  return (
    <div className="ds-light screen-enter">
      <PageHeader
        category="Question pools"
        title={<>Review: {data.pool_name}</>}
        sub={<>
          {data.questions.length} question{data.questions.length === 1 ? "" : "s"}
          {" · "}team <strong>{data.team}</strong>
          {!pending && " · this pool is not waiting for review"}
        </>}
        actions={
          <Link to="/question-pools/approvals" className="btn" style={{ textDecoration: "none" }}>
            Back to queue
          </Link>
        }
      />

      {pending && (
        // Sticky, because on a 40-question pool the actions would otherwise be
        // a long scroll away from the decision the checker just made.
        <div className="card" style={{
          padding: "12px 16px", marginBottom: 16, display: "flex", alignItems: "center",
          gap: 12, flexWrap: "wrap", position: "sticky", top: 8, zIndex: 5,
        }}>
          <button type="button" className="btn btn-ghost btn-sm" onClick={approveAll} disabled={busy}>
            Approve all
          </button>
          <span className="muted" style={{ fontSize: 13 }}>
            {counts.approved} approved · {counts.rejected} rejected
            {counts.undecided > 0 && <> · <strong>{counts.undecided} undecided</strong></>}
          </span>
          <button type="button" className="btn btn-primary btn-sm" style={{ marginLeft: "auto" }}
                  onClick={() => void send()}
                  disabled={busy || counts.undecided > 0 || missingReason.length > 0}>
            {busy ? "Submitting…" : "Submit review"}
          </button>
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {data.questions.map((q, i) => {
          const qid = q.id ?? "";
          const d = decisions[qid] ?? { verdict: null, comment: "" };
          const tone =
            d.verdict === "approved" ? "var(--ok, #2fb67c)"
            : d.verdict === "rejected" ? "var(--danger)"
            : "var(--line)";
          return (
            <div key={qid || i} className="card"
                 style={{ padding: 14, borderLeft: `3px solid ${tone}` }}>
              <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                <span className="muted-3" style={{ fontSize: 12, minWidth: 24, paddingTop: 2 }}>
                  {i + 1}
                </span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14, lineHeight: 1.5 }}>{q.text}</div>
                  <div className="muted-3" style={{ fontSize: 11.5, marginTop: 4 }}>
                    {[q.kind, q.topic, q.difficulty].filter(Boolean).join(" · ")}
                  </div>
                </div>
                {pending && (
                  <div style={{ display: "flex", gap: 6, flex: "0 0 auto" }}>
                    <button type="button" disabled={busy}
                            className={`btn btn-sm ${d.verdict === "approved" ? "btn-primary" : "btn-ghost"}`}
                            onClick={() => set(qid, { verdict: "approved" })}>
                      Approve
                    </button>
                    <button type="button" disabled={busy}
                            className="btn btn-ghost btn-sm"
                            style={d.verdict === "rejected"
                              ? { borderColor: "var(--danger)", color: "var(--danger)" } : undefined}
                            onClick={() => set(qid, { verdict: "rejected" })}>
                      Reject
                    </button>
                  </div>
                )}
              </div>
              {d.verdict === "rejected" && (
                <div style={{ marginTop: 10, paddingLeft: 36 }}>
                  <input
                    className="input" style={{ width: "100%" }} value={d.comment}
                    placeholder="What needs to change? The author sees only this."
                    disabled={busy}
                    onChange={(e) => set(qid, { comment: e.target.value })}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
