// Access: People, Teams (with that team's approval chain) and the role grid.
// Three tabs, one permission each. The server returns the list again after
// every save, so a checkbox here is whatever the database now says.
import { useEffect, useState } from "react";
import { PageHeader } from "../components/PageHeader";
import { ApiError } from "../lib/api";
import "./Access.css";
import { can, roleLine, usePermissions } from "../lib/auth";
import {
  useAddGrant, useChain, useCreateTeam, useDeleteTeam, usePeople, useRemoveGrant,
  useRoleGrid, useSaveChain, useSetActive, useSetPermission, useTeams, useUpdateTeam,
  type Person, type TeamRow,
} from "../lib/access";

type Tab = "people" | "teams" | "roles";

const TABS: { id: Tab; label: string; permission: string }[] = [
  { id: "people", label: "People", permission: "admin.users" },
  { id: "teams", label: "Teams", permission: "admin.teams" },
  { id: "roles", label: "Roles", permission: "admin.permissions" },
];

function message(e: unknown): string {
  return e instanceof ApiError ? e.message : "That did not work.";
}

function count(n: number, one: string, many: string): string {
  return `${n} ${n === 1 ? one : many}`;
}

function useReport() {
  const [error, setError] = useState("");
  const run = async (fn: () => Promise<unknown>) => {
    setError("");
    try {
      await fn();
    } catch (e) {
      setError(message(e));
    }
  };
  return { error, run };
}

export function Access() {
  const { data: me } = usePermissions();
  const tabs = TABS.filter((tab) => can(me, tab.permission));
  const [tab, setTab] = useState<Tab | null>(null);
  const current = tab && tabs.some((item) => item.id === tab) ? tab : tabs[0]?.id;

  return (
    <div className="ds-light access-page screen-enter">
      <PageHeader
        category="Admin"
        title="Access"
        sub="Who can use the platform, and on which team."
      />
      <div className="ds-tabs" role="tablist">
        {tabs.map((item) => (
          <button
            key={item.id}
            type="button"
            role="tab"
            aria-selected={current === item.id}
            className="ds-tab"
            onClick={() => setTab(item.id)}
          >
            {item.label}
          </button>
        ))}
      </div>
      <div className="access-body">
        {current === "people" && <PeopleTab />}
        {current === "teams" && <TeamsTab />}
        {current === "roles" && <RolesTab />}
      </div>
    </div>
  );
}

function PeopleTab() {
  const people = usePeople();
  const setActive = useSetActive();
  const addGrant = useAddGrant();
  const removeGrant = useRemoveGrant();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState<number | null>(null);
  const [role, setRole] = useState("");
  const [team, setTeam] = useState("");
  const { error, run } = useReport();

  const rows = people.data?.people ?? [];
  const shown = rows.filter((person) => {
    const text = `${person.display_name} ${person.email}`.toLowerCase();
    if (query && !text.includes(query.trim().toLowerCase())) return false;
    if (filter === "active") return person.is_active;
    if (filter === "inactive") return !person.is_active;
    if (filter === "none") return person.grants.length === 0;
    return true;
  });
  const person = rows.find((row) => row.id === selected) ?? shown[0] ?? null;

  const roles = people.data?.roles ?? [];
  const teams = people.data?.teams ?? [];
  const roleKey = role || roles[0]?.key || "";
  const choices = teamsFor(roleKey, roles, teams);
  const teamKey = choices.some((item) => item.key === team) ? team : (choices[0]?.key ?? "");

  const activeAdmins = rows.filter(
    (row) => row.is_active && row.grants.some((grant) => grant.role === "admin"),
  ).length;
  const lastAdmin = !!person?.is_active
    && person.grants.some((grant) => grant.role === "admin")
    && activeAdmins === 1;

  if (people.isLoading) return <p className="muted">Loading…</p>;
  if (people.isError) return <p className="muted">{message(people.error)}</p>;

  return (
    <div className="access-split">
      <div className="access-pane">
        <input
          className="input"
          placeholder="Search name or email"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          style={{ width: "100%" }}
          aria-label="Search name or email"
        />
        <select className="input" value={filter} onChange={(e) => setFilter(e.target.value)} style={{ width: "100%" }} aria-label="Filter people">
          <option value="all">All</option>
          <option value="none">No role</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
        <div className="access-scroll" role="listbox" aria-label="People">
          {shown.map((row) => (
            <button
              key={row.id}
              type="button"
              role="option"
              aria-selected={person?.id === row.id}
              className={`card access-person${person?.id === row.id ? " is-selected" : ""}`}
              onClick={() => setSelected(row.id)}
            >
              <div style={{ fontWeight: 700 }}>{row.display_name || row.email}</div>
              <div className="muted" style={{ fontSize: 12.5 }}>{row.email}</div>
              <div style={{ marginTop: 6 }}>
                <Status person={row} />
              </div>
            </button>
          ))}
          {shown.length === 0 && <p className="muted">No one matches.</p>}
        </div>
      </div>

      <div className="card access-detail">
        {person ? (<>
          <h2 style={{ fontSize: 18, fontWeight: 700 }}>{person.display_name || person.email}</h2>
          <p className="muted" style={{ marginTop: 4 }}>{person.email}</p>
          <p className="muted" style={{ marginTop: 4, fontSize: 13 }}>
            Last sign-in: {person.last_login_at ? person.last_login_at.slice(0, 16).replace("T", " ") : "Never"}
          </p>
          <div style={{ marginTop: 12 }}>
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              disabled={lastAdmin || setActive.isPending}
              onClick={() => void run(() => setActive.mutateAsync({ id: person.id, is_active: !person.is_active }))}
            >
              {person.is_active ? "Turn off" : "Turn on"}
            </button>
            {lastAdmin && (
              <p className="muted" style={{ marginTop: 8, fontSize: 13 }}>Someone has to be able to assign roles.</p>
            )}
          </div>

          <div style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 8 }}>
            {person.grants.length === 0 && <span className="pill warn" style={{ alignSelf: "flex-start" }}>No role</span>}
            {person.grants.map((grant) => {
              const locked = lastAdmin && grant.role === "admin";
              return (
                <div key={`${grant.role}:${grant.team}`} style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                  <span className="pill">{roleLine(grant)}</span>
                  {grant.granted_by_name && (
                    <span className="muted" style={{ fontSize: 12.5 }}>
                      Added by {grant.granted_by_name}
                      {grant.granted_at ? ` · ${grant.granted_at.slice(0, 16).replace("T", " ")}` : ""}
                    </span>
                  )}
                  <button
                    type="button"
                    className="btn btn-ghost btn-sm"
                    disabled={locked || removeGrant.isPending}
                    onClick={() => void run(() => removeGrant.mutateAsync({
                      id: person.id, role: grant.role, team: grant.team,
                    }))}
                  >
                    Remove
                  </button>
                </div>
              );
            })}
          </div>

          <div style={{ marginTop: 18, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "end" }}>
            <label>
              <div className="field-label">Role</div>
              <select className="input" value={roleKey} onChange={(e) => setRole(e.target.value)}>
                {roles.map((item) => <option key={item.key} value={item.key}>{item.name}</option>)}
              </select>
            </label>
            <label>
              <div className="field-label">Team</div>
              <select className="input" value={teamKey} onChange={(e) => setTeam(e.target.value)}>
                {choices.map((item) => (
                  <option key={item.key} value={item.key}>
                    {item.key === "*" ? "Every team" : item.name}
                  </option>
                ))}
              </select>
            </label>
            <button
              type="button"
              className="btn btn-primary btn-sm"
              disabled={!roleKey || !teamKey || addGrant.isPending}
              onClick={() => void run(() => addGrant.mutateAsync({ id: person.id, role: roleKey, team: teamKey }))}
            >
              Add
            </button>
          </div>
          {error && <p style={{ color: "var(--danger)", marginTop: 10, fontSize: 13 }}>{error}</p>}
        </>) : (
          <p className="muted">Select a person.</p>
        )}
      </div>
    </div>
  );
}

function Status({ person }: { person: Person }) {
  if (!person.is_active) return <span className="pill danger">Inactive</span>;
  if (person.grants.length === 0) return <span className="pill warn">No role</span>;
  return <span className="pill ok">Active</span>;
}

/** Which teams a role may be granted on. The server refuses the other combinations. */
function teamsFor(
  roleKey: string,
  roles: { key: string; scope: string }[],
  teams: { key: string; name: string }[],
) {
  const role = roles.find((item) => item.key === roleKey);
  if (!role) return [];
  if (role.scope === "global") return teams.filter((item) => item.key === "*");
  if (roleKey === "pool_author") return teams.filter((item) => item.key !== "*");
  return teams;
}

function TeamsTab() {
  const teams = useTeams();
  const create = useCreateTeam();
  const update = useUpdateTeam();
  const remove = useDeleteTeam();
  const [name, setName] = useState("");
  const [key, setKey] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const { error, run } = useReport();
  const rows = teams.data?.teams ?? [];
  const team = rows.find((row) => row.key === selected) ?? rows[0] ?? null;

  if (teams.isLoading) return <p className="muted">Loading…</p>;
  if (teams.isError) return <p className="muted">{message(teams.error)}</p>;

  return (
    <div className="access-split">
      <div className="access-pane">
        <div className="card" style={{ padding: 12 }}>
          <div className="field-label">New team</div>
          <input className="input" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} style={{ width: "100%", marginTop: 6 }} />
          <input className="input" placeholder="Key, optional" value={key} onChange={(e) => setKey(e.target.value)} style={{ width: "100%", marginTop: 6 }} />
          <button
            type="button"
            className="btn btn-primary btn-sm"
            style={{ marginTop: 8 }}
            disabled={!name.trim() || create.isPending}
            onClick={() => void run(async () => {
              await create.mutateAsync({ name: name.trim(), key: key.trim() });
              setName("");
              setKey("");
            })}
          >
            Create
          </button>
        </div>
        <div className="access-scroll" role="listbox" aria-label="Teams">
          {rows.map((row) => (
            <button
              key={row.key}
              type="button"
              role="option"
              aria-selected={team?.key === row.key}
              className={`card access-person${team?.key === row.key ? " is-selected" : ""}`}
              onClick={() => setSelected(row.key)}
            >
              <div style={{ fontWeight: 700 }}>{row.key === "*" ? "Every team" : row.name}</div>
              <div className="muted" style={{ fontSize: 12.5 }}>
                {count(row.people, "person", "people")} · {count(row.pools, "pool", "pools")} · {count(row.steps, "step", "steps")}
              </div>
            </button>
          ))}
        </div>
      </div>
      {team && (
        <TeamDetail
          team={team}
          busy={update.isPending || remove.isPending}
          onRename={(next) => void run(() => update.mutateAsync({ key: team.key, name: next }))}
          onActive={(isActive) => void run(() => update.mutateAsync({ key: team.key, is_active: isActive }))}
          onDelete={() => void run(() => remove.mutateAsync(team.key))}
        />
      )}
      {error && <p style={{ color: "var(--danger)", gridColumn: "1 / -1", fontSize: 13 }}>{error}</p>}
    </div>
  );
}

function TeamDetail({
  team, busy, onRename, onActive, onDelete,
}: {
  team: TeamRow;
  busy: boolean;
  onRename: (name: string) => void;
  onActive: (isActive: boolean) => void;
  onDelete: () => void;
}) {
  const [name, setName] = useState(team.name);
  useEffect(() => { setName(team.name); }, [team.key, team.name]);
  const inUse = team.people > 0 || team.pools > 0 || team.steps > 0;

  return (
    <div className="access-scroll" style={{ gap: 16 }}>
      <div className="card" style={{ padding: 18 }}>
        <h2 style={{ fontSize: 18, fontWeight: 700 }}>{team.key === "*" ? "Every team" : team.name}</h2>
        <p className="muted" style={{ marginTop: 4, fontSize: 13 }}>Key: {team.key}</p>
        {!team.is_system && (
          <div style={{ display: "flex", gap: 8, marginTop: 12, flexWrap: "wrap", alignItems: "center" }}>
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} />
            <button type="button" className="btn btn-ghost btn-sm" disabled={busy || !name.trim()} onClick={() => onRename(name.trim())}>
              Rename
            </button>
            <button type="button" className="btn btn-ghost btn-sm" disabled={busy} onClick={() => onActive(!team.is_active)}>
              {team.is_active ? "Deactivate" : "Activate"}
            </button>
            {inUse ? (
              <span className="muted" style={{ fontSize: 13 }}>In use</span>
            ) : (
              <button type="button" className="btn btn-ghost btn-sm" style={{ color: "var(--danger)" }} disabled={busy} onClick={onDelete}>
                Delete
              </button>
            )}
            <p className="muted" style={{ marginTop: 8, fontSize: 13, flexBasis: "100%" }}>
              {team.is_active
                ? "Turn off to pause this team. The grants stay, and they stop working until it is turned back on."
                : "Off. People on this team cannot use it until it is turned back on."}
            </p>
          </div>
        )}
        {team.is_system && (
          <p className="muted" style={{ marginTop: 10, fontSize: 13 }}>
            This row covers every team. It is not renamed or deleted.
          </p>
        )}
      </div>
      <ChainEditor teamKey={team.key} />
    </div>
  );
}

function ChainEditor({ teamKey }: { teamKey: string }) {
  const chain = useChain(teamKey);
  const save = useSaveChain(teamKey);
  const [steps, setSteps] = useState<{ name: string; role: string; role_name?: string }[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!chain.data || chain.data.key !== teamKey) return;
    setSteps(chain.data.chain.map((step) => ({
      name: step.name, role: step.role, role_name: step.role_name,
    })));
    setError("");
  }, [chain.data, teamKey]);

  const roles = chain.data?.roles ?? [];
  const fallbackRole = roles.find((role) => role.key === "pool_checker")?.key || roles[0]?.key || "";

  const move = (index: number, delta: number) => {
    const next = steps.slice();
    const target = index + delta;
    if (target < 0 || target >= next.length) return;
    const [row] = next.splice(index, 1);
    next.splice(target, 0, row);
    setSteps(next);
  };

  if (chain.isLoading) return <p className="muted">Loading the chain…</p>;
  if (chain.isError) return <p className="muted">{message(chain.error)}</p>;

  return (
    <div className="card" style={{ padding: 18 }}>
      <h2 style={{ fontSize: 16, fontWeight: 700 }}>Approval chain</h2>
      <p className="muted" style={{ marginTop: 4, fontSize: 13 }}>
        Pools already waiting keep the steps they started with.
        {teamKey !== "*" && " An empty chain uses the every-team chain."}
      </p>
      <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 12 }}>
        {steps.map((step, index) => (
          <div key={index} style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
            <span className="muted" style={{ width: 18 }}>{index + 1}</span>
            <input
              className="input"
              value={step.name}
              placeholder="Step name"
              onChange={(e) => setSteps(steps.map((row, i) => i === index ? { ...row, name: e.target.value } : row))}
            />
            <select
              className="input"
              value={step.role}
              onChange={(e) => setSteps(steps.map((row, i) => i === index ? { ...row, role: e.target.value } : row))}
            >
              {!roles.some((role) => role.key === step.role) && (
                <option value={step.role}>{step.role_name || step.role} (cannot review)</option>
              )}
              {roles.map((role) => <option key={role.key} value={role.key}>{role.name}</option>)}
            </select>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => move(index, -1)}>Up</button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => move(index, 1)}>Down</button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setSteps(steps.filter((_, i) => i !== index))}>
              Remove
            </button>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
        <button
          type="button"
          className="btn btn-ghost btn-sm"
          disabled={!fallbackRole}
          onClick={() => setSteps([...steps, { name: "", role: fallbackRole }])}
        >
          Add step
        </button>
        <button
          type="button"
          className="btn btn-primary btn-sm"
          disabled={save.isPending}
          onClick={() => {
            setError("");
            save.mutate(steps, { onError: (e) => setError(message(e)) });
          }}
        >
          {save.isPending ? "Saving…" : "Save chain"}
        </button>
      </div>
      {(chain.data?.warnings ?? []).map((warning) => (
        <p key={warning} className="muted" style={{ marginTop: 8, fontSize: 13 }}>{warning}</p>
      ))}
      {error && <p style={{ color: "var(--danger)", marginTop: 8, fontSize: 13 }}>{error}</p>}
    </div>
  );
}

function RolesTab() {
  const grid = useRoleGrid();
  const setCell = useSetPermission();
  const [error, setError] = useState("");

  if (grid.isLoading) return <p className="muted">Loading…</p>;
  if (grid.isError) return <p className="muted">{message(grid.error)}</p>;
  const data = grid.data!;

  return (
    <div className="access-roles">
      <div style={{ overflowX: "auto" }}>
        <table className="ui-table" style={{ width: "100%" }}>
          <thead>
            <tr>
              <th style={{ textAlign: "left", padding: 8 }} />
              {data.roles.map((role) => (
                <th key={role.key} style={{ textAlign: "left", padding: 8, fontSize: 13 }}>{role.name}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.permissions.map((permission, index) => {
              const groupStart = index === 0 || data.permissions[index - 1].group !== permission.group;
              return (
                <tr key={permission.key}>
                  <td style={{ padding: 8 }}>
                    {groupStart && (
                      <div className="muted" style={{ fontSize: 12, letterSpacing: "0.08em", marginBottom: 6 }}>
                        {permission.group.toUpperCase()}
                      </div>
                    )}
                    {permission.label}
                  </td>
                  {data.roles.map((role) => {
                    const on = role.permissions.includes(permission.key);
                    const locked = (data.locked[role.key] ?? []).includes(permission.key);
                    return (
                      <td key={role.key} style={{ padding: 8 }}>
                        <input
                          type="checkbox"
                          checked={on}
                          disabled={locked || setCell.isPending}
                          onChange={() => {
                            setError("");
                            setCell.mutate(
                              { role: role.key, permission: permission.key, enabled: !on },
                              { onError: (e) => setError(message(e)) },
                            );
                          }}
                        />
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p className="muted" style={{ marginTop: 12, fontSize: 13 }}>This changes the role for everyone who has it.</p>
      {error && <p style={{ color: "var(--danger)", marginTop: 8, fontSize: 13 }}>{error}</p>}
    </div>
  );
}
