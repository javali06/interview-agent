import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ApiError, getJSON } from "../lib/api";
import { Icon } from "../components/Icon";
import { PageHeader } from "../components/PageHeader";

type EditPrefill = {
  candidate_name: string;
  role: string;
  candidate_email: string;
  jd_text: string;
  cadence_requirements_text: string;
  resume_filename: string | null;
  jd_filename: string | null;
  cadence_requirements_filename: string | null;
  status: string;
  record_enabled: boolean;
  modality: string;
};

// Multipart submit — uploads stream as form-data, same contract as the Jinja
// form. Returns the (new or edited) session token.
async function submitSchedule(fd: FormData): Promise<{ ok: boolean; token?: string; error?: string }> {
  const res = await fetch("/api/schedule", { method: "POST", credentials: "same-origin", body: fd });
  return (await res.json().catch(() => ({ ok: false, error: `${res.status} ${res.statusText}` }))) as {
    ok: boolean;
    token?: string;
    error?: string;
  };
}

function FileField({
  label,
  name,
  accept,
  current,
  required,
}: {
  label: string;
  name: string;
  accept: string;
  current?: string | null;
  required?: boolean;
}) {
  const [picked, setPicked] = useState<string | null>(null);
  const [drag, setDrag] = useState(false);
  const ref = useRef<HTMLInputElement>(null);
  return (
    <div>
      <label className="field-label">
        {label} {required && <span style={{ color: "var(--danger)" }}>*</span>}
      </label>
      <div
        className={drag ? "dropzone drag" : "dropzone"}
        onDragOver={(e) => {
          e.preventDefault();
          setDrag(true);
        }}
        onDragLeave={(e) => {
          e.preventDefault();
          setDrag(false);
        }}
        onDrop={(e) => {
          e.preventDefault();
          setDrag(false);
          const dropped = e.dataTransfer.files;
          if (dropped && dropped.length > 0 && ref.current) {
            const dt = new DataTransfer();
            dt.items.add(dropped[0]);
            ref.current.files = dt.files;
            setPicked(dropped[0].name);
          }
        }}
      >
        <button type="button" onClick={() => ref.current?.click()} className="btn btn-sm">
          <Icon name="file" className="ico" /> Choose file
        </button>
        <span className="muted-3" style={{ fontSize: 13 }}>
          {picked || (current ? `current: ${current}` : "drop a file here or choose one")}
        </span>
      </div>
      <input
        ref={ref}
        type="file"
        name={name}
        accept={accept}
        style={{ display: "none" }}
        onChange={(e) => setPicked(e.target.files?.[0]?.name ?? null)}
      />
    </div>
  );
}

export function Schedule() {
  const [params] = useSearchParams();
  const token = params.get("token");
  const editing = Boolean(token);
  const navigate = useNavigate();
  const formRef = useRef<HTMLFormElement>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // Controlled so the recording toggle can hide for text (nothing to record) and
  // so recording can render as a switch rather than a bare checkbox.
  const [modality, setModality] = useState<"voice" | "text">("voice");
  const [recordEnabled, setRecordEnabled] = useState(!editing);

  const prefillQ = useQuery<EditPrefill>({
    queryKey: ["schedule-edit", token],
    queryFn: () => getJSON<EditPrefill>(`/api/schedule/${token}/edit`),
    enabled: editing,
  });

  // For edit mode, prefill text fields once the data arrives.
  const [seeded, setSeeded] = useState(false);
  useEffect(() => {
    if (editing && prefillQ.data && !seeded && formRef.current) {
      const f = formRef.current;
      (f.elements.namedItem("candidate_name") as HTMLInputElement).value = prefillQ.data.candidate_name;
      (f.elements.namedItem("role") as HTMLInputElement).value = prefillQ.data.role;
      (f.elements.namedItem("candidate_email") as HTMLInputElement).value = prefillQ.data.candidate_email || "";
      (f.elements.namedItem("jd_text") as HTMLTextAreaElement).value = prefillQ.data.jd_text;
      (f.elements.namedItem("cadence_requirements_text") as HTMLTextAreaElement).value =
        prefillQ.data.cadence_requirements_text;
      setModality(prefillQ.data.modality === "text" ? "text" : "voice");
      setRecordEnabled(Boolean(prefillQ.data.record_enabled));
      setSeeded(true);
    }
  }, [editing, prefillQ.data, seeded]);

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const fd = new FormData(e.currentTarget);
      if (editing && token) fd.set("token", token);
      const r = await submitSchedule(fd);
      if (r.ok && r.token) {
        navigate(`/schedule/${r.token}/cadence`);
      } else {
        setError(r.error || "Failed to schedule.");
      }
    } catch (err) {
      setError((err as ApiError).message || "Network error.");
    } finally {
      setSubmitting(false);
    }
  };

  if (editing && prefillQ.isError) {
    return (
      <div className="ds-light">
        <Link to="/dashboard" className="ds-back">← Back to interviews</Link>
        <p style={{ marginTop: 16, fontSize: 14, color: "var(--danger)" }}>
          {(prefillQ.error as ApiError).message || "Failed to load session."}
        </p>
      </div>
    );
  }

  const pre = prefillQ.data;

  return (
    <div className="ds-light screen-enter">
      <PageHeader
        category="Interviews"
        back={<Link to="/dashboard" className="ds-back">← Back to interviews</Link>}
        title={editing ? "Edit interview" : "Schedule interview"}
        sub="Upload the candidate's resume (and optionally a JD + cadence spec); the cadence is generated for review next."
      />

      <div style={{ maxWidth: 720 }}>
      {error && (
        <div className="alert alert-danger" role="alert" style={{ marginBottom: 16 }}>{error}</div>
      )}

      <form ref={formRef} onSubmit={onSubmit} className="card" style={{ padding: 24, display: "flex", flexDirection: "column", gap: 20 }}>
        <div className="ds-grid-2">
          <div>
            <label className="field-label" htmlFor="sch-name">
              Candidate name <span style={{ color: "var(--danger)" }}>*</span>
            </label>
            <input id="sch-name" name="candidate_name" required className="input" />
          </div>
          <div>
            <label className="field-label" htmlFor="sch-role">
              Role <span style={{ color: "var(--danger)" }}>*</span>
            </label>
            <input id="sch-role" name="role" required placeholder="e.g. Senior AI Engineer" className="input" />
          </div>
        </div>

        <div>
          <label className="field-label" htmlFor="sch-email">Candidate email</label>
          <input
            id="sch-email"
            name="candidate_email"
            type="email"
            placeholder="candidate@example.com"
            className="input"
          />
        </div>

        <FileField
          label="Resume"
          name="resume_upload"
          accept=".pdf,.docx,.txt,.md"
          required={!editing}
          current={pre?.resume_filename}
        />

        <div>
          <label className="field-label" htmlFor="sch-jd">Job description (paste)</label>
          <textarea
            id="sch-jd"
            name="jd_text"
            rows={4}
            className="input"
            placeholder="Paste the JD, or upload a .txt/.md below."
          />
          <div style={{ marginTop: 12 }}>
            <FileField label="…or upload JD" name="jd_upload" accept=".txt,.md,.pdf,.docx" current={pre?.jd_filename} />
          </div>
        </div>

        <div>
          <label className="field-label" htmlFor="sch-cadence">Cadence requirements (paste)</label>
          <textarea
            id="sch-cadence"
            name="cadence_requirements_text"
            rows={3}
            className="input"
            placeholder="e.g. 30 min total — 5m warm-up, 10m resume dive, 12m technical, 3m wrap."
          />
          <div style={{ marginTop: 12 }}>
            <FileField
              label="…or upload spec"
              name="cadence_requirements_upload"
              accept=".txt,.md,.pdf,.docx"
              current={pre?.cadence_requirements_filename}
            />
          </div>
        </div>

        {/* Interview mode — voice (spoken) or text (typed chat). Immutable after
            creation: the disabled <select> is excluded from FormData by the browser
            on edit, and update_draft ignores it server-side. */}
        <div>
          <label className="field-label" htmlFor="sch-modality">Interview mode</label>
          <select
            id="sch-modality"
            name="modality"
            className="input"
            style={{ maxWidth: 360 }}
            value={modality}
            onChange={(e) => setModality(e.target.value === "text" ? "text" : "voice")}
            disabled={editing}
          >
            <option value="voice">Voice — spoken interview</option>
            <option value="text">Text — typed / chat interview</option>
          </select>
          {editing && <span className="ds-help">Set when the interview was created</span>}
        </div>

        {/* Recording is video-only — a text interview has no camera/screen to
            record, so the control is hidden entirely for text (and no
            record_enabled is submitted → the interview is created not-recorded).
            Rendered as a switch; immutable after creation. update_draft ignores
            record_enabled server-side, so the hidden input is safe in edit mode. */}
        {modality !== "text" && (
          <div
            style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, padding: "14px 16px", border: "1px solid var(--line)", borderRadius: 12, background: "var(--panel-2)" }}
          >
            <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
              <span style={{ fontSize: 13.5, fontWeight: 600, color: "var(--text)" }}>Record this interview</span>
              <span className="muted-3" style={{ fontSize: 12 }}>
                Camera + screen capture, for review / fraud analytics
                {editing ? " — set when the interview was created" : ""}
              </span>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={recordEnabled}
              aria-label="Record this interview"
              onClick={() => { if (!editing) setRecordEnabled((v) => !v); }}
              disabled={editing}
              className="ds-toggle"
            />
            <input type="hidden" name="record_enabled" value={recordEnabled ? "1" : "0"} />
          </div>
        )}

        {editing && (
          <label className="muted" style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13.5 }}>
            <input type="checkbox" name="regenerate_cadence" value="1" />
            Regenerate cadence from these inputs (discards manual edits)
          </label>
        )}

        <div style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: 14, borderTop: "1px solid var(--line)", paddingTop: 18 }}>
          <button type="submit" disabled={submitting} className="btn btn-primary">
            {submitting ? "Generating cadence…" : editing ? "Save & review cadence" : "Generate cadence →"}
          </button>
          <Link to="/dashboard" className="btn btn-ghost">Cancel</Link>
        </div>
      </form>
      </div>
    </div>
  );
}
