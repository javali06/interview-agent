import { useState } from "react";
import { Link } from "react-router-dom";
import { useCreateRole, useRoles, type Role } from "../lib/roles";
import RoleStatesChart, { ROLE_STATE_META, type RoleState } from "../components/RoleStatesChart";
import { ApiError } from "../lib/api";
import { Icon } from "../components/Icon";
import { PageHeader } from "../components/PageHeader";
import { LoadingBlock } from "../components/LoadingBlock";

// Role-first Shortlist: pick or create a role (with a match threshold), then
// open it to upload a JD + resumes and rank the best fits.
export function Shortlist() {
  const roles = useRoles();
  const create = useCreateRole();
  const [showNew, setShowNew] = useState(false);
  const [title, setTitle] = useState("");
  const [threshold, setThreshold] = useState(70);
  // Voice or text, chosen once for the role: every candidate takes the same
  // interview, and both the cadence template and every interview created from
  // it inherit this.
  const [modality, setModality] = useState<"voice" | "text">("voice");
  const [jd, setJd] = useState("");

  const submit = async () => {
    if (!title.trim()) return;
    await create.mutateAsync({ title: title.trim(), jd_text: jd, threshold, modality });
    setTitle("");
    setJd("");
    setThreshold(70);
    setShowNew(false);
  };

  return (
    <div className="ds-light screen-enter">
      <PageHeader
        category="Shortlist"
        title="Roles"
        sub="Match resumes to a role and rank the best fits."
        actions={
          <button type="button" onClick={() => setShowNew((v) => !v)} className={showNew ? "btn" : "btn btn-primary"}>
            {showNew ? "Cancel" : <><Icon name="plus" className="ico" /> New role</>}
          </button>
        }
      />

      {showNew && (
        <div className="card" style={{ padding: 20, marginBottom: 18 }}>
          <div className="ds-grid-3">
            <div>
              <label className="field-label">Role title</label>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Senior AI Engineer"
                className="input"
              />
            </div>
            <div>
              <label className="field-label">Interview mode</label>
              <select
                value={modality}
                onChange={(e) => setModality(e.target.value === "text" ? "text" : "voice")}
                className="input"
              >
                <option value="voice">Voice — spoken</option>
                <option value="text">Text — typed / chat</option>
              </select>
            </div>
            <div>
              <label className="field-label">Match threshold</label>
              <input
                type="number"
                min={0}
                max={100}
                value={threshold}
                onChange={(e) => setThreshold(Number(e.target.value))}
                className="input"
              />
            </div>
          </div>
          <label className="field-label" style={{ marginTop: 14 }}>
            Job description (optional now — can add inside)
          </label>
          <textarea
            value={jd}
            onChange={(e) => setJd(e.target.value)}
            rows={3}
            placeholder="Paste the JD, or add it inside the role."
            className="input"
          />
          <div style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 12 }}>
            <button type="button" disabled={!title.trim() || create.isPending} onClick={submit} className="btn btn-primary">
              {create.isPending ? "Creating…" : "Create role"}
            </button>
            {create.isError && <span style={{ fontSize: 13, color: "var(--danger)" }}>{(create.error as ApiError).message}</span>}
          </div>
        </div>
      )}

      {roles.isLoading && <LoadingBlock label="Loading roles…" />}
      {roles.isError && (
        <p style={{ fontSize: 14, color: "var(--danger)" }}>{(roles.error as ApiError).message || "Failed to load roles."}</p>
      )}

      {roles.data && roles.data.roles.length === 0 && !showNew && (
        <div className="ds-empty">
          <p className="muted">No roles yet. Create one to start matching resumes.</p>
        </div>
      )}

      {roles.data && roles.data.roles.length > 0 && (
        <div style={{ marginBottom: 18 }}>
          <RoleStatesChart counts={roles.data.roles.reduce((acc, r) => {
            acc[r.state] = (acc[r.state] || 0) + 1;
            return acc;
          }, { sourcing: 0, interviewing: 0, closed: 0 } as Record<RoleState, number>)} />
        </div>
      )}

      {roles.data && roles.data.roles.length > 0 && (
        <div style={{ display: "grid", gap: 14, gridTemplateColumns: "repeat(auto-fill, minmax(min(300px, 100%), 1fr))" }}>
          {roles.data.roles.map((r) => (
            <RoleCard key={r.public_id} role={r} />
          ))}
        </div>
      )}
    </div>
  );
}

function RoleCard({ role }: { role: Role }) {
  return (
    <Link to={`/shortlist/${role.public_id}`} className="card ds-tile" style={{ display: "block", padding: 20, textDecoration: "none", color: "var(--text)" }}>
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 10 }}>
        <h2 style={{ fontWeight: 600, fontSize: 16 }}>{role.title}</h2>
        <span className="pill" style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
          <span aria-hidden style={{ width: 8, height: 8, borderRadius: 2,
                                     background: ROLE_STATE_META[role.state].color }} />
          {ROLE_STATE_META[role.state].label}
        </span>
      </div>
      <div style={{ marginTop: 14, display: "flex", alignItems: "center", gap: "4px 10px", fontSize: 13, flexWrap: "wrap" }}>
        <span className="muted">threshold {role.threshold}</span>
        <span className="muted-3">·</span>
        <span className="muted">{role.candidate_count ?? 0} matched</span>
        <span style={{ color: "var(--magenta-soft)", fontWeight: 600 }}>{role.matched_count ?? 0} above bar</span>
        <span className="muted-3">·</span>
        <span className="muted-3" style={{ textTransform: "uppercase", fontSize: 11 }}>{role.modality}</span>
      </div>
    </Link>
  );
}
