import { useEffect, useRef } from "react";
import { mountCodingPanel, type CodingPanelHandle, type CodingPhaseMsg } from "../coding";

// React host for the reused vanilla coding-panel widget. Mounts the widget
// (Monaco + Pyodide worker) into a div ref on first render of a coding phase,
// and tears it down on unmount. Incoming AI hints are written into the
// widget's own .coding-hint-display element (same as the vanilla app did).
export function CodingPanel({
  phaseStartMsg,
  sendWS,
  hint,
}: {
  phaseStartMsg: CodingPhaseMsg;
  sendWS: (m: Record<string, unknown>) => void;
  hint: string | null;
}) {
  const hostRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<CodingPanelHandle | null>(null);

  // Mount once per coding phase. phaseStartMsg is stable for the phase's life
  // (the parent unmounts this component when the phase ends), so empty deps.
  useEffect(() => {
    let alive = true;
    const host = hostRef.current;
    if (host) {
      mountCodingPanel({ hostEl: host, phaseStartMsg, sendWS })
        .then((p) => {
          if (alive) panelRef.current = p;
          else p.unmount();
        })
        .catch((e) => console.error("[coding] mount failed", e));
    }
    return () => {
      alive = false;
      try {
        panelRef.current?.unmount();
      } catch {
        /* noop */
      }
      panelRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Surface AI hints into the widget's hint display.
  useEffect(() => {
    if (hint && hostRef.current) {
      const el = hostRef.current.querySelector(".coding-hint-display") as HTMLElement | null;
      if (el) {
        el.textContent = hint;
        el.hidden = false;
      }
    }
  }, [hint]);

  return <div ref={hostRef} className="coding-host" data-minimized="0" />;
}
