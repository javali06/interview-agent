// Question pools — list view. Shows the pools the admin authored alongside the
// read-only ones shipped in the image, since both feed the same cadence
// customizer and the difference only matters when you try to EDIT one.
import { useCallback, useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Icon } from "../components/Icon";
import { PageHeader } from "../components/PageHeader";
import { LoadingBlock } from "../components/LoadingBlock";
import { PoolStatePill, PoolWorkflow } from "../components/PoolWorkflow";
import { useToast } from "../components/Toaster";
import { ApiError } from "../lib/api";
import { can, usePermissions } from "../lib/auth";
import {
  deletePool, duplicatePool, exportPoolUrl, listPools, type PoolSummary,
} from "../lib/questionPools";

export function QuestionPools() {
  const toast = useToast();
  const nav = useNavigate();
  const [pools, setPools] = useState<PoolSummary[] | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const { data: me } = usePermissions();

  const refresh = useCallback(async () => {
    try {
      setPools((await listPools()).pools);
    } catch (e) {
      toast.error((e as ApiError).message || "Could not load question pools.");
      setPools([]);
    }
  }, [toast]);

  useEffect(() => { void refresh(); }, [refresh]);

  const onDuplicate = async (p: PoolSummary) => {
    setBusy(p.pool_file);
    try {
      const made = await duplicatePool(p.pool_file);
      toast.success(`Copied to “${made.pool_name}”.`);
      nav(`/question-pools/${made.pool_id}`);
    } catch (e) {
      toast.error((e as ApiError).message || "Could not duplicate.");
    } finally { setBusy(null); }
  };

  const onDelete = async (p: PoolSummary) => {
    // A pool may already be referenced by an approved cadence, and deleting it
    // can't retroactively change one — but a future "Apply to cadence" would
    // fail, so make the admin confirm rather than making it a one-click loss.
    if (!window.confirm(`Delete “${p.pool_name}” and its ${p.question_count} question(s)? This cannot be undone.`)) return;
    setBusy(p.pool_id);
    try {
      await deletePool(p.pool_id);
      toast.success(`Deleted “${p.pool_name}”.`);
      void refresh();
    } catch (e) {
      toast.error((e as ApiError).message || "Could not delete.");
    } finally { setBusy(null); }
  };

  return (
    <div className="ds-light screen-enter">
      <PageHeader
        category="Question pools"
        title="All pools"
        sub={<>
          Reusable banks of interview questions. Build one for any role — technical
          or not — then pull questions from it into an interview’s cadence.
        </>}
        actions={<>
          {can(me, "pools.approve") && (
            <Link to="/question-pools/approvals" className="btn"
                  style={{ textDecoration: "none" }}>
              Approvals
            </Link>
          )}
          {can(me, "pools.edit") && (
            <Link to="/question-pools/new" className="btn btn-primary" style={{ textDecoration: "none" }}>
              <Icon name="plus" className="ico" style={{ width: 16, height: 16 }} /> New pool
            </Link>
          )}
        </>}
      />

      {pools === null ? (
        <LoadingBlock label="Loading…" />
      ) : pools.length === 0 ? (
        <div className="ds-empty">
          <h2 style={{ fontSize: 17, fontWeight: 600, color: "var(--text)" }}>No question pools yet</h2>
          <p className="muted" style={{ marginTop: 8, fontSize: 14 }}>
            Create one to reuse the same questions across interviews.
          </p>
          <Link to="/question-pools/new" className="btn btn-primary" style={{ marginTop: 16, textDecoration: "none", display: "inline-flex" }}>
            Create a pool
          </Link>
        </div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(min(330px, 100%), 1fr))", gap: 16 }}>
          {pools.map((p) => (
            <div key={p.pool_file} className="card" style={{ padding: 18, display: "flex", flexDirection: "column", gap: 10 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                <h2 style={{ fontSize: 16, fontWeight: 600, margin: 0 }}>{p.pool_name}</h2>
                <PoolStatePill pool={p} />
                <span className="muted-3" style={{ fontSize: 12, marginLeft: "auto" }}>
                  {p.question_count} question{p.question_count === 1 ? "" : "s"}
                </span>
              </div>

              {p.description && (
                <p className="muted" style={{ fontSize: 13, margin: 0, lineHeight: 1.5 }}>{p.description}</p>
              )}

              {p.topics.length > 0 && (
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                  {p.topics.slice(0, 6).map((t) => (
                    <span key={t} className="pill" style={{ padding: "2px 8px", fontSize: 11 }}>{t}</span>
                  ))}
                  {p.topics.length > 6 && (
                    <span className="muted-3" style={{ fontSize: 11, alignSelf: "center" }}>+{p.topics.length - 6}</span>
                  )}
                </div>
              )}

              {p.source !== "builtin" && (
                <div style={{ paddingTop: 4, borderTop: "1px solid var(--line)" }}>
                  <PoolWorkflow poolId={p.pool_id} team={p.team} summary={p}
                                onChanged={() => void refresh()} showHistory={false} />
                </div>
              )}

              {/* Gated on what this PERSON may do, not just on whether the pool
                  is a built-in. A checker can read every pool on their teams but
                  edit none of them — showing them an Edit button that 403s on
                  save is worse than showing no button, because they only find
                  out after typing. */}
              <div style={{ display: "flex", gap: 8, marginTop: "auto", paddingTop: 6, flexWrap: "wrap" }}>
                {p.source === "builtin" ? (
                  // A built-in is readable by anyone who may see pools — it is
                  // the content a cadence actually draws on, so "you may not
                  // edit this" is no reason to refuse to SHOW it. (It used to
                  // be inert text, so a shipped pool could not be opened at
                  // all.) The editor renders it read-only.
                  <Link to={`/question-pools/${p.pool_id}`} className="btn btn-ghost btn-sm" style={{ textDecoration: "none" }}>
                    <Icon name="notes" className="ico" style={{ width: 14, height: 14 }} /> View
                  </Link>
                ) : (
                  <Link to={`/question-pools/${p.pool_id}`} className="btn btn-ghost btn-sm" style={{ textDecoration: "none" }}>
                    <Icon name={can(me, "pools.edit", p.team) ? "edit" : "notes"} className="ico" style={{ width: 14, height: 14 }} />
                    {can(me, "pools.edit", p.team) ? " Edit" : " View"}
                  </Link>
                )}
                {/* A copy is new work of your own, so it needs the authoring
                    permission rather than the source pool's team. */}
                {can(me, "pools.edit") && (
                  <button type="button" className="btn btn-ghost btn-sm" disabled={busy === p.pool_file}
                          onClick={() => void onDuplicate(p)}>
                    {busy === p.pool_file ? "Copying…" : "Duplicate"}
                  </button>
                )}
                {p.source !== "builtin" && (
                  <a className="btn btn-ghost btn-sm" href={exportPoolUrl(p.pool_id)} style={{ textDecoration: "none" }}>
                    <Icon name="download" className="ico" style={{ width: 14, height: 14 }} /> YAML
                  </a>
                )}
                {/* Deleting something interviews are using is as consequential
                    as publishing it, so a published pool asks for the same
                    permission that publishes one. */}
                {p.source !== "builtin" &&
                  can(me, p.state === "published" ? "pools.publish" : "pools.edit", p.team) && (
                  <button type="button" className="btn btn-ghost btn-sm" disabled={busy === p.pool_id}
                          style={{ marginLeft: "auto", color: "var(--danger)" }}
                          onClick={() => void onDelete(p)}>
                    <Icon name="trash" className="ico" style={{ width: 14, height: 14 }} />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
