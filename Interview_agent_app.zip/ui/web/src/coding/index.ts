// Typed facade over the verbatim vanilla coding-panel widget. The widget
// (coding_panel.js + editor_wrapper.js + pyodide_worker.js + .html/.css) is
// reused AS-IS from the candidate client — porting 916 lines of editor/Pyodide
// orchestration to React would only add regression risk. React hosts it via
// CodingPanel.tsx, which mounts it into a div ref. allowJs lets tsc resolve the
// .js without type-checking it.
import { mountCodingPanel as _mount, ensureWorker as _ensure } from "./coding_panel.js";

export type CodingTestCase = { name?: string; input?: unknown; expected?: unknown };
export type CodingQuestion = {
  question_id: string;
  title?: string;
  question_prompt?: string;
  starter_code?: string;
  function_name?: string;
  test_cases?: CodingTestCase[];
  time_budget_s?: number;
  difficulty?: string;
  hint_count?: number;
};
export type CodingPhaseMsg = { phase_id: string; questions?: CodingQuestion[] } & Partial<CodingQuestion>;
export type CodingPanelHandle = { unmount: () => void; lockEditor: () => void };

export function mountCodingPanel(opts: {
  hostEl: HTMLElement;
  phaseStartMsg: CodingPhaseMsg;
  sendWS: (m: Record<string, unknown>) => void;
}): Promise<CodingPanelHandle> {
  return _mount(opts) as Promise<CodingPanelHandle>;
}

export function ensureWorker(): Promise<unknown> {
  return _ensure() as Promise<unknown>;
}
