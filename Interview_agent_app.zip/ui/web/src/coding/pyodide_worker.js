// Pyodide worker — runs candidate Python code in browser, isolated from the
// main thread so a long-running snippet doesn't freeze the UI.
//
// Protocol with coding_panel.js:
//   IN  {kind:"init"}                              -> start loading Pyodide
//   OUT {kind:"loading"}                            sent during init
//   OUT {kind:"ready", load_time_ms}                Pyodide loaded + ready
//   IN  {kind:"warm", code}                         preload this code's imports
//   OUT {kind:"packages", state, names, ms}          package load progress
//   IN  {kind:"run", code, function_name, test_cases, run_id}
//   OUT {kind:"run_result", run_id, stdout, stderr, runtime_ms, test_results}
//   OUT {kind:"error", message}                     any failure
//
// IMPORTANT: this worker NEVER fetches anything from the candidate code's
// namespace and never has network/filesystem access. Pyodide sandbox is the
// security boundary — we don't enable any I/O capabilities.

// Load Pyodide from jsdelivr CDN. Pinned to a tested version.
const PYODIDE_VERSION = "0.27.7";
const PYODIDE_CDN = `https://cdn.jsdelivr.net/pyodide/v${PYODIDE_VERSION}/full/`;

importScripts(`${PYODIDE_CDN}pyodide.js`);

let pyodide = null;
let initStartedAt = 0;

// Python-side helper: defines a runner function we'll call per Run.
// It executes user code in a fresh namespace, then calls the named function
// against each test case, capturing stdout/stderr and structured results.
const PY_RUNNER_BOOTSTRAP = `
import io
import json
import sys
import traceback
import contextlib

def __run_user_code(user_code: str, function_name: str, test_cases_json: str):
    """Execute user_code in a fresh namespace and run test cases.

    Returns a dict with stdout/stderr/test_results.
    """
    test_cases = json.loads(test_cases_json)
    namespace = {}

    out_buf = io.StringIO()
    err_buf = io.StringIO()

    # First: execute the user's code to define the function.
    # Compile with a custom filename so tracebacks can identify user-code frames
    # and surface the right line number for runtime errors below.
    try:
        with contextlib.redirect_stdout(out_buf), contextlib.redirect_stderr(err_buf):
            compiled = compile(user_code, "<your_code>", "exec")
            exec(compiled, namespace)
    except SyntaxError as e:
        # Syntax errors have their own line/offset on the exception itself.
        err_buf.write(
            f"SyntaxError on line {e.lineno}: {e.msg}\\n"
        )
        if e.text:
            err_buf.write(f"    {e.text.rstrip()}\\n")
        return {
            "stdout": out_buf.getvalue(),
            "stderr": err_buf.getvalue(),
            "test_results": [],
            "fatal": True,
        }
    except Exception as e:
        err_buf.write(traceback.format_exc())
        return {
            "stdout": out_buf.getvalue(),
            "stderr": err_buf.getvalue(),
            "test_results": [],
            "fatal": True,
        }

    func = namespace.get(function_name)
    if not callable(func):
        err_buf.write(f"Function {function_name!r} not defined.\\n")
        return {
            "stdout": out_buf.getvalue(),
            "stderr": err_buf.getvalue(),
            "test_results": [],
            "fatal": True,
        }

    # Run each test case with PER-TEST stdout/stderr capture (pytest model).
    # Each test gets its own buffer so its print() output can be attached to
    # that specific result. A separate aggregate copy goes to the top-level
    # output pane so the candidate can also scroll the full run output.
    results = []
    for tc in test_cases:
        name = tc.get("name", "")
        input_expr = tc.get("input", "")
        expected = tc.get("expected", "")
        per_out = io.StringIO()
        per_err = io.StringIO()
        try:
            with contextlib.redirect_stdout(per_out), contextlib.redirect_stderr(per_err):
                # Evaluate the input expression in a SAFE namespace (only builtins).
                # The candidate can NOT use names from their own code as test input.
                args_tuple = eval(f"({input_expr},)", {"__builtins__": __builtins__}, {})
                # Unpack — input "[1,2], 3" becomes (([1,2], 3),) -> we want ([1,2], 3)
                if len(args_tuple) == 1 and isinstance(args_tuple[0], tuple):
                    args = args_tuple[0]
                else:
                    args = args_tuple
                actual = func(*args)
            actual_repr = repr(actual)
            passed = actual_repr == expected
            results.append({
                "name": name,
                "input": input_expr,
                "expected": expected,
                "actual": actual_repr,
                "passed": bool(passed),
                "error": "",
                "stdout": per_out.getvalue(),
                "stderr": per_err.getvalue(),
            })
        except Exception as e:
            # Extract the deepest user-code frame from the traceback so we
            # can show the candidate WHICH line in their code raised.
            error_line = None
            error_source = ""
            try:
                tb = traceback.extract_tb(e.__traceback__)
                user_frames = [f for f in tb if f.filename == "<your_code>"]
                if user_frames:
                    last = user_frames[-1]
                    error_line = last.lineno
                    error_source = (last.line or "").strip()
            except Exception:
                pass
            results.append({
                "name": name,
                "input": input_expr,
                "expected": expected,
                "actual": "",
                "passed": False,
                "error": f"{type(e).__name__}: {e}",
                "error_line": error_line,
                "error_source": error_source,
                "stdout": per_out.getvalue(),
                "stderr": per_err.getvalue(),
            })
        # Aggregate into top-level buffers for the "Output" pane above results
        out_buf.write(per_out.getvalue())
        err_buf.write(per_err.getvalue())

    return {
        "stdout": out_buf.getvalue(),
        "stderr": err_buf.getvalue(),
        "test_results": results,
        "fatal": False,
    }
`;


self.onmessage = async (ev) => {
  const msg = ev.data || {};
  try {
    if (msg.kind === "init") {
      await initPyodide();
      return;
    }
    if (msg.kind === "warm") {
      // Preload the packages the STARTER code needs while the candidate is
      // still reading the problem, so the first Run doesn't stall on a
      // multi-megabyte download mid-question.
      if (pyodide) await loadImports(msg.code || "", null);
      return;
    }
    if (msg.kind === "run") {
      await runUserCode(msg);
      return;
    }
    self.postMessage({ kind: "error", message: `unknown kind ${msg.kind}` });
  } catch (err) {
    self.postMessage({ kind: "error", message: String(err && err.message || err) });
  }
};


async function initPyodide() {
  if (pyodide) {
    self.postMessage({ kind: "ready", load_time_ms: 0, cached: true });
    return;
  }
  initStartedAt = performance.now();
  self.postMessage({ kind: "loading" });

  pyodide = await loadPyodide({ indexURL: PYODIDE_CDN });
  // Bootstrap the Python-side runner once. Subsequent runs reuse it.
  pyodide.runPython(PY_RUNNER_BOOTSTRAP);

  const loadTime = Math.round(performance.now() - initStartedAt);
  self.postMessage({ kind: "ready", load_time_ms: loadTime, cached: false });
}


// Packages Pyodide simply does not have — no amount of loading fixes these,
// so say so plainly instead of letting the candidate stare at a bare
// ModuleNotFoundError. (Checked against pyodide-lock.json for the pinned
// version: torch/tensorflow/keras/transformers/jax have no WASM build.)
const UNAVAILABLE = {
  torch: "PyTorch", tensorflow: "TensorFlow", keras: "Keras",
  transformers: "Hugging Face Transformers", jax: "JAX",
};

function findUnavailable(code) {
  const found = [];
  // Deliberately a simple scan, matching only top-level module names — the
  // point is a helpful hint, not a parser. The real import still raises.
  const re = /^\s*(?:import|from)\s+([A-Za-z_][A-Za-z0-9_]*)/gm;
  let m;
  while ((m = re.exec(code)) !== null) {
    const name = m[1];
    if (UNAVAILABLE[name] && !found.includes(UNAVAILABLE[name])) {
      found.push(UNAVAILABLE[name]);
    }
  }
  return found;
}

// Read the code's imports and fetch whatever Pyodide has for them (numpy,
// pandas, scipy, scikit-learn, …). Pyodide resolves IMPORT names to package
// names itself — `import sklearn` pulls the scikit-learn wheel — using the
// `imports` map in pyodide-lock.json.
//
// NEVER fatal. Two reasons it can fail, both of which must let the run
// proceed so the candidate gets a normal traceback at the right line:
//   1. the code has a syntax error (very common — they're mid-edit), and
//      the import scan parses the source;
//   2. an import Pyodide has no package for (torch), which we hint about
//      separately.
async function loadImports(code, runId) {
  if (!code || !code.trim()) return;
  const blocked = findUnavailable(code);
  if (blocked.length) {
    self.postMessage({
      kind: "packages", run_id: runId, state: "unavailable",
      names: blocked,
      message: `${blocked.join(", ")} cannot run in the browser — `
             + "available: numpy, pandas, scipy, scikit-learn, sympy, matplotlib.",
    });
  }
  try {
    const t0 = performance.now();
    self.postMessage({ kind: "packages", run_id: runId, state: "loading" });
    await pyodide.loadPackagesFromImports(code);
    self.postMessage({
      kind: "packages", run_id: runId, state: "ready",
      ms: Math.round(performance.now() - t0),
    });
  } catch (err) {
    self.postMessage({
      kind: "packages", run_id: runId, state: "skipped",
      message: String((err && err.message) || err),
    });
  }
}


async function runUserCode(msg) {
  if (!pyodide) {
    self.postMessage({
      kind: "error",
      run_id: msg.run_id,
      message: "Pyodide not initialized yet",
    });
    return;
  }

  const startedAt = performance.now();
  const code = msg.code || "";
  const functionName = msg.function_name || "";
  const testCases = msg.test_cases || [];

  // Fetch any packages this code imports BEFORE executing it. Cached by
  // Pyodide, so only the first use of a package pays the download.
  await loadImports(code, msg.run_id);

  // Pass arguments to Python via globals, call the runner.
  pyodide.globals.set("__user_code", code);
  pyodide.globals.set("__function_name", functionName);
  pyodide.globals.set("__test_cases_json", JSON.stringify(testCases));

  let result;
  try {
    const py_obj = pyodide.runPython(
      "__run_user_code(__user_code, __function_name, __test_cases_json)"
    );
    // Convert PyProxy to JS object
    result = py_obj.toJs ? py_obj.toJs({ dict_converter: Object.fromEntries }) : py_obj;
    if (py_obj.destroy) py_obj.destroy();
  } catch (err) {
    self.postMessage({
      kind: "run_result",
      run_id: msg.run_id,
      stdout: "",
      stderr: String(err.message || err),
      runtime_ms: Math.round(performance.now() - startedAt),
      test_results: [],
      fatal: true,
    });
    return;
  }

  const runtimeMs = Math.round(performance.now() - startedAt);

  self.postMessage({
    kind: "run_result",
    run_id: msg.run_id,
    stdout: result.stdout || "",
    stderr: result.stderr || "",
    runtime_ms: runtimeMs,
    test_results: result.test_results || [],
    fatal: !!result.fatal,
  });
}
