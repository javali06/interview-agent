// Monaco editor wrapper. Loads Monaco from CDN on first use, exposes a small
// API for the coding panel — no Monaco types leak out of this file.
//
// Public API:
//   const editor = await createEditor(containerEl, { value, language, onChange });
//   editor.getValue()
//   editor.setValue(s)
//   editor.dispose()
//   editor.setReadOnly(bool)

const MONACO_VERSION = "0.52.2";
const MONACO_BASE = `https://cdn.jsdelivr.net/npm/monaco-editor@${MONACO_VERSION}/min`;

let monacoLoaderPromise = null;

function loadMonaco() {
  if (monacoLoaderPromise) return monacoLoaderPromise;
  monacoLoaderPromise = new Promise((resolve, reject) => {
    // Monaco uses AMD loader. We script-tag the loader, then config + require.
    const script = document.createElement("script");
    script.src = `${MONACO_BASE}/vs/loader.js`;
    script.onload = () => {
      // eslint-disable-next-line no-undef
      window.require.config({ paths: { vs: `${MONACO_BASE}/vs` } });
      // eslint-disable-next-line no-undef
      window.require(["vs/editor/editor.main"], () => {
        // window.monaco is now populated
        resolve(window.monaco);
      });
    };
    script.onerror = () => reject(new Error("Monaco loader failed to download"));
    document.head.appendChild(script);
  });
  return monacoLoaderPromise;
}

export async function createEditor(containerEl, options = {}) {
  const monaco = await loadMonaco();

  const editor = monaco.editor.create(containerEl, {
    value: options.value || "",
    language: options.language || "python",
    theme: options.theme || "vs-dark",
    automaticLayout: true,
    minimap: { enabled: false },
    fontSize: 14,
    lineNumbers: "on",
    scrollBeyondLastLine: false,
    tabSize: 4,
    insertSpaces: true,
    wordWrap: "on",
    renderWhitespace: "boundary",
    readOnly: !!options.readOnly,
    // Anti-cheat: kill the right-click context menu (offers "Paste",
    // browser-DevTools "Inspect", etc.). HackerRank-style.
    contextmenu: false,
  });

  let lastValue = options.value || "";
  let debounceTimer = null;
  const debounceMs = options.debounceMs || 500;

  if (typeof options.onChange === "function") {
    editor.onDidChangeModelContent(() => {
      const current = editor.getValue();
      if (current === lastValue) return;
      lastValue = current;
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        options.onChange(current);
      }, debounceMs);
    });
  }

  // Anti-cheat: BLOCK paste / drop entirely (HackerRank-style). Capture
  // phase so we run before Monaco's internal paste handler. Also disables
  // the right-click context menu via Monaco options below.
  const _blockClipboard = (e) => {
    e.preventDefault();
    e.stopPropagation();
    let pastedLen = 0;
    try {
      pastedLen = (e.clipboardData?.getData("text") || "").length;
    } catch (_err) { /* clipboard read denied */ }
    if (typeof options.onPaste === "function") {
      options.onPaste({ blocked: true, pasted_text_length: pastedLen });
    }
  };
  containerEl.addEventListener("paste", _blockClipboard, true);
  // Drag-and-drop is another way to inject code — block it.
  const _blockDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (typeof options.onPaste === "function") {
      options.onPaste({ blocked: true, source: "drop" });
    }
  };
  containerEl.addEventListener("drop", _blockDrop, true);
  containerEl.addEventListener("dragover", (e) => e.preventDefault(), true);
  // Monaco also has its own paste action — register a custom action that
  // overrides Ctrl+V/Cmd+V to do nothing (besides notify).
  editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyV, () => {
    if (typeof options.onPaste === "function") {
      options.onPaste({ blocked: true, source: "shortcut" });
    }
  });

  return {
    getValue: () => editor.getValue(),
    setValue: (s) => {
      lastValue = s;
      editor.setValue(s);
    },
    setReadOnly: (ro) => editor.updateOptions({ readOnly: !!ro }),
    focus: () => editor.focus(),
    dispose: () => {
      if (debounceTimer) clearTimeout(debounceTimer);
      editor.dispose();
    },
  };
}
