// Coding panel — UI coordinator. Mounted into a host container when the
// server sends a coding_phase_start message. Manages:
//   - Pyodide worker lifecycle
//   - Monaco editor instance
//   - Run/Submit/Hint button wiring
//   - Output rendering
//   - WS message round-trips
//
// Public API (called by ui/candidate/app.js):
//   const panel = await mountCodingPanel({
//     hostEl,            // DOM element to mount into
//     phaseStartMsg,     // {kind, phase_id, question_id, question_prompt,
//                        //  starter_code, test_cases, time_budget_s, function_name?}
//     sendWS,            // function(msgObj) → posts to server
//   });
//   panel.unmount()
//
// Server contract — see coding/messages.py for the canonical schema.

import { createEditor } from "./editor_wrapper.js";

const PANEL_HTML_URL = new URL("./coding_panel.html", import.meta.url).href;
const PANEL_CSS_URL = new URL("./coding_panel.css", import.meta.url).href;

let workerInstance = null;
let workerReady = false;
let workerReadyPromise = null;

// ---- Worker management (shared across panel mounts so warm_up preload sticks) ----

export function ensureWorker() {
  if (workerInstance) return workerReadyPromise;
  workerInstance = new Worker(
    new URL("./pyodide_worker.js", import.meta.url),
    { type: "classic" }
  );
  workerReadyPromise = new Promise((resolve, reject) => {
    workerInstance.onmessage = (ev) => {
      const m = ev.data || {};
      if (m.kind === "ready") {
        workerReady = true;
        resolve(m);
      } else if (m.kind === "loading") {
        // ignore — handled in mountCodingPanel via separate listener
      } else if (m.kind === "error" && !workerReady) {
        reject(new Error(m.message || "worker init failed"));
      }
    };
  });
  workerInstance.postMessage({ kind: "init" });
  return workerReadyPromise;
}


// ---- Panel lifecycle --------------------------------------------------------

export async function mountCodingPanel({ hostEl, phaseStartMsg, sendWS }) {
  if (!hostEl) throw new Error("mountCodingPanel: hostEl required");

  injectCSS(PANEL_CSS_URL);
  hostEl.innerHTML = await fetchTemplate();

  const root = hostEl.querySelector(".coding-panel");
  const els = {
    title: root.querySelector('[data-bind="title"]'),
    prompt: root.querySelector('[data-bind="prompt"]'),
    timeBudget: root.querySelector('[data-bind="time-budget"]'),
    testCount: root.querySelector('[data-bind="test-count"]'),
    editorMount: root.querySelector('[data-mount="editor"]'),
    tabsMount: root.querySelector('[data-mount="tabs"]'),
    runtime: root.querySelector('[data-bind="runtime"]'),
    stdout: root.querySelector('[data-bind="stdout"]'),
    stderr: root.querySelector('[data-bind="stderr"]'),
    testResults: root.querySelector('[data-bind="test-results"]'),
    status: root.querySelector('[data-bind="status"]'),
    runBtn: root.querySelector('[data-action="run"]'),
    submitBtn: root.querySelector('[data-action="submit"]'),
    hintBtn: root.querySelector('[data-action="hint"]'),
    toggleBtn: root.querySelector('[data-action="toggle-minimize"]'),
    forceTalkBtn: root.querySelector('[data-action="force-talk"]'),
    toggleLabel: root.querySelector('[data-bind="toggle-label"]'),
  };

  const { phase_id } = phaseStartMsg;

  // ── Normalise the phase-start payload into a question list ────────────
  // New form (multi-question): `questions: [{question_id, title,
  //   question_prompt, starter_code, function_name, test_cases,
  //   test_case_count, time_budget_s, difficulty, hint_count}, ...]`
  // Legacy form (single): the same fields at the top level. We synthesise
  // a single-item list so the rest of the code is uniform.
  let questions = Array.isArray(phaseStartMsg.questions)
    ? phaseStartMsg.questions
    : null;
  if (!questions || questions.length === 0) {
    questions = [{
      question_id: phaseStartMsg.question_id || "q",
      title: phaseStartMsg.title || phaseStartMsg.question_id || "Coding exercise",
      question_prompt: phaseStartMsg.question_prompt || "",
      starter_code: phaseStartMsg.starter_code || "",
      function_name: phaseStartMsg.function_name || phaseStartMsg.question_id || "",
      test_cases: phaseStartMsg.test_cases || [],
      test_case_count: (phaseStartMsg.test_cases || []).length,
      time_budget_s: phaseStartMsg.time_budget_s || 600,
      difficulty: phaseStartMsg.difficulty || "",
      hint_count: phaseStartMsg.hint_count || 0,
    }];
  }
  const multiQuestion = questions.length > 1;

  // Per-question state: editor content (string, not Monaco model — single
  // editor instance, swap content on tab change), runCount, last results,
  // submitted flag, time_remaining_s + setInterval id.
  const questionStates = questions.map((q) => ({
    qid: q.question_id,
    title: q.title || q.question_id,
    difficulty: q.difficulty || "",
    prompt: q.question_prompt || "",
    starterCode: q.starter_code || "",
    functionName: q.function_name || q.question_id,
    testCases: q.test_cases || [],
    timeBudgetS: q.time_budget_s || 600,
    timeRemainingS: q.time_budget_s || 600,
    code: q.starter_code || "",     // editor content for this tab
    runCount: 0,
    submitted: false,
    autoSubmitted: false,
    lastResults: null,              // [{name,passed,...}] or null
    lastStdout: "",
    lastStderr: "",
    lastRuntimeMs: 0,
    warned80: false,                // 80%-time reminder fired
    intervalId: null,
  }));

  let activeIdx = 0;

  // ── Tab bar (multi-question only) ────────────────────────────────────
  if (multiQuestion && els.tabsMount) {
    els.tabsMount.hidden = false;
    els.tabsMount.innerHTML = questionStates.map((st, i) => `
      <button type="button" class="coding-tab"
              data-tab-idx="${i}"
              data-difficulty="${st.difficulty}"
              ${i === activeIdx ? 'aria-current="true"' : ""}>
        <span class="coding-tab-num">${i + 1}</span>
        <span class="coding-tab-title">${escapeHTML(st.title)}</span>
        <span class="coding-tab-time" data-bind="tab-time-${i}">--:--</span>
      </button>
    `).join("");
    els.tabsMount.addEventListener("click", (ev) => {
      const btn = ev.target.closest(".coding-tab");
      if (!btn) return;
      const idx = parseInt(btn.dataset.tabIdx, 10);
      if (!isNaN(idx) && idx !== activeIdx) {
        switchTab(idx);
      }
    });
  }

  // Populate the visible question
  const renderActiveQuestion = () => {
    const st = questionStates[activeIdx];
    const qNum = multiQuestion ? `Q${activeIdx + 1} · ` : "";
    els.title.textContent = `${qNum}${st.title}`;
    els.prompt.textContent = (st.prompt || "").trim();
    // Pill text owned by updatePhaseTimerDisplay (MM:SS shared phase
    // timer). Writing "X min left" here was the source of the stale
    // "1 min left" flash on tab switch — the per-question budget
    // rounded to 1 min even when only ~24s actually remained.
    els.testCount.textContent = `${st.testCases.length} tests`;
    // Tab active class
    if (multiQuestion) {
      els.tabsMount.querySelectorAll(".coding-tab").forEach((b, i) => {
        if (i === activeIdx) b.setAttribute("aria-current", "true");
        else b.removeAttribute("aria-current");
        b.classList.toggle("coding-tab-submitted", questionStates[i].submitted);
      });
    }
    // Render output of the active question (cached from its last run)
    els.stdout.textContent = st.lastStdout || 'Click "Run" to test your code.';
    if (st.lastStderr) {
      els.stderr.hidden = false;
      els.stderr.textContent = st.lastStderr;
    } else {
      els.stderr.hidden = true;
      els.stderr.textContent = "";
    }
    els.runtime.textContent = st.lastRuntimeMs ? `${st.lastRuntimeMs}ms` : "";
    els.testResults.innerHTML = "";
    if (st.lastResults) {
      for (const r of st.lastResults) {
        els.testResults.appendChild(renderTestResult(r));
      }
    }
    // Disable Run/Submit when this question is already submitted
    els.runBtn.disabled = st.submitted;
    els.submitBtn.disabled = st.submitted;
  };

  const switchTab = (idx) => {
    if (idx === activeIdx) return;
    // Save current editor content to state before switching
    questionStates[activeIdx].code = editor.getValue();
    activeIdx = idx;
    const st = questionStates[activeIdx];
    editor.setValue(st.code || st.starterCode);
    editor.setReadOnly(!!st.submitted);
    renderActiveQuestion();
    // Sequential timing: pause the previous tab's timer, start the new
    // active tab's timer where it left off.
    if (typeof startActiveTimer === "function") startActiveTimer();
  };

  // ── Anti-cheat helper: toast + persistent violation badge ──────────────
  // HackerRank-style: when paste is blocked or tab focus is lost, show a
  // visible warning in the panel + bump a violation counter pinned in the
  // header. The server also gets a `coding_anti_cheat` event so the admin
  // sees the same signal in the session detail.
  const antiCheat = (() => {
    let violations = 0;
    let toastTimer = null;
    const ensureBadge = () => {
      let badge = root.querySelector(".coding-anti-cheat-badge");
      if (!badge) {
        badge = document.createElement("div");
        badge.className = "coding-anti-cheat-badge";
        badge.hidden = true;
        const header = root.querySelector(".coding-question-header") || root;
        header.appendChild(badge);
      }
      return badge;
    };
    const ensureToast = () => {
      let toast = root.querySelector(".coding-anti-cheat-toast");
      if (!toast) {
        toast = document.createElement("div");
        toast.className = "coding-anti-cheat-toast";
        toast.hidden = true;
        toast.setAttribute("role", "alert");
        root.appendChild(toast);
      }
      return toast;
    };
    const recordViolation = (msg) => {
      violations += 1;
      const badge = ensureBadge();
      badge.textContent = "⚠ " + violations + " warning(s)";
      badge.hidden = false;
      const toast = ensureToast();
      toast.textContent = msg;
      toast.hidden = false;
      if (toastTimer) clearTimeout(toastTimer);
      toastTimer = setTimeout(() => { toast.hidden = true; }, 4500);
    };
    return { recordViolation };
  })();

  // Editor — single instance, content swapped per active tab.
  let _editCount = 0;
  const editor = await createEditor(els.editorMount, {
    value: questionStates[0].starterCode || "",
    language: "python",
    debounceMs: 500,
    onChange: (code) => {
      // Persist into the active question's state so a tab switch
      // doesn't lose typing.
      questionStates[activeIdx].code = code;
      sendWS({
        type: "coding_code_edit",
        phase_id,
        question_id: questionStates[activeIdx].qid,
        code,
        edit_count: ++_editCount,
      });
    },
    onPaste: (info) => {
      sendWS({
        type: "coding_anti_cheat",
        phase_id,
        question_id: questionStates[activeIdx].qid,
        reason: "paste_blocked",
        metadata: info,
      });
      antiCheat.recordViolation(
        "Paste is disabled during the coding interview. Please type your solution.",
      );
    },
  });

  // Legacy `state` shim kept for the worker-message routing — the new
  // per-question state lives in questionStates[activeIdx].
  const state = {
    phaseId: phase_id,
    workerListener: null,
  };

  // Render the initial active question (must run before worker awaits
  // so the prompt is visible while Pyodide is still loading).
  renderActiveQuestion();

  // Ensure worker is ready (may already be preloaded from warm_up)
  setStatus(els, "Loading Python environment…");
  await ensureWorker();
  setStatus(els, "Ready. Click Run to test your code.", "success");
  root.setAttribute("data-coding-state", "ready");

  // Track which run_id corresponds to which question — the worker
  // responds asynchronously and we don't want a switch-tabs race to
  // attribute results to the wrong question.
  const runIdToQid = new Map();   // run_id → qid

  // ---- Per-panel worker message routing ----
  const handleWorkerMsg = (ev) => {
    const m = ev.data || {};
    if (m.kind === "run_result") {
      const targetQid = runIdToQid.get(m.run_id) || questionStates[activeIdx].qid;
      runIdToQid.delete(m.run_id);
      handleRunResultForQid(m, targetQid);
    } else if (m.kind === "error") {
      setStatus(els, `Worker error: ${m.message}`, "error");
    }
  };
  workerInstance.addEventListener("message", handleWorkerMsg);
  state.workerListener = handleWorkerMsg;

  // Helper: run code for a specific qid (NOT necessarily the active tab —
  // used for auto-run on timer expiry of a non-active question).
  const runCodeForQid = (qid, opts = {}) => {
    if (!workerReady) {
      setStatus(els, "Python environment still loading, please wait…");
      return false;
    }
    const idx = questionStates.findIndex((s) => s.qid === qid);
    if (idx < 0) return false;
    const st = questionStates[idx];
    if (st.submitted) return false;
    // If the run is for the ACTIVE question, pull live code from editor;
    // otherwise use cached code from when that tab was last edited.
    const code = (idx === activeIdx) ? editor.getValue() : st.code;
    st.code = code;
    st.runCount += 1;
    if (idx === activeIdx) {
      setStatus(els, opts.silent ? "Auto-running…" : "Running…");
      els.stdout.textContent = "";
      els.stderr.hidden = true;
      els.stderr.textContent = "";
      els.testResults.innerHTML = "";
      els.runtime.textContent = "";
    }
    sendWS({
      type: "coding_code_run",
      phase_id,
      question_id: qid,
      code,
      run_count: st.runCount,
    });
    const run_id = st.runCount * 1000 + idx;  // unique-ish per (qid, runCount)
    runIdToQid.set(run_id, qid);
    workerInstance.postMessage({
      kind: "run",
      run_id,
      code,
      function_name: st.functionName || st.qid,
      test_cases: st.testCases || [],
    });
    return true;
  };

  const handleRunResultForQid = (m, qid) => {
    const idx = questionStates.findIndex((s) => s.qid === qid);
    if (idx < 0) return;
    const st = questionStates[idx];
    st.lastStdout = m.stdout || "";
    st.lastStderr = m.stderr || "";
    st.lastRuntimeMs = m.runtime_ms || 0;
    st.lastResults = m.test_results || [];

    sendWS({
      type: "coding_code_run_result",
      phase_id,
      question_id: qid,
      run_count: st.runCount,
      stdout: st.lastStdout,
      stderr: st.lastStderr,
      runtime_ms: st.lastRuntimeMs,
      test_results: st.lastResults,
    });

    if (idx === activeIdx) {
      renderActiveQuestion();
      const passed = st.lastResults.filter(r => r.passed).length;
      const total = st.lastResults.length;
      const allPassed = total > 0 && passed === total;
      setStatus(
        els,
        `Q${idx + 1}: ${passed}/${total} tests passed`,
        allPassed ? "success" : (passed === 0 ? "error" : "")
      );
    }
  };

  // Submit a specific question (manual or auto-on-timer-expiry).
  const submitQuestion = (qid, opts = {}) => {
    const idx = questionStates.findIndex((s) => s.qid === qid);
    if (idx < 0) return;
    const st = questionStates[idx];
    if (st.submitted) return;
    const code = (idx === activeIdx) ? editor.getValue() : st.code;
    st.code = code;
    st.submitted = true;
    st.autoSubmitted = !!opts.auto;
    if (st.intervalId) {
      clearInterval(st.intervalId);
      st.intervalId = null;
    }
    sendWS({
      type: "coding_code_submitted",
      phase_id,
      question_id: qid,
      final_code: code,
      final_test_results: st.lastResults || [],
      runs_used: st.runCount,
      auto_submitted: !!opts.auto,
    });
    if (idx === activeIdx) {
      editor.setReadOnly(true);
      els.runBtn.disabled = true;
      els.submitBtn.disabled = true;
      setStatus(
        els,
        opts.auto
          ? `Q${idx + 1}: time up — auto-submitted.`
          : `Q${idx + 1}: submitted.`,
        "success",
      );
    }
    // Refresh tab styling to show the submitted badge
    if (multiQuestion) {
      const btn = els.tabsMount.querySelector(`[data-tab-idx="${idx}"]`);
      if (btn) btn.classList.add("coding-tab-submitted");
    }
    // If all questions are submitted, drop a final status line. The server
    // advances the phase once it sees the last submit.
    if (questionStates.every((s) => s.submitted)) {
      setStatus(els, "All questions submitted. Moving on…", "success");
      stopAllTimers();
    } else if (multiQuestion && idx === activeIdx) {
      // Sequential timing: when the active question is submitted, jump
      // to the next un-submitted tab and start its timer. The submitted
      // tab's timer is already stopped (inside submitQuestion).
      const nextIdx = questionStates.findIndex((s) => !s.submitted);
      if (nextIdx >= 0 && nextIdx !== activeIdx) {
        switchTab(nextIdx);
      }
    }
  };

  // ---- Buttons ----
  els.runBtn.addEventListener("click", () => {
    runCodeForQid(questionStates[activeIdx].qid);
  });

  els.submitBtn.addEventListener("click", () => {
    submitQuestion(questionStates[activeIdx].qid);
  });

  els.hintBtn.addEventListener("click", () => {
    sendWS({
      type: "coding_hint_request",
      phase_id,
      question_id: questionStates[activeIdx].qid,
    });
    setStatus(els, "Hint requested. Listen for the AI…");
    setMinimized(true);
  });

  // ── Toggle minimize/expand the panel ────────────────────────────────────
  // While minimized: small floating widget bottom-right, candidate sees avatar.
  // Click the minimized widget OR the toggle button again to restore.
  //
  // Default on mount: EXPANDED. The candidate needs to see the question
  // immediately. The editor mount is now deferred until after the AI's
  // intro line finishes (see _scheduleCodingMount in app.js), so the
  // "popup appears out of nowhere" surprise is handled at a different
  // layer. When candidate clicks Hint or Talk-to-AI, the panel auto-
  // minimizes so the avatar is visible while the AI speaks.
  const host = root.parentElement;  // codingHost div
  const setMinimized = (on) => {
    if (host) host.setAttribute("data-minimized", on ? "1" : "0");
    if (els.toggleLabel) els.toggleLabel.textContent = on ? "Show editor" : "Show AI";
  };
  els.toggleBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    const cur = host && host.getAttribute("data-minimized") === "1";
    setMinimized(!cur);
  });
  // Click anywhere on the minimized widget to expand it
  if (host) {
    host.addEventListener("click", () => {
      if (host.getAttribute("data-minimized") === "1") setMinimized(false);
    });
  }
  // Default = expanded. The toggle button label starts at "Show AI".
  setMinimized(false);

  // ── Force-talk: bypass the coding dispatch gate and have AI speak ───────
  // Sends a `coding_force_talk` message; launcher resets ai_activity so the
  // director's next tick dispatches a turn. Auto-minimizes panel so the
  // candidate can see the avatar.
  els.forceTalkBtn.addEventListener("click", () => {
    sendWS({
      type: "coding_force_talk",
      phase_id,
      question_id: questionStates[activeIdx].qid,
    });
    setStatus(els, "Asked AI to speak. Listen…");
    setMinimized(true);
  });

  // ---- Single phase timer ─────────────────────────────────────────────
  // ONE countdown for the entire coding round — totalTimeBudgetS is the
  // sum of all questions' time budgets. The candidate spends it however
  // they want across tabs. At 80% elapsed → a warning toast fires; at
  // 60s and 10s remaining → final reminders; at 0s → every unsubmitted
  // question gets auto-submitted with its current code.
  const formatMMSS = (s) => {
    s = Math.max(0, Math.floor(s));
    const m = Math.floor(s / 60);
    const r = s % 60;
    return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
  };
  const totalTimeBudgetS = questionStates.reduce(
    (acc, st) => acc + (st.timeBudgetS || 0), 0,
  ) || 600;
  let totalTimeRemainingS = totalTimeBudgetS;
  let phaseTimerId = null;
  let warnedPhase80 = false;

  const updatePhaseTimerDisplay = () => {
    // Show MM:SS in every tab's time slot (since they all share one
    // timer) AND in the main "X min left" pill on the active question.
    const mmss = formatMMSS(totalTimeRemainingS);
    if (multiQuestion && els.tabsMount) {
      questionStates.forEach((st, i) => {
        const el = els.tabsMount.querySelector(`[data-bind="tab-time-${i}"]`);
        if (!el) return;
        el.textContent = st.submitted ? "✓" : mmss;
        const pct = totalTimeRemainingS / totalTimeBudgetS;
        el.classList.toggle("coding-tab-time-warn", pct <= 0.2 && !st.submitted);
        el.classList.toggle("coding-tab-time-crit", pct <= 0.05 && !st.submitted);
      });
    }
    if (els.timeBudget) {
      // Show exact MM:SS so the pill stays in sync with the tab badges
      // — rounding up to "1 min left" while the tab said "0:35" was
      // contradictory.
      els.timeBudget.textContent = totalTimeRemainingS > 0
        ? `${mmss} left`
        : "time up";
    }
  };

  const stopPhaseTimer = () => {
    if (phaseTimerId) {
      clearInterval(phaseTimerId);
      phaseTimerId = null;
    }
  };

  const autoSubmitAllRemaining = () => {
    // Time's up on the phase. Run + submit every question that hasn't
    // been submitted yet so the server has fresh code for each.
    const remaining = questionStates.filter((s) => !s.submitted);
    remaining.forEach((st) => runCodeForQid(st.qid, { silent: true }));
    setTimeout(() => {
      remaining.forEach((st) => submitQuestion(st.qid, { auto: true }));
    }, 800);
  };

  const startPhaseTimer = () => {
    stopPhaseTimer();
    updatePhaseTimerDisplay();
    phaseTimerId = setInterval(() => {
      // Stop early if all questions are already submitted manually
      if (questionStates.every((s) => s.submitted)) {
        stopPhaseTimer();
        return;
      }
      totalTimeRemainingS -= 1;
      updatePhaseTimerDisplay();
      const elapsedPct = 1 - totalTimeRemainingS / totalTimeBudgetS;
      // 80%-elapsed reminder — fires once. Toast text persists for
      // several seconds while the timer keeps ticking, so any specific
      // number we put in here goes stale fast (the user reported
      // "warning says 1 min, timer says 24s"). Refer them to the live
      // pill instead of baking a number into the toast.
      if (!warnedPhase80 && elapsedPct >= 0.8 && totalTimeRemainingS > 0) {
        warnedPhase80 = true;
        antiCheat.recordViolation(
          "Coding time is running low — see the timer next to the question. Wrap up and submit soon.",
        );
      }
      // Final 60s + 10s reminders (catch short rounds)
      if (totalTimeRemainingS === 60 || totalTimeRemainingS === 10) {
        antiCheat.recordViolation(
          `${totalTimeRemainingS}s left — all unsubmitted code will auto-submit.`,
        );
      }
      // Time up → auto-run + auto-submit every unsubmitted question
      if (totalTimeRemainingS <= 0) {
        stopPhaseTimer();
        autoSubmitAllRemaining();
      }
    }, 1000);
  };

  // Compat shims for code paths that previously stopped/started
  // per-question timers (e.g. inside submitQuestion). Now there's only
  // one timer; these become no-ops or aliases.
  const stopAllTimers = stopPhaseTimer;
  const startActiveTimer = () => { /* single-timer model — already running */ };

  startPhaseTimer();

  // ---- Anti-cheat: tab focus loss ----
  // HackerRank-style: any time the candidate switches tabs / windows /
  // alt-tabs we record it, send a coding_anti_cheat event to the server,
  // and show a visible warning on return.
  let focusLostAt = 0;
  const onVisibilityChange = () => {
    if (document.hidden) {
      focusLostAt = Date.now();
    } else if (focusLostAt) {
      const durationMs = Date.now() - focusLostAt;
      sendWS({
        type: "coding_anti_cheat",
        phase_id,
        question_id: questionStates[activeIdx].qid,
        reason: "tab_focus_lost",
        metadata: { duration_ms: durationMs },
      });
      antiCheat.recordViolation(
        "You switched away from this tab for " +
        Math.max(1, Math.round(durationMs / 1000)) +
        "s. Please stay on this page during the coding round.",
      );
      focusLostAt = 0;
    }
  };
  document.addEventListener("visibilitychange", onVisibilityChange);

  // Also block the browser context menu (right-click) at the panel level —
  // catches right-clicks outside the editor (on the question prompt, etc.)
  // that the Monaco contextmenu:false option doesn't cover.
  const onContextMenu = (e) => {
    e.preventDefault();
    sendWS({
      type: "coding_anti_cheat",
      phase_id,
      question_id: questionStates[activeIdx].qid,
      reason: "context_menu_blocked",
      metadata: {},
    });
  };
  root.addEventListener("contextmenu", onContextMenu);

  // ---- Public unmount API ----
  return {
    unmount() {
      if (state.workerListener) {
        workerInstance.removeEventListener("message", state.workerListener);
      }
      document.removeEventListener("visibilitychange", onVisibilityChange);
      root.removeEventListener("contextmenu", onContextMenu);
      // Stop the single phase timer + any (legacy) per-question timers
      // so they don't keep ticking after the phase ends.
      if (typeof stopPhaseTimer === "function") stopPhaseTimer();
      for (const st of questionStates) {
        if (st.intervalId) {
          clearInterval(st.intervalId);
          st.intervalId = null;
        }
      }
      editor.dispose();
      hostEl.innerHTML = "";
    },
    lockEditor() {
      editor.setReadOnly(true);
      for (const st of questionStates) st.submitted = true;
      root.setAttribute("data-coding-state", "submitted");
    },
  };
}

// HTML-escape helper for tab labels (titles come from server payload —
// won't normally contain HTML but better safe than DOM-injection-prone).
function escapeHTML(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}


// ---- Run / Submit -----------------------------------------------------------

function runCode({ editor, els, state, phaseStartMsg, sendWS }) {
  if (!workerReady) {
    setStatus(els, "Python environment still loading, please wait…");
    return;
  }
  state.runCount += 1;
  const code = editor.getValue();

  setStatus(els, "Running…");
  els.stdout.textContent = "";
  els.stderr.hidden = true;
  els.stderr.textContent = "";
  els.testResults.innerHTML = "";
  els.runtime.textContent = "";

  // Tell server we kicked off a run
  sendWS({
    type: "coding_code_run",
    phase_id: state.phaseId,
    code,
    run_count: state.runCount,
  });

  // Send to worker
  workerInstance.postMessage({
    kind: "run",
    run_id: state.runCount,
    code,
    function_name: phaseStartMsg.function_name || phaseStartMsg.question_id,
    test_cases: phaseStartMsg.test_cases || [],
  });
}


function handleRunResult(m, els, state, sendWS) {
  // Render to UI
  els.stdout.textContent = m.stdout || "(no output)";
  if (m.stderr) {
    els.stderr.hidden = false;
    els.stderr.textContent = m.stderr;
  }
  els.runtime.textContent = `${m.runtime_ms}ms`;

  const results = m.test_results || [];
  els.testResults.innerHTML = "";
  for (const r of results) {
    els.testResults.appendChild(renderTestResult(r));
  }

  const passed = results.filter(r => r.passed).length;
  const total = results.length;
  const allPassed = total > 0 && passed === total;
  setStatus(
    els,
    `${passed}/${total} tests passed`,
    allPassed ? "success" : (passed === 0 ? "error" : "")
  );

  // Tell server about the result
  sendWS({
    type: "coding_code_run_result",
    phase_id: state.phaseId,
    run_count: state.runCount,
    stdout: m.stdout || "",
    stderr: m.stderr || "",
    runtime_ms: m.runtime_ms || 0,
    test_results: results,
  });
}


function submitCode({ editor, els, state, phaseStartMsg, sendWS }) {
  const code = editor.getValue();
  const finalTestResults = state.lastTestResults || [];
  sendWS({
    type: "coding_code_submitted",
    phase_id: state.phaseId,
    final_code: code,
    final_test_results: finalTestResults,
    runs_used: state.runCount,
  });
  setStatus(els, "Submitted. Moving on…", "success");
  editor.setReadOnly(true);
  state.submitted = true;
  els.runBtn.disabled = true;
  els.submitBtn.disabled = true;
}


// ---- Helpers ----------------------------------------------------------------

function renderTestResult(r) {
  // Compact format for pass, expanded for fail so the candidate can see
  // input + expected + actual/error and debug without re-reading the prompt.
  const li = document.createElement("li");
  li.classList.add(r.passed ? "coding-test-pass" : "coding-test-fail");

  const header = document.createElement("div");
  header.className = "coding-test-header";

  const icon = document.createElement("span");
  icon.className = "coding-test-icon";
  icon.textContent = r.passed ? "PASS" : "FAIL";

  const name = document.createElement("span");
  name.className = "coding-test-name";
  name.textContent = r.name || "test";

  header.appendChild(icon);
  header.appendChild(name);

  if (r.passed) {
    // Compact: PASS  test_name                          → actual
    const detail = document.createElement("span");
    detail.className = "coding-test-detail";
    detail.textContent = `→ ${r.actual}`;
    header.appendChild(detail);
    li.appendChild(header);
  } else {
    // Expanded: show input + expected + actual/error on separate rows
    li.appendChild(header);
    const body = document.createElement("div");
    body.className = "coding-test-body";
    body.appendChild(makeKV("input", r.input || "(unknown)"));
    body.appendChild(makeKV("expected", r.expected || "(unknown)"));
    if (r.error) {
      body.appendChild(makeKV("error", r.error, "coding-test-error"));
      // Line + source if Pyodide captured the user-code frame
      if (r.error_line) {
        body.appendChild(makeKV("at line", String(r.error_line)));
      }
      if (r.error_source) {
        body.appendChild(makeKV("in code", r.error_source, "coding-test-source"));
      }
    } else {
      body.appendChild(makeKV("got", r.actual || "(no return)", "coding-test-error"));
    }
    // Per-test stdout (pytest-style "Captured stdout call") — shown only
    // when non-empty, since candidates usually print() while debugging
    // and want to see what their function printed for THIS specific input.
    if (r.stdout && r.stdout.trim()) {
      body.appendChild(makeKVBlock("stdout", r.stdout, "coding-test-stdout"));
    }
    if (r.stderr && r.stderr.trim()) {
      body.appendChild(makeKVBlock("stderr", r.stderr, "coding-test-stderr"));
    }
    li.appendChild(body);
  }

  return li;
}

function makeKV(label, value, valueClass = "") {
  const row = document.createElement("div");
  row.className = "coding-test-kv";
  const lbl = document.createElement("span");
  lbl.className = "coding-test-kv-label";
  lbl.textContent = label;
  const val = document.createElement("span");
  val.className = "coding-test-kv-value" + (valueClass ? " " + valueClass : "");
  val.textContent = value;
  row.appendChild(lbl);
  row.appendChild(val);
  return row;
}

// Multi-line variant for stdout / stderr blocks — label on its own row above
// a pre-formatted box. Avoids cramming N lines of print output into one
// inline span.
function makeKVBlock(label, value, valueClass = "") {
  const wrap = document.createElement("div");
  wrap.className = "coding-test-kv-block";
  const lbl = document.createElement("div");
  lbl.className = "coding-test-kv-block-label";
  lbl.textContent = `captured ${label}`;
  const val = document.createElement("pre");
  val.className = "coding-test-kv-block-value" + (valueClass ? " " + valueClass : "");
  val.textContent = value;
  wrap.appendChild(lbl);
  wrap.appendChild(val);
  return wrap;
}

function setStatus(els, text, kind = "") {
  els.status.textContent = text;
  els.status.classList.remove("coding-status-error", "coding-status-success");
  if (kind === "error") els.status.classList.add("coding-status-error");
  if (kind === "success") els.status.classList.add("coding-status-success");
}


let _templateCache = null;
async function fetchTemplate() {
  if (_templateCache) return _templateCache;
  const resp = await fetch(PANEL_HTML_URL);
  _templateCache = await resp.text();
  return _templateCache;
}


function injectCSS(href) {
  if (document.querySelector(`link[data-coding-css="1"]`)) return;
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = href;
  link.setAttribute("data-coding-css", "1");
  document.head.appendChild(link);
}
