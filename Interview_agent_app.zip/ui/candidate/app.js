// app.js — Candidate Interview UI controller.
//
// Single-page app with three screens (lobby / live / done) driven by the
// body[data-screen] attribute. State machine + WS client + mic worklet + UI
// updates all in one module.
//
// URL params (all optional):
//   ?name=Prabhu&role=Backend+Engineer&ws=9000
//   ?demo=1                 ← runs UI without backend (preview-only)
//   ?avatar=URL.glb          ← override default TalkingHead model
//
// Backend wire protocol (server → browser; binary IN are PCM16 mono @ 16kHz):
//   {type:"hello",        sample_rate, start_armed}
//   {type:"audio_start",  text, sample_rate, sub_id}
//   <binary PCM16 LE>
//   {type:"audio_end",    sub_id}
//   {type:"audio_cancel", sub_id}                     ← barge-in
//   {type:"stt_partial",  text}                       ← live transcript
//   {type:"stt_final",    text}
//   {type:"session_end"}                              ← interview done
//
// Browser → server messages:
//   {type:"start", visual_mode, candidate_meta}        ← begin interview
//   {type:"end"}                                       ← user clicked End
//   <binary PCM16 LE @ 16kHz>                          ← mic frames

import { TalkingHead } from "talkinghead";

// ── URL params ───────────────────────────────────────────────────────────
const URL_PARAMS = new URLSearchParams(window.location.search);
const PARAM = {
  name:     URL_PARAMS.get("name")   || "Candidate",
  role:     URL_PARAMS.get("role")   || "the role",
  wsPort:   URL_PARAMS.get("ws")     || "9000",
  demo:     URL_PARAMS.get("demo") === "1",
  // Standalone coding-panel preview — does NOT require backend / cadence /
  // director integration. Mounts the panel with a hardcoded question so you
  // can validate Monaco + Pyodide + Run + Submit flow without an interview.
  //   ?demo_coding=1                  → uses running_sum (default)
  //   ?demo_coding=two_sum            → uses two_sum
  //   ?demo_coding=palindrome_check   → uses palindrome
  demoCoding: URL_PARAMS.get("demo_coding") || "",
  avatar:   URL_PARAMS.get("avatar")
            || "https://cdn.jsdelivr.net/gh/met4citizen/TalkingHead@1.7/avatars/brunette.glb",
  // Token is just carried in the URL for traceability. The orchestrator
  // already knows the candidate by token via SQLite when it was spawned
  // with --scheduled-token, so we don't need to send it over the wire.
  token:    URL_PARAMS.get("token") || "",
};

// ── DOM refs ─────────────────────────────────────────────────────────────
const $ = (id) => document.getElementById(id);
const els = {
  body:          document.body,
  // lobby
  lobbyName:     $("lobbyName"),
  lobbyRole:     $("lobbyRole"),
  lobbyDuration: $("lobbyDuration"),
  micStatus:     $("micStatus"),
  micMeterLobby: $("micMeterLobby"),
  btnEnableMic:  $("btnEnableMic"),
  spkStatus:     $("spkStatus"),
  btnTestSpeaker:$("btnTestSpeaker"),
  browserStatus: $("browserStatus"),
  browserPill:   $("browserPill"),
  connStatus:    $("connStatus"),
  connPill:      $("connPill"),
  btnStartInterview: $("btnStartInterview"),
  // live
  connDot:       $("connDot"),
  connLabel:     $("connLabel"),
  sessionTimer:  $("sessionTimer"),
  btnEndInterview: $("btnEndInterview"),
  avatarEl:      $("avatar"),
  orb:           $("orb"),
  turnIndicator: $("turnIndicator"),
  turnLabel:     $("turnLabel"),
  aiCaption:     $("aiCaption"),
  aiCaptionText: $("aiCaptionText"),
  youTranscriptText: $("youTranscriptText"),
  micMeterLive:  $("micMeterLive"),
  volumeSlider:  $("volumeSlider"),
  // done
  doneName:      $("doneName"),
  btnCloseWindow:$("btnCloseWindow"),
  // modal/toast
  modal:         $("modal"),
  modalTitle:    $("modalTitle"),
  modalBody:     $("modalBody"),
  modalPrimary:  $("modalPrimary"),
  modalSecondary:$("modalSecondary"),
  toast:         $("toast"),
};

// ── Controller ───────────────────────────────────────────────────────────
class CandidateApp {
  constructor() {
    this.screen           = "lobby";
    this.visualMode       = "minimal";    // or "avatar" — Ava's orb is the default
    this.checks           = { mic: false, speaker: false, browser: false, connection: false };
    this.audioCtx         = null;
    this.micStream        = null;
    this.micNode          = null;
    this.micWorklet       = null;
    this.head             = null;          // TalkingHead instance
    this.ws               = null;
    this.sessionStart     = 0;
    this.timerInterval    = null;
    this.orbAnim          = null;          // RAF id for orb
    this.lastAiTalk       = 0;             // ts of last AI audio chunk for turn indicator
    // ── AI audio receive + play state ────────────────────────────────────
    // A multi-sentence AI response arrives as several "chunks", each one
    // framed by audio_start → binary PCM frames → audio_end. Each chunk
    // carries its own TEXT and the chunks must play SEQUENTIALLY through
    // the speakers. We can NOT update the caption on audio_start because
    // chunks 2/3/4 arrive within milliseconds while chunk 1 audio is still
    // playing — the caption would race ahead of the sound. Instead:
    //
    //   • _activeRecv: receive buffer for the CURRENTLY arriving chunk
    //                  (filled by audio_start + binary frames; sealed on audio_end)
    //   • _aiQueue:    sealed chunks waiting to play
    //   • _playerActive: a single-flight loop that drains _aiQueue,
    //                    updating the caption right before each chunk
    //                    plays and waiting that chunk's duration before
    //                    advancing to the next chunk.
    this.currentSampleRate= 16000;
    this._activeRecv      = null;          // {sub_id, text, pcmChunks[], sampleRate} | null
    this._aiQueue         = [];            // queue of sealed chunks ready to play
    this._playerActive    = false;
    this.toastTimer       = null;
    // AI output amplification. Browsers cap <audio>.volume at 1.0 and the
    // TalkingHead avatar manages its own AudioContext (so a GainNode on
    // our own ctx doesn't reach it). We instead boost the PCM samples in
    // JS before handing them to TalkingHead/AudioBufferSource. Range is
    // wired to the volumeSlider in the live header (1.0–3.0).
    this.aiVolumeGain     = 2.0;
  }

  // ── boot ───────────────────────────────────────────────────────────────
  init() {
    els.lobbyName.textContent = PARAM.name;
    els.lobbyRole.textContent = PARAM.role;
    els.doneName.textContent  = PARAM.name;

    // Estimated time is derived from THIS candidate's cadence (sum of phase
    // budgets), not a hardcoded "~30 minutes". Fire-and-forget — if the
    // fetch fails the static fallback text stays.
    this.loadEstimatedTime();

    // Admin Login link points at the admin web app on :8000. The candidate
    // UI is served by the orchestrator on :8090, so we have to switch ports.
    const adminLink = document.getElementById("lnkAdmin");
    if (adminLink) {
      const host = window.location.hostname || "localhost";
      adminLink.href = `http://${host}:8000/admin/login`;
    }

    this.detectBrowser();
    this.measureConnection();

    els.btnEnableMic.addEventListener("click",     () => this.enableMic());
    els.btnTestSpeaker.addEventListener("click",   () => this.testSpeaker());
    els.btnStartInterview.addEventListener("click",() => this.startInterview());
    els.btnEndInterview.addEventListener("click",  () => this.endInterview());
    els.btnCloseWindow.addEventListener("click",   () => this.closeOrFallback());
    els.modalPrimary.addEventListener("click",     () => this.hideModal());
    if (els.volumeSlider) {
      els.volumeSlider.value = String(this.aiVolumeGain);
      els.volumeSlider.addEventListener("input", (e) => {
        const v = parseFloat(e.target.value);
        if (!Number.isNaN(v)) this.aiVolumeGain = v;
      });
    }
    document.querySelectorAll('input[name="visualMode"]').forEach(input => {
      input.addEventListener("change", (e) => {
        this.visualMode = e.target.value;
        document.body.dataset.visual = this.visualMode;
      });
    });
    document.body.dataset.visual = "minimal";
  }

  // ── lobby: estimated interview time from cadence ────────────────────────
  // The backend derives this from the candidate's cadence (sum of phase
  // budgets) so a 15- or 45-minute plan shows the right figure instead of a
  // hardcoded "~30 minutes". On any failure we leave the static fallback.
  async loadEstimatedTime() {
    if (!els.lobbyDuration) return;
    try {
      const qs = PARAM.token ? `?token=${encodeURIComponent(PARAM.token)}` : "";
      const resp = await fetch(`/session-info${qs}`, { cache: "no-store" });
      if (!resp.ok) return;
      const data = await resp.json();
      const mins = parseInt(data && data.duration_min, 10);
      if (Number.isFinite(mins) && mins > 0) {
        els.lobbyDuration.textContent = `~${mins} minute${mins === 1 ? "" : "s"}`;
      }
    } catch (_) { /* keep the static fallback text */ }
  }

  // ── screen switching ───────────────────────────────────────────────────
  setScreen(name) {
    this.screen = name;
    els.body.dataset.screen = name;
  }


  // ── close window — graceful fallback ─────────────────────────────────
  // window.close() only works for windows opened by JS via window.open().
  // For tabs the user opened directly (or via a candidate link), modern
  // browsers silently refuse. We try close() first, then fall back to a
  // friendly "you can close this tab now" replacement so the button feels
  // like it did something.
  closeOrFallback() {
    try { window.close(); } catch (_) {}
    // If we're still here after the try, replace the page with a clear
    // closure-instruction view.
    setTimeout(() => {
      document.body.innerHTML = `
        <div style="height:100vh;display:grid;place-items:center;text-align:center;padding:40px;">
          <div>
            <div style="font-size:48px;margin-bottom:16px;">✓</div>
            <h1 style="font-family:Inter,sans-serif;font-size:22px;margin:0 0 8px;color:#1a0010;">Interview submitted</h1>
            <p style="font-family:Inter,sans-serif;color:#80606e;margin:0;">You can close this tab now.</p>
          </div>
        </div>`;
    }, 50);
  }

  // ── lobby: browser check ───────────────────────────────────────────────
  detectBrowser() {
    const ua = navigator.userAgent;
    let name = "Unknown", ok = false;
    if (/Edg\//.test(ua))         { name = "Edge";    ok = true; }
    else if (/Chrome\//.test(ua)) { name = "Chrome";  ok = true; }
    else if (/Firefox\//.test(ua)){ name = "Firefox"; ok = true; }
    else if (/Safari\//.test(ua)) { name = "Safari";  ok = false; }  // AudioWorklet quirks
    const version = (ua.match(/(?:Chrome|Edg|Firefox|Safari)\/(\d+)/) || [])[1] || "?";
    els.browserStatus.textContent = `${name} ${version}`;
    els.browserPill.textContent   = ok ? "OK" : "Unsupported";
    els.browserPill.dataset.state = ok ? "ok"  : "error";
    this.setCheckState("browser", ok ? "ok" : "error");
    this.checks.browser = ok;
    this.updateStartButton();
    if (!ok) {
      this.showModal({
        title: "Browser not supported",
        body:  "Please open this page in Chrome or Edge. Safari and older browsers have AudioWorklet limitations that prevent reliable voice capture.",
      });
    }
  }

  // ── lobby: connection latency check ────────────────────────────────────
  async measureConnection() {
    if (PARAM.demo) {
      els.connStatus.textContent = "Demo mode (no backend)";
      els.connPill.textContent   = "demo";
      els.connPill.dataset.state = "warn";
      this.checks.connection = true;
      this.setCheckState("connection", "warn");
      this.updateStartButton();
      return;
    }
    // Ping the WS broker by opening + closing a temp socket and timing it.
    const url = this.wsUrl();
    const t0 = performance.now();
    try {
      const probe = await this.probeWs(url, 4000);
      const ms = Math.round(performance.now() - t0);
      let state = "ok";
      if (ms > 300) state = "warn";
      if (ms > 800) state = "error";
      els.connStatus.textContent = `Healthy (${ms}ms)`;
      els.connPill.textContent   = `${ms}ms`;
      els.connPill.dataset.state = state;
      this.setCheckState("connection", state);
      this.checks.connection = state !== "error";
      probe.close();
    } catch (err) {
      els.connStatus.textContent = "Cannot reach interview server";
      els.connPill.textContent   = "down";
      els.connPill.dataset.state = "error";
      this.setCheckState("connection", "error");
      this.checks.connection = false;
    }
    this.updateStartButton();
  }

  probeWs(url, timeoutMs) {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(url);
      const to = setTimeout(() => { try { ws.close(); } catch {} reject(new Error("timeout")); }, timeoutMs);
      ws.addEventListener("open",  () => { clearTimeout(to); resolve(ws); });
      ws.addEventListener("error", () => { clearTimeout(to); reject(new Error("error")); });
    });
  }

  wsUrl() {
    // Two deployment shapes:
    //   • Local dev: orchestrator runs WS on a dedicated port (default 9100)
    //     and serves static UI on a different port (8090). The lobby URL
    //     therefore carries ?ws=9100 so the browser knows where to connect.
    //   • Azure App Service: ONE port for everything. Static UI and the
    //     WebSocket share the page's own origin, with WS on the path
    //     /ws/candidate/{session_id}. No ?ws= needed.
    const params = new URLSearchParams(window.location.search);
    if (params.has("ws")) {
      const host = window.location.hostname || "localhost";
      return `ws://${host}:${params.get("ws")}`;
    }
    // Azure (or any single-port HTTPS deploy) — same origin, /ws/candidate/<uuid>.
    // If the page URL carries ?token=<uuid>, forward it on the WS URL too —
    // the server's _session_runner uses it to look up the scheduled
    // session's cadence + resume from SQLite. Without the token, the
    // server falls back to default cadence + URL-param name/role.
    const sid = (window.crypto && window.crypto.randomUUID)
      ? window.crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    const scheme = window.location.protocol === "https:" ? "wss" : "ws";
    const tokenParam = params.get("token");
    const tokenQuery = tokenParam ? `?token=${encodeURIComponent(tokenParam)}` : "";
    return `${scheme}://${window.location.host}/ws/candidate/${sid}${tokenQuery}`;
  }

  // ── lobby: mic enable + level ──────────────────────────────────────────
  async enableMic() {
    els.btnEnableMic.disabled = true;
    els.micStatus.textContent = "Requesting permission…";
    try {
      // Browser does AEC/AGC/NS for free — this is the whole point of Track B.
      this.micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl:  true,
          channelCount:     1,
        },
        video: false,
      });
      // Spin up an AudioContext + worklet
      this.audioCtx = this.audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (this.audioCtx.state === "suspended") await this.audioCtx.resume();
      try {
        await this.audioCtx.audioWorklet.addModule("mic-worklet.js");
      } catch (err) {
        throw new Error("AudioWorklet failed to load: " + err.message);
      }
      const source = this.audioCtx.createMediaStreamSource(this.micStream);
      this.micWorklet = new AudioWorkletNode(this.audioCtx, "mic-capture");
      this.micWorklet.port.onmessage = (e) => this.onMicMessage(e.data);
      source.connect(this.micWorklet);
      // Do NOT connect worklet to destination (no monitoring loopback).

      els.micStatus.textContent = "Active — speak normally";
      els.btnEnableMic.textContent = "Enabled";
      this.checks.mic = true;
      this.setCheckState("mic", "ok");
      this.updateStartButton();
    } catch (err) {
      console.error(err);
      els.btnEnableMic.disabled = false;
      els.micStatus.textContent = "Permission denied or device error";
      this.setCheckState("mic", "error");
      this.showModal({
        title: "Microphone access needed",
        body:  "We can't run the interview without microphone access. Click the 🔒 in your address bar and allow microphone, then refresh the page.",
      });
    }
  }

  onMicMessage(msg) {
    if (msg.type === "meter") {
      // RMS is roughly 0..0.5 for normal speech
      const pct = Math.min(100, msg.rms * 600);
      els.micMeterLobby.style.width = pct + "%";
      els.micMeterLive.style.width  = pct + "%";
      this._orbMicRms = msg.rms; // read by startOrbAnim() for the "listening" glow
      // If we've been quiet for 30s during live, hint to the user
      if (this.screen === "live") this.maybeWarnLowMic(msg.rms);
    } else if (msg.type === "pcm") {
      // Forward PCM16 frame to backend (or just discard if demo/no-ws)
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        try { this.ws.send(msg.buffer); } catch {}
      }
    }
  }

  maybeWarnLowMic(rms) {
    if (!this._lowMicWindow) this._lowMicWindow = { start: Date.now(), totalSilent: 0, lastWarn: 0 };
    const now = Date.now();
    if (rms < 0.01) {
      // Quiet sample — track a running window
      if (now - this._lowMicWindow.lastWarn > 30000 && now - this._lowMicWindow.start > 30000) {
        this.showToast("We're barely hearing you — move closer or check your mic.");
        this._lowMicWindow.lastWarn = now;
      }
    } else {
      this._lowMicWindow = { start: now, totalSilent: 0, lastWarn: this._lowMicWindow.lastWarn };
    }
  }

  // ── lobby: speaker test ────────────────────────────────────────────────
  async testSpeaker() {
    this.audioCtx = this.audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    if (this.audioCtx.state === "suspended") await this.audioCtx.resume();
    els.spkStatus.textContent = "Playing test tone…";
    els.btnTestSpeaker.disabled = true;
    // Pleasant short chime — major triad up-arp
    const now = this.audioCtx.currentTime;
    const notes = [523.25, 659.25, 783.99]; // C5 E5 G5
    notes.forEach((f, i) => {
      const o = this.audioCtx.createOscillator();
      const g = this.audioCtx.createGain();
      o.frequency.value = f;
      o.type = "sine";
      g.gain.setValueAtTime(0, now + i * 0.12);
      g.gain.linearRampToValueAtTime(0.12, now + i * 0.12 + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.12 + 0.25);
      o.connect(g).connect(this.audioCtx.destination);
      o.start(now + i * 0.12);
      o.stop(now + i * 0.12 + 0.3);
    });
    setTimeout(() => {
      els.spkStatus.textContent = "Did you hear that? ✓";
      els.btnTestSpeaker.disabled = false;
      els.btnTestSpeaker.textContent = "Play again";
      this.checks.speaker = true;
      this.setCheckState("speaker", "ok");
      this.updateStartButton();
    }, 600);
  }

  setCheckState(name, state) {
    const row = document.querySelector(`.check-row[data-check="${name}"]`);
    if (row) row.dataset.state = state;
  }

  updateStartButton() {
    const ready = this.checks.mic && this.checks.speaker && this.checks.browser && this.checks.connection;
    els.btnStartInterview.disabled = !ready;
    if (ready) els.btnStartInterview.textContent = "Start Interview";
    else        els.btnStartInterview.textContent = "Complete checks above";
  }

  // ── transition to live ─────────────────────────────────────────────────
  async startInterview() {
    this.setScreen("live");
    this.startTimer();
    this.setTurnState("listening", "Connecting…");

    // Show a "preparing" caption immediately so the candidate doesn't sit
    // in silence wondering if anything is happening. The AI's first
    // greeting can take a few seconds (slow LLM TTFT + Kokoro cold-start).
    // The player loop's _setCaption() call (right before the first audio
    // chunk plays) naturally overwrites this with the real greeting text.
    this._setCaption("Your interviewer is preparing to greet you…");

    // Unlock audio: browser autoplay policy gates AudioContext + speech
    // synthesis behind a user gesture. The Start click IS the gesture —
    // resume our own ctx, prime SpeechSynthesis voices, and (after
    // bootAvatar) resume the TalkingHead's internal audioCtx too.
    try {
      this.audioCtx = this.audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (this.audioCtx.state === "suspended") await this.audioCtx.resume();
    } catch {}
    if (window.speechSynthesis) {
      // Trigger voice loading (Chrome returns [] on first call until the
      // voiceschanged event fires; a no-op speak primes it).
      try {
        const probe = new SpeechSynthesisUtterance("");
        window.speechSynthesis.speak(probe);
      } catch {}
    }

    if (this.visualMode === "avatar") {
      await this.bootAvatar();
      try {
        if (this.head?.audioCtx && this.head.audioCtx.state === "suspended") {
          await this.head.audioCtx.resume();
        }
      } catch {}
    } else {
      this.startOrbAnim();
    }

    if (PARAM.demo) {
      this.runDemoLoop();
      return;
    }
    this.connectInterviewWs();
  }

  startTimer() {
    this.sessionStart = Date.now();
    this.timerInterval = setInterval(() => {
      const ms = Date.now() - this.sessionStart;
      const s  = Math.floor(ms / 1000);
      const mm = String(Math.floor(s / 60)).padStart(2, "0");
      const ss = String(s % 60).padStart(2, "0");
      els.sessionTimer.textContent = `${mm}:${ss}`;
    }, 1000);
  }

  setTurnState(state, label) {
    els.turnIndicator.dataset.state = state;
    els.turnLabel.textContent = label;
  }

  setConn(state, label) {
    els.connDot.dataset.state   = state;
    els.connLabel.textContent   = label;
  }

  // ── avatar (TalkingHead) ───────────────────────────────────────────────
  async bootAvatar() {
    try {
      this.head = new TalkingHead(els.avatarEl, {
        cameraView: "upper",
        lipsyncModules: ["en"],
        modelPixelRatio: window.devicePixelRatio || 1,
        pcmSampleRate: this.currentSampleRate,
      });
      await this.head.showAvatar({
        url: PARAM.avatar,
        body: PARAM.avatar.toLowerCase().includes("brunette") ? "F" : "M",
        avatarMood: "neutral",
        lipsyncLang: "en",
      });
    } catch (err) {
      console.error("avatar boot failed", err);
      this.visualMode = "minimal";
      document.body.dataset.visual = "minimal";
      this.startOrbAnim();
    }
  }

  // ── minimal orb visual (Ava) ────────────────────────────────────────────
  // CSS-driven, no canvas: each frame just writes --level (0..1, real
  // amplitude) and --mix (-1 listening / 0 idle / +1 speaking) onto the
  // orb root; every gradient/blur in style.css is a fixed constant reading
  // those two vars, so this stays compositor-only. --level comes from the
  // AI's own playback analyser while speaking, or the mic worklet's RMS
  // while the candidate is talking — smoothed with a fast attack / slower
  // release so it reads as alive rather than jittery.
  startOrbAnim() {
    const root = els.orb;
    if (!root) return;
    let level = 0.08, mix = 0;
    const tick = () => {
      const now = performance.now();
      const speaking  = (Date.now() - this.lastAiTalk) < 800;
      const micRms    = this._orbMicRms || 0;
      const listening = !speaking && micRms > 0.015;

      let target, mixTarget;
      if (speaking) {
        target = this.readAiPlaybackLevel();
        mixTarget = 1;
      } else if (listening) {
        target = Math.min(1, micRms * 6); // same scale as the mic meter bars
        mixTarget = -1;
      } else {
        target = 0.08 + 0.04 * Math.sin(now * 0.0008);
        mixTarget = 0;
      }
      target = Math.max(0, Math.min(1, target));

      const rate = target > level ? 0.32 : 0.12; // fast attack, slower release
      level += (target - level) * rate;
      mix += (mixTarget - mix) * 0.08;

      root.style.setProperty("--level", level.toFixed(3));
      root.style.setProperty("--mix", mix.toFixed(3));

      this.orbAnim = requestAnimationFrame(tick);
    };
    this.orbAnim = requestAnimationFrame(tick);
  }
  stopOrbAnim() { if (this.orbAnim) cancelAnimationFrame(this.orbAnim); this.orbAnim = null; }

  // Real amplitude off the AI's own audio graph (see _kickPlayer, which
  // routes each chunk through this.aiAnalyser). Falls back to a steady hum
  // for the first frame or two right after audio_start, before any PCM has
  // actually reached the analyser.
  readAiPlaybackLevel() {
    if (!this.aiAnalyser || !this.aiAnalyserData) return 0.45;
    this.aiAnalyser.getByteTimeDomainData(this.aiAnalyserData);
    let sum = 0;
    for (let i = 0; i < this.aiAnalyserData.length; i++) {
      const v = (this.aiAnalyserData[i] - 128) / 128;
      sum += v * v;
    }
    return Math.min(1, Math.sqrt(sum / this.aiAnalyserData.length) * 3.2);
  }

  // ── WebSocket to backend ───────────────────────────────────────────────
  connectInterviewWs() {
    const url = this.wsUrl();
    this.ws = new WebSocket(url);
    this.ws.binaryType = "arraybuffer";
    let reconnectAttempts = 0;

    this.ws.addEventListener("open", () => {
      this.setConn("ok", "Connected");
      // Tell backend the user clicked Start
      this.ws.send(JSON.stringify({
        type: "start",
        visual_mode: this.visualMode,
        candidate: { name: PARAM.name, role: PARAM.role },
      }));
      this.setTurnState("listening", "Listening…");
    });

    this.ws.addEventListener("message", (evt) => this.onWsMessage(evt));

    this.ws.addEventListener("close", () => {
      this.setConn("error", "Disconnected");
      if (this.screen === "live" && reconnectAttempts < 3) {
        reconnectAttempts++;
        this.showToast(`Connection dropped — reconnecting (${reconnectAttempts}/3)…`);
        setTimeout(() => this.connectInterviewWs(), 1500 * reconnectAttempts);
      } else if (this.screen === "live") {
        this.showModal({
          title: "Lost connection",
          body:  "We couldn't reconnect after 3 attempts. Please refresh the page to try again. Your session may resume where it left off.",
          primaryLabel: "Refresh",
          onPrimary: () => window.location.reload(),
        });
      }
    });

    this.ws.addEventListener("error", (e) => {
      console.error("ws error", e);
      this.setConn("warn", "Connection issue");
    });
  }

  async onWsMessage(evt) {
    if (typeof evt.data === "string") {
      let msg;
      try { msg = JSON.parse(evt.data); } catch { return; }
      await this.handleControlMessage(msg);
    } else {
      // Binary PCM from server — append to the active receive buffer.
      if (this._activeRecv) this._activeRecv.pcmChunks.push(evt.data);
    }
  }

  async handleControlMessage(msg) {
    switch (msg.type) {
      case "hello":
        if (msg.sample_rate) this.currentSampleRate = msg.sample_rate;
        break;

      case "audio_start":
        // Open a fresh per-chunk receive buffer. We DO NOT update the
        // caption here — that's the player loop's job, fired only when
        // the chunk actually starts playing through the speakers. Showing
        // the text on audio_start leaks the answer before the candidate
        // hears it AND races ahead when there are multiple chunks per
        // utterance (chunks 2/3/4 arrive within ms while chunk 1 plays).
        if (msg.sample_rate) this.currentSampleRate = msg.sample_rate;
        this._activeRecv = {
          sub_id: msg.sub_id || "",
          text: msg.text || "",
          pcmChunks: [],
          sampleRate: msg.sample_rate || this.currentSampleRate,
        };
        this.lastAiTalk = Date.now();
        this.setTurnState("speaking", "AI is speaking");
        // Mark AI-speaking so any LATE stt_partial / stt_final from the
        // candidate's previous utterance is suppressed (otherwise the
        // server's tail-end Azure delivery overwrites the cleared box
        // RIGHT after we clear it, and the previous transcript reappears
        // while the AI is asking the next question).
        this._aiSpeaking = true;
        if (els.youTranscriptText) {
          els.youTranscriptText.textContent = "";
        }
        break;

      case "audio_end":
        // Seal the buffer and hand it to the player loop. The audio_end
        // message gives us the COMPLETE chunk PCM; the player can compute
        // exact duration and update the caption at the right moment.
        if (this._activeRecv && this._activeRecv.pcmChunks.length > 0) {
          this._aiQueue.push(this._activeRecv);
          this._kickPlayer();
        }
        this._activeRecv = null;
        // If a coding phase was announced and we're waiting for the AI's
        // intro to finish before mounting the editor, mount on the audio
        // queue draining. This avoids the "editor pops up before AI says
        // anything" surprise. See _scheduleCodingMount.
        if (this._pendingCodingMount) {
          this._codingMountWhenAudioIdle();
        }
        // Note: turn indicator stays in "speaking" until the queue drains
        // (handled in _kickPlayer's finally clause).
        break;

      case "audio_cancel":
        // Barge-in — drop the in-flight receive buffer, drain the queue,
        // stop any audio TalkingHead is mid-playback, and clear the caption.
        this._activeRecv = null;
        this._aiQueue.length = 0;
        try { this.head?.stopSpeaking(); } catch {}
        this.setTurnState("listening", "Your turn");
        this._setCaption("");
        // Candidate barged in → they're speaking → STT updates resume.
        this._aiSpeaking = false;
        break;

      case "stt_partial":
        // The AI-speaking gate drops the candidate's late STT deliveries
        // (the source of the "previous answer reappears" bug).
        if (this._aiSpeaking) break;
        els.youTranscriptText.textContent = (msg.text || "") + "…";
        break;

      case "stt_final":
        if (this._aiSpeaking) break;
        els.youTranscriptText.textContent = msg.text || "";
        break;

      case "session_end":
        this.endInterview();
        break;

      // ── Coding feature (CODING_ENABLED on server) ──────────────────
      // Lazy-import the coding panel module on first phase_start so the
      // ~10 KB of editor/Pyodide glue is NOT in the default bundle.
      // Pyodide WASM itself (~6 MB) downloads inside the worker on its
      // first init — kicked off here on coding_preload during warm_up.
      case "coding_preload":
        this._codingPreload().catch(err => console.warn("[coding] preload:", err));
        break;

      case "coding_phase_start":
        console.log("[coding] RECEIVED coding_phase_start", msg);
        // Wait for the AI's intro line to finish playing before mounting
        // the editor. Prevents the "editor pops up out of nowhere" surprise
        // candidates reported. Audio_end of the next AI utterance triggers
        // the mount; an 18-second fallback covers slow LLM cases.
        this._scheduleCodingMount(msg);
        break;

      case "coding_phase_end":
        this._unmountCodingPanel();
        break;

      case "coding_hint":
        // Surface in the dedicated hint banner inside the coding panel.
        // The hint dispatcher (launcher) sends text from library.yaml.
        if (msg.hint_text) {
          try {
            const el = document.querySelector('.coding-hint-display');
            if (el) {
              el.textContent = msg.hint_text;
              el.setAttribute('data-level', String(msg.hint_level || 1));
              el.hidden = false;
            }
          } catch {}
        }
        break;
    }
  }

  async _codingPreload() {
    if (this._codingModulePromise) return this._codingModulePromise;
    this._codingModulePromise = import("./coding/coding_panel.js");
    const mod = await this._codingModulePromise;
    // Kick off Pyodide download in the worker — hidden by warm_up duration
    await mod.ensureWorker().catch(err => console.warn("[coding] worker:", err));
  }

  // Defer the editor mount until the AI's intro line has finished playing.
  // Without this, the editor pops up the moment the phase starts, before
  // the AI has said anything — candidates report this as jarring. We
  // stash the phase_start payload and wait for the next audio_end (or
  // a fallback timer if the AI is unusually quiet).
  _scheduleCodingMount(phaseStartMsg) {
    this._pendingCodingMount = phaseStartMsg;
    // Cancel any prior timer (defensive — should never happen).
    if (this._codingMountTimer) {
      clearTimeout(this._codingMountTimer);
    }
    // Fallback: if no audio_end arrives in 18s, mount anyway. The phase
    // intro should typically be <10s; 18s leaves slack for slow LLM TTFT.
    this._codingMountTimer = setTimeout(() => {
      console.log("[coding] mount-deferral fallback timer fired");
      this._codingMountWhenAudioIdle();
    }, 18000);
    // Inform the candidate something is about to happen — small toast in
    // the top-right corner. Reuses the avatar speaking caption space.
    this._setCaption("Coding round starting — the editor will appear after this introduction.");
  }

  _codingMountWhenAudioIdle() {
    if (!this._pendingCodingMount) return;
    // If the AI audio queue still has items pending playback, wait until
    // the queue drains naturally (next audio_end will re-enter this fn).
    if (this._aiQueue && this._aiQueue.length > 0) {
      return;
    }
    const msg = this._pendingCodingMount;
    this._pendingCodingMount = null;
    if (this._codingMountTimer) {
      clearTimeout(this._codingMountTimer);
      this._codingMountTimer = null;
    }
    // Small grace so the last audio chunk's audible tail isn't cut off
    // by the editor mount's visual snap.
    setTimeout(() => {
      this._mountCodingPanel(msg).catch(err => console.error("[coding] mount FAILED:", err));
    }, 400);
  }

  async _mountCodingPanel(phaseStartMsg) {
    console.log("[coding] _mountCodingPanel called");
    // Lazy-import if preload didn't fire (e.g., cadence skipped warm_up)
    if (!this._codingModulePromise) {
      console.log("[coding] importing coding_panel.js module...");
      this._codingModulePromise = import("./coding/coding_panel.js");
    }
    const mod = await this._codingModulePromise;
    console.log("[coding] module loaded, exports:", Object.keys(mod));

    // Tear down any prior panel FIRST (defensive). This sets display:none
    // on the host — we re-show it below right before mounting the new panel.
    this._unmountCodingPanel();

    // Host element: dedicated div added to the live screen. We create it
    // on demand so the existing layout doesn't shift when feature is off.
    let host = document.getElementById("codingHost");
    if (!host) {
      host = document.createElement("div");
      host.id = "codingHost";
      host.className = "coding-host";
      // Insert into the live-screen DOM — adjust selector if your layout differs.
      const liveScreen = document.body;
      liveScreen.appendChild(host);
    }
    // MUST happen AFTER _unmountCodingPanel which sets display:none.
    host.style.display = "block";
    console.log("[coding] mounting panel into host element:", host);
    this._codingPanel = await mod.mountCodingPanel({
      hostEl: host,
      phaseStartMsg,
      sendWS: (m) => {
        try {
          if (this.ws && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(JSON.stringify(m));
          }
        } catch (err) {
          console.warn("[coding] sendWS failed:", err);
        }
      },
    });
    console.log("[coding] panel mounted successfully");
  }

  _unmountCodingPanel() {
    if (this._codingPanel) {
      try { this._codingPanel.unmount(); } catch (err) { console.warn("[coding] unmount:", err); }
      this._codingPanel = null;
    }
    const host = document.getElementById("codingHost");
    if (host) host.style.display = "none";
  }

  // Single-flight player loop. Multiple audio_end events may queue chunks
  // faster than they play (a 3-sentence AI response can fully arrive in
  // <200 ms while playback takes 4 seconds). The loop pulls one chunk at
  // a time, sets the caption to THAT chunk's text, fires playback through
  // TalkingHead (or the minimal sink), then waits the chunk's natural
  // duration before advancing to the next. The caption stays visible
  // until either the next chunk's text replaces it or audio_cancel clears
  // it — so the candidate sees exactly what is being spoken at the moment
  // it's being heard.
  _kickPlayer() {
    if (this._playerActive) return;
    this._playerActive = true;
    (async () => {
      try {
        while (this._aiQueue.length > 0) {
          const item = this._aiQueue.shift();
          this.lastAiTalk = Date.now();
          this._setCaption(item.text);

          const totalBytes = item.pcmChunks.reduce((s, b) => s + b.byteLength, 0);
          const durMs = (totalBytes / 2 / item.sampleRate) * 1000;

          // Apply volume gain in-place on the PCM samples. We do this here
          // (not in the audio graph) because the avatar branch hands the
          // PCM to TalkingHead's INTERNAL AudioContext which we can't
          // reach with a GainNode on our own ctx. Same boost path for
          // both visual modes keeps behaviour consistent.
          const amplifiedChunks = this.amplifyPcmChunks(item.pcmChunks, this.aiVolumeGain);

          if (this.visualMode === "avatar" && this.head) {
            try {
              if (this.head.audioCtx && this.head.audioCtx.state === "suspended") {
                await this.head.audioCtx.resume();
              }
              const { words, wtimes, wdurations } = this.estimateWordTimings(item.text, durMs);
              this.head.speakAudio({ audio: amplifiedChunks, words, wtimes, wdurations });
            } catch (err) {
              console.error("speakAudio failed", err);
            }
          } else if (this.audioCtx) {
            try {
              const buf = this.pcm16BuffersToAudioBuffer(amplifiedChunks, item.sampleRate);
              const src = this.audioCtx.createBufferSource();
              src.buffer = buf;
              // Route through a persistent analyser so the orb's "speaking"
              // glow is driven by the AI's actual playback amplitude, not a
              // timer guess. Created once and reused across chunks.
              if (!this.aiAnalyser) {
                this.aiAnalyser = this.audioCtx.createAnalyser();
                this.aiAnalyser.fftSize = 512;
                this.aiAnalyserData = new Uint8Array(this.aiAnalyser.frequencyBinCount);
                this.aiAnalyser.connect(this.audioCtx.destination);
              }
              src.connect(this.aiAnalyser);
              src.start();
            } catch (err) {
              console.error("audioCtx playback failed", err);
            }
          }

          // Wait this chunk's natural duration before advancing the
          // caption. Refresh lastAiTalk inside the wait so the orb stays
          // in "speaking" colour for the full duration even when the
          // browser tab is backgrounded.
          const startedAt = Date.now();
          while (Date.now() - startedAt < durMs) {
            await new Promise(r => setTimeout(r, Math.min(200, durMs - (Date.now() - startedAt))));
            this.lastAiTalk = Date.now();
          }
        }
      } finally {
        this._playerActive = false;
        // Queue drained → AI is no longer speaking → STT updates from the
        // candidate's next utterance should be displayed again.
        this._aiSpeaking = false;
        // Caption stays on screen after the last chunk — the next
        // audio_start (or audio_cancel) will replace/clear it. Feels
        // natural: the candidate can finish reading the AI's question
        // even after the audio ends.
      }
    })();
  }

  // Reveal the AI caption with a brief fade. Empty text clears the caption.
  // Used everywhere the caption changes so the timing is consistent.
  _setCaption(text) {
    if (!text) {
      els.aiCaptionText.textContent = "";
      els.aiCaption.classList.remove("caption-visible");
      return;
    }
    els.aiCaptionText.textContent = text;
    // Trigger CSS transition: remove + reflow + add for re-entry on the
    // same node so consecutive calls still fade.
    els.aiCaption.classList.remove("caption-visible");
    void els.aiCaption.offsetWidth;
    els.aiCaption.classList.add("caption-visible");
    // Caption is now a multi-line scrollable box on the side; keep the
    // most-recent text in view if it overflowed.
    els.aiCaption.scrollTop = els.aiCaption.scrollHeight;
  }

  estimateWordTimings(text, durationMs) {
    const words = (text || "").trim().split(/\s+/).filter(Boolean);
    if (words.length === 0) return { words: [], wtimes: [], wdurations: [] };
    const weights = words.map(w => Math.max(1, w.length));
    const total = weights.reduce((a, b) => a + b, 0);
    const wtimes = [];
    const wdurations = [];
    let cursor = 0;
    for (const w of weights) {
      const dur = (w / total) * durationMs;
      wtimes.push(cursor);
      wdurations.push(dur);
      cursor += dur;
    }
    return { words, wtimes, wdurations };
  }

  // Return a list of NEW ArrayBuffers with each PCM16 LE sample scaled by
  // `gain` and clamped to int16 range. Returns the originals untouched if
  // gain is ~1.0 (skip the copy/allocation in the no-boost case).
  amplifyPcmChunks(chunks, gain) {
    if (!chunks || chunks.length === 0) return chunks;
    if (!gain || Math.abs(gain - 1.0) < 0.01) return chunks;
    const out = [];
    for (const b of chunks) {
      const inView = new DataView(b);
      const outBuf = new ArrayBuffer(b.byteLength);
      const outView = new DataView(outBuf);
      for (let i = 0; i < b.byteLength; i += 2) {
        let s = inView.getInt16(i, true) * gain;
        if (s > 32767) s = 32767;
        else if (s < -32768) s = -32768;
        outView.setInt16(i, s | 0, true);
      }
      out.push(outBuf);
    }
    return out;
  }

  pcm16BuffersToAudioBuffer(buffers, sampleRate) {
    const totalSamples = buffers.reduce((s, b) => s + b.byteLength, 0) / 2;
    const buf = this.audioCtx.createBuffer(1, totalSamples, sampleRate);
    const channel = buf.getChannelData(0);
    let off = 0;
    for (const b of buffers) {
      const view = new DataView(b);
      for (let i = 0; i < b.byteLength; i += 2) {
        channel[off++] = view.getInt16(i, true) / 0x8000;
      }
    }
    return buf;
  }

  // ── demo loop (no backend) ─────────────────────────────────────────────
  // In demo mode we use the browser's built-in SpeechSynthesis for actual
  // audible AI voice (no backend TTS needed) AND drive TalkingHead's
  // viseme animation with silent PCM + estimated word timings — the avatar
  // lips move while Web Speech provides the sound. In real (--web) mode
  // the PCM coming over the WS is the actual audio, so the lips and sound
  // are derived from the same bytes and stay perfectly in sync.
  async runDemoLoop() {
    this.setConn("warn", "Demo mode (no backend)");
    const script = [
      "Welcome to the interview. Let's start with a warm-up question.",
      "Tell me a little about yourself and what brought you here.",
      "Walk me through how you'd design a rate limiter for a public API.",
      "What's the most interesting bug you've shipped a fix for recently?",
      "How do you think about trade-offs between consistency and availability?",
    ];
    let i = 0;
    const tick = async () => {
      if (this.screen !== "live") return;
      const text = script[i % script.length];
      // Caption is intentionally NOT set here — speakDemo's utter.onstart
      // shows it at the moment speech actually starts (in sync with the
      // speakers), mirroring the per-chunk caption sync the real-backend
      // _kickPlayer() loop does.
      this._setCaption("");
      this.setTurnState("speaking", "AI is speaking");

      // Play audio + animate avatar lips concurrently.
      try {
        await this.speakDemo(text);
      } catch (err) {
        console.warn("[demo] speakDemo failed:", err);
      }

      if (this.screen !== "live") return;
      this.setTurnState("listening", "Your turn");
      els.youTranscriptText.textContent = "(you would answer here)";

      // Show a fake candidate response cycling after a short pause.
      const youResponses = [
        "Sure, the first thing I'd consider is the throughput requirements…",
        "I'd start by listing the failure modes and working backwards from there.",
        "Right, so the trade-off depends on whether read or write availability matters more.",
      ];
      setTimeout(() => {
        if (this.screen === "live") {
          els.youTranscriptText.textContent = youResponses[i % youResponses.length];
        }
      }, 1200);

      i++;
      setTimeout(tick, 4000);
    };
    // Browsers gate speechSynthesis behind a user gesture — wait for the
    // Start click to settle, then go.
    setTimeout(tick, 800);
  }

  // Use Web Speech API for the actual AI voice, drive TalkingHead visemes
  // from silent PCM + word timings so the lips move in sync. The estimated
  // duration is approximate; SpeechSynthesis rate may drift by ~10%. For
  // real (backend) audio the timing is exact because we use the same PCM.
  async speakDemo(text) {
    const wordCount = text.trim().split(/\s+/).filter(Boolean).length;
    // ~270ms/word at rate=0.95 — empirically close to most browser voices.
    const estDurMs = Math.max(1500, wordCount * 270);

    // 1) Schedule audible speech via SpeechSynthesis
    let speechPromise = Promise.resolve();
    if (window.speechSynthesis) {
      const utter = new SpeechSynthesisUtterance(text);
      utter.rate = 0.95;
      utter.pitch = 1.0;
      // Prefer a FEMALE English voice — the default TalkingHead avatar is
      // female (brunette.glb), so a male voice creates an obvious mismatch.
      // Match common female voice names across macOS / Windows / Chrome.
      const voices = window.speechSynthesis.getVoices();
      const preferred =
            voices.find(v => /Samantha|Karen|Victoria|Tessa|Moira|Fiona|Allison|Ava|Susan|Zira|Hazel|Eva|Catherine/i.test(v.name) && (v.lang || "").startsWith("en"))
         || voices.find(v => /female|woman/i.test(v.name) && (v.lang || "").startsWith("en"))
         || voices.find(v => /Google\s+US\s+English/i.test(v.name))
         || voices.find(v => (v.lang || "").startsWith("en"));
      if (preferred) utter.voice = preferred;
      speechPromise = new Promise(resolve => {
        // onstart fires when audio actually begins — reveal caption here
        // so the candidate sees the text the moment they hear it, not
        // before. This matches the real-backend playAiAudio() behaviour.
        utter.onstart = () => this._setCaption(text);
        utter.onend = () => resolve();
        utter.onerror = () => resolve();
      });
      this.lastAiTalk = Date.now();
      window.speechSynthesis.speak(utter);
    } else {
      // No SpeechSynthesis available — fall back to showing caption now
      // (no speech to sync with).
      this._setCaption(text);
    }

    // 2) Drive TalkingHead lip-sync with silent PCM of matching duration
    if (this.visualMode === "avatar" && this.head) {
      try {
        if (this.head.audioCtx && this.head.audioCtx.state === "suspended") {
          await this.head.audioCtx.resume();
        }
        const sr = this.currentSampleRate || 16000;
        const samples = Math.floor((estDurMs / 1000) * sr);
        const silentPcm = new Int16Array(samples).buffer; // zeros
        const { words, wtimes, wdurations } = this.estimateWordTimings(text, estDurMs);
        this.head.speakAudio({ audio: [silentPcm], words, wtimes, wdurations });
      } catch (err) {
        console.warn("[demo] head.speakAudio failed:", err);
      }
    }

    // 3) Pulse the orb continuously while we estimate speech duration
    const pulseInterval = setInterval(() => { this.lastAiTalk = Date.now(); }, 300);
    await Promise.race([
      speechPromise,
      new Promise(r => setTimeout(r, estDurMs + 500)),  // safety cap
    ]);
    clearInterval(pulseInterval);
  }

  // ── end interview ──────────────────────────────────────────────────────
  endInterview() {
    try { if (this.ws && this.ws.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify({ type: "end" })); } catch {}
    try { this.ws?.close(); } catch {}
    try { this.micStream?.getTracks().forEach(t => t.stop()); } catch {}
    try { this.head?.stopSpeaking(); } catch {}
    this.stopOrbAnim();
    if (this.timerInterval) clearInterval(this.timerInterval);
    this.setScreen("done");
  }

  // ── modal + toast ──────────────────────────────────────────────────────
  showModal({ title, body, primaryLabel = "OK", onPrimary, secondaryLabel, onSecondary }) {
    els.modalTitle.textContent = title;
    els.modalBody.textContent  = body;
    els.modalPrimary.textContent = primaryLabel;
    els.modal.hidden = false;
    this._modalOnPrimary = onPrimary;
    if (secondaryLabel) {
      els.modalSecondary.hidden = false;
      els.modalSecondary.textContent = secondaryLabel;
      els.modalSecondary.onclick = () => { this.hideModal(); onSecondary?.(); };
    } else {
      els.modalSecondary.hidden = true;
    }
  }
  hideModal() {
    els.modal.hidden = true;
    if (this._modalOnPrimary) { const fn = this._modalOnPrimary; this._modalOnPrimary = null; fn(); }
  }
  showToast(text, ms = 4000) {
    els.toast.textContent = text;
    els.toast.hidden = false;
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => { els.toast.hidden = true; }, ms);
  }
}

// ── boot ─────────────────────────────────────────────────────────────────
const app = new CandidateApp();
app.init();
window.__app = app;  // for debugging from devtools
