"""Unit tests for app/plugin_aggregate.py — benchmark math + v1 adapter.

Exercises the aggregation heart of the v2 pipeline without a DB or LLM by
running deterministic plugins (coverage_tags, coding) over real segments.
Runs under pytest OR directly (`python tests/test_plugin_aggregate.py`).
"""
from __future__ import annotations

import asyncio

import app.plugin_aggregate as agg
import features.eval.plugins as P
from app.evaluation_service import EvaluationModel
from features.eval.plugins.base import EvalContext
from features.eval.sectioner import build_segments

TECH_EVENTS = [
    {"kind": "session_started", "payload": {"initial_phase": "tech"}, "ts": "t"},
    {"kind": "question_dispatched", "payload": {"phase_id": "tech", "question_id": "q1",
        "difficulty": "easy", "coverage_tags": ["softmax", "scaling"]}, "ts": "t"},
    {"kind": "ai_utterance", "payload": {"text": "q1"}, "ts": "t"},
    {"kind": "stt_final", "payload": {"text": "uses softmax and scaling"}, "ts": "t"},  # 2/2
    {"kind": "question_dispatched", "payload": {"phase_id": "tech", "question_id": "q2",
        "difficulty": "hard", "coverage_tags": ["retrieval", "chunking"]}, "ts": "t"},
    {"kind": "ai_utterance", "payload": {"text": "q2"}, "ts": "t"},
    {"kind": "stt_final", "payload": {"text": "just retrieval"}, "ts": "t"},  # 1/2
    {"kind": "phase_changed", "payload": {"from_phase": "tech", "to_phase": "code"}, "ts": "t"},
    {"kind": "coding_phase_started", "payload": {"phase_id": "code",
        "questions": [{"question_id": "running_sum", "question_prompt": "sum"}]}, "ts": "t"},
    {"kind": "coding_code_submitted", "payload": {"question_id": "running_sum", "final_code": "def f(): pass",
        "final_test_results": [{"pass": True}, {"pass": True}, {"pass": True}, {"pass": False}], "runs_used": 1}, "ts": "t"},
    {"kind": "session_ended", "payload": {}, "ts": "t"},
]


def _build_v2():
    iv = build_segments(TECH_EVENTS)
    ctx = EvalContext()
    phases_input = []
    all_evals = []
    coding_quality = []
    for ph in iv.phases:
        segs = [s for s in ph.segments if s.kind != "warmup"]
        if ph.phase_id == "tech":
            plug = P.get_plugin("coverage_tags")()
            cfg = {"marks_per_tag": 5.0}
        else:
            plug = P.get_plugin("coding")()
            cfg = {"marks_possible": 10.0, "use_llm_judge": False}
        evs = [asyncio.run(plug.run(s, cfg, ctx=ctx)) for s in segs]
        all_evals.extend(evs)
        pairs = list(zip(segs, evs))
        if ph.phase_id == "code":
            for seg, ev in pairs:
                coding_quality.append({"phase_id": ph.phase_id, "question_id": seg.question_id,
                                       "pass_rate": ev.raw.get("pass_rate")})
        block = agg.build_phase(ph.phase_id, ph.phase_id.title(), [(plug.id, plug.view_id, cfg, pairs)])
        phases_input.append(block)
    v2 = agg.aggregate(phases_input, model="test-model", generated_at="2026-06-25T00:00:00Z",
                       plan_fingerprint="fp", coding_quality=coding_quality, all_evals=all_evals)
    return v2


def test_phase_totals_sum_segments():
    v2 = _build_v2()
    tech = next(p for p in v2["phases"] if p["phase_id"] == "tech")
    # q1: 2/2 tags * 5 = 10/10 ; q2: 1/2 * 5 = 5/10  → phase 15/20
    assert tech["marks_earned"] == 15.0
    assert tech["marks_possible"] == 20.0
    # per-result summary sums match the phase
    summ = tech["results"][0]["summary"]
    assert summ["marks_earned"] == 15.0 and summ["marks_possible"] == 20.0
    assert summ["total_questions"] == 2


def test_grand_total_sums_phases():
    v2 = _build_v2()
    code = next(p for p in v2["phases"] if p["phase_id"] == "code")
    assert code["marks_earned"] == 7.5  # 3/4 pass rate * 10
    total = v2["total"]
    assert total["marks_earned"] == round(15.0 + 7.5, 2)
    assert total["marks_possible"] == 30.0
    assert total["pct"] == round(100.0 * 22.5 / 30.0, 1)


def test_v1_adapter_validates_against_evaluation_model():
    v2 = _build_v2()
    v1 = agg.to_evaluation_model_v1(v2)
    EvaluationModel.model_validate(v1)  # raises if invalid
    assert v1["overall"]["score"] == int(round(v2["total"]["pct"]))
    assert v1["overall"]["band"]  # mapped
    # benchmark source is carried inside for the v2 UI
    assert v1["benchmark"]["total"]["marks_possible"] == 30.0
    # per-question rows surfaced for the tech phase
    tech = next(p for p in v1["phases"] if p["id"] == "tech")
    assert {q["id"] for q in tech["questions"]} == {"q1", "q2"}


def test_segments_carry_evidence_transcript():
    # Evidence must be the actual transcript content (speaker + text), not just
    # event-index numbers, so the UI can show what each plugin scored.
    v2 = _build_v2()
    tech = next(p for p in v2["phases"] if p["phase_id"] == "tech")
    seg = tech["results"][0]["segments"][0]
    assert isinstance(seg.get("evidence"), list) and seg["evidence"]
    assert any(e["speaker"] == "candidate" and e["text"] for e in seg["evidence"])
    assert all({"speaker", "text", "event_index", "cited"} <= set(e) for e in seg["evidence"])


def test_coding_quality_preserved_for_legacy_view():
    v2 = _build_v2()
    assert any(c["question_id"] == "running_sum" for c in v2["coding_quality"])


def test_not_observed_excluded_from_totals():
    # A coding plugin on a segment with no submission → assumptions_unmet,
    # which must not drag the totals to 0.
    events = [
        {"kind": "session_started", "payload": {"initial_phase": "code"}, "ts": "t"},
        {"kind": "coding_phase_started", "payload": {"phase_id": "code",
            "questions": [{"question_id": "a", "question_prompt": "p"}]}, "ts": "t"},
        {"kind": "session_ended", "payload": {}, "ts": "t"},
    ]
    iv = build_segments(events)
    segs = [s for s in iv.phases[0].segments if s.kind != "warmup"]
    plug = P.get_plugin("coding")()
    evs = [asyncio.run(plug.run(s, {}, ctx=EvalContext())) for s in segs]
    block = agg.build_phase("code", "Code", [(plug.id, plug.view_id, {}, list(zip(segs, evs)))])
    assert block["marks_possible"] == 0.0  # the unscored segment is excluded
    assert all(e.state != "scored" for e in evs)


def _run_all():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn()
        print(f"  ok  {fn.__name__}")
    print(f"\n{len(fns)} aggregate tests passed.")


if __name__ == "__main__":
    _run_all()
