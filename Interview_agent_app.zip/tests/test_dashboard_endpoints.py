"""Tests for the JSON dashboard endpoints used by the React SPA.

Run with: .venv/bin/python -m pytest tests/test_dashboard_endpoints.py -v

Coverage:
  - GET /api/sessions        — auth gate (401) + payload shape (rows/active/base)
  - POST /api/sessions/{t}/archive — auth gate, 404 on bogus, flips status→cancelled
  - DELETE /api/sessions/{t} — auth gate, 404 on bogus, drops row + rm -rf session_dir
"""
from __future__ import annotations

import pytest


@pytest.fixture
def clients(tmp_path, monkeypatch):
    """An authenticated TestClient + an unauthenticated one, sharing the app."""
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    from fastapi.testclient import TestClient
    from app import auth, db, main

    db.init_db()  # TestClient never fires the startup event that builds the schema
    authed = TestClient(main.app)
    authed.cookies.set(auth.COOKIE_NAME, auth.issue_cookie("test_admin"))
    anon = TestClient(main.app)
    return authed, anon


def _seed(token: str, status: str = "ready") -> str:
    from app import db

    if db.get(token) is None:
        db.insert({
            "token": token,
            "candidate_name": "Dash Test",
            "role": "AI Engineer",
            "jd_text": "Builds LLM systems.",
            "resume_path": "resume.pdf",
            "cadence_yaml": "phases: []\n",
            "status": status,
            "created_at": db.now_iso(),
        })
    return token


# ── GET /api/sessions ──────────────────────────────────────────────────────


def test_sessions_requires_auth(clients):
    _, anon = clients
    assert anon.get("/api/sessions").status_code == 401


def test_sessions_list_shape(clients):
    authed, _ = clients
    token = _seed("dashtest-list")
    try:
        r = authed.get("/api/sessions")
        assert r.status_code == 200, r.text
        data = r.json()
        # `active` was renamed to `active_count` when the platform stopped
        # being single-interview-at-a-time; this assertion was never updated.
        assert set(("rows", "active_count", "candidate_link_base")) <= set(data)
        assert isinstance(data["rows"], list)
        tokens = [row["token"] for row in data["rows"]]
        assert token in tokens
        row = next(row for row in data["rows"] if row["token"] == token)
        for key in ("candidate_name", "role", "status", "created_at", "ended_at"):
            assert key in row
        # The old response carried the single ACTIVE ROW, back when only one
        # interview could run at a time. The scaled platform runs many, so it
        # now reports a live COUNT of in-progress interviews instead — and a
        # 'ready' session is scheduled, not yet running, so it counts zero.
        assert isinstance(data["active_count"], int)
    finally:
        from app import db
        db.delete(token)


# ── POST /api/sessions/{token}/archive ───────────────────────────────────────


def test_archive_requires_auth(clients):
    _, anon = clients
    assert anon.post("/api/sessions/whatever/archive").status_code == 401


def test_archive_404_when_missing(clients):
    authed, _ = clients
    r = authed.post("/api/sessions/no-such-token/archive")
    assert r.status_code == 404


def test_archive_flips_status_to_cancelled(clients):
    from app import db

    authed, _ = clients
    token = _seed("dashtest-archive", status="ready")
    try:
        r = authed.post(f"/api/sessions/{token}/archive")
        assert r.status_code == 200, r.text
        assert r.json() == {"ok": True}
        assert db.get(token)["status"] == "cancelled"
    finally:
        db.delete(token)


# ── DELETE /api/sessions/{token} ─────────────────────────────────────────────


def test_delete_requires_auth(clients):
    _, anon = clients
    assert anon.delete("/api/sessions/whatever").status_code == 401


def test_delete_404_when_missing(clients):
    authed, _ = clients
    r = authed.delete("/api/sessions/no-such-token")
    assert r.status_code == 404


def test_delete_drops_row_and_dir(clients):
    from app import db
    from app.paths import session_dir

    authed, _ = clients
    token = _seed("dashtest-delete", status="draft")
    sdir = session_dir(token)
    sdir.mkdir(parents=True, exist_ok=True)
    (sdir / "events.jsonl").write_text("{}\n", encoding="utf-8")

    r = authed.delete(f"/api/sessions/{token}")
    assert r.status_code == 200, r.text
    assert r.json() == {"ok": True}
    assert db.get(token) is None
    assert not sdir.exists()
