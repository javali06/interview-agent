"""Deterministic (no-LLM) regression tests for the text-interview core.

Covers the pieces that do NOT need a live model: the timed/untimed cadence flag,
written_response (essay) schema validation, the CadenceTracker snapshot/restore
overlay (the stateless-tier resume mechanism), SessionState (de)serialization,
the HMAC state-blob signing, and the shared follow-up budget that lets an
unproductive question (partial / off-topic / not-applicable) eventually be
skipped. The full turn-loop / HTTP / eval-parity is exercised live in
tests/_check_text_interview.py (needs an LLM key).
"""
from __future__ import annotations

import uuid

import pytest

from engine.brain.cadence.schema import (
    CadencePlan,
    PhaseDef,
    QuestionPoolItem,
    WrittenQuestion,
    WrittenResponse,
)
from engine.brain.contracts.session_state import (
    CandidateProfile,
    SessionState,
    Speaker,
    Turn,
)
from engine.brain.core.cadence_tracker import CadenceTracker, TickDecision
from engine.brain.core.event_bus import EventBus
from engine.brain.llm import LLMClient
from engine.brain.observability import JsonlEventLog, Tracer
from engine.brain.text.state_codec import (
    sign_blob,
    state_from_jsonable,
    state_to_jsonable,
    verify_blob,
)
from engine.brain.text.turn_engine import TextTurnEngine


def _spec(pid: str, *qids: str, wr: WrittenResponse | None = None) -> PhaseDef:
    return PhaseDef(
        id=pid, duration_s=1, intent=pid, question_mode="specific",
        question_pool=[QuestionPoolItem(id=q, text=f"Q {q}", coverage_tags=["t"]) for q in qids],
        written_response=wr,
    )


def _generic(pid: str, dur: int) -> PhaseDef:
    return PhaseDef(id=pid, duration_s=dur, intent=pid, question_mode="generic",
                    generic_prompts=["go"])


def _untimed_plan() -> CadencePlan:
    # dummy durations + a total that does NOT match the sum (allowed when untimed)
    return CadencePlan(total_duration_s=99, timed=False, phases=[_spec("p1", "a"), _spec("p2", "b", "c")])


# ── timed / untimed flag ─────────────────────────────────────────────────────
def test_voice_plan_defaults_timed_and_enforces_totals():
    plan = CadencePlan(total_duration_s=300, phases=[_generic("w", 300)])
    assert plan.timed is True
    with pytest.raises(ValueError):
        CadencePlan(total_duration_s=999, phases=[_generic("w", 300)])  # sum mismatch


def test_untimed_plan_skips_the_sum_check_and_round_trips():
    plan = _untimed_plan()
    assert plan.timed is False
    assert CadencePlan.model_validate(plan.model_dump()).timed is False


# ── tracker gating: untimed advances ONLY on pool exhaustion ─────────────────
def test_untimed_tracker_ignores_the_wall_clock():
    clock = [0]
    t = CadenceTracker(_untimed_plan(), now_ms_provider=lambda: clock[0])
    clock[0] = 10_000_000  # far past any conceivable budget
    assert t.check_phase_budget() == TickDecision.STAY  # untimed → no time advance
    t.pick_next_question()  # drain p1's only question
    assert t.check_phase_budget() == TickDecision.ADVANCE  # pool exhausted → advance


def test_timed_tracker_still_advances_on_budget():
    clock = [0]
    plan = CadencePlan(total_duration_s=2, phases=[_generic("a", 1), _generic("b", 1)])
    t = CadenceTracker(plan, now_ms_provider=lambda: clock[0])
    assert t.check_phase_budget() == TickDecision.STAY
    clock[0] = 5_000  # 5s > 1s budget
    assert t.check_phase_budget() == TickDecision.ADVANCE


# ── written_response (essay) validation ──────────────────────────────────────
def test_written_response_requires_a_specific_pool():
    wr = WrittenResponse(word_limit=250, time_limit_s=600)
    assert _spec("e", "only", wr=wr).written_response is wr  # ok
    # A written-response phase may hold SEVERAL questions (the candidate answers
    # them one at a time) — see tests/test_phase_question_types.py for the
    # per-question config. What it can't be is generic-mode or pool-less.
    assert len(_spec("e", "one", "two", wr=wr).question_pool) == 2
    with pytest.raises(ValueError):
        PhaseDef(id="e", duration_s=1, intent="i", question_mode="generic",
                 generic_prompts=["g"], written_response=wr)  # generic mode


# ── CadenceTracker snapshot / restore (the resume overlay) ───────────────────
def test_tracker_snapshot_restore_round_trip():
    plan = _untimed_plan()
    a = CadenceTracker(plan, now_ms_provider=lambda: 0)
    a.pick_next_question()            # pop p1
    a.advance(reason="x")            # -> p2
    a.pick_next_question()            # pop p2's first
    a.mark_current_question_presented()
    snap = a.to_snapshot()

    b = CadenceTracker(plan, now_ms_provider=lambda: 0)  # fresh (as a new replica would build)
    b.restore_snapshot(snap)
    assert b.current_phase_id == "p2"
    assert b.questions_remaining() == a.questions_remaining()
    assert b.asked_ids_in_current_phase() == a.asked_ids_in_current_phase()


# ── SessionState (de)serialization (text-relevant fields) ────────────────────
def test_session_state_round_trip():
    st = SessionState(
        candidate_profile=CandidateProfile(name="Alex", role="Eng", resume_summary="rs"),
        phase="p2", rolling_summary="summary",
    )
    st.turns = [
        Turn(turn_id="1", speaker=Speaker.AI, text="hi"),
        Turn(turn_id="2", speaker=Speaker.CANDIDATE, text="hello"),
    ]
    st.cost_so_far_usd = 0.42
    st2 = state_from_jsonable(state_to_jsonable(st))
    assert [t.text for t in st2.turns] == ["hi", "hello"]
    assert st2.candidate_profile.name == "Alex"
    assert st2.phase == "p2"
    assert st2.rolling_summary == "summary"
    assert st2.cost_so_far_usd == 0.42


# ── HMAC state-blob integrity ────────────────────────────────────────────────
def test_hmac_sign_verify_tamper_and_wrong_secret():
    payload = {"state": {"phase": "p1"}, "tracker": {"current_phase_id": "p1"}, "n": 1}
    signed = sign_blob(payload, "sekret")
    assert isinstance(signed["payload"], str)                        # opaque string body
    assert verify_blob(signed, "sekret") == payload                  # parses back equal
    assert verify_blob(signed, "other") is None                      # wrong secret
    tampered = {**signed, "payload": signed["payload"].replace("p1", "p9", 1)}
    assert verify_blob(tampered, "sekret") is None                   # mutated body
    assert verify_blob({"payload": signed["payload"]}, "sekret") is None  # missing sig
    assert verify_blob("not-a-dict", "sekret") is None               # garbage


def test_hmac_survives_json_round_trip_with_whole_number_floats():
    # Simulates the browser holding the signed blob + re-posting it: the whole
    # envelope is JSON round-tripped. Floats like 1.0/0.0 (turn confidence, cost)
    # must NOT break verification — the signed body is an opaque string, so the
    # HMAC is stable across the round-trip.
    import json as _json
    payload = {"state": {"turns": [{"confidence": 1.0}], "cost_so_far_usd": 0.0}}
    signed = sign_blob(payload, "sekret")
    reposted = _json.loads(_json.dumps(signed))  # exactly what the browser does
    assert verify_blob(reposted, "sekret") == payload


# ── shared follow-up budget: unproductive answers eventually skip ────────────
# Regression coverage for the loop where `off_topic` / `not_applicable` never
# consumed the pool question: both intents tell the AI to "steer back to the
# current question", but neither incremented a counter or popped the pool, so
# an untimed text phase (no wall clock) re-asked the same question forever.
# They now share ONE budget with partial_answer. Driven through _apply_verifier
# with a fake verdict so no LLM is needed.
class _FakeVerifier:
    """Stand-in for VerifierResult — _apply_verifier reads only these three."""

    def __init__(self, intent: str, missing_tags=None, instruction: str = "canned"):
        self.intent = intent
        self.instruction = instruction
        self.missing_tags = list(missing_tags or [])


def _budget_engine(tmp_path, max_follow_ups: int = 1) -> TextTurnEngine:
    tracer = Tracer(
        session_id=uuid.uuid4(),
        event_log=JsonlEventLog(str(tmp_path / "events.jsonl")),
        bus=EventBus(),
    )
    plan = CadencePlan(total_duration_s=99, timed=False, phases=[
        _spec("technical", "t1", "t2"), _spec("wrap_up", "w"),
    ])
    return TextTurnEngine(
        plan=plan, candidate=CandidateProfile(name="Sam", role="Eng"), tracer=tracer,
        # Never called: these tests drive _apply_verifier directly.
        slow_llm=LLMClient(api_key="unused", base_url="http://example.invalid"),
        fast_llm=None, slow_model="m", fast_model="m",
        max_follow_ups=max_follow_ups,
    )


@pytest.mark.parametrize("intent", ["off_topic", "not_applicable"])
def test_unproductive_reply_below_cap_re_asks_without_consuming_the_question(tmp_path, intent):
    eng = _budget_engine(tmp_path)
    report: dict = {}
    eng._apply_verifier(_FakeVerifier(intent), True, report)
    assert "popped_question" not in report          # same question stays on the table
    assert eng.tracker.questions_remaining() == 2
    assert eng._unproductive_count_current_q == 1


@pytest.mark.parametrize("intent", ["off_topic", "not_applicable"])
def test_unproductive_reply_hits_the_cap_and_skips_to_the_next_question(tmp_path, intent):
    eng = _budget_engine(tmp_path)                  # max_follow_ups=1
    eng._apply_verifier(_FakeVerifier(intent), True, {})        # 1st → steer back
    report: dict = {}
    eng._apply_verifier(_FakeVerifier(intent), True, report)    # 2nd → cap exceeded
    assert report["popped_question"] == "t1"        # moved on to the next question
    assert eng.tracker.questions_remaining() == 1
    assert f"from {intent}" in report["effective_intent"]
    assert eng._unproductive_count_current_q == 0   # fresh budget for question 2


def test_partial_and_off_topic_share_one_budget(tmp_path):
    # Alternating shallow/off-topic must NOT buy the candidate two budgets.
    eng = _budget_engine(tmp_path)
    eng._apply_verifier(_FakeVerifier("partial_answer", ["softmax"]), True, {})
    report: dict = {}
    eng._apply_verifier(_FakeVerifier("off_topic"), True, report)
    assert report["popped_question"] == "t1"


def test_a_higher_cap_allows_more_steer_backs_before_skipping(tmp_path):
    eng = _budget_engine(tmp_path, max_follow_ups=3)
    for _ in range(3):
        report: dict = {}
        eng._apply_verifier(_FakeVerifier("off_topic"), True, report)
        assert "popped_question" not in report
    report = {}
    eng._apply_verifier(_FakeVerifier("off_topic"), True, report)   # 4th > 3
    assert report["popped_question"] == "t1"


@pytest.mark.parametrize(
    "intent", ["asked_to_repeat", "asked_for_time", "clarifying_question", "no_speech"],
)
def test_legitimate_candidate_needs_never_burn_the_budget(tmp_path, intent):
    # Skipping someone's question because they asked you to repeat it (or went
    # briefly silent) would be hostile — these must never count toward the cap.
    eng = _budget_engine(tmp_path)
    for _ in range(5):
        report: dict = {}
        eng._apply_verifier(_FakeVerifier(intent), True, report)
        assert "popped_question" not in report
    assert eng._unproductive_count_current_q == 0


def test_missing_tags_are_stashed_only_for_partial_answers(tmp_path):
    # An off-topic reply addressed none of the coverage tags, so scoping the
    # next verification to "what's still missing" would be meaningless.
    eng = _budget_engine(tmp_path, max_follow_ups=3)
    eng._apply_verifier(_FakeVerifier("partial_answer", ["softmax"]), True, {})
    assert eng._latest_missing_tags == ["softmax"]
    eng._apply_verifier(_FakeVerifier("off_topic", ["ignored"]), True, {})
    assert eng._latest_missing_tags == ["softmax"]      # unchanged


def test_generic_phases_never_skip_on_unproductive_replies(tmp_path):
    # A generic phase has no pool to pop, so the cap is meaningless there.
    eng = _budget_engine(tmp_path)
    for _ in range(5):
        eng._apply_verifier(_FakeVerifier("off_topic"), False, {})  # is_specific=False
    assert eng._unproductive_count_current_q == 0
    assert eng.tracker.questions_remaining() == 2


def test_answering_resets_the_budget_for_the_next_question(tmp_path):
    eng = _budget_engine(tmp_path)
    eng._apply_verifier(_FakeVerifier("off_topic"), True, {})       # spend 1
    eng._apply_verifier(_FakeVerifier("answered"), True, {})        # pops t1, resets
    assert eng._unproductive_count_current_q == 0
    report: dict = {}
    eng._apply_verifier(_FakeVerifier("off_topic"), True, report)   # t2 gets a full budget
    assert "popped_question" not in report


def test_budget_round_trips_under_the_legacy_snapshot_key(tmp_path):
    # In-flight browsers hold signed blobs keyed `partial_count_current_q`; the
    # key must stay stable across this rename or a mid-interview resume silently
    # refunds the spent budget.
    eng = _budget_engine(tmp_path)
    eng._apply_verifier(_FakeVerifier("off_topic"), True, {})
    snap = eng.snapshot()
    assert snap["carry"]["partial_count_current_q"] == 1

    resumed = _budget_engine(tmp_path)
    resumed._apply_restore(snap)
    assert resumed._unproductive_count_current_q == 1
    report: dict = {}
    resumed._apply_verifier(_FakeVerifier("off_topic"), True, report)
    assert report["popped_question"] == "t1"   # budget carried over, cap still hit


def test_text_tier_reads_max_follow_ups_from_config_with_env_override(monkeypatch):
    # Was a hardcoded literal in text_service, so system_config.yaml was ignored.
    from app.text_service import _max_follow_ups

    monkeypatch.delenv("MAX_FOLLOW_UPS_PER_QUESTION", raising=False)
    from_config = _max_follow_ups()
    assert isinstance(from_config, int) and from_config >= 0

    monkeypatch.setenv("MAX_FOLLOW_UPS_PER_QUESTION", "3")
    assert _max_follow_ups() == 3                    # env wins, as in the voice path

    monkeypatch.setenv("MAX_FOLLOW_UPS_PER_QUESTION", "junk")
    assert _max_follow_ups() == from_config          # bad value → config, no raise


# ── adding the same phase twice folds into the existing one ──────────────────
# Regression: the admin picked "Comprehensive" twice, the modal seeded the same
# name both times, and the builder uniquified the id → a second, near-identical
# `comprehensive_2` phase instead of a second question in the phase they already
# had. A phase's id is its identity (the eval plan + events.jsonl key off it),
# so a same-type/same-name add now MERGES.
def _plan_yaml(*extra_phases) -> str:
    import yaml as _yaml
    return _yaml.safe_dump({
        "total_duration_s": 2, "timed": False,
        "phases": [
            *extra_phases,
            {"id": "wrap_up", "duration_s": 1, "intent": "Close.",
             "question_mode": "specific",
             "question_pool": [{"id": "wrap", "text": "Questions?", "coverage_tags": []}]},
        ],
    }, sort_keys=False)


def _phases(y: str) -> list:
    import yaml as _yaml
    return _yaml.safe_load(y)["phases"]


def _phase(y: str, pid: str) -> dict:
    return next(p for p in _phases(y) if p["id"] == pid)


def test_adding_the_same_written_phase_twice_merges_instead_of_duplicating():
    from app.cadence_service import append_written_phase

    o1: dict = {}
    y1 = append_written_phase(_plan_yaml(), question_type="comprehensive",
                              name="Comprehensive", outcome=o1,
                              questions=[{"prompt": "describe about LLM", "char_limit": 1500}])
    assert o1 == {"created": "comprehensive", "added": 1}

    o2: dict = {}
    y2 = append_written_phase(y1, question_type="comprehensive", name="Comprehensive",
                              outcome=o2,
                              questions=[{"prompt": "describe", "char_limit": 1200}])
    assert o2 == {"merged_into": "comprehensive", "added": 1}
    assert [p["id"] for p in _phases(y2)] == ["comprehensive", "wrap_up"]   # no _2
    pool = _phase(y2, "comprehensive")["question_pool"]
    assert [q["id"] for q in pool] == ["comprehensive_q1", "comprehensive_q2"]
    assert [q["text"] for q in pool] == ["describe about LLM", "describe"]


def test_a_merge_keeps_existing_questions_and_their_ids_untouched():
    # Those ids are referenced by events.jsonl / eval segments — a merge must not
    # renumber or rewrite anything already in the phase.
    from app.cadence_service import append_written_phase

    y1 = append_written_phase(_plan_yaml(), question_type="comprehensive",
                              name="Comprehensive",
                              questions=[{"prompt": "first", "char_limit": 500,
                                          "time_limit_s": 600}])
    before = _phase(y1, "comprehensive")["question_pool"][0]
    y2 = append_written_phase(y1, question_type="comprehensive", name="Comprehensive",
                              questions=[{"prompt": "second", "char_limit": 100},
                                         {"prompt": "third", "char_limit": 200}])
    pool = _phase(y2, "comprehensive")["question_pool"]
    assert pool[0] == before
    assert [q["id"] for q in pool] == [
        "comprehensive_q1", "comprehensive_q2", "comprehensive_q3",
    ]


def test_a_merge_does_not_inflate_the_interview_duration():
    # total_duration_s is bumped per PHASE added; a merge adds no phase.
    import yaml as _yaml
    from app.cadence_service import append_written_phase

    y1 = append_written_phase(_plan_yaml(), question_type="comprehensive",
                              name="Comprehensive",
                              questions=[{"prompt": "a", "char_limit": 100}])
    total_after_create = _yaml.safe_load(y1)["total_duration_s"]
    y2 = append_written_phase(y1, question_type="comprehensive", name="Comprehensive",
                              questions=[{"prompt": "b", "char_limit": 100}])
    assert _yaml.safe_load(y2)["total_duration_s"] == total_after_create


def test_a_different_question_type_under_the_same_name_stays_a_separate_phase():
    # A phase holds N questions of ONE type, so this can't merge — it falls back
    # to the uniquified id rather than smuggling a translation into an essay.
    from app.cadence_service import append_written_phase

    y1 = append_written_phase(_plan_yaml(), question_type="comprehensive",
                              name="Comprehensive",
                              questions=[{"prompt": "a", "char_limit": 100}])
    o: dict = {}
    y2 = append_written_phase(y1, question_type="translation", name="Comprehensive",
                              source_language="en", target_language="fr", outcome=o,
                              questions=[{"prompt": "", "char_limit": 600,
                                          "source_text": "Hello."}])
    assert o == {"created": "comprehensive_2", "added": 1}
    assert [p["id"] for p in _phases(y2)] == [
        "comprehensive", "comprehensive_2", "wrap_up",
    ]


def test_a_different_name_still_creates_a_second_phase_of_the_same_type():
    # The escape hatch: two comprehensive phases are legitimate, the admin just
    # names the second one.
    from app.cadence_service import append_written_phase

    y1 = append_written_phase(_plan_yaml(), question_type="comprehensive",
                              name="Comprehensive",
                              questions=[{"prompt": "a", "char_limit": 100}])
    o: dict = {}
    y2 = append_written_phase(y1, question_type="comprehensive", name="Deep dive",
                              outcome=o, questions=[{"prompt": "b", "char_limit": 100}])
    assert o == {"created": "deep_dive", "added": 1}
    assert [p["id"] for p in _phases(y2)] == ["comprehensive", "deep_dive", "wrap_up"]


def test_a_phase_can_mix_language_pairs_across_its_questions():
    # The pair used to be authored ONCE for the whole phase, which forced a
    # separate phase per pair. It is per QUESTION now, so one translation phase
    # can hold en→es and fr→de side by side — and each question's instruction is
    # synthesised from its OWN pair.
    from app.cadence_service import append_written_phase

    y = append_written_phase(_plan_yaml(), question_type="translation",
                             name="Translation", questions=[
        {"char_limit": 600, "source_text": "A.",
         "source_language": "en", "target_language": "es"},
        {"char_limit": 400, "source_text": "B.",
         "source_language": "fr", "target_language": "de"},
    ])
    pool = _phase(y, "translation")["question_pool"]
    assert [q["text"] for q in pool] == [
        "Translate the text below from English into Spanish.",
        "Translate the text below from French into German.",
    ]
    assert pool[0]["written_response"]["target_language"] == "es"
    assert pool[1]["written_response"]["target_language"] == "de"
    # nothing pinned at phase level any more — only the type
    assert _phase(y, "translation")["written_response"] == {"question_type": "translation"}

    # ...and merging a THIRD pair into the same phase is allowed (was refused)
    y2 = append_written_phase(y, question_type="translation", name="Translation",
                              questions=[{"char_limit": 300, "source_text": "C.",
                                          "source_language": "es",
                                          "target_language": "en"}])
    pool2 = _phase(y2, "translation")["question_pool"]
    assert len(pool2) == 3
    assert pool2[2]["text"] == "Translate the text below from Spanish into English."


def test_a_phase_level_pair_still_works_as_a_default_for_older_cadences():
    # Cadences authored while the pair was phase-level must keep loading, and an
    # EDIT of one must inherit that pair for questions that don't restate it.
    import yaml as _yaml
    from app.cadence_service import update_written_phase
    from engine.brain.cadence.schema import CadencePlan

    legacy = _yaml.safe_dump({"total_duration_s": 2, "timed": False, "phases": [
        {"id": "translation", "duration_s": 1, "intent": "T.",
         "question_mode": "specific",
         "question_pool": [{"id": "translation_q1", "text": "Translate this.",
                            "topic": "translation", "coverage_tags": [],
                            "written_response": {"char_limit": 600,
                                                 "source_text": "old passage"}}],
         "written_response": {"question_type": "translation",
                              "source_language": "en", "target_language": "es"}},
        {"id": "wrap_up", "duration_s": 1, "intent": "C.", "question_mode": "specific",
         "question_pool": [{"id": "w", "text": "Q?", "coverage_tags": []}]},
    ]}, sort_keys=False)
    plan = CadencePlan.model_validate(_yaml.safe_load(legacy))     # still valid
    phase = next(p for p in plan.phases if p.id == "translation")
    resolved = phase.written_response.resolved_for(phase.question_pool[0].written_response)
    assert (resolved.source_language, resolved.target_language) == ("en", "es")

    # editing it: q1 inherits the phase pair, the new q2 brings its own
    y = update_written_phase(legacy, "translation", question_type="translation",
                             questions=[
        {"id": "translation_q1", "char_limit": 600, "source_text": "old passage"},
        {"char_limit": 200, "source_text": "new one",
         "source_language": "en", "target_language": "it"},
    ])
    pool = _phase(y, "translation")["question_pool"]
    assert pool[0]["written_response"]["target_language"] == "es"   # inherited
    assert pool[1]["written_response"]["target_language"] == "it"   # its own
    assert pool[1]["text"] == "Translate the text below from English into Italian."


def test_translation_never_takes_a_hand_written_instruction():
    # prompt_hidden: the admin authors no instruction for these types, so a
    # stale sentence can't survive a language change and contradict what's
    # graded (translation/transcription) or drift from the ground-truth
    # checklist (image_description). All three ground-truth ("ground truth
    # scoring") ADMIN-authored types hide it; comprehensive still requires it,
    # since there the instructions ARE the question.
    from app.cadence_service import append_written_phase
    from engine.brain.cadence import question_types as qt

    assert qt.spec_for("translation").prompt_hidden is True
    assert qt.spec_for("transcription").prompt_hidden is True
    assert qt.spec_for("image_description").prompt_hidden is True
    assert qt.spec_for("comprehensive").prompt_hidden is False

    y = append_written_phase(_plan_yaml(), question_type="translation",
                             name="Translation", questions=[
        {"char_limit": 600, "source_text": "x", "prompt": "MY CUSTOM INSTRUCTION",
         "source_language": "en", "target_language": "ja"},
    ])
    text = _phase(y, "translation")["question_pool"][0]["text"]
    assert text == "Translate the text below from English into Japanese."
    assert "CUSTOM" not in text


def test_the_language_pair_is_question_scoped_in_the_catalog():
    # The authoring form renders phase-level vs per-question purely off `scope`,
    # so this is what actually moves the dropdowns into each question card.
    from engine.brain.cadence import question_types as qt

    for qtype in ("translation", "transcription"):
        names = {f.name for f in qt.question_fields(qtype)}
        assert {"source_language", "target_language"} <= names, qtype
        assert not qt.phase_fields(qtype), f"{qtype} should have no phase-level fields"


def test_merging_into_a_legacy_essay_phase_resolves_each_limit_independently():
    # The legacy shape keeps limits at PHASE level with no per-question block. A
    # merged char-limited question must not end up carrying both units.
    import yaml as _yaml
    from app.cadence_service import append_essay_phase, append_written_phase
    from engine.brain.cadence.schema import CadencePlan

    y1 = append_essay_phase(_plan_yaml(), "Write about scaling.", 300, 600, "Essay")
    y2 = append_written_phase(y1, question_type="comprehensive", name="Essay",
                              questions=[{"prompt": "And caching.", "char_limit": 800}])
    plan = CadencePlan.model_validate(_yaml.safe_load(y2))
    phase = next(p for p in plan.phases if p.id == "essay")
    resolved = [phase.written_response.resolved_for(q.written_response)
                for q in phase.question_pool]
    assert [(r.limit_kind, r.limit_value) for r in resolved] == [
        ("words", 300), ("chars", 800),
    ]


# ── written-response phase-change instructions to the interviewer LLM ────────
# The task's MATERIAL (audio clip / source passage / image) is rendered on the
# candidate's screen from the phase config and deliberately never passes through
# the LLM. The model only sees the instruction — so unless told, it invents a
# plausible passage and reads it out (observed live), or answers the task itself,
# either of which silently replaces the authored assessment. It also can't know
# the submission is one-shot and tries to probe for depth.
_MATERIAL = {
    "translation": {"source_text": "Hello, how are you?"},
    "transcription": {"audio_asset": "clip.mp3"},
    "image_description": {"image_asset": "pic.png"},
    "comprehensive": {},
}
_PHASE_LEVEL = {
    "translation": {"source_language": "en", "target_language": "es"},
    "transcription": {"source_language": "en", "target_language": "en"},
    "image_description": {},
    "comprehensive": {},
}


def _written_plan(qtype: str, **wq) -> CadencePlan:
    mat = _MATERIAL[qtype]
    return CadencePlan(total_duration_s=3, timed=False, phases=[
        _spec("warm_up", "wu"),
        PhaseDef(
            id="task", duration_s=1, intent="Written.", question_mode="specific",
            question_pool=[
                QuestionPoolItem(id="t_q1", topic="t", text="FIRST task.",
                                 written_response=WrittenQuestion(
                                     char_limit=1500, time_limit_s=600, **mat, **wq)),
                QuestionPoolItem(id="t_q2", topic="t", text="SECOND task.",
                                 written_response=WrittenQuestion(char_limit=800, **mat)),
            ],
            written_response=WrittenResponse(question_type=qtype, **_PHASE_LEVEL[qtype]),
        ),
        _spec("wrap_up", "w"),
    ])


def _tracker_at_task(qtype: str) -> CadenceTracker:
    t = CadenceTracker(_written_plan(qtype), now_ms_provider=lambda: 0)
    t.pick_next_question()          # drain warm_up
    t.advance(reason="x")           # -> task, q1 on the table
    return t


@pytest.mark.parametrize("qtype,material,ban", [
    ("translation", "source passage", "do not translate the passage yourself"),
    ("transcription", "audio clip", "do not transcribe"),
    ("image_description", "the image", "do not describe the image yourself"),
])
def test_phase_change_marker_tells_the_llm_the_material_is_not_its_to_invent(
    qtype, material, ban,
):
    marker = _tracker_at_task(qtype).render_transition_marker("warm_up", "task")
    assert "WRITTEN RESPONSE TASK" in marker
    assert "EXACTLY as written" in marker          # no paraphrase licence
    assert material in marker
    assert "You do NOT have it" in marker
    assert "Never quote it, invent it" in marker
    assert ban in marker
    assert "ONE submission closes this task" in marker
    # the spoken-question paraphrase licence must NOT survive here
    assert "minimal paraphrase" not in marker


def test_comprehensive_has_no_separate_material_so_omits_that_rule():
    # Its instruction IS the whole task — claiming material is "on their screen"
    # would be a lie the model then tries to reference.
    marker = _tracker_at_task("comprehensive").render_transition_marker("warm_up", "task")
    assert "WRITTEN RESPONSE TASK" in marker
    assert "already displayed on their screen" not in marker
    assert "do not write any part of the answer for them" in marker


@pytest.mark.parametrize("qtype", list(_MATERIAL))
def test_every_question_in_the_phase_gets_the_rules_not_just_the_first(qtype):
    # A written phase holds N tasks and only the FIRST arrives via a phase
    # change; questions 2..N are dispatched with the phase unchanged, so the
    # <think> directive has to carry the rules too.
    t = _tracker_at_task(qtype)
    t.pick_next_question()                      # q1 submitted → q2 on the table
    directive = t.render_think_directive(is_phase_entry=False)
    assert "SECOND task." in directive
    assert "EXACTLY as written" in directive
    assert "WRITTEN RESPONSE TASK" in directive
    assert "ONE submission closes this task" in directive


def test_spoken_phases_are_completely_unaffected():
    t = CadenceTracker(_written_plan("translation"), now_ms_provider=lambda: 0)
    marker = t.render_transition_marker("x", "warm_up")
    assert "WRITTEN RESPONSE TASK" not in marker
    assert "minimal paraphrase for natural speech" in marker   # unchanged licence
    assert t.render_written_response_brief() == ""
    directive = t.render_think_directive(is_phase_entry=False)
    assert "WRITTEN RESPONSE TASK" not in directive
    assert "ask this question (verbatim, or minimal paraphrase" in directive


def test_a_legacy_word_limited_essay_phase_says_word_limit_not_character():
    # Legacy essay phases carry word_limit at PHASE level with no question_type;
    # the rules must describe the unit the candidate actually sees.
    plan = CadencePlan(total_duration_s=2, timed=False, phases=[
        PhaseDef(id="essay", duration_s=1, intent="Essay.", question_mode="specific",
                 question_pool=[QuestionPoolItem(id="e1", text="Write about scaling.",
                                                 coverage_tags=[])],
                 written_response=WrittenResponse(word_limit=300, time_limit_s=600)),
        _spec("wrap_up", "w"),
    ])
    t = CadenceTracker(plan, now_ms_provider=lambda: 0)
    brief = t.render_written_response_brief()
    assert "word limit" in brief and "character limit" not in brief
    assert "do not write any part of the answer for them" in brief   # reads as comprehensive


def test_phase_boundary_imperative_gains_the_written_clause_only_when_relevant():
    from engine.brain.agents.question_agent import _build_phase_transition_messages

    class _Ctx:
        def __init__(self, brief):
            self.recent_turns = []
            self.think_content = None
            self.written_response_brief = brief

    spoken = _build_phase_transition_messages(_Ctx(None))[-1]["content"]
    assert spoken.startswith("PHASE BOUNDARY")
    assert "WRITTEN task" not in spoken

    written = _build_phase_transition_messages(_Ctx("some brief"))[-1]["content"]
    assert written.startswith("PHASE BOUNDARY")          # same imperative, extended
    assert "This phase is a WRITTEN task" in written
    assert "never do the task yourself" in written
    assert "ask NO follow-up" in written


# ── draft durability: text + frozen clock survive a refresh AND a device change ──
# The candidate's UNSUBMITTED work used to live only in React state, so a refresh
# lost it even right after clicking Save (Save persisted conversation state, which
# has no field for a half-typed answer). It now autosaves to localStorage on every
# keystroke (client side) and is folded into the SIGNED payload on an explicit
# Save, which writes Redis AND mirrors to Blob — Blob has no TTL, so a "finish
# later" that outlives the Redis copy still resumes.
def _draft_app(tmp_path, monkeypatch):
    import uuid as _uuid
    import yaml as _yaml
    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    monkeypatch.setenv("TEXT_STATE_SECRET", "test-secret")
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path / "sessions"))
    monkeypatch.setenv("BLOB_ENABLED", "0")               # disk fallback
    monkeypatch.setenv("BLOB_DISK_FALLBACK_DIR", str(tmp_path / "blob"))
    monkeypatch.setenv("GROQ_API_KEY", "dummy-for-construction")

    import app.text_service as ts
    from app.paths import session_dir

    token = str(_uuid.uuid4())
    d = session_dir(token)
    d.mkdir(parents=True, exist_ok=True)
    (d / "cadence.yaml").write_text(_yaml.safe_dump({
        "total_duration_s": 2, "timed": False, "phases": [
            {"id": "essay", "duration_s": 1, "intent": "Written.",
             "question_mode": "specific",
             "question_pool": [{
                 "id": "essay_q1", "text": "Describe about LLMs",
                 "topic": "comprehensive", "coverage_tags": [],
                 "written_response": {"char_limit": 1500, "time_limit_s": 600}}],
             "written_response": {"question_type": "comprehensive"}},
            {"id": "wrap_up", "duration_s": 1, "intent": "Close.",
             "question_mode": "specific",
             "question_pool": [{"id": "wrap", "text": "Questions?", "coverage_tags": []}]},
        ]}, sort_keys=False))

    class _Store:
        def __init__(self): self.d = {}
        async def get(self, k): return self.d.get(k)
        async def set(self, k, v, ttl): self.d[k] = v
        async def delete(self, k): self.d.pop(k, None)

    class _Sink:
        async def append_events(self, token, events): pass

    store = _Store()
    ts.configure(store_factory=lambda: store, sink_factory=lambda: _Sink())
    api = FastAPI()
    api.include_router(ts.router)
    eng, _log = ts._build_engine(token, restore=None)
    blob = ts._signed(eng.snapshot(), [])
    store.d[ts._STATE_KEY.format(token=token)] = blob
    return ts, TestClient(api), token, store, blob


_DRAFT = "LLMs are autoregressive transformers trained on… (half-written)"


def test_save_puts_the_draft_in_the_signed_blob_and_mirrors_it_to_blob(tmp_path, monkeypatch):
    ts, c, token, store, blob = _draft_app(tmp_path, monkeypatch)
    r = c.post(f"/text/{token}/save", json={
        "state": blob,
        "draft": {"question_id": "essay_q1", "text": _DRAFT,
                  "remaining_s": 412, "ts": 1700000000000},
    }).json()
    assert r["ok"]
    # SIGNED, so a browser can't forge or edit it (that's why the merge is
    # server-side rather than the client adding a field to its own blob).
    payload = ts.verify_blob(r["state"], ts._secret())
    assert payload["draft"]["text"] == _DRAFT
    assert payload["draft"]["remaining_s"] == 412
    # ...and the no-TTL copy exists
    mirrored = ts._load_state_from_blob(token)
    assert mirrored is not None
    assert ts.verify_blob(mirrored, ts._secret())["draft"]["text"] == _DRAFT


def test_resume_returns_the_draft_alongside_the_question(tmp_path, monkeypatch):
    ts, c, token, store, blob = _draft_app(tmp_path, monkeypatch)
    c.post(f"/text/{token}/save", json={
        "state": blob,
        "draft": {"question_id": "essay_q1", "text": _DRAFT, "remaining_s": 412},
    })
    st = c.get(f"/text/{token}/state").json()
    assert st["question"]["question_id"] == "essay_q1"    # panel re-renders
    assert st["draft"]["text"] == _DRAFT                  # textarea refilled
    assert st["draft"]["remaining_s"] == 412              # clock, not a full reset


def test_an_expired_redis_copy_falls_back_to_blob_and_rewarms(tmp_path, monkeypatch):
    # The Redis copy has a TTL; "finish later" can easily outlive it. Losing the
    # interview at that point is the difference between a pause and a data loss.
    ts, c, token, store, blob = _draft_app(tmp_path, monkeypatch)
    c.post(f"/text/{token}/save", json={
        "state": blob,
        "draft": {"question_id": "essay_q1", "text": _DRAFT, "remaining_s": 412},
    })
    store.d.clear()                                        # TTL expiry
    st = c.get(f"/text/{token}/state").json()
    assert "state" in st, "must not report the interview as never-started"
    assert st["draft"]["text"] == _DRAFT
    assert store.d, "the hot Redis copy should be re-warmed on the way through"


def test_saving_with_no_draft_clears_a_stale_one(tmp_path, monkeypatch):
    # Otherwise a submitted question's leftover text would be re-offered later.
    ts, c, token, store, blob = _draft_app(tmp_path, monkeypatch)
    saved = c.post(f"/text/{token}/save", json={
        "state": blob,
        "draft": {"question_id": "essay_q1", "text": _DRAFT, "remaining_s": 412},
    }).json()["state"]
    again = c.post(f"/text/{token}/save", json={"state": saved}).json()
    assert ts.verify_blob(again["state"], ts._secret()).get("draft") is None
    assert c.get(f"/text/{token}/state").json()["draft"] is None


def test_a_tampered_draft_blob_is_still_refused(tmp_path, monkeypatch):
    # The draft rides inside the HMAC'd payload, so editing it invalidates the
    # signature — a candidate can't hand themselves more time this way.
    ts, c, token, store, blob = _draft_app(tmp_path, monkeypatch)
    saved = c.post(f"/text/{token}/save", json={
        "state": blob,
        "draft": {"question_id": "essay_q1", "text": _DRAFT, "remaining_s": 412},
    }).json()["state"]
    tampered = {**saved, "payload": saved["payload"].replace("412", "999", 1)}
    assert c.post(f"/text/{token}/save", json={"state": tampered}).status_code == 401


# ── question_mode NAMES the task for written-response phases ────────────────
# It used to say "specific" for all four written types, so every layer that
# needed the real kind re-derived it from a side-channel (which is what coding
# phases still do via coding_question_ids — the same inference written five
# times). The mode now states it once. Mechanically these are still pool-backed,
# so nothing may compare against "specific" any more: PhaseDef.uses_question_pool
# is the single place that knows, and the tracker's POOL INITIALISATION is the
# call site where being missed means a phase runs with nothing to ask.
def test_the_builder_writes_the_task_type_as_the_question_mode():
    from app.cadence_service import append_written_phase

    y = append_written_phase(_plan_yaml(), question_type="translation",
                             name="Translation",
                             questions=[{"char_limit": 600, "source_text": "A.",
                                         "source_language": "en",
                                         "target_language": "es"}])
    y = append_written_phase(y, question_type="comprehensive", name="Comprehensive",
                             questions=[{"prompt": "Describe LLMs.", "char_limit": 1500}])
    modes = {p["id"]: p["question_mode"] for p in _phases(y)}
    assert modes["translation"] == "translation"
    assert modes["comprehensive"] == "comprehensive"
    assert modes["wrap_up"] == "specific"          # spoken phases untouched


@pytest.mark.parametrize("mode,pool_backed", [
    ("generic", False), ("specific", True),
    ("comprehensive", True), ("transcription", True),
    ("translation", True), ("image_description", True),
])
def test_every_known_mode_declares_whether_it_is_pool_backed(mode, pool_backed):
    # Guards the landmine: a future written type that forgets this mapping would
    # silently be treated as "generic" and never get a question pool.
    from engine.brain.cadence import question_types as qt
    from engine.brain.cadence.schema import PhaseDef, QuestionPoolItem, WrittenResponse

    assert mode in {"generic", "specific", *qt.QUESTION_TYPE_IDS}
    if mode == "generic":
        phase = PhaseDef(id="p", duration_s=1, intent="i", question_mode="generic",
                         generic_prompts=["go"])
    elif mode == "specific":
        phase = PhaseDef(id="p", duration_s=1, intent="i", question_mode="specific",
                         question_pool=[QuestionPoolItem(id="q", text="t",
                                                         coverage_tags=["a"])])
    else:
        # _written_plan supplies each type's required material; re-stamp the
        # phase with its own mode.
        task = next(p for p in _written_plan(mode).phases if p.id == "task")
        phase = PhaseDef(**{**task.model_dump(), "question_mode": mode})
    assert phase.uses_question_pool is pool_backed


def test_a_written_phase_still_gets_its_question_pool_built(tmp_path):
    # THE landmine, asserted end-to-end: the tracker's pool init used to read
    # `question_mode != "specific"`, which a named mode would have failed.
    from engine.brain.cadence.schema import CadencePlan
    from app.cadence_service import append_written_phase
    import yaml as _yaml

    y = append_written_phase(_plan_yaml(), question_type="translation",
                             name="Translation", questions=[
        {"char_limit": 600, "source_text": "A.", "source_language": "en",
         "target_language": "es"},
        {"char_limit": 400, "source_text": "B.", "source_language": "en",
         "target_language": "fr"},
    ])
    plan = CadencePlan.model_validate(_yaml.safe_load(y))
    t = CadenceTracker(plan, now_ms_provider=lambda: 0)
    while t.current_phase_id != "translation":
        t.pick_next_question()
        t.advance(reason="x")
    assert t.questions_remaining() == 2, "the phase was built with no questions"
    assert t.peek_next_question() is not None


def test_the_verifier_is_told_the_task_type_not_just_specific():
    # The point of the change: a voice/text verifier grading a translation must
    # know that's what it is, without re-deriving it from the phase config.
    import yaml as _yaml
    from app.cadence_service import append_written_phase
    from engine.brain.cadence.schema import CadencePlan
    from engine.brain.contracts.session_state import CandidateProfile, SessionState
    from engine.brain.core.conversation_context import build_context

    y = append_written_phase(_plan_yaml(), question_type="translation",
                             name="Translation",
                             questions=[{"char_limit": 600, "source_text": "A.",
                                         "source_language": "en",
                                         "target_language": "es"}])
    plan = CadencePlan.model_validate(_yaml.safe_load(y))
    t = CadenceTracker(plan, now_ms_provider=lambda: 0)
    while t.current_phase_id != "translation":
        t.pick_next_question()
        t.advance(reason="x")
    ctx = build_context(
        SessionState(candidate_profile=CandidateProfile(name="S", role="Eng"),
                     phase="translation"),
        now_ms=0, tracker=t,
    )
    assert "question_mode: translation" in (ctx.current_phase_descriptor or "")
    # the pool-backed branch must still run — it builds the verifier's rubric
    # (a literal `== "specific"` here would have silently dropped it)
    assert "question:" in (ctx.current_pool_question_rubric or "")
    # and the interviewer's phase block must not contradict itself
    assert "question_mode=specific" not in t.render_phase_context()


def test_cadences_authored_before_the_named_modes_still_load():
    # Approved interviews say question_mode: specific with a written_response
    # block. They must keep working untouched — no migration.
    import yaml as _yaml
    from engine.brain.cadence.schema import CadencePlan

    legacy = _yaml.safe_dump({"total_duration_s": 1, "timed": False, "phases": [
        {"id": "translation", "duration_s": 1, "intent": "T.",
         "question_mode": "specific",
         "question_pool": [{"id": "q1", "text": "Translate.", "topic": "translation",
                            "coverage_tags": [],
                            "written_response": {"char_limit": 600, "source_text": "x",
                                                 "source_language": "en",
                                                 "target_language": "es"}}],
         "written_response": {"question_type": "translation"}},
    ]}, sort_keys=False)
    phase = CadencePlan.model_validate(_yaml.safe_load(legacy)).phases[0]
    assert phase.question_mode == "specific"        # unchanged on disk
    assert phase.uses_question_pool is True         # still pool-backed
    assert phase.written_question_type == "translation"   # type still recoverable


def test_a_mode_that_contradicts_its_written_block_is_refused():
    # Two fields naming different tasks would leave every consumer guessing.
    import yaml as _yaml
    from engine.brain.cadence.schema import CadencePlan

    bad = _yaml.safe_dump({"total_duration_s": 1, "timed": False, "phases": [
        {"id": "x", "duration_s": 1, "intent": "i", "question_mode": "translation",
         "question_pool": [{"id": "q", "text": "t", "coverage_tags": [],
                            "written_response": {"char_limit": 10, "source_text": "s",
                                                 "source_language": "en",
                                                 "target_language": "es"}}],
         "written_response": {"question_type": "comprehensive"}},
    ]}, sort_keys=False)
    with pytest.raises(ValueError, match="disagrees with"):
        CadencePlan.model_validate(_yaml.safe_load(bad))


def test_an_unknown_question_mode_is_refused():
    from engine.brain.cadence.schema import PhaseDef, QuestionPoolItem

    with pytest.raises(ValueError, match="unknown question_mode"):
        PhaseDef(id="p", duration_s=1, intent="i", question_mode="banana",
                 question_pool=[QuestionPoolItem(id="q", text="t", coverage_tags=["a"])])


# ── the API body must carry every question-scoped field the registry declares ──
# Regression: the language pair became question-scoped but `_WrittenQuestionBody`
# still only listed the material fields. Pydantic drops undeclared keys SILENTLY,
# so the languages the admin picked vanished between the browser and the builder
# and the phase was then rejected with "Transcription needs source language" —
# pointing at a field that was filled in. Nothing failed loudly at the boundary,
# which is exactly why this needs a test rather than care.
def test_the_request_body_declares_every_question_scoped_field():
    from app.main import _WrittenQuestionBody
    from engine.brain.cadence import question_types as qt

    declared = set(_WrittenQuestionBody.model_fields)
    for qtype in qt.QUESTION_TYPE_IDS:
        for field in qt.question_fields(qtype):
            assert field.name in declared, (
                f"question type '{qtype}' authors '{field.name}', but "
                f"_WrittenQuestionBody does not declare it — pydantic will drop "
                f"it and the value never reaches the builder"
            )


def test_a_picked_language_pair_survives_the_api_boundary():
    from app.main import _WrittenQuestionBody, _written_questions

    body = _WrittenQuestionBody(
        prompt="", char_limit=1500, audio_asset="clip.mp3",
        source_language="en", target_language="es",
    )
    out = _written_questions([body])[0]
    assert out["source_language"] == "en"
    assert out["target_language"] == "es"


def test_transcription_with_per_question_languages_builds(tmp_path, monkeypatch):
    # End-to-end over the real route: upload-shaped payload → add_phase → the
    # phase validates and each question keeps its own pair.
    import uuid as _uuid
    import yaml as _yaml
    from fastapi.testclient import TestClient

    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path / "sessions"))
    from app.main import app as admin_app
    from app import db as _db

    token = str(_uuid.uuid4())
    base = _yaml.safe_dump({"total_duration_s": 1, "timed": False, "phases": [
        {"id": "wrap_up", "duration_s": 1, "intent": "Close.",
         "question_mode": "specific",
         "question_pool": [{"id": "w", "text": "Q?", "coverage_tags": []}]},
    ]}, sort_keys=False)

    monkeypatch.setattr(_db, "get", lambda t: {"token": token, "role": "AI Engineer"})
    c = TestClient(admin_app)
    r = c.post(f"/api/cadence/{token}/add_phase", json={
        "yaml": base,
        "question_type": "transcription",
        "name": "Transcription",
        "questions": [
            {"prompt": "jkn", "char_limit": 1500, "audio_asset": "sample-35s.mp3",
             "source_language": "en", "target_language": "es"},
            {"prompt": "", "char_limit": 800, "audio_asset": "other.mp3",
             "source_language": "fr", "target_language": "de"},
        ],
    })
    assert r.status_code == 200, r.text
    body = r.json()
    assert body.get("ok"), body            # NOT "needs source language"
    pool = next(p for p in _yaml.safe_load(body["yaml"])["phases"]
                if p["id"] == "transcription")["question_pool"]
    assert pool[0]["written_response"]["source_language"] == "en"
    assert pool[0]["written_response"]["target_language"] == "es"
    assert pool[1]["written_response"]["source_language"] == "fr"
    assert pool[1]["written_response"]["target_language"] == "de"
