"""
Verify every question in coding/questions/library.yaml passes its own
test cases by exec'ing the `solution` field and running it.

Why: solutions are shown in the grader/reviewer path; if a solution is
wrong, scoring/hints/explanations downstream all degrade. Catch drift
the moment the YAML changes.

Run (Windows PowerShell):
    & ".venv\\Scripts\\python.exe" tests\\_verify_library.py
Run (Mac / Linux):
    ./.venv/bin/python tests/_verify_library.py
Exits non-zero if any test mismatches.
"""

from __future__ import annotations

import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT / "coding" / "questions" / "library.yaml"


def run() -> int:
    with LIB.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f)

    questions = data["questions"]
    fail_count = 0
    pass_count = 0
    total_cases = 0

    for q in questions:
        qid = q["id"]
        fn_name = q["function_name"]
        solution_src = q["solution"]

        ns: dict = {}
        try:
            exec(solution_src, ns)
        except Exception as exc:
            print(f"[FAIL] {qid}: solution failed to exec — {exc!r}")
            fail_count += 1
            continue

        fn = ns.get(fn_name)
        if fn is None:
            print(f"[FAIL] {qid}: function '{fn_name}' not defined by solution")
            fail_count += 1
            continue

        q_fail = 0
        for tc in q.get("test_cases", []):
            total_cases += 1
            name = tc["name"]
            raw_input = tc["input"]
            raw_expected = tc["expected"]
            try:
                args = eval(raw_input, {"__builtins__": __builtins__})
            except Exception as exc:
                print(f"[FAIL] {qid} :: {name}: input eval error — {exc!r}")
                q_fail += 1
                continue
            # Support both single-arg ("[1,2,3]") and tuple-of-args ("([1,2,3], 4)")
            if isinstance(args, tuple):
                call_args = args
            else:
                call_args = (args,)
            try:
                actual = fn(*call_args)
            except Exception as exc:
                print(f"[FAIL] {qid} :: {name}: solution raised — {exc!r}")
                q_fail += 1
                continue
            try:
                expected = eval(raw_expected, {"__builtins__": __builtins__})
            except Exception as exc:
                print(f"[FAIL] {qid} :: {name}: expected eval error — {exc!r}")
                q_fail += 1
                continue
            if actual != expected:
                print(
                    f"[FAIL] {qid} :: {name}: got {actual!r}, expected {expected!r}"
                )
                q_fail += 1

        if q_fail:
            fail_count += q_fail
        else:
            pass_count += 1
            print(f"[OK]   {qid}  ({len(q.get('test_cases', []))} cases)")

    print()
    print(f"Questions OK: {pass_count}/{len(questions)}")
    print(f"Total cases:  {total_cases}, failures: {fail_count}")
    return 0 if fail_count == 0 else 1


if __name__ == "__main__":
    sys.exit(run())
