"""Capacity/Speech broker tests — key rotation, admission caps, STT fallback,
LLM timeout/backup. fakeredis-backed; no Azure/Groq/LLM calls."""
from __future__ import annotations

import asyncio

import pytest

from app import coordination as coord
from app.broker import llm_guard, speech_pool, stt_fallback


@pytest.fixture()
def fake_redis():
    import fakeredis.aioredis as fr
    coord.set_redis(fr.FakeRedis(decode_responses=True))
    yield
    coord.set_redis(None)


# ── speech_pool ─────────────────────────────────────────────────────────────
def test_parse_keys_variants(monkeypatch):
    monkeypatch.setenv("AZURE_SPEECH_KEYS", "aaa:westus, bbb , ccc:eastus2")
    monkeypatch.setenv("AZURE_SPEECH_REGION", "eastus")
    keys = speech_pool.parse_keys()
    assert [k.region for k in keys] == ["westus", "eastus", "eastus2"]
    # distinct stable ids, secret never equals id
    assert len({k.key_id for k in keys}) == 3
    assert all(k.key_id != k.key for k in keys)


def test_parse_keys_single_fallback(monkeypatch):
    monkeypatch.delenv("AZURE_SPEECH_KEYS", raising=False)
    monkeypatch.setenv("AZURE_SPEECH_KEY", "solo")
    monkeypatch.setenv("AZURE_SPEECH_REGION", "eastus")
    keys = speech_pool.parse_keys()
    assert len(keys) == 1 and keys[0].region == "eastus"


@pytest.mark.asyncio
async def test_pool_grants_until_full_then_none(fake_redis, monkeypatch):
    monkeypatch.setenv("AZURE_SPEECH_KEYS", "k1,k2")
    monkeypatch.setenv("SPEECH_STREAMS_PER_KEY", "2")  # 2 keys x 2 = 4 slots

    leases = []
    for _ in range(4):
        l = await speech_pool.acquire()
        assert l is not None
        leases.append(l)
    # Pool exhausted.
    assert await speech_pool.acquire() is None

    # Streams spread across both keys (least-loaded pick), not stacked on one.
    used = {l.speech_key.key_id for l in leases}
    assert len(used) == 2

    # Releasing one frees exactly one slot.
    await speech_pool.release(leases[0])
    again = await speech_pool.acquire()
    assert again is not None


# ── stt_fallback ────────────────────────────────────────────────────────────
@pytest.mark.asyncio
async def test_stt_prefers_azure_then_groq(fake_redis, monkeypatch):
    monkeypatch.setenv("AZURE_SPEECH_KEYS", "only")
    monkeypatch.setenv("SPEECH_STREAMS_PER_KEY", "1")
    monkeypatch.setenv("GROQ_API_KEY", "gk")

    first = await stt_fallback.acquire_stt()
    assert first.provider == stt_fallback.AZURE
    assert first.key == "only"

    # Azure now full → next falls back to Groq.
    second = await stt_fallback.acquire_stt()
    assert second.provider == stt_fallback.GROQ

    await stt_fallback.release_stt(first)  # returns the azure slot
    third = await stt_fallback.acquire_stt()
    assert third.provider == stt_fallback.AZURE


@pytest.mark.asyncio
async def test_stt_raises_when_no_capacity(fake_redis, monkeypatch):
    monkeypatch.setenv("AZURE_SPEECH_KEYS", "only")
    monkeypatch.setenv("SPEECH_STREAMS_PER_KEY", "1")
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    await stt_fallback.acquire_stt()  # take the only slot
    with pytest.raises(RuntimeError):
        await stt_fallback.acquire_stt()


# ── llm_guard ───────────────────────────────────────────────────────────────
@pytest.mark.asyncio
async def test_call_with_backup_uses_primary():
    async def primary():
        return "primary-ok"
    out = await llm_guard.call_with_backup(primary, timeout_s=1.0)
    assert out == "primary-ok"


@pytest.mark.asyncio
async def test_call_with_backup_falls_over_on_timeout():
    async def slow():
        await asyncio.sleep(5)
        return "too-late"

    async def backup():
        return "backup-ok"

    out = await llm_guard.call_with_backup(slow, timeout_s=0.05, backups=[backup])
    assert out == "backup-ok"


@pytest.mark.asyncio
async def test_call_with_backup_raises_when_all_fail():
    async def boom():
        raise ValueError("nope")
    with pytest.raises(ValueError):
        await llm_guard.call_with_backup(boom, timeout_s=0.5, backups=[boom])


@pytest.mark.asyncio
async def test_llm_slot_admission_cap(fake_redis, monkeypatch):
    monkeypatch.setenv("MAX_LLM_INFLIGHT", "1")
    async with llm_guard.llm_slot() as ok1:
        assert ok1 is True
        async with llm_guard.llm_slot() as ok2:
            assert ok2 is False  # at cap
    # released on exit → available again
    async with llm_guard.llm_slot() as ok3:
        assert ok3 is True
