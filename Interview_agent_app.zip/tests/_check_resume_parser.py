"""Probe why attachments fails on the user's resume PDF.

Run directly WITHOUT the fd-level silencer so we see what attachments is
actually printing on failure.
"""
from __future__ import annotations

import sys
from pathlib import Path


def main(pdf_path: str) -> int:
    p = Path(pdf_path)
    print(f"PDF path: {p}")
    print(f"Exists: {p.exists()}")
    print(f"Is file: {p.is_file()}")
    try:
        print(f"Size: {p.stat().st_size} bytes")
    except Exception as e:
        print(f"Stat failed: {e}")

    # Try attachments
    try:
        from attachments import Attachments
    except ImportError as e:
        print(f"FAIL: attachments not installed: {e}")
        return 1

    print("\n--- Running Attachments() directly (no FD silencing) ---")
    try:
        ctx = Attachments(str(p))
        rendered = str(ctx)
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"\nAttachments raised: {e}")
        return 2

    print(f"\nRendered length: {len(rendered)} chars")
    print(f"First 600 chars of rendered output:")
    print("-" * 60)
    print(rendered[:600])
    print("-" * 60)
    return 0


if __name__ == "__main__":
    pdf = sys.argv[1] if len(sys.argv) > 1 else r"sessions\ebeb5068-2d8a-4fa2-8fb1-730333d94c60\Raghu Dasigi - AI Engineer Resume 1.pdf"
    sys.exit(main(pdf))
