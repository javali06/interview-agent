"""Reproduce exactly what the orchestrator does — call _silence_load."""
from __future__ import annotations

import sys
from pathlib import Path


def main(pdf_path: str) -> int:
    from orchestrator_new.resume_parser import _silence_load, _strip_markdown_wrapper
    print(f"Path: {pdf_path}")
    try:
        rendered = _silence_load(pdf_path)
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"_silence_load raised: {e}")
        return 1

    print(f"Rendered length: {len(rendered)}")
    print(f"First 400 chars of rendered output:")
    print("-" * 60)
    print(rendered[:400])
    print("-" * 60)

    text = _strip_markdown_wrapper(rendered)
    print(f"After strip_markdown_wrapper: {len(text)} chars")
    print(f"First 400 chars:")
    print("-" * 60)
    print(text[:400])
    print("-" * 60)
    return 0


if __name__ == "__main__":
    pdf = sys.argv[1] if len(sys.argv) > 1 else r"sessions\ebeb5068-2d8a-4fa2-8fb1-730333d94c60\Raghu Dasigi - AI Engineer Resume 1.pdf"
    sys.exit(main(pdf))
