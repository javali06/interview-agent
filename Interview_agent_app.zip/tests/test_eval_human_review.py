"""Human review on top of the LLM evaluation.

The feature is one rule and its consequences:

    the AI's number is never overwritten.

`marks_earned` on an exported section keeps meaning *what the model said*; the
reviewer's correction lives in `review.final_marks_earned`. Audit (a raised
score and an AI score are different claims), measurement (each adjustment is a
labelled example of where the model is wrong) and regeneration (which rewrites
every AI value) all break the moment those two share a field.

No LLM and no database: the merge is a pure function over an already-built
export plus a list of records.
"""
from __future__ import annotations

import json

import pytest
from pydantic import ValidationError

from features.eval import export as X
from features.eval import review as R
from features.eval.plugins.base import BreakdownItem, SegmentEvaluation
from features.eval.plugins.export import SectionReview
from features.eval.plugins.registry import list_plugins
from features.eval.sectioner import Segment


def _seg(segment_id: str, phase_id: str = "warm_up") -> Segment:
    return Segment(segment_id=segment_id, kind="question", phase_id=phase_id,
                   question_id="q1", start_event_index=0, end_event_index=1, turns=[])


def _rubric_doc():
    """One conversational_rubric segment: 2 dimensions, 2.8 of 5 marks.

    mean(7, 4) = 5.5 → 5.5/10 × 5 = 2.75 ≈ 2.8, i.e. the plugin's real
    arithmetic, so a recompute here is checkable by hand."""
    ev = SegmentEvaluation(
        plugin_id="conversational_rubric", segment_id="w::0", phase_id="warm_up",
        state="scored", marks_earned=2.8, marks_possible=5.0, rationale="intern-level depth",
        breakdown=[BreakdownItem(label="communication_clarity", delta=7.0, detail="7/10"),
                   BreakdownItem(label="role_fit", delta=4.0, detail="4/10")],
        sub_scores={"communication_clarity": 7.0, "role_fit": 4.0},
        view_payload={"dimensions": {"communication_clarity": 7.0, "role_fit": 4.0},
                      "mean_0_10": 5.5, "rationale": "intern-level depth"})
    return json.loads(X.build_report([(_seg("w::0"), ev)]).model_dump_json())


def _submit(doc, **kw):
    base = dict(segment_id="w::0", section="rubric_dimensions",
                reason_kind="ai_misread", reason="Scored seniority off the job title.")
    base.update(kw)
    sub = R.ReviewSubmission(**base)
    return R.records_from_submission("tok", sub, doc["sections"][0],
                                     reviewer="sathwik@centific.com",
                                     generated_at=doc["generated_at"])


# ── the load-bearing serialisation fix ──────────────────────────────────────
def test_a_section_exports_its_plugins_own_payload_not_just_the_envelope():
    """Regression: `sections` declared as the base model alone serialises to the
    BASE's fields and silently drops every plugin-specific key — so the document
    did not validate against the `section_schemas` it ships with, and the UI
    rendered empty payloads. Duck-typed serialisation keeps them."""
    sec = _rubric_doc()["sections"][0]
    assert sec["dimensions"] == {"communication_clarity": 7.0, "role_fit": 4.0}
    assert sec["rationale"] == "intern-level depth"
    declared = set(X.build_report([]).section_schemas["rubric_dimensions"]["json_schema"]["properties"])
    assert declared <= set(sec), f"declared but not emitted: {declared - set(sec)}"


# ── the AI's number survives ────────────────────────────────────────────────
def test_the_ai_score_is_kept_beside_the_human_one_never_replaced():
    doc = _rubric_doc()
    merged = R.apply_reviews(doc, _submit(doc, items={"role_fit": 9.0}))
    sec = merged["sections"][0]
    assert sec["marks_earned"] == 2.8, "the model's own number must still be readable"
    assert sec["review"]["final_marks_earned"] == 4.0
    assert sec["review"]["items"] == [
        {"label": "role_fit", "ai_value": 4.0, "human_value": 9.0,
         "reason": "Scored seniority off the job title."}]


def test_an_unreviewed_document_is_returned_untouched():
    # An evaluation nobody reviewed must read exactly as it did before this
    # feature existed — no review block, no second totals, no status change.
    doc = _rubric_doc()
    assert R.apply_reviews(doc, []) is doc
    assert doc["sections"][0]["review"] is None
    assert doc.get("totals_after_review") is None
    assert doc["review_status"] == "ai_only"


# ── the arithmetic stays the system's job ───────────────────────────────────
def test_moving_one_dimension_recomputes_the_marks_by_the_plugins_own_rule():
    # mean(7, 9) = 8 → 8/10 × 5 = 4.0. The reviewer moves the judgement they
    # have an opinion about; they never hand-compute a total.
    doc = _rubric_doc()
    merged = R.apply_reviews(doc, _submit(doc, items={"role_fit": 9.0}))
    assert merged["sections"][0]["review"]["final_marks_earned"] == 4.0


def test_a_direct_total_wins_over_the_recompute():
    doc = _rubric_doc()
    merged = R.apply_reviews(doc, _submit(doc, items={"role_fit": 9.0}, marks_earned=5.0))
    assert merged["sections"][0]["review"]["final_marks_earned"] == 5.0


def test_sum_deltas_plugins_recompute_by_summing_their_breakdown():
    ev = SegmentEvaluation(
        plugin_id="coverage_tags", segment_id="t::q1", phase_id="technical_questions",
        state="scored", marks_earned=2.0, marks_possible=4.0, rationale="1/2 covered",
        breakdown=[BreakdownItem(label="batching", delta=2.0, detail="covered"),
                   BreakdownItem(label="quantisation", delta=0.0, detail="missing")],
        view_payload={"tags": [], "matched": 1, "total": 2})
    doc = json.loads(X.build_report([(_seg("t::q1", "technical_questions"), ev)]).model_dump_json())
    sub = R.ReviewSubmission(segment_id="t::q1", section="coverage_tags",
                             items={"quantisation": 2.0}, reason_kind="ai_misread",
                             reason="They did cover quantisation, in the second follow-up.")
    merged = R.apply_reviews(doc, R.records_from_submission("tok", sub, doc["sections"][0],
                                                            reviewer="ta@x"))
    assert merged["sections"][0]["review"]["final_marks_earned"] == 4.0


def test_every_plugin_declares_what_a_reviewer_may_edit():
    # A new plugin with no declaration defaults to total-only, which is the safe
    # reading — but it must be a real declaration, not a missing attribute.
    for p in list_plugins():
        d = p.export_descriptor()
        if d is None:
            continue
        assert d.adjustable is not None, p.id
        if d.adjustable.items:
            assert d.adjustable.recompute != "none", (
                f"{d.key} offers per-item editing but declares no way to recompute "
                "its marks — the reviewer would move a line and see no effect")


def test_python_method_plugins_are_total_only():
    # Overriding "3 of 5 tests passed" is not a rubric judgement. If the harness
    # was broken that is a total override with a stated reason, and it reads as
    # exactly that in the file.
    from features.eval.plugins.registry import get_plugin
    for pid in ("coding", "transcription_scoring", "translation_scoring",
                "image_description_scoring"):
        assert get_plugin(pid).export_descriptor().adjustable.items is False, pid


# ── invariants that must survive human editing ──────────────────────────────
def test_marks_cannot_exceed_what_the_question_is_worth():
    doc = _rubric_doc()
    merged = R.apply_reviews(doc, _submit(doc, marks_earned=99.0))
    assert merged["sections"][0]["review"]["final_marks_earned"] == 5.0, "clamped, not accepted"


def test_marks_possible_is_not_editable_through_a_review():
    # Two candidates scored out of different denominators aren't comparable, so
    # what a question is worth is a cadence edit, never a review.
    doc = _rubric_doc()
    merged = R.apply_reviews(doc, _submit(doc, marks_earned=4.0))
    assert merged["sections"][0]["review"]["final_marks_possible"] == 5.0
    assert merged["sections"][0]["marks_possible"] == 5.0
    with pytest.raises(ValidationError):
        R.ReviewSubmission(segment_id="w::0", section="rubric_dimensions",
                           marks_possible=99.0, reason_kind="other", reason="x")


def test_a_reviewer_cannot_turn_a_non_scored_segment_into_a_zero():
    # The same rule the envelope enforces on the model. A reviewer MAY change
    # the state — that is a separate, stated act — but marks and a non-scored
    # state still cannot coexist.
    with pytest.raises(ValidationError, match="not a zero|must not carry marks"):
        SectionReview(final_state="not_observed", final_marks_earned=0.0,
                      final_marks_possible=5.0)


def test_a_review_must_change_something_and_must_say_why():
    with pytest.raises(ValidationError, match="reason is required"):
        R.ReviewSubmission(segment_id="w::0", section="rubric_dimensions",
                           marks_earned=4.0, reason_kind="other", reason="   ")
    with pytest.raises(ValidationError, match="must change a mark"):
        R.ReviewSubmission(segment_id="w::0", section="rubric_dimensions",
                           reason_kind="other", reason="looks fine to me")


def test_reason_kind_is_a_closed_set_so_adjustments_stay_aggregatable():
    with pytest.raises(ValidationError):
        R.ReviewSubmission(segment_id="w::0", section="rubric_dimensions",
                           marks_earned=4.0, reason_kind="because_i_said_so", reason="x")


# ── totals ──────────────────────────────────────────────────────────────────
def test_totals_after_review_use_the_final_marks_and_the_ai_totals_are_kept():
    doc = _rubric_doc()
    merged = R.apply_reviews(doc, _submit(doc, items={"role_fit": 9.0}))
    assert merged["totals"]["marks_earned"] == 2.8, "the AI's totals must not move"
    assert merged["totals_after_review"]["marks_earned"] == 4.0
    assert merged["totals_after_review"]["pct"] == 80.0
    assert merged["review_status"] == "human_reviewed"


def test_a_non_scored_section_still_shrinks_the_denominator_after_review():
    """The invariant that can reach a hiring decision, checked on the reviewed
    path too: a phase that never ran is absent from the totals, not a zero."""
    ran = SegmentEvaluation(plugin_id="coverage_tags", segment_id="t::q1",
                            phase_id="technical_questions", state="scored",
                            marks_earned=4.0, marks_possible=5.0, rationale="ok",
                            breakdown=[BreakdownItem(label="batching", delta=4.0, detail="covered")],
                            view_payload={"tags": [], "matched": 1, "total": 1})
    missed = SegmentEvaluation(plugin_id="rubric_marks", segment_id="c::q1",
                               phase_id="coding_round", state="not_observed",
                               marks_earned=0.0, marks_possible=30.0,
                               rationale="Phase did not run.")
    doc = json.loads(X.build_report([
        (_seg("t::q1", "technical_questions"), ran),
        (_seg("c::q1", "coding_round"), missed)]).model_dump_json())
    sub = R.ReviewSubmission(segment_id="t::q1", section="coverage_tags",
                             marks_earned=5.0, reason_kind="calibration",
                             reason="Full credit — the depth was there.")
    merged = R.apply_reviews(doc, R.records_from_submission("tok", sub, doc["sections"][0],
                                                            reviewer="ta@x"))
    t = merged["totals_after_review"]
    assert t["marks_possible"] == 5.0, "the unobserved 30 marks must not appear"
    assert t["marks_earned"] == 5.0 and t["pct"] == 100.0
    assert t["by_state"] == {"scored": 1, "not_observed": 1}


# ── regeneration ────────────────────────────────────────────────────────────
def test_a_regenerate_that_moves_the_ai_value_flags_the_review_stale():
    """Never silently dropped (the reviewer's work vanishes), never silently
    re-applied (a correction to a judgement the model no longer makes)."""
    doc = _rubric_doc()
    records = _submit(doc, items={"role_fit": 9.0})
    regenerated = _rubric_doc()
    regenerated["sections"][0]["breakdown"][1]["delta"] = 6.0   # the AI changed its mind
    merged = R.apply_reviews(regenerated, records)
    assert merged["sections"][0]["review"]["stale"] is True
    assert merged["sections"][0]["review"]["final_marks_earned"] == 4.0, (
        "the correction still applies until a human confirms or redoes it")


def test_an_unchanged_ai_value_carries_the_review_forward_without_flagging():
    doc = _rubric_doc()
    merged = R.apply_reviews(_rubric_doc(), _submit(doc, items={"role_fit": 9.0}))
    assert merged["sections"][0]["review"]["stale"] is False


# ── provenance ──────────────────────────────────────────────────────────────
def test_each_record_freezes_what_it_was_correcting():
    doc = _rubric_doc()
    rec = next(r for r in _submit(doc, items={"role_fit": 9.0}) if r.target.item_label)
    assert rec.ai_value == 4.0 and rec.human_value == 9.0
    assert rec.ai_rationale == "intern-level depth"
    assert rec.evaluation_generated_at == doc["generated_at"]
    assert rec.reviewer == "sathwik@centific.com"
    assert rec.status == "active"


def test_a_note_alone_is_recorded_without_changing_any_mark():
    doc = _rubric_doc()
    merged = R.apply_reviews(doc, _submit(doc, note="Worth a second opinion on depth.",
                                          reason_kind="other", reason="Flagging for review."))
    rev = merged["sections"][0]["review"]
    assert rev["notes"] == ["Worth a second opinion on depth."]
    assert rev["final_marks_earned"] == 2.8, "a note must not move the score"
    assert merged["totals_after_review"]["marks_earned"] == 2.8


# ── through the API ─────────────────────────────────────────────────────────
@pytest.fixture()
def api(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path / "sessions"))
    monkeypatch.setenv("BLOB_ENABLED", "0")
    monkeypatch.setenv("DATABASE_URL", f"sqlite:///{tmp_path / 'rev.db'}")
    import importlib
    from fastapi.testclient import TestClient
    from app import blob_store, paths
    from db import engine as dbengine
    importlib.reload(paths)
    importlib.reload(blob_store)
    dbengine.reset_engine()
    dbengine.create_all()
    import app.main as M
    importlib.reload(M)

    token = "tok-review-1"
    row = {"token": token, "role": "AI Engineer", "candidate_name": "Sam",
           "status": "completed", "event_log_path": "events.jsonl", "modality": "voice"}
    sdir = M.session_dir(token)
    sdir.mkdir(parents=True, exist_ok=True)
    (sdir / "evaluation_export.json").write_text(json.dumps(_rubric_doc(), indent=2),
                                                 encoding="utf-8")
    monkeypatch.setattr(M.db, "get", lambda t: row if t == token else None)
    monkeypatch.setattr(M, "_require_user_or_redirect", lambda r: None)
    monkeypatch.setattr(M.auth, "get_current_user", lambda r: "sathwik@centific.com")
    return M, TestClient(M.app), token


def _post(client, token, **kw):
    body = dict(segment_id="w::0", section="rubric_dimensions",
                reason_kind="ai_misread", reason="Scored seniority off the job title.")
    body.update(kw)
    return client.post(f"/api/sessions/{token}/review", json=body)


def test_the_screen_and_the_download_stay_one_document_after_a_review(api):
    """The existing guarantee, re-asserted on the reviewed path. Both routes go
    through one merge; a second implementation is how they would drift."""
    _M, c, token = api
    assert _post(c, token, items={"role_fit": 9.0}).status_code == 200

    view = c.get(f"/api/sessions/{token}/evaluation-view")
    download = c.get(f"/admin/sessions/{token}/evaluation-export.json?inline=1")
    assert view.status_code == 200 and download.status_code == 200
    assert view.json()["export"] == download.json()
    assert download.json()["sections"][0]["review"]["final_marks_earned"] == 4.0


def test_the_stored_artefact_is_never_rewritten_by_a_review(api):
    """The export is the record of what the MODEL produced. A human correction
    is a separate store joined on read — if a review edited the file, a
    regenerate could no longer tell the two apart."""
    M, c, token = api
    before = (M.session_dir(token) / "evaluation_export.json").read_text()
    _post(c, token, marks_earned=5.0)
    assert (M.session_dir(token) / "evaluation_export.json").read_text() == before


def test_a_review_is_rejected_without_a_reason(api):
    _M, c, token = api
    r = _post(c, token, marks_earned=4.0, reason="  ")
    assert r.status_code == 400 and "reason" in r.json()["detail"]


def test_a_review_for_an_unknown_section_is_refused(api):
    _M, c, token = api
    assert _post(c, token, section="not_a_section", marks_earned=4.0).status_code == 404


def test_re_reviewing_a_section_supersedes_rather_than_stacking(api):
    """One submission is one coherent statement about a section. A reviewer who
    edits twice gets their second verdict, not a half-old blend of both."""
    _M, c, token = api
    _post(c, token, items={"role_fit": 9.0})
    _post(c, token, items={"role_fit": 6.0}, reason="Second look — solid, not exceptional.")
    doc = c.get(f"/admin/sessions/{token}/evaluation-export.json?inline=1").json()
    rev = doc["sections"][0]["review"]
    assert [i["human_value"] for i in rev["items"]] == [6.0]
    assert rev["final_marks_earned"] == 3.25   # mean(7, 6) = 6.5 -> 6.5/10 * 5
    assert rev["reason"].startswith("Second look")


def test_withdrawing_a_review_falls_back_to_the_ai_score(api):
    _M, c, token = api
    _post(c, token, items={"role_fit": 9.0})
    r = c.request("DELETE", f"/api/sessions/{token}/review",
                  params={"segment_id": "w::0", "section": "rubric_dimensions"})
    assert r.status_code == 200
    doc = c.get(f"/admin/sessions/{token}/evaluation-export.json?inline=1").json()
    assert doc["sections"][0]["review"] is None
    assert doc["sections"][0]["marks_earned"] == 2.8
    assert doc["review_status"] == "ai_only"


def test_the_reviewer_is_recorded_from_the_session_not_the_request_body(api):
    # Who adjusted a score is an audit fact, so it comes from the authenticated
    # session — a client cannot claim to be someone else.
    _M, c, token = api
    _post(c, token, marks_earned=4.0)
    doc = c.get(f"/admin/sessions/{token}/evaluation-export.json?inline=1").json()
    assert doc["sections"][0]["review"]["reviewer"] == "sathwik@centific.com"
