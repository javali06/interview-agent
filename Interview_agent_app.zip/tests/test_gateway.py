"""Gateway WS-proxy routing-decision tests (fakeredis). The byte-pump itself
needs a live socket pair and is covered by the local-stack integration run."""
from __future__ import annotations

import pytest

from app import coordination as coord
from app.coordination import admission, registry
from app.gateway import ws_proxy


@pytest.fixture()
def env(monkeypatch):
    import fakeredis.aioredis as fr
    coord.set_redis(fr.FakeRedis(decode_responses=True))
    monkeypatch.setenv("SESSION_SHARDS", "session-0,session-1,session-2")
    monkeypatch.setenv("SESSION_SHARD_FQDNS",
                       "s0.internal:8080,s1.internal:8080,s2.internal:8080")
    yield
    coord.set_redis(None)


@pytest.mark.asyncio
async def test_existing_token_routes_to_owning_shard(env):
    await registry.claim("tok", shard="session-1", fqdn="s1.internal:8080")
    assert await ws_proxy.resolve_target("tok") == "s1.internal:8080"


@pytest.mark.asyncio
async def test_new_candidate_token_placed_on_least_loaded(env):
    # Load session-0 and session-1 so session-2 is least loaded.
    await admission.try_acquire(admission.shard_counter("session-0"), None)
    await admission.try_acquire(admission.shard_counter("session-1"), None)
    target = await ws_proxy.resolve_target("brand-new")
    assert target == "s2.internal:8080"


@pytest.mark.asyncio
async def test_proxy_forwards_the_tab_id_to_the_shard(env, monkeypatch):
    # The shard tells a refresh (same tab) from the link opened in a second tab
    # by ?client= — dropping it at the gateway would let a second tab steal a
    # live interview again.
    from app.gateway import ws_proxy

    async def target(token):
        return "session-0:8080"
    seen = {}

    def connect(uri, **kw):
        seen["uri"] = uri
        raise ConnectionError("stop here")

    class _Client:
        async def accept(self): pass
        async def close(self, code=1000): pass

    monkeypatch.setattr(ws_proxy, "resolve_target", target)
    monkeypatch.setattr(ws_proxy.websockets, "connect", connect)
    await ws_proxy.proxy(_Client(), "sid", "tokA", "tab-1")
    assert seen["uri"] == "ws://session-0:8080/ws/candidate/sid?token=tokA&client=tab-1"
