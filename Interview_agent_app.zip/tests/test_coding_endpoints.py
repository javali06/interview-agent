"""In-process tests for the new coding admin endpoints and schema/state
changes from the coding integration PR.

Run with: `.venv\\Scripts\\python.exe -m pytest tests/test_coding_endpoints.py -v`

Coverage:
  - GET /admin/coding/questions (auth, filters, solution-stripping)
  - GET /admin/coding/question/{qid} (auth, 404, solution-stripping)
  - PhaseDef fallback generic_prompts injection (#11)
  - PhaseDef silent tolerance of legacy coding_time_budget_s (#13)
  - SessionState.last_coding_submission default value (#1)
  - Director.request_session_end public API (#3)
  - Coding-submission prompt block rendering (#1)
"""
from __future__ import annotations

import os

import pytest


# ── fixtures ──────────────────────────────────────────────────────────


@pytest.fixture
def admin_client():
    # Lazy import: starting the FastAPI app pulls in a lot of optional deps.
    from fastapi.testclient import TestClient
    from app import auth, main
    client = TestClient(main.app)
    cookie_value = auth.issue_cookie("test_admin")
    client.cookies.set(auth.COOKIE_NAME, cookie_value)
    return client


# ── admin endpoint tests ───────────────────────────────────────────────


def test_questions_list_requires_auth():
    from fastapi.testclient import TestClient
    from app import main
    client = TestClient(main.app)  # no cookie
    r = client.get("/admin/coding/questions")
    # Endpoint returns 401 JSON; main.py auth helpers redirect HTML routes.
    assert r.status_code == 401


def test_questions_list_returns_library(admin_client):
    r = admin_client.get("/admin/coding/questions")
    assert r.status_code == 200, r.text
    data = r.json()
    assert data["ok"] is True
    assert data["count"] >= 1
    assert isinstance(data["questions"], list)
    # Sanity: each entry has the expected picker shape
    q = data["questions"][0]
    expected_keys = {
        "id", "title", "prompt", "starter_code", "function_name",
        "test_case_count", "difficulty", "topic", "role_fit", "hint_count",
    }
    assert expected_keys.issubset(q.keys())


def test_questions_list_never_leaks_solution(admin_client):
    # Library-internal `solution` field must NEVER reach the browser.
    r = admin_client.get("/admin/coding/questions")
    assert r.status_code == 200
    for q in r.json()["questions"]:
        assert "solution" not in q
        assert "_solution" not in q


def test_questions_list_difficulty_filter(admin_client):
    r_all = admin_client.get("/admin/coding/questions").json()
    r_easy = admin_client.get("/admin/coding/questions?difficulty=easy").json()
    assert r_easy["count"] <= r_all["count"]
    for q in r_easy["questions"]:
        assert q["difficulty"] == "easy"


def test_questions_list_topic_filter(admin_client):
    # Pick a known-good topic from the library
    r_all = admin_client.get("/admin/coding/questions").json()
    topics = set()
    for q in r_all["questions"]:
        topics.update(q.get("topic") or [])
    if not topics:
        pytest.skip("library has no topics; nothing to filter on")
    one = next(iter(topics))
    r_filtered = admin_client.get(f"/admin/coding/questions?topic={one}").json()
    for q in r_filtered["questions"]:
        assert one in q["topic"]


def test_questions_list_sorted_by_difficulty(admin_client):
    r = admin_client.get("/admin/coding/questions").json()
    order = {"easy": 0, "medium": 1, "hard": 2}
    diffs = [order.get(q["difficulty"], 9) for q in r["questions"]]
    assert diffs == sorted(diffs), f"questions not sorted by difficulty: {diffs}"


def test_question_detail_returns_full_shape(admin_client):
    # Get any qid from the list
    listing = admin_client.get("/admin/coding/questions").json()
    qid = listing["questions"][0]["id"]
    r = admin_client.get(f"/admin/coding/question/{qid}")
    assert r.status_code == 200, r.text
    data = r.json()
    assert data["ok"] is True
    q = data["question"]
    # Detail view adds hints + test_cases beyond the picker shape
    assert "hints" in q
    assert "test_cases" in q
    assert isinstance(q["test_cases"], list)
    # Still no solution leak
    assert "solution" not in q


def test_question_detail_404(admin_client):
    r = admin_client.get("/admin/coding/question/__no_such_question__")
    assert r.status_code == 404
    data = r.json()
    assert data["ok"] is False


def test_question_detail_requires_auth():
    from fastapi.testclient import TestClient
    from app import main
    client = TestClient(main.app)
    r = client.get("/admin/coding/question/anything")
    assert r.status_code == 401


# ── schema tests (#11, #13) ────────────────────────────────────────────


def test_schema_fallback_generic_prompts():
    # Tier 3 #11: coding phase without generic_prompts gets a safe default
    from engine.brain.cadence.schema import PhaseDef
    ph = PhaseDef(
        id="coding_q1",
        duration_s=600,
        intent="Candidate solves a coding question.",
        question_mode="generic",
        coding_question_id="running_sum",
    )
    assert ph.generic_prompts  # non-empty
    assert len(ph.generic_prompts) == 1
    assert "coding exercise" in ph.generic_prompts[0].lower()


def test_schema_preserves_explicit_generic_prompts():
    # Fallback should NOT override admin-provided prompts.
    from engine.brain.cadence.schema import PhaseDef
    ph = PhaseDef(
        id="coding_q1",
        duration_s=600,
        intent="x",
        question_mode="generic",
        coding_question_id="running_sum",
        generic_prompts=["Custom opener."],
    )
    assert ph.generic_prompts == ["Custom opener."]


def test_schema_silently_drops_legacy_coding_time_budget_s():
    # Tier 3 #13: schema dropped the field, but legacy YAMLs still set it.
    # Pydantic v2 default extras-ignore behavior should silently drop it.
    from engine.brain.cadence.schema import PhaseDef
    ph = PhaseDef.model_validate({
        "id": "coding_q1",
        "duration_s": 600,
        "intent": "x",
        "question_mode": "generic",
        "coding_question_id": "running_sum",
        "coding_time_budget_s": 900,  # legacy field
        "generic_prompts": ["opener"],
    })
    assert not hasattr(ph, "coding_time_budget_s")
    assert ph.duration_s == 600


def test_example_cadence_validates():
    # Sanity: shipped example_cadence.yaml still validates against new schema
    import yaml
    from pathlib import Path
    from engine.brain.cadence.schema import CadencePlan
    yaml_path = (
        Path(__file__).resolve().parent.parent / "features" / "coding" / "example_cadence.yaml"
    )
    plan = CadencePlan.model_validate(yaml.safe_load(yaml_path.read_text()))
    ids = [p.id for p in plan.phases]
    assert ids == ["warm_up", "coding_q1", "code_discussion", "wrap_up"]
    # The legacy single-question `coding_question_id` is normalized into the
    # canonical `coding_question_ids` list and the legacy field is cleared, so
    # the model round-trips (dump -> load) without tripping the EITHER/OR guard.
    coding = [p for p in plan.phases if p.coding_question_ids]
    assert len(coding) == 1
    assert coding[0].coding_question_ids == ["running_sum"]
    assert coding[0].coding_question_id is None  # legacy field consumed


def test_coding_phase_roundtrips_idempotently():
    # Regression for the cadence-flow breakage: the normalizer used to lift the
    # legacy `coding_question_id` into the list but leave it set, so a
    # dump -> load round-trip serialized BOTH fields and re-validation raised
    # "set EITHER ... OR ... not both" — breaking every cadence customize /
    # revise / validate / approve. It now clears the legacy field => idempotent.
    import yaml
    from engine.brain.cadence.schema import CadencePlan
    base = {
        "total_duration_s": 120,
        "phases": [
            {"id": "warm_up", "intent": "warm up", "duration_s": 60,
             "question_mode": "generic", "generic_prompts": ["Hi."]},
            {"id": "coding", "intent": "code", "duration_s": 60,
             "question_mode": "generic", "coding_question_id": "running_sum"},
        ],
    }
    plan = CadencePlan.model_validate(base)
    c = next(p for p in plan.phases if p.id == "coding")
    assert c.coding_question_id is None and c.coding_question_ids == ["running_sum"]
    # the exact round-trip every customize/revise/validate/approve performs:
    reparsed = CadencePlan.model_validate(
        yaml.safe_load(yaml.safe_dump(plan.model_dump(mode="json")))
    )
    rc = next(p for p in reparsed.phases if p.id == "coding")
    assert rc.coding_question_ids == ["running_sum"] and rc.coding_question_id is None


def test_coding_phase_consistent_both_set_is_accepted():
    # The cadence a user got stuck on already carried BOTH fields (consistent).
    # That must normalize, not error.
    from engine.brain.cadence.schema import PhaseDef
    ph = PhaseDef.model_validate({
        "id": "coding", "intent": "code", "duration_s": 60,
        "question_mode": "generic",
        "coding_question_id": "running_sum",
        "coding_question_ids": ["running_sum"],
    })
    assert ph.coding_question_id is None and ph.coding_question_ids == ["running_sum"]


def test_coding_phase_genuine_conflict_rejected():
    import pytest
    from engine.brain.cadence.schema import PhaseDef
    with pytest.raises(Exception):
        PhaseDef.model_validate({
            "id": "coding", "intent": "code", "duration_s": 60,
            "question_mode": "generic",
            "coding_question_id": "running_sum",
            "coding_question_ids": ["two_sum"],  # conflicts with the legacy id
        })


def test_parse_llm_json_accepts_json_fenced_and_yaml():
    # Every cadence agent asks the LLM for JSON (robust vs whitespace-sensitive
    # YAML like 'total_duration_s: 300phases:'); the shared parser accepts JSON,
    # fenced JSON, or a YAML fallback, and rejects non-objects.
    import pytest
    from app.cadence_agents import parse_llm_json
    assert parse_llm_json('{"total_duration_s": 1, "phases": []}')["total_duration_s"] == 1
    assert parse_llm_json('```json\n{"total_duration_s": 2, "phases": []}\n```')["total_duration_s"] == 2
    assert parse_llm_json("total_duration_s: 3\nphases: []")["total_duration_s"] == 3
    with pytest.raises(ValueError):
        parse_llm_json("[1, 2, 3]")


# ── state + context tests (#1) ─────────────────────────────────────────


def test_session_state_last_coding_submission_default():
    from engine.brain.contracts.session_state import SessionState
    s = SessionState()
    assert s.last_coding_submission is None


def test_coding_submission_block_render():
    # Tier 1 #1: helper that renders the LLM prompt block from a submission.
    from engine.brain.core.conversation_context import (
        _render_coding_submission_block,
    )
    sub = {
        "phase_id": "coding_q1",
        "question_id": "running_sum",
        "function_name": "running_sum",
        "question_prompt": "Return a running sum.",
        "code": "def running_sum(nums):\n    return [sum(nums[:i+1]) for i in range(len(nums))]",
        "test_results": [
            {"name": "empty", "passed": True},
            {"name": "basic", "passed": True},
            {"name": "negatives", "passed": False, "error": "off by one"},
        ],
    }
    block = _render_coding_submission_block(sub)
    assert "running_sum" in block
    assert "2/3" in block  # tests passed summary
    assert "off by one" in block  # failure detail surfaced
    assert "Open by asking the candidate to walk through" in block
    # Code is properly indented inside the YAML-like block
    assert "submitted_code:" in block
    assert "def running_sum" in block


def test_coding_submission_block_handles_empty_results():
    from engine.brain.core.conversation_context import (
        _render_coding_submission_block,
    )
    block = _render_coding_submission_block({
        "phase_id": "coding_q1",
        "question_id": "x",
        "function_name": "x",
        "question_prompt": "",
        "code": "",
        "test_results": [],
    })
    assert "no test results recorded" in block


# ── director public-API test (#3) ──────────────────────────────────────


def test_director_request_session_end_exists():
    # Tier 1 #3: new public method for external session-end requests.
    from engine.brain.core.director import Director
    assert hasattr(Director, "request_session_end")
    assert callable(Director.request_session_end)


def test_backfill_attaches_question_to_intent_coding_phase():
    # Regression: the cadence LLM often emits a "coding" phase + intro prompt
    # but forgets coding_question_id, so the coding window never opens. The
    # backfill safety net must attach a valid library question.
    from app.cadence_service import backfill_coding_questions, _is_intended_coding_phase
    data = {
        "total_duration_s": 120,
        "phases": [
            {"id": "warm_up", "intent": "warm up", "duration_s": 60,
             "question_mode": "generic", "generic_prompts": ["Hi."]},
            {"id": "coding", "intent": "Candidate solves one Python question; AI observes.",
             "duration_s": 60, "question_mode": "generic",
             "generic_prompts": ["We'll do a short coding exercise; the question is on screen."]},
        ],
    }
    assert _is_intended_coding_phase(data["phases"][1]) is True
    assert _is_intended_coding_phase(data["phases"][0]) is False
    out, notes = backfill_coding_questions(data, role="AI Engineer")
    coding = next(p for p in out["phases"] if p["id"] == "coding")
    assert coding.get("coding_question_ids"), "coding phase must get a question id"
    assert len(coding["coding_question_ids"]) == 1
    assert notes  # reported what it did
    # idempotent: a phase that already has ids is left alone
    out2, notes2 = backfill_coding_questions(out, role="AI Engineer")
    assert notes2 == []


def test_backfill_in_yaml_roundtrips_and_validates():
    import yaml as _yaml
    from app.cadence_service import backfill_coding_in_yaml
    from engine.brain.cadence.schema import CadencePlan
    src = (
        "total_duration_s: 120\n"
        "phases:\n"
        "  - id: warm_up\n    intent: warm up\n    duration_s: 60\n"
        "    question_mode: generic\n    generic_prompts: [\"Hi.\"]\n"
        "  - id: coding\n    intent: short coding exercise\n    duration_s: 60\n"
        "    question_mode: generic\n"
        "    generic_prompts: [\"The question is on screen; begin when ready.\"]\n"
    )
    out_yaml, notes = backfill_coding_in_yaml(src, role="Backend Engineer")
    assert notes
    plan = CadencePlan.model_validate(_yaml.safe_load(out_yaml))  # still valid
    coding = next(p for p in plan.phases if p.id == "coding")
    assert coding.coding_question_ids  # window will now open
