"""Phase 4: a crash (or a hand-off) costs one turn, not one phase.

A per-turn checkpoint lets a resumed interview continue from the candidate's
last answer. The trace/evaluation view must then keep every answer given before
the interruption — they are not asked again — and drop only what was in flight
(the AI reply being generated when the runner was lost).
"""
from __future__ import annotations

from app.resume_collapse import collapse_resumed_events


def _ev(event_kind, **payload):
    return {"kind": event_kind, "payload": payload}


def _kinds(events):
    return [(e["kind"], (e["payload"] or {}).get("text") or (e["payload"] or {}).get("seq") or "")
            for e in events]


def _interrupted_mid_phase(*, with_checkpoint_event=True):
    return [
        _ev("session_started", initial_phase="warm_up"),
        _ev("phase_changed", to_phase="technical"),
        _ev("stt_final", text="answer one"),
        _ev("ai_utterance", text="follow-up one"),
        _ev("stt_final", text="answer two"),
        *([_ev("checkpoint_written", kind="turn", seq="ck2")] if with_checkpoint_event else []),
        _ev("ai_utterance", text="reply cut short by the crash"),
        _ev("session_started", initial_phase="technical", resumed=True),
        _ev("session_resumed", phase_id="technical", mode="turn", checkpoint_seq="ck2"),
        _ev("ai_utterance", text="we're back - about answer two"),
        _ev("stt_final", text="answer three"),
    ]


def test_a_mid_phase_resume_keeps_every_answer_given_before_it():
    out = collapse_resumed_events(_interrupted_mid_phase())
    texts = [t for k, t in _kinds(out) if k in ("stt_final", "ai_utterance")]
    assert texts == ["answer one", "follow-up one", "answer two",
                     "we're back - about answer two", "answer three"]
    # The phantom second start is gone; the original start and the marker stay.
    assert [k for k, _ in _kinds(out)].count("session_started") == 1
    assert any(k == "session_resumed" for k, _ in _kinds(out))


def test_without_its_checkpoint_event_answers_are_kept_not_dropped():
    out = collapse_resumed_events(_interrupted_mid_phase(with_checkpoint_event=False))
    texts = [t for k, t in _kinds(out) if k == "stt_final"]
    assert texts == ["answer one", "answer two", "answer three"]
    assert [k for k, _ in _kinds(out)].count("session_started") == 1


def test_a_phase_level_resume_still_replaces_the_partial_phase():
    events = [
        _ev("session_started", initial_phase="warm_up"),
        _ev("phase_changed", to_phase="technical"),
        _ev("stt_final", text="partial answer"),
        _ev("session_started", initial_phase="technical", resumed=True),
        _ev("session_resumed", phase_id="technical"),   # no mode: the old kind
        _ev("stt_final", text="fresh answer"),
    ]
    texts = [t for k, t in _kinds(collapse_resumed_events(events)) if k == "stt_final"]
    assert texts == ["fresh answer"]


def test_coding_and_scenario_phases_never_take_turn_checkpoints():
    from engine.brain.core.director import _turn_checkpointable

    class P:
        def __init__(self, **kw):
            self.__dict__.update(kw)
    assert _turn_checkpointable(P(coding_question_ids=[], is_scenario_analysis=False))
    assert not _turn_checkpointable(P(coding_question_ids=["two_sum"]))
    assert not _turn_checkpointable(P(coding_question_ids=[], is_scenario_analysis=True))


async def _run_checkpoint(**kw):
    from engine.brain.runtime.interview_session import InterviewSession
    events, written = [], {}

    class _Tracer:
        def event(self, kind, **payload):  # same signature as the real tracer
            events.append((str(getattr(kind, "value", kind)), payload))

    async def writer(phase_id, turns, **fields):
        written.update(fields, phase_id=phase_id)
        return True
    s = type("S", (), {})()
    s._tracer, s._checkpoint_writer, s._elapsed_ms = _Tracer(), writer, (lambda: 4200)
    await InterviewSession._checkpoint(s, "technical", [], **kw)
    return events, written


def test_a_turn_checkpoint_is_recorded_with_the_seq_the_resume_will_name():
    # The collapse finds the checkpoint a resume continued from by this seq.
    # (A `kind=` field once collided with tracer.event's own first parameter;
    # the TypeError was swallowed and no checkpoint event was ever recorded.)
    import asyncio
    events, written = asyncio.run(_run_checkpoint(
        kind="turn", tracker={"current_phase_id": "technical"}, phase_elapsed_ms=61000))
    assert events and events[0][0] == "checkpoint_written"
    payload = events[0][1]
    assert payload["seq"] == written["seq"] and payload["checkpoint_kind"] == "turn"
    assert written["kind"] == "turn" and written["phase_elapsed_ms"] == 61000
    assert written["tracker"] == {"current_phase_id": "technical"}
