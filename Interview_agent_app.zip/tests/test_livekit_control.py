"""Phase 2: the page's control messages ride the LiveKit room's data channel.

What must hold, or a LiveKit interview silently breaks:
  * a message too big for one reliable packet (a coding question with its tests)
    arrives whole, in order;
  * the broadcaster treats the room exactly like a WebSocket client: the same
    catch-up messages on (re)attach, the same handling of start / end / acks;
  * audio never goes through the data channel (it has its own track);
  * the gateway forwards a start to the shard that owns the token, signed.
"""
from __future__ import annotations

import asyncio
import json

import pytest

from engine.orchestrator.livekit.transport import ControlReassembler, control_packets


# ── chunking ─────────────────────────────────────────────────────────────────
@pytest.mark.parametrize("size", [10, 1999, 2000, 2001, 45_000])
def test_any_size_message_arrives_whole(size):
    text = json.dumps({"type": "coding_phase_started", "prompt": "é✓" + "x" * size})
    packets = control_packets(text)
    assert all(len(p.encode()) <= 15_000 for p in packets), "each packet fits a reliable send"
    r = ControlReassembler()
    out = [r.feed(p) for p in packets]
    assert out[:-1] == [None] * (len(packets) - 1)
    assert out[-1] == text


def test_interleaved_messages_reassemble_independently():
    a = control_packets(json.dumps({"type": "a", "d": "a" * 5000}))
    b = control_packets(json.dumps({"type": "b", "d": "b" * 5000}))
    r = ControlReassembler()
    got = [x for x in (r.feed(p) for pair in zip(a, b) for p in pair) if x]
    assert sorted(json.loads(g)["type"] for g in got) == ["a", "b"]


def test_a_page_message_in_js_spacing_is_recognised():
    # JSON.stringify writes no spaces; Python's json.dumps does.
    r = ControlReassembler()
    assert r.feed('{"type":"__chunk","id":"x","i":0,"n":2,"d":"{\\"type\\":"}') is None
    assert r.feed('{"type":"__chunk","id":"x","i":1,"n":2,"d":"\\"end\\"}"}') == '{"type":"end"}'


# ── the broadcaster treats the room like a client ────────────────────────────
@pytest.fixture
def room():
    from engine.orchestrator.web.broadcaster import WebBroadcaster

    async def make():
        b = WebBroadcaster(host="(embedded)", port=0)
        sent: list[dict] = []

        async def send(text):
            sent.append(json.loads(text))
        b.attach_room(send, present=lambda identity=None: identity in (None, "candidate-tab1"))
        await b.start_embedded()
        return b, sent
    return make


@pytest.mark.asyncio
async def test_attach_brings_the_page_up_to_date(room):
    b, sent = await room()
    b.emit_phase("technical")
    b.set_media_transport("livekit")
    await b.flush()
    sent.clear()
    await b.handle_room_message(json.dumps({"type": "attach"}))
    types = [m["type"] for m in sent]
    assert types[0] == "hello"
    assert {"type": "phase_changed", "to_phase": "technical"} in sent
    assert {"type": "media_transport", "transport": "livekit"} in sent
    await b.stop()


@pytest.mark.asyncio
async def test_control_goes_out_through_the_room_audio_does_not(room):
    b, sent = await room()
    b.emit_audio_start("Hello", sub_id="s1")
    b.emit_pcm(b"\x01\x02" * 100)
    b.emit_audio_end(sub_id="s1")
    await b.flush()
    assert [m["type"] for m in sent] == ["audio_start", "audio_end"]
    await b.stop()


@pytest.mark.asyncio
async def test_start_end_and_acks_from_the_room_reach_the_session(room):
    b, _ = await room()
    acks = []

    async def on_ack(parsed):
        acks.append(parsed["sub_id"])
    b.set_audio_ack_callback(on_ack)
    await b.handle_room_message(json.dumps({"type": "start", "candidate": {"name": "Jane"}}))
    await b.handle_room_message(json.dumps({"type": "audio_playback_finished", "sub_id": "s1"}))
    await b.handle_room_message(json.dumps({"type": "end"}))
    await b.handle_room_message("not json")
    assert b.start_signal.is_set() and b.candidate_meta == {"name": "Jane"}
    assert acks == ["s1"]
    assert b.end_signal.is_set()
    await b.stop()


@pytest.mark.asyncio
async def test_presence_is_answered_per_tab(room):
    b, _ = await room()
    assert b.room_present() is True
    assert b.room_present("candidate-tab1") is True
    assert b.room_present("candidate-other") is False
    b.detach_room()
    assert b.room_present() is False
    await b.stop()


# ── placement: starts travel through Redis (Phase 3.2) ───────────────────────
@pytest.fixture
def redis(monkeypatch):
    import fakeredis.aioredis as fr
    from app import coordination as coord
    coord.set_redis(fr.FakeRedis(decode_responses=True))
    monkeypatch.setenv("SHARD_ID", "session-0")
    monkeypatch.setenv("SHARD_FQDN", "session-0:8080")
    yield
    coord.set_redis(None)


async def _replica(me, *, capacity=True, answers=None):
    """A replica's serve loop answering every start with its own name."""
    from app.session_tier import placement
    stop = asyncio.Event()
    seen = answers if answers is not None else []

    async def handle(token, body):
        seen.append((me, token, body))
        return 200, {"transport": "livekit", "by": me}
    task = asyncio.create_task(placement.serve(me, handle, has_capacity=lambda: capacity, stop=stop))
    await asyncio.sleep(0.05)  # publish its liveness key
    return stop, task, seen


async def _stop(stop, task):
    stop.set()
    await asyncio.wait_for(task, 5)


@pytest.mark.asyncio
async def test_a_new_interview_goes_to_whichever_replica_has_room(redis):
    from app.session_tier import placement
    stop, task, seen = await _replica("pool-a")
    status, body = await placement.request_room_start("tokA", {"client": "tab1"}, timeout_s=5)
    assert (status, body["by"]) == (200, "pool-a")
    assert seen == [("pool-a", "tokA", {"client": "tab1"})]
    await _stop(stop, task)


@pytest.mark.asyncio
async def test_a_rejoin_goes_to_the_owner_even_when_it_is_full(redis):
    from app.coordination import registry
    from app.session_tier import placement
    await registry.claim("tokA", "pool-b", "")
    a = await _replica("pool-a")                   # has room, but doesn't own it
    b = await _replica("pool-b", capacity=False)  # full, but owns it
    status, body = await placement.request_room_start("tokA", {}, timeout_s=5)
    assert body["by"] == "pool-b"
    await _stop(*a[:2]); await _stop(*b[:2])


@pytest.mark.asyncio
async def test_a_dead_owners_interview_goes_back_to_the_queue(redis):
    from app.coordination import registry
    from app.session_tier import placement
    await registry.claim("tokA", "pool-gone", "")  # no liveness key: crashed
    stop, task, _ = await _replica("pool-a")
    _, body = await placement.request_room_start("tokA", {}, timeout_s=5)
    assert body["by"] == "pool-a"
    await _stop(stop, task)


@pytest.mark.asyncio
async def test_nobody_answering_means_the_websocket(redis):
    from app.session_tier import placement
    status, body = await placement.request_room_start("tokA", {}, timeout_s=1)
    assert (status, body) == (200, {"transport": "websocket"})


@pytest.mark.asyncio
async def test_a_start_the_gateway_gave_up_on_is_never_run_late(redis):
    from app.coordination.client import get_redis
    from app.session_tier import placement
    await get_redis().rpush(placement.SHARED_QUEUE, json.dumps(
        {"id": "x", "token": "tokA", "body": {}, "deadline": 1.0}))
    stop, task, seen = await _replica("pool-a")
    await asyncio.sleep(0.3)
    assert seen == []
    await _stop(stop, task)


@pytest.mark.asyncio
async def test_claim_takes_over_only_a_dead_and_fenced_owner(redis, monkeypatch):
    from app.coordination import registry
    from app.coordination.client import get_redis
    from app.session_tier import lifecycle, placement
    monkeypatch.setenv("AZURE_SPEECH_KEYS", "k1")
    monkeypatch.setenv("SPEECH_STREAMS_PER_KEY", "5")
    # Fenced owner that is alive: refused.
    await registry.claim("tokA", "session-1", "session-1:8080")
    await get_redis().set("place:alive:session-1", "1", ex=10)
    assert (await lifecycle.claim("tokA")).reason == "owned_elsewhere"
    # ...the same owner dead: taken over with a newer fence.
    await get_redis().delete("place:alive:session-1")
    c = await lifecycle.claim("tokA")
    assert c.ok and (await registry.get("tokA")).shard == "session-0"
    # An entry from pre-fencing code (fence 0) is never taken over: that
    # replica publishes no liveness key and is probably alive.
    await get_redis().set(registry._key("tokB"), json.dumps(
        {"shard": "session-1", "fqdn": "s1", "created_at": 0}), ex=60)
    assert (await lifecycle.claim("tokB")).reason == "owned_elsewhere"


@pytest.mark.asyncio
async def test_gateway_start_goes_through_placement(redis, monkeypatch):
    pytest.importorskip("deploy.gateway_app")
    from deploy import gateway_app
    monkeypatch.setenv("MEDIA_TRANSPORT", "livekit")
    stop, task, seen = await _replica("pool-a")

    class _Req:
        async def json(self):
            return {"client": "tab1"}
    r = await gateway_app._candidate_room_start("tokA", _Req())
    assert r.status_code == 200 and json.loads(r.body)["by"] == "pool-a"
    monkeypatch.setenv("MEDIA_TRANSPORT", "websocket")
    r = await gateway_app._candidate_room_start("tokA", _Req())
    assert json.loads(r.body) == {"transport": "websocket"}, "switch off: no placement at all"
    await _stop(stop, task)
