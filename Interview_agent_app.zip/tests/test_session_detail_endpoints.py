"""Tests for the JSON session-detail endpoints used by the React SPA.

Run with: .venv/bin/python -m pytest tests/test_session_detail_endpoints.py -v

Coverage:
  - GET  /api/sessions/{t}/detail   — auth gate, 404, full view-model shape
  - POST /api/sessions/{t}/evaluate — auth gate, 404, returns generated eval
                                       (generate_evaluation is monkeypatched —
                                       no real LLM call)
"""
from __future__ import annotations

import pytest


@pytest.fixture
def clients(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    from fastapi.testclient import TestClient
    from app import auth, db, main

    db.init_db()
    authed = TestClient(main.app)
    authed.cookies.set(auth.COOKIE_NAME, auth.issue_cookie("test_admin"))
    anon = TestClient(main.app)
    return authed, anon


def _seed(token: str, status: str = "completed") -> str:
    from app import db

    if db.get(token) is None:
        db.insert({
            "token": token,
            "candidate_name": "Detail Test",
            "role": "AI Engineer",
            "jd_text": "Builds LLM systems.",
            "resume_path": "resume.pdf",
            "cadence_yaml": "total_duration_s: 60\nphases: []\n",
            "status": status,
            "created_at": db.now_iso(),
        })
    return token


# ── GET /api/sessions/{token}/detail ─────────────────────────────────────────


def test_detail_requires_auth(clients):
    _, anon = clients
    assert anon.get("/api/sessions/x/detail").status_code == 401


def test_detail_404_when_missing(clients):
    authed, _ = clients
    assert authed.get("/api/sessions/no-such/detail").status_code == 404


def test_detail_shape(clients):
    from app import db

    authed, _ = clients
    token = _seed("detailtest-shape")
    try:
        r = authed.get(f"/api/sessions/{token}/detail")
        assert r.status_code == 200, r.text
        d = r.json()
        # the full view-model the React page renders
        expected = {
            "row", "events", "summary", "evaluation", "candidate_link_base",
            "phases", "totals", "per_model", "coding_perf", "rubric_by_phase",
            "eval_used_rubric", "rubric_changed",
        }
        assert expected <= set(d)
        assert d["row"]["token"] == token
        # no events.jsonl on disk → empty timeline, evaluation absent
        assert d["events"] == []
        assert d["phases"] == []
        assert d["evaluation"] is None
        assert d["eval_used_rubric"] is False
    finally:
        db.delete(token)


# ── POST /api/sessions/{token}/evaluate ──────────────────────────────────────


def test_evaluate_requires_auth(clients):
    _, anon = clients
    assert anon.post("/api/sessions/x/evaluate").status_code == 401


def test_evaluate_404_when_missing(clients):
    authed, _ = clients
    assert authed.post("/api/sessions/no-such/evaluate").status_code == 404


def test_evaluate_returns_generated(clients, monkeypatch):
    from app import db, main

    fake_eval = {
        "generated_at": "2026-06-12T00:00:00Z",
        "model": "test-model",
        "overall": {"score": 72, "band": "good", "headline": "Solid", "summary": "ok"},
        "dimensions": {"technical_depth": {"score": 7, "rationale": "fine"}},
        "phases": [{"id": "p1", "name": "Warm up", "score": 7, "summary": "x", "questions": []}],
        "strengths": [{"title": "S", "detail": "d"}],
        "weaknesses": [],
    }

    async def _fake_generate(token, **kwargs):
        return fake_eval

    monkeypatch.setattr(main, "generate_evaluation", _fake_generate)

    authed, _ = clients
    token = _seed("detailtest-eval")
    try:
        r = authed.post(f"/api/sessions/{token}/evaluate")
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["ok"] is True
        assert body["evaluation"]["overall"]["score"] == 72
    finally:
        db.delete(token)
