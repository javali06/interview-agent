"""Shared db/ layer + admin.db migration onto it.

Verifies the admin session store behaves identically after moving from raw
sqlite3 to SQLAlchemy, and that the shared schema (roles/candidates/etc.)
co-creates in the same database. Runs entirely on a throwaway SQLite file.

Run: .venv/bin/python -m pytest tests/test_db_layer.py -v
"""
from __future__ import annotations

import pytest
from sqlalchemy import inspect


@pytest.fixture
def fresh_db(tmp_path):
    """Point the shared engine at a throwaway sqlite file and create tables."""
    from db import engine as db_engine

    url = f"sqlite:///{tmp_path / 'test.db'}"
    db_engine.reset_engine(url)
    db_engine.create_all()
    yield url
    db_engine.reset_engine(None)  # restore default for other tests


def _row(token="tok-1", status="ready"):
    from app import db
    return {
        "token": token, "candidate_name": "Test", "role": "Senior AI Engineer",
        "resume_path": "r.pdf", "cadence_yaml": "phases: []",
        "status": status, "created_at": db.now_iso(),
    }


def test_shared_tables_all_created(fresh_db):
    names = set(inspect(__import__("db").get_engine()).get_table_names())
    assert {"sessions", "roles", "candidates", "job_descriptions",
            "scores", "score_dimensions"}.issubset(names)


def test_session_crud_round_trip(fresh_db):
    from app import db

    db.insert(_row("tok-1", "ready"))
    got = db.get("tok-1")
    assert got is not None
    # row["col"] dict access still works (sqlite3.Row compatibility)
    assert got["candidate_name"] == "Test"
    assert got["status"] == "ready"

    # has_active_session sees 'ready'
    active = db.has_active_session()
    assert active is not None and active["token"] == "tok-1"

    # update
    db.update("tok-1", status="in_progress", pid=4242)
    assert db.get("tok-1")["pid"] == 4242

    # list_recent
    db.insert(_row("tok-2", "completed"))
    tokens = {r["token"] for r in db.list_recent(10)}
    assert tokens == {"tok-1", "tok-2"}

    # archive → no longer active, still present
    db.archive("tok-1")
    assert db.get("tok-1")["status"] == "cancelled"
    assert db.has_active_session() is None

    # delete
    db.delete("tok-2")
    assert db.get("tok-2") is None


def test_database_url_respects_env(monkeypatch):
    from db import engine as db_engine

    monkeypatch.setenv("DATABASE_URL", "postgresql+psycopg://h/db")
    assert db_engine.database_url() == "postgresql+psycopg://h/db"
    monkeypatch.delenv("DATABASE_URL", raising=False)
    # default falls back to the local sqlite sessions.db
    assert db_engine.database_url().startswith("sqlite:///")
    assert db_engine.database_url().endswith("sessions.db")
