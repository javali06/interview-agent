"""Session-tier lifecycle tests: claim/release/heartbeat over the coord plane
+ broker, all fakeredis-backed. No Azure, no live interview."""
from __future__ import annotations

import asyncio

import pytest

from app import coordination as coord
from app.coordination import admission, registry
from app.session_tier import identity, lifecycle


@pytest.fixture()
def env(monkeypatch):
    import fakeredis.aioredis as fr
    coord.set_redis(fr.FakeRedis(decode_responses=True))
    monkeypatch.setenv("SHARD_ID", "session-0")
    monkeypatch.setenv("SHARD_FQDN", "session-0.internal:8080")
    monkeypatch.setenv("AZURE_SPEECH_KEYS", "k1,k2")
    monkeypatch.setenv("SPEECH_STREAMS_PER_KEY", "5")
    monkeypatch.delenv("MAX_ACTIVE_SESSIONS", raising=False)
    yield
    coord.set_redis(None)


@pytest.mark.asyncio
async def test_claim_success_registers_and_admits(env):
    c = await lifecycle.claim("tokA")
    assert c.ok
    assert c.stt is not None and c.stt.provider == "azure"

    loc = await registry.get("tokA")
    assert loc is not None and loc.shard == "session-0"
    assert loc.fqdn == "session-0.internal:8080"
    assert await admission.value(admission.ACTIVE_SESSIONS) == 1
    assert await admission.value(admission.shard_counter("session-0")) == 1


@pytest.mark.asyncio
async def test_claim_adopts_a_token_left_by_a_dead_runner_on_this_shard(env):
    # This shard restarted mid-interview; the candidate reconnects before the
    # registry entry expires. The new runner needs its OWN Speech lease — the
    # old one died with the old process (it used to get none and crash).
    await lifecycle.claim("tokA")
    again = await lifecycle.claim("tokA")
    assert again.ok and again.stt is not None and again.stt.provider == "azure"
    # Still exactly one session admitted: the dead runner's slots are reused.
    assert await admission.value(admission.ACTIVE_SESSIONS) == 1
    assert await admission.value(admission.shard_counter("session-0")) == 1
    # The registry now points at the NEW lease's key.
    loc = await registry.get("tokA")
    assert loc.speech_key == again.stt.speech.speech_key.key_id


@pytest.mark.asyncio
async def test_claim_owned_elsewhere(env):
    # Pretend another shard already owns the token — and is alive.
    await registry.claim("tokB", shard="session-9", fqdn="session-9.internal:8080")
    await coord.get_redis().set("place:alive:session-9", "1", ex=10)
    c = await lifecycle.claim("tokB")
    assert not c.ok and c.reason == "owned_elsewhere"
    assert c.location is not None and c.location.shard == "session-9"


@pytest.mark.asyncio
async def test_claim_at_capacity(env, monkeypatch):
    monkeypatch.setenv("MAX_ACTIVE_SESSIONS", "1")
    a = await lifecycle.claim("tok1")
    assert a.ok
    b = await lifecycle.claim("tok2")
    assert not b.ok and b.reason == "at_capacity"
    # The rejected claim left no residue.
    assert await registry.get("tok2") is None
    assert await admission.value(admission.ACTIVE_SESSIONS) == 1


@pytest.mark.asyncio
async def test_claim_shard_at_capacity(env, monkeypatch):
    # Per-shard cap enforced (SHARD_MAX_SESSIONS) — the second claim on the same
    # full shard is rejected rather than piled onto one event loop.
    monkeypatch.setenv("SHARD_MAX_SESSIONS", "1")
    a = await lifecycle.claim("tok1")
    assert a.ok
    b = await lifecycle.claim("tok2")
    assert not b.ok and b.reason == "shard_at_capacity"
    # The rejected claim rolled back BOTH counters and left no registry residue.
    assert await registry.get("tok2") is None
    assert await admission.value(admission.ACTIVE_SESSIONS) == 1
    assert await admission.value(admission.shard_counter("session-0")) == 1


@pytest.mark.asyncio
async def test_claim_no_speech_capacity_rolls_back(env, monkeypatch):
    monkeypatch.setenv("AZURE_SPEECH_KEYS", "solo")
    monkeypatch.setenv("SPEECH_STREAMS_PER_KEY", "1")
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    a = await lifecycle.claim("tok1")   # takes the only Azure slot
    assert a.ok
    b = await lifecycle.claim("tok2")   # pool full, no Groq
    assert not b.ok and b.reason == "no_speech_capacity"
    # active_sessions rolled back to just the first.
    assert await admission.value(admission.ACTIVE_SESSIONS) == 1
    assert await registry.get("tok2") is None


@pytest.mark.asyncio
async def test_release_frees_everything(env):
    c = await lifecycle.claim("tokA")
    await lifecycle.release("tokA", c)
    assert await registry.get("tokA") is None
    assert await admission.value(admission.ACTIVE_SESSIONS) == 0
    assert await admission.value(admission.shard_counter("session-0")) == 0
    # Speech slot returned to the pool.
    assert await admission.value(admission.speech_key_counter(c.stt.speech.speech_key.key_id)) == 0


@pytest.mark.asyncio
async def test_release_after_adopt_frees_everything(env):
    await lifecycle.claim("tokA")          # the dead runner's claim, never released
    adopted = await lifecycle.claim("tokA")
    await lifecycle.release("tokA", adopted)
    assert await registry.get("tokA") is None
    assert await admission.value(admission.ACTIVE_SESSIONS) == 0
    assert await admission.value(admission.shard_counter("session-0")) == 0


@pytest.mark.asyncio
async def test_heartbeat_restores_an_entry_redis_lost(env):
    c = await lifecycle.claim("tokA")
    await registry.release("tokA")  # simulate eviction/expiry
    assert await registry.get("tokA") is None

    stop = asyncio.Event()
    task = asyncio.create_task(
        lifecycle.heartbeat_loop("tokA", stop, interval_s=0.01, lease=c.lease)
    )
    await asyncio.sleep(0.05)  # let a beat fire and restore ownership
    stop.set()
    await asyncio.wait_for(task, timeout=2.0)
    loc = await registry.get("tokA")
    assert loc is not None and loc.shard == "session-0" and loc.fence == c.lease.fence


@pytest.mark.asyncio
async def test_heartbeat_stops_the_interview_when_another_replica_took_it(env):
    c = await lifecycle.claim("tokA")
    await registry.claim("tokA", "session-1", "session-1.internal:8080")  # taken over
    lost = asyncio.Event()
    task = asyncio.create_task(lifecycle.heartbeat_loop(
        "tokA", asyncio.Event(), interval_s=0.01, lease=c.lease, on_lost=lost.set))
    await asyncio.wait_for(lost.wait(), timeout=2.0)
    await asyncio.wait_for(task, timeout=2.0)  # and it stops renewing
    assert (await registry.get("tokA")).shard == "session-1", "never re-takes it"
    # Its teardown gives back its own slots without touching the new owner's entry.
    await lifecycle.release("tokA", c)
    assert (await registry.get("tokA")).shard == "session-1"


@pytest.mark.asyncio
async def test_heartbeat_stops_promptly(env):
    await lifecycle.claim("tokA")
    stop = asyncio.Event()
    task = asyncio.create_task(lifecycle.heartbeat_loop("tokA", stop, interval_s=30))
    stop.set()  # should return without waiting the full interval
    await asyncio.wait_for(task, timeout=1.0)
