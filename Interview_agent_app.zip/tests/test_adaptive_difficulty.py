"""Unit tests for adaptive (dynamic) difficulty.

Covers the pure rubric functions, the dynamic-populated-ladder selection in
`AdaptivePoolState`, and a CadenceTracker integration drive. Written to run
either under pytest OR directly as a script (`python tests/test_adaptive_difficulty.py`)
since pytest isn't always installed in the runtime venv.
"""
from __future__ import annotations

from engine.brain.cadence.schema import CadencePlan
from engine.brain.core.adaptive import (
    AdaptiveConfig,
    Outcome,
    build_adaptive_pool,
    classify_outcome,
    decide_level_delta,
)
from engine.brain.core.cadence_tracker import CadenceTracker, TickDecision


CFG = AdaptiveConfig()


# ── classify_outcome ─────────────────────────────────────────────────────────


def test_classify_outcome():
    assert classify_outcome("answered", 0, CFG) is Outcome.FIRST_TRY
    assert classify_outcome("answered", 1, CFG) is Outcome.RECOVERED
    assert classify_outcome("answered", 3, CFG) is Outcome.RECOVERED
    assert classify_outcome("partial_answer_skip", 1, CFG) is Outcome.FAILED
    # default_answered is neutral by default (verifier outage must not escalate)
    assert classify_outcome("default_answered", 0, CFG) is Outcome.NEUTRAL
    # ...unless the operator opts out
    opt_out = AdaptiveConfig(neutral_on_default_answered=False)
    assert classify_outcome("default_answered", 0, opt_out) is Outcome.FIRST_TRY
    assert classify_outcome("default_answered", 2, opt_out) is Outcome.RECOVERED
    # unexpected intents never move difficulty
    assert classify_outcome("off_topic", 0, CFG) is Outcome.NEUTRAL


# ── decide_level_delta ───────────────────────────────────────────────────────


def test_decide_level_delta_first_try_escalates():
    assert decide_level_delta(Outcome.FIRST_TRY, 0, CFG) == (1, 0)


def test_decide_level_delta_recovered_streak():
    # one recovery → hold, streak=1
    assert decide_level_delta(Outcome.RECOVERED, 0, CFG) == (0, 1)
    # second consecutive recovery → escalate, streak resets
    assert decide_level_delta(Outcome.RECOVERED, 1, CFG) == (1, 0)


def test_decide_level_delta_failed_deescalates():
    assert decide_level_delta(Outcome.FAILED, 0, CFG) == (-1, 0)
    assert decide_level_delta(Outcome.FAILED, 1, CFG) == (-1, 0)  # resets streak


def test_decide_level_delta_neutral_holds():
    assert decide_level_delta(Outcome.NEUTRAL, 2, CFG) == (0, 2)


def test_decide_level_delta_config_off():
    off = AdaptiveConfig(escalate_on_first_try=False, deescalate_on_skip=False)
    assert decide_level_delta(Outcome.FIRST_TRY, 0, off) == (0, 0)
    assert decide_level_delta(Outcome.FAILED, 0, off) == (0, 0)


# ── AdaptivePoolState selection helpers ──────────────────────────────────────


def _pool(difficulties, cfg=CFG):
    return build_adaptive_pool(phase_id="p", difficulties=difficulties, cfg=cfg)


def _head_difficulty(pool, difficulties):
    idx = pool.head_index()
    return None if idx is None else difficulties[idx]


def test_build_adaptive_pool_levels_and_start():
    diffs = ["hard", "easy", "medium", "easy"]
    pool = _pool(diffs)
    assert pool.levels == ["easy", "medium", "hard"]  # canonical order
    assert pool.remaining_by_level == {"easy": [1, 3], "medium": [2], "hard": [0]}
    assert pool.current_level == "easy"  # default start


def test_start_clamps_to_lowest_present():
    # no easy present, start defaults to 'easy' → clamp to lowest present (medium)
    pool = _pool(["medium", "hard"])
    assert pool.current_level == "medium"


def test_explicit_start_difficulty():
    pool = _pool(["easy", "medium", "hard"], AdaptiveConfig(start_difficulty="medium"))
    assert pool.current_level == "medium"


def test_no_repeat_and_first_try_escalates():
    diffs = ["easy", "easy", "medium", "hard"]
    pool = _pool(diffs)
    assert _head_difficulty(pool, diffs) == "easy"
    idx0 = pool.pop_and_advance(Outcome.FIRST_TRY)
    assert idx0 == 0
    # FIRST_TRY escalates → next is medium (skips the 2nd easy)
    assert pool.current_level == "medium"
    assert pool.last_transition == "escalated"
    assert _head_difficulty(pool, diffs) == "medium"
    # consumed index is gone; never offered again
    assert 0 not in pool.remaining_by_level["easy"]


def test_floor_clamp_constant_deescalation():
    # All easy: repeatedly failing can't go below the easiest bucket.
    diffs = ["easy", "easy", "easy"]
    pool = _pool(diffs)
    for _ in range(3):
        assert _head_difficulty(pool, diffs) == "easy" or pool.head_index() is None
        idx = pool.pop_and_advance(Outcome.FAILED)
        if idx is None:
            break
        assert pool.current_level == "easy"  # never drops below floor
        assert pool.last_transition in ("stayed", "exhausted")


def test_ceiling_clamp_constant_escalation():
    diffs = ["hard", "hard"]
    pool = _pool(diffs)
    pool.pop_and_advance(Outcome.FIRST_TRY)
    # already at the top populated level → stays hard
    assert pool.current_level == "hard"
    assert pool.last_transition in ("stayed", "exhausted")


def test_exhaustion_snap_up_makes_medium_the_floor():
    # easy drains → climb to medium; medium becomes the new floor so a later
    # de-escalation can't drop back to (empty) easy.
    diffs = ["easy", "medium", "medium", "hard"]
    pool = _pool(diffs)
    # answer the only easy first-try → escalate to medium (easy now empty)
    pool.pop_and_advance(Outcome.FIRST_TRY)
    assert pool.current_level == "medium"
    assert pool.remaining_by_level["easy"] == []
    # now fail at medium → would de-escalate, but easy is drained → floor=medium
    assert _head_difficulty(pool, diffs) == "medium"
    pool.pop_and_advance(Outcome.FAILED)
    assert pool.current_level == "medium"  # clamped at the new floor, not easy
    assert _head_difficulty(pool, diffs) == "medium"


def test_highest_drained_ends_even_if_lower_remains():
    # 2 easy + 1 hard. Climb to hard, drain it → phase should END (head None)
    # even though an easy question is still sitting unused.
    diffs = ["easy", "easy", "hard"]
    pool = _pool(diffs)
    assert pool.levels == ["easy", "hard"]
    pool.pop_and_advance(Outcome.FIRST_TRY)  # easy[0] → escalate to hard
    assert pool.current_level == "hard"
    assert _head_difficulty(pool, diffs) == "hard"
    pool.pop_and_advance(Outcome.FIRST_TRY)  # drain hard
    # Highest reachable level drained → nothing drawable, even though easy[1] left
    assert pool.head_index() is None
    assert pool.last_transition == "exhausted"
    assert pool.remaining_by_level["easy"] == [1]  # the leftover easy is unused


def test_gaps_skip_absent_levels():
    # No medium present at all → escalate jumps easy→hard.
    diffs = ["easy", "hard"]
    pool = _pool(diffs)
    pool.pop_and_advance(Outcome.FIRST_TRY)
    assert pool.current_level == "hard"


def test_full_drain_returns_none():
    diffs = ["easy"]
    pool = _pool(diffs)
    assert pool.pop_and_advance(Outcome.FIRST_TRY) == 0
    assert pool.head_index() is None
    assert pool.pop_and_advance(Outcome.FIRST_TRY) is None


# ── CadenceTracker integration ───────────────────────────────────────────────


def _adaptive_plan():
    return CadencePlan.model_validate({
        "total_duration_s": 100,
        "phases": [{
            "id": "tech",
            "duration_s": 100,
            "intent": "probe depth",
            "question_mode": "specific",
            "adaptive_difficulty": True,
            "question_pool": [
                {"id": "e1", "text": "easy one", "difficulty": "easy"},
                {"id": "e2", "text": "easy two", "difficulty": "easy"},
                {"id": "m1", "text": "medium one", "difficulty": "medium"},
                {"id": "h1", "text": "hard one", "difficulty": "hard"},
            ],
        }],
    })


def test_tracker_adaptive_climb_and_end():
    plan = _adaptive_plan()
    tracker = CadenceTracker(plan, now_ms_provider=lambda: 0)
    assert tracker.is_adaptive_phase()

    # First question is easy.
    q = tracker.peek_next_question()
    assert q.id == "e1" and q.difficulty == "easy"

    # Answer first-try → escalate to medium (skips e2).
    popped = tracker.pick_next_question(outcome=Outcome.FIRST_TRY)
    assert popped.id == "e1"
    q = tracker.peek_next_question()
    assert q.difficulty == "medium" and q.id == "m1"

    # Answer medium first-try → escalate to hard.
    tracker.pick_next_question(outcome=Outcome.FIRST_TRY)
    q = tracker.peek_next_question()
    assert q.difficulty == "hard" and q.id == "h1"

    # Drain hard → no more drawable (e2 left unused) → phase ends.
    tracker.pick_next_question(outcome=Outcome.FIRST_TRY)
    assert tracker.peek_next_question() is None
    assert tracker.check_phase_budget() is TickDecision.END  # terminal phase


def test_tracker_static_phase_unchanged():
    # A specific phase WITHOUT adaptive_difficulty keeps plain FIFO behaviour
    # and ignores the outcome arg.
    plan = CadencePlan.model_validate({
        "total_duration_s": 50,
        "phases": [{
            "id": "tech",
            "duration_s": 50,
            "intent": "x",
            "question_mode": "specific",
            "question_pool": [
                {"id": "q1", "text": "one"},
                {"id": "q2", "text": "two"},
            ],
        }],
    })
    tracker = CadenceTracker(plan, now_ms_provider=lambda: 0)
    assert not tracker.is_adaptive_phase()
    assert tracker.peek_next_question().id == "q1"
    assert tracker.pick_next_question(outcome=Outcome.FAILED).id == "q1"  # outcome ignored
    assert tracker.peek_next_question().id == "q2"
    tracker.pick_next_question()
    assert tracker.peek_next_question() is None


# ── script runner (so we can run without pytest installed) ───────────────────

if __name__ == "__main__":
    import traceback

    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for fn in fns:
        try:
            fn()
            print(f"PASS {fn.__name__}")
        except Exception:
            failed += 1
            print(f"FAIL {fn.__name__}")
            traceback.print_exc()
    print(f"\n{len(fns) - failed}/{len(fns)} passed")
    raise SystemExit(1 if failed else 0)
