"""Tests for the schedule JSON twins used by the React SPA.

Run with: .venv/bin/python -m pytest tests/test_schedule_endpoints.py -v

Coverage:
  - GET  /api/schedule/{t}/edit  — auth gate, 404, 409 (already started), prefill
  - POST /api/schedule           — auth gate, validation (name/role/resume),
                                    create + edit success (create_draft /
                                    update_draft monkeypatched — no file I/O
                                    or LLM cadence generation)
"""
from __future__ import annotations

import pytest


@pytest.fixture
def clients(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    from fastapi.testclient import TestClient
    from app import auth, db, main

    db.init_db()
    authed = TestClient(main.app)
    authed.cookies.set(auth.COOKIE_NAME, auth.issue_cookie("test_admin"))
    anon = TestClient(main.app)
    return authed, anon


def _seed(token: str, status: str = "draft") -> str:
    from app import db

    if db.get(token) is None:
        db.insert({
            "token": token,
            "candidate_name": "Sched Test",
            "role": "AI Engineer",
            "jd_text": "Builds LLM systems.",
            "resume_path": f"sessions/{token}/resume.pdf",
            "cadence_yaml": "phases: []\n",
            "status": status,
            "created_at": db.now_iso(),
        })
    return token


# ── GET /api/schedule/{token}/edit ───────────────────────────────────────────


def test_edit_requires_auth(clients):
    _, anon = clients
    assert anon.get("/api/schedule/x/edit").status_code == 401


def test_edit_404(clients):
    authed, _ = clients
    assert authed.get("/api/schedule/no-such/edit").status_code == 404


def test_edit_409_when_started(clients):
    from app import db

    authed, _ = clients
    token = _seed("schedtest-prog", status="in_progress")
    try:
        assert authed.get(f"/api/schedule/{token}/edit").status_code == 409
    finally:
        db.delete(token)


def test_edit_prefill_shape(clients):
    from app import db

    authed, _ = clients
    token = _seed("schedtest-edit")
    try:
        r = authed.get(f"/api/schedule/{token}/edit")
        assert r.status_code == 200, r.text
        d = r.json()
        assert d["candidate_name"] == "Sched Test"
        assert d["role"] == "AI Engineer"
        assert d["resume_filename"] == "resume.pdf"  # basename of the stored path
    finally:
        db.delete(token)


# ── POST /api/schedule ───────────────────────────────────────────────────────


def test_submit_requires_auth(clients):
    _, anon = clients
    r = anon.post("/api/schedule", data={"candidate_name": "A", "role": "B"})
    assert r.status_code == 401


def test_submit_missing_role_400(clients):
    # multipart (the form's real content-type); role blank -> name/role check
    authed, _ = clients
    r = authed.post(
        "/api/schedule",
        data={"candidate_name": "A", "role": "   "},  # whitespace -> Form accepts, handler .strip() rejects
        files={"resume_upload": ("r.txt", b"x", "text/plain")},
    )
    assert r.status_code == 400
    assert "required" in r.json()["error"]


def test_submit_create_without_resume_400(clients):
    # multipart but no resume file -> resume-required check
    authed, _ = clients
    r = authed.post(
        "/api/schedule",
        data={"candidate_name": "A", "role": "AI Engineer"},
        files={"jd_upload": ("jd.txt", b"x", "text/plain")},
    )
    assert r.status_code == 400
    assert "Resume" in r.json()["error"]


def test_submit_create_success(clients, monkeypatch):
    from app import main

    async def _fake_create(form):
        assert form.candidate_name == "Jane"
        return ("tok-created", "phases: []\n")

    monkeypatch.setattr(main.sessions, "create_draft", _fake_create)

    authed, _ = clients
    r = authed.post(
        "/api/schedule",
        data={"candidate_name": "Jane", "role": "AI Engineer"},
        files={"resume_upload": ("resume.txt", b"Jane Doe\nAI Engineer\n", "text/plain")},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["ok"] is True
    assert body["token"] == "tok-created"


def test_submit_edit_success(clients, monkeypatch):
    from app import db, main

    async def _fake_update(token, form, regenerate_cadence=False):
        return None

    monkeypatch.setattr(main.sessions, "update_draft", _fake_update)

    authed, _ = clients
    token = _seed("schedtest-update")
    try:
        r = authed.post(
            "/api/schedule",
            data={"candidate_name": "Sched Test", "role": "AI Engineer", "token": token},
        )
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["ok"] is True
        assert body["token"] == token
    finally:
        db.delete(token)
