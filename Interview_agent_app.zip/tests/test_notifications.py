"""Tests for app/notifications — the candidate invite email.

Template building is pure (no I/O) and tested directly. Sending is tested
against a fake aiosmtplib.send (no real network / mailbox needed) plus the
EmailNotConfigured no-op path.
"""
from __future__ import annotations

import os

import pytest

from app.notifications import email_client
from app.notifications.templates import build_invite_email, build_subject


def test_build_subject():
    assert build_subject("Senior AI Engineer") == "Your Senior AI Engineer interview is ready"


def test_build_invite_email_contains_link_name_and_role():
    subject, html = build_invite_email(
        "Priya Rao", "Senior AI Engineer", "https://example.com/app/candidate?token=abc123",
    )
    assert subject == "Your Senior AI Engineer interview is ready"
    assert "https://example.com/app/candidate?token=abc123" in html
    assert "Priya Rao" in html
    assert "Senior AI Engineer" in html
    assert "Start your interview" in html


def test_build_invite_email_escapes_html():
    # A candidate/role field containing HTML-significant characters must not
    # inject markup into the email — this is the whole point of the escape().
    _subject, html = build_invite_email(
        "<script>alert(1)</script>", "R&D", "https://example.com/x",
    )
    assert "<script>" not in html
    assert "&lt;script&gt;" in html
    assert "R&amp;D" in html


def test_is_configured_false_when_env_blank(monkeypatch):
    monkeypatch.delenv("SMTP_HOST", raising=False)
    monkeypatch.delenv("SMTP_FROM_ADDRESS", raising=False)
    assert email_client.is_configured() is False


def test_is_configured_true_when_env_set(monkeypatch):
    monkeypatch.setenv("SMTP_HOST", "smtp.example.com")
    monkeypatch.setenv("SMTP_FROM_ADDRESS", "invites@example.com")
    assert email_client.is_configured() is True


@pytest.mark.asyncio
async def test_send_email_raises_not_configured_when_blank(monkeypatch):
    monkeypatch.delenv("SMTP_HOST", raising=False)
    monkeypatch.delenv("SMTP_FROM_ADDRESS", raising=False)
    with pytest.raises(email_client.EmailNotConfigured):
        await email_client.send_email("candidate@example.com", "subject", "<p>hi</p>")


@pytest.mark.asyncio
async def test_send_email_calls_aiosmtplib_with_expected_args(monkeypatch):
    monkeypatch.setenv("SMTP_HOST", "smtp.example.com")
    monkeypatch.setenv("SMTP_PORT", "587")
    monkeypatch.setenv("SMTP_USERNAME", "invites@example.com")
    monkeypatch.setenv("SMTP_PASSWORD", "secret")
    monkeypatch.setenv("SMTP_FROM_ADDRESS", "invites@example.com")
    monkeypatch.setenv("SMTP_USE_TLS", "true")

    calls = {}

    async def fake_send(message, **kwargs):
        calls["message"] = message
        calls["kwargs"] = kwargs

    monkeypatch.setattr(email_client.aiosmtplib, "send", fake_send)

    await email_client.send_email("candidate@example.com", "Your interview is ready", "<p>hi</p>")

    assert calls["kwargs"]["hostname"] == "smtp.example.com"
    assert calls["kwargs"]["port"] == 587
    assert calls["kwargs"]["username"] == "invites@example.com"
    assert calls["kwargs"]["password"] == "secret"
    # 587 -> STARTTLS, not implicit TLS.
    assert calls["kwargs"]["use_tls"] is False
    assert calls["kwargs"]["start_tls"] is True
    assert calls["message"]["To"] == "candidate@example.com"
    assert calls["message"]["From"] == "invites@example.com"
    assert calls["message"]["Subject"] == "Your interview is ready"


@pytest.mark.asyncio
async def test_send_email_implicit_tls_on_port_465(monkeypatch):
    monkeypatch.setenv("SMTP_HOST", "smtp.example.com")
    monkeypatch.setenv("SMTP_PORT", "465")
    monkeypatch.setenv("SMTP_FROM_ADDRESS", "invites@example.com")

    calls = {}

    async def fake_send(message, **kwargs):
        calls["kwargs"] = kwargs

    monkeypatch.setattr(email_client.aiosmtplib, "send", fake_send)

    await email_client.send_email("candidate@example.com", "s", "<p>hi</p>")

    assert calls["kwargs"]["use_tls"] is True
    assert calls["kwargs"]["start_tls"] is False


@pytest.mark.asyncio
async def test_invite_dispatch_skips_when_not_configured(monkeypatch):
    """The job handler itself must not raise/dead-letter just because a dev
    box has no mailbox configured — it should report a clean skip."""
    monkeypatch.delenv("SMTP_HOST", raising=False)
    monkeypatch.delenv("SMTP_FROM_ADDRESS", raising=False)

    from app.jobs.jobs import _invite_dispatch

    result = await _invite_dispatch({
        "token": "abc123",
        "to": "candidate@example.com",
        "candidate_name": "Priya Rao",
        "role": "Senior AI Engineer",
        "link": "https://example.com/app/candidate?token=abc123",
    })
    assert result == {"token": "abc123", "sent": False, "reason": "not_configured"}


@pytest.mark.asyncio
async def test_invite_dispatch_sends_when_configured(monkeypatch):
    monkeypatch.setenv("SMTP_HOST", "smtp.example.com")
    monkeypatch.setenv("SMTP_FROM_ADDRESS", "invites@example.com")

    sent = {}

    async def fake_send_email(to, subject, html_body):
        sent["to"] = to
        sent["subject"] = subject
        sent["html_body"] = html_body

    monkeypatch.setattr(email_client, "send_email", fake_send_email)

    from app.jobs.jobs import _invite_dispatch

    result = await _invite_dispatch({
        "token": "abc123",
        "to": "candidate@example.com",
        "candidate_name": "Priya Rao",
        "role": "Senior AI Engineer",
        "link": "https://example.com/app/candidate?token=abc123",
    })
    assert result == {"token": "abc123", "sent": True}
    assert sent["to"] == "candidate@example.com"
    assert "Senior AI Engineer" in sent["subject"]
    assert "https://example.com/app/candidate?token=abc123" in sent["html_body"]
