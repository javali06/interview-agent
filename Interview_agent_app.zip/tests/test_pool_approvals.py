"""Maker-checker on question pools: storage split, the chain, and the refusals.

The first test in this file is the one that matters. Everything else is
workflow; `test_a_draft_is_invisible_to_cadence` is the control — if it ever
fails, an unapproved question can be asked of a real candidate.
"""
from __future__ import annotations

import pytest

from app.constants import POOL_DRAFT, POOL_PENDING, POOL_PUBLISHED
from db.engine import reset_engine


AYUSH = "ayush.kothiyal@centific.com"        # admin @ *
AZHAR = "md.azhar@centific.com"              # pool_author @ backend
HARIKA = "puchalapalli.harika@centific.com"  # pool_checker @ backend
SHOBIT = "sai.kambampati@centific.com"       # pool_checker @ *
HASINI = "hasini.gandhe@centific.com"        # pool_author @ qa
JAVALI = "javali.manda@centific.com"         # hr


QUESTION = {
    "text": "Walk me through how you would shard a write-heavy table.",
    "topic": "databases",
    "difficulty": "medium",
}


@pytest.fixture()
def env(tmp_path, monkeypatch):
    """A throwaway database and a throwaway blob directory."""
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.setenv("BLOB_ENABLED", "0")

    # blob_store reads SESSIONS_DIR through app.paths, which resolved it at
    # import time — so point the constant itself at tmp_path.
    import app.paths

    monkeypatch.setattr(app.paths, "SESSIONS_DIR", tmp_path, raising=False)

    reset_engine()
    from db.engine import create_all

    create_all()
    from app.rbac_seed import seed_rbac

    seed_rbac()

    from app import rbac

    def uid(email: str) -> int:
        row = rbac.user_by_email(email)
        assert row is not None, email
        return row["id"]

    yield uid
    reset_engine()


def _draft(team="backend", author=AZHAR, name="Backend pool"):
    """Save a draft the way the route does, and return its id."""
    from app import question_pools as qp

    pool = qp.QuestionPool.model_validate(
        {"pool_name": name, "questions": [QUESTION]}
    )
    pool.team = team
    pool.created_by = author
    pool.updated_by = author
    return qp.save_draft(pool).pool_id


# ── the control ──────────────────────────────────────────────────────────


def test_a_draft_is_invisible_to_cadence(env):
    """THE test. A draft must not be listable or resolvable by the cadence
    path, because that is what stops an unapproved question reaching a
    candidate. It holds by construction — drafts live under a different blob
    prefix — not by any check that could be forgotten."""
    from app import question_pools as qp

    pool_id = _draft()

    assert qp.load_pool(pool_id) is None                       # not published
    assert qp.pool_questions(pool_id) is None                  # cadence cannot resolve it
    assert pool_id not in {p["pool_id"] for p in qp.list_pools()}
    assert qp.load_draft(pool_id) is not None                  # but it does exist


def test_publishing_moves_it_and_removes_the_draft(env):
    """Once published the draft is gone — otherwise every pool reads as 'has a
    pending draft' forever and the annotation stops meaning anything."""
    from app import question_pools as qp

    pool_id = _draft()
    qp.publish_draft(pool_id)

    assert qp.load_pool(pool_id) is not None
    assert qp.pool_questions(pool_id) is not None
    assert qp.load_draft(pool_id) is None
    assert qp.has_draft(pool_id) is False


def test_editing_a_published_pool_leaves_the_live_one_alone(env):
    """The version interviews are using keeps working until the new draft
    clears the chain in its own turn."""
    from app import question_pools as qp

    pool_id = _draft(name="Original")
    qp.publish_draft(pool_id)

    edited = qp.load_pool(pool_id)
    edited.pool_name = "Edited"
    qp.save_draft(edited, pool_id=pool_id)

    assert qp.load_pool(pool_id).pool_name == "Original"     # live, untouched
    assert qp.load_draft(pool_id).pool_name == "Edited"      # the work in progress
    assert qp.load_editable(pool_id).pool_name == "Edited"   # what an author sees


# ── the happy path ───────────────────────────────────────────────────────


def test_one_approval_publishes_by_default(env):
    from app import approval_service as a
    from app import question_pools as qp

    uid = env
    pool_id = _draft()

    status = a.submit(pool_id, uid(AZHAR), "backend", author_emails=[AZHAR])
    assert status["state"] == POOL_PENDING
    assert status["next_step"]["step_no"] == 1

    status = a.approve(
        pool_id, uid(HARIKA), on_publish=lambda: qp.publish_draft(pool_id)
    )
    assert status["state"] == POOL_PUBLISHED
    assert qp.load_pool(pool_id) is not None


def test_state_is_derived_from_the_ledger_alone(env):
    from app import approval_service as a

    uid = env
    pool_id = _draft()
    assert a.pool_status(pool_id)["state"] == POOL_DRAFT
    a.submit(pool_id, uid(AZHAR), "backend")
    assert a.pool_status(pool_id)["state"] == POOL_PENDING
    assert len(a.history(pool_id)) == 1


# ── the refusals ─────────────────────────────────────────────────────────


def test_the_submitter_cannot_approve_their_own_pool(env):
    from app import approval_service as a

    uid = env
    pool_id = _draft()
    a.submit(pool_id, uid(AZHAR), "backend", author_emails=[AZHAR])

    with pytest.raises(a.ApprovalError) as e:
        a.approve(pool_id, uid(AZHAR))
    assert e.value.code == "self_approval"


def test_an_author_cannot_approve_even_if_someone_else_submitted(env):
    """The second hole: a colleague submitting on your behalf must not turn
    your own work into something you may sign off."""
    from app import approval_service as a
    from db.engine import session_scope
    from db.models import AppRole, AppTeam, AppUserRole

    uid = env
    pool_id = _draft(author=HARIKA)          # Harika WROTE it
    # ...and she is a checker for backend, so only the author rule stops her.
    a.submit(pool_id, uid(AZHAR), "backend", author_emails=[HARIKA])

    with pytest.raises(a.ApprovalError) as e:
        a.approve(pool_id, uid(HARIKA))
    assert e.value.code == "self_approval"


def test_a_checker_cannot_approve_another_teams_pool(env):
    """Team scoping, proven by a refusal: Harika checks for Backend, so
    Hasini's QA pool is not hers to approve."""
    from app import approval_service as a

    uid = env
    pool_id = _draft(team="qa", author=HASINI)
    a.submit(pool_id, uid(HASINI), "qa", author_emails=[HASINI])

    with pytest.raises(a.ApprovalError) as e:
        a.approve(pool_id, uid(HARIKA))
    assert e.value.code == "wrong_team"


def test_a_central_checker_can_approve_any_team(env):
    from app import approval_service as a
    from app import question_pools as qp

    uid = env
    pool_id = _draft(team="qa", author=HASINI)
    a.submit(pool_id, uid(HASINI), "qa", author_emails=[HASINI])
    status = a.approve(
        pool_id, uid(SHOBIT), on_publish=lambda: qp.publish_draft(pool_id)
    )
    assert status["state"] == POOL_PUBLISHED


def test_hr_cannot_approve(env):
    from app import approval_service as a

    uid = env
    pool_id = _draft()
    a.submit(pool_id, uid(AZHAR), "backend", author_emails=[AZHAR])
    with pytest.raises(a.ApprovalError):
        a.approve(pool_id, uid(JAVALI))


def test_a_return_needs_a_reason(env):
    from app import approval_service as a

    uid = env
    pool_id = _draft()
    a.submit(pool_id, uid(AZHAR), "backend")
    with pytest.raises(a.ApprovalError) as e:
        a.return_pool(pool_id, uid(HARIKA), "   ")
    assert e.value.code == "comment_required"


def test_a_return_sends_it_back_to_draft_with_the_comment(env):
    from app import approval_service as a

    uid = env
    pool_id = _draft()
    a.submit(pool_id, uid(AZHAR), "backend")
    status = a.return_pool(pool_id, uid(HARIKA), "Two questions are duplicates.")
    assert status["state"] == POOL_DRAFT
    assert status["last_comment"] == "Two questions are duplicates."
    assert status["cycle_id"] is None


def test_only_the_submitter_withdraws(env):
    from app import approval_service as a

    uid = env
    pool_id = _draft()
    a.submit(pool_id, uid(AZHAR), "backend")
    with pytest.raises(a.ApprovalError) as e:
        a.withdraw(pool_id, uid(HARIKA))
    assert e.value.code == "not_submitter"
    assert a.withdraw(pool_id, uid(AZHAR))["state"] == POOL_DRAFT


def test_submitting_twice_is_refused(env):
    from app import approval_service as a

    uid = env
    pool_id = _draft()
    a.submit(pool_id, uid(AZHAR), "backend")
    with pytest.raises(a.ApprovalError) as e:
        a.submit(pool_id, uid(AZHAR), "backend")
    assert e.value.code == "already_pending"


def test_a_failed_publish_leaves_the_pool_pending(env):
    """The ledger must never claim a publication the storage did not perform."""
    from app import approval_service as a

    uid = env
    pool_id = _draft()
    a.submit(pool_id, uid(AZHAR), "backend", author_emails=[AZHAR])

    def _boom():
        raise RuntimeError("storage is down")

    with pytest.raises(RuntimeError):
        a.approve(pool_id, uid(HARIKA), on_publish=_boom)

    status = a.pool_status(pool_id)
    assert status["state"] == POOL_PENDING          # not published
    assert status["signed"] == []                # and not even signed


# ── two levels ───────────────────────────────────────────────────────────


def _two_step_chain():
    """Give `backend` its own two-step chain."""
    from sqlalchemy import select

    from db.engine import session_scope
    from db.models import AppApprovalStep, AppRole, AppTeam

    with session_scope() as s:
        team_id = s.execute(select(AppTeam.id).where(AppTeam.key == "backend")).scalar_one()
        role_id = s.execute(
            select(AppRole.id).where(AppRole.key == "pool_checker")
        ).scalar_one()
        s.add(AppApprovalStep(team_id=team_id, step_no=1,
                              approver_role_id=role_id, name="Team lead"))
        s.add(AppApprovalStep(team_id=team_id, step_no=2,
                              approver_role_id=role_id, name="Governance"))


def test_a_middle_step_does_not_publish(env):
    from app import approval_service as a
    from app import question_pools as qp

    uid = env
    _two_step_chain()
    pool_id = _draft()
    a.submit(pool_id, uid(AZHAR), "backend", author_emails=[AZHAR])

    status = a.approve(pool_id, uid(HARIKA), on_publish=lambda: qp.publish_draft(pool_id))
    assert status["state"] == POOL_PENDING
    assert status["next_step"]["step_no"] == 2
    assert qp.load_pool(pool_id) is None            # still not live

    status = a.approve(pool_id, uid(SHOBIT), on_publish=lambda: qp.publish_draft(pool_id))
    assert status["state"] == POOL_PUBLISHED
    assert qp.load_pool(pool_id) is not None


def test_one_person_cannot_sign_both_steps(env):
    """Otherwise a two-level chain is theatre: one checker holding the role
    both steps ask for would be 'two pairs of eyes' that are one."""
    from app import approval_service as a

    uid = env
    _two_step_chain()
    pool_id = _draft()
    a.submit(pool_id, uid(AZHAR), "backend", author_emails=[AZHAR])
    a.approve(pool_id, uid(HARIKA))

    with pytest.raises(a.ApprovalError) as e:
        a.approve(pool_id, uid(HARIKA))
    assert e.value.code == "already_signed"


def test_deleting_a_step_mid_cycle_does_not_publish(env):
    """The sharpest failure mode in the design: without a snapshot, removing
    the pending step would make the derivation find nothing unsigned and
    silently publish a pool that one person signed."""
    from sqlalchemy import select

    from app import approval_service as a
    from db.engine import session_scope
    from db.models import AppApprovalStep, AppTeam

    uid = env
    _two_step_chain()
    pool_id = _draft()
    a.submit(pool_id, uid(AZHAR), "backend", author_emails=[AZHAR])
    a.approve(pool_id, uid(HARIKA))               # step 1 signed

    with session_scope() as s:                    # an admin edits the chain
        team_id = s.execute(select(AppTeam.id).where(AppTeam.key == "backend")).scalar_one()
        row = s.execute(
            select(AppApprovalStep).where(
                AppApprovalStep.team_id == team_id, AppApprovalStep.step_no == 2
            )
        ).scalar_one()
        s.delete(row)

    status = a.pool_status(pool_id)
    assert status["state"] == POOL_PENDING            # NOT published
    assert status["next_step"]["step_no"] == 2     # judged against the snapshot


def test_a_new_submission_starts_a_clean_cycle(env):
    """Prior approvals never carry over — otherwise a returned pool could be
    republished on signatures given to an older version of it."""
    from app import approval_service as a

    uid = env
    _two_step_chain()
    pool_id = _draft()
    a.submit(pool_id, uid(AZHAR), "backend", author_emails=[AZHAR])
    a.approve(pool_id, uid(HARIKA))                       # step 1 signed
    a.return_pool(pool_id, uid(SHOBIT), "Needs work.")    # then returned

    status = a.submit(pool_id, uid(AZHAR), "backend", author_emails=[AZHAR])
    assert status["state"] == POOL_PENDING
    assert status["next_step"]["step_no"] == 1             # back to the start
    assert status["signed"] == []


# ── break-glass ──────────────────────────────────────────────────────────


def test_force_publish_bypasses_the_chain_and_is_recorded(env):
    from sqlalchemy import select

    from app import approval_service as a
    from app import question_pools as qp
    from db.engine import session_scope
    from db.models import AuditLog

    uid = env
    pool_id = _draft()
    status = a.force_publish(
        pool_id, uid(AYUSH), "backend", comment="Typo in a live question.",
        on_publish=lambda: qp.publish_draft(pool_id),
    )
    assert status["state"] == POOL_PUBLISHED
    assert qp.load_pool(pool_id) is not None

    with session_scope() as s:
        actions = s.execute(select(AuditLog.action)).scalars().all()
    assert "pool.force_published" in actions


# ── the queue ────────────────────────────────────────────────────────────


def test_the_queue_only_shows_work_you_could_actually_sign(env):
    from app import approval_service as a

    uid = env
    backend_pool = _draft(team="backend", author=AZHAR)
    qa_pool = _draft(team="qa", author=HASINI, name="QA pool")
    a.submit(backend_pool, uid(AZHAR), "backend", author_emails=[AZHAR])
    a.submit(qa_pool, uid(HASINI), "qa", author_emails=[HASINI])

    harika = {i["pool_id"] for i in a.queue_for(uid(HARIKA))}
    shobit = {i["pool_id"] for i in a.queue_for(uid(SHOBIT))}
    azhar = {i["pool_id"] for i in a.queue_for(uid(AZHAR))}

    assert harika == {backend_pool}                 # her team only
    assert shobit == {backend_pool, qa_pool}        # central reviewer
    assert azhar == set()                           # he submitted one, authors neither


# ── the routes ───────────────────────────────────────────────────────────


@pytest.fixture()
def api(env, monkeypatch):
    """A TestClient plus a helper to become someone: it sets the session
    cookie a Microsoft sign-in ends with (email + `app_users.id`)."""
    from fastapi.testclient import TestClient

    from app import auth, rbac

    monkeypatch.setenv("ADMIN_SECRET_KEY", "test-secret-approvals")
    from app.main import app

    client = TestClient(app)

    def become(email: str):
        user = rbac.user_by_email(email)
        assert user is not None, email
        client.cookies.set(auth.COOKIE_NAME, auth.issue_cookie(user["email"], user_id=user["id"]))
        return client

    return client, become, env


def test_hr_is_refused_on_every_pool_route(api):
    """Javali schedules interviews. She must be turned away from the whole
    pools surface — asserted by walking the router, so a pool route added later
    cannot quietly become HR-visible."""
    from app.question_pool_routes import router

    client, become, _ = api
    become(JAVALI)

    checked = 0
    for route in router.routes:
        path = route.path
        if "{" in path:                     # needs an id; covered below
            continue
        for method in sorted(route.methods - {"HEAD", "OPTIONS"}):
            r = client.request(method, path, json={})
            assert r.status_code in (403, 422), f"{method} {path} -> {r.status_code}"
            checked += 1
    assert checked >= 4                      # /kinds, "", /duplicate, /approvals/queue

    # ...and the id-bearing ones.
    for path in ("/api/question-pools/x", "/api/question-pools/x/history",
                 "/api/question-pools/x/export"):
        assert client.get(path).status_code == 403, path
    for path in ("/api/question-pools/x/submit", "/api/question-pools/x/approve",
                 "/api/question-pools/x/return", "/api/question-pools/x/publish"):
        assert client.post(path, json={"comment": "x"}).status_code == 403, path


def test_create_lands_as_a_draft_not_live(api):
    from app import question_pools as qp

    client, become, _ = api
    become(AZHAR)
    r = client.post("/api/question-pools", json={
        "pool_name": "Sharding", "team": "backend", "questions": [QUESTION],
    })
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["state"] == "draft"
    pool_id = body["pool_id"]

    assert qp.load_pool(pool_id) is None            # not live
    assert qp.load_draft(pool_id) is not None


def test_an_author_cannot_create_for_another_team(api):
    client, become, _ = api
    become(AZHAR)                                   # author @ backend
    r = client.post("/api/question-pools", json={
        "pool_name": "Nope", "team": "qa", "questions": [QUESTION],
    })
    assert r.status_code == 403


def test_the_full_round_trip_over_http(api):
    from app import question_pools as qp

    client, become, _ = api

    become(AZHAR)
    pool_id = client.post("/api/question-pools", json={
        "pool_name": "Sharding", "team": "backend", "questions": [QUESTION],
    }).json()["pool_id"]

    assert client.post(f"/api/question-pools/{pool_id}/submit",
                       json={}).status_code == 200
    # He submitted it, so he cannot sign it off.
    assert client.post(f"/api/question-pools/{pool_id}/approve",
                       json={}).status_code == 403

    become(HASINI)                                   # author @ qa, not a checker
    assert client.post(f"/api/question-pools/{pool_id}/approve",
                       json={}).status_code == 403

    become(HARIKA)                                   # checker @ backend
    assert client.get("/api/question-pools/approvals/queue").json()["queue"][0][
        "pool_id"
    ] == pool_id
    r = client.post(f"/api/question-pools/{pool_id}/approve", json={})
    assert r.status_code == 200, r.text
    assert r.json()["published"] is True

    assert qp.load_pool(pool_id) is not None         # live at last
    assert qp.load_draft(pool_id) is None            # draft cleaned up

    hist = client.get(f"/api/question-pools/{pool_id}/history").json()["history"]
    assert [h["action"] for h in hist] == ["submitted", "approved", "published"]


def test_a_returned_pool_carries_the_comment_back(api):
    client, become, _ = api

    become(AZHAR)
    pool_id = client.post("/api/question-pools", json={
        "pool_name": "Sharding", "team": "backend", "questions": [QUESTION],
    }).json()["pool_id"]
    client.post(f"/api/question-pools/{pool_id}/submit", json={})

    become(HARIKA)
    assert client.post(f"/api/question-pools/{pool_id}/return",
                       json={"comment": ""}).status_code == 400
    r = client.post(f"/api/question-pools/{pool_id}/return",
                    json={"comment": "Split question 1 in two."})
    assert r.status_code == 200

    become(AZHAR)
    got = client.get(f"/api/question-pools/{pool_id}").json()
    assert got["workflow"] == "draft"
    assert got["last_comment"] == "Split question 1 in two."


def test_a_pending_pool_cannot_be_edited(api):
    client, become, _ = api
    become(AZHAR)
    pool_id = client.post("/api/question-pools", json={
        "pool_name": "Sharding", "team": "backend", "questions": [QUESTION],
    }).json()["pool_id"]
    client.post(f"/api/question-pools/{pool_id}/submit", json={})

    r = client.put(f"/api/question-pools/{pool_id}", json={
        "pool_name": "Changed", "team": "backend", "questions": [QUESTION],
    })
    assert r.status_code == 409


def test_for_phase_serves_published_only(api):
    """The cadence-facing route. A draft must 404 here even for an admin."""
    client, become, _ = api

    become(AZHAR)
    pool_id = client.post("/api/question-pools", json={
        "pool_name": "Sharding", "team": "backend", "questions": [QUESTION],
    }).json()["pool_id"]

    become(AYUSH)                                    # admin: every permission
    r = client.get(f"/api/question-pools/{pool_id}/for-phase?token=tok")
    assert r.status_code == 404                      # draft is unreachable

    client.post(f"/api/question-pools/{pool_id}/publish",
                json={"comment": "urgent"})
    r = client.get(f"/api/question-pools/{pool_id}/for-phase?token=tok")
    assert r.status_code == 200
    assert len(r.json()["questions"]) == 1


def test_an_author_sees_only_their_own_teams_drafts(api):
    client, become, _ = api

    become(AZHAR)
    client.post("/api/question-pools", json={
        "pool_name": "Backend draft", "team": "backend", "questions": [QUESTION],
    })
    become(HASINI)
    client.post("/api/question-pools", json={
        "pool_name": "QA draft", "team": "qa", "questions": [QUESTION],
    })

    become(AZHAR)
    names = {p["pool_name"] for p in client.get("/api/question-pools").json()["pools"]}
    assert "Backend draft" in names
    assert "QA draft" not in names               # not his team's work in progress

    become(SHOBIT)                                # checker @ * sees both
    names = {p["pool_name"] for p in client.get("/api/question-pools").json()["pools"]}
    assert {"Backend draft", "QA draft"} <= names


def _qa_pool(client, become):
    become(HASINI)
    return client.post("/api/question-pools", json={
        "pool_name": "QA draft", "team": "qa", "questions": [QUESTION],
    }).json()["pool_id"]


def test_an_author_cannot_move_another_teams_pool_into_their_own(api):
    """Naming your own team in the body must not take over another team's pool."""
    from app import question_pools as qp

    client, become, _ = api
    pool_id = _qa_pool(client, become)

    become(AZHAR)                                  # author @ backend only
    for team in ("backend", ""):
        r = client.put(f"/api/question-pools/{pool_id}", json={
            "pool_name": "Mine now", "team": team, "questions": [QUESTION],
        })
        assert r.status_code == 403, team
    assert qp.load_draft(pool_id).team == "qa"


def test_another_teams_review_and_history_are_hidden(api):
    client, become, _ = api
    pool_id = _qa_pool(client, become)
    client.post(f"/api/question-pools/{pool_id}/submit", json={})

    become(AZHAR)                                  # pools.view, but not for qa
    assert client.get(f"/api/question-pools/{pool_id}/review").status_code == 403
    assert client.get(f"/api/question-pools/{pool_id}/history").status_code == 403

    become(SHOBIT)                                 # checker @ *
    assert client.get(f"/api/question-pools/{pool_id}/review").status_code == 200
    assert client.get(f"/api/question-pools/{pool_id}/history").status_code == 200


def test_force_publish_is_scoped_to_the_publishers_team(api):
    from sqlalchemy import select

    from app import question_pools as qp
    from db.engine import session_scope
    from db.models import AppRole, AppTeam, AppUserRole

    client, become, uid = api
    pool_id = _qa_pool(client, become)
    with session_scope() as s:                     # an admin for backend only
        role_id = s.execute(select(AppRole.id).where(AppRole.key == "admin")).scalar_one()
        team_id = s.execute(select(AppTeam.id).where(AppTeam.key == "backend")).scalar_one()
        s.add(AppUserRole(user_id=uid(AZHAR), role_id=role_id, team_id=team_id))

    become(AZHAR)
    r = client.post(f"/api/question-pools/{pool_id}/publish", json={"comment": "x"})
    assert r.status_code == 403
    assert qp.load_pool(pool_id) is None


def test_force_publish_after_a_return_reads_as_published(api):
    client, become, _ = api
    become(AZHAR)
    pool_id = client.post("/api/question-pools", json={
        "pool_name": "Sharding", "team": "backend", "questions": [QUESTION],
    }).json()["pool_id"]
    client.post(f"/api/question-pools/{pool_id}/submit", json={})
    become(HARIKA)
    client.post(f"/api/question-pools/{pool_id}/return", json={"comment": "Fix it."})

    become(AYUSH)
    r = client.post(f"/api/question-pools/{pool_id}/publish", json={"comment": "urgent"})
    assert r.status_code == 200
    assert r.json()["status"]["state"] == POOL_PUBLISHED


def test_a_review_must_decide_every_question(api):
    from app import question_pools as qp

    client, become, _ = api
    become(AZHAR)
    pool_id = client.post("/api/question-pools", json={
        "pool_name": "Two", "team": "backend",
        "questions": [QUESTION, {**QUESTION, "text": "A second question."}],
    }).json()["pool_id"]
    client.post(f"/api/question-pools/{pool_id}/submit", json={})
    first = qp.load_draft(pool_id).questions[0].id

    become(HARIKA)
    r = client.post(f"/api/question-pools/{pool_id}/review", json={
        "verdicts": [{"question_id": first, "verdict": "approved"}],
    })
    assert r.status_code == 400
    assert qp.load_pool(pool_id) is None


def test_a_review_verdict_must_be_approved_or_rejected(api):
    """An entry that is not approved or rejected is not a decision. The route
    must refuse it, or the service drops it and publishes the rest."""
    from app import question_pools as qp

    client, become, _ = api
    become(AZHAR)
    pool_id = client.post("/api/question-pools", json={
        "pool_name": "Two", "team": "backend",
        "questions": [QUESTION, {**QUESTION, "text": "A second question."}],
    }).json()["pool_id"]
    client.post(f"/api/question-pools/{pool_id}/submit", json={})
    questions = qp.load_draft(pool_id).questions

    become(HARIKA)
    r = client.post(f"/api/question-pools/{pool_id}/review", json={
        "verdicts": [
            {"question_id": questions[0].id, "verdict": "approved"},
            {"question_id": questions[1].id, "verdict": ""},
        ],
    })
    assert r.status_code == 400
    assert "approved or rejected" in r.json()["detail"]
    assert qp.load_pool(pool_id) is None
