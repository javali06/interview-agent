"""Tests for the resume-email fallback: when the admin leaves candidate_email
blank at schedule time, app.jobs.jobs._resume_summary should pick one up out
of the parsed resume text (engine.orchestrator.resume_parser.extract_email)
— but must never override an email the admin actually typed in.
"""
from __future__ import annotations

import pytest

from engine.orchestrator.resume_parser import extract_email


# ── extract_email (pure function, no I/O) ───────────────────────────────────


def test_extract_email_finds_address_in_resume_text():
    text = "Priya Rao\nSenior AI Engineer\npriya.rao@example.com | +1 555-0100\n\nExperience..."
    assert extract_email(text) == "priya.rao@example.com"


def test_extract_email_returns_none_when_absent():
    text = "Priya Rao\nSenior AI Engineer\n555-0100\n\nExperience..."
    assert extract_email(text) is None


def test_extract_email_picks_the_first_match():
    # A resume's OWN contact email is almost always the first one — a
    # reference's or former manager's email later in the document shouldn't
    # be picked instead.
    text = "Contact: candidate@example.com\n...\nReference: manager@othercorp.com"
    assert extract_email(text) == "candidate@example.com"


def test_extract_email_ignores_non_email_at_signs():
    text = "Handled @scale infrastructure serving 10k req/s. No contact info here."
    assert extract_email(text) is None


# ── _resume_summary fallback wiring ──────────────────────────────────────────


@pytest.fixture()
def temp_db(tmp_path, monkeypatch):
    """Point the shared engine at a throwaway SQLite file and build the schema."""
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    monkeypatch.delenv("DATABASE_URL", raising=False)
    import db.engine as engine
    engine.reset_engine()
    from app import db
    db.init_db()
    yield
    engine.reset_engine(None)


def _insert_session(token: str, *, candidate_email: str | None, resume_path: str) -> None:
    from app import db
    db.insert({
        "token": token,
        "candidate_name": "Priya Rao",
        "role": "Senior AI Engineer",
        "candidate_email": candidate_email,
        "jd_path": None,
        "jd_text": None,
        "resume_path": resume_path,
        "cadence_requirements_path": None,
        "cadence_requirements_text": None,
        "cadence_yaml": "phases: []\n",
        "status": "draft",
        "pid": None,
        "ws_port": None,
        "http_port": None,
        "created_at": db.now_iso(),
        "started_at": None,
        "ended_at": None,
        "event_log_path": "events.jsonl",
        "record_enabled": True,
        "modality": "voice",
    })


@pytest.mark.asyncio
async def test_resume_summary_fills_blank_candidate_email(temp_db, monkeypatch, tmp_path):
    from app import db
    from app.jobs import jobs
    from app.paths import session_dir

    token = "tok-blank-email"
    sdir = session_dir(token)
    sdir.mkdir(parents=True, exist_ok=True)
    resume_file = sdir / "resume.txt"
    resume_file.write_text("dummy", encoding="utf-8")  # content irrelevant; parse_resume is stubbed
    _insert_session(token, candidate_email=None, resume_path="resume.txt")

    monkeypatch.setattr(
        "engine.orchestrator.resume_parser.parse_resume",
        lambda path: "Priya Rao\npriya.rao@example.com\n\nExperience building things.",
    )

    async def fake_summarize(*args, **kwargs):
        return "a short summary"

    monkeypatch.setattr("engine.orchestrator.resume_parser.summarize_resume", fake_summarize)
    monkeypatch.setattr("app.cadence_service._resolve_llm", lambda: ("key", "https://x", "model"))

    await jobs._resume_summary({"token": token})

    row = db.get(token)
    assert row["candidate_email"] == "priya.rao@example.com"


@pytest.mark.asyncio
async def test_resume_summary_never_overrides_entered_email(temp_db, monkeypatch, tmp_path):
    from app import db
    from app.jobs import jobs
    from app.paths import session_dir

    token = "tok-entered-email"
    sdir = session_dir(token)
    sdir.mkdir(parents=True, exist_ok=True)
    resume_file = sdir / "resume.txt"
    resume_file.write_text("dummy", encoding="utf-8")
    _insert_session(token, candidate_email="entered@company.com", resume_path="resume.txt")

    monkeypatch.setattr(
        "engine.orchestrator.resume_parser.parse_resume",
        lambda path: "Priya Rao\nsomeother@example.com\n\nExperience building things.",
    )

    async def fake_summarize(*args, **kwargs):
        return "a short summary"

    monkeypatch.setattr("engine.orchestrator.resume_parser.summarize_resume", fake_summarize)
    monkeypatch.setattr("app.cadence_service._resolve_llm", lambda: ("key", "https://x", "model"))

    await jobs._resume_summary({"token": token})

    row = db.get(token)
    # The admin's own entry survives untouched — the resume's email is ignored.
    assert row["candidate_email"] == "entered@company.com"


@pytest.mark.asyncio
async def test_resume_summary_leaves_email_blank_when_none_found(temp_db, monkeypatch, tmp_path):
    from app import db
    from app.jobs import jobs
    from app.paths import session_dir

    token = "tok-no-email-anywhere"
    sdir = session_dir(token)
    sdir.mkdir(parents=True, exist_ok=True)
    resume_file = sdir / "resume.txt"
    resume_file.write_text("dummy", encoding="utf-8")
    _insert_session(token, candidate_email=None, resume_path="resume.txt")

    monkeypatch.setattr(
        "engine.orchestrator.resume_parser.parse_resume",
        lambda path: "Priya Rao\n555-0100\n\nExperience building things, no email listed.",
    )

    async def fake_summarize(*args, **kwargs):
        return "a short summary"

    monkeypatch.setattr("engine.orchestrator.resume_parser.summarize_resume", fake_summarize)
    monkeypatch.setattr("app.cadence_service._resolve_llm", lambda: ("key", "https://x", "model"))

    await jobs._resume_summary({"token": token})

    row = db.get(token)
    assert row["candidate_email"] is None
