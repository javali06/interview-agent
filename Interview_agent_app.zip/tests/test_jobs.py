"""Worker-tier tests: enqueue + status lifecycle + worker success/retry/dead.

Uses the InMemoryQueue seam and a temp SQLite DB (via SESSIONS_DIR), so no
Azure and no Redis needed.
"""
from __future__ import annotations

import pytest

from app.jobs import jobs, status, worker
from app.jobs.queue import InMemoryQueue, set_queue


@pytest.fixture()
def temp_db(tmp_path, monkeypatch):
    """Point the shared engine at a throwaway SQLite file and build the schema."""
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    monkeypatch.delenv("DATABASE_URL", raising=False)
    import db.engine as engine
    engine.reset_engine()  # rebuild against the temp SESSIONS_DIR
    from app import db
    db.init_db()
    yield
    engine.reset_engine(None)


@pytest.fixture()
def mem_queue():
    q = InMemoryQueue()
    set_queue(q)
    yield q
    set_queue(None)


@pytest.fixture()
def fake_handler(monkeypatch):
    """Register a controllable job type; return a dict to tweak its behavior."""
    ctl = {"mode": "ok", "calls": 0}

    async def _h(payload: dict) -> dict:
        ctl["calls"] += 1
        if ctl["mode"] == "boom":
            raise RuntimeError("kaboom")
        return {"echo": payload.get("x")}

    monkeypatch.setitem(jobs.HANDLERS, "unit_test_job", _h)
    return ctl


@pytest.mark.asyncio
async def test_enqueue_creates_row_and_message(temp_db, mem_queue, fake_handler):
    job_id = await jobs.enqueue("unit_test_job", {"x": 1}, token="tok")
    row = status.get(job_id)
    assert row is not None
    assert row["status"] == status.QUEUED
    assert row["token"] == "tok"
    assert await mem_queue.approx_count() == 1


@pytest.mark.asyncio
async def test_worker_success_acks_message(temp_db, mem_queue, fake_handler):
    job_id = await jobs.enqueue("unit_test_job", {"x": 42})
    (msg,) = await mem_queue.receive()
    await worker.process_one(msg)

    row = status.get(job_id)
    assert row["status"] == status.SUCCEEDED
    assert row["result"] == {"echo": 42}
    assert row["attempts"] == 1
    assert await mem_queue.approx_count() == 0  # deleted on success


@pytest.mark.asyncio
async def test_worker_transient_failure_retries(temp_db, mem_queue, fake_handler, monkeypatch):
    monkeypatch.setenv("JOBS_MAX_ATTEMPTS", "3")
    fake_handler["mode"] = "boom"
    job_id = await jobs.enqueue("unit_test_job", {"x": 1})

    (msg,) = await mem_queue.receive()  # dequeue_count -> 1
    await worker.process_one(msg)

    row = status.get(job_id)
    assert row["status"] == status.FAILED     # transient — will retry
    assert await mem_queue.approx_count() == 1  # NOT deleted; reappears
    assert not mem_queue.poison


@pytest.mark.asyncio
async def test_worker_dead_letters_after_max_attempts(temp_db, mem_queue, fake_handler, monkeypatch):
    monkeypatch.setenv("JOBS_MAX_ATTEMPTS", "3")
    fake_handler["mode"] = "boom"
    job_id = await jobs.enqueue("unit_test_job", {"x": 1})

    # Burn attempts up to the limit.
    for _ in range(3):
        (msg,) = await mem_queue.receive()
        await worker.process_one(msg)

    row = status.get(job_id)
    assert row["status"] == status.DEAD
    assert await mem_queue.approx_count() == 0   # removed from main queue
    assert mem_queue.poison == [job_id]          # parked in poison


@pytest.mark.asyncio
async def test_unknown_job_type_rejected(temp_db, mem_queue):
    with pytest.raises(KeyError):
        await jobs.enqueue("no_such_job", {})


def test_only_real_wired_jobs_registered():
    # Stubs for non-existent features were removed — every registered job is real.
    assert set(jobs.HANDLERS) == {
        jobs.CADENCE_GEN, jobs.EVAL_V2, jobs.SHORTLIST_SCORE, jobs.RESUME_SUMMARY, jobs.INVITE_DISPATCH,
        jobs.RECORDING_FINALIZE,
    }


@pytest.mark.asyncio
async def test_cadence_gen_enqueue_seam(temp_db, mem_queue):
    # The schedule route enqueues this instead of running the ~10s LLM inline.
    job_id = await jobs.enqueue(jobs.CADENCE_GEN, {"token": "tok"}, token="tok")
    row = status.get(job_id)
    assert row["type"] == "cadence_gen"
    assert row["status"] == status.QUEUED
    assert row["token"] == "tok"
    assert await mem_queue.approx_count() == 1
