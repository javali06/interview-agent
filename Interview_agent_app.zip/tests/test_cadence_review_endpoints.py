"""Tests for the cadence-review JSON twins used by the React SPA.

Run with: .venv/bin/python -m pytest tests/test_cadence_review_endpoints.py -v

Coverage:
  - GET  /api/schedule/{t}/cadence  — auth gate, 404, page-context shape
  - POST /api/schedule/{t}/approve  — auth gate, 404, invalid-cadence 400,
                                      success path (validate + spawner
                                      monkeypatched — no orchestrator launched)
"""
from __future__ import annotations

import pytest

_VALID_CADENCE = (
    "total_duration_s: 120\n"
    "phases:\n"
    "- id: warm_up\n"
    "  duration_s: 60\n"
    "  intent: Settle in.\n"
    "  question_mode: generic\n"
    "  generic_prompts: ['Hi']\n"
    "- id: tech\n"
    "  duration_s: 60\n"
    "  intent: Depth.\n"
    "  question_mode: generic\n"
    "  generic_prompts: ['Explain X']\n"
)


@pytest.fixture
def clients(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    from fastapi.testclient import TestClient
    from app import auth, db, main

    db.init_db()
    authed = TestClient(main.app)
    authed.cookies.set(auth.COOKIE_NAME, auth.issue_cookie("test_admin"))
    anon = TestClient(main.app)
    return authed, anon


def _seed(token: str, status: str = "draft") -> str:
    from app import db

    if db.get(token) is None:
        db.insert({
            "token": token,
            "candidate_name": "Cadence Test",
            "role": "AI Engineer",
            "jd_text": "Builds LLM systems.",
            "resume_path": "resume.pdf",
            "cadence_yaml": _VALID_CADENCE,
            "status": status,
            "created_at": db.now_iso(),
        })
    return token


# ── GET /api/schedule/{token}/cadence ────────────────────────────────────────


def test_cadence_ctx_requires_auth(clients):
    _, anon = clients
    assert anon.get("/api/schedule/x/cadence").status_code == 401


def test_cadence_ctx_404(clients):
    authed, _ = clients
    assert authed.get("/api/schedule/no-such/cadence").status_code == 404


def test_cadence_ctx_shape(clients):
    from app import db

    authed, _ = clients
    token = _seed("cadtest-ctx")
    try:
        r = authed.get(f"/api/schedule/{token}/cadence")
        assert r.status_code == 200, r.text
        d = r.json()
        assert {"row", "phase_ids", "pool_files", "rubric_enabled", "active_blocker"} <= set(d)
        assert d["row"]["token"] == token
        assert d["phase_ids"] == ["warm_up", "tech"]
        assert d["active_blocker"] is False
    finally:
        db.delete(token)


# ── POST /api/schedule/{token}/approve ───────────────────────────────────────


def test_approve_requires_auth(clients):
    _, anon = clients
    assert anon.post("/api/schedule/x/approve", json={"cadence_yaml": "x"}).status_code == 401


def test_approve_404(clients):
    authed, _ = clients
    r = authed.post("/api/schedule/no-such/approve", json={"cadence_yaml": _VALID_CADENCE})
    assert r.status_code == 404


def test_approve_invalid_cadence_400(clients, monkeypatch):
    from app import db, main

    monkeypatch.setattr(main, "validate_cadence_yaml", lambda y: (False, "bad phases"))
    authed, _ = clients
    token = _seed("cadtest-bad")
    try:
        r = authed.post(f"/api/schedule/{token}/approve", json={"cadence_yaml": "broken"})
        assert r.status_code == 400
        assert "bad phases" in r.json()["error"]
    finally:
        db.delete(token)


def test_approve_success_launches_and_returns_links(clients, monkeypatch):
    from app import db, main

    # Don't actually spawn an orchestrator subprocess or touch disk.
    monkeypatch.setattr(main, "validate_cadence_yaml", lambda y: (True, None))
    monkeypatch.setattr(main.spawner, "launch_orchestrator", lambda token: 99999)
    monkeypatch.setattr(main.sessions, "write_cadence_to_disk", lambda token, y: None)

    authed, _ = clients
    token = _seed("cadtest-ok")
    try:
        r = authed.post(f"/api/schedule/{token}/approve", json={"cadence_yaml": _VALID_CADENCE})
        assert r.status_code == 200, r.text
        body = r.json()
        assert body["ok"] is True
        # The candidate link points at the React SPA. There is NO observer
        # link: an interview is the AI and the candidate only.
        assert f"/app/candidate?token={token}" in body["candidate_link"]
        assert "observer_link" not in body
        # status flipped to 'ready' with the (fake) pid
        row = db.get(token)
        assert row["status"] == "ready"
        assert str(row["pid"]) == "99999"
    finally:
        db.delete(token)
