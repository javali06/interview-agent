"""The export DOCUMENT layer (features/eval/export.py).

`tests/test_eval_export.py` covers the per-plugin section contract. This file
covers the envelope around them: totals, ordering, self-description, and the
one property that can reach a hiring decision —

    a segment that was NOT scored must never read as a zero.

That is enforced two ways and both are asserted here: `ExportSectionModel`
refuses to construct a non-scored section carrying marks, and the totals sum
only scored sections, so an unobserved phase shrinks the denominator instead of
dragging the percentage down.

No LLM: exporting reads an already-computed SegmentEvaluation.
"""
from __future__ import annotations

import json

import pytest
from pydantic import ValidationError

from features.eval import export as X
from features.eval.plugins.base import SegmentEvaluation
from features.eval.plugins.registry import export_schemas, list_plugins
from features.eval.sectioner import Segment

RUBRIC_AND_COVERAGE = ["conversational_rubric", "rubric_marks",
                       "coverage_tags", "dynamic_difficulty"]


def _seg(segment_id: str, phase_id: str = "technical_questions",
         question_id: str | None = "q1") -> Segment:
    return Segment(segment_id=segment_id, kind="question", phase_id=phase_id,
                   question_id=question_id, start_event_index=0,
                   end_event_index=1, turns=[])


def _ev(plugin_id: str, segment_id: str, **kw) -> SegmentEvaluation:
    base = dict(plugin_id=plugin_id, segment_id=segment_id,
                phase_id="technical_questions", state="scored",
                marks_earned=3.0, marks_possible=5.0, rationale="because")
    base.update(kw)
    return SegmentEvaluation(**base)


# ── every plugin now shares ONE contract ────────────────────────────────────
def test_all_eight_plugins_declare_a_section():
    # Both stories landed: Rubric & Coverage (34149) and Ground-truth & Coding
    # (34150) are on the same contract. A new plugin with no section is a
    # silently missing slice of a customer-facing document.
    missing = [p.id for p in list_plugins() if p.export_descriptor() is None]
    assert not missing, (
        f"plugins declaring no export section: {missing}. Add export_descriptor() "
        f"+ export_section() — see features/eval/plugins/export.py"
    )


def test_section_keys_are_unique():
    # export_schemas() raises on a duplicate key; this states the guarantee.
    keys = [p.export_descriptor().key for p in list_plugins()]
    assert len(keys) == len(set(keys)), f"duplicate section keys: {keys}"
    assert set(export_schemas()) == set(keys)


@pytest.mark.parametrize("pid", RUBRIC_AND_COVERAGE)
def test_my_family_emits_sections_that_validate_against_their_schema(pid):
    from features.eval.plugins.registry import get_plugin
    p = get_plugin(pid)
    sec = p().export_section(_seg(f"{pid}::s0"), _ev(pid, f"{pid}::s0"))
    assert isinstance(sec, p.export_descriptor().model)
    # Round-trips through JSON and back through its own declared model.
    p.export_descriptor().model.model_validate(json.loads(sec.model_dump_json()))


@pytest.mark.parametrize("pid", RUBRIC_AND_COVERAGE)
def test_the_envelope_carries_identity_from_the_segment_not_just_the_evaluation(pid):
    # question_id lives on the Segment, which is why export_section takes both.
    from features.eval.plugins.registry import get_plugin
    p = get_plugin(pid)
    sec = p().export_section(_seg(f"{pid}::s0", question_id="q-42"),
                             _ev(pid, f"{pid}::s0"))
    assert sec.question_id == "q-42"
    assert sec.plugin_id == pid and sec.segment_id == f"{pid}::s0"
    assert sec.section == p.export_descriptor().key


# ── non-scored is not zero ──────────────────────────────────────────────────
@pytest.mark.parametrize("state", list(X.NON_SCORED_STATES))
@pytest.mark.parametrize("pid", RUBRIC_AND_COVERAGE)
def test_a_non_scored_segment_exports_no_marks_at_all(pid, state):
    from features.eval.plugins.registry import get_plugin
    p = get_plugin(pid)
    sec = p().export_section(
        _seg(f"{pid}::s0"),
        _ev(pid, f"{pid}::s0", state=state, marks_earned=0.0, marks_possible=5.0),
    )
    # null, NOT 0 — a consumer must not be able to read "not measured" as
    # "scored nothing".
    assert sec.marks_earned is None and sec.marks_possible is None
    assert sec.not_scored_reason, "a non-scored section must say why"


def test_the_model_itself_refuses_a_non_scored_section_with_marks():
    # The invariant is structural, not a convention a plugin author must
    # remember: you cannot even construct the wrong thing.
    from features.eval.plugins.export import ExportSectionModel
    with pytest.raises(ValidationError, match="not a zero|must not carry marks"):
        ExportSectionModel(
            section="x", schema_version="1.0", plugin_id="p",
            segment_id="s", phase_id="ph", method="python",
            state="not_observed", marks_earned=0.0, marks_possible=5.0,
        )


def test_unobserved_phase_shrinks_the_denominator_rather_than_scoring_zero():
    from features.eval.plugins.registry import get_plugin
    cov = get_plugin("coverage_tags")
    rub = get_plugin("rubric_marks")
    sections = [
        cov().export_section(_seg("t::q1"),
                             _ev("coverage_tags", "t::q1",
                                 marks_earned=4.0, marks_possible=5.0)),
        rub().export_section(_seg("coding::q1", phase_id="coding_round"),
                             _ev("rubric_marks", "coding::q1",
                                 state="not_observed",
                                 marks_earned=0.0, marks_possible=30.0)),
    ]
    t = X.build_totals(sections)
    assert t.marks_possible == 5.0, "the unobserved 30 marks must not inflate the denominator"
    assert t.marks_earned == 4.0
    assert t.pct == 80.0, "80% (4/5), NOT 11.4% (4/35)"
    assert t.segments_scored == 1 and t.segments_not_scored == 1
    assert t.by_state == {"scored": 1, "not_observed": 1}


def test_a_report_where_nothing_was_scored_has_null_pct_not_zero():
    # 0% reads as "the candidate scored nothing". null reads as "there is no
    # score", which is the truth.
    from features.eval.plugins.registry import get_plugin
    sec = get_plugin("coverage_tags")().export_section(
        _seg("t::q1"), _ev("coverage_tags", "t::q1", state="not_observed"))
    t = X.build_totals([sec])
    assert t.pct is None and t.marks_possible == 0.0


def test_non_scored_states_are_an_explicit_list_not_everything_but_scored():
    # Guards the design choice: a NEW EvalState must be classified deliberately
    # rather than defaulting into "counts as a zero".
    import typing
    from features.eval.plugins.base import EvalState
    assert set(X.NON_SCORED_STATES) | {"scored"} == set(typing.get_args(EvalState)), (
        "a new EvalState was added — decide explicitly whether it is scored"
    )


# ── the document ────────────────────────────────────────────────────────────
def _golden_pairs():
    """A believable interview across BOTH plugin families, including a phase
    that never ran — the case the document must represent honestly."""
    return [
        (_seg("warm_up::generic::0", "warm_up", None),
         _ev("conversational_rubric", "warm_up::generic::0", phase_id="warm_up",
             marks_earned=2.8, marks_possible=5.0,
             sub_scores={"communication_clarity": 7.0, "role_fit": 4.0},
             view_payload={"dimensions": {"communication_clarity": 7.0, "role_fit": 4.0},
                           "mean_0_10": 5.5, "rationale": "Clear, intern-level depth."})),
        (_seg("tech::q1"),
         _ev("dynamic_difficulty", "tech::q1", marks_earned=4.0, marks_possible=8.0,
             view_payload={"difficulty": "medium", "base_marks": 8.0, "follow_ups": 2,
                           "covered": ["overfitting"], "still_missed": ["regularization"],
                           "verifier_alignment": "agree", "coverage_source": "question",
                           "tags": ["overfitting", "regularization"]})),
        (_seg("tech::q2"),
         _ev("coverage_tags", "tech::q2", marks_earned=2.0, marks_possible=4.0,
             view_payload={"tags": [{"label": "batching", "delta": 2.0, "detail": "covered"},
                                    {"label": "quantisation", "delta": 0.0, "detail": "missing"}],
                           "matched": 1, "total": 2})),
        (_seg("scenario::q1", "scenario_based"),
         _ev("rubric_marks", "scenario::q1", phase_id="scenario_based",
             marks_earned=3.0, marks_possible=5.0,
             view_payload={"criteria": [
                 {"number": 1, "description": "States assumptions", "marks": 2,
                  "selected": True, "applied": 2.0, "note": "listed three"},
                 {"number": 2, "description": "Hand-waves rollout", "marks": -1,
                  "selected": False, "applied": 0.0, "note": ""}],
                 "applicable": [1]})),
        (_seg("coding::q1", "coding_round"),
         _ev("rubric_marks", "coding::q1", phase_id="coding_round",
             state="not_observed", marks_earned=0.0, marks_possible=30.0,
             rationale="Phase did not run.")),
    ]


def test_document_is_versioned_self_describing_and_in_interview_order():
    r = X.build_report(_golden_pairs(),
                       session={"token": "golden-1", "role": "AI Engineer"},
                       generated_at="2026-09-21T00:00:00+00:00")
    doc = json.loads(r.model_dump_json())

    assert doc["report_version"] == X.REPORT_VERSION
    assert doc["generated_at"] == "2026-09-21T00:00:00+00:00"
    assert doc["session"]["token"] == "golden-1"

    # Order is the order they happened — never re-sorted by score or phase.
    assert [s["segment_id"] for s in doc["sections"]] == [
        "warm_up::generic::0", "tech::q1", "tech::q2", "scenario::q1", "coding::q1"]

    # The document validates itself: every emitted section's schema travels
    # with the data, so a consumer needs nothing else from us.
    for s in doc["sections"]:
        assert s["section"] in doc["section_schemas"], f"{s['section']} undeclared"

    # Totals over the four scored sections only: 11.8 / 22.0
    assert doc["totals"]["marks_earned"] == 11.8
    assert doc["totals"]["marks_possible"] == 22.0
    assert doc["totals"]["pct"] == 53.6
    assert doc["totals"]["marks_possible"] != 52.0, "the unobserved 30 marks leaked in"

    # The unobserved phase is present and honest, not omitted and not a zero.
    missed = next(s for s in doc["sections"] if s["segment_id"] == "coding::q1")
    assert missed["state"] == "not_observed"
    assert missed["marks_earned"] is None and missed["marks_possible"] is None
    assert missed["not_scored_reason"]


def test_a_plugin_that_declares_no_section_is_skipped_not_half_emitted():
    # Defensive: if a future plugin ships without a contract, the document
    # drops it rather than emitting an identity-only shell that looks scored.
    pairs = [(_seg("x::q1"), _ev("does_not_exist", "x::q1"))]
    r = X.build_report(pairs)
    assert r.sections == [] and r.totals.segments_total == 0
