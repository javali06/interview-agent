"""Per-question approve/reject, and what partial approval publishes.

The load-bearing test here is
`test_a_rejected_edit_leaves_the_live_question_alone`: partial approval is only
safe if rejecting a change cannot remove something candidates are already being
asked. Everything else is workflow around that guarantee.
"""
from __future__ import annotations

import pytest

from db.engine import reset_engine


AZHAR = "md.azhar@centific.com"              # pool_author @ backend
HARIKA = "puchalapalli.harika@centific.com"  # pool_checker @ backend

Q1 = {"text": "Shard a write-heavy table.", "topic": "databases", "difficulty": "medium"}
Q2 = {"text": "Explain CAP.", "topic": "systems", "difficulty": "easy"}
Q3 = {"text": "Describe a deadlock.", "topic": "databases", "difficulty": "hard"}


@pytest.fixture()
def env(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.setenv("BLOB_ENABLED", "0")
    import app.paths

    monkeypatch.setattr(app.paths, "SESSIONS_DIR", tmp_path, raising=False)
    reset_engine()
    from db.engine import create_all

    create_all()
    from app.rbac_seed import seed_rbac

    seed_rbac()
    from app import rbac

    def uid(email: str) -> int:
        row = rbac.user_by_email(email)
        assert row is not None, email
        return row["id"]

    yield uid
    reset_engine()


def _draft(questions, team="backend", author=AZHAR, name="Backend pool", pool_id=None):
    from app import question_pools as qp

    pool = qp.QuestionPool.model_validate({"pool_name": name, "questions": questions})
    pool.team = team
    pool.created_by = author
    pool.updated_by = author
    return qp.save_draft(pool, pool_id=pool_id).pool_id


def _submit(pool_id, uid):
    from app import approval_service as approvals

    return approvals.submit(pool_id, uid(AZHAR), team_key="backend")


def _review(pool_id, uid, verdicts, comments=None):
    from app import approval_service as approvals
    from app import question_pools as qp

    return approvals.review(
        pool_id,
        uid(HARIKA),
        verdicts,
        comments=comments or {},
        on_publish=lambda ids: qp.publish_approved(pool_id, ids),
    )


def _ids(pool_id, draft=False):
    from app import question_pools as qp

    pool = qp.load_draft(pool_id) if draft else qp.load_pool(pool_id)
    return [q.id for q in pool.questions] if pool else []


# ── the whole point: a rejection must not destroy live content ───────────


def test_a_rejected_edit_leaves_the_live_question_alone(env):
    """Reject a CHANGE to a published question and candidates keep getting the
    last reviewed wording — not nothing."""
    from app import question_pools as qp

    pool_id = _draft([Q1, Q2])
    _submit(pool_id, env)
    first = _ids(pool_id)[:0] or None            # nothing published yet
    assert first is None
    # publish both
    qids = [q.id for q in qp.load_draft(pool_id).questions]
    _review(pool_id, env, {q: "approved" for q in qids})
    live_before = {q.id: q.text for q in qp.load_pool(pool_id).questions}
    assert len(live_before) == 2

    # now edit BOTH and have one edit rejected
    edited = [
        {"id": qids[0], "text": "REWRITTEN shard question.", "topic": "databases", "difficulty": "medium"},
        {"id": qids[1], "text": "REWRITTEN cap question.", "topic": "systems", "difficulty": "easy"},
    ]
    _draft(edited, pool_id=pool_id)
    _submit(pool_id, env)
    _review(
        pool_id,
        env,
        {qids[0]: "approved", qids[1]: "rejected"},
        comments={qids[1]: "Too vague — name the trade-off."},
    )

    live_after = {q.id: q.text for q in qp.load_pool(pool_id).questions}
    assert live_after[qids[0]] == "REWRITTEN shard question."   # approved edit landed
    assert live_after[qids[1]] == live_before[qids[1]]          # rejected edit did NOT


def test_partial_approval_publishes_the_approved_and_returns_the_rest(env):
    pool_id = _draft([Q1, Q2, Q3])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    status = _review(
        pool_id,
        env,
        {qids[0]: "approved", qids[1]: "approved", qids[2]: "rejected"},
        comments={qids[2]: "Ambiguous."},
    )
    assert sorted(_ids(pool_id)) == sorted(qids[:2])    # two went live
    assert _ids(pool_id, draft=True) == [qids[2]]       # the rejected one is the work left
    assert status["state"] == "draft"                   # back with the author


def test_approving_the_fixed_question_keeps_the_ones_approved_earlier(env):
    """After a partial review the draft holds only the rejected question, so
    approving all of it must merge, not replace the live pool with it."""
    pool_id = _draft([Q1, Q2, Q3])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    _review(
        pool_id,
        env,
        {qids[0]: "approved", qids[1]: "approved", qids[2]: "rejected"},
        comments={qids[2]: "Ambiguous."},
    )

    fixed = {"id": qids[2], "text": "Describe a deadlock and one way to prevent it.",
             "topic": "databases", "difficulty": "hard"}
    _draft([fixed], pool_id=pool_id)
    _submit(pool_id, env)
    _review(pool_id, env, {qids[2]: "approved"})

    assert sorted(_ids(pool_id)) == sorted(qids)        # nothing approved earlier was lost
    assert _ids(pool_id, draft=True) == []


def test_approving_everything_behaves_exactly_like_approve_all(env):
    """The bulk button is the same code path, so it cannot drift."""
    pool_id = _draft([Q1, Q2])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    status = _review(pool_id, env, {q: "approved" for q in qids})
    assert status["state"] == "published"
    assert sorted(_ids(pool_id)) == sorted(qids)
    from app import question_pools as qp

    assert qp.load_draft(pool_id) is None     # nothing outstanding -> draft gone


def test_rejecting_everything_publishes_nothing(env):
    from app import question_pools as qp

    pool_id = _draft([Q1, Q2])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    status = _review(
        pool_id, env,
        {q: "rejected" for q in qids},
        comments={q: "No." for q in qids},
    )
    assert status["state"] == "draft"
    assert qp.load_pool(pool_id) is None               # never went live
    assert sorted(_ids(pool_id, draft=True)) == sorted(qids)


# ── the refusals ─────────────────────────────────────────────────────────


def test_a_rejection_without_a_reason_is_refused(env):
    from app import approval_service as approvals

    pool_id = _draft([Q1, Q2])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    with pytest.raises(approvals.ApprovalError) as e:
        _review(pool_id, env, {qids[0]: "approved", qids[1]: "rejected"})
    assert e.value.code == "comment_required"


def test_an_empty_review_is_refused(env):
    from app import approval_service as approvals

    pool_id = _draft([Q1])
    _submit(pool_id, env)
    with pytest.raises(approvals.ApprovalError) as e:
        _review(pool_id, env, {})
    assert e.value.code == "no_verdicts"


def test_an_invalid_verdict_publishes_nothing(env):
    """A value other than approved/rejected must not be dropped. Dropping it
    publishes the rest and treats the gap as a rejection, with no return."""
    from app import approval_service as approvals
    from app import question_pools as qp

    pool_id = _draft([Q1, Q2])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    with pytest.raises(approvals.ApprovalError) as e:
        _review(pool_id, env, {qids[0]: "approved", qids[1]: "maybe"})
    assert e.value.code == "invalid_verdict"
    assert qp.load_pool(pool_id) is None
    assert approvals.pool_status(pool_id)["state"] == "pending"
    assert _verdict_rows(pool_id) == 0
    assert [h["action"] for h in approvals.history(pool_id)] == ["submitted"]


def test_the_author_cannot_review_their_own_pool(env):
    """Per-question review inherits the self-approval refusal, because it
    delegates to the same transition rather than reimplementing it."""
    from app import approval_service as approvals
    from app import question_pools as qp

    pool_id = _draft([Q1])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    with pytest.raises(approvals.ApprovalError):
        approvals.review(
            pool_id, env(AZHAR), {qids[0]: "approved"},
            on_publish=lambda ids: qp.publish_approved(pool_id, ids),
        )


def _verdict_rows(pool_id):
    from db.engine import session_scope
    from db.models import PoolQuestionReview

    with session_scope() as s:
        return s.query(PoolQuestionReview).filter_by(pool_id=pool_id).count()


def test_the_author_cannot_publish_part_of_their_own_pool(env):
    """A mixed review publishes, so it must refuse self-approval BEFORE anything
    goes live — and must not leave the refused verdicts behind."""
    from app import approval_service as approvals
    from app import question_pools as qp

    pool_id = _draft([Q1, Q2])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    with pytest.raises(approvals.ApprovalError) as e:
        approvals.review(
            pool_id, env(AZHAR), {qids[0]: "approved", qids[1]: "rejected"},
            comments={qids[1]: "Mine, but no."},
            on_publish=lambda ids: qp.publish_approved(pool_id, ids),
        )
    assert e.value.code == "self_approval"
    assert qp.load_pool(pool_id) is None                       # nothing went live
    assert approvals.pool_status(pool_id)["state"] == "pending"
    assert _verdict_rows(pool_id) == 0                         # no stray verdicts


def test_a_wrong_team_checker_cannot_publish_part_of_a_pool(env):
    from app import approval_service as approvals
    from app import question_pools as qp

    hasini = "hasini.gandhe@centific.com"                      # pool_author @ qa
    pool_id = _draft([Q1, Q2], team="qa", author=hasini, name="QA pool")
    approvals.submit(pool_id, env(hasini), team_key="qa")
    qids = _ids(pool_id, draft=True)
    with pytest.raises(approvals.ApprovalError) as e:
        _review(pool_id, env, {qids[0]: "approved", qids[1]: "rejected"},
                comments={qids[1]: "No."})                     # HARIKA: backend only
    assert e.value.code == "wrong_team"
    assert qp.load_pool(pool_id) is None
    assert _verdict_rows(pool_id) == 0


def test_a_partial_review_is_recorded_as_a_publish(env):
    """What went live must appear in the ledger and the audit log."""
    from sqlalchemy import select

    from app import approval_service as approvals
    from db.engine import session_scope
    from db.models import AuditLog

    pool_id = _draft([Q1, Q2])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    _review(pool_id, env, {qids[0]: "approved", qids[1]: "rejected"},
            comments={qids[1]: "No."})
    actions = [h["action"] for h in approvals.history(pool_id)]
    assert actions == ["submitted", "approved", "published", "returned"]
    with session_scope() as s:
        assert "pool.published" in s.execute(select(AuditLog.action)).scalars().all()


@pytest.mark.xfail(
    strict=True,
    reason="Approve all merges by id, as production did, because after a partial review the "
           "draft holds only the rejected questions and copying it would drop live ones. "
           "Applying an author's deletion here needs the draft to keep the whole pool.",
)
def test_review_approve_all_publishes_what_approve_publishes(env):
    """Both "Approve all" buttons must leave the same live pool — including an
    author's deletion, which a merge by id would silently undo."""
    from app import question_pools as qp

    pool_id = _draft([Q1, Q2])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    _review(pool_id, env, {q: "approved" for q in qids})

    kept = qp.load_pool(pool_id).questions[0]
    _draft([kept.model_dump()], pool_id=pool_id)               # author deletes one
    _submit(pool_id, env)
    _review(pool_id, env, {kept.id: "approved"})
    assert _ids(pool_id) == [kept.id]                           # deletion took effect


def test_a_partial_review_at_an_earlier_step_publishes_nothing(env):
    """On a two-step chain the first checker cannot put anything live."""
    from sqlalchemy import select

    from app import question_pools as qp
    from db.engine import session_scope
    from db.models import AppApprovalStep, AppRole, AppTeam

    with session_scope() as s:
        team_id = s.execute(select(AppTeam.id).where(AppTeam.key == "backend")).scalar_one()
        role_id = s.execute(select(AppRole.id).where(AppRole.key == "pool_checker")).scalar_one()
        s.add(AppApprovalStep(team_id=team_id, step_no=1, approver_role_id=role_id, name="Lead"))
        s.add(AppApprovalStep(team_id=team_id, step_no=2, approver_role_id=role_id, name="Gov"))

    pool_id = _draft([Q1, Q2])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    status = _review(pool_id, env, {qids[0]: "approved", qids[1]: "rejected"},
                     comments={qids[1]: "No."})
    assert qp.load_pool(pool_id) is None
    assert status["state"] == "draft"
    assert sorted(_ids(pool_id, draft=True)) == sorted(qids)   # all still to do


def test_reviewing_a_pool_that_is_not_pending_is_refused(env):
    from app import approval_service as approvals

    pool_id = _draft([Q1])                # never submitted
    qids = _ids(pool_id, draft=True)
    with pytest.raises(approvals.ApprovalError) as e:
        _review(pool_id, env, {qids[0]: "approved"})
    assert e.value.code == "not_pending"


# ── the record ───────────────────────────────────────────────────────────


def test_verdicts_are_readable_afterwards_with_their_comments(env):
    from app import approval_service as approvals

    pool_id = _draft([Q1, Q2])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    cycle = approvals.pool_status(pool_id)["cycle_id"]
    _review(
        pool_id, env,
        {qids[0]: "approved", qids[1]: "rejected"},
        comments={qids[1]: "Name the trade-off."},
    )
    seen = approvals.question_reviews(pool_id, cycle_id=cycle)
    assert seen[qids[0]]["verdict"] == "approved"
    assert seen[qids[1]]["verdict"] == "rejected"
    assert seen[qids[1]]["comment"] == "Name the trade-off."
    assert seen[qids[1]]["by"] == HARIKA


def test_changing_your_mind_keeps_the_history_and_the_latest_wins(env):
    """Append-only: a second verdict supersedes without erasing the first."""
    from app import approval_service as approvals
    from db.engine import session_scope
    from db.models import PoolQuestionReview

    pool_id = _draft([Q1, Q2])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    cycle = approvals.pool_status(pool_id)["cycle_id"]
    # first pass rejects both, which returns the pool
    _review(pool_id, env, {q: "rejected" for q in qids}, comments={q: "no" for q in qids})
    _submit(pool_id, env)
    cycle2 = approvals.pool_status(pool_id)["cycle_id"]
    assert cycle2 != cycle
    _review(pool_id, env, {q: "approved" for q in qids})

    with session_scope() as s:
        rows = s.query(PoolQuestionReview).filter_by(pool_id=pool_id).all()
        assert len(rows) == 4           # both passes survive
    assert approvals.question_reviews(pool_id, cycle_id=cycle2)[qids[0]]["verdict"] == "approved"


def test_the_author_can_still_read_the_comments_after_the_return(env):
    """The moment the author needs the feedback is AFTER the pool comes back —
    by which time the cycle has closed. If verdicts were only readable while
    pending, per-question rejection would tell them nothing."""
    from app import approval_service as approvals

    pool_id = _draft([Q1, Q2])
    _submit(pool_id, env)
    qids = _ids(pool_id, draft=True)
    _review(
        pool_id, env,
        {qids[0]: "approved", qids[1]: "rejected"},
        comments={qids[1]: "Name the eviction policy."},
    )
    assert approvals.pool_status(pool_id)["state"] == "draft"   # cycle is closed
    seen = approvals.question_reviews(pool_id)                  # no cycle passed
    assert seen[qids[1]]["verdict"] == "rejected"
    assert seen[qids[1]]["comment"] == "Name the eviction policy."
