"""User-authored question pools: validation, Blob round-trip, and the merged
listing/resolution that lets a hand-written pool feed a cadence exactly like a
pool shipped in the image.

No LLM anywhere in this feature, so every test here is deterministic.
"""
from __future__ import annotations

import pathlib
import uuid

import pytest
import yaml as _yaml
from fastapi.testclient import TestClient


@pytest.fixture()
def pools(tmp_path, monkeypatch):
    """Blob DISABLED on purpose — exercises blob_store's disk fallback, which is
    what a local/dev box actually runs. The cloud path is the same code with a
    container client instead."""
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path / "sessions"))
    monkeypatch.setenv("BLOB_ENABLED", "0")
    import importlib
    from app import blob_store, paths
    importlib.reload(paths)
    importlib.reload(blob_store)
    from app import question_pools as qp
    importlib.reload(qp)
    return qp


def _q(text, topic="general", difficulty="easy", tags=None):
    return {"text": text, "topic": topic, "difficulty": difficulty,
            "coverage_tags": tags or ["a point"]}


# ── validation ───────────────────────────────────────────────────────────────
def test_a_pool_needs_at_least_one_question(pools):
    with pytest.raises(ValueError, match="at least one question"):
        pools.QuestionPool.model_validate({"pool_name": "X", "questions": []})


def test_difficulty_is_constrained(pools):
    with pytest.raises(ValueError, match="difficulty must be"):
        pools.QuestionPool.model_validate(
            {"pool_name": "X", "questions": [_q("t", difficulty="trivial")]})


def test_question_ids_are_derived_and_uniquified(pools):
    # Ids key the question at runtime, so a duplicate would make the tracker
    # treat two questions as one. They are generated here, never trusted.
    pool = pools.QuestionPool.model_validate({"pool_name": "X", "questions": [
        _q("Tell me about a hard day."), _q("Tell me about a hard day."),
    ]})
    ids = [q.id for q in pool.questions]
    assert len(set(ids)) == 2 and ids[1].endswith("_2")


def test_topics_are_normalised_so_the_filter_matches(pools):
    # The customizer filters topics slug-wise; "De-escalation" and
    # "de escalation" must not become two categories.
    pool = pools.QuestionPool.model_validate({"pool_name": "X", "questions": [
        _q("a", topic="De-escalation"), _q("b", topic="de escalation"),
    ]})
    assert {q.topic for q in pool.questions} == {"de_escalation"}


def test_coverage_tags_accept_a_pasted_string(pools):
    pool = pools.QuestionPool.model_validate(
        {"pool_name": "X", "questions": [_q("a", tags="stays calm, offers a fix")]})
    assert pool.questions[0].coverage_tags == ["stays calm", "offers a fix"]


# ── storage round-trip ───────────────────────────────────────────────────────
def test_save_load_list_delete_round_trip(pools):
    pool = pools.QuestionPool.model_validate({
        "pool_name": "Customer Support", "description": "Front line.",
        "questions": [_q("How do you calm an angry caller?", topic="de_escalation")],
    })
    saved = pools.save_pool(pool)
    assert saved.pool_id and saved.updated_at

    got = pools.load_pool(saved.pool_id)
    assert got is not None and got.pool_name == "Customer Support"

    listed = pools.list_pools()
    assert [p["pool_name"] for p in listed] == ["Customer Support"]
    assert listed[0]["source"] == "custom" and listed[0]["editable"] is True

    assert pools.delete_pool(saved.pool_id)
    assert pools.load_pool(saved.pool_id) is None


@pytest.mark.parametrize("bad", ["../../etc/passwd", "a/b", "a\\b", "", "x" * 80])
def test_pool_ids_that_could_escape_the_prefix_are_refused(pools, bad):
    assert pools.load_pool(bad) is None
    assert pools.delete_pool(bad) is False


def test_the_exported_yaml_is_the_builtin_file_shape(pools):
    # So a pool authored in the UI can be committed to questions_pool/ verbatim.
    pool = pools.QuestionPool.model_validate({
        "pool_name": "Sales", "questions": [_q("Q?", topic="discovery")]})
    data = _yaml.safe_load(pools.save_pool(pool).to_yaml())
    assert set(data) >= {"pool_name", "description", "questions"}
    q = data["questions"][0]
    assert set(q) == {"id", "text", "topic", "difficulty", "coverage_tags"}


def test_an_unreadable_pool_is_skipped_not_fatal(pools, tmp_path):
    # One corrupt file must not hide every other pool from the list.
    good = pools.save_pool(pools.QuestionPool.model_validate(
        {"pool_name": "Good", "questions": [_q("q")]}))
    from app import blob_store
    import io
    blob_store.upload_fileobj(io.BytesIO(b"{{ not yaml"),
                              f"{pools.BLOB_PREFIX}broken.yaml")
    names = [p["pool_name"] for p in pools.list_pools()]
    assert names == ["Good"] and good.pool_id


# ── the integration that matters: a custom pool feeding a cadence ────────────
class _AutoPublishClient(TestClient):
    """A client whose pool CREATE and DUPLICATE also publish.

    Since maker-checker landed, those routes write a DRAFT and interviews read
    only published pools. Every test below is about pool CONTENT — validation,
    assets, kinds, what `for-phase` filters — so each one would otherwise need
    an approval step that has nothing to do with what it is checking.

    Publishing here, in one named place, keeps those tests about their subject.
    The workflow itself (submit / approve / return / refusals, and the fact that
    a draft is unreachable from a cadence) is covered in
    tests/test_pool_approvals.py, which is where it belongs.
    """

    def post(self, url, *args, **kwargs):
        r = super().post(url, *args, **kwargs)
        if (
            str(url).rstrip("/") in ("/api/question-pools",
                                     "/api/question-pools/duplicate")
            and r.status_code == 200
        ):
            from app import question_pools as _qp

            pool_id = r.json().get("pool_id")
            if pool_id and _qp.has_draft(pool_id):
                _qp.publish_draft(pool_id)
        return r


@pytest.fixture()
def api(pools, tmp_path, monkeypatch):
    import app.main as M

    # Authentication: the legacy dependency the routers are mounted behind.
    monkeypatch.setattr(M.app, "dependency_overrides",
                        {M._api_require_user: lambda: {"username": "admin"}},
                        raising=False)
    M.app.dependency_overrides[M._api_require_user] = lambda: {"username": "admin"}

    # Authorisation: each pool route now also asks WHICH person this is. Seed a
    # throwaway RBAC database and answer as the platform admin, so these tests
    # stay about pools rather than about permissions.
    monkeypatch.delenv("DATABASE_URL", raising=False)
    from app.paths import SESSIONS_DIR
    from db.engine import create_all, reset_engine

    # `pools` points SESSIONS_DIR at a tmp path but never creates it, and the
    # sqlite file cannot be opened inside a directory that is not there.
    pathlib.Path(SESSIONS_DIR).mkdir(parents=True, exist_ok=True)
    reset_engine()
    create_all()
    from app.rbac_seed import seed_rbac

    seed_rbac()

    from app import rbac

    admin = rbac.user_by_email("ayush.kothiyal@centific.com")
    monkeypatch.setattr(rbac, "current_user_id", lambda request: admin["id"])

    yield M, _AutoPublishClient(M.app)
    reset_engine()


_CADENCE = _yaml.safe_dump({"total_duration_s": 120, "phases": [
    {"id": "warm_up", "duration_s": 60, "intent": "Ease in.",
     "question_mode": "generic", "generic_prompts": ["go"]},
    {"id": "wrap_up", "duration_s": 60, "intent": "Close.",
     "question_mode": "generic", "generic_prompts": ["bye"]},
]}, sort_keys=False)


def test_a_custom_pool_is_listed_beside_the_builtins(api):
    _M, c = api
    r = c.post("/api/question-pools", json={
        "pool_name": "Customer Support", "description": "",
        "questions": [_q("How do you calm an angry caller?", topic="de_escalation")]})
    assert r.status_code == 200, r.text
    listed = c.get("/api/question-pools").json()["pools"]
    sources = {p["source"] for p in listed}
    assert "custom" in sources and "builtin" in sources
    builtin = next(p for p in listed if p["source"] == "builtin")
    assert builtin["editable"] is False        # shipped pools can't be edited in place


def test_a_custom_pool_can_be_applied_to_a_cadence(api, monkeypatch):
    M, c = api
    made = c.post("/api/question-pools", json={
        "pool_name": "Support", "description": "",
        "questions": [
            _q("How do you calm an angry caller?", topic="de_escalation"),
            _q("How do you refuse a request?", topic="de_escalation"),
        ]}).json()
    token = str(uuid.uuid4())
    monkeypatch.setattr(M.db, "get", lambda t: {
        "token": token, "role": "Support", "cadence_yaml": _CADENCE,
        "candidate_name": "Sam", "status": "draft"})
    r = c.post(f"/api/cadence/{token}/customize", json={
        "yaml": _CADENCE, "difficulty": "easy", "phase": "__other__",
        "custom_phase_name": "support_screen", "anchor_phase": "warm_up",
        "pool_file": made["pool_id"], "count": 2, "topics": "de_escalation"})
    assert r.status_code == 200 and r.json().get("ok"), r.text
    phase = next(p for p in _yaml.safe_load(r.json()["yaml"])["phases"]
                 if p["id"] == "support_screen")
    assert phase["question_mode"] == "specific"
    assert phase["question_pool"], "no questions injected"
    assert phase["question_pool"][0]["coverage_tags"]   # the verifier's checklist


def test_the_builtin_pool_still_applies_unchanged(api, monkeypatch):
    # The shared resolver must not regress the path that already worked.
    M, c = api
    token = str(uuid.uuid4())
    monkeypatch.setattr(M.db, "get", lambda t: {
        "token": token, "role": "AI Engineer", "cadence_yaml": _CADENCE,
        "candidate_name": "Sam", "status": "draft"})
    r = c.post(f"/api/cadence/{token}/customize", json={
        "yaml": _CADENCE, "difficulty": "easy", "phase": "warm_up",
        "pool_file": "ai_engineer_pool.yaml", "count": 2})
    assert r.status_code == 200 and r.json().get("ok"), r.text


def test_customize_refuses_a_traversal_pool_ref(api, monkeypatch):
    M, c = api
    token = str(uuid.uuid4())
    monkeypatch.setattr(M.db, "get", lambda t: {
        "token": token, "role": "X", "cadence_yaml": _CADENCE,
        "candidate_name": "Sam", "status": "draft"})
    r = c.post(f"/api/cadence/{token}/customize", json={
        "yaml": _CADENCE, "difficulty": "easy", "phase": "warm_up",
        "pool_file": "../../etc/passwd", "count": 1})
    assert r.status_code == 400


def test_duplicating_a_builtin_yields_an_editable_copy(api):
    _M, c = api
    r = c.post("/api/question-pools/duplicate", json={"source": "ai_engineer_pool.yaml"})
    assert r.status_code == 200, r.text
    copy = r.json()
    # A copy lands as a DRAFT now (it is new work, and goes through the chain
    # like anything else) -- but it is editable, which is the point here: the
    # built-in it came from is not.
    assert copy["editable"] is True and copy["source"] != "builtin"
    assert copy["question_count"] > 0
    assert copy["pool_id"] != "ai_engineer_pool.yaml"   # never overwrites the source


def test_creating_a_pool_with_no_questions_is_a_400_not_a_500(api):
    _M, c = api
    r = c.post("/api/question-pools", json={"pool_name": "X", "description": "", "questions": []})
    assert r.status_code == 400
    assert "question" in r.json()["detail"].lower()


# ── pool kinds: pools can hold written tasks, not just spoken questions ──────
# The whole point is extensibility — the kinds come from the question-type
# registry, so adding one (MCQ, say) is one entry there and this module, the
# API, the editor form and the validator all pick it up unchanged.
_KIND_MATERIAL = {
    "spoken": {},
    "comprehensive": {"written_response": {"char_limit": 1500}},
    "translation": {"written_response": {"char_limit": 600, "source_text": "Hello.",
                                         "source_language": "en", "target_language": "es"}},
    "transcription": {"written_response": {"char_limit": 800, "audio_asset": "clip.mp3",
                                           "source_language": "en", "target_language": "en"}},
    "image_description": {"written_response": {"char_limit": 900, "image_asset": "pic.png"}},
}


def test_the_kinds_come_from_the_question_type_registry(pools):
    # The WRITTEN kinds are never listed by hand — they come from the registry,
    # so adding one there is all it takes. Spoken, coding and scenario sit
    # outside it because none is a written_response: spoken has no material at
    # all, coding carries its own block (starter code / tests / solution), and
    # scenario carries its own block (media reference + follow-up cap).
    from engine.brain.cadence import question_types as qt_mod
    assert pools.pool_kind_ids() == (
        pools.SPOKEN_KIND, pools.CODING_KIND, pools.SCENARIO_KIND,
        *qt_mod.QUESTION_TYPE_IDS)
    # is_written_kind must EXCLUDE coding and scenario — treating either as
    # written sends it to WrittenResponse(question_type=...), which raises.
    assert not pools.is_written_kind(pools.CODING_KIND)
    assert not pools.is_written_kind(pools.SCENARIO_KIND)
    assert not pools.is_written_kind(pools.SPOKEN_KIND)
    assert all(pools.is_written_kind(k) for k in qt_mod.QUESTION_TYPE_IDS)


@pytest.mark.parametrize("kind", list(_KIND_MATERIAL))
def test_a_pool_of_each_kind_saves_and_round_trips(pools, kind):
    pool = pools.QuestionPool.model_validate({
        "pool_name": f"{kind} bank",
        "questions": [{"kind": kind, "text": "Do the task.", "topic": "general",
                       "difficulty": "easy", "coverage_tags": ["a"],
                       **_KIND_MATERIAL[kind]}]})
    saved = pools.save_pool(pool)
    got = pools.load_pool(saved.pool_id)
    assert got is not None and got.questions[0].kind == kind
    assert got.summary()["kinds"] == [kind]
    if kind != pools.SPOKEN_KIND:
        assert got.questions[0].written_response is not None


def test_a_written_question_is_validated_by_the_cadence_rules(pools):
    # Reusing WrittenResponse.resolved_for(...).missing_requirements() is what
    # stops a pooled question passing here and failing when it reaches a phase.
    with pytest.raises(ValueError, match="source_text"):
        pools.QuestionPool.model_validate({
            "pool_name": "bad",
            "questions": [{"kind": "translation", "text": "t",
                           "written_response": {"char_limit": 100}}]})


def test_material_foreign_to_the_kind_is_refused(pools):
    with pytest.raises(ValueError, match="Question 1"):
        pools.QuestionPool.model_validate({
            "pool_name": "bad",
            "questions": [{"kind": "comprehensive", "text": "t",
                           "written_response": {"char_limit": 100, "source_text": "x"}}]})


def test_an_unknown_kind_is_refused(pools):
    with pytest.raises(ValueError, match="kind must be one of"):
        pools.QuestionPool.model_validate({
            "pool_name": "x", "questions": [{"kind": "mcq", "text": "t"}]})


def test_a_spoken_pool_drops_stray_written_material(pools):
    # It would be silently ignored when applied, so don't store it.
    pool = pools.QuestionPool.model_validate({
        "pool_name": "s",
        "questions": [{"kind": "spoken", "text": "t",
                       "written_response": {"char_limit": 10}}]})
    assert pool.questions[0].written_response is None


def test_pools_authored_before_kinds_existed_default_to_spoken(pools):
    # No pool_kind in the stored YAML → the classic conversational pool.
    pool = pools.QuestionPool.model_validate({
        "pool_name": "legacy", "questions": [{"text": "t"}]})
    assert pool.questions[0].kind == pools.SPOKEN_KIND


# ── applying a pool to a phase ───────────────────────────────────────────────
def test_for_phase_copies_assets_into_the_interview(pools, api, tmp_path):
    """A pool is a TEMPLATE: its clip must be copied into the interview, so
    deleting or editing the pool later can't break an approved cadence."""
    import io
    import uuid as _uuid
    from app import blob_store
    _M, c = api

    made = c.post("/api/question-pools", json={
        "pool_name": "Clips", "description": "",
        "questions": [{"kind": "transcription", "text": "Transcribe it.",
                       "topic": "audio", "difficulty": "easy",
                       "coverage_tags": [],
                       "written_response": {"char_limit": 800, "audio_asset": "clip.mp3",
                                            "source_language": "en", "target_language": "en"}}]}).json()
    pid = made["pool_id"]
    # the asset the question references (flat namespace — not scoped to a pool,
    # so it can be uploaded before the pool exists)
    blob_store.upload_fileobj(io.BytesIO(b"ID3fake"), "question_pool_assets/clip.mp3")

    token = str(_uuid.uuid4())
    r = c.get(f"/api/question-pools/{pid}/for-phase?token={token}")
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["questions"][0]["kind"] == "transcription"
    assert body["assets_copied"] == 1 and body["assets_missing"] == []
    # copied into the INTERVIEW's own folder
    assert blob_store.download_bytes(f"{token}/phase_assets/clip.mp3") == b"ID3fake"
    # and the question carries its material through
    assert body["questions"][0]["written_response"]["audio_asset"] == "clip.mp3"


def test_for_phase_reports_a_missing_asset_rather_than_silently_succeeding(pools, api):
    # Handing over a phase whose clip the candidate can't load would surface as
    # a broken interview, not an authoring error.
    import uuid as _uuid
    _M, c = api
    made = c.post("/api/question-pools", json={
        "pool_name": "Clips2", "description": "",
        "questions": [{"kind": "transcription", "text": "Transcribe.",
                       "topic": "a", "difficulty": "easy",
                       "coverage_tags": [],
                       "written_response": {"char_limit": 500, "audio_asset": "gone.mp3",
                                            "source_language": "en", "target_language": "en"}}]}).json()
    r = c.get(f"/api/question-pools/{made['pool_id']}/for-phase?token={_uuid.uuid4()}").json()
    assert r["assets_missing"] == ["gone.mp3"] and r["assets_copied"] == 0


def test_duplicating_a_written_pool_keeps_its_kind(pools, api):
    # Copied as "spoken" it would fail validation and lose all its material.
    _M, c = api
    made = c.post("/api/question-pools", json={
        "pool_name": "Tr", "description": "",
        "questions": [{"kind": "translation", "text": "T.", "topic": "a",
                       "difficulty": "easy", "coverage_tags": [],
                       "written_response": {"char_limit": 600, "source_text": "Hello.",
                                            "source_language": "en", "target_language": "es"}}]}).json()
    copy = c.post("/api/question-pools/duplicate", json={"source": made["pool_id"]}).json()
    assert copy["kinds"] == ["translation"]
    detail = c.get(f"/api/question-pools/{copy['pool_id']}").json()
    assert detail["questions"][0]["written_response"]["source_text"] == "Hello."


def test_the_kinds_catalog_drives_the_editor_form(pools, api):
    # The form renders from THIS, so a new question type needs no frontend edit.
    _M, c = api
    r = c.get("/api/question-pools/kinds").json()
    ids = [k["id"] for k in r["kinds"]]
    assert ids[0] == "spoken" and "translation" in ids
    tr = next(k for k in r["kinds"] if k["id"] == "translation")
    names = {f["name"] for f in tr["fields"]}
    assert {"source_text", "source_language", "target_language"} <= names
    assert r["languages"], "the language catalog must ride along for the dropdowns"
    spoken = next(k for k in r["kinds"] if k["id"] == "spoken")
    assert spoken["written"] is False and spoken["fields"] == []
    # The id stays "spoken" (storage-compatible with every pool already saved);
    # only the admin-facing label changed to match the cadence's own
    # generic/SPECIFIC terminology for a pre-written, pool-backed question.
    assert spoken["label"] == "Specific question"


def test_an_asset_filename_cannot_escape_the_asset_folder(pools):
    # Refused outright rather than quietly rewritten — a caller that meant to
    # escape gets an error, not a file at a surprising path. Reading back by a
    # traversal path likewise finds nothing.
    with pytest.raises(ValueError, match="unsafe file name"):
        pools.store_asset("audio", "../../evil.mp3", b"x")
    assert pools.load_asset("../../evil.mp3") is None
    # an ordinary name still works, and is uniquified
    ok = pools.store_asset("audio", "clip.mp3", b"ID3x")
    assert ok.endswith("_clip.mp3") and "/" not in ok


def test_an_asset_can_be_uploaded_before_its_pool_exists(pools, api):
    # The whole point of the flat namespace: the upload control must work while
    # the admin is still composing a pool that has no id yet.
    _M, c = api
    r = c.post("/api/question-pools/assets?kind=image",
               files={"file": ("cat.png", b"\x89PNG\r\n\x1a\n" + b"x" * 64, "image/png")})
    assert r.status_code == 200, r.text
    name = r.json()["name"]
    assert name.endswith("_cat.png") and name != "cat.png"   # uniquified
    assert c.get(r.json()["url"]).status_code == 200          # previewable


def test_a_wrong_file_type_is_refused_at_upload(pools, api):
    _M, c = api
    r = c.post("/api/question-pools/assets?kind=image",
               files={"file": ("evil.exe", b"MZ", "application/octet-stream")})
    assert r.status_code == 400 and "png" in r.json()["detail"]


def test_one_pool_can_mix_kinds_and_a_phase_pulls_only_its_own(pools, api):
    """The point of per-question kinds: a single pool serves several phases."""
    import uuid as _uuid
    _M, c = api
    made = c.post("/api/question-pools", json={
        "pool_name": "Mixed", "description": "", "questions": [
            {"kind": "spoken", "text": "Tell me about a hard day.", "topic": "general",
             "difficulty": "easy", "coverage_tags": ["a specific example"]},
            {"kind": "comprehensive", "text": "Describe your approach.",
             "written_response": {"char_limit": 1500}},
            {"kind": "translation",
             "written_response": {"char_limit": 600, "source_text": "Hello there.",
                                  "source_language": "en", "target_language": "es"}},
        ]})
    assert made.status_code == 200, made.text
    assert made.json()["kinds"] == ["comprehensive", "spoken", "translation"]

    token = str(_uuid.uuid4())
    for want, expected in [("spoken", 1), ("comprehensive", 1),
                           ("translation", 1), ("transcription", 0)]:
        r = c.get(f"/api/question-pools/{made.json()['pool_id']}"
                  f"/for-phase?token={token}&kind={want}").json()
        assert len(r["questions"]) == expected, want
        assert all(q["kind"] == want for q in r["questions"])


def test_a_prompt_hidden_kind_has_its_question_synthesised(pools, api):
    # Translation never takes a hand-written instruction — it is built from the
    # question's own language pair, exactly as the cadence builder does, so the
    # two can't drift apart.
    _M, c = api
    made = c.post("/api/question-pools", json={
        "pool_name": "Tr2", "description": "", "questions": [
            {"kind": "translation",
             "written_response": {"char_limit": 600, "source_text": "Hi.",
                                  "source_language": "en", "target_language": "fr"}}]})
    assert made.status_code == 200, made.text
    q = c.get(f"/api/question-pools/{made.json()['pool_id']}").json()["questions"][0]
    assert q["text"] == "Translate the text below from English into French."


def test_a_spoken_question_still_needs_its_text(pools):
    with pytest.raises(ValueError, match="question text"):
        pools.QuestionPool.model_validate({
            "pool_name": "x", "questions": [{"kind": "spoken", "text": "  "}]})


# ── ground truth: the shape depends on the kind ──────────────────────────────
# transcription wants ONE exact transcript (a string); translation and image
# description want a LIST of accepted answers. The editor renders a plain box
# for the first and an add/remove row list for the others — getting that wrong
# stored a string where the schema demands a list, and the pool then failed to
# LOAD with a raw pydantic error the author could do nothing about.
def test_ground_truth_shape_is_enforced_per_kind(pools, api):
    _M, c = api
    bad = c.post("/api/question-pools", json={
        "pool_name": "bad", "description": "", "questions": [
            {"kind": "image_description", "text": "Describe it.",
             "written_response": {"char_limit": 900, "image_asset": "x.png",
                                  "ground_truth": "tell me about it"}}]})
    assert bad.status_code == 400
    assert "list of strings" in bad.json()["detail"]


def test_each_kind_round_trips_its_own_ground_truth_shape(pools, api):
    import uuid as _uuid
    _M, c = api
    r = c.post("/api/question-pools", json={
        "pool_name": "gt", "description": "", "questions": [
            {"kind": "image_description", "text": "Describe it.",
             "written_response": {"char_limit": 900, "image_asset": "x.png",
                                  "ground_truth": ["a grey cat", "white background"]}},
            {"kind": "transcription",
             "written_response": {"char_limit": 800, "audio_asset": "c.mp3",
                                  "source_language": "en", "target_language": "en",
                                  "ground_truth": "the exact transcript"}},
            {"kind": "translation",
             "written_response": {"char_limit": 600, "source_text": "Hello.",
                                  "source_language": "en", "target_language": "es",
                                  "ground_truth": ["Hola.", "Buenas."]}}]})
    assert r.status_code == 200, r.text
    by_kind = {q["kind"]: q for q in
               c.get(f"/api/question-pools/{r.json()['pool_id']}").json()["questions"]}
    assert by_kind["image_description"]["written_response"]["ground_truth"] == \
        ["a grey cat", "white background"]
    assert by_kind["transcription"]["written_response"]["ground_truth"] == \
        "the exact transcript"
    # and it survives into the phase, where the scorer reads it
    got = c.get(f"/api/question-pools/{r.json()['pool_id']}/for-phase"
                f"?token={_uuid.uuid4()}&kind=translation").json()
    assert got["questions"][0]["written_response"]["ground_truth"] == ["Hola.", "Buenas."]


def test_the_catalog_tells_the_form_which_control_to_render(pools, api):
    # A list field rendered as a plain text box is exactly how the wrong type got
    # stored, so the kind (and the stricter authoring requirement) must ship.
    _M, c = api
    kinds = {k["id"]: k for k in c.get("/api/question-pools/kinds").json()["kinds"]}
    gt = {kid: next(f for f in k["fields"] if f["name"] == "ground_truth")
          for kid, k in kinds.items()
          if any(f["name"] == "ground_truth" for f in k["fields"])}
    assert gt["transcription"]["kind"] == "long_text"
    assert gt["translation"]["kind"] == "string_list"
    assert gt["image_description"]["kind"] == "string_list"
    # optional to the SCHEMA, required by the FORM — without it nothing can score
    assert all(f["ui_required"] is True for f in gt.values())
    assert all(f["required"] is False for f in gt.values())


# ── coding questions in a pool ───────────────────────────────────────────────
def _coding_q(**over):
    q = {
        "kind": "coding", "text": "Return the running sum of a list.",
        "difficulty": "easy",
        "coding": {
            "title": "Running Sum of a List",
            "starter_code": "def running_sum(nums):\n    pass",
            "function_name": "running_sum",
            "test_cases": [{"name": "basic", "input": "[1, 2]", "expected": "[1, 3]"}],
            "solution": "def running_sum(nums): ...",
            "hints": ["Keep a running total."],
            "topics": ["list", "algo"],
            "role_fit": ["backend"],
        },
    }
    q.update(over)
    return q


def test_a_coding_question_saves_and_round_trips(pools):
    pool = pools.save_pool(pools.QuestionPool.model_validate(
        {"pool_name": "Coding", "questions": [_coding_q()]}))
    again = pools.load_pool(pool.pool_id)
    # The KIND must survive the YAML round-trip. Writing the emit condition as
    # `is_written_kind` silently reloaded coding questions as spoken, which then
    # nulled their whole block — the question looked saved and came back empty.
    assert again.questions[0].kind == "coding"
    assert again.questions[0].coding.function_name == "running_sum"
    assert again.questions[0].written_response is None


def test_a_coding_question_must_be_runnable(pools):
    for block, why in [
        ({"starter_code": "x", "function_name": "f", "test_cases": []}, "test case"),
        ({"starter_code": "", "function_name": "f",
          "test_cases": [{"input": "1", "expected": "1"}]}, "starter code"),
        ({"starter_code": "x", "function_name": "2bad",
          "test_cases": [{"input": "1", "expected": "1"}]}, "function name"),
        ({"starter_code": "x", "function_name": "f",
          "test_cases": [{"input": "1", "expected": ""}]}, "expected value"),
    ]:
        with pytest.raises(Exception) as e:
            pools.QuestionPool.model_validate(
                {"pool_name": "x", "questions": [_coding_q(coding=block)]})
        assert why in str(e.value), f"{why}: {e.value}"


def test_a_coding_question_without_its_block_is_refused(pools):
    # Otherwise it would save as an empty exercise and fail only at interview time.
    with pytest.raises(Exception, match="starter code"):
        pools.QuestionPool.model_validate(
            {"pool_name": "x", "questions": [{"kind": "coding", "text": "t"}]})


def test_a_non_coding_question_cannot_smuggle_a_coding_block(pools):
    pool = pools.QuestionPool.model_validate({"pool_name": "x", "questions": [
        _coding_q(kind="spoken", coverage_tags=["x"])]})
    assert pool.questions[0].coding is None, "a stray block would be ignored at apply time"


def test_blank_test_case_and_hint_rows_are_dropped(pools):
    # Editing artefacts, not data — same rule the blank answer-point rows follow.
    pool = pools.QuestionPool.model_validate({"pool_name": "x", "questions": [_coding_q(
        coding={
            "starter_code": "def f():\n    pass", "function_name": "f",
            "test_cases": [{"input": "1", "expected": "1"},
                           {"name": "", "input": "", "expected": ""}],
            "hints": ["real", "  "],
        })]})
    assert len(pool.questions[0].coding.test_cases) == 1
    assert pool.questions[0].coding.hints == ["real"]


def test_the_catalog_exposes_coding_with_its_own_block(pools, api):
    _M, c = api
    kinds = {k["id"]: k for k in c.get("/api/question-pools/kinds").json()["kinds"]}
    assert "coding" in kinds
    cod = kinds["coding"]
    # `block` is what keeps the editor generic — it writes `coding`, not
    # `written_response`, without a special case in the form.
    assert cod["block"] == "coding" and cod["written"] is False
    assert kinds["translation"]["block"] == "written_response"
    names = {f["name"]: f for f in cod["fields"]}
    assert {"starter_code", "function_name", "test_cases", "solution", "hints"} <= set(names)
    assert names["test_cases"]["kind"] == "test_cases"
    assert names["starter_code"]["kind"] == "code"


def test_for_phase_filters_to_coding_and_carries_the_block(pools, api):
    _M, c = api
    pool = pools.save_pool(pools.QuestionPool.model_validate({
        "pool_name": "Mixed", "questions": [
            {"kind": "spoken", "text": "Talk to me.", "topic": "x",
             "coverage_tags": ["y"]},
            _coding_q(),
        ]}))
    r = c.get(f"/api/question-pools/{pool.pool_id}/for-phase"
              f"?token=tok-1&kind=coding").json()
    assert len(r["questions"]) == 1, "a coding phase must not be offered a spoken question"
    q = r["questions"][0]
    assert q["id"] and q["coding"]["function_name"] == "running_sum"
    # The id has to ride along: the cadence keys its inline map by it.
    assert q["coding"]["test_cases"][0]["expected"] == "[1, 3]"


def test_a_coding_question_uses_the_builtin_library_template(pools):
    # The point of the coding kind: it is authored in the SAME template as
    # features/coding/questions/library.yaml, not squeezed into the generic
    # pool shape. That means a real title, a topic LIST, a role fit and a time
    # budget — none of which the generic question has.
    pool = pools.QuestionPool.model_validate(
        {"pool_name": "C", "questions": [_coding_q()]})
    q = pool.questions[0]
    assert q.coding.title == "Running Sum of a List"
    assert q.coding.topics == ["list", "algo"]          # a LIST, not one slug
    assert q.coding.role_fit == ["backend"]
    assert q.coding.estimated_time_s == 600             # easy default
    # The generic fields are DERIVED, never authored twice.
    assert q.topic == "list", "the coverage matrix still needs a single topic"
    assert q.coverage_tags == [], "answer points are meaningless for code"
    # The id reads like a library key because it slugs from the TITLE, not from
    # the whole problem statement. An explicit id (as every library entry has)
    # always wins, so a pasted entry keeps the key other things reference.
    assert q.id == "running_sum_of_a_list"
    kept = pools.QuestionPool.model_validate({"pool_name": "C", "questions": [
        _coding_q(id="running_sum")]}).questions[0]
    assert kept.id == "running_sum"


def test_an_entry_copied_out_of_library_yaml_validates_as_is(pools):
    # The library puts everything at the top level of the entry; a pool nests it
    # under `coding`. Accepting both means a vetted question can be pasted
    # straight in — and it is what makes our own export round-trip.
    entry = _yaml.safe_load("""
    kind: coding
    title: Two Sum
    prompt: Return the indices of the two numbers adding to the target.
    starter_code: |
      def two_sum(nums, target):
          pass
    function_name: two_sum
    test_cases:
      - {name: basic, input: "[2, 7], 9", expected: "(0, 1)"}
    solution: "def two_sum(n, t): ..."
    hints: ["Use a dict."]
    difficulty: medium
    topic: [list, dict]
    role_fit: [backend, data]
    """)
    q = pools.QuestionPool.model_validate(
        {"pool_name": "C", "questions": [entry]}).questions[0]
    assert q.text.startswith("Return the indices")      # prompt → text
    assert q.coding.title == "Two Sum" and q.coding.topics == ["list", "dict"]
    assert q.coding.estimated_time_s == 1200            # medium default
    assert q.id == "two_sum"


def test_a_coding_pool_exports_in_the_library_file_shape(pools):
    # Mirrors the spoken rule: a spoken pool's export is committable to
    # questions_pool/, and a coding pool's is committable to library.yaml.
    pool = pools.save_pool(pools.QuestionPool.model_validate(
        {"pool_name": "C", "questions": [_coding_q()]}))
    out = _yaml.safe_load(pool.to_yaml())["questions"][0]
    assert out["prompt"] and out["title"]                # library names
    assert out["topic"] == ["list", "algo"]              # `topic`, and a list
    assert out["role_fit"] == ["backend"]
    assert "text" not in out and "coding" not in out     # no pool-internal keys
    assert "coverage_tags" not in out
    # and it survives a full storage round-trip
    again = pools.load_pool(pool.pool_id).questions[0]
    assert again.coding.title == "Running Sum of a List"
    assert again.coding.topics == ["list", "algo"]


def test_off_vocabulary_topics_and_roles_are_refused(pools):
    # Refused, NOT dropped: the coding picker filters on these, so a silently
    # discarded tag makes the question unfindable with no signal.
    for block, word in [({"topics": ["algos"]}, "topic"),
                        ({"role_fit": ["wizard"]}, "role_fit")]:
        q = _coding_q()
        q["coding"] = {**q["coding"], **block}
        with pytest.raises(Exception, match=word):
            pools.QuestionPool.model_validate({"pool_name": "C", "questions": [q]})


def test_the_coding_catalog_offers_the_library_fields(pools, api):
    _M, c = api
    cod = next(k for k in c.get("/api/question-pools/kinds").json()["kinds"]
               if k["id"] == "coding")
    names = {f["name"]: f for f in cod["fields"]}
    assert {"title", "topics", "role_fit", "estimated_time_s"} <= set(names)
    # The vocabularies ride along so the form can only offer legal values.
    assert names["topics"]["kind"] == "chips"
    assert set(names["topics"]["options"]) == set(pools.CODING_TOPICS)
    assert set(names["role_fit"]["options"]) == set(pools.CODING_ROLES)
    assert names["estimated_time_s"]["kind"] == "duration"
    # and nothing written-response-ish leaked in
    assert "char_limit" not in names and "ground_truth" not in names


# ── scenario (Visual Scenario Analysis) ──────────────────────────────────────
def _scenario_q(**over):
    q = {
        "kind": "scenario",
        "text": "What is wrong with this architecture diagram?",
        "coverage_tags": ["single point of failure", "no caching layer"],
        "scenario": {
            "media": {"kind": "image", "ref": "abc123_diagram.png",
                      "filename": "diagram.png", "mime_type": "image/png"},
            "max_followups": 3,
        },
    }
    q.update(over)
    return q


def test_a_scenario_question_saves_and_round_trips(pools):
    pool = pools.save_pool(pools.QuestionPool.model_validate(
        {"pool_name": "Scenario", "questions": [_scenario_q()]}))
    again = pools.load_pool(pool.pool_id)
    assert again.questions[0].kind == "scenario"
    assert again.questions[0].scenario.media.ref == "abc123_diagram.png"
    assert again.questions[0].scenario.max_followups == 3
    assert again.questions[0].written_response is None
    assert again.questions[0].coding is None


def test_a_scenario_question_without_media_is_refused(pools):
    with pytest.raises(Exception, match="media file"):
        pools.QuestionPool.model_validate(
            {"pool_name": "x", "questions": [{"kind": "scenario", "text": "t"}]})


def test_a_scenario_media_kind_must_match_its_mime_type(pools):
    q = _scenario_q()
    q["scenario"]["media"]["mime_type"] = "video/mp4"   # kind says image
    with pytest.raises(Exception, match="does not match"):
        pools.QuestionPool.model_validate({"pool_name": "x", "questions": [q]})


def test_a_non_scenario_question_cannot_smuggle_a_scenario_block(pools):
    q = _scenario_q(kind="spoken", topic="t")
    pool = pools.QuestionPool.model_validate({"pool_name": "x", "questions": [q]})
    assert pool.questions[0].scenario is None, "a stray block would be ignored at apply time"


def test_scenario_and_coding_blocks_are_mutually_exclusive(pools):
    # Saving as scenario must drop any stray coding block, same as a written
    # question dropped a stray coding block — neither kind reads the other's
    # material at apply time.
    q = _scenario_q()
    q["coding"] = {"starter_code": "x", "function_name": "f",
                   "test_cases": [{"input": "1", "expected": "1"}]}
    pool = pools.QuestionPool.model_validate({"pool_name": "x", "questions": [q]})
    assert pool.questions[0].coding is None
    assert pool.questions[0].scenario is not None


def test_the_catalog_exposes_scenario_with_its_own_block(pools, api):
    _M, c = api
    kinds = {k["id"]: k for k in c.get("/api/question-pools/kinds").json()["kinds"]}
    assert "scenario" in kinds
    sc = kinds["scenario"]
    assert sc["block"] == "scenario" and sc["written"] is False
    names = {f["name"]: f for f in sc["fields"]}
    assert names["media"]["kind"] == "asset_media"
    assert names["max_followups"]["kind"] == "count"


def test_for_phase_filters_to_scenario_copies_media_and_carries_the_block(pools, api):
    _M, c = api
    name = pools.store_asset("image", "diagram.png", b"fake-bytes")
    pool = pools.save_pool(pools.QuestionPool.model_validate({
        "pool_name": "Mixed", "questions": [
            {"kind": "spoken", "text": "Talk to me.", "topic": "x",
             "coverage_tags": ["y"]},
            _scenario_q(scenario={
                "media": {"kind": "image", "ref": name,
                          "filename": "diagram.png", "mime_type": "image/png"},
                "max_followups": 2,
            }),
        ]}))
    r = c.get(f"/api/question-pools/{pool.pool_id}/for-phase"
              f"?token=tok-scenario&kind=scenario").json()
    assert len(r["questions"]) == 1, "a scenario phase must not be offered a spoken question"
    q = r["questions"][0]
    assert q["id"] and q["scenario"]["media"]["ref"] == name
    assert q["scenario"]["max_followups"] == 2
    assert r["assets_copied"] == 1
    # The asset is now reachable from the interview's own session, independent
    # of the pool — the same "pool is a template" guarantee coding/written get.
    from app import blob_store
    assert blob_store.download_bytes(f"tok-scenario/phase_assets/{name}") == b"fake-bytes"
