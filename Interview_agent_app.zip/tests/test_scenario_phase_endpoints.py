"""Tests for the Visual Scenario Analysis phase-editor HTTP routes
(add/update/remove_scenario_phase) — the voice/video counterpart to the
existing coding-phase and written-response phase routes.

Follows tests/test_text_interview.py's pattern for these stateless builder
routes: `db.get` is monkeypatched to a plain dict (no real DB row needed —
these routes never persist; see the module comment above them in
app/main.py), and SESSIONS_DIR points at tmp_path so the real
`app/blob_store.py` disk-fallback path is exercised for the media-exists
check (BLOB_ENABLED is unset in tests, so no real Azure call happens).

Run with: python -m pytest tests/test_scenario_phase_endpoints.py -v
"""
from __future__ import annotations

import uuid as _uuid

import pytest
import yaml as _yaml
from fastapi.testclient import TestClient

from engine.brain.cadence.schema import CadencePlan


def _base_cadence(timed: bool = True) -> str:
    return _yaml.safe_dump({
        "total_duration_s": 120,
        "timed": timed,
        "phases": [
            {"id": "warm_up", "duration_s": 60, "intent": "Settle in.",
             "question_mode": "generic", "generic_prompts": ["Hi"]},
            {"id": "wrap_up", "duration_s": 60, "intent": "Close.",
             "question_mode": "generic", "generic_prompts": ["Bye"]},
        ],
    }, sort_keys=False)


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path / "sessions"))
    from app import auth, db as _db
    from app.main import app as admin_app

    token = str(_uuid.uuid4())
    monkeypatch.setattr(_db, "get", lambda t: {"token": token, "role": "AI Engineer"})
    c = TestClient(admin_app)
    # The phase-asset UPLOAD route is admin-gated (Depends(_api_require_user));
    # the phase-editor mutation routes below rely on db.get only, same as
    # add_phase/update_phase — but a signed-in cookie is harmless there and
    # keeps this one client usable for every call in the file.
    c.cookies.set(auth.COOKIE_NAME, auth.issue_cookie("test_admin"))
    return c, token


def _upload(client: TestClient, token: str, kind: str, filename: str, content: bytes, ctype: str) -> dict:
    r = client.post(
        f"/api/cadence/{token}/phase-asset",
        params={"kind": kind},
        files={"file": (filename, content, ctype)},
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["ok"], body
    return body


def _image_item(client, token, iid: str = "diagram_1") -> dict:
    up = _upload(client, token, "image", "arch.png", b"\x89PNG\r\n fake", "image/png")
    return {
        "id": iid, "media": {"kind": "image", "ref": up["name"], "filename": "arch.png",
                              "mime_type": "image/png"},
        "question": "What is missing here?", "coverage_tags": ["load balancer"],
        "max_followups": 2,
    }


def _video_item(client, token, iid: str = "clip_1") -> dict:
    up = _upload(client, token, "video", "demo.mp4", b"\x00\x00\x00\x18ftypmp42 fake", "video/mp4")
    return {
        "id": iid, "media": {"kind": "video", "ref": up["name"], "filename": "demo.mp4",
                              "mime_type": "video/mp4"},
        "question": "How would you scale this to 2000 users?",
        "coverage_tags": ["caching", "horizontal scaling"], "max_followups": 1,
    }


# ── media upload reuses the existing route, now with a video kind ──────────


def test_video_kind_uploads_through_the_existing_phase_asset_route(client):
    c, token = client
    up = _upload(c, token, "video", "demo.mp4", b"x" * 1000, "video/mp4")
    assert up["url"] == f"/api/sessions/{token}/phase-asset/{up['name']}"


def test_oversized_video_upload_is_rejected(client):
    c, token = client
    r = c.post(
        f"/api/cadence/{token}/phase-asset", params={"kind": "video"},
        files={"file": ("big.mp4", b"x" * (101 * 1024 * 1024), "video/mp4")},
    )
    assert r.status_code == 400, r.text
    assert "100 MB" in r.json()["error"]


# ── add_scenario_phase ──────────────────────────────────────────────────────


def test_add_scenario_phase_with_an_image_and_a_video_item(client):
    c, token = client
    items = [_image_item(c, token), _video_item(c, token)]
    r = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": _base_cadence(), "items": items,
    })
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["ok"], body
    data = _yaml.safe_load(body["yaml"])
    ids = [p["id"] for p in data["phases"]]
    assert ids == ["warm_up", "scenario_analysis", "wrap_up"]

    # Round-trips through the REAL schema, incl. the auto-injected banter.
    plan = CadencePlan.model_validate(data)
    phase = plan.get_phase("scenario_analysis")
    assert phase.is_scenario_analysis
    assert [i.id for i in phase.scenario_items] == ["diagram_1", "clip_1"]
    assert data["total_duration_s"] == 120 + 360  # +3min/item default


def test_add_scenario_phase_requires_items(client):
    c, token = client
    r = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": _base_cadence(), "items": [],
    })
    assert r.status_code == 400
    assert "item" in r.json()["error"].lower()


def test_add_scenario_phase_rejects_text_modality_with_a_clear_message(client):
    c, token = client
    items = [_image_item(c, token)]
    r = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": _base_cadence(timed=False), "items": items,
    })
    assert r.status_code == 400
    err = r.json()["error"]
    assert "voice/video" in err
    assert "text-only" in err
    # Clean, no pydantic noise — the whole point of the up-front check.
    assert "validation error" not in err.lower()


def test_add_scenario_phase_rejects_a_missing_media_ref(client):
    c, token = client
    items = [{
        "id": "a", "media": {"kind": "image", "ref": "never_uploaded.png",
                              "filename": "never_uploaded.png", "mime_type": "image/png"},
        "question": "q?", "coverage_tags": ["t"], "max_followups": 2,
    }]
    r = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": _base_cadence(), "items": items,
    })
    assert r.status_code == 400
    assert "was not found" in r.json()["error"]


def test_add_scenario_phase_404_when_session_missing(client, monkeypatch):
    c, token = client
    from app import db as _db
    monkeypatch.setattr(_db, "get", lambda t: None)
    r = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": _base_cadence(), "items": [{"id": "a",
            "media": {"kind": "image", "ref": "x", "filename": "x", "mime_type": "image/png"},
            "question": "q", "coverage_tags": ["t"]}],
    })
    assert r.status_code == 404


def test_add_scenario_phase_rejects_a_malformed_item(client):
    # coverage_tags all-blank -> the REAL schema validator rejects it; the
    # route surfaces whatever the schema raises (matching the sibling
    # coding/written-response routes' existing raw-error convention).
    c, token = client
    items = [_image_item(c, token)]
    items[0]["coverage_tags"] = ["  ", ""]
    r = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": _base_cadence(), "items": items,
    })
    assert r.status_code == 400
    assert r.json()["ok"] is False


def test_add_scenario_phase_rejects_when_one_already_exists(client):
    # Bug regression: the admin UI's "Add phases" menu now routes to the
    # EDIT path when a scenario phase already exists (CadenceReview.tsx), so
    # this route should only ever be hit in that state via a stale bundle,
    # a direct API call, or two admin tabs racing — defense in depth, not
    # the primary guard.
    c, token = client
    first = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": _base_cadence(), "items": [_image_item(c, token)],
    })
    assert first.status_code == 200, first.text

    second = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": first.json()["yaml"], "items": [_image_item(c, token, "diagram_2")],
    })
    assert second.status_code == 400
    err = second.json()["error"]
    assert "already exists" in err
    assert "Open it and add questions" in err

    # And no second phase was created — still exactly one.
    data = _yaml.safe_load(first.json()["yaml"])
    scenario_phases = [p["id"] for p in data["phases"] if p.get("scenario_items")]
    assert scenario_phases == ["scenario_analysis"]


# ── update_scenario_phase ────────────────────────────────────────────────────


def test_update_scenario_phase_reorders_and_adds_an_item(client):
    c, token = client
    img = _image_item(c, token, "diagram_1")
    r = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": _base_cadence(), "items": [img],
    })
    yaml_after_add = r.json()["yaml"]

    vid = _video_item(c, token, "clip_1")
    # Send the reversed + extended list — update replaces the WHOLE ordered list.
    r2 = c.post(f"/api/cadence/{token}/update_scenario_phase", json={
        "yaml": yaml_after_add, "phase_id": "scenario_analysis",
        "items": [vid, img], "duration_s": 500,
    })
    assert r2.status_code == 200, r2.text
    data = _yaml.safe_load(r2.json()["yaml"])
    plan = CadencePlan.model_validate(data)
    phase = plan.get_phase("scenario_analysis")
    assert [i.id for i in phase.scenario_items] == ["clip_1", "diagram_1"]
    assert phase.duration_s == 500
    # total recomputed from the phase sum (60+60+500)
    assert data["total_duration_s"] == 620


def test_update_scenario_phase_appends_item_keeping_id_and_duration(client):
    # Matches the "Add phases" menu's edit-mode save: an existing item plus
    # one freshly-added blank one, appended at the END, no explicit
    # duration_s change — the phase id and total_duration_s bookkeeping
    # must be exactly what they were before.
    c, token = client
    img = _image_item(c, token, "diagram_1")
    r = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": _base_cadence(), "items": [img], "duration_s": 300,
    })
    added = r.json()["yaml"]
    assert _yaml.safe_load(added)["total_duration_s"] == 420  # 60+60+300

    vid = _video_item(c, token, "clip_1")
    r2 = c.post(f"/api/cadence/{token}/update_scenario_phase", json={
        "yaml": added, "phase_id": "scenario_analysis", "items": [img, vid],
    })
    assert r2.status_code == 200, r2.text
    data = _yaml.safe_load(r2.json()["yaml"])
    ids = [p["id"] for p in data["phases"]]
    assert ids == ["warm_up", "scenario_analysis", "wrap_up"]  # SAME id, SAME position
    plan = CadencePlan.model_validate(data)
    phase = plan.get_phase("scenario_analysis")
    assert [i.id for i in phase.scenario_items] == ["diagram_1", "clip_1"]  # new one at the END
    assert phase.duration_s == 300  # untouched (no duration_s sent)
    assert data["total_duration_s"] == 420  # bookkeeping unchanged


def test_update_scenario_phase_removes_an_item_by_omitting_it(client):
    c, token = client
    img = _image_item(c, token, "diagram_1")
    vid = _video_item(c, token, "clip_1")
    r = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": _base_cadence(), "items": [img, vid],
    })
    r2 = c.post(f"/api/cadence/{token}/update_scenario_phase", json={
        "yaml": r.json()["yaml"], "phase_id": "scenario_analysis", "items": [img],
    })
    assert r2.status_code == 200, r2.text
    plan = CadencePlan.model_validate(_yaml.safe_load(r2.json()["yaml"]))
    assert [i.id for i in plan.get_phase("scenario_analysis").scenario_items] == ["diagram_1"]


def test_update_scenario_phase_rejects_emptying_all_items(client):
    c, token = client
    img = _image_item(c, token)
    r = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": _base_cadence(), "items": [img],
    })
    r2 = c.post(f"/api/cadence/{token}/update_scenario_phase", json={
        "yaml": r.json()["yaml"], "phase_id": "scenario_analysis", "items": [],
    })
    assert r2.status_code == 400
    assert "remove the phase" in r2.json()["error"]


def test_update_scenario_phase_404s_on_unknown_phase_id(client):
    c, token = client
    img = _image_item(c, token)
    r = c.post(f"/api/cadence/{token}/update_scenario_phase", json={
        "yaml": _base_cadence(), "phase_id": "nope", "items": [img],
    })
    assert r.status_code == 400
    assert "no phase 'nope'" in r.json()["error"]


def test_update_scenario_phase_rejects_a_non_scenario_phase_id(client):
    c, token = client
    img = _image_item(c, token)
    r = c.post(f"/api/cadence/{token}/update_scenario_phase", json={
        "yaml": _base_cadence(), "phase_id": "warm_up", "items": [img],
    })
    assert r.status_code == 400
    assert "not a Visual Scenario Analysis phase" in r.json()["error"]


def test_update_scenario_phase_rejects_missing_media(client):
    c, token = client
    img = _image_item(c, token)
    r = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": _base_cadence(), "items": [img],
    })
    bad = dict(img)
    bad["media"] = {**img["media"], "ref": "gone.png"}
    r2 = c.post(f"/api/cadence/{token}/update_scenario_phase", json={
        "yaml": r.json()["yaml"], "phase_id": "scenario_analysis", "items": [bad],
    })
    assert r2.status_code == 400
    assert "was not found" in r2.json()["error"]


# ── remove_scenario_phase — duration bookkeeping ────────────────────────────


def test_remove_scenario_phase_keeps_total_duration_consistent(client):
    c, token = client
    img = _image_item(c, token)
    r = c.post(f"/api/cadence/{token}/add_scenario_phase", json={
        "yaml": _base_cadence(), "items": [img], "duration_s": 300,
    })
    added = r.json()["yaml"]
    assert _yaml.safe_load(added)["total_duration_s"] == 420  # 60+60+300

    r2 = c.post(f"/api/cadence/{token}/remove_scenario_phase", json={
        "yaml": added, "phase_id": "scenario_analysis",
    })
    assert r2.status_code == 200, r2.text
    data = _yaml.safe_load(r2.json()["yaml"])
    assert [p["id"] for p in data["phases"]] == ["warm_up", "wrap_up"]
    assert data["total_duration_s"] == 120
    # Still a valid plan.
    CadencePlan.model_validate(data)


def test_remove_scenario_phase_404s_on_unknown_phase_id(client):
    c, token = client
    r = c.post(f"/api/cadence/{token}/remove_scenario_phase", json={
        "yaml": _base_cadence(), "phase_id": "nope",
    })
    assert r.status_code == 400
    assert "no phase 'nope'" in r.json()["error"]


def test_remove_scenario_phase_rejects_a_non_scenario_phase_id(client):
    c, token = client
    r = c.post(f"/api/cadence/{token}/remove_scenario_phase", json={
        "yaml": _base_cadence(), "phase_id": "warm_up",
    })
    assert r.status_code == 400
    assert "not a Visual Scenario Analysis phase" in r.json()["error"]
