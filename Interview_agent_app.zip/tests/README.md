# Integration tests

## End-to-end smoke

`e2e_smoke.py` runs the full integrated pipeline against
`fixtures/Speaker26_000_padded.wav` (251 seconds of book narration with 40-s
gaps padded between utterances) and validates the result.

### What it actually does

1. **Pre-flight checks:**
   - `fixtures/Speaker26_000_padded.wav` exists
   - `OPENROUTER_API_KEY` is set in env or in any of `.env` / `.env.example`
   - `.venv/bin/python` exists (so both projects' deps are installed)

2. **Runs `scripts/run_integrated.sh`** with the fixture as argument. That script:
   - kills anything stale on ports 8010/8011/8012
   - boots Stream A's STT (`faster-distil-whisper-large-v3`), VAD (Silero v5), TTS (Kokoro)
   - waits up to 15 min for healthchecks (with 30-s heartbeat)
   - runs `orchestrator/main.py` which feeds the WAV in, bridges WS events to Stream B's `AgentSession`, and lets DeepSeek drive the conversation

3. **Validates the event log** at `/tmp/integration/events.jsonl`:
   - `session_started` exists
   - At least one `utterance_final` (Stream A actually transcribed)
   - At least one `tick` (Stream B's heartbeat ran)
   - At least one `llm_generation_start` (Stream B called DeepSeek)
   - At least one `ai_utterance` (the AI produced a response)
   - `session_ended` exists (clean shutdown)

4. **Prints a transcript** of the candidate's STT finals and the AI's responses.

### Pre-reqs (do these once, then forget)

```bash
# from interview_assist/

# Stream A models — these auto-download on first run, but pre-download to
# avoid waiting through 1.5GB at the e2e timeout
.venv/bin/python -c "from huggingface_hub import snapshot_download; \
  snapshot_download('Systran/faster-distil-whisper-large-v3')"
.venv/bin/python -c "from huggingface_hub import snapshot_download; \
  snapshot_download('hexgrad/Kokoro-82M')"

# Stream B's deps installed into the same .venv that Stream A uses
.venv/bin/pip install -r STREAM_B/Interview_agent_app/requirements.txt

# Silero VAD ONNX (one-time)
mkdir -p models
curl -L -o models/silero_vad.onnx \
  https://github.com/snakers4/silero-vad/raw/master/src/silero_vad/data/silero_vad.onnx

# Put your OpenRouter key in .env at the repo root
echo 'OPENROUTER_API_KEY=sk-or-v1-...' >> .env
```

### Run it

From the repo root:

```bash
.venv/bin/python STREAM_A_B_Integration/tests/e2e_smoke.py
```

That's the whole thing. The script handles boot, run, and validation.

### Expected runtime

- **First run:** 5-7 minutes if models are pre-cached, plus first-time HF
  download time if not (~5-15 min on a typical connection for the ~3 GB total).
- **Subsequent runs:** 5-7 minutes, dominated by the realtime audio pump (251s)
  and DeepSeek call latencies (~5-10s each, 5-10 calls per session).

### Expected output (success)

```
[e2e] OPENROUTER_API_KEY sourced from /Users/.../.env
[e2e] executing: bash /Users/.../scripts/run_integrated.sh /Users/.../Speaker26_000_padded.wav
[e2e] (this is the long part — model loads + 251s of audio + real DeepSeek calls)
... live output from Stream A boot + orchestrator ...
[e2e] orchestrator finished — validating outputs
[e2e] events recorded: 412
[e2e]   ai_utterance                 6
[e2e]   llm_generation_end           6
[e2e]   llm_generation_start         6
[e2e]   phase_changed                1
[e2e]   policy_decision              503
[e2e]   session_ended                1
[e2e]   session_started              1
[e2e]   tick                         503
[e2e]   tts_speak                    24
[e2e]   utterance_final              7
[e2e]   utterance_partial            12
[e2e]   vad_endpoint                 7
[e2e]   vad_speech_end               21
[e2e]   vad_speech_start             21

=== STT finals ===
  • Section zero of Aesop's Fables, a new revised version by Aesop.
  • The following are some of Aesop's best loved fables.
  • The Goose with the Golden Eggs.
  • A certain man had the good fortune to possess a goose...
  • ...

=== AI utterances ===
  • Welcome — could you tell me a bit about yourself before we dig in?
  • What's your favorite of Aesop's fables to recall right now?
  • ...

[e2e] all checks passed ✓
```

(Numbers will vary — they're not asserted.)

### What "failed" looks like

```
[e2e] orchestrator exited with code 3
```

Means the wrapper script timed out or a service crashed. Check
`/tmp/integration_logs/{stt,vad,tts}.log` for stack traces.

```
[e2e] VALIDATION FAILED:
[e2e]   - no llm_generation_start events — Stream B never called the LLM
```

Means the orchestrator ran but Stream B's policy never decided "YES". Most
likely cause is `OPENROUTER_API_KEY` invalid — check
`/tmp/integration_logs/stt.log` for HTTP errors. Or VAD never fired endpoint,
in which case check VAD's `silence_tail_ms` against the audio's pause structure.

### Trying it on your own audio

The smoke script hardcodes `fixtures/Speaker26_000_padded.wav`. If you want a
different WAV, run the orchestrator directly:

```bash
./STREAM_A_B_Integration/scripts/run_integrated.sh /path/to/your/audio.wav
```

(Any sample rate, mono or stereo — the audio_pump auto-resamples to 16 kHz mono.)

### Files

```
tests/
├── README.md                              (this file)
├── __init__.py
├── e2e_smoke.py                           runnable test harness
└── fixtures/
    └── Speaker26_000_padded.wav           251s book narration with padded gaps
```
