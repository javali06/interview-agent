"""Test-wide safety net: no test may touch a real database.

Every DB test isolates itself by setting SESSIONS_DIR to a tmp_path and calling
`db.engine.reset_engine()`, on the assumption that this points the shared engine
at a throwaway sqlite file. That assumption is FALSE whenever `DATABASE_URL` is
set: `database_url()` returns the env var and only falls back to
`<SESSIONS_DIR>/sessions.db` when it is empty. So running the suite in any shell
carrying the app's own environment — a sourced .env, a container shell, an IDE
runner with the compose env — silently wrote test fixtures into the live
Postgres.

That is not hypothetical. It happened: `tests/test_roles_endpoints.py` and
`tests/test_shortlist.py` were run ~18 times against the dev database between
2026-08-08 and 2026-08-13, leaving 108 fixture roles ("X", "R", "NoJD", …) and
54 scores in the Shortlist that a person then had to look at and wonder about.

Unsetting the variable here fixes it for EVERY test at once, including ones not
yet written — a per-file fix would have to be remembered by each new DB test,
which is exactly the kind of discipline this incident showed does not hold. A
test that genuinely wants a database sets `DATABASE_URL` itself inside its own
fixture (autouse fixtures run first, so it wins).
"""
from __future__ import annotations

import os

import pytest


@pytest.fixture(autouse=True)
def _no_real_database(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    yield
    # A test that pointed itself at a server rather than a file is a bug even if
    # it passed — fail loudly here instead of leaving rows behind for someone to
    # find in the UI weeks later.
    url = os.environ.get("DATABASE_URL", "")
    if url and not url.startswith("sqlite"):
        pytest.fail(
            f"test set DATABASE_URL={url!r} — tests must use a throwaway sqlite "
            "file (see tests/conftest.py); this is how 108 fixture roles ended "
            "up in the dev database."
        )
