"""End-to-end smoke test for the Stream A + Stream B integration.

Runs `scripts/run_integrated.sh` against `tests/fixtures/Speaker26_000_padded.wav`
and validates that:

  1. The orchestrator process exited cleanly.
  2. The event log was written.
  3. STT actually transcribed something (≥ 1 utterance_final event).
  4. The agent loop ran (tick events present).
  5. Stream B called the LLM at least once (llm_generation_start present).
  6. The session ended cleanly (session_ended present).

This costs real OpenRouter credits — DeepSeek calls run for real. Total run
time on CPU: ~5-7 minutes (the WAV is 251s of audio, plus model loads + LLM
latency on top).

Pre-reqs (run these BEFORE invoking this script):

  * Stream A models cached locally (Whisper + Kokoro + Silero ONNX)
  * Stream B requirements installed into the same venv as Stream A:
        .venv/bin/pip install -r STREAM_B/Interview_agent_app/requirements.txt
  * OPENROUTER_API_KEY available in the environment, or in any of:
        ./.env                   (Stream A repo root)
        ./STREAM_B/Interview_agent_app/.env
        ./STREAM_A_B_Integration/.env
        ./.env.example           (fallback)

Run:

    .venv/bin/python STREAM_A_B_Integration/tests/e2e_smoke.py

Exit codes:

    0  — all checks passed
    2  — pre-req missing (key, fixture, etc.)
    3  — orchestrator subprocess failed
    1  — orchestrator ran but outputs failed validation
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

# ── paths ────────────────────────────────────────────────────────────────────
TESTS_DIR = Path(__file__).resolve().parent
INTEG_ROOT = TESTS_DIR.parent
ROOT = INTEG_ROOT.parent
FIXTURE = TESTS_DIR / "fixtures" / "Speaker26_000_padded.wav"

EVENTS_LOG = Path("/tmp/integration/events.jsonl")
SERVICE_LOGS = Path("/tmp/integration_logs")
RUN_SCRIPT = INTEG_ROOT / "scripts" / "run_integrated.sh"

# ── helpers ──────────────────────────────────────────────────────────────────


def _print(msg: str) -> None:
    print(f"[e2e] {msg}", flush=True)


def _source_openrouter_key_into_env() -> bool:
    if os.environ.get("OPENROUTER_API_KEY"):
        return True
    candidates = [
        ROOT / ".env",
        ROOT / "STREAM_B" / "Interview_agent_app" / ".env",
        INTEG_ROOT / ".env",
        ROOT / ".env.example",
    ]
    for path in candidates:
        if not path.exists():
            continue
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith("OPENROUTER_API_KEY="):
                value = line.split("=", 1)[1].strip()
                if value:
                    os.environ["OPENROUTER_API_KEY"] = value
                    _print(f"OPENROUTER_API_KEY sourced from {path}")
                    return True
    return False


def _check_prereqs() -> int | None:
    if not FIXTURE.exists():
        _print(f"ERROR: missing fixture {FIXTURE}")
        return 2
    if not RUN_SCRIPT.exists():
        _print(f"ERROR: missing run script {RUN_SCRIPT}")
        return 2
    if not _source_openrouter_key_into_env():
        _print("ERROR: OPENROUTER_API_KEY not set and not found in any .env")
        return 2
    # Prefer the integration's own venv; fall back to parent repo's.
    for v in (INTEG_ROOT / ".venv" / "bin" / "python", ROOT / ".venv" / "bin" / "python"):
        if v.exists():
            return None
    _print(f"ERROR: no .venv found in {INTEG_ROOT} or {ROOT} — run install steps first")
    return 2


def _run_integration() -> int:
    cmd = ["bash", str(RUN_SCRIPT), str(FIXTURE)]
    _print(f"executing: {' '.join(cmd)}")
    _print("(this is the long part — model loads + 251s of audio + real DeepSeek calls)")
    proc = subprocess.run(cmd, env=os.environ.copy())
    return proc.returncode


# ── validators ───────────────────────────────────────────────────────────────


def _load_events() -> list[dict]:
    if not EVENTS_LOG.exists():
        return []
    rows: list[dict] = []
    for line in EVENTS_LOG.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return rows


def _validate(events: list[dict]) -> list[str]:
    failures: list[str] = []

    if not events:
        return [f"event log is empty or missing: {EVENTS_LOG}"]

    by_kind: dict[str, list[dict]] = {}
    for ev in events:
        by_kind.setdefault(ev.get("kind", ""), []).append(ev)

    _print(f"events recorded: {len(events)}")
    for kind, rows in sorted(by_kind.items()):
        _print(f"  {kind:<28}  {len(rows)}")

    if not by_kind.get("session_started"):
        failures.append("missing session_started event")
    if not by_kind.get("utterance_final"):
        failures.append(
            "no utterance_final events — STT didn't transcribe anything"
        )
    if not by_kind.get("tick"):
        failures.append(
            "no tick events — AgentSession heartbeat never ran"
        )
    if not by_kind.get("llm_generation_start"):
        failures.append(
            "no llm_generation_start events — Stream B never called the LLM"
        )
    if not by_kind.get("ai_utterance"):
        failures.append(
            "no ai_utterance events — AI never produced an utterance"
        )
    if not by_kind.get("session_ended"):
        failures.append("missing session_ended event — orchestrator exited dirty")

    return failures


def _print_summary(events: list[dict]) -> None:
    by_kind: dict[str, list[dict]] = {}
    for ev in events:
        by_kind.setdefault(ev.get("kind", ""), []).append(ev)

    print()
    print("=== STT finals ===")
    for ev in by_kind.get("utterance_final", []):
        text = (ev.get("payload") or {}).get("text", "")
        text = text.replace("\n", " ")
        print(f"  • {text[:200]}")

    print()
    print("=== AI utterances ===")
    for ev in by_kind.get("ai_utterance", []):
        # Stream B emits the AI text under "text", not "utterance".
        payload = ev.get("payload") or {}
        text = payload.get("text") or payload.get("utterance") or ""
        text = text.replace("\n", " ")
        print(f"  • {text[:200]}")


# ── main ─────────────────────────────────────────────────────────────────────


def main() -> int:
    rc = _check_prereqs()
    if rc is not None:
        return rc

    rc = _run_integration()
    if rc != 0:
        _print(f"orchestrator exited with code {rc}")
        return 3

    _print("orchestrator finished — validating outputs")
    events = _load_events()
    failures = _validate(events)
    _print_summary(events)

    if failures:
        print()
        _print("VALIDATION FAILED:")
        for f in failures:
            _print(f"  - {f}")
        _print(
            f"  service logs: {SERVICE_LOGS}/  ·  event log: {EVENTS_LOG}"
        )
        return 1

    print()
    _print("all checks passed ✓")
    return 0


if __name__ == "__main__":
    sys.exit(main())
