"""Shortlist feature — ported scorer + persistence on the shared db/ layer.

No real LLM: the semantic step is stubbed so these run offline. Covers the
deterministic keyword coverage, the hybrid blend, and a save→read round-trip
against a throwaway SQLite DB.

Run: .venv/bin/python -m pytest tests/test_shortlist.py -v
"""
from __future__ import annotations

import pytest


# ── deterministic keyword coverage ─────────────────────────────────────


def test_coverage_matches_required_and_preferred():
    from features.shortlist import compute_coverage

    resume = "Built data pipelines in Python and SQL. Used Pandas and Docker daily."
    cov = compute_coverage(
        resume,
        required_skills=["Python", "SQL", "Kubernetes"],
        preferred_skills=["Pandas", "Terraform"],
    )
    assert set(cov.required_matched) == {"Python", "SQL"}
    assert cov.required_missing == ["Kubernetes"]
    assert "Pandas" in cov.preferred_matched
    assert "Terraform" in cov.preferred_missing
    assert 0 < cov.score <= 100


def test_word_boundary_no_false_positive():
    from features.shortlist import compute_coverage

    # "go" must not match inside "google"
    cov = compute_coverage("Experienced with Google Cloud.", ["Go"], [])
    assert cov.required_matched == []
    assert cov.required_missing == ["Go"]


# ── hybrid blend (LLM stubbed) ──────────────────────────────────────────


def _stub_llm(overall=80.0, required=("Python",), preferred=(), email="a@b.com"):
    from features.shortlist.models import Candidate, LLMScore

    return LLMScore(
        overall_score=overall, summary="ok", dimensions=[],
        strengths=["x"], gaps=["y"], recommendation="possible fit",
        required_skills=list(required), preferred_skills=list(preferred),
        candidate=Candidate(name="Ada", email=email, phone=""),
    )


def test_hybrid_blend_weights(monkeypatch):
    from features.shortlist import HybridScorer

    sc = HybridScorer(llm_weight=0.5)
    monkeypatch.setattr(sc, "_llm", type("L", (), {"score": staticmethod(
        lambda r, j: _stub_llm(overall=80.0, required=("Python", "SQL"))
    ), "model": "stub"})())
    res = sc.score("I know Python.", "Need Python and SQL.")
    # coverage = required 1/2 matched (Python yes, SQL no) -> 50; blend 0.5*80 + 0.5*50 = 65
    assert res.coverage.score == 50.0
    assert res.final_score == 65.0
    assert res.weights == {"llm": 0.5, "coverage": 0.5}


# ── persistence round-trip on the shared db/ layer ──────────────────────


@pytest.fixture
def fresh_db(tmp_path):
    from db import engine as db_engine

    db_engine.reset_engine(f"sqlite:///{tmp_path / 'sl.db'}")
    db_engine.create_all()
    yield
    db_engine.reset_engine(None)


def test_save_score_round_trip(fresh_db):
    from features.shortlist import save_score, get_scores_for_candidate
    from features.shortlist.models import ScoreResponse, SkillCoverage

    resp = ScoreResponse(
        final_score=72.0,
        coverage=SkillCoverage(score=60.0, required_matched=["Python"]),
        llm=_stub_llm(overall=80.0, email="ada@example.com"),
        weights={"llm": 0.65, "coverage": 0.35},
        model="stub-model",
        source="ada_resume.pdf",
    )
    public_id = save_score(resp, job_description="Need Python.")
    assert public_id  # hex

    scores = get_scores_for_candidate(public_id)
    assert len(scores) == 1
    assert scores[0].final_score == 72.0
    assert scores[0].result["source"] == "ada_resume.pdf"  # lossless JSON round-trip

    # re-scoring the same email reuses the candidate (dedupe)
    save_score(resp, job_description="Need Python again.")
    assert len(get_scores_for_candidate(public_id)) == 2


# ── HTTP API (mounted in the admin app, auth-gated, LLM stubbed) ────────


def _stub_response():
    from features.shortlist.models import ScoreResponse, SkillCoverage
    return ScoreResponse(
        final_score=77.0,
        coverage=SkillCoverage(score=70.0, required_matched=["Python"]),
        llm=_stub_llm(overall=80.0, email="api@example.com"),
        weights={"llm": 0.65, "coverage": 0.35},
        model="stub-model",
    )


@pytest.fixture
def api_client(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    from db import engine as db_engine
    db_engine.reset_engine(f"sqlite:///{tmp_path / 'api.db'}")
    db_engine.create_all()
    # Stub the scorer so no real LLM is called.
    from features.shortlist import routes as sl_routes
    monkeypatch.setattr(sl_routes, "_get_scorer",
                        lambda: type("S", (), {"score": staticmethod(lambda r, j: _stub_response())})())
    from fastapi.testclient import TestClient
    from app import auth, main
    client = TestClient(main.app)
    client.cookies.set(auth.COOKIE_NAME, auth.issue_cookie("test_admin"))
    yield client
    db_engine.reset_engine(None)


def test_score_text_requires_auth(api_client):
    from fastapi.testclient import TestClient
    from app import main
    anon = TestClient(main.app)  # no cookie
    r = anon.post("/api/shortlist/score/text",
                  json={"resume_text": "Python dev", "job_description": "Need Python"})
    assert r.status_code == 401


def test_score_text_returns_scoreresponse(api_client):
    r = api_client.post("/api/shortlist/score/text",
                        json={"resume_text": "Python dev", "job_description": "Need Python"})
    assert r.status_code == 200, r.text
    data = r.json()
    assert data["final_score"] == 77.0
    assert data["llm"]["recommendation"] == "possible fit"
    assert "coverage" in data and "weights" in data
