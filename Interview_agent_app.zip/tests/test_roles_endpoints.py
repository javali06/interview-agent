"""Tests for the role-centric Shortlist API (/api/roles).

Run with: .venv/bin/python -m pytest tests/test_roles_endpoints.py -v

Coverage: auth gate, role CRUD, threshold update, and the match flow (resume →
score vs role JD → store ranked) with the scorer + resume parser monkeypatched
so no real LLM/file parsing runs.
"""
from __future__ import annotations

import pytest


def _fake_score(final=85.0, name="Jane Doe", email="jane@example.com"):
    from features.shortlist.models import Candidate, LLMScore, ScoreResponse, SkillCoverage

    return ScoreResponse(
        final_score=final,
        coverage=SkillCoverage(score=final),
        llm=LLMScore(
            overall_score=final,
            summary="Solid fit.",
            recommendation="strong fit",
            candidate=Candidate(name=name, email=email),
        ),
        weights={"llm": 0.65, "coverage": 0.35},
        model="test-model",
        source=None,
    )


class _FakeScorer:
    def __init__(self, final=85.0):
        self._final = final

    def score(self, resume_text, jd_text):
        return _fake_score(final=self._final)


@pytest.fixture
def clients(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    from db.engine import create_all, reset_engine

    reset_engine()  # point the shared engine at the throwaway sessions.db
    create_all()
    from fastapi.testclient import TestClient
    from app import auth, main

    authed = TestClient(main.app)
    authed.cookies.set(auth.COOKIE_NAME, auth.issue_cookie("test_admin"))
    anon = TestClient(main.app)
    return authed, anon


# ── auth + CRUD ──────────────────────────────────────────────────────────────


def test_roles_requires_auth(clients):
    _, anon = clients
    assert anon.get("/api/roles").status_code == 401


def test_create_and_list_role(clients):
    authed, _ = clients
    r = authed.post("/api/roles", json={"title": "Senior AI Engineer", "jd_text": "Builds LLM systems.", "threshold": 72})
    assert r.status_code == 200, r.text
    role = r.json()
    assert role["title"] == "Senior AI Engineer"
    assert role["threshold"] == 72
    pid = role["public_id"]

    lst = authed.get("/api/roles").json()["roles"]
    assert any(x["public_id"] == pid for x in lst)
    mine = next(x for x in lst if x["public_id"] == pid)
    assert mine["candidate_count"] == 0 and mine["matched_count"] == 0


def test_get_role_404(clients):
    authed, _ = clients
    assert authed.get("/api/roles/deadbeef").status_code == 404


def test_update_threshold(clients):
    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "X", "jd_text": "jd"}).json()["public_id"]
    r = authed.put(f"/api/roles/{pid}", json={"threshold": 60})
    assert r.status_code == 200
    assert r.json()["threshold"] == 60


# ── match flow ───────────────────────────────────────────────────────────────


def test_match_stores_and_ranks(clients, monkeypatch):
    from features.shortlist import role_routes

    async def _fake_upload(up, label):
        return "Jane Doe — AI engineer, PyTorch, transformers."

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer(final=85.0))

    authed, _ = clients
    pid = authed.post(
        "/api/roles", json={"title": "AI Eng", "jd_text": "Builds LLM systems.", "threshold": 70}
    ).json()["public_id"]

    r = authed.post(
        f"/api/roles/{pid}/match",
        files=[("resumes", ("jane.txt", b"resume bytes", "text/plain"))],
    )
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["processed"] == 1
    assert body["errors"] == []
    cands = body["candidates"]
    assert len(cands) == 1
    assert cands[0]["name"] == "Jane Doe"
    assert cands[0]["final_score"] == 85.0
    assert cands[0]["above_threshold"] is True
    assert cands[0]["has_resume"] is True

    # and via the candidates endpoint
    c2 = authed.get(f"/api/roles/{pid}/candidates").json()["candidates"]
    assert len(c2) == 1 and c2[0]["above_threshold"] is True


def test_match_below_threshold_flag(clients, monkeypatch):
    from features.shortlist import role_routes

    async def _fake_upload(up, label):
        return "resume"

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer(final=55.0))

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "R", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    body = authed.post(f"/api/roles/{pid}/match", files=[("resumes", ("a.txt", b"x", "text/plain"))]).json()
    assert body["candidates"][0]["above_threshold"] is False


@pytest.fixture
def no_job_queue(monkeypatch):
    """create_draft enqueues a cadence_gen job on the worker tier's Azure queue,
    which isn't running here. Stubbing the ENQUEUE (not create_draft) keeps the
    rest of the real path — the session row, the is_template flag, the role
    pointer — under test."""
    import app.sessions as admin_sessions

    async def _noop(token):
        return None

    monkeypatch.setattr(admin_sessions, "_enqueue_cadence_gen", _noop)
    monkeypatch.setattr(admin_sessions, "_enqueue_resume_summary", _noop)


def _approve_template(authed, pid, yaml_text="phases: [{id: warm_up}]\n"):
    """Give a role an approved cadence template, the way the UI does.

    The template is a real session row (is_template=True) so it reuses the
    cadence editor; 'ready' on it means a person reviewed the plan, not that an
    interview is live."""
    from app import db as admin_db

    tok = authed.post(f"/api/roles/{pid}/cadence-template").json()["token"]
    admin_db.update(tok, cadence_yaml=yaml_text, status="ready")
    return tok


def test_create_interviews_batch(clients, monkeypatch, no_job_queue):
    from features.shortlist import role_routes

    async def _fake_upload(up, label):
        return "Jane Doe resume"

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer(final=85.0))

    # create_draft is the per-session schedule logic (file I/O + LLM cadence);
    # stub it so the batch endpoint is tested without spawning anything.
    import app.sessions as admin_sessions

    seen: list[str] = []

    async def _fake_create_draft(form):
        seen.append(form.cadence_yaml)
        return (f"tok-{form.candidate_name.replace(' ', '-')}", "phases: []\n")

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    authed.post(f"/api/roles/{pid}/match", files=[("resumes", ("jane.txt", b"bytes", "text/plain"))])
    cands = authed.get(f"/api/roles/{pid}/candidates").json()["candidates"]
    cpid = cands[0]["candidate_public_id"]
    _approve_template(authed, pid, "phases: [{id: warm_up}]\n")
    # Stub only AFTER the template exists — it is built by the real path.
    monkeypatch.setattr(admin_sessions, "create_draft", _fake_create_draft)

    r = authed.post(f"/api/roles/{pid}/interviews", json={"candidate_public_ids": [cpid]})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["errors"] == []
    assert len(body["created"]) == 1
    assert body["created"][0]["token"].startswith("tok-")
    assert body["created"][0]["candidate_name"] == "Jane Doe"
    # The role's cadence reaches the interview VERBATIM — not regenerated from
    # this candidate's resume, which is what made scores incomparable.
    assert seen == ["phases: [{id: warm_up}]"]


def test_create_interviews_404(clients):
    authed, _ = clients
    r = authed.post("/api/roles/nope/interviews", json={"candidate_public_ids": []})
    assert r.status_code == 404


def test_match_404_missing_role(clients):
    authed, _ = clients
    r = authed.post("/api/roles/nope/match", files=[("resumes", ("a.txt", b"x", "text/plain"))])
    assert r.status_code == 404


def test_match_requires_jd(clients, monkeypatch):
    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "NoJD", "jd_text": ""}).json()["public_id"]
    r = authed.post(f"/api/roles/{pid}/match", files=[("resumes", ("a.txt", b"x", "text/plain"))])
    assert r.status_code == 400



# ── the role's cadence template ─────────────────────────────────────────────
def test_interviews_refused_until_the_role_has_a_cadence(clients, monkeypatch):
    """The step is REQUIRED. Falling back to per-candidate generation is what
    made candidates incomparable and let interviews be created with no reviewed
    plan and no evaluation plugins (the 0/0 scorecard)."""
    from features.shortlist import role_routes

    async def _fake_upload(up, label):
        return "Jane Doe resume"

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer(final=85.0))

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    authed.post(f"/api/roles/{pid}/match", files=[("resumes", ("jane.txt", b"bytes", "text/plain"))])
    cpid = authed.get(f"/api/roles/{pid}/candidates").json()["candidates"][0]["candidate_public_id"]

    r = authed.post(f"/api/roles/{pid}/interviews", json={"candidate_public_ids": [cpid]})
    assert r.status_code == 409
    assert "cadence" in r.json()["detail"].lower()


def test_an_unapproved_cadence_is_not_enough(clients, monkeypatch, no_job_queue):
    # Generated but never reviewed by a person — the gate is approval, not
    # existence, so nobody is interviewed against a plan nobody read.
    import app.sessions as admin_sessions
    from features.shortlist import role_routes

    async def _fake_upload(up, label):
        return "Jane Doe resume"

    async def _fake_create_draft(form):
        return ("tok-x", "phases: []\n")

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer(final=85.0))
    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    authed.post(f"/api/roles/{pid}/match", files=[("resumes", ("jane.txt", b"bytes", "text/plain"))])
    cpid = authed.get(f"/api/roles/{pid}/candidates").json()["candidates"][0]["candidate_public_id"]

    tok = authed.post(f"/api/roles/{pid}/cadence-template").json()["token"]
    from app import db as admin_db
    admin_db.update(tok, cadence_yaml="phases: []\n", status="draft")

    monkeypatch.setattr(admin_sessions, "create_draft", _fake_create_draft)
    r = authed.post(f"/api/roles/{pid}/interviews", json={"candidate_public_ids": [cpid]})
    assert r.status_code == 409 and "approve" in r.json()["detail"].lower()


def test_the_template_is_created_once_and_reused(clients, no_job_queue):
    # Idempotent, so leaving the page and coming back returns to the same plan
    # instead of silently starting a second one.
    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    a = authed.post(f"/api/roles/{pid}/cadence-template").json()["token"]
    b = authed.post(f"/api/roles/{pid}/cadence-template").json()["token"]
    assert a and a == b
    assert authed.get(f"/api/roles/{pid}/cadence-template").json()["token"] == a
    assert authed.get(f"/api/roles/{pid}").json()["template_token"] == a


def test_a_template_is_never_listed_or_counted_as_an_interview(clients, no_job_queue):
    """It is a session row so it can reuse the cadence editor — it must not read
    as somebody's scheduled interview anywhere."""
    from app import db as admin_db

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    tok = _approve_template(authed, pid)          # status 'ready', like an approved interview

    assert tok not in [r["token"] for r in admin_db.list_recent(200)]
    assert admin_db.count_scheduled() == 0, "a template must not read as a scheduled interview"
    assert admin_db.count_active() == 0
    assert admin_db.has_active_session() is None
    assert admin_db.get(tok) is not None, "still addressable by token — the cadence editor needs it"


def test_a_template_uses_THE_SAME_default_as_a_scheduled_interview(clients, no_job_queue):
    """One default cadence per modality, shared by every flow that needs a
    starting plan. A second 'template' default would let the two drift apart
    silently, so this asserts byte-equality with the file the single-interview
    schedule path uses — not merely that the cadence is non-empty."""
    from engine.brain.cadence.schema import default_yaml_path_for
    from app import db as admin_db

    authed, _ = clients
    pid = authed.post("/api/roles",
                      json={"title": "AI", "jd_text": "a real JD that would have triggered the LLM",
                            "threshold": 70}).json()["public_id"]
    tok = authed.post(f"/api/roles/{pid}/cadence-template").json()["token"]

    row = admin_db.get(tok)
    assert row["status"] == "draft", "never 'generating' — the template must not wait on the LLM"
    assert row["is_template"] is True
    expected = default_yaml_path_for("voice").read_text(encoding="utf-8")
    # apply_recording_flag / apply_modality_flag stamp deterministic keys onto
    # it, so compare the PHASES rather than the raw bytes.
    import yaml as _yaml
    got = _yaml.safe_load(row["cadence_yaml"])
    assert got["phases"] == _yaml.safe_load(expected)["phases"]
    assert row["jd_text"], "the JD is kept so Revise-with-AI on that page can use it"


def test_a_text_role_uses_the_text_default_and_creates_text_interviews(clients, no_job_queue,
                                                                       monkeypatch):
    """Mode is picked once for the role and inherited. A text role creating voice
    interviews would ship an untimed cadence onto the wall-clock voice path."""
    import yaml as _yaml

    import app.sessions as admin_sessions
    from engine.brain.cadence.schema import default_yaml_path_for
    from features.shortlist import role_routes
    from app import db as admin_db

    async def _fake_upload(up, label):
        return "Jane Doe resume"

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer(final=85.0))

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70,
                                          "modality": "text"}).json()["public_id"]
    authed.post(f"/api/roles/{pid}/match", files=[("resumes", ("jane.txt", b"bytes", "text/plain"))])
    cpid = authed.get(f"/api/roles/{pid}/candidates").json()["candidates"][0]["candidate_public_id"]

    body = authed.post(f"/api/roles/{pid}/cadence-template").json()
    assert body["modality"] == "text"
    tok = body["token"]
    row = admin_db.get(tok)
    assert row["modality"] == "text"
    got = _yaml.safe_load(row["cadence_yaml"])
    assert got["phases"] == _yaml.safe_load(
        default_yaml_path_for("text").read_text(encoding="utf-8"))["phases"]
    assert got.get("timed") is False, "the text default is untimed"
    assert row["record_enabled"] is False, "a text interview has no camera or screen"

    # Every interview created from it inherits the mode.
    admin_db.update(tok, status="ready")
    forms = []

    async def _fake_create_draft(form):
        forms.append(form)
        return ("tok-jane", "phases: []\n")

    monkeypatch.setattr(admin_sessions, "create_draft", _fake_create_draft)
    r = authed.post(f"/api/roles/{pid}/interviews", json={"candidate_public_ids": [cpid]})
    assert r.status_code == 200, r.text
    assert forms[0].modality == "text"
    assert forms[0].record_enabled is False


def test_the_mode_is_a_property_of_the_role_and_is_inherited(clients, no_job_queue):
    # Chosen once when the role is created, not per template or per interview —
    # every candidate for a role takes the same interview.
    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70,
                                          "modality": "text"}).json()["public_id"]
    assert authed.get(f"/api/roles/{pid}").json()["modality"] == "text"
    first = authed.post(f"/api/roles/{pid}/cadence-template").json()
    again = authed.post(f"/api/roles/{pid}/cadence-template").json()
    assert again["token"] == first["token"] and again["modality"] == "text"


def test_approving_a_template_never_mints_a_candidate_link(clients, no_job_queue):
    """A template has no candidate. Returning a working interview link for it
    would hand out a live link to a session that is only meant to be a plan."""
    from app import db as admin_db

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    tok = authed.post(f"/api/roles/{pid}/cadence-template").json()["token"]
    yaml_text = admin_db.get(tok)["cadence_yaml"]

    r = authed.post(f"/api/schedule/{tok}/approve", json={"cadence_yaml": yaml_text})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["ok"] is True and body["is_template"] is True
    assert "candidate_link" not in body and "observer_link" not in body
    assert body["role_public_id"] == pid
    assert admin_db.get(tok)["status"] == "ready"
    assert authed.get(f"/api/roles/{pid}/cadence-template").json()["ready"] is True


# ── role states ─────────────────────────────────────────────────────────────
def test_a_new_role_is_sourcing(clients):
    authed, _ = clients
    r = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70}).json()
    assert r["state"] == "sourcing" and r["interview_count"] == 0


def test_a_role_becomes_interviewing_when_its_first_interview_is_created(clients, no_job_queue,
                                                                         monkeypatch):
    import app.sessions as admin_sessions
    from features.shortlist import role_routes

    async def _fake_upload(up, label):
        return "Jane Doe resume"

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer(final=85.0))

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    authed.post(f"/api/roles/{pid}/match", files=[("resumes", ("jane.txt", b"bytes", "text/plain"))])
    cpid = authed.get(f"/api/roles/{pid}/candidates").json()["candidates"][0]["candidate_public_id"]
    _approve_template(authed, pid)

    # The role's own cadence template must NOT count — it is a plan, not a
    # person being interviewed.
    assert authed.get(f"/api/roles/{pid}").json()["state"] == "sourcing"

    real = []

    async def _fake_create_draft(form):
        real.append(form)
        from app import db as admin_db
        admin_db.insert({
            "token": "tok-jane", "candidate_name": form.candidate_name, "role": form.role,
            "jd_path": None, "jd_text": None, "resume_path": "r.txt",
            "cadence_requirements_path": None, "cadence_requirements_text": None,
            "cadence_yaml": "phases: []\n", "status": "draft", "pid": None,
            "ws_port": None, "http_port": None, "created_at": admin_db.now_iso(),
            "started_at": None, "ended_at": None, "event_log_path": "events.jsonl",
            "record_enabled": True, "modality": form.modality,
            "is_template": False, "role_public_id": form.role_public_id or None,
        })
        return ("tok-jane", "phases: []\n")

    monkeypatch.setattr(admin_sessions, "create_draft", _fake_create_draft)
    authed.post(f"/api/roles/{pid}/interviews", json={"candidate_public_ids": [cpid]})
    assert real[0].role_public_id == pid, "the interview must be linked back to its role"

    body = authed.get(f"/api/roles/{pid}").json()
    assert body["state"] == "interviewing" and body["interview_count"] == 1


def test_closing_a_role_is_a_decision_and_overrides_the_rest(clients):
    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    assert authed.put(f"/api/roles/{pid}", json={"status": "closed"}).status_code == 200
    assert authed.get(f"/api/roles/{pid}").json()["state"] == "closed"
    # Reversible — reopening puts it back on its derived state.
    authed.put(f"/api/roles/{pid}", json={"status": "open"})
    assert authed.get(f"/api/roles/{pid}").json()["state"] == "sourcing"


def test_bulk_approve_returns_a_link_per_candidate(clients, no_job_queue, monkeypatch):
    monkeypatch.setenv("CLOUD_MODE", "1")   # the shape every container deploy runs
    """The last step of the role flow: turn the drafts into live interviews and
    hand back one link per person. It reuses the single-interview approve, so
    the cadence validation and evaluation-plan gate cannot be skipped by taking
    the bulk path."""
    from app import db as admin_db
    from app import spawner

    monkeypatch.setattr(spawner, "launch_orchestrator", lambda token: 4242)

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    from engine.brain.cadence.schema import default_yaml_path_for
    _approve_template(authed, pid)
    good_yaml = default_yaml_path_for("voice").read_text(encoding="utf-8")

    tokens = []
    for name in ("Jane", "Sam"):
        tok = f"tok-{name}"
        admin_db.insert({
            "token": tok, "candidate_name": name, "role": "AI", "jd_path": None, "jd_text": None,
            "resume_path": "r.txt", "cadence_requirements_path": None,
            "cadence_requirements_text": None, "cadence_yaml": good_yaml, "status": "draft",
            "pid": None, "ws_port": None, "http_port": None, "created_at": admin_db.now_iso(),
            "started_at": None, "ended_at": None, "event_log_path": "events.jsonl",
            "record_enabled": True, "modality": "voice", "is_template": False,
            "role_public_id": pid,
        })
        tokens.append(tok)

    r = authed.post(f"/api/roles/{pid}/interviews/approve", json={"tokens": tokens})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["errors"] == []
    assert len(body["approved"]) == 2
    for a in body["approved"]:
        assert a["candidate_link"].endswith(f"token={a['token']}")
        assert "observer_link" not in a, "no human joins an interview"
        assert admin_db.get(a["token"])["status"] == "ready"


def test_bulk_approve_reports_partial_failure_rather_than_hiding_it(clients, no_job_queue,
                                                                    monkeypatch):
    monkeypatch.setenv("CLOUD_MODE", "1")
    # One candidate's bad plan must not silently deny links to the rest.
    from app import db as admin_db
    from app import spawner

    monkeypatch.setattr(spawner, "launch_orchestrator", lambda token: 4242)

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    from engine.brain.cadence.schema import default_yaml_path_for
    _approve_template(authed, pid)
    good_yaml = default_yaml_path_for("voice").read_text(encoding="utf-8")

    for name, yaml_text in (("Jane", good_yaml), ("Broken", "phases: [[[")):
        admin_db.insert({
            "token": f"tok-{name}", "candidate_name": name, "role": "AI", "jd_path": None,
            "jd_text": None, "resume_path": "r.txt", "cadence_requirements_path": None,
            "cadence_requirements_text": None, "cadence_yaml": yaml_text, "status": "draft",
            "pid": None, "ws_port": None, "http_port": None, "created_at": admin_db.now_iso(),
            "started_at": None, "ended_at": None, "event_log_path": "events.jsonl",
            "record_enabled": True, "modality": "voice", "is_template": False,
            "role_public_id": pid,
        })

    body = authed.post(f"/api/roles/{pid}/interviews/approve",
                       json={"tokens": ["tok-Jane", "tok-Broken"]}).json()
    assert [a["candidate_name"] for a in body["approved"]] == ["Jane"]
    assert len(body["errors"]) == 1 and body["errors"][0]["candidate_name"] == "Broken"


def test_bulk_approve_refuses_an_interview_from_another_role(clients, no_job_queue):
    from app import db as admin_db

    authed, _ = clients
    a = authed.post("/api/roles", json={"title": "A", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    b = authed.post("/api/roles", json={"title": "B", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    _approve_template(authed, a)
    admin_db.insert({
        "token": "tok-other", "candidate_name": "Sam", "role": "B", "jd_path": None,
        "jd_text": None, "resume_path": "r.txt", "cadence_requirements_path": None,
        "cadence_requirements_text": None, "cadence_yaml": "phases: []\n", "status": "draft",
        "pid": None, "ws_port": None, "http_port": None, "created_at": admin_db.now_iso(),
        "started_at": None, "ended_at": None, "event_log_path": "events.jsonl",
        "record_enabled": True, "modality": "voice", "is_template": False, "role_public_id": b,
    })
    body = authed.post(f"/api/roles/{a}/interviews/approve", json={"tokens": ["tok-other"]}).json()
    assert body["approved"] == [] and "different role" in body["errors"][0]["error"]
    assert admin_db.get("tok-other")["status"] == "draft", "must not have been launched"


def test_bulk_approve_refuses_a_batch_where_only_one_can_run(clients, no_job_queue, monkeypatch):
    """Local single-laptop mode runs one interview at a time. Approving a batch
    there made the single-active guard cancel each previously approved sibling —
    so refuse the batch rather than silently mangling it."""
    monkeypatch.delenv("CLOUD_MODE", raising=False)

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    r = authed.post(f"/api/roles/{pid}/interviews/approve", json={"tokens": ["a", "b"]})
    assert r.status_code == 409 and "one interview at a time" in r.json()["detail"]


def test_a_candidates_email_is_correctable(clients, monkeypatch):
    """The address is EXTRACTED from the resume by an LLM, so it is a guess —
    and it is the one field that decides whether a real person receives their
    interview. It has to be editable."""
    from features.shortlist import role_routes

    async def _fake_upload(up, label):
        return "Jane Doe resume"

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer(final=85.0))

    authed, anon = clients
    pid = authed.post("/api/roles", json={"title": "AI", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    authed.post(f"/api/roles/{pid}/match", files=[("resumes", ("jane.txt", b"bytes", "text/plain"))])
    cand = authed.get(f"/api/roles/{pid}/candidates").json()["candidates"][0]
    assert cand["email"] == "jane@example.com", "extracted from the resume"

    cpid = cand["candidate_public_id"]
    r = authed.put(f"/api/roles/{pid}/candidates/{cpid}/email",
                   json={"email": "  corrected@example.com  "})
    assert r.status_code == 200
    assert r.json()["email"] == "corrected@example.com", "stored trimmed"
    assert authed.get(f"/api/roles/{pid}/candidates").json()["candidates"][0]["email"] == "corrected@example.com"

    # Clearing it is allowed — a missing address is better than a wrong one.
    authed.put(f"/api/roles/{pid}/candidates/{cpid}/email", json={"email": ""})
    assert authed.get(f"/api/roles/{pid}/candidates").json()["candidates"][0]["email"] == ""

    assert authed.put(f"/api/roles/{pid}/candidates/{'0'*32}/email",
                      json={"email": "x@y.z"}).status_code == 404
    assert anon.put(f"/api/roles/{pid}/candidates/{cpid}/email",
                    json={"email": "x@y.z"}).status_code == 401


def test_interviews_can_be_created_for_candidates_below_the_threshold(clients, no_job_queue,
                                                                      monkeypatch):
    """The threshold decides what is PRE-selected, never what is allowed.

    A role where nobody clears the bar (a strict threshold, a rough JD) must
    still be interviewable — the server must not quietly enforce the bar that
    the UI only uses as a default."""
    import app.sessions as admin_sessions
    from features.shortlist import role_routes

    async def _fake_upload(up, label):
        return "Jane Doe resume"

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    # Scores 13 — far below the threshold of 70.
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer(final=13.0))

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "ML", "jd_text": "jd", "threshold": 70,
                                          "modality": "text"}).json()["public_id"]
    authed.post(f"/api/roles/{pid}/match", files=[("resumes", ("jane.txt", b"bytes", "text/plain"))])
    cand = authed.get(f"/api/roles/{pid}/candidates").json()["candidates"][0]
    assert cand["above_threshold"] is False

    _approve_template(authed, pid)
    forms = []

    async def _fake_create_draft(form):
        forms.append(form)
        return ("tok-below", "phases: []\n")

    monkeypatch.setattr(admin_sessions, "create_draft", _fake_create_draft)
    r = authed.post(f"/api/roles/{pid}/interviews",
                    json={"candidate_public_ids": [cand["candidate_public_id"]]})
    assert r.status_code == 200, r.text
    assert r.json()["errors"] == [] and len(r.json()["created"]) == 1
    # And a TEXT role produces a text interview with recording off.
    assert forms[0].modality == "text" and forms[0].record_enabled is False


# ── a role's own interview stages (the chart under Resumes) ────────────────
def test_a_role_reports_its_interviews_by_stage(clients, no_job_queue, monkeypatch):
    """Counted per role and per status, so the chart on a role page shows THAT
    role's interviews rather than the platform's."""
    from app import db as admin_db
    from features.shortlist import role_store

    authed, _ = clients
    a = authed.post("/api/roles", json={"title": "A", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    b = authed.post("/api/roles", json={"title": "B", "jd_text": "jd", "threshold": 70}).json()["public_id"]

    base = dict(candidate_name="X", role="A", jd_path=None, jd_text=None,
                resume_path="r.txt", cadence_requirements_path=None,
                cadence_requirements_text=None, cadence_yaml="phases: []\n",
                pid=None, ws_port=None, http_port=None, created_at=admin_db.now_iso(),
                started_at=None, ended_at=None, event_log_path="events.jsonl",
                record_enabled=True, modality="voice", is_template=False)
    for tok, status, role_pid in [
        ("a-draft", "draft", a), ("a-ready", "ready", a),
        ("a-live", "in_progress", a), ("a-done", "completed", a),
        ("a-cancel", "cancelled", a),
        ("b-done", "completed", b),          # another role — must not leak in
        ("a-tmpl", "ready", a),              # a template — never an interview
    ]:
        admin_db.insert({**base, "token": tok, "status": status,
                         "role_public_id": role_pid,
                         "is_template": tok.endswith("tmpl")})

    st = authed.get(f"/api/roles/{a}").json()["interview_states"]
    # Each stage means exactly one thing.
    assert st["ready_to_send"] == 1, "'ready' = the link exists and is unused"
    assert st["in_progress"] == 1, "'in_progress' = the candidate has STARTED"
    assert st["completed"] == 1
    # A draft has no link yet, so it is NOT 'ready to send' — it is reported
    # separately, as is a cancelled interview. Neither inflates a slice.
    assert st["awaiting_approval"] == 1, "draft = created, not approved, no link"
    assert st["cancelled"] == 1
    assert st["ready_to_send"] + st["in_progress"] + st["completed"] == 3
    # The template is excluded from every number, including the total.
    assert st["total"] == 5, "5 real interviews for role A; the template is not one"

    assert authed.get(f"/api/roles/{b}").json()["interview_states"]["completed"] == 1


def test_every_session_status_has_a_role_stage(clients):
    """The chart shows three stages; a status with no stage is counted in the
    total but shown nowhere, so a NEW status must be mapped deliberately."""
    from features.shortlist.role_store import _ROLE_STAGE

    # draft/generating and cancelled are reported under the chart rather than
    # as slices, so they are legitimately absent from the stage map.
    every_status = {"draft", "generating", "ready", "in_progress", "completed", "cancelled"}
    reported_elsewhere = {"draft", "generating", "cancelled"}
    unmapped = every_status - set(_ROLE_STAGE) - reported_elsewhere
    assert not unmapped, f"statuses with no role stage: {unmapped}"


def test_removing_a_candidate_is_scoped_to_one_role(clients, monkeypatch):
    """Dropping someone from a shortlist must not delete the person.

    The same CV is regularly matched against several openings, so removal is
    scoped to this role's scores — the candidate, their resume and their
    standing elsewhere survive."""
    from features.shortlist import role_routes

    async def _fake_upload(up, label):
        return "Jane Doe resume"

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer(final=85.0))

    authed, anon = clients
    a = authed.post("/api/roles", json={"title": "A", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    b = authed.post("/api/roles", json={"title": "B", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    for pid in (a, b):
        authed.post(f"/api/roles/{pid}/match",
                    files=[("resumes", ("jane.txt", b"bytes", "text/plain"))])

    cpid = authed.get(f"/api/roles/{a}").json()["candidates"][0]["candidate_public_id"]
    assert authed.delete(f"/api/roles/{a}/candidates/{cpid}").status_code == 200

    assert authed.get(f"/api/roles/{a}").json()["candidates"] == [], "gone from this role"
    # Still on the OTHER role, and still a person with a resume on file.
    other = authed.get(f"/api/roles/{b}").json()["candidates"]
    assert len(other) == 1 and other[0]["candidate_public_id"] == cpid

    # Removing twice is a clear 404, not a silent success.
    assert authed.delete(f"/api/roles/{a}/candidates/{cpid}").status_code == 404
    assert anon.delete(f"/api/roles/{b}/candidates/{cpid}").status_code == 401


def test_removing_a_candidate_keeps_interviews_already_created(clients, monkeypatch):
    """An interview that happened is a record, not a shortlist entry — deleting
    it here would lose a scorecard somebody may need."""
    from app import db as admin_db
    from features.shortlist import role_routes

    async def _fake_upload(up, label):
        return "Jane Doe resume"

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer(final=85.0))

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "A", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    authed.post(f"/api/roles/{pid}/match",
                files=[("resumes", ("jane.txt", b"bytes", "text/plain"))])
    cpid = authed.get(f"/api/roles/{pid}").json()["candidates"][0]["candidate_public_id"]

    admin_db.insert({
        "token": "kept-1", "candidate_name": "Jane Doe", "role": "A", "jd_path": None,
        "jd_text": None, "resume_path": "r.txt", "cadence_requirements_path": None,
        "cadence_requirements_text": None, "cadence_yaml": "phases: []\n",
        "status": "completed", "pid": None, "ws_port": None, "http_port": None,
        "created_at": admin_db.now_iso(), "started_at": None, "ended_at": None,
        "event_log_path": "events.jsonl", "record_enabled": True, "modality": "voice",
        "is_template": False, "role_public_id": pid, "candidate_public_id": cpid,
    })

    authed.delete(f"/api/roles/{pid}/candidates/{cpid}")
    assert admin_db.get("kept-1") is not None, "the completed interview must survive"
    assert authed.get(f"/api/roles/{pid}").json()["interview_states"]["completed"] == 1


def test_a_role_lists_its_interviews_with_links_only_once_approved(clients, no_job_queue):
    """The setup screen used to show only the batch the browser remembered
    creating, so navigating away lost it. Reading from the server is what makes
    'go back to the role' a useful place to land after approving one."""
    from app import db as admin_db

    authed, anon = clients
    pid = authed.post("/api/roles", json={"title": "A", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    other = authed.post("/api/roles", json={"title": "B", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    tpl = _approve_template(authed, pid)

    base = dict(candidate_name="Jane", role="A", jd_path=None, jd_text=None,
                resume_path="r.txt", cadence_requirements_path=None,
                cadence_requirements_text=None, cadence_yaml="phases: []\n",
                pid=None, ws_port=None, http_port=None, created_at=admin_db.now_iso(),
                started_at=None, ended_at=None, event_log_path="events.jsonl",
                record_enabled=True, modality="voice", is_template=False)
    admin_db.insert({**base, "token": "iv-draft", "status": "draft", "role_public_id": pid})
    admin_db.insert({**base, "token": "iv-ready", "status": "ready", "role_public_id": pid})
    admin_db.insert({**base, "token": "iv-other", "status": "ready", "role_public_id": other})

    rows = authed.get(f"/api/roles/{pid}/interviews").json()["interviews"]
    by_token = {r["token"]: r for r in rows}

    assert set(by_token) == {"iv-draft", "iv-ready"}, "another role's interviews must not leak in"
    assert tpl not in by_token, "the cadence template is not an interview"

    # A link exists only once approved — offering one for a draft would hand
    # out a URL that does not work yet.
    assert by_token["iv-draft"]["candidate_link"] == ""
    assert by_token["iv-ready"]["candidate_link"].endswith("token=iv-ready")
    assert "observer_link" not in by_token["iv-ready"], "no human joins an interview"

    assert anon.get(f"/api/roles/{pid}/interviews").status_code == 401


def test_approving_a_role_interview_says_which_role_to_return_to(clients, no_job_queue,
                                                                 monkeypatch):
    """A single-link screen would strand the admin outside the role flow they
    were in, so the response carries the role to go back to."""
    from app import db as admin_db
    from app import spawner
    from engine.brain.cadence.schema import default_yaml_path_for

    monkeypatch.setenv("CLOUD_MODE", "1")
    monkeypatch.setattr(spawner, "launch_orchestrator", lambda token: 4242)

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "A", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    _approve_template(authed, pid)
    good = default_yaml_path_for("voice").read_text(encoding="utf-8")

    admin_db.insert({
        "token": "iv-1", "candidate_name": "Jane", "role": "A", "jd_path": None,
        "jd_text": None, "resume_path": "r.txt", "cadence_requirements_path": None,
        "cadence_requirements_text": None, "cadence_yaml": good, "status": "draft",
        "pid": None, "ws_port": None, "http_port": None, "created_at": admin_db.now_iso(),
        "started_at": None, "ended_at": None, "event_log_path": "events.jsonl",
        "record_enabled": True, "modality": "voice", "is_template": False,
        "role_public_id": pid,
    })

    body = authed.post("/api/schedule/iv-1/approve", json={"cadence_yaml": good}).json()
    assert body["ok"] is True
    assert body["role_public_id"] == pid
    assert body["candidate_link"], "it is still a real approval — the link exists"


def test_the_list_carries_the_candidate_so_the_picker_can_exclude_them(clients, no_job_queue,
                                                                       monkeypatch):
    """Somebody who already has an interview must not be offered again — a
    second interview for the same person is almost always a mistake. The picker
    filters on candidate_public_id, so the list has to carry it."""
    import app.sessions as admin_sessions
    from app import db as admin_db
    from features.shortlist import role_routes

    async def _fake_upload(up, label):
        return "Jane Doe resume"

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer(final=85.0))

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "A", "jd_text": "jd", "threshold": 70}).json()["public_id"]
    authed.post(f"/api/roles/{pid}/match", files=[("resumes", ("jane.txt", b"bytes", "text/plain"))])
    cpid = authed.get(f"/api/roles/{pid}").json()["candidates"][0]["candidate_public_id"]
    _approve_template(authed, pid)

    forms = []

    async def _fake_create_draft(form):
        forms.append(form)
        tok = "iv-jane"
        admin_db.insert({
            "token": tok, "candidate_name": form.candidate_name, "role": form.role,
            "jd_path": None, "jd_text": None, "resume_path": "r.txt",
            "cadence_requirements_path": None, "cadence_requirements_text": None,
            "cadence_yaml": "phases: []\n", "status": "draft", "pid": None,
            "ws_port": None, "http_port": None, "created_at": admin_db.now_iso(),
            "started_at": None, "ended_at": None, "event_log_path": "events.jsonl",
            "record_enabled": True, "modality": "voice", "is_template": False,
            "role_public_id": form.role_public_id or None,
            "candidate_public_id": form.candidate_public_id or None,
        })
        return (tok, "phases: []\n")

    monkeypatch.setattr(admin_sessions, "create_draft", _fake_create_draft)
    authed.post(f"/api/roles/{pid}/interviews", json={"candidate_public_ids": [cpid]})

    rows = authed.get(f"/api/roles/{pid}/interviews").json()["interviews"]
    assert len(rows) == 1
    assert rows[0]["candidate_public_id"] == cpid, (
        "without this the picker cannot tell who already has an interview"
    )
    # The email travels too, so it is editable from that same row.
    assert rows[0]["candidate_email"] == "jane@example.com"


# ── a closed role takes no new work ────────────────────────────────────────
def test_a_closed_role_refuses_every_path_that_starts_new_work(clients, no_job_queue,
                                                               monkeypatch):
    """Closing a role is a DECISION that hiring for it has stopped.

    So the four things that begin new work — matching more resumes, giving the
    role a cadence, creating interviews, handing out links — must all refuse,
    and refuse on the SERVER: the UI hides the buttons, but a stale tab or a
    direct call must not slip past. Each says the same thing, because there is
    one remedy: reopen the role."""
    import app.sessions as admin_sessions
    from features.shortlist import role_routes

    async def _fake_upload(up, label):
        return "Jane Doe resume"

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer())

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "ML", "jd_text": "jd",
                                          "threshold": 70}).json()["public_id"]
    # Shortlist one candidate and approve a cadence WHILE the role is open, so
    # every refusal below is caused by the closure and not by a missing
    # precondition that would have refused anyway.
    authed.post(f"/api/roles/{pid}/match",
                files=[("resumes", ("jane.txt", b"bytes", "text/plain"))])
    cand = authed.get(f"/api/roles/{pid}/candidates").json()["candidates"][0]
    _approve_template(authed, pid)

    async def _fake_create_draft(form):
        return ("tok-closed", "phases: []\n")

    monkeypatch.setattr(admin_sessions, "create_draft", _fake_create_draft)

    assert authed.put(f"/api/roles/{pid}", json={"status": "closed"}).status_code == 200

    calls = {
        "match": lambda: authed.post(
            f"/api/roles/{pid}/match",
            files=[("resumes", ("bob.txt", b"bytes", "text/plain"))]),
        "cadence-template": lambda: authed.post(f"/api/roles/{pid}/cadence-template"),
        "interviews": lambda: authed.post(
            f"/api/roles/{pid}/interviews",
            json={"candidate_public_ids": [cand["candidate_public_id"]]}),
        "approve": lambda: authed.post(f"/api/roles/{pid}/interviews/approve",
                                       json={"tokens": ["tok-closed"]}),
    }
    for name, call in calls.items():
        r = call()
        assert r.status_code == 409, f"{name} was allowed on a closed role: {r.text}"
        assert "closed" in r.text and "reopen" in r.text.lower(), \
            f"{name} refused without naming the remedy: {r.text}"


def test_closing_a_role_leaves_the_interviews_already_sent_alone(clients, no_job_queue,
                                                                 monkeypatch):
    """A candidate holding a link was told they are being interviewed.

    Closing the role stops NEW work; it must not revoke an interview that is
    already out, and reopening must restore the role exactly as it was."""
    import app.sessions as admin_sessions
    from app import db as admin_db
    from features.shortlist import role_routes

    async def _fake_upload(up, label):
        return "Jane Doe resume"

    monkeypatch.setattr(role_routes, "_upload_to_text", _fake_upload)
    monkeypatch.setattr(role_routes, "_get_scorer", lambda: _FakeScorer())

    authed, _ = clients
    pid = authed.post("/api/roles", json={"title": "ML", "jd_text": "jd",
                                          "threshold": 70}).json()["public_id"]
    authed.post(f"/api/roles/{pid}/match",
                files=[("resumes", ("jane.txt", b"bytes", "text/plain"))])
    cand = authed.get(f"/api/roles/{pid}/candidates").json()["candidates"][0]
    _approve_template(authed, pid)

    async def _fake_create_draft(form):
        # The real one writes the row; the fake stands in for the LLM path, so
        # the row this test reads back is inserted here.
        admin_db.insert(dict(
            token="tok-live", candidate_name="Jane", role="ML", jd_path=None,
            jd_text=None, resume_path="r.txt", cadence_requirements_path=None,
            cadence_requirements_text=None, cadence_yaml="phases: []\n",
            pid=None, ws_port=None, http_port=None, created_at=admin_db.now_iso(),
            started_at=None, ended_at=None, event_log_path="events.jsonl",
            record_enabled=True, modality="voice", is_template=False,
            status="draft", role_public_id=pid))
        return ("tok-live", "phases: []\n")

    monkeypatch.setattr(admin_sessions, "create_draft", _fake_create_draft)
    authed.post(f"/api/roles/{pid}/interviews",
                json={"candidate_public_ids": [cand["candidate_public_id"]]})
    admin_db.update("tok-live", status="ready")

    authed.put(f"/api/roles/{pid}", json={"status": "closed"})

    rows = authed.get(f"/api/roles/{pid}/interviews").json()["interviews"]
    assert [r["token"] for r in rows] == ["tok-live"]
    assert rows[0]["status"] == "ready", "an issued interview must survive the closure"
    assert authed.get(f"/api/roles/{pid}").json()["interview_states"]["ready_to_send"] == 1

    # Reopening lifts the restriction — nothing about the closure is permanent.
    authed.put(f"/api/roles/{pid}", json={"status": "open"})
    assert authed.post(f"/api/roles/{pid}/cadence-template").status_code == 200
