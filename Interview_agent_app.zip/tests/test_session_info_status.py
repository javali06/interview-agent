"""/session-info must surface the session's DB status, so the candidate page
can recognize an already-finished interview on load and refuse to offer the
Lobby again (see candidateEngine.ts::loadSessionInfo). Covers app.main's
handler only — deploy/azure_app.py carries the identical field but isn't
import-safe in this test environment (pulls in the full session-tier/
broker/Redis stack); the two are kept in agreement by inspection, per the
comment above both handlers.
"""
from __future__ import annotations

import pytest


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    from db.engine import create_all, reset_engine

    reset_engine()
    create_all()
    from fastapi.testclient import TestClient
    from app import main

    return TestClient(main.app)


def _insert_session(token: str, status: str) -> None:
    from app import db

    db.insert({
        "token": token,
        "candidate_name": "Jane Doe",
        "role": "AI Engineer",
        "resume_path": "",
        "cadence_yaml": "",
        "status": status,
        "created_at": db.now_iso(),
    })


def test_session_info_reports_completed_status(client):
    _insert_session("tok-completed", "completed")
    r = client.get("/session-info", params={"token": "tok-completed"})
    assert r.status_code == 200
    assert r.json()["status"] == "completed"


def test_session_info_reports_cancelled_status(client):
    _insert_session("tok-cancelled", "cancelled")
    r = client.get("/session-info", params={"token": "tok-cancelled"})
    assert r.json()["status"] == "cancelled"


def test_session_info_reports_ready_status_for_a_fresh_session(client):
    _insert_session("tok-ready", "ready")
    r = client.get("/session-info", params={"token": "tok-ready"})
    assert r.json()["status"] == "ready"


def test_session_info_status_is_none_without_a_token(client):
    r = client.get("/session-info")
    assert r.json()["status"] is None


# ── "over" is not the same as status=completed ──────────────────────────────
# The runner's teardown marks EVERY exit completed, crashes included. A crashed
# interview keeps its resume checkpoint, and its candidate must get back in —
# so a reopened link is refused only when completed AND no checkpoint is left.

@pytest.fixture
def redis():
    import fakeredis.aioredis as fr
    from app import coordination as coord
    coord.set_redis(fr.FakeRedis(decode_responses=True))
    yield
    coord.set_redis(None)


@pytest.mark.asyncio
@pytest.mark.parametrize("status, checkpoint, over", [
    ("completed", False, True),    # finished cleanly: checkpoint was cleared
    ("completed", True, False),    # runner crashed: resumable
    ("cancelled", True, True),     # an admin's cancel always wins
    ("in_progress", False, False),
    ("ready", False, False),
    (None, False, False),
])
async def test_interview_over(redis, status, checkpoint, over):
    from app.coordination import interview_checkpoint
    if checkpoint:
        await interview_checkpoint.save("tok", {"v": 1, "phase_id": "technical"})
    assert await interview_checkpoint.interview_over("tok", status) is over


@pytest.mark.asyncio
async def test_interview_over_refuses_when_redis_is_unreachable(monkeypatch):
    from app.coordination import interview_checkpoint

    async def boom(token):
        raise ConnectionError("redis down")
    monkeypatch.setattr(interview_checkpoint, "load", boom)
    assert await interview_checkpoint.interview_over("tok", "completed") is True


def test_session_info_sends_a_crashed_interview_back_in_not_to_done(client, redis):
    import asyncio
    from app.coordination import interview_checkpoint
    _insert_session("tok-crashed", "completed")
    _insert_session("tok-finished", "completed")
    asyncio.run(interview_checkpoint.save("tok-crashed", {"v": 1, "phase_id": "technical"}))

    crashed = client.get("/session-info", params={"token": "tok-crashed"}).json()
    finished = client.get("/session-info", params={"token": "tok-finished"}).json()
    assert crashed["status"] == "completed" and crashed["interview_over"] is False
    assert finished["interview_over"] is True
