"""Tests for the Visual Scenario Analysis runtime wiring in
`CadenceTracker` (engine/brain/core/cadence_tracker.py) and
`build_context` (engine/brain/core/conversation_context.py) — the pieces
that hand the pure `ScenarioCursor` state machine (see
test_scenario_cursor.py) to the slow LLM's system prompt / <think>
directive and to the verifier's rubric. No LLM calls, no asyncio, no WS —
these are the same "build a real CadencePlan + CadenceTracker and read the
rendered strings" tests the pool-mode machinery already gets.

Run with: python -m pytest tests/test_scenario_runtime.py -v
"""
from __future__ import annotations

import pytest

from engine.brain.cadence.schema import CadencePlan
from engine.brain.core.cadence_tracker import CadenceTracker, TickDecision
from engine.brain.core.conversation_context import build_context
from engine.brain.core.scenario_cursor import ScenarioStage
from engine.brain.contracts.session_state import SessionState


def _plan(scenario_duration_s: int = 60, terminal: bool = True, max_followups: int = 2) -> CadencePlan:
    phases = [
        {"id": "warm_up", "duration_s": 30, "intent": "settle in",
         "question_mode": "generic", "generic_prompts": ["hi"]},
        {"id": "scenario_analysis", "duration_s": scenario_duration_s, "intent": "scenario",
         "question_mode": "generic", "scenario_items": [
            {"id": "diagram_1",
             "media": {"kind": "image", "ref": "arch.png", "filename": "arch.png", "mime_type": "image/png"},
             "question": "What is missing from this diagram?",
             "coverage_tags": ["load balancer", "redundancy"],
             "max_followups": max_followups},
            {"id": "clip_1",
             "media": {"kind": "video", "ref": "demo.mp4", "filename": "demo.mp4", "mime_type": "video/mp4"},
             "question": "How would you scale this to 2000 users?",
             "coverage_tags": ["caching", "horizontal scaling"],
             "max_followups": 1},
        ]},
    ]
    if not terminal:
        phases.append({"id": "wrap_up", "duration_s": 30, "intent": "close",
                        "question_mode": "generic", "generic_prompts": ["bye"]})
    total = sum(p["duration_s"] for p in phases)
    return CadencePlan.model_validate({"total_duration_s": total, "phases": phases})


def _tracker(plan: CadencePlan, ms: int = 0) -> CadenceTracker:
    t = CadenceTracker(plan, now_ms_provider=lambda: ms)
    t.jump_to("scenario_analysis")
    return t


# ── construction ──────────────────────────────────────────────────────────


def test_tracker_builds_one_cursor_per_scenario_phase():
    plan = _plan()
    t = CadenceTracker(plan, now_ms_provider=lambda: 0)
    cursor = t.scenario_cursor("scenario_analysis")
    assert cursor is not None
    assert len(cursor.items) == 2
    assert t.scenario_cursor("warm_up") is None


def test_non_scenario_plan_has_no_cursors():
    plan = CadencePlan.model_validate({
        "total_duration_s": 30,
        "phases": [{"id": "p", "duration_s": 30, "intent": "x",
                    "question_mode": "generic", "generic_prompts": ["hi"]}],
    })
    t = CadenceTracker(plan, now_ms_provider=lambda: 0)
    assert t.scenario_cursor("p") is None
    assert t.current_scenario_item() is None
    assert t.scenario_next_action() == {"action": "noop"}


# ── check_phase_budget: scenario exhaustion ends the phase early ────────


def test_check_phase_budget_advances_when_every_item_finishes_early():
    plan = _plan(scenario_duration_s=600, terminal=False)  # huge budget, items finish way before it
    t = _tracker(plan)
    cursor = t.scenario_cursor()
    for item_id in ("diagram_1", "clip_1"):
        cursor.media_intro_dispatched(0.0)
        cursor.media_ack("ended") if cursor.current_item().media.kind != "image" else None
        cursor.question_dispatched("q")
        cursor.record_answer("great answer", "answered", [])
    assert cursor.is_phase_done()
    assert t.check_phase_budget() == TickDecision.ADVANCE


def test_check_phase_budget_ends_on_terminal_scenario_phase_exhaustion():
    plan = _plan(scenario_duration_s=600, terminal=True)  # scenario IS the last phase
    t = _tracker(plan)
    cursor = t.scenario_cursor()
    cursor.media_intro_dispatched(0.0)
    cursor.question_dispatched("q")
    cursor.record_answer("great", "answered", [])
    cursor.media_intro_dispatched(0.0)  # video item — still image-like call is harmless here (kind=video)
    cursor.media_ack("ended")
    cursor.question_dispatched("q")
    cursor.record_answer("great", "answered", [])
    assert cursor.is_phase_done()
    assert t.check_phase_budget() == TickDecision.END


def test_check_phase_budget_stays_while_items_remain_and_time_remains():
    plan = _plan(scenario_duration_s=600)
    t = _tracker(plan)
    assert t.check_phase_budget() == TickDecision.STAY


def test_check_phase_budget_time_budget_closes_out_the_cursor():
    plan = _plan(scenario_duration_s=5, terminal=False)
    clock = {"ms": 0}
    t = CadenceTracker(plan, now_ms_provider=lambda: clock["ms"])
    t.jump_to("scenario_analysis")
    clock["ms"] = 6000  # 6s elapsed since phase start, budget is 5s
    decision = t.check_phase_budget()
    assert decision == TickDecision.ADVANCE
    cursor = t.scenario_cursor()
    assert cursor.records[0].outcome == "skipped_time_budget"
    assert cursor.records[1].outcome == "not_reached"


# ── render_phase_context (static system-prompt block) ────────────────────


def test_render_phase_context_names_scenario_not_generic():
    t = _tracker(_plan())
    block = t.render_phase_context()
    assert "scenario_items" in block
    assert "scenario_items_total: 2" in block
    assert "improvise organically" not in block  # must NOT fall into the plain-generic branch


def test_render_phase_context_still_falls_back_to_generic_for_ordinary_phases():
    plan = _plan()
    t = CadenceTracker(plan, now_ms_provider=lambda: 0)  # stays on warm_up
    block = t.render_phase_context()
    assert "improvise organically" in block  # unaffected — regression guard


# ── render_transition_marker (phase-entry marker) ─────────────────────────


def test_transition_marker_names_scenario_phase_and_defers_to_think_block():
    t = CadenceTracker(_plan(), now_ms_provider=lambda: 0)
    marker = t.render_transition_marker("warm_up", "scenario_analysis")
    assert "VISUAL SCENARIO ANALYSIS phase" in marker
    assert "do not ask the question yet" in marker
    assert "scenario_items_total: 2" in marker


# ── render_think_directive across every stage ─────────────────────────────


def test_think_directive_show_media_image():
    t = _tracker(_plan())
    directive = t.render_think_directive(is_phase_entry=True)
    assert "Say ONLY this framing line" in directive
    assert "This is the image on your screen" in directive
    assert "Take a look" in directive


def test_think_directive_show_media_video_mentions_waiting():
    plan = _plan()
    t = _tracker(plan)
    cursor = t.scenario_cursor()
    cursor.media_intro_dispatched(0.0)
    cursor.question_dispatched("q")
    cursor.record_answer("great", "answered", [])  # advance to the video item
    directive = t.render_think_directive()
    assert "video" in directive
    assert "wait silently" in directive


def test_think_directive_await_media_is_empty_defensive_noop():
    plan = _plan()
    t = _tracker(plan)
    cursor = t.scenario_cursor()
    cursor.media_intro_dispatched(0.0)
    cursor.question_dispatched("q")
    cursor.record_answer("great", "answered", [])  # -> video item, AWAIT_MEDIA_INTRO
    cursor.media_intro_dispatched(0.0)             # -> AWAIT_MEDIA_ACK
    assert cursor.stage is ScenarioStage.AWAIT_MEDIA_ACK
    assert t.render_think_directive() == ""


def test_think_directive_ask_question_never_leaks_tags_as_a_list_label():
    t = _tracker(_plan())
    cursor = t.scenario_cursor()
    cursor.media_intro_dispatched(0.0)
    directive = t.render_think_directive()
    assert "REPHRASED naturally" in directive
    assert 'question: "What is missing from this diagram?"' in directive
    # first-presentation directive must NOT itself dump the coverage tags —
    # those only appear later, on the FOLLOW-UP directive, and even then
    # framed as "do not reveal".
    assert "load balancer" not in directive


def test_think_directive_followup_names_missing_tags_but_says_dont_reveal():
    t = _tracker(_plan())
    cursor = t.scenario_cursor()
    cursor.media_intro_dispatched(0.0)
    cursor.question_dispatched("q")
    cursor.record_answer("partial", "partial_answer", ["redundancy"])
    directive = t.render_think_directive()
    assert "ALREADY ASKED" in directive
    assert "redundancy" in directive
    assert "do NOT recite this list" in directive


def test_think_directive_pacing_hint_present_with_items_remaining():
    t = _tracker(_plan(scenario_duration_s=90))
    cursor = t.scenario_cursor()
    cursor.media_intro_dispatched(0.0)
    directive = t.render_think_directive()
    assert "pacing:" in directive
    assert "2 scenario items remain" in directive  # index hasn't advanced yet (media just dispatched)


def test_think_directive_phase_exhausted_wrap_up_nudge():
    t = _tracker(_plan(terminal=False))
    cursor = t.scenario_cursor()
    for _ in range(2):
        cursor.media_intro_dispatched(0.0)
        if cursor.current_item().media.kind != "image":
            cursor.media_ack("ended")
        cursor.question_dispatched("q")
        cursor.record_answer("great", "answered", [])
    directive = t.render_think_directive()
    assert "every scenario item is finished" in directive


def test_think_directive_acknowledges_previous_media_error():
    t = _tracker(_plan())
    cursor = t.scenario_cursor()
    cursor.media_intro_dispatched(0.0)
    cursor.media_ack("error")  # skips item 0, advances to item 1 (video)
    directive = t.render_think_directive()
    assert "previous item's media failed to load" in directive
    assert "didn't load" in directive


def test_think_directive_no_error_ack_on_a_clean_transition():
    t = _tracker(_plan())
    cursor = t.scenario_cursor()
    cursor.media_intro_dispatched(0.0)
    cursor.question_dispatched("q")
    cursor.record_answer("great", "answered", [])  # clean finish, no error
    directive = t.render_think_directive()
    assert "failed to load" not in directive


def test_render_scenario_item_brief_matches_current_item():
    t = _tracker(_plan())
    brief = t.render_scenario_item_brief()
    assert "VISUAL SCENARIO ANALYSIS ITEM" in brief
    assert "image" in brief


def test_render_scenario_item_brief_empty_when_not_a_scenario_phase():
    t = CadenceTracker(_plan(), now_ms_provider=lambda: 0)  # on warm_up
    assert t.render_scenario_item_brief() == ""


# ── scenario_needs_media_wait ─────────────────────────────────────────────


def test_scenario_needs_media_wait_gates_video_not_image():
    t = _tracker(_plan())
    cursor = t.scenario_cursor()
    assert not t.scenario_needs_media_wait(now_s=0.0)  # AWAIT_MEDIA_INTRO, not a wait state
    cursor.media_intro_dispatched(0.0)                 # image -> READY_TO_ASK
    assert not t.scenario_needs_media_wait(now_s=0.0)


# ── build_context / verifier rubric wiring ────────────────────────────────


def test_build_context_rubric_matches_current_scenario_item():
    t = _tracker(_plan())
    state = SessionState()
    state.phase = "scenario_analysis"
    ctx = build_context(state, now_ms=0, tracker=t)
    assert ctx.current_pool_question_rubric is not None
    assert 'question: "What is missing from this diagram?"' in ctx.current_pool_question_rubric
    assert "load balancer" in ctx.current_pool_question_rubric
    assert "coverage_tags" in ctx.current_pool_question_rubric


def test_build_context_rubric_scopes_to_prior_missing_tags_on_followup():
    t = _tracker(_plan())
    state = SessionState()
    state.phase = "scenario_analysis"
    ctx = build_context(state, now_ms=0, tracker=t, prior_missing_tags=["redundancy"])
    assert "FOLLOW-UP verification" in ctx.current_pool_question_rubric
    assert "redundancy" in ctx.current_pool_question_rubric
    assert "load balancer" not in ctx.current_pool_question_rubric


def test_build_context_descriptor_marks_scenario_exhausted():
    t = _tracker(_plan(terminal=False))
    cursor = t.scenario_cursor()
    for _ in range(2):
        cursor.media_intro_dispatched(0.0)
        if cursor.current_item().media.kind != "image":
            cursor.media_ack("ended")
        cursor.question_dispatched("q")
        cursor.record_answer("great", "answered", [])
    state = SessionState()
    state.phase = "scenario_analysis"
    ctx = build_context(state, now_ms=0, tracker=t)
    assert ctx.current_pool_question_rubric is None
    assert "scenario_status: exhausted" in ctx.current_phase_descriptor


def test_build_context_does_not_touch_pool_phase_behaviour():
    # Regression guard: an ordinary `specific` pool phase must render
    # EXACTLY as before — the new `elif` branch must not have changed the
    # pool branch's own behaviour.
    plan = CadencePlan.model_validate({
        "total_duration_s": 30,
        "phases": [{"id": "p", "duration_s": 30, "intent": "x",
                    "question_mode": "specific",
                    "question_pool": [{"id": "q1", "text": "Explain X",
                                        "coverage_tags": ["a", "b"]}]}],
    })
    t = CadenceTracker(plan, now_ms_provider=lambda: 0)
    state = SessionState()
    state.phase = "p"
    ctx = build_context(state, now_ms=0, tracker=t)
    assert 'question: "Explain X"' in ctx.current_pool_question_rubric
    assert "coverage_tags" in ctx.current_pool_question_rubric
