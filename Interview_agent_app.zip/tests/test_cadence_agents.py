"""The three cadence-editor agents (ROUTER → MODIFYING → VALIDATING) plus the
orchestrator that wires them, and the deterministic duration math they share.

No real network/LLM calls: `openai.AsyncOpenAI` is monkeypatched to a fake
client whose responses are dispatched by WHICH SYSTEM PROMPT the call used, so
each test exercises exactly the agent it names. The pure helpers (duration
parsing/rescaling, conflict detection) are tested directly — they must never
need an LLM.
"""
from __future__ import annotations

import asyncio
import json

import pytest
import yaml

from app import cadence_service
from app.cadence_agents import (
    ALL_PHASES,
    CODE_DISCUSSION_ID,
    CadenceLLM,
    phase_content_view,
    ClauseOutcome,
    ModifyingAgent,
    PHASE_REVISE_SYSTEM_PROMPT,
    PLAUSIBLE_REF,
    ROUTER_SYSTEM_PROMPT,
    RouterAgent,
    VALIDATOR_SYSTEM_PROMPT,
    ValidatingAgent,
    capability_message,
    derive_phase_id,
    detect_and_apply_phase_mutations,
    detect_structure_verb,
    is_time_change_ask,
    blacklist_entry,
    has_coding_round,
    load_phase_blacklist,
    reads_as_confirmation,
    detect_duration_conflicts,
    extract_context_for_instruction,
    find_best_phase_match,
    parse_absolute_duration_target,
    parse_relative_duration_delta,
    plan_deterministic,
    plan_structure_op,
    reconcile_total_with_pins,
    rescale_to_clean_minutes,
    rescale_to_exact_total,
    resolve_phase_ref,
    resolve_total_target,
)

_CADENCE_YAML = """\
total_duration_s: 120
phases:
  - id: warm_up
    duration_s: 30
    intent: Put the candidate at ease.
    question_mode: generic
    generic_prompts:
      - "Greet the candidate."
  - id: resume_deep_dive
    duration_s: 60
    intent: Assess a resume project.
    question_mode: generic
    generic_prompts:
      - "Ask about a project."
  - id: wrap_up
    duration_s: 30
    intent: Close the interview gracefully.
    question_mode: generic
    generic_prompts:
      - "Say goodbye."
"""


def _phases() -> list[dict]:
    return yaml.safe_load(_CADENCE_YAML)["phases"]


# ── fake OpenAI client plumbing ──────────────────────────────────────────

class _FakeMessage:
    def __init__(self, content: str) -> None:
        self.content = content


class _FakeChoice:
    def __init__(self, content: str) -> None:
        self.message = _FakeMessage(content)


class _FakeResp:
    def __init__(self, content: str) -> None:
        self.choices = [_FakeChoice(content)]
        self.usage = None  # trace_call's finish() tolerates a missing usage block


class _FakeCompletions:
    def __init__(self, responder) -> None:
        self._responder = responder

    async def create(self, **kwargs):
        return _FakeResp(await self._responder(kwargs))


class _FakeChat:
    def __init__(self, responder) -> None:
        self.completions = _FakeCompletions(responder)


class FakeClient:
    def __init__(self, responder) -> None:
        self.chat = _FakeChat(responder)


def make_llm(responder) -> CadenceLLM:
    return CadenceLLM(client=FakeClient(responder), model="test-model", extra_body={})


def make_fake_async_openai(responder):
    """Class matching `openai.AsyncOpenAI`'s constructor shape, for
    monkeypatching so `_build_cadence_llm` picks up the fake."""
    class _Fake:
        def __init__(self, *a, **kw) -> None:
            self.chat = _FakeChat(responder)
    return _Fake


@pytest.fixture()
def fixed_llm(monkeypatch):
    monkeypatch.setattr(
        cadence_service, "_resolve_llm",
        lambda: ("dummy-key", "https://api.groq.com/openai/v1", "test-model"),
    )


@pytest.fixture()
def wire_openai(monkeypatch):
    def _wire(responder):
        import openai as openai_pkg
        monkeypatch.setattr(openai_pkg, "AsyncOpenAI", make_fake_async_openai(responder))
    return _wire


def _system(kwargs) -> str:
    return kwargs["messages"][0]["content"]


def _user(kwargs) -> str:
    return kwargs["messages"][-1]["content"]


def _phase_arg(kwargs) -> dict:
    import re
    m = re.search(r"CURRENT PHASE \(JSON\):\n(.*?)\n\nINSTRUCTIONS", _user(kwargs), re.DOTALL)
    assert m, f"couldn't find phase JSON in: {_user(kwargs)[:200]}"
    return json.loads(m.group(1))


# ══════════════════════════════════════════════════════════════════════════
# deterministic duration math (no LLM involved, ever)
# ══════════════════════════════════════════════════════════════════════════

@pytest.mark.parametrize("text,expected", [
    ("make the interview 10 minutes", 600),
    ("set it to 600 seconds", 600),
    ("make it 1.5 hours", 5400),
    ("make it 90 secs", 90),
    # relative asks are NOT absolute targets — left to the LLM
    ("add 2 more minutes", None),
    ("shorten by 3 minutes", None),
    ("reduce it by 5 min", None),
    # ambiguous/none
    ("make it 5 minutes then 8 minutes", None),
    ("make it shorter", None),
])
def test_parse_absolute_duration_target(text, expected):
    assert parse_absolute_duration_target([text]) == expected


def test_rescale_to_exact_total_hits_target_exactly():
    phases = [{"id": "a", "duration_s": 30}, {"id": "b", "duration_s": 60}, {"id": "c", "duration_s": 30}]
    out = rescale_to_exact_total(phases, 901)  # deliberately awkward, not divisible
    assert sum(p["duration_s"] for p in out) == 901
    assert all(p["duration_s"] >= 1 for p in out)
    # relative ordering by share is preserved
    by_id = {p["id"]: p["duration_s"] for p in out}
    assert by_id["b"] > by_id["a"]


def test_rescale_to_exact_total_keeps_every_phase_at_least_one_second():
    phases = [{"id": f"p{i}", "duration_s": 60} for i in range(5)]
    out = rescale_to_exact_total(phases, 5)
    assert sum(p["duration_s"] for p in out) == 5
    assert all(p["duration_s"] == 1 for p in out)


@pytest.mark.parametrize("text,expected", [
    ("add 2 minutes", 120),
    ("add 2 more minutes to the interview", 120),
    ("shorten it by 3 minutes", -180),
    ("reduce it by 30 seconds", -30),
    ("cut 1 minute", -60),
    # no direction, contradictory, or not one number → ask, don't guess
    ("make it 10 minutes", None),
    ("add less than 5 minutes", None),
    ("add 2 minutes then 3 minutes", None),
    ("make it shorter", None),
])
def test_parse_relative_duration_delta(text, expected):
    assert parse_relative_duration_delta([text]) == expected


@pytest.mark.parametrize("text,expected", [
    ("make the whole interview 15 minutes", 900),   # absolute wins
    ("add 2 minutes", 240),                         # relative, off current 120
    ("shorten it by 1 minute", 60),
    ("make it shorter", None),                      # nothing pinnable → ask
    ("shorten it by 10 minutes", None),             # would go non-positive
])
def test_resolve_total_target(text, expected):
    assert resolve_total_target([text], 120) == expected


def test_rescale_to_clean_minutes_lands_on_whole_minutes():
    """The reported bug: "make the whole interview 15 minutes" produced
    1:53 / 3:45 / 7:30 / 1:52. Whole minutes, exact total, shares preserved."""
    shot = [
        {"id": "warm_up", "duration_s": 113},
        {"id": "resume_deep_dive", "duration_s": 225},
        {"id": "technical_questions", "duration_s": 450},
        {"id": "wrap_up", "duration_s": 112},
    ]
    out = rescale_to_clean_minutes(shot, 900)
    durations = [p["duration_s"] for p in out]
    assert sum(durations) == 900
    assert all(d % 60 == 0 for d in durations), f"not whole minutes: {durations}"
    # The longest phase is still the longest — relative weight is preserved.
    by_id = {p["id"]: p["duration_s"] for p in out}
    assert by_id["technical_questions"] == max(durations)


@pytest.mark.parametrize("target_min", [10, 15, 20, 30, 45, 60])
def test_rescale_to_clean_minutes_is_whole_minutes_for_any_sane_target(target_min):
    phases = [{"id": f"p{i}", "duration_s": d} for i, d in enumerate((30, 60, 450, 30))]
    out = rescale_to_clean_minutes(phases, target_min * 60)
    durations = [p["duration_s"] for p in out]
    assert sum(durations) == target_min * 60
    assert all(d % 60 == 0 for d in durations), f"{target_min}min -> {durations}"
    assert all(d >= 60 for d in durations), "no phase should vanish"


# ══════════════════════════════════════════════════════════════════════════════
# Phase mutations & fuzzy matching
# ══════════════════════════════════════════════════════════════════════════════

def test_phase_ref_matches_any_spelling_of_the_name():
    """The bug this exists for: "wrapup" / "wrap up" / "wrap-up" are all wrap_up.

    The old difflib-on-the-whole-instruction scorer gave "remove the wrapup
    phase" 0.65 against "wrap_up" and gated at 0.7, so the removal was silently
    dropped."""
    phases = _phases()
    for spelling in ("remove the wrapup phase", "drop the wrap up round",
                     "delete Wrap-Up", "get rid of wrap_up"):
        pid, score, _ = resolve_phase_ref(spelling, phases)
        assert pid == "wrap_up", spelling
        assert score >= 0.9


def test_phase_ref_tolerates_a_typo_in_the_name():
    """"warumup 2min30sec" must still land on warm_up — the admin shouldn't have
    to retype a name to get their edit."""
    pid, score, _ = resolve_phase_ref("warumup 2min30sec", _phases())
    assert pid == "warm_up"
    assert score >= 0.9


def test_phase_ref_does_not_confuse_warm_up_with_wrap_up():
    """The two most collidable ids in the default cadence."""
    assert resolve_phase_ref("make the warmup longer", _phases())[0] == "warm_up"
    assert resolve_phase_ref("make the wrapup longer", _phases())[0] == "wrap_up"


def test_phase_ref_offers_an_intent_match_as_a_GUESS_not_a_match():
    """"system architecture" only matches technical_questions via its INTENT.

    That's an inference, not a name — so it comes back as a candidate to confirm,
    never as something to silently rewrite."""
    phases = _phases()
    # Names nothing; only resume_deep_dive's INTENT ("Assess a resume project")
    # shares vocabulary with it.
    pid, score, ranked = resolve_phase_ref("make the bit where we assess a project harder", phases)
    assert pid is None, "an intent match must be confirmed, not applied"
    assert ranked and ranked[0] == "resume_deep_dive"
    assert score >= PLAUSIBLE_REF


def test_phase_ref_no_match_lists_every_phase():
    """"hr round" doesn't exist; the admin gets the real list to pick from."""
    phases = _phases()
    pid, score, ranked = resolve_phase_ref("make hr round 3min", phases)
    assert pid is None
    assert score < PLAUSIBLE_REF
    assert set(ranked) <= {p["id"] for p in phases}


def test_find_best_phase_match_back_compat():
    """The 2-tuple wrapper still works for callers that only want (id, score)."""
    pid, score = find_best_phase_match("remove the wrapup phase", _phases())
    assert (pid, score >= 0.9) == ("wrap_up", True)


def test_extract_context_for_instruction_triggers():
    """Instruction mentioning project/resume gets context."""
    assert extract_context_for_instruction("ask about their projects")
    assert extract_context_for_instruction("reference the candidate's experience")
    assert extract_context_for_instruction("deep dive into the resume")


def test_extract_context_for_instruction_no_trigger():
    """Instruction with no context triggers doesn't get context."""
    assert not extract_context_for_instruction("make it friendlier")
    assert not extract_context_for_instruction("reduce the duration")


def test_detect_and_apply_phase_mutations_remove():
    """Remove a phase deterministically."""
    phases = _phases()
    modified, remaining = detect_and_apply_phase_mutations(
        ["remove the wrap_up phase"], phases
    )
    assert {p["id"] for p in modified} == {"warm_up", "resume_deep_dive"}
    assert remaining == []


def test_detect_and_apply_phase_mutations_reorder():
    """Reorder phases deterministically."""
    phases = _phases()
    modified, remaining = detect_and_apply_phase_mutations(
        ["move resume_deep_dive before warm_up"], phases
    )
    assert [p["id"] for p in modified] == ["resume_deep_dive", "warm_up", "wrap_up"]
    assert remaining == []


def test_detect_and_apply_phase_mutations_add_returns_to_remaining():
    """'Add phase' never applies; returns to remaining for router."""
    phases = _phases()
    modified, remaining = detect_and_apply_phase_mutations(
        ["add a coding phase"], phases
    )
    assert modified == phases, "no phases modified"
    assert remaining == ["add a coding phase"], "add request returned to router"


def test_detect_and_apply_phase_mutations_mixed():
    """Multiple mutations, some apply, some ask for clarity."""
    phases = _phases()
    modified, remaining = detect_and_apply_phase_mutations(
        ["remove wrap_up", "make it friendlier", "swap warm_up and resume_deep_dive"],
        phases,
    )
    assert {p["id"] for p in modified} == {"warm_up", "resume_deep_dive"}
    assert [p["id"] for p in modified] == ["resume_deep_dive", "warm_up"]
    assert "make it friendlier" in remaining


def test_detect_and_apply_phase_mutations_no_match_remove():
    """Remove with no matching phase returns instruction to remaining."""
    phases = _phases()
    modified, remaining = detect_and_apply_phase_mutations(
        ["remove the hr round"], phases  # no such phase
    )
    assert modified == phases
    assert "remove the hr round" in remaining


def test_rescale_to_clean_minutes_honours_an_explicit_sub_minute_pin():
    """"make the warm-up 15 seconds" is MORE specific than "the interview is 15
    minutes", so it survives literally — only it is allowed to be non-round."""
    phases = [
        {"id": "warm_up", "duration_s": 15},
        {"id": "resume_deep_dive", "duration_s": 60},
        {"id": "wrap_up", "duration_s": 30},
    ]
    out = rescale_to_clean_minutes(phases, 900, {"warm_up"})
    by_id = {p["id"]: p["duration_s"] for p in out}
    assert by_id["warm_up"] == 15
    assert sum(by_id.values()) == 900
    # The odd seconds land on exactly ONE flexible phase, not smeared over all.
    assert sum(1 for pid, d in by_id.items() if pid != "warm_up" and d % 60) == 1


def test_rescale_to_clean_minutes_falls_back_when_a_minute_each_is_impossible():
    phases = [{"id": f"p{i}", "duration_s": 60} for i in range(4)]
    out = rescale_to_clean_minutes(phases, 100)   # 1:40 across 4 phases
    assert sum(p["duration_s"] for p in out) == 100, "exactness beats prettiness"
    assert all(p["duration_s"] >= 1 for p in out)


def test_reconcile_total_with_pins_honours_the_pin():
    """The core merge edge case: "warm-up 5 min AND whole interview 15 min" —
    the pin holds, the difference is absorbed by the phases nobody mentioned."""
    phases = [
        {"id": "warm_up", "duration_s": 300},
        {"id": "resume_deep_dive", "duration_s": 60},
        {"id": "wrap_up", "duration_s": 30},
    ]
    out = reconcile_total_with_pins(phases, 900, {"warm_up"})
    assert out is not None
    by_id = {p["id"]: p["duration_s"] for p in out}
    assert by_id["warm_up"] == 300              # pin untouched
    assert sum(by_id.values()) == 900           # target hit exactly
    assert by_id["resume_deep_dive"] > by_id["wrap_up"]  # shares preserved


def test_reconcile_total_with_pins_gives_up_when_pins_exceed_target():
    phases = [{"id": "warm_up", "duration_s": 900}, {"id": "wrap_up", "duration_s": 30}]
    # Pin alone (900) leaves < 1s for the remaining phase → impossible.
    assert reconcile_total_with_pins(phases, 900, {"warm_up"}) is None


def test_detect_duration_conflicts_flags_two_absolutes_on_one_phase():
    clauses = [
        {"clause_id": "c1", "kind": "phase", "phase_id": "warm_up", "text": "make warm-up 5 minutes"},
        {"clause_id": "c2", "kind": "phase", "phase_id": "warm_up", "text": "make warm-up 8 minutes"},
    ]
    out = detect_duration_conflicts(clauses)
    assert {c["clause_id"] for c in out} == {"c1", "c2"}
    assert all(c["kind"] == "ambiguous" for c in out)
    assert out[0]["options"] == ["5:00", "8:00"]


def test_detect_duration_conflicts_ignores_agreeing_and_single_values():
    clauses = [
        {"clause_id": "c1", "kind": "phase", "phase_id": "warm_up", "text": "make warm-up 5 minutes"},
        {"clause_id": "c2", "kind": "phase", "phase_id": "wrap_up", "text": "make wrap-up 2 minutes"},
        {"clause_id": "c3", "kind": "phase", "phase_id": ALL_PHASES,
         "text": "make the interview 15 minutes"},
    ]
    assert detect_duration_conflicts(clauses) == []


def test_capability_message_always_lists_capabilities():
    msg = capability_message("add a system design phase", "use the Add coding phase button")
    assert "add a system design phase" in msg
    assert "change the interview's total duration" in msg   # capabilities listed
    assert "Add coding phase button" in msg           # suggestion carried


# ══════════════════════════════════════════════════════════════════════════
# 1. ROUTER agent
# ══════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_router_splits_phase_and_whole_interview_clauses():
    """Two kinds only. A whole-interview ask is still a "phase" clause — it just
    carries the reserved ALL id, and the total is then arithmetic, not an LLM call."""
    async def responder(kwargs):
        assert _system(kwargs) == ROUTER_SYSTEM_PROMPT
        payload = json.loads(_user(kwargs))
        # Only id/intent/duration reach the router — never phase content.
        for p in payload["phases"]:
            assert set(p) == {"id", "intent", "duration_s"}
        return json.dumps({"clauses": [
            {"kind": "phase", "text": "ask about projects", "phase_id": "resume_deep_dive"},
            {"kind": "phase", "text": "make the whole interview 15 minutes", "phase_id": "ALL"},
        ]})

    r = await RouterAgent(make_llm(responder)).route(
        feedback="ask about projects and make the whole interview 15 minutes",
        clarifications=[], phases=_phases(), total_duration_s=120,
    )
    # phase_mapping is what fans out to concurrent calls; ALL is excluded from it.
    assert r.phase_mapping == {"resume_deep_dive": ["ask about projects"]}
    assert r.total_instructions == ["make the whole interview 15 minutes"]
    assert r.questions == [] and r.out_of_scope == []


@pytest.mark.parametrize("feedback", ["make the interview shorter", "trim the interview a bit"])
def test_whole_interview_ask_with_no_number_is_asked_about(feedback):
    """"make the interview shorter" carries no number, so it must ASK.

    This check moved from the ROUTER to the deterministic pre-pass: the router now
    only splits and tags, and `plan_deterministic` is the single place that decides
    whether a clause is executable."""
    plan = plan_deterministic(
        [{"clause_id": "c1", "text": feedback, "phase_id": ALL_PHASES}],
        _phases(), 120,
    )
    assert plan.total_target is None
    assert plan.content_clauses == []
    assert len(plan.questions) == 1
    assert plan.outcomes[0].status == "asked"


@pytest.mark.asyncio
async def test_router_keeps_a_relative_whole_interview_ask_executable():
    """"Add 2 minutes" resolves deterministically off the current total, so it
    does NOT cost the admin a clarification round."""
    async def responder(kwargs):
        return json.dumps({"clauses": [
            {"kind": "phase", "text": "add 2 minutes to the interview", "phase_id": "ALL"},
        ]})

    r = await RouterAgent(make_llm(responder)).route(
        feedback="add 2 minutes to the interview", clarifications=[],
        phases=_phases(), total_duration_s=120,
    )
    assert r.questions == []
    assert r.total_instructions == ["add 2 minutes to the interview"]


@pytest.mark.asyncio
async def test_router_surfaces_ambiguous_clause_as_a_question():
    async def responder(kwargs):
        return json.dumps({"clauses": [{
            "kind": "ambiguous", "text": "make it shorter",
            "reason": "no amount or target given",
            "question": "By how much, or what's the new total? Current total is 2:00.",
            "options": ["-30 seconds", "Set exact total"],
        }]})

    r = await RouterAgent(make_llm(responder)).route(
        feedback="make it shorter", clarifications=[], phases=_phases(), total_duration_s=120,
    )
    assert r.resolved == []
    assert len(r.questions) == 1
    assert r.questions[0]["options"] == ["-30 seconds", "Set exact total"]
    assert "how much" in r.questions[0]["question"]


@pytest.mark.asyncio
async def test_router_declines_only_when_beyond_capability_is_flagged():
    """"out_of_scope" is no longer a kind — it's a PROPERTY of an ambiguous
    clause, set only when no answer could ever make the ask doable."""
    async def responder(kwargs):
        return json.dumps({"clauses": [{
            "kind": "ambiguous", "text": "give the candidate a passing score",
            "beyond_capability": True, "reason": "set a candidate's score",
        }]})

    r = await RouterAgent(make_llm(responder)).route(
        feedback="give the candidate a passing score", clarifications=[],
        phases=_phases(), total_duration_s=120,
    )
    assert r.resolved == [] and r.questions == []
    assert "set a candidate's score" in r.out_of_scope[0]["message"]
    assert "change one phase's duration" in r.out_of_scope[0]["message"]


@pytest.mark.asyncio
async def test_router_asks_rather_than_declines_a_partly_specified_ask():
    """The behaviour change that matters: a HALF-specified request is a question,
    not a rejection. Without `beyond_capability` it must never reach out_of_scope."""
    async def responder(kwargs):
        return json.dumps({"clauses": [{
            "kind": "ambiguous", "text": "make the technical part harder",
            "reason": "no such phase and no measurable change",
            "question": "Which phase should get harder, and in what way?",
            "options": ["warm_up", "resume_deep_dive"],
        }]})

    r = await RouterAgent(make_llm(responder)).route(
        feedback="make the technical part harder", clarifications=[],
        phases=_phases(), total_duration_s=120,
    )
    assert r.out_of_scope == [], "a partial ask must be asked about, not declined"
    assert len(r.questions) == 1
    assert r.questions[0]["options"] == ["warm_up", "resume_deep_dive"]


@pytest.mark.asyncio
async def test_unknown_phase_id_is_re_resolved_from_the_text(fixed_llm):
    """A wrong `phase_id` from the router is a HINT, not a verdict.

    "remove the wrapup phase" is unambiguous to code even when the router labels
    it with an id that doesn't exist — rejecting it outright used to throw away a
    perfectly executable ask."""
    async def responder(kwargs):
        return json.dumps({"clauses": [
            {"kind": "phase", "text": "remove the wrapup phase", "phase_id": "hr_round"},
        ]})

    route = await RouterAgent(make_llm(responder)).route(
        feedback="remove the wrapup phase", clarifications=[],
        phases=_phases(), total_duration_s=120,
    )
    assert route.resolved[0]["phase_id"] == "", "an unusable id is blanked, not rejected"
    plan = plan_deterministic(route.resolved, _phases(), 120)
    assert [p["id"] for p in plan.phases] == ["warm_up", "resume_deep_dive"]
    assert plan.outcomes[0].message == "Removed the wrap-up phase"


@pytest.mark.asyncio
async def test_router_demotes_unknown_kind_to_a_question():
    async def responder(kwargs):
        return json.dumps({"clauses": [{"kind": "banana", "text": "do a thing"}]})

    r = await RouterAgent(make_llm(responder)).route(
        feedback="do a thing", clarifications=[], phases=_phases(), total_duration_s=120,
    )
    assert len(r.questions) == 1 and r.resolved == []


@pytest.mark.asyncio
async def test_router_detects_conflicting_durations_without_an_extra_call():
    calls = []

    async def responder(kwargs):
        calls.append(1)
        return json.dumps({"clauses": [
            {"kind": "phase", "text": "make warm_up 5 minutes", "phase_id": "warm_up"},
            {"kind": "phase", "text": "make warm_up 8 minutes", "phase_id": "warm_up"},
        ]})

    r = await RouterAgent(make_llm(responder)).route(
        feedback="make warm_up 5 minutes and make warm_up 8 minutes",
        clarifications=[], phases=_phases(), total_duration_s=120,
    )
    assert len(calls) == 1, "conflict detection must be deterministic, not another LLM call"
    assert r.resolved == []
    assert len(r.questions) == 2
    assert r.questions[0]["options"] == ["5:00", "8:00"]


@pytest.mark.asyncio
async def test_router_passes_clarification_answers_back_into_the_same_call():
    seen = {}

    async def responder(kwargs):
        seen["payload"] = json.loads(_user(kwargs))
        return json.dumps({"clauses": [
            {"kind": "phase", "text": "make it friendlier", "phase_id": "warm_up"},
        ]})

    r = await RouterAgent(make_llm(responder)).route(
        feedback="", phases=_phases(), total_duration_s=120,
        clarifications=[{"text": "make the HR round friendlier",
                         "question": "Which phase?", "answer": "warm_up"}],
    )
    assert seen["payload"]["clarifications"][0]["answer"] == "warm_up"
    assert r.phase_mapping == {"warm_up": ["make it friendlier"]}


@pytest.mark.asyncio
async def test_router_unanswered_clarifications_are_not_sent():
    seen = {}

    async def responder(kwargs):
        seen["payload"] = json.loads(_user(kwargs))
        return json.dumps({"clauses": [
            {"kind": "phase", "text": "shrink the warm up to 10 seconds", "phase_id": "warm_up"},
        ]})

    await RouterAgent(make_llm(responder)).route(
        feedback="shrink it", phases=_phases(), total_duration_s=120,
        clarifications=[{"text": "x", "question": "y", "answer": "  "}],
    )
    assert seen["payload"]["clarifications"] == []


@pytest.mark.asyncio
async def test_router_raises_on_llm_error():
    async def responder(kwargs):
        raise RuntimeError("provider down")

    with pytest.raises(ValueError):
        await RouterAgent(make_llm(responder)).route(
            feedback="anything", clarifications=[], phases=_phases(), total_duration_s=120,
        )


@pytest.mark.asyncio
async def test_router_raises_on_empty_clause_list():
    async def responder(kwargs):
        return json.dumps({"clauses": []})

    with pytest.raises(ValueError):
        await RouterAgent(make_llm(responder)).route(
            feedback="anything", clarifications=[], phases=_phases(), total_duration_s=120,
        )


# ══════════════════════════════════════════════════════════════════════════
# 2. MODIFYING agent
# ══════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_revise_phase_success():
    async def responder(kwargs):
        assert _system(kwargs) == PHASE_REVISE_SYSTEM_PROMPT
        phase = _phase_arg(kwargs)
        phase["duration_s"] = 180
        return json.dumps(phase)

    revised = await ModifyingAgent(make_llm(responder)).revise_phase(
        _phases()[0], ["make it 3 minutes"],
    )
    assert revised["id"] == "warm_up" and revised["duration_s"] == 180


@pytest.mark.asyncio
async def test_revise_phase_raises_after_three_bad_attempts():
    calls = []

    async def responder(kwargs):
        calls.append(1)
        return "{}"  # fails PhaseDef validation every time

    with pytest.raises(ValueError):
        await ModifyingAgent(make_llm(responder)).revise_phase(_phases()[0], ["do something"])
    assert len(calls) == 3


@pytest.mark.asyncio
async def test_revise_phase_attaches_resume_context_only_when_referenced():
    seen = {}

    async def responder(kwargs):
        seen[_phase_arg(kwargs)["id"]] = "CANDIDATE CONTEXT" in _user(kwargs)
        return json.dumps(_phase_arg(kwargs))

    agent = ModifyingAgent(make_llm(responder))
    await agent.revise_phase(_phases()[0], ["make it more engaging"], "RESUME TEXT")
    assert seen["warm_up"] is False, "no trigger word → no resume/JD attached"

    await agent.revise_phase(_phases()[1], ["ask about a project"], "RESUME TEXT")
    assert seen["resume_deep_dive"] is True, "'project' is a trigger word → context attached"


@pytest.mark.asyncio
async def test_apply_sets_the_total_in_whole_minutes_with_no_extra_llm_call():
    """The regression this rework targets: "make the whole interview 15 minutes"
    used to yield 1:53 / 3:45 / 7:30 / 1:52 via second-level proportional
    rescaling. It must land on whole minutes, exactly on target, and the total
    must cost ZERO LLM calls (no structure call exists any more)."""
    calls = []

    async def responder(kwargs):
        calls.append(_system(kwargs))
        raise AssertionError("a pure total change must not call any LLM")

    result = await ModifyingAgent(make_llm(responder)).apply(
        data=yaml.safe_load(_CADENCE_YAML), phases=_phases(), phase_mapping={},
        total_instructions=["make the whole interview 15 minutes"], current_total=120,
    )
    assert calls == [], "total duration is arithmetic, not a prompt"
    assert result.ok
    durations = [p["duration_s"] for p in result.data["phases"]]
    assert sum(durations) == 900
    assert all(d % 60 == 0 for d in durations), f"not whole minutes: {durations}"
    assert result.data["total_duration_s"] == 900


@pytest.mark.asyncio
async def test_apply_honours_a_relative_total_ask_off_the_current_total():
    result = await ModifyingAgent(make_llm(_never_called)).apply(
        data=yaml.safe_load(_CADENCE_YAML), phases=_phases(), phase_mapping={},
        total_instructions=["add 3 minutes to the interview"], current_total=120,
    )
    assert result.data["total_duration_s"] == 300  # 2:00 + 3:00
    assert all(p["duration_s"] % 60 == 0 for p in result.data["phases"])


@pytest.mark.asyncio
async def test_apply_pins_an_explicit_phase_duration_against_the_total():
    """"warm-up 30 seconds AND whole interview 15 minutes" — the explicit
    sub-minute ask is MORE specific, so it survives literally while the phases
    the admin said nothing about absorb the rest."""
    async def responder(kwargs):
        phase = _phase_arg(kwargs)
        phase["duration_s"] = 30
        return json.dumps(phase)

    result = await ModifyingAgent(make_llm(responder)).apply(
        data=yaml.safe_load(_CADENCE_YAML), phases=_phases(),
        phase_mapping={"warm_up": ["make the warm up 30 seconds"]},
        total_instructions=["make the whole interview 15 minutes"], current_total=120,
    )
    by_id = {p["id"]: p["duration_s"] for p in result.data["phases"]}
    assert by_id["warm_up"] == 30, "an explicit sub-minute ask is honoured literally"
    assert sum(by_id.values()) == 900
    assert result.ok


@pytest.mark.asyncio
async def test_apply_reports_an_unreachable_total_instead_of_mangling_it():
    async def responder(kwargs):
        phase = _phase_arg(kwargs)
        phase["duration_s"] = 1200          # 20 min pinned inside a 5 min interview
        return json.dumps(phase)

    result = await ModifyingAgent(make_llm(responder)).apply(
        data=yaml.safe_load(_CADENCE_YAML), phases=_phases(),
        phase_mapping={"warm_up": ["make the warm up 20 minutes"]},
        total_instructions=["make the whole interview 5 minutes"], current_total=120,
    )
    assert not result.ok
    assert "already add up to more than" in result.total_error
    # The phase edit that DID work is still applied.
    assert {p["id"]: p["duration_s"] for p in result.data["phases"]}["warm_up"] == 1200


@pytest.mark.asyncio
async def test_apply_runs_phase_calls_concurrently():
    """Two phase edits in one request must overlap, not queue."""
    active, peak = 0, 0

    async def responder(kwargs):
        nonlocal active, peak
        active += 1
        peak = max(peak, active)
        await asyncio.sleep(0.05)
        active -= 1
        return json.dumps(_phase_arg(kwargs))

    result = await ModifyingAgent(make_llm(responder)).apply(
        data=yaml.safe_load(_CADENCE_YAML), phases=_phases(),
        phase_mapping={"warm_up": ["a"], "resume_deep_dive": ["b"]},
        total_instructions=[], current_total=120,
    )
    assert peak == 2, f"phase calls did not overlap (peak={peak})"
    assert result.ok


@pytest.mark.asyncio
async def test_apply_reports_failure_without_raising():
    async def responder(kwargs):
        return "{}"  # every phase attempt fails validation

    result = await ModifyingAgent(make_llm(responder)).apply(
        data=yaml.safe_load(_CADENCE_YAML), phases=_phases(),
        phase_mapping={"warm_up": ["x"]}, total_instructions=[], current_total=120,
    )
    assert not result.ok
    assert result.failed_phases == ["warm_up"]



# ══════════════════════════════════════════════════════════════════════════
# 3. VALIDATING agent
# ══════════════════════════════════════════════════════════════════════════

async def _never_called(kwargs):
    raise AssertionError("no LLM call should have been made")


@pytest.mark.asyncio
async def test_validator_corrects_a_wrong_phase_duration_in_code():
    before = {p["id"]: p for p in _phases()}
    after = yaml.safe_load(_CADENCE_YAML)
    after["phases"][0]["duration_s"] = 200          # LLM set the wrong number
    after["total_duration_s"] = 290

    report = await ValidatingAgent(make_llm(_never_called)).validate(
        content_clauses=[], before_by_id=before, after_data=after,
        phase_targets={"warm_up": 300},
    )
    by_id = {p["id"]: p["duration_s"] for p in report.data["phases"]}
    assert by_id["warm_up"] == 300, "duration ask is repaired deterministically"
    assert report.data["total_duration_s"] == 300 + 60 + 30
    assert report.satisfied


@pytest.mark.asyncio
async def test_validator_reconciles_total_against_a_phase_pin():
    """"warm-up 5 min" + "whole interview 15 min": the pin holds and the other
    phases absorb the difference, so BOTH asks end up satisfied."""
    before = {p["id"]: p for p in _phases()}
    after = yaml.safe_load(_CADENCE_YAML)
    after["phases"][0]["duration_s"] = 300
    after["total_duration_s"] = 390                  # off the 900 target

    report = await ValidatingAgent(make_llm(_never_called)).validate(
        content_clauses=[], before_by_id=before, after_data=after,
        phase_targets={"warm_up": 300}, total_target=900,
    )
    by_id = {p["id"]: p["duration_s"] for p in report.data["phases"]}
    assert by_id["warm_up"] == 300
    assert report.data["total_duration_s"] == 900
    assert report.satisfied


@pytest.mark.asyncio
async def test_validator_notes_an_unsatisfiable_total_instead_of_guessing():
    before = {p["id"]: p for p in _phases()}
    after = yaml.safe_load(_CADENCE_YAML)
    after["phases"][0]["duration_s"] = 900           # pin alone exceeds the target
    after["total_duration_s"] = 990

    report = await ValidatingAgent(make_llm(_never_called)).validate(
        content_clauses=[], before_by_id=before, after_data=after,
        phase_targets={"warm_up": 900}, total_target=600,
    )
    assert any("kept those" in n["why"] for n in report.notes)


@pytest.mark.asyncio
async def test_validator_reports_a_content_shortfall_for_retry():
    async def responder(kwargs):
        assert _system(kwargs) == VALIDATOR_SYSTEM_PROMPT
        payload = json.loads(_user(kwargs))
        # Every instruction rides in ONE call, tagged with the phase it hit.
        assert payload["instructions"] == [
            {"id": "c1", "phase_id": "resume_deep_dive",
             "instruction": "ask about their projects"},
        ]
        # Duration must not reach the content validator, and it sees the PATCHED
        # phase rather than the cadence.
        assert all("duration_s" not in ph for ph in payload["before"] + payload["after"])
        assert [ph["id"] for ph in payload["after"]] == ["resume_deep_dive"]
        return json.dumps({"verdicts": [
            {"id": "c1", "satisfied": False, "why": "no project question was added"},
        ]})

    before = {p["id"]: p for p in _phases()}
    report = await ValidatingAgent(make_llm(responder)).validate(
        content_clauses=[{"clause_id": "c1", "kind": "phase", "phase_id": "resume_deep_dive",
                          "text": "ask about their projects"}],
        before_by_id=before, after_data=yaml.safe_load(_CADENCE_YAML),
    )
    assert not report.satisfied
    assert report.phase_shortfalls == {"resume_deep_dive": ["ask about their projects"]}
    assert report.notes[0]["why"] == "no project question was added"


@pytest.mark.asyncio
async def test_validator_checks_every_phase_in_a_single_call():
    """Two phases edited in one turn cost ONE validator call, not two."""
    calls = []

    async def responder(kwargs):
        calls.append(json.loads(_user(kwargs)))
        return json.dumps({"verdicts": [
            {"id": "c1", "satisfied": True, "summary": "Warm-up opens more warmly"},
            {"id": "c2", "satisfied": True, "summary": "Wrap-up is shorter"},
        ]})

    before = {p["id"]: p for p in _phases()}
    report = await ValidatingAgent(make_llm(responder)).validate(
        content_clauses=[
            {"clause_id": "c1", "kind": "phase", "phase_id": "warm_up", "text": "be friendlier"},
            {"clause_id": "c2", "kind": "phase", "phase_id": "wrap_up", "text": "be briefer"},
        ],
        before_by_id=before, after_data=yaml.safe_load(_CADENCE_YAML),
    )
    assert len(calls) == 1, f"expected ONE batched call, got {len(calls)}"
    assert {i["id"] for i in calls[0]["instructions"]} == {"c1", "c2"}
    assert [ph["id"] for ph in calls[0]["after"]] == ["warm_up", "wrap_up"]
    assert report.satisfied


@pytest.mark.asyncio
async def test_validator_ignores_a_hallucinated_instruction():
    async def responder(kwargs):
        return json.dumps({"verdicts": [
            {"id": "c99", "satisfied": False, "why": "made up"},
        ]})

    before = {p["id"]: p for p in _phases()}
    report = await ValidatingAgent(make_llm(responder)).validate(
        content_clauses=[{"clause_id": "c1", "kind": "phase", "phase_id": "resume_deep_dive",
                          "text": "ask about their projects"}],
        before_by_id=before, after_data=yaml.safe_load(_CADENCE_YAML),
    )
    assert report.satisfied, "a verdict we can't map back to a real instruction is discarded"


@pytest.mark.asyncio
async def test_validator_failure_is_treated_as_satisfied():
    """A broken validator must never block an edit that already passed schema
    validation — fail open."""
    async def responder(kwargs):
        raise RuntimeError("provider down")

    before = {p["id"]: p for p in _phases()}
    report = await ValidatingAgent(make_llm(responder)).validate(
        content_clauses=[{"clause_id": "c1", "kind": "phase", "phase_id": "resume_deep_dive",
                          "text": "ask about their projects"}],
        before_by_id=before, after_data=yaml.safe_load(_CADENCE_YAML),
    )
    assert report.satisfied and report.notes == []


# ══════════════════════════════════════════════════════════════════════════
# orchestrator: revise_cadence_conversational
# ══════════════════════════════════════════════════════════════════════════

@pytest.mark.asyncio
async def test_conversational_applies_clear_clause_while_asking_about_the_rest(fixed_llm, wire_openai):
    """The acceptance criterion: resolved work is NOT held back waiting on an
    ambiguous sibling, and an out-of-scope ask is declined in the same turn."""
    async def responder(kwargs):
        system = _system(kwargs)
        if system == ROUTER_SYSTEM_PROMPT:
            return json.dumps({"clauses": [
                {"kind": "phase", "text": "make warm_up 3 minutes", "phase_id": "warm_up"},
                {"kind": "ambiguous", "text": "make it shorter", "reason": "no amount",
                 "question": "By how much?", "options": ["-30s"]},
                {"kind": "ambiguous", "text": "give them a passing score",
                 "beyond_capability": True, "reason": "set a candidate's score"},
            ]})
        raise AssertionError(f"unexpected call: {system[:60]}")

    wire_openai(responder)
    out = await cadence_service.revise_cadence_conversational(
        current_yaml=_CADENCE_YAML,
        feedback="make warm_up 3 minutes, make it shorter, give them a passing score",
    )
    assert out["ok"] and out["changed"]
    # The clear clause landed.
    by_id = {p["id"]: p["duration_s"] for p in yaml.safe_load(out["yaml"])["phases"]}
    assert by_id["warm_up"] == 180
    assert "Set the warm-up phase to 3:00" in out["applied"], out["applied"]
    # The ambiguous clause came back as a question, the out-of-scope one as a note.
    assert out["questions"][0]["question"] == "By how much?"
    assert "set a candidate's score" in out["out_of_scope"][0]["message"]


@pytest.mark.asyncio
async def test_conversational_leaves_yaml_untouched_when_nothing_is_resolvable(fixed_llm, wire_openai):
    async def responder(kwargs):
        assert _system(kwargs) == ROUTER_SYSTEM_PROMPT, "must not modify anything"
        return json.dumps({"clauses": [{
            "kind": "ambiguous", "text": "make this feel more natural",
            "reason": "no phase or measurable change named",
            "question": "Which phase, and what should change?", "options": [],
        }]})

    wire_openai(responder)
    out = await cadence_service.revise_cadence_conversational(
        current_yaml=_CADENCE_YAML, feedback="make this feel more natural",
    )
    assert out["changed"] is False
    assert out["yaml"] == _CADENCE_YAML
    assert out["applied"] == [] and len(out["questions"]) == 1


@pytest.mark.asyncio
async def test_conversational_answering_a_question_resolves_it(fixed_llm, wire_openai):
    async def responder(kwargs):
        system = _system(kwargs)
        if system == ROUTER_SYSTEM_PROMPT:
            assert json.loads(_user(kwargs))["clarifications"][0]["answer"] == "warm_up"
            return json.dumps({"clauses": [
                {"kind": "phase", "text": "make it friendlier", "phase_id": "warm_up"},
            ]})
        if system == PHASE_REVISE_SYSTEM_PROMPT:
            phase = _phase_arg(kwargs)
            phase["generic_prompts"] = ["Warmly greet the candidate."]
            return json.dumps(phase)
        if system == VALIDATOR_SYSTEM_PROMPT:
            return json.dumps({"verdicts": []})
        raise AssertionError(system[:60])

    wire_openai(responder)
    out = await cadence_service.revise_cadence_conversational(
        current_yaml=_CADENCE_YAML, feedback="",
        clarifications=[{"clause_id": "c1", "text": "make the HR round friendlier",
                         "question": "Which phase?", "answer": "warm_up"}],
    )
    assert out["questions"] == []
    assert any("warm-up" in a for a in out["applied"]), out["applied"]


@pytest.mark.asyncio
async def test_conversational_retries_a_content_shortfall_then_reports_it(fixed_llm, wire_openai):
    """Validator → Modifying retry is capped at VALIDATE_RETRY_MAX; after that
    the shortfall is surfaced to the admin rather than retried forever."""
    counts = {"phase": 0, "validate": 0}

    async def responder(kwargs):
        system = _system(kwargs)
        if system == ROUTER_SYSTEM_PROMPT:
            return json.dumps({"clauses": [
                {"kind": "phase", "text": "ask about their projects", "phase_id": "resume_deep_dive"},
            ]})
        if system == PHASE_REVISE_SYSTEM_PROMPT:
            counts["phase"] += 1
            return json.dumps(_phase_arg(kwargs))
        if system == VALIDATOR_SYSTEM_PROMPT:
            counts["validate"] += 1
            return json.dumps({"verdicts": [
                {"id": "c1", "satisfied": False, "why": "still missing"},
            ]})
        raise AssertionError(system[:60])

    wire_openai(responder)
    out = await cadence_service.revise_cadence_conversational(
        current_yaml=_CADENCE_YAML, feedback="ask about their projects in the deep dive",
    )
    assert counts["phase"] == 1 + cadence_service.VALIDATE_RETRY_MAX
    assert counts["validate"] == cadence_service.VALIDATE_RETRY_MAX + 1
    assert out["ok"] and any("still missing" in n["why"] for n in out["notes"])


# ── no full-YAML fallback: refuse, or report per-clause ──────────────────────
# There is no FallbackAgent. The raw cadence is never sent to an LLM, so an
# unusable input or a dead router REFUSES the turn (ok=False + why), and a failure
# below that line is per-clause and survivable.


@pytest.mark.asyncio
async def test_conversational_refuses_on_router_failure_without_touching_the_yaml(fixed_llm, wire_openai):
    calls = []

    async def responder(kwargs):
        calls.append(_system(kwargs))
        if _system(kwargs) == ROUTER_SYSTEM_PROMPT:
            raise RuntimeError("provider down")
        raise AssertionError("nothing may run after the router fails")

    wire_openai(responder)
    out = await cadence_service.revise_cadence_conversational(
        current_yaml=_CADENCE_YAML, feedback="restructure this interview",
    )
    assert out["ok"] is False and out["changed"] is False
    assert out["yaml"] == _CADENCE_YAML, "a refused turn must not alter the cadence"
    assert "provider down" in out["error"]
    # complete_json retries once without `response_format` (providers that reject
    # it), so 2 calls is correct — what matters is that BOTH were the router's
    # metadata-only prompt and the cadence went nowhere.
    assert set(calls) == {ROUTER_SYSTEM_PROMPT}


@pytest.mark.asyncio
async def test_conversational_refuses_when_cadence_is_unparseable(fixed_llm, wire_openai):
    async def responder(kwargs):
        raise AssertionError("an unreadable cadence must not reach any LLM")

    wire_openai(responder)
    bad = "not: [a, valid, cadence"
    out = await cadence_service.revise_cadence_conversational(current_yaml=bad, feedback="fix it")
    assert out["ok"] is False and out["yaml"] == bad
    assert "isn't valid YAML" in out["error"]


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "bad_yaml, expect",
    [
        ("total_duration_s: 60\n", "no `phases` list"),           # key missing
        ("total_duration_s: 60\nphases: []\n", "no phases"),      # present but empty
        ("total_duration_s: 60\nphases:\n  - intent: x\n    duration_s: 60\n", "missing an `id`"),
    ],
)
async def test_conversational_refuses_unusable_phase_lists(fixed_llm, wire_openai, bad_yaml, expect):
    async def responder(kwargs):
        raise AssertionError("an unusable cadence must not reach any LLM")

    wire_openai(responder)
    out = await cadence_service.revise_cadence_conversational(current_yaml=bad_yaml, feedback="fix it")
    assert out["ok"] is False
    assert expect in out["error"]


@pytest.mark.asyncio
async def test_conversational_reports_an_invalid_merged_plan_and_keeps_questions(
    fixed_llm, wire_openai, monkeypatch,
):
    """A merged plan the schema rejects is NOT shipped and NOT papered over with a
    whole-plan rewrite: the cadence is left alone, the reason becomes a note, and
    the router's question survives because it's still worth answering.

    Forced via the schema gate rather than contrived phase data: `revise_phase`
    already validates every phase against PhaseDef and retries, so a bad phase is
    caught as a failed phase long before plan-level validation. This branch is the
    defensive net for a plan that's invalid only in combination."""
    from engine.brain.cadence.schema import CadencePlan

    class _RejectingPlan:
        @staticmethod
        def model_validate(_data):
            CadencePlan.model_validate({"total_duration_s": 1, "phases": "not-a-list"})
    monkeypatch.setattr(cadence_service, "CadencePlan", _RejectingPlan)

    async def responder(kwargs):
        system = _system(kwargs)
        if system == ROUTER_SYSTEM_PROMPT:
            return json.dumps({"clauses": [
                {"kind": "phase", "text": "rework warm_up", "phase_id": "warm_up"},
                {"kind": "ambiguous", "text": "tighten it up", "reason": "no amount",
                 "question": "Which phase?", "options": []},
            ]})
        if system == PHASE_REVISE_SYSTEM_PROMPT:
            phase = _phase_arg(kwargs)
            phase["generic_prompts"] = ["Reworked greeting."]
            return json.dumps(phase)
        if system == VALIDATOR_SYSTEM_PROMPT:
            return json.dumps({"verdicts": []})
        raise AssertionError(f"unexpected call: {system[:60]}")

    wire_openai(responder)
    out = await cadence_service.revise_cadence_conversational(
        current_yaml=_CADENCE_YAML, feedback="rework warm_up, tighten it up",
    )
    assert out["ok"] is True, "the turn WAS processed — the edit just didn't survive"
    assert out["changed"] is False and out["yaml"] == _CADENCE_YAML
    assert out["applied"] == []
    assert "invalid plan" in out["notes"][0]["why"]
    assert out["questions"][0]["question"] == "Which phase?"


@pytest.mark.asyncio
async def test_conversational_keeps_the_sibling_edit_when_one_phase_call_fails(fixed_llm, wire_openai):
    """One clause's call dying must not cost the other clause its edit — there's
    no whole-YAML retry to recover it. The validator then repairs the casualty
    itself, because the ask was an exact duration."""
    async def responder(kwargs):
        system = _system(kwargs)
        if system == ROUTER_SYSTEM_PROMPT:
            return json.dumps({"clauses": [
                {"kind": "phase", "text": "make warm_up 3 minutes", "phase_id": "warm_up"},
                {"kind": "phase", "text": "ask about their projects",
                 "phase_id": "resume_deep_dive"},
            ]})
        if system == PHASE_REVISE_SYSTEM_PROMPT:
            phase = _phase_arg(kwargs)
            if phase["id"] == "warm_up":
                raise RuntimeError("provider hiccup on this one call")
            phase["generic_prompts"] = ["Tell me about your projects."]
            return json.dumps(phase)
        if system == VALIDATOR_SYSTEM_PROMPT:
            return json.dumps({"verdicts": []})
        raise AssertionError(f"unexpected call: {system[:60]}")

    wire_openai(responder)
    out = await cadence_service.revise_cadence_conversational(
        current_yaml=_CADENCE_YAML,
        feedback="make warm_up 3 minutes, ask about their projects in the deep dive",
    )
    assert out["ok"] is True and out["changed"] is True
    by_id = {p["id"]: p for p in yaml.safe_load(out["yaml"])["phases"]}
    # The surviving clause landed...
    assert "projects" in by_id["resume_deep_dive"]["generic_prompts"][0]
    # ...and the failed one was repaired deterministically by the validator.
    assert by_id["warm_up"]["duration_s"] == 180


@pytest.mark.asyncio
async def test_conversational_rejects_an_empty_ask():
    with pytest.raises(ValueError):
        await cadence_service.revise_cadence_conversational(current_yaml=_CADENCE_YAML, feedback="   ")


# ══════════════════════════════════════════════════════════════════════════
# Regressions from the live admin session (the four reported defects)
# ══════════════════════════════════════════════════════════════════════════

def test_regression_the_whole_reported_turn():
    """"remove the wrapup phase and make whole interview 15min and warumup 2min30sec"

    Every one of these silently failed at once: the removal fell through to the
    content editor ("wrap_up: questions updated" on a phase to be DELETED), the
    explicit 15 min came back as a question the admin had already answered, and the
    total was just recomputed as the phase sum (4:00 → 6:00)."""
    plan = plan_deterministic(
        [
            {"clause_id": "c1", "text": "remove the wrapup phase", "phase_id": ""},
            {"clause_id": "c2", "text": "make whole interview 15min", "phase_id": ALL_PHASES},
            {"clause_id": "c3", "text": "warumup 2min30sec", "phase_id": ""},
        ],
        _phases(), 120,
    )
    assert [p["id"] for p in plan.phases] == ["warm_up", "resume_deep_dive"]
    assert plan.total_target == 900
    assert plan.phase_targets == {"warm_up": 150}
    assert plan.questions == [], "nothing here needed asking about"
    assert [o.message for o in plan.outcomes] == [
        "Removed the wrap-up phase",
        "Set the whole interview to 15:00",
        "Set the warm-up phase to 2:30",
    ]


def test_regression_no_llm_call_is_needed_for_structure_or_duration():
    """Structure and arithmetic must not consume a model call at all — that is what
    made them unreliable."""
    plan = plan_deterministic(
        [
            {"clause_id": "c1", "text": "remove the wrap up phase", "phase_id": ""},
            {"clause_id": "c2", "text": "make the whole interview 10 minutes", "phase_id": ALL_PHASES},
        ],
        _phases(), 120,
    )
    assert plan.content_clauses == [], "no clause should reach the modifying agent"


def test_regression_untouched_phases_are_never_reported_as_changed():
    """Schema normalisation alone used to make every phase compare unequal, so a
    one-phase edit was reported as four."""
    raw = _phases()[0]                              # straight from YAML
    normalized = dict(raw, question_pool=[], coding_question_ids=[],
                      adaptive_difficulty=False, coding_question_id=None)
    assert phase_content_view(raw) == phase_content_view(normalized)


def test_regression_a_removal_that_did_not_happen_is_reported_as_a_failure():
    """The validator's structure check: if the phase is still there, say so — never
    report a removal that didn't land as applied."""
    after = yaml.safe_load(_CADENCE_YAML)           # wrap_up still present
    prior = [ClauseOutcome("c1", "remove the wrap up phase", "applied",
                           "Removed the wrap-up phase", "wrap_up")]

    async def run():
        return await ValidatingAgent(make_llm(_never_called)).validate(
            content_clauses=[], before_by_id={p["id"]: p for p in _phases()},
            after_data=after, prior_outcomes=prior,
        )

    report = asyncio.get_event_loop_policy().new_event_loop().run_until_complete(run())
    assert report.outcomes[0].status == "failed"
    assert any("still in the plan" in n["why"] for n in report.notes)


def test_regression_a_full_sentence_refusal_reads_correctly():
    """"I can't Creating a brand-new phase is not supported" — the router returns a
    SENTENCE as often as a verb phrase, and the template has to cope with both."""
    verb = capability_message("set a candidate's score")
    sentence = capability_message("Creating a brand-new phase is not supported.")
    assert verb.startswith("I can't set a candidate's score from here.")
    assert sentence.startswith("Creating a brand-new phase is not supported.")
    assert "I can't Creating" not in sentence


def test_regression_coding_phase_add_points_at_the_picker():
    op = plan_structure_op("add a coding phase", _phases(), _catalog(),
                           _res("coding_round"))
    assert op is not None and not op.ok and op.beyond_capability
    assert "picker" in op.question


# ══════════════════════════════════════════════════════════════════════════
# Adding a phase BACK: restore from the catalog, never invent
# ══════════════════════════════════════════════════════════════════════════

def _catalog() -> dict:
    """The known-phase catalog, in running order."""
    return {p["id"]: p for p in _phases()}


# ── what the phase RESOLVER hands the deterministic layer ────────────────
# "Which phase do they mean?" is now an LLM judgement made on phase INTENTS
# (PhaseResolverAgent), so these tests inject its verdict rather than relying on
# word matching. Live accuracy on the real model is covered separately; here we
# pin what the DETERMINISTIC layer does with each possible verdict.

def _res(*phase_ids: str) -> dict:
    """Resolved to one or more existing/known phases, in mention order."""
    return {"phase_ids": list(phase_ids), "new_name": "", "covers": ""}


def _new(name: str, covers: str = "") -> dict:
    """Resolved to no known phase → a NEW one."""
    return {"phase_ids": [], "new_name": name, "covers": covers}


def test_a_removed_phase_can_be_added_back():
    """Remove then re-add in ONE turn — the phase is restored from the catalog."""
    plan = plan_deterministic(
        [
            {"clause_id": "c1", "text": "remove the wrapup phase", "phase_id": ""},
            {"clause_id": "c2", "text": "actually can you add wrapup phase back", "phase_id": ""},
        ],
        _phases(), 120, catalog=_catalog(),
        add_resolutions={"c2": _res("wrap_up")},
    )
    assert [o.status for o in plan.outcomes] == ["applied", "applied"]
    assert [o.message for o in plan.outcomes] == [
        "Removed the wrap-up phase", "Added the wrap-up phase back",
    ]
    assert [p["id"] for p in plan.phases] == ["warm_up", "resume_deep_dive", "wrap_up"]


def test_a_restored_phase_keeps_its_REAL_body():
    """The whole point of the catalog: restoring is not generating. The phase comes
    back with the intent/prompts/duration it actually had."""
    survivors = [p for p in _phases() if p["id"] != "wrap_up"]
    op = plan_structure_op("add the wrap up phase", survivors, _catalog(),
                           _res("wrap_up"))
    assert op is not None and op.ok and op.phase_id == "wrap_up"
    assert op.phase_def["intent"] == "Close the interview gracefully."
    assert op.phase_def["duration_s"] == 30
    assert op.phase_def["generic_prompts"] == ["Say goodbye."]


def test_a_restored_phase_lands_in_its_catalog_position():
    """wrap_up is LAST in the catalog, so it goes back last — not wherever."""
    survivors = [p for p in _phases() if p["id"] != "warm_up"]
    plan = plan_deterministic(
        [{"clause_id": "c1", "text": "add the warm up phase back", "phase_id": ""}],
        survivors, 90, catalog=_catalog(),
        add_resolutions={"c1": _res("warm_up")},
    )
    assert [p["id"] for p in plan.phases] == ["warm_up", "resume_deep_dive", "wrap_up"], \
        "warm_up is first in the catalog, so it returns to the front"


def test_add_back_accepts_any_spelling():
    survivors = [p for p in _phases() if p["id"] != "wrap_up"]
    for spelling in ("add wrapup phase", "add the wrap up phase",
                     "put Wrap-Up back", "bring back wrap_up"):
        op = plan_structure_op(spelling, survivors, _catalog(), _res("wrap_up"))
        assert op is not None and op.ok and op.phase_id == "wrap_up", spelling


def test_a_brand_new_phase_is_now_offered_not_refused():
    """SUPERSEDES "a brand-new phase is refused". A phase the resolver matched to
    nothing is now CREATED — after asking for what cannot be inferred."""
    op = plan_structure_op("add a behavioural phase", _phases(), _catalog(),
                           _new("behavioural"))
    assert op is not None and op.kind == "create"
    assert not op.ok, "nothing is created until duration AND coverage are known"
    assert not op.beyond_capability, "this is a question, not a refusal"
    assert op.phase_id == "behavioural"
    assert "how long" in op.question.lower()


def test_a_coding_phase_add_still_points_at_the_picker():
    """Unchanged by the catalog work: a coding phase needs question ids, so the
    picker owns it even if one sits in the catalog."""
    cat = dict(_catalog(), coding_exercise={"id": "coding_exercise", "duration_s": 600,
                                           "intent": "Write code."})
    op = plan_structure_op("can you add coding phase", _phases(), cat,
                           _res("coding_round"))
    assert op is not None and not op.ok and op.beyond_capability
    assert "picker" in op.question


def test_adding_a_phase_that_is_already_there_says_so():
    op = plan_structure_op("add the warm up phase", _phases(), _catalog(),
                           _res("warm_up"))
    assert op is not None and not op.ok and not op.beyond_capability
    assert "already in this plan" in op.question


def test_an_unresolved_add_asks_and_never_guesses():
    """The resolver returning nothing must produce a QUESTION. Guessing here is
    what answered "did you mean resume-deep-dive?" for "add a system design
    round" — a baffling suggestion built from intent overlap."""
    op = plan_structure_op("add the thing", _phases(), _catalog(), None)
    assert op is not None and not op.ok and not op.beyond_capability
    assert "not sure which phase" in op.question
    assert "resume" not in op.question.split("add these back")[0]


def test_add_with_no_catalog_still_never_applies_silently():
    """The back-compat path (`detect_and_apply_phase_mutations`) passes no catalog.
    With nothing to restore FROM there is no real body, so the op must not come
    back `ok` — its callers treat ok=False as "left for someone else", which is
    what keeps the shim from inventing a phase."""
    op = plan_structure_op("add the wrap up phase", _phases()[:2], None, None)
    assert op is not None and not op.ok
    # And the shim leaves the instruction alone rather than applying anything.
    phases, remaining = detect_and_apply_phase_mutations(
        ["add the wrap up phase"], _phases()[:2],
    )
    assert [p["id"] for p in phases] == ["warm_up", "resume_deep_dive"]
    assert remaining == ["add the wrap up phase"]


def test_a_clause_with_BOTH_a_structure_op_and_a_duration_honours_both():
    """"add the wrap up phase and make it 3 minutes" — consuming the clause on the
    structure op alone silently dropped the number."""
    survivors = [p for p in _phases() if p["id"] != "wrap_up"]
    plan = plan_deterministic(
        [{"clause_id": "c1", "text": "add the wrap up phase and make it 3 minutes",
          "phase_id": ""}],
        survivors, 90, catalog=_catalog(),
        add_resolutions={"c1": _res("wrap_up")},
    )
    by_id = {p["id"]: p["duration_s"] for p in plan.phases}
    assert by_id["wrap_up"] == 180, "the duration in the same clause must apply"
    assert plan.phase_targets == {"wrap_up": 180}, "and be PINNED against a rescale"
    assert plan.outcomes[0].message == "Added the wrap-up phase back, set to 3:00"


def test_a_duration_is_not_stolen_by_an_unrelated_structure_op():
    """"remove the wrap up phase" + a number elsewhere must not pin the removed phase."""
    plan = plan_deterministic(
        [{"clause_id": "c1", "text": "remove the wrap up phase", "phase_id": ""}],
        _phases(), 120, catalog=_catalog(),
    )
    assert plan.phase_targets == {}
    assert "wrap_up" not in {p["id"] for p in plan.phases}


def test_one_clause_asking_for_a_restorable_AND_a_coding_phase_honours_both():
    """"add wrapup phase and coding phase" reliably arrives as ONE clause. Refusing
    the whole thing on the coding half silently lost the wrap-up."""
    survivors = [p for p in _phases() if p["id"] != "wrap_up"]
    plan = plan_deterministic(
        [{"clause_id": "c1", "text": "can you add wrapup phase and coding phase",
          "phase_id": ""}],
        survivors, 90, catalog=_catalog(),
        # The resolver names BOTH — dropping either half is the bug being pinned.
        add_resolutions={"c1": _res("wrap_up", "coding_round")},
    )
    assert "wrap_up" in {p["id"] for p in plan.phases}, "the restorable half must land"
    statuses = [o.status for o in plan.outcomes]
    assert statuses == ["applied", "refused"]
    assert plan.outcomes[0].message == "Added the wrap-up phase back"
    assert "picker" in plan.outcomes[1].message
    assert len(plan.refusals) == 1


def test_a_coding_phase_is_never_restorable_even_if_it_is_in_the_catalog():
    """It needs question ids attached, so the picker owns it either way."""
    cat = dict(_catalog(), coding_exercise={"id": "coding_exercise", "duration_s": 600,
                                           "intent": "Write code.",
                                           "coding_question_ids": ["q1"]})
    op = plan_structure_op("add the coding exercise phase back", _phases(), cat,
                           _res("coding_exercise"))
    assert op is not None and not op.ok and op.beyond_capability
    assert "picker" in op.question


# ══════════════════════════════════════════════════════════════════════════
# Creating a NEW phase (ask for what can't be inferred, then build it)
# ══════════════════════════════════════════════════════════════════════════

def test_a_new_phase_asks_for_duration_before_creating_anything():
    """The duration is the one thing that CANNOT be inferred — it changes the
    interview's length, and the schema requires total == Σ phases exactly."""
    op = plan_structure_op("add a system design round", _phases(), _catalog(),
                           _new("system_design"))
    assert op is not None and op.kind == "create" and not op.ok
    assert op.phase_id == "system_design"
    assert op.phase_def is None, "nothing is built until duration AND coverage exist"
    assert not op.options, \
        "NO duration chips: clicking one answers half the question, and the phase " \
        "would be authored from a bare name"
    assert "how long" in op.question.lower() and "cover" in op.question.lower()


def test_a_new_phase_with_a_duration_is_created_and_handed_to_the_modifier():
    """The skeleton is inserted deterministically; only its CONTENT goes to an LLM."""
    plan = plan_deterministic(
        [{"clause_id": "c1", "text": "add a system design round of 10 minutes",
          "phase_id": ""}],
        _phases(), 120, catalog=_catalog(),
        add_resolutions={"c1": _new("system_design", "scalability trade-offs")},
    )
    assert [o.status for o in plan.outcomes] == ["applied"]
    assert plan.outcomes[0].message == "Added a new system-design phase, set to 10:00"

    new = next(p for p in plan.phases if p["id"] == "system_design")
    assert new["duration_s"] == 600
    assert new["question_mode"] == "generic" and new["generic_prompts"], \
        "the skeleton is schema-valid on its own, so an LLM failure can't break the plan"
    assert plan.phase_targets["system_design"] == 600, "explicit duration is PINNED"

    # The content ask — and ONLY the content ask — reaches the modifying agent.
    assert len(plan.content_clauses) == 1
    clause = plan.content_clauses[0]
    assert clause["phase_id"] == "system_design"
    assert "intent" in clause["text"] and "generic_prompts" in clause["text"]
    # The brief is what the admin said the phase should COVER, not the raw ask —
    # "add a ... round of 10 minutes" is scaffolding, "scalability trade-offs" is
    # the thing the content has to deliver.
    assert "scalability trade-offs" in clause["text"], "carries the coverage brief"


def test_a_new_phase_never_lands_after_the_wrap_up():
    """A new round belongs in the body of the interview, never after the goodbye."""
    plan = plan_deterministic(
        [{"clause_id": "c1", "text": "add an hr round 5 min", "phase_id": ""}],
        _phases(), 120, catalog=_catalog(),
        add_resolutions={"c1": _new("hr", "notice period and expectations")},
    )
    ids = [p["id"] for p in plan.phases]
    assert ids[-1] == "wrap_up", f"wrap_up must stay last, got {ids}"
    assert "hr" in ids


def test_a_new_phase_id_comes_from_the_admins_words():
    existing = {"warm_up"}
    assert derive_phase_id("add a system design round", existing) == "system_design"
    assert derive_phase_id("please add an HR round for 5 minutes", existing) == "hr"
    # Collisions get a suffix rather than silently overwriting a real phase.
    assert derive_phase_id("add a warm up phase", existing) == "warm_up_2"
    # Nothing name-like → no id, so the caller asks instead of creating junk.
    assert derive_phase_id("add a phase", existing) is None


def test_a_typo_on_a_real_phase_name_still_confirms_instead_of_creating():
    """"add the warumup back" is a typo on warm_up, not a request for a new phase."""
    survivors = [p for p in _phases() if p["id"] != "warm_up"]
    op = plan_structure_op("add the warumup phase back", survivors, _catalog(),
                           _res("warm_up"))
    assert op is not None and op.ok and op.phase_id == "warm_up", \
        "a close NAME match restores; it must not create a `warumup` phase"


def test_a_vague_intent_match_creates_rather_than_guessing_a_wrong_phase():
    """REGRESSION: "add a system design round" used to answer "did you mean to add
    the resume-deep-dive phase back?" — intent overlap scored above the old gate,
    producing a baffling guess. Only a close NAME match may be confirmed."""
    op = plan_structure_op("add a system design round", _phases(), _catalog(),
                           _new("system_design"))
    assert op is not None and op.kind == "create"
    assert "resume" not in op.question, f"no bogus guess, got: {op.question}"


# ══════════════════════════════════════════════════════════════════════════
# Coding phase vs coding DISCUSSION (blacklist is data, not a regex)
# ══════════════════════════════════════════════════════════════════════════

def _phases_with_coding() -> list[dict]:
    """A plan whose coding phase is a real EXERCISE (has coding_question_ids)."""
    out = _phases()
    out.insert(-1, {"id": "coding_round", "duration_s": 600,
                    "intent": "Live coding.", "question_mode": "generic",
                    "generic_prompts": ["Code."], "coding_question_ids": ["q1"]})
    return out


def _real_catalog(phases: list[dict]) -> dict:
    """The catalog PRODUCTION builds, not a hand-rolled one.

    Load-bearing for the code-discussion tests: `phase_tools` deliberately owns no
    copy of that phase's body — it comes from `cadence_service`, so a fixture that
    fakes the catalog would test the wrong wiring and hide a real break."""
    from app.cadence_service import _phase_catalog
    return _phase_catalog(None, phases)


def test_the_blacklist_ships_as_data_with_no_keyword_lists():
    """It carries an `intent` for the RESOLVER to match on, and a `reason` for the
    admin. Deliberately NO aliases: word lists could not separate a coding round
    from a coding discussion, and every new entry would need its own spellings."""
    entries = load_phase_blacklist()
    assert entries, "config/phase_blacklist.json must ship and parse"
    coding = next((e for e in entries if e["id"] == "coding_round"), None)
    assert coding is not None
    assert coding["intent"], "the resolver matches on this"
    assert "picker" in coding["reason"], "and the admin is pointed somewhere useful"
    for e in entries:
        assert "aliases" not in e, "no keyword matching anywhere"


def test_blacklist_entry_is_looked_up_by_the_resolved_id():
    assert blacklist_entry("coding_round") is not None
    assert blacklist_entry("code_discussion") is None, \
        "the discussion phase is addable — it needs nothing from the picker"
    assert blacklist_entry("warm_up") is None


def test_a_coding_phase_ask_points_at_the_picker():
    op = plan_structure_op("add a coding phase", _phases(), _catalog(),
                           _res("coding_round"))
    assert op is not None and not op.ok and op.beyond_capability
    assert "picker" in op.question


def test_a_coding_discussion_with_a_coding_round_is_added_straight_away():
    phases = _phases_with_coding()
    plan = plan_deterministic(
        [{"clause_id": "c1", "text": "add a coding discussion", "phase_id": ""}],
        phases, sum(p["duration_s"] for p in phases),
        catalog=_real_catalog(phases),
        add_resolutions={"c1": _res(CODE_DISCUSSION_ID)},
    )
    assert [o.status for o in plan.outcomes] == ["applied"]
    ids = [p["id"] for p in plan.phases]
    assert ids.index("coding_round") < ids.index(CODE_DISCUSSION_ID), \
        f"a review must follow the thing it reviews, got {ids}"
    assert not plan.content_clauses, \
        "the definition already exists — nothing is generated for it"


def test_a_coding_discussion_with_NO_coding_round_asks_first():
    op = plan_structure_op("add a coding discussion", _phases(),
                           _real_catalog(_phases()), _res(CODE_DISCUSSION_ID))
    assert op is not None and not op.ok and not op.beyond_capability
    assert "no coding phase" in op.question
    assert len(op.options) == 2, "yes / use-the-picker"


def test_confirming_the_orphan_discussion_adds_the_existing_definition():
    plan = plan_deterministic(
        [{"clause_id": "c1", "phase_id": "",
          "text": "add a code discussion — yes, add the code discussion"}],
        _phases(), 120, catalog=_real_catalog(_phases()),
        add_resolutions={"c1": _res(CODE_DISCUSSION_ID)},
    )
    assert [o.status for o in plan.outcomes] == ["applied"]
    added = next(p for p in plan.phases if p["id"] == CODE_DISCUSSION_ID)
    assert "complexity" in added["intent"], "the REAL body, not a generated one"
    assert not plan.content_clauses


def test_declining_the_orphan_discussion_ENDS_the_exchange():
    """REGRESSION: a "no" answer re-asked the same question forever, because only
    an affirmative was detected and anything else fell through to the ask."""
    op = plan_structure_op(
        "add a code discussion — no, I'll add a coding phase from the picker",
        _phases(), _real_catalog(_phases()), _res(CODE_DISCUSSION_ID),
    )
    assert op is not None and not op.ok
    assert op.beyond_capability, "terminal, so the chat does not loop"
    assert "no coding phase in this plan" not in op.question, "must not re-ask"
    assert not op.options


def test_a_decline_beats_an_affirmative_in_the_same_replayed_text():
    """The clarification replays the ASK next to the ANSWER, so both sets of words
    are present — the negative has to win or a "no" creates the phase."""
    assert reads_as_confirmation("yes, add the code discussion")
    assert not reads_as_confirmation(
        "add a code discussion — no, I'll add a coding phase from the picker")


def test_has_coding_round_ignores_the_discussion_phase():
    """`code_discussion` is a conversation. Only coding_question_ids makes a phase
    a real exercise — an id containing "cod" is not enough."""
    assert has_coding_round(_phases_with_coding())
    assert not has_coding_round(_phases())
    assert not has_coding_round([
        {"id": "code_discussion", "duration_s": 120, "intent": "Review."}])


def test_a_clause_naming_a_new_phase_AND_a_blocked_one_answers_both():
    """The list contract exists for this: one clause can name several phases, and
    answering only the first would silently drop the rest of the request."""
    survivors = [p for p in _phases() if p["id"] != "wrap_up"]
    op = plan_structure_op(
        "add the wrap up phase and a coding phase", survivors, _catalog(),
        _res("wrap_up", "coding_round"),
    )
    assert op is not None and op.ok and op.phase_id == "wrap_up"
    assert "picker" in op.extra_refusal, "the blocked half still gets its answer"


def test_a_coding_phase_from_the_CATALOG_is_refused_not_created():
    """It's excluded from `restorable` (no question ids), but it must not then fall
    through to the create path and produce a coding phase that never opens an
    editor."""
    cat = dict(_catalog(), coding_exercise={
        "id": "coding_exercise", "duration_s": 600, "intent": "Write code.",
        "coding_question_ids": ["q1"]})
    op = plan_structure_op("add the coding exercise back", _phases(), cat,
                           _res("coding_exercise"))
    assert op is not None and not op.ok and op.beyond_capability
    assert "picker" in op.question
    assert op.kind != "create", "must never be created"


def test_the_resolver_drops_a_hallucinated_id_rather_than_acting_on_it():
    """Guard at the agent boundary: an id we never offered can't reach the planner,
    because it would name a phase nobody holds a definition for."""
    from app.cadence_agents import PhaseResolverAgent

    def _agent(reply: str) -> PhaseResolverAgent:
        async def responder(kwargs):
            return reply
        return PhaseResolverAgent(make_llm(responder))

    async def run(reply: str):
        return await _agent(reply).resolve(
            asks=[{"clause_id": "c1", "text": "add a made up phase"}],
            in_plan=_phases(), available=[], blocked=[],
        )

    loop = asyncio.get_event_loop_policy().new_event_loop()
    # A real id survives...
    ok = loop.run_until_complete(run(
        '{"resolutions":[{"id":"c1","phase_ids":["warm_up"],"covers":""}]}'))
    assert ok["c1"]["phase_ids"] == ["warm_up"]
    # ...an invented one takes the whole ask out, so the admin is asked instead.
    bad = loop.run_until_complete(run(
        '{"resolutions":[{"id":"c1","phase_ids":["totally_invented"],"covers":""}]}'))
    assert "c1" not in bad
    # A malformed body is the same story: no resolution, never a guess.
    junk = loop.run_until_complete(run('{"nope": []}'))
    assert junk == {}


def test_the_resolver_fails_CLOSED_when_the_call_breaks():
    """No resolution → the admin is asked. Never a guess: a wrong silent add is the
    failure this layer exists to prevent."""
    from app.cadence_agents import PhaseResolverAgent

    async def boom(_kwargs):
        raise RuntimeError("provider down")

    loop = asyncio.get_event_loop_policy().new_event_loop()
    out = loop.run_until_complete(
        PhaseResolverAgent(make_llm(boom)).resolve(
            asks=[{"clause_id": "c1", "text": "add a coding phase"}],
            in_plan=_phases(), available=[], blocked=[]))
    assert out == {}
    op = plan_structure_op("add a coding phase", _phases(), _catalog(), None)
    assert op is not None and not op.ok and "not sure which phase" in op.question


# ══════════════════════════════════════════════════════════════════════════
# Duration scope: a relative ask is measured against WHAT IT TARGETS
# ══════════════════════════════════════════════════════════════════════════

def _timed(**durs) -> list[dict]:
    return [{"id": k, "duration_s": v, "intent": f"{k} phase.",
             "question_mode": "generic", "generic_prompts": ["x"]}
            for k, v in durs.items()]


def _dur_after(text: str, phases: list[dict], scope: str = "") -> dict:
    plan = plan_deterministic(
        [{"clause_id": "c1", "text": text, "phase_id": scope}],
        phases, sum(p["duration_s"] for p in phases),
    )
    return {p["id"]: p["duration_s"] for p in plan.phases}


def test_regression_a_relative_phase_ask_uses_THAT_PHASE_as_the_base():
    """THE reported bug. `resolve_total_target(text, current_total)` was computed
    once, against the INTERVIEW's total, and the result then assigned to a PHASE —
    so on a 7:30 interview "reduce the warm-up by 30 seconds" set the warm-up to
    7:00 and made the interview LONGER. Real numbers from the report."""
    phases = _timed(warm_up=240, resume_deep_dive=60, technical_questions=90, wrap_up=60)
    assert sum(p["duration_s"] for p in phases) == 450          # 7:30, as reported
    after = _dur_after("reduce the warm up by 30 seconds", phases)
    assert after["warm_up"] == 210, "240 − 30, not 450 − 30 (=420, the bug)"
    # Every other phase is untouched.
    assert after["resume_deep_dive"] == 60 and after["wrap_up"] == 60


def test_regression_reduce_TO_a_value_is_absolute_not_a_delta():
    """"reduce ... TO 30 seconds" is a TARGET; "reduce ... BY 30 seconds" is a
    delta. The preposition decides, not the verb — reading the verb alone made the
    whole clause relative, which is how 30 seconds became 7:00."""
    assert parse_absolute_duration_target(["reduce the warm up to 30 seconds"]) == 30
    assert parse_absolute_duration_target(["increase warm up to 5 minutes"]) == 300
    assert parse_absolute_duration_target(["cut it down to 2 minutes"]) == 120
    # BY stays relative...
    assert parse_absolute_duration_target(["reduce the warm up by 30 seconds"]) is None
    assert parse_relative_duration_delta(["reduce the warm up by 30 seconds"]) == -30
    # ...and "to" pointing at a PHASE rather than a number is still relative.
    assert parse_absolute_duration_target(["add 30 seconds to the warm up"]) is None
    assert parse_relative_duration_delta(["add 30 seconds to the warm up"]) == 30


def test_regression_the_reported_transcript_now_yields_the_right_numbers():
    """The three lines from the live session, each with its real starting plan."""
    # "reduce the time of phase by 30 seconds" → warm_up (clicked), 1:00 → 0:30
    after = _dur_after("reduce the time of phase by 30 seconds",
                       _timed(warm_up=60, resume_deep_dive=60,
                              technical_questions=90, wrap_up=60), scope="warm_up")
    assert after["warm_up"] == 30, "was 270 − 30 = 240 → 'Set the warm-up phase to 4:00'"

    # "reduce the time of warm up to 30 seconds" on a 7:30 interview
    after = _dur_after("I want you to reduce the time of warm up to 30 seconds",
                       _timed(warm_up=240, resume_deep_dive=60,
                              technical_questions=90, wrap_up=60))
    assert after["warm_up"] == 30, "was 450 − 30 = 420 → 'Set the warm-up phase to 7:00'"

    # "reduce the time of warmup to 30 seconds only" on a 10:00 interview
    after = _dur_after("I want you to reduce the time of warmup to 30 seconds only",
                       _timed(warm_up=420, resume_deep_dive=30,
                              technical_questions=90, wrap_up=60))
    assert after["warm_up"] == 30, "was 600 − 30 = 570 → 'Set the warm-up phase to 9:30'"


def test_a_whole_interview_relative_ask_still_uses_the_TOTAL():
    """The other half of the same rule: an ALL-scoped delta is measured against the
    interview, which is what it always should have been."""
    plan = plan_deterministic(
        [{"clause_id": "c1", "text": "add 2 minutes to the whole interview",
          "phase_id": ALL_PHASES}],
        _timed(warm_up=240), 240,
    )
    assert plan.total_target == 360
    assert plan.outcomes[0].message == "Set the whole interview to 6:00"


def test_a_reduction_past_zero_asks_instead_of_writing_a_bad_number():
    phases = _timed(warm_up=20, resume_deep_dive=60, technical_questions=90, wrap_up=60)
    plan = plan_deterministic(
        [{"clause_id": "c1", "text": "reduce the warm up by 30 seconds", "phase_id": ""}],
        phases, sum(p["duration_s"] for p in phases),
    )
    assert plan.outcomes[0].status == "asked"
    assert "at or below zero" in plan.outcomes[0].message
    assert {p["id"]: p["duration_s"] for p in plan.phases}["warm_up"] == 20, "unchanged"


def test_regression_adding_TIME_is_not_a_structure_add():
    """Pre-existing on HEAD and absurd there: "add" made the STRUCTURE step claim
    the clause before the duration step ran, so "add 2 minutes to the warm up"
    answered "the warm-up phase is already in this plan", and the whole-interview
    version answered "I can't create a brand-new phase"."""
    for t in ("add 2 minutes to the warm up", "add 30 seconds",
              "reduce warm up by 30 seconds", "trim 30 seconds off the wrap up"):
        assert detect_structure_verb(t) is None, t
    # ...while adding a PHASE is still a structure op.
    for t in ("add a coding phase", "add wrapup phase", "add a system design round",
              "add the wrap up phase and make it 3 minutes", "put the wrap-up back"):
        assert detect_structure_verb(t) == "add", t
    # And it now actually applies.
    after = _dur_after("add 2 minutes to the warm up",
                       _timed(warm_up=240, wrap_up=60))
    assert after["warm_up"] == 360


def test_a_number_that_is_not_a_duration_is_not_a_time_change():
    """"add 2 questions about caching" counts questions, not seconds."""
    assert not is_time_change_ask("add 2 questions about caching")
    assert detect_structure_verb("add 2 questions about caching") == "add"


def test_an_add_whose_object_is_CONTENT_goes_to_the_modifier():
    """"add two questions about caching to the technical round" resolves to a phase
    that is already present. Answering "that phase is already in this plan" is a
    dead end for a doable ask, so it becomes a content edit instead."""
    phases = _timed(warm_up=150, technical_questions=600, wrap_up=150)
    cat = {p["id"]: p for p in phases}
    plan = plan_deterministic(
        [{"clause_id": "c1", "phase_id": "",
          "text": "add 2 questions about caching to the technical round"}],
        phases, 900, catalog=cat,
        add_resolutions={"c1": {"phase_ids": ["technical_questions"],
                                "new_name": "", "covers": "caching"}},
    )
    assert [c["phase_id"] for c in plan.content_clauses] == ["technical_questions"]
    assert not plan.questions

    # With nothing to add (pure membership), it still says the phase is present.
    plan2 = plan_deterministic(
        [{"clause_id": "c1", "text": "add the wrap up phase", "phase_id": ""}],
        phases, 900, catalog=cat,
        add_resolutions={"c1": {"phase_ids": ["wrap_up"], "new_name": "", "covers": ""}},
    )
    assert plan2.questions and "already in this plan" in plan2.questions[0]["question"]


def test_regression_a_clarification_keeps_the_ORIGINAL_verb_in_its_text():
    """The two-turn create flow: "add a system design round" → we ask for duration
    and coverage → the admin answers in a SEPARATE message.

    The answer alone ("10 minutes, covering caching") has lost the word "add", and
    every downstream decision keys off that verb: `detect_structure_verb` decides
    it's a structure ask, `_resolve_add_asks` only calls the RESOLVER for clauses
    whose verb is "add". With the answer alone, turn 2 was read as an ambiguous
    DURATION on an existing phase and the new phase was never created — the whole
    feature was unreachable unless the admin said everything in one message.

    Router prompt rule 6 requires the clause text to be "<original> — <answer>".
    This test pins the CONSEQUENCE (which is what actually breaks), so it fails if
    that rule is ever dropped from the prompt."""
    answer_only = "10 minutes, focus on scalability trade-offs and caching"
    combined = f"add a system design round — {answer_only}"

    # The bug: with the answer alone there is no "add", so no resolver, no create.
    assert detect_structure_verb(answer_only) is None
    # The fix: the original verb survives, so the clause still routes as an add.
    assert detect_structure_verb(combined) == "add"

    # ...and it is NOT mistaken for a time-change ask (which would skip the
    # resolver and try to re-time an existing phase instead of creating one).
    assert not is_time_change_ask(combined), \
        '"add a system design round — 10 minutes" adds a PHASE, not time'

    # End to end: the combined text creates the phase with BOTH answers honoured.
    phases = _timed(warm_up=150, resume_deep_dive=390, technical_questions=360)
    plan = plan_deterministic(
        [{"clause_id": "c1", "text": combined, "phase_id": ""}],
        phases, 900, catalog={p["id"]: p for p in phases},
        add_resolutions={"c1": _new("system_design",
                                    "scalability trade-offs and caching")},
    )
    created = {p["id"]: p["duration_s"] for p in plan.phases}
    assert created.get("system_design") == 600, "the 10 minutes must land"
    assert plan.phase_targets["system_design"] == 600, "and be PINNED"
    assert [c["phase_id"] for c in plan.content_clauses] == ["system_design"], \
        "the coverage brief must reach the modifying agent"
    assert not plan.questions, "nothing left to ask — both answers were given"
