"""Export-contract tests for the Ground-truth & Coding plugin family.

Drives ONE synthetic session that exercises all four plugins (transcription,
translation, image_description, coding), then checks the section each one emits
against its own declared schema.

Runs under pytest OR directly (`python tests/test_eval_export.py`).
"""
from __future__ import annotations

import asyncio
import json

import features.eval.plugins as P
from features.eval.plugins.base import EvalContext
from features.eval.plugins.builtins import coding as coding_mod
from features.eval.plugins.export import GroundTruthExport
from features.eval.sectioner import build_segments

# ── the session under test ───────────────────────────────────────────────────
# One phase per ground-truth question type plus a coding phase, with the cadence
# that carries each question's ground_truth.

REFERENCE = "the quick brown fox jumps over the lazy dog"

CADENCE = {"phases": [
    {"id": "transcribe", "question_pool": [
        {"id": "t1", "written_response": {"ground_truth": REFERENCE}},
    ]},
    {"id": "translate", "question_pool": [
        {"id": "x1", "written_response": {"ground_truth": ["el perro esta durmiendo",
                                                            "el perro duerme"]}},
    ]},
    {"id": "describe", "question_pool": [
        {"id": "i1", "written_response": {"ground_truth": ["a red bicycle", "a wet street",
                                                            "two pedestrians"]}},
    ]},
    {"id": "coding", "coding_question_ids": ["running_sum"]},
]}


def _events() -> list[dict]:
    def q(phase, qid, text, answer):
        return [
            {"kind": "question_dispatched", "ts": "t",
             "payload": {"phase_id": phase, "question_id": qid, "question_text": text}},
            {"kind": "ai_utterance", "ts": "t", "payload": {"text": text}},
            {"kind": "stt_final", "ts": "t", "payload": {"text": answer}},
        ]

    ev: list[dict] = [{"kind": "session_started", "ts": "t", "payload": {"initial_phase": "transcribe"}}]
    ev += q("transcribe", "t1", "Type what you heard.", "a fast brown fox leaps over the lazy dog")
    ev += [{"kind": "phase_changed", "ts": "t", "payload": {"from_phase": "transcribe", "to_phase": "translate"}}]
    ev += q("translate", "x1", "Translate the sentence.", "el perro esta dormido")
    ev += [{"kind": "phase_changed", "ts": "t", "payload": {"from_phase": "translate", "to_phase": "describe"}}]
    ev += q("describe", "i1", "Describe the image.", "A red bike leaning on a wet street.")
    ev += [
        {"kind": "phase_changed", "ts": "t", "payload": {"from_phase": "describe", "to_phase": "coding"}},
        {"kind": "coding_phase_started", "ts": "t", "payload": {
            "phase_id": "coding",
            "questions": [{"question_id": "running_sum", "question_prompt": "Return the running sum."}]}},
        {"kind": "coding_code_submitted", "ts": "t", "payload": {
            "phase_id": "coding", "question_id": "running_sum",
            "final_code": "def running_sum(nums):\n    return nums",
            "final_test_results": [
                {"name": "case 1", "input": "[1,2]", "expected": "[1,3]", "actual": "[1,3]",
                 "passed": True, "error": "", "stdout": "", "stderr": ""},
                {"name": "case 2", "input": "[]", "expected": "[]", "actual": "",
                 "passed": False, "error": "TypeError: bad", "stdout": "noise", "stderr": ""},
            ],
            "runs_used": 3, "auto_submitted": False}},
    ]
    ev.append({"kind": "session_ended", "ts": "t", "payload": {}})
    return ev


# The LLM verdicts the three ground-truth plugins would get for the answers
# above. Keyed by the marker each plugin's prompt contains, so one stub serves
# all three and each plugin still exercises its real parsing + scoring code.
_LLM_REPLIES = {
    "TRANSCRIPTION": json.dumps({"reference_word_count": 9, "diffs": [
        {"type": "substitution", "reference": "the", "candidate": "a"},
        {"type": "substitution", "reference": "quick", "candidate": "fast"},
        {"type": "substitution", "reference": "jumps", "candidate": "leaps"}]}),
    "TRANSLATION": json.dumps({"best_matching_reference_index": 0,
                               "meaning_preserved": True, "match_quality": "close"}),
    "IMAGE DESCRIPTION": json.dumps({"element_coverage": [
        {"element": "a red bicycle", "covered": True},
        {"element": "a wet street", "covered": True},
        {"element": "two pedestrians", "covered": False}]}),
}


def _ctx() -> EvalContext:
    async def scoring_llm(model: str, prompt: str) -> str:
        for marker, reply in _LLM_REPLIES.items():
            if marker in prompt:
                return reply
        raise AssertionError(f"unexpected scoring prompt: {prompt[:200]!r}")

    return EvalContext(cadence=CADENCE, score_llm_raw=scoring_llm)


def _segments() -> dict[str, object]:
    """phase_id -> the segment to grade, for the four phases under test."""
    iv = build_segments(_events(), cadence=CADENCE)
    out = {}
    for _phase, seg in iv.iter_segments():
        if seg.kind in ("question", "coding"):
            out[seg.phase_id] = seg
    return out


_PLUGIN_FOR_PHASE = {
    "transcribe": "transcription_scoring",
    "translate": "translation_scoring",
    "describe": "image_description_scoring",
    "coding": "coding",
}


def _run_family() -> dict[str, tuple]:
    """plugin_id -> (segment, evaluation, export section) for all four."""
    segs, ctx, out = _segments(), _ctx(), {}
    for phase_id, plugin_id in _PLUGIN_FOR_PHASE.items():
        seg = segs[phase_id]
        plug = P.get_plugin(plugin_id)()
        ev = asyncio.run(plug.run(seg, {}, ctx=ctx))
        out[plugin_id] = (seg, ev, plug.export_section(seg, ev))
    return out


# ── schema validation ────────────────────────────────────────────────────────


def _validate_against_schema(payload: dict, schema: dict, *, model) -> None:
    """Check `payload` against the section's DECLARED schema.

    Uses `jsonschema` when it is installed; otherwise falls back to the
    structural checks the declared schema expresses plus a strict re-parse
    through the model. The models set `extra="forbid"`, so the schema says
    `additionalProperties: false` and the two paths enforce the same thing."""
    try:
        import jsonschema  # noqa: PLC0415 — optional; the fallback below is equivalent
    except Exception:
        props, required = schema.get("properties", {}), set(schema.get("required", []))
        missing = required - set(payload)
        assert not missing, f"payload missing required keys {sorted(missing)}"
        undeclared = set(payload) - set(props)
        assert not undeclared, f"payload has keys absent from its schema: {sorted(undeclared)}"
        assert schema.get("additionalProperties") is False, "section schema must be closed"
    else:
        jsonschema.validate(payload, schema)
    # Round-trips through its own model — catches a payload that is structurally
    # fine but violates a model-level rule (e.g. marks on a non-scored state).
    model.model_validate(payload)


def test_every_emitted_section_validates_against_its_declared_schema():
    schemas = P.export_schemas()
    for plugin_id, (_seg, ev, section) in _run_family().items():
        assert ev.state == "scored", f"{plugin_id} did not score: {ev.rationale}"
        assert section is not None, f"{plugin_id} emitted no export section"
        descriptor = P.get_plugin(plugin_id).export_descriptor()
        payload = json.loads(section.model_dump_json())   # the JSON as it ships
        _validate_against_schema(payload, descriptor.json_schema(), model=descriptor.model)
        assert payload["section"] == descriptor.key
        assert schemas[descriptor.key]["plugin_id"] == plugin_id


def test_export_descriptor_declared_for_the_whole_family():
    # AC: descriptor + fill method on all four of THIS family. Asserted as a
    # subset, not equality: the Rubric & Coverage family (AB#34149) declares its
    # own four sections on the same contract, so an equality check here would
    # fail whenever the other story lands — which is not this family's concern.
    # `test_eval_export_document.py` asserts the whole-registry property.
    assert {
        "coding", "transcription_scoring", "translation_scoring", "image_description_scoring",
    } <= set(P.export_schemas())
    for plugin_id in _PLUGIN_FOR_PHASE.values():
        cls = P.get_plugin(plugin_id)
        assert cls.export_descriptor() is not None
        assert cls.export_section is not P.EvalPlugin.export_section, \
            f"{plugin_id} inherits the no-op fill method"


def test_contract_holds_for_both_methods():
    # The same envelope spans the python member (coding) and the llm_judge ones.
    fam = _run_family()
    assert fam["coding"][2].method == "python"
    for plugin_id in ("transcription_scoring", "translation_scoring", "image_description_scoring"):
        assert fam[plugin_id][2].method == "llm_judge"
    envelope_keys = set(P.ExportSectionModel.model_fields)
    for _seg, _ev, section in fam.values():
        assert envelope_keys <= set(section.model_dump()), "a section dropped an envelope field"


def test_coding_section_carries_per_test_results_and_judge_verdict():
    _seg, _ev, section = _run_family()["coding"]
    assert [t.passed for t in section.tests] == [True, False]
    assert section.tests_passed == 1 and section.tests_total == 2
    assert section.pass_rate == 0.5
    failed = section.tests[1]
    assert failed.name == "case 2" and failed.error == "TypeError: bad"
    assert section.runs_used == 3
    # No judge here: this run had no LLM, and that is reported as absence, not 0.
    assert section.judge is None


def test_coding_section_reports_the_judge_when_it_ran():
    """The judge verdict rides in its own field, separate from the test facts."""
    from features.coding.evaluator import CodingScore

    def fake_evaluate(**kw):
        return CodingScore(question_id=kw["question_id"], pass_rate=0.5, correctness=8.0,
                           readability=7.0, idiomatic=6.0, edge_cases=5.0,
                           runs_used=kw.get("runs_used", 0), rationale="solid but misses empty input")

    real = coding_mod.evaluate_submission
    coding_mod.evaluate_submission = fake_evaluate
    try:
        seg = _segments()["coding"]
        plug = P.get_plugin("coding")()

        async def any_llm(system, user):
            return "{}"

        ev = asyncio.run(plug.run(seg, {}, ctx=EvalContext(cadence=CADENCE, llm_complete=any_llm)))
        section = plug.export_section(seg, ev)
    finally:
        coding_mod.evaluate_submission = real

    assert section.judge is not None
    assert section.judge.dimensions == {"correctness": 8.0, "readability": 7.0,
                                        "idiomatic": 6.0, "edge_cases": 5.0}
    assert section.judge.composite_0_10 == 6.5
    assert section.judge.rationale == "solid but misses empty input"
    # The deterministic test facts are untouched by the judge running.
    assert section.tests_passed == 1 and section.tests_total == 2


def test_ground_truth_trio_shares_one_shape():
    fam = _run_family()
    trio = ["transcription_scoring", "translation_scoring", "image_description_scoring"]

    # Literally the same model, not three lookalikes.
    for plugin_id in trio:
        assert P.get_plugin(plugin_id).export_descriptor().model is GroundTruthExport
        assert isinstance(fam[plugin_id][2], GroundTruthExport)

    shapes = {plugin_id: set(fam[plugin_id][2].model_dump()["comparison"]) for plugin_id in trio}
    assert len(set(map(frozenset, shapes.values()))) == 1, f"comparison shapes diverged: {shapes}"

    kinds = {plugin_id: fam[plugin_id][2].comparison.expected_kind for plugin_id in trio}
    assert kinds == {
        "transcription_scoring": "reference_transcript",
        "translation_scoring": "accepted_translations",
        "image_description_scoring": "key_elements",
    }


def test_ground_truth_expected_vs_actual_content():
    fam = _run_family()

    tr = fam["transcription_scoring"][2].comparison
    assert tr.expected == [REFERENCE]
    assert tr.total_count == 9 and tr.matched_count == 6      # 3 word-level diffs
    assert [(i.expected, i.actual) for i in tr.items] == [("the", "a"), ("quick", "fast"), ("jumps", "leaps")]
    assert all(i.matched is False for i in tr.items)          # items exist only where they differ

    tx = fam["translation_scoring"][2].comparison
    assert tx.expected == ["el perro esta durmiendo", "el perro duerme"]
    assert tx.actual == "el perro esta dormido"
    assert [i.matched for i in tx.items] == [True, False]     # the judge picked reference 0
    assert tx.items[0].note == "close"
    assert (tx.matched_count, tx.total_count) == (1, 1)       # alternatives, so one thing to get right

    im = fam["image_description_scoring"][2].comparison
    assert im.expected == ["a red bicycle", "a wet street", "two pedestrians"]
    assert [i.matched for i in im.items] == [True, True, False]
    assert (im.matched_count, im.total_count) == (2, 3)
    # matched_count always agrees with the items for a per-item checklist
    assert im.matched_count == sum(1 for i in im.items if i.matched)


# ── non-scored states (never a 0) ────────────────────────────────────────────


def test_transcription_survives_non_string_diff_fields_from_the_llm():
    """A diff whose reference/candidate is a bare number must not blow up the
    fill method — `export_section` runs OUTSIDE run()'s error handling, so a
    pydantic failure here would propagate to whoever assembles the export."""
    seg = _segments()["transcribe"]
    plug = P.get_plugin("transcription_scoring")()

    async def numeric_llm(model, prompt):
        return json.dumps({"reference_word_count": 9, "diffs": [
            {"type": "substitution", "reference": 1000, "candidate": 1_000_000},
            {"type": "deletion", "reference": "lazy", "candidate": None}]})

    ev = asyncio.run(plug.run(seg, {}, ctx=EvalContext(cadence=CADENCE, score_llm_raw=numeric_llm)))
    assert ev.state == "scored"

    section = plug.export_section(seg, ev)
    assert [(i.expected, i.actual) for i in section.comparison.items] == [
        ("1000", "1000000"), ("lazy", None),
    ]
    descriptor = plug.export_descriptor()
    _validate_against_schema(json.loads(section.model_dump_json()),
                             descriptor.json_schema(), model=descriptor.model)


def test_non_scored_section_carries_a_reason_and_no_marks():
    # No ground_truth in the cadence -> assumptions_unmet, for every plugin that
    # needs one. The section must say so rather than export a zero.
    empty_cadence = {"phases": [{"id": p, "question_pool": []} for p in _PLUGIN_FOR_PHASE]}
    segs = _segments()
    for phase_id, plugin_id in _PLUGIN_FOR_PHASE.items():
        if plugin_id == "coding":
            continue  # coding's precheck is about a submission, covered below
        seg = segs[phase_id]
        plug = P.get_plugin(plugin_id)()
        ev = asyncio.run(plug.run(seg, {}, ctx=EvalContext(cadence=empty_cadence)))
        assert ev.state == "assumptions_unmet"

        section = plug.export_section(seg, ev)
        assert section.state == "assumptions_unmet"
        assert section.marks_earned is None and section.marks_possible is None
        assert section.not_scored_reason
        assert section.comparison is None

        payload = json.loads(section.model_dump_json())
        assert payload["marks_earned"] is None, "a non-scored segment must never export 0"
        descriptor = plug.export_descriptor()
        _validate_against_schema(payload, descriptor.json_schema(), model=descriptor.model)


def test_non_scored_coding_section_validates_too():
    events = [
        {"kind": "session_started", "ts": "t", "payload": {"initial_phase": "coding"}},
        {"kind": "coding_phase_started", "ts": "t", "payload": {
            "phase_id": "coding",
            "questions": [{"question_id": "running_sum", "question_prompt": "Return the running sum."}]}},
        {"kind": "session_ended", "ts": "t", "payload": {}},
    ]
    seg = next(s for _p, s in build_segments(events, cadence=CADENCE).iter_segments() if s.kind == "coding")
    plug = P.get_plugin("coding")()
    ev = asyncio.run(plug.run(seg, {}, ctx=EvalContext(cadence=CADENCE)))
    assert ev.state == "assumptions_unmet"          # no submission

    section = plug.export_section(seg, ev)
    assert section.marks_earned is None and section.not_scored_reason
    assert section.tests == [] and section.judge is None
    descriptor = plug.export_descriptor()
    _validate_against_schema(json.loads(section.model_dump_json()),
                             descriptor.json_schema(), model=descriptor.model)


def test_the_model_itself_rejects_marks_on_a_non_scored_state():
    # The invariant is enforced by the contract, not by plugin discipline — a
    # future plugin cannot quietly export "0 marks" for something it could not
    # grade.
    base = dict(section="x", schema_version="1.0", plugin_id="p", segment_id="s",
                phase_id="ph", method="python")
    GroundTruthExport(**base, state="not_observed", not_scored_reason="phase never reached")
    for bad in ({"marks_earned": 0.0, "marks_possible": 10.0}, {"marks_earned": 0.0}):
        try:
            GroundTruthExport(**base, state="not_observed",
                              not_scored_reason="phase never reached", **bad)
            assert False, f"expected marks {bad} to be rejected on a non-scored state"
        except Exception as e:
            assert "not carry marks" in str(e)
    # ...and a scored section must actually carry them.
    try:
        GroundTruthExport(**base, state="scored")
        assert False, "expected a scored section with no marks to be rejected"
    except Exception as e:
        assert "must carry marks_earned" in str(e)


def test_scored_ground_truth_section_must_carry_its_comparison():
    try:
        GroundTruthExport(section="x", schema_version="1.0", plugin_id="p", segment_id="s",
                          phase_id="ph", method="llm_judge", state="scored",
                          marks_earned=5.0, marks_possible=10.0)
        assert False, "expected a scored section with no comparison to be rejected"
    except Exception as e:
        assert "must carry its comparison" in str(e)


# ── the recorded PII decision, enforced ──────────────────────────────────────


def test_export_carries_pointers_not_transcript_text():
    """docs/eval-export-pii-decision.md, as a test.

    Event-index pointers ship; transcript text does not — except the one answer
    a ground-truth score is computed from (`comparison.actual`), and the coding
    per-test rows, which are the graded facts."""
    fam = _run_family()
    for plugin_id, (_seg, _ev, section) in fam.items():
        payload = section.model_dump()
        assert payload["evidence_refs"], f"{plugin_id} exported no evidence pointers"
        assert all(isinstance(r, int) for r in payload["evidence_refs"])

    # The coding section carries no source code and no captured console output.
    coding_json = fam["coding"][2].model_dump_json()
    assert "def running_sum" not in coding_json
    assert "noise" not in coding_json, "test stdout must not ship in the export"
    coding_test_keys = set(fam["coding"][2].tests[0].model_dump())
    assert "stdout" not in coding_test_keys and "stderr" not in coding_test_keys

    # The ground-truth answer IS exported (the score is unverifiable without
    # it) but nothing else from the transcript is — the AI's question text in
    # particular stays out.
    for plugin_id in ("transcription_scoring", "translation_scoring", "image_description_scoring"):
        section = fam[plugin_id][2]
        assert section.comparison.actual
        assert "Describe the image." not in section.model_dump_json()
        assert "Translate the sentence." not in section.model_dump_json()


def _run_all():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn()
        print(f"  ok  {fn.__name__}")
    print(f"\n{len(fns)} export tests passed.")


if __name__ == "__main__":
    _run_all()
