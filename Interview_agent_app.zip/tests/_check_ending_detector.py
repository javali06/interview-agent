"""Quick regression check on Director._matches_ending_phrase.

Run: .venv\\Scripts\\python.exe tests\\_check_ending_detector.py
"""
from __future__ import annotations

import sys

from stream_b_new.core.director import Director


m = Director._matches_ending_phrase

cases = [
    # (utterance, expected_match_or_None)
    # ── greetings / polite openers must NOT end the interview ──────
    ("Yeah, hi, thank you.", None),
    ("Hi, thank you for that.", None),
    ("Thank you for the question, that helped.", None),
    ("Thanks for the explanation.", None),
    ("I am done with that part, what's next?", None),

    # ── short closing utterances should match WEAK exactly ─────────
    ("Thank you.", "thank you"),
    ("thanks for your time.", "thanks for your time"),
    ("Goodbye!", "goodbye"),
    ("Bye", "bye"),
    ("Have a good day", "have a good day"),

    # ── strong closing phrases match anywhere ──────────────────────
    ("Okay, let's wrap up.", "let's wrap up"),
    ("I'm done with the interview.", "i'm done with the interview"),
    ("No more questions from me, thanks.", "no more questions"),
    ("Could we stop here, please?", "can we stop here"),  # not in list

    # ── edge cases ─────────────────────────────────────────────────
    ("", None),
    ("   ", None),
]


def main() -> int:
    fails = 0
    for text, expected in cases:
        got = m(text)
        # The "can we stop here" case in the WEAK / STRONG list has the
        # form "can we stop here" only via STRONG ("stop the interview")
        # — so it WON'T match. Update expected.
        if text == "Could we stop here, please?":
            expected = None
        ok = got == expected
        if not ok:
            fails += 1
        verdict = "OK  " if ok else "FAIL"
        print(f"{verdict}  {text!r:50s} expected={expected!r}  got={got!r}")
    print()
    print(f"{len(cases)} tests, {fails} failures")
    return 0 if fails == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
