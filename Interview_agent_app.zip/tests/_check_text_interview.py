"""Manual LIVE smoke for the text interview (needs an LLM key — NOT part of the
pytest suite; mirrors the tests/_check_* convention). Runs the real TextTurnEngine
end-to-end over an untimed, pool-backed cadence that INCLUDES two one-shot
written-response phases (a legacy word-limited essay AND a char-limited
translation), and checks:
  1. the turn loop (ask → follow-up → advance → end),
  2. the one-shot written phases (a submission ends each, no verifier follow-up)
     — for the legacy comprehensive type AND a typed question type,
  3. eval parity — the emitted events.jsonl parses through the real sectioner,
  4. resume — snapshot → restore into a fresh engine → continue to completion.

Run:  PYTHONPATH=. python tests/_check_text_interview.py
"""
from __future__ import annotations

import asyncio
import os
import sys
import tempfile
import uuid

from dotenv import find_dotenv, load_dotenv

load_dotenv(find_dotenv(usecwd=True))

from engine.brain.cadence.schema import (  # noqa: E402
    CadencePlan, PhaseDef, QuestionPoolItem, WrittenQuestion, WrittenResponse,
)
from engine.brain.contracts.session_state import CandidateProfile  # noqa: E402
from engine.brain.core.event_bus import EventBus  # noqa: E402
from engine.brain.llm import LLMClient  # noqa: E402
from engine.brain.observability import JsonlEventLog, Tracer  # noqa: E402
from engine.brain.text import TextTurnEngine  # noqa: E402
from app.text_service import _question_for_current  # noqa: E402
from features.eval.sectioner import build_segments  # noqa: E402

_KEY = os.environ.get("OPENROUTER_API_KEY") or os.environ.get("GROQ_API_KEY")
if not _KEY:
    print("SKIP: no OPENROUTER_API_KEY / GROQ_API_KEY in env — live check needs a model.")
    sys.exit(0)

_OR = os.environ.get("OPENROUTER_API_KEY")
BASE = "https://openrouter.ai/api/v1" if _OR else "https://api.groq.com/openai/v1"
KEY = _OR or os.environ.get("GROQ_API_KEY")
SLOW = os.environ.get("SLOW_MODEL", "openai/gpt-oss-120b")
FAST = os.environ.get("FAST_MODEL", "meta-llama/llama-3.1-8b-instruct")
ORD = {"provider": {"order": ["Groq"], "allow_fallbacks": False}} if _OR else None


def _q(qid, text):
    return QuestionPoolItem(id=qid, text=text, topic="t", coverage_tags=["a", "b"])


def _plan():
    return CadencePlan(total_duration_s=3, timed=False, phases=[
        PhaseDef(id="warm_up", duration_s=1, intent="Ease in.", question_mode="specific",
                 question_pool=[_q("wu", "Tell me about your current role and main tech.")]),
        PhaseDef(id="essay", duration_s=1, intent="Written depth.", question_mode="specific",
                 question_pool=[_q("essay_q", "In up to 200 words, describe a hard problem you solved.")],
                 written_response=WrittenResponse(word_limit=200, time_limit_s=600)),
        # A typed question type (translation) with TWO questions: char-limited,
        # untimed, each carrying its own material (source_text) in the phase
        # config rather than through the LLM. The candidate answers them one at a
        # time and the phase only ends when the pool is drained.
        PhaseDef(id="translation", duration_s=1, intent="Translation.", question_mode="specific",
                 question_pool=[
                     QuestionPoolItem(
                         id="translation_q1", topic="t",
                         text="Translate the text below from English into French.",
                         written_response=WrittenQuestion(
                             char_limit=600,
                             source_text="The deployment failed twice last night."),
                     ),
                     QuestionPoolItem(
                         id="translation_q2", topic="t",
                         text="Translate the text below from English into French.",
                         written_response=WrittenQuestion(
                             char_limit=400,
                             source_text="Please restart the service and confirm."),
                     ),
                 ],
                 written_response=WrittenResponse(question_type="translation",
                                                  source_language="en", target_language="fr")),
        PhaseDef(id="wrap_up", duration_s=1, intent="Close.", question_mode="specific",
                 question_pool=[_q("wrap", "Any questions for me?")]),
    ])


def _engine(events_path, restore=None):
    log = JsonlEventLog(events_path)
    tr = Tracer(session_id=uuid.uuid4(), event_log=log, bus=EventBus())
    slow = LLMClient(api_key=KEY, base_url=BASE, default_extra_body=ORD, tier="slow")
    fast = LLMClient(api_key=KEY, base_url=BASE, default_extra_body=ORD, tier="fast")
    eng = TextTurnEngine(plan=_plan(), candidate=CandidateProfile(name="Sam", role="Backend Eng"),
                         tracer=tr, slow_llm=slow, fast_llm=fast, slow_model=SLOW, fast_model=FAST,
                         restore=restore)
    return eng, log


async def main():
    tmp = tempfile.mkdtemp()
    ev = os.path.join(tmp, "events.jsonl")
    eng, log = _engine(ev)

    await eng.open_turn()
    # Answer warm_up until it advances (the exact number of verifier follow-ups
    # is LLM-dependent; the follow-up cap guarantees it advances within a couple).
    for _ in range(4):
        await eng.run_one_turn(
            "I'm a senior backend engineer at a fintech; I own the payments API in "
            "Go and Postgres, on-call rotations, and mentoring two juniors."
        )
        if eng.phase != "warm_up":
            break
    assert eng.phase == "essay", f"expected essay, got {eng.phase}"

    # essay one-shot: a single submission ends the phase (no verifier follow-up)
    r_essay = await eng.run_one_turn(
        "The hardest problem was a cascading failure in settlement: a slow ledger call exhausted the "
        "thread pool and stalled unrelated requests. I reproduced it under load, added bounded timeouts "
        "and a bulkhead, made settlement idempotent behind a queue, and added back-pressure + alerts."
    )
    assert r_essay.get("written_response_submitted") is True, "essay must be one-shot"
    assert "verifier_intent" not in r_essay, "essay must skip the verifier follow-up"
    assert eng.phase == "translation", eng.phase

    # the payload the candidate renders from — material verbatim, char-counted,
    # and it says WHICH question of the phase we're on
    q = _question_for_current(eng, "live-token")
    assert q["question_type"] == "translation" and q["limit_kind"] == "chars", q
    assert q["source_text"] == "The deployment failed twice last night.", q
    assert q["target_language_label"] == "French", q
    assert (q["question_id"], q["question_index"], q["question_total"]) == ("translation_q1", 1, 2), q

    # question 1 of 2: one-shot submission closes the QUESTION, not the phase
    r_tr = await eng.run_one_turn("Le déploiement a échoué deux fois la nuit dernière.")
    assert r_tr.get("written_response_submitted") is True, "translation must be one-shot"
    assert "verifier_intent" not in r_tr, "translation must skip the verifier follow-up"
    assert eng.phase == "translation", f"phase must hold until its pool drains: {eng.phase}"
    q2 = _question_for_current(eng, "live-token")
    assert (q2["question_id"], q2["question_index"]) == ("translation_q2", 2), q2
    assert q2["source_text"] == "Please restart the service and confirm.", q2
    assert q2["limit"] == 400, q2

    # question 2 of 2: now the pool is drained → the phase advances
    r_tr2 = await eng.run_one_turn("Veuillez redémarrer le service et confirmer.")
    assert r_tr2.get("written_response_submitted") is True
    assert eng.phase == "wrap_up", eng.phase

    # snapshot mid-interview → restore into a FRESH engine → finish
    snap = eng.snapshot()
    log.close()
    eng2, log2 = _engine(ev, restore=snap)
    r_end = await eng2.run_one_turn("No questions, thanks!")
    log2.close()
    assert r_end["ended"], "interview should end after wrap_up on the resumed engine"

    # eval parity: the events.jsonl parses through the real sectioner
    with open(ev) as fp:
        import json
        rows = [json.loads(li) for li in fp if li.strip()]
    segs = build_segments(rows, cadence=_plan().model_dump())
    phase_objs = getattr(segs, "phases", segs)
    ids = [getattr(p, "phase_id", p) for p in phase_objs]
    assert "warm_up" in ids and "essay" in ids and "translation" in ids, \
        f"sectioner missing phases: {ids}"
    print("live check OK · phases sectioned:", ids)
    print("PASS — turn loop + one-shot essay + multi-question translation phase "
          "+ resume + eval-parity all green.")


if __name__ == "__main__":
    asyncio.run(main())
