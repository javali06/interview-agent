"""Unit tests for the evaluation plan (migration/validation/fingerprint) and
the deterministic paths of the production plugins.

Runs under pytest OR directly (`python tests/test_eval_plan.py`).
"""
from __future__ import annotations

import asyncio

import features.eval.plugins as P
from features.eval.heuristic import heuristic_rubric
from features.eval.plan import (
    extend_plan_with_new_phases,
    plan_fingerprint,
    plan_from_cadence,
    plan_from_rubric,
    validate_plan_dict,
)
from features.eval.plugins.base import EvalContext
from features.eval.sectioner import build_segments

CADENCE = {
    "total_duration_s": 240,
    "phases": [
        {"id": "warm_up", "duration_s": 30, "intent": "greet", "question_mode": "generic", "generic_prompts": ["hi"]},
        {"id": "tech", "duration_s": 120, "intent": "fundamentals", "question_mode": "specific",
         "question_pool": [{"id": "q1", "text": "attention?", "difficulty": "medium", "coverage_tags": ["qkv"]}]},
        {"id": "code", "duration_s": 60, "intent": "coding", "question_mode": "generic",
         "generic_prompts": ["code"], "coding_question_ids": ["running_sum"]},
        {"id": "wrap_up", "duration_s": 30, "intent": "close", "question_mode": "generic", "generic_prompts": ["bye"]},
    ],
}


def test_plan_from_cadence_assigns_sensible_plugins():
    plan = plan_from_cadence(CADENCE, role="AI Engineer").model_dump(mode="json")
    by_phase = {p["phase_id"]: p["plugins"][0] for p in plan["phases"]}
    assert by_phase["code"]["plugin_id"] == "coding"
    assert by_phase["tech"]["plugin_id"] == "conversational_rubric"
    # warm_up / wrap_up quarantined → carried but disabled
    assert by_phase["warm_up"]["enabled"] is False
    assert by_phase["wrap_up"]["enabled"] is False
    assert by_phase["tech"]["enabled"] is True


def test_plan_validates_and_rejects_bad_config():
    plan = plan_from_cadence(CADENCE).model_dump(mode="json")
    ok, err = validate_plan_dict(plan)
    assert ok is not None and err is None

    plan["phases"][1]["plugins"][0] = {"plugin_id": "coverage_tags", "config": {"marks_per_tag": -1}}
    bad, err2 = validate_plan_dict(plan)
    assert bad is None and "invalid config" in err2


def test_plan_rejects_unknown_plugin():
    plan = plan_from_cadence(CADENCE).model_dump(mode="json")
    plan["phases"][0]["plugins"][0] = {"plugin_id": "does_not_exist", "config": {}}
    bad, err = validate_plan_dict(plan)
    assert bad is None and "unknown plugin" in err


def test_fingerprint_stable_and_sensitive():
    a = plan_from_cadence(CADENCE).model_dump(mode="json")
    b = plan_from_cadence(CADENCE).model_dump(mode="json")
    assert plan_fingerprint(a) == plan_fingerprint(b)  # timestamps excluded
    b["phases"][1]["plugins"][0]["config"]["marks_possible"] = 99
    assert plan_fingerprint(a) != plan_fingerprint(b)


def test_migration_from_rubric_round_trips():
    rubric = heuristic_rubric(CADENCE, role="AI Engineer").model_dump(mode="json")
    plan = plan_from_rubric(rubric, CADENCE).model_dump(mode="json")
    ok, err = validate_plan_dict(plan)
    assert ok is not None and err is None
    assert plan["source"] == "migrated"
    assert {p["phase_id"] for p in plan["phases"]} == {"warm_up", "tech", "code", "wrap_up"}


def test_extend_with_new_phase():
    short = {"phases": [{"phase_id": "warm_up",
                         "plugins": [{"plugin_id": "conversational_rubric", "config": {}, "enabled": False}]}]}
    ext = extend_plan_with_new_phases(short, CADENCE, role="AI Engineer")
    assert [p["phase_id"] for p in ext["phases"]] == ["warm_up", "tech", "code", "wrap_up"]


# ── deterministic plugin paths ───────────────────────────────────────────────


def _dd_segment():
    events = [
        {"kind": "session_started", "payload": {"initial_phase": "tech"}, "ts": "t"},
        {"kind": "question_dispatched", "payload": {"phase_id": "tech", "question_id": "q1",
            "difficulty": "medium", "coverage_tags": ["qkv", "softmax"]}, "ts": "t"},
        {"kind": "ai_utterance", "payload": {"text": "explain attention"}, "ts": "t"},
        {"kind": "stt_final", "payload": {"text": "qkv similarity"}, "ts": "t"},
        {"kind": "verifier_classified", "payload": {"intent": "partial_answer", "missing_tags": ["softmax"]}, "ts": "t"},
        {"kind": "ai_utterance", "payload": {"text": "what about softmax"}, "ts": "t"},
        {"kind": "stt_final", "payload": {"text": "not sure"}, "ts": "t"},
        {"kind": "verifier_classified", "payload": {"intent": "answered", "missing_tags": ["softmax"]}, "ts": "t"},
        {"kind": "session_ended", "payload": {}, "ts": "t"},
    ]
    return next(s for _, s in build_segments(events).iter_segments() if s.question_id == "q1")


def test_dynamic_difficulty_deterministic_via_verifier():
    seg = _dd_segment()
    plug = P.get_plugin("dynamic_difficulty")()
    res = asyncio.run(plug.run(seg, {"difficulty_marks": {"medium": 10}, "follow_up_penalty": 2,
                                     "missed_tag_penalty": 3}, ctx=EvalContext()))
    # 10 base − 2 (one follow-up) − 3 (one missed tag) = 5
    assert res.state == "scored"
    assert res.marks_possible == 10.0
    assert res.marks_earned == 5.0
    assert res.view_payload["still_missed"] == ["softmax"]


def test_dynamic_difficulty_assumptions_unmet_without_difficulty():
    events = [
        {"kind": "session_started", "payload": {"initial_phase": "tech"}, "ts": "t"},
        {"kind": "question_dispatched", "payload": {"phase_id": "tech", "question_id": "q1", "coverage_tags": ["x"]}, "ts": "t"},
        {"kind": "stt_final", "payload": {"text": "ans"}, "ts": "t"},
        {"kind": "session_ended", "payload": {}, "ts": "t"},
    ]
    seg = next(s for _, s in build_segments(events).iter_segments() if s.question_id == "q1")
    res = asyncio.run(P.get_plugin("dynamic_difficulty")().run(seg, {}, ctx=EvalContext()))
    assert res.state == "assumptions_unmet"


def test_coding_plugin_deterministic_pass_rate():
    events = [
        {"kind": "session_started", "payload": {"initial_phase": "code"}, "ts": "t"},
        {"kind": "coding_phase_started", "payload": {"phase_id": "code",
            "questions": [{"question_id": "running_sum", "question_prompt": "sum"}]}, "ts": "t"},
        {"kind": "coding_code_submitted", "payload": {"question_id": "running_sum", "final_code": "def f(): pass",
            "final_test_results": [{"pass": True}, {"pass": True}, {"pass": False}, {"pass": True}], "runs_used": 2}, "ts": "t"},
        {"kind": "session_ended", "payload": {}, "ts": "t"},
    ]
    seg = next(s for _, s in build_segments(events).iter_segments() if s.question_id == "running_sum")
    res = asyncio.run(P.get_plugin("coding")().run(seg, {"marks_possible": 10, "use_llm_judge": False}, ctx=EvalContext()))
    assert res.state == "scored"
    assert res.view_payload["pass_rate"] == 0.75
    assert res.marks_earned == 7.5  # no LLM → pass_rate * marks_possible


def test_validate_against_cadence_flags_missing_difficulty():
    # tech phase questions lack difficulty/coverage_tags when assigned dynamic_difficulty
    cad = {
        "phases": [
            {"id": "tech", "question_mode": "specific",
             "question_pool": [{"id": "q1", "text": "?"}, {"id": "q2", "text": "?", "difficulty": "easy"}]},
        ],
    }
    plan = {"phases": [{"phase_id": "tech", "plugins": [
        {"plugin_id": "dynamic_difficulty", "config": {}, "enabled": True}]}]}
    from features.eval.plan import validate_plan_against_cadence
    res = validate_plan_against_cadence(plan, cad)
    pr = res[0]["plugins"][0]
    assert pr["plugin_id"] == "dynamic_difficulty" and pr["ok"] is False
    joined = " ".join(pr["unmet"])
    assert "difficulty" in joined and "coverage_tags" in joined


def test_validate_against_cadence_passes_when_satisfied():
    cad = {"phases": [{"id": "tech", "question_mode": "specific",
                       "question_pool": [{"id": "q1", "text": "?", "difficulty": "medium", "coverage_tags": ["a"]}]}]}
    plan = {"phases": [{"phase_id": "tech", "plugins": [
        {"plugin_id": "dynamic_difficulty", "config": {}, "enabled": True}]}]}
    from features.eval.plan import validate_plan_against_cadence
    res = validate_plan_against_cadence(plan, cad)
    assert res[0]["plugins"][0]["ok"] is True


def test_validate_against_cadence_prefixes_unmet_with_phase_and_plugin():
    # Two phases failing the SAME rule must still be distinguishable in the
    # unmet text alone — a copied/pasted message with no surrounding UI has
    # nothing else to identify which phase it's about.
    cad = {"phases": [
        {"id": "warm_up", "question_mode": "generic"},
        {"id": "genai_basics", "question_mode": "generic"},
    ]}
    plan = {"phases": [
        {"phase_id": "warm_up", "plugins": [{"plugin_id": "conversational_rubric", "config": {}, "enabled": True}]},
        {"phase_id": "genai_basics", "plugins": [{"plugin_id": "conversational_rubric", "config": {}, "enabled": True}]},
    ]}
    from features.eval.plan import validate_plan_against_cadence
    res = validate_plan_against_cadence(plan, cad)
    warm_up_unmet = next(p for p in res if p["phase_id"] == "warm_up")["plugins"][0]["unmet"]
    genai_unmet = next(p for p in res if p["phase_id"] == "genai_basics")["plugins"][0]["unmet"]
    assert warm_up_unmet != genai_unmet
    assert all(u.startswith("warm_up / conversational_rubric: ") for u in warm_up_unmet)
    assert all(u.startswith("genai_basics / conversational_rubric: ") for u in genai_unmet)


def test_every_precheck_cadence_failure_has_example_or_instruction():
    """Regression guard: every built-in plugin's precheck_cadence, when it
    fails on a maximally-empty phase + default config, must include either a
    JSON "Example:" line (cadence-fixable) or a reference to the "Evaluation
    panel" (config-fixable) somewhere in its unmet list — so a future plugin
    can't silently ship a bare, example-less message like the old
    dynamic_difficulty/coverage_tags/etc. messages did. Plugins that pass on
    an empty phase (nothing required) are skipped; this only probes plugins
    with a real cadence/config precondition to fail in the first place."""
    from features.eval.plugins.registry import list_plugins

    checked = 0
    for cls in list_plugins():
        cfg = cls.default_config()
        res = cls().precheck_cadence({}, cfg)
        if res.ok:
            continue
        checked += 1
        has_example = any("Example:" in u for u in res.unmet)
        has_instruction = any("Evaluation panel" in u for u in res.unmet)
        assert has_example or has_instruction, (
            f"{cls.id}: precheck_cadence failure has no example/instruction: {res.unmet}"
        )
    assert checked >= 5, "expected at least the 5 built-ins to fail on an empty phase"


def test_validate_skips_disabled_plugins():
    # coding plugin on a non-coding phase would fail — but it's disabled, so skipped
    cad = {"phases": [{"id": "tech", "question_mode": "specific", "question_pool": [{"id": "q1", "text": "?"}]}]}
    plan = {"phases": [{"phase_id": "tech", "plugins": [
        {"plugin_id": "coding", "config": {}, "enabled": False}]}]}
    from features.eval.plan import validate_plan_against_cadence
    res = validate_plan_against_cadence(plan, cad)
    assert res[0]["plugins"] == []  # disabled assignment skipped


def test_validate_plan_dict_skips_disabled_bad_config():
    # a disabled assignment with an invalid config must NOT fail save validation
    plan = {"phases": [{"phase_id": "tech", "plugins": [
        {"plugin_id": "coverage_tags", "config": {"marks_per_tag": -5}, "enabled": False}]}]}
    ok, err = validate_plan_dict(plan)
    assert ok is not None and err is None


def test_validate_plan_dict_allows_no_plugin_phase():
    # A phase the TA left ungraded (no plugin chosen) must save without error —
    # whether expressed as an empty plugin list or an empty plugin_id.
    plan = {"phases": [
        {"phase_id": "warm_up", "plugins": []},
        {"phase_id": "tech", "plugins": [{"plugin_id": "", "config": {}, "enabled": True}]},
    ]}
    ok, err = validate_plan_dict(plan)
    assert ok is not None and err is None
    # and the no-plugin phase contributes nothing to validation-against-cadence
    from features.eval.plan import validate_plan_against_cadence
    res = validate_plan_against_cadence(plan, {"phases": [{"id": "tech"}]})
    tech = next(p for p in res if p["phase_id"] == "tech")
    assert tech["plugins"] == []


def test_llm_plugins_unmet_without_key():
    seg = _dd_segment()
    for pid in ("rubric_marks", "conversational_rubric"):
        cfg = {"criteria": [{"description": "x", "marks": 2}]} if pid == "rubric_marks" \
            else {"score_dimensions": ["technical_depth"]}
        res = asyncio.run(P.get_plugin(pid)().run(seg, cfg, ctx=EvalContext()))
        assert res.state == "assumptions_unmet", pid


def _run_all():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn()
        print(f"  ok  {fn.__name__}")
    print(f"\n{len(fns)} plan tests passed.")


if __name__ == "__main__":
    _run_all()


def test_the_plan_lives_beside_every_other_session_artefact(monkeypatch, tmp_path):
    """Regression: plans were written to <repo>/features/sessions/ instead of
    <repo>/sessions/.

    `_sessions_dir` recomputed the repo root as `Path(__file__).parent.parent`,
    which from features/eval/ is `<repo>/features`. In a container that path is
    INSIDE the image while /app/sessions is the mounted volume, so every image
    rebuild destroyed all saved plans. The next evaluation then derived the
    "nothing is scored" default, persisted it, and scored 0/0 for ever after —
    silently, because an unassigned phase is a legitimate state, so nothing
    logged an error and no test failed.
    """
    from app.paths import session_dir
    from features.eval import plan_storage

    got = plan_storage.plan_path("tok-1")
    assert got.parent == session_dir("tok-1"), (
        f"the plan must sit beside the other artefacts: {got.parent} != {session_dir('tok-1')}"
    )
    assert "features" not in got.parts, "plan escaped into the source tree"


def test_sessions_dir_env_override_still_wins(monkeypatch, tmp_path):
    # Cloud points SESSIONS_DIR at a persistent volume; the fix must not break it.
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path / "vol"))
    import importlib
    from app import paths
    from features.eval import plan_storage as ps
    importlib.reload(paths)
    importlib.reload(ps)
    assert ps.plan_path("tok-2") == tmp_path / "vol" / "tok-2" / "evaluation_plan.json"


def test_a_cold_session_dir_restores_the_plan_from_blob_instead_of_wiping_it(
        monkeypatch, tmp_path):
    """Regression: the second half of the 0/0 bug.

    When the local plan file is missing (cold dir after a restart, or a
    different replica), `load_plan` used to return None. The caller then
    derived the "nothing is scored" default, persisted it, and the mirror
    overwrote the good copy in blob — so a configured interview silently began
    scoring 0 and the configuration was unrecoverable.

    Note: with BLOB_ENABLED=0 blob_store's disk fallback writes INTO
    SESSIONS_DIR, so a real round-trip cannot distinguish local from blob here.
    The blob read is stubbed to keep this a test of load_plan's fallback.
    """
    import json
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path / "cold"))
    import importlib
    from app import blob_store, paths
    importlib.reload(paths); importlib.reload(blob_store)
    from features.eval import plan_storage as ps
    importlib.reload(ps)

    configured = {"source": "operator", "generated_at": "2026-09-22T00:00:00+00:00",
                  "phases": [{"phase_id": "warm_up",
                              "plugins": [{"plugin_id": "conversational_rubric",
                                           "config": {}, "enabled": True}]}]}
    monkeypatch.setattr(
        blob_store, "download_bytes",
        lambda name: json.dumps({"current": configured, "history": []}).encode()
        if name == "tok-cold/evaluation_plan.json" else None)

    assert not ps.plan_path("tok-cold").exists(), "local copy must be absent"
    got = ps.load_plan("tok-cold")
    assert got is not None, "a cold dir must not read as 'no plan' while blob has one"
    assert got["phases"][0]["plugins"][0]["plugin_id"] == "conversational_rubric"


def test_no_local_and_no_blob_is_still_None(monkeypatch, tmp_path):
    # The genuinely-new-session case must keep working.
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path / "empty"))
    import importlib
    from app import blob_store, paths
    importlib.reload(paths); importlib.reload(blob_store)
    from features.eval import plan_storage as ps
    importlib.reload(ps)
    monkeypatch.setattr(blob_store, "download_bytes", lambda name: None)
    assert ps.load_plan("tok-brand-new") is None
