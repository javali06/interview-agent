"""Phase-boundary attribution: a candidate answer that finalizes while the phase
clock is expiring must stay in the phase whose question it was answering.

The director emits phase_changed TWICE per transition (see director.py):
  1. a QUEUED pre-announcement (payload.queued=True) the instant the phase clock
     expires — fired ungated, even mid-utterance;
  2. the real APPLIED marker (reason="natural", no queued flag) once the candidate
     stops speaking.
A candidate's answer to the OLD phase finalizes BETWEEN the two, so every
positional parser must segment on the applied marker only. These tests pin that
across all four read-time parsers.

Runs under pytest OR directly as a script (`python tests/test_phase_boundary_attribution.py`)
since pytest isn't always installed in the runtime venv.
"""
from __future__ import annotations

from features.eval.sectioner import build_segments
from app.event_viewer import group_by_phase, annotate
from app.resume_collapse import collapse_resumed_events


def _ts(n: int) -> str:
    """Deterministic ISO-8601 UTC timestamps (event_viewer parses these)."""
    return f"2026-08-07T10:{n // 60:02d}:{n % 60:02d}+00:00"


def _straddle_events() -> list[dict]:
    """The confirmed event order when the clock expires mid-answer in phase 'tech':
    the candidate's second half of the q1 answer lands AFTER the queued marker but
    BEFORE the applied one, so it belongs to tech, not wrap_up."""
    return [
        {"kind": "session_started", "payload": {"initial_phase": "tech"}, "ts": _ts(0)},
        {"kind": "question_dispatched", "payload": {
            "phase_id": "tech", "question_id": "q1", "question_text": "Explain X"}, "ts": _ts(1)},
        {"kind": "ai_utterance", "payload": {"text": "Explain X"}, "ts": _ts(2)},
        {"kind": "stt_final", "payload": {"text": "first half of my answer"}, "ts": _ts(3)},
        # clock expires while the candidate is still answering q1:
        {"kind": "phase_changed", "payload": {
            "from_phase": "tech", "to_phase": "wrap_up", "reason": "time_budget", "queued": True}, "ts": _ts(4)},
        # the candidate finishes q1 — MUST stay in tech, not wrap_up:
        {"kind": "stt_final", "payload": {"text": "second half of my answer"}, "ts": _ts(5)},
        # the real transition, after the candidate stopped:
        {"kind": "phase_changed", "payload": {
            "from_phase": "tech", "to_phase": "wrap_up", "reason": "natural"}, "ts": _ts(6)},
        {"kind": "ai_utterance", "payload": {"text": "Thanks, that wraps us up."}, "ts": _ts(7)},
        {"kind": "session_ended", "payload": {}, "ts": _ts(8)},
    ]


# ── sectioner (v2 eval — the evaluation-critical one) ────────────────────────


def test_sectioner_keeps_straddling_answer_in_prev_phase():
    iv = build_segments(_straddle_events())
    assert [p.phase_id for p in iv.phases] == ["tech", "wrap_up"], [p.phase_id for p in iv.phases]
    tech = iv.phases[0]
    q1 = next((s for s in tech.segments if s.question_id == "q1"), None)
    assert q1 is not None, "q1 segment missing from tech"
    answers = " ".join(t.text for t in q1.candidate_turns())
    assert "first half of my answer" in answers
    # the crux: the answer that finalized after the QUEUED marker is still under q1
    assert "second half of my answer" in answers, "straddling answer was misfiled out of tech"
    # and it did NOT leak into wrap_up (where it would land in a dropped warmup seed)
    wrap_text = " ".join(t.text for s in iv.phases[1].segments for t in s.turns)
    assert "second half of my answer" not in wrap_text


# ── admin trace viewer (group_by_phase) ──────────────────────────────────────


def test_group_by_phase_keeps_straddling_answer_in_prev_phase():
    phases = group_by_phase(_straddle_events())
    by_id = {p["id"]: p for p in phases}
    assert "tech" in by_id and "wrap_up" in by_id, list(by_id)
    tech_text = " ".join(t["candidate_text"] for t in by_id["tech"]["turns"])
    assert "first half of my answer" in tech_text
    assert "second half of my answer" in tech_text, "straddling answer misfiled out of tech"
    wrap_text = " ".join(t["candidate_text"] for t in by_id["wrap_up"]["turns"])
    assert "second half of my answer" not in wrap_text


def test_annotate_labels_queued_phase_change_distinctly():
    rows = annotate_from_events(_straddle_events())
    phase_rows = [r for r in rows if r["kind"] == "phase_changed"]
    labels = [r["label"] for r in phase_rows]
    # one queued pre-announcement (distinct label) + one applied transition
    assert "Phase (pending)" in labels, labels
    assert any(l != "Phase (pending)" for l in labels), labels


def annotate_from_events(events: list[dict]):
    """annotate() reads a file path; exercise its row logic on an in-memory list
    by writing a temp jsonl. Kept tiny + local so the module has no fixture deps."""
    import json, tempfile, os
    from pathlib import Path
    fd, name = tempfile.mkstemp(suffix=".jsonl")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            for e in events:
                f.write(json.dumps(e) + "\n")
        return annotate(Path(name))
    finally:
        os.unlink(name)


# ── v1 transcript assembler (guarded import — pulls heavy deps) ───────────────


def test_assemble_transcript_places_answer_before_boundary():
    try:
        from app.evaluation_service import _assemble_transcript
    except Exception as e:  # bare venv without cadence/LLM deps — skip cleanly
        print(f"  skip test_assemble_transcript_places_answer_before_boundary ({type(e).__name__})")
        return
    tx = _assemble_transcript(_straddle_events())
    # exactly ONE phase marker (the applied one; the queued pre-announce is skipped)
    assert tx.count("tech → wrap_up") == 1, tx
    # the straddling answer renders BEFORE the boundary heading → under tech
    assert tx.index("second half of my answer") < tx.index("tech → wrap_up"), tx


# ── resume_collapse walk-back (secondary consistency) ────────────────────────


def _resume_events() -> list[dict]:
    """A crash mid-tech: the pre-crash partial + a QUEUED tech→coding marker sit
    between the applied entry into tech and the resume marker. The walk-back must
    anchor on the APPLIED tech entry, not the queued pre-announcement."""
    return [
        {"kind": "session_started", "payload": {"initial_phase": "warm_up"}, "ts": _ts(0)},          # 0
        {"kind": "phase_changed", "payload": {"from_phase": "warm_up", "to_phase": "tech",
            "reason": "natural"}, "ts": _ts(1)},                                                       # 1 applied entry
        {"kind": "ai_utterance", "payload": {"text": "tech question"}, "ts": _ts(2)},                 # 2
        {"kind": "stt_final", "payload": {"text": "partial answer before crash"}, "ts": _ts(3)},      # 3 abandoned
        {"kind": "phase_changed", "payload": {"from_phase": "tech", "to_phase": "coding",
            "reason": "time_budget", "queued": True}, "ts": _ts(4)},                                   # 4 queued (crash after)
        {"kind": "session_started", "payload": {"resumed": True}, "ts": _ts(5)},                      # 5 phantom start
        {"kind": "session_resumed", "payload": {"phase_id": "tech"}, "ts": _ts(6)},                   # 6 resume marker
        {"kind": "ai_utterance", "payload": {"text": "resuming tech question"}, "ts": _ts(7)},        # 7
        {"kind": "stt_final", "payload": {"text": "real answer after resume"}, "ts": _ts(8)},         # 8
        {"kind": "session_ended", "payload": {}, "ts": _ts(9)},                                       # 9
    ]


def test_resume_collapse_anchors_on_applied_not_queued():
    result = collapse_resumed_events(_resume_events())
    texts = [(e.get("payload") or {}).get("text") for e in result if e["kind"] == "stt_final"]
    assert "partial answer before crash" not in texts, "abandoned partial not dropped"
    assert "real answer after resume" in texts
    to_phases = [(e.get("payload") or {}).get("to_phase") for e in result if e["kind"] == "phase_changed"]
    # the queued tech→coding pre-announce is dropped with the abandoned attempt;
    # the applied entry into tech survives as the phase anchor
    assert "coding" not in to_phases, to_phases
    assert "tech" in to_phases, to_phases


def test_resume_then_group_by_phase_puts_resumed_answer_in_tech():
    # End-to-end: collapse + bucket. The resumed answer belongs to tech, and the
    # dropped queued coding marker must not create a phantom coding bucket.
    phases = group_by_phase(collapse_resumed_events(_resume_events()))
    by_id = {p["id"]: p for p in phases}
    assert "coding" not in by_id, list(by_id)
    tech_text = " ".join(t["candidate_text"] for t in by_id.get("tech", {}).get("turns", []))
    assert "real answer after resume" in tech_text


def _run_all():
    fns = [v for k, v in sorted(globals().items())
           if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn()
        print(f"  ok  {fn.__name__}")
    print(f"\n{len(fns)} phase-boundary attribution tests passed.")


if __name__ == "__main__":
    _run_all()
