"""Workstream A: identity, teams, roles, the permission grid.

Most of these assert a REFUSAL. That is deliberate — a permission system is
only worth having if something is closed, and "Harika can approve" passing tells
you nothing about whether "Harika can approve QA's pool" is blocked.
"""
from __future__ import annotations

import pytest

from db.engine import reset_engine, session_scope


AYUSH = "ayush.kothiyal@centific.com"      # admin @ *
SATHWIK = "sathwik.badda@centific.com"     # admin @ *
AZHAR = "md.azhar@centific.com"            # pool_author @ backend
HARIKA = "puchalapalli.harika@centific.com"  # pool_checker @ backend
SHOBIT = "sai.kambampati@centific.com"     # pool_checker @ * (central)
HASINI = "hasini.gandhe@centific.com"      # pool_author @ qa
JAVALI = "javali.manda@centific.com"       # hr


@pytest.fixture()
def seeded(tmp_path, monkeypatch):
    """A throwaway SQLite database with the RBAC seed applied."""
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    monkeypatch.delenv("DATABASE_URL", raising=False)
    reset_engine()

    from db.engine import create_all

    create_all()

    from app.rbac_seed import seed_rbac

    seed_rbac()

    from app import rbac

    def uid(email: str) -> int:
        row = rbac.user_by_email(email)
        assert row is not None, f"{email} was not seeded"
        return row["id"]

    yield uid
    reset_engine()


# ── the vocabulary ───────────────────────────────────────────────────────


def test_permission_vocabulary_is_closed():
    from app import rbac

    assert rbac.is_valid_permission("pools.approve")
    assert not rbac.is_valid_permission("pools.aprove")      # typo
    assert not rbac.is_valid_permission("pools.*")           # not a wildcard
    with pytest.raises(ValueError):
        rbac.validate_permission("pools.destroy")


def test_every_seeded_grid_permission_is_in_the_vocabulary():
    """A seed that grants a permission nothing recognises would silently grant
    nothing at all — the exact failure the closed vocabulary exists to stop."""
    from app.rbac import ALL_PERMISSIONS
    from app.rbac_seed import ROLE_PERMISSIONS

    for role_key, permissions in ROLE_PERMISSIONS.items():
        for permission in permissions:
            assert permission in ALL_PERMISSIONS, f"{role_key} -> {permission}"


# ── the seed ─────────────────────────────────────────────────────────────


def test_seed_creates_the_seven_accounts(seeded):
    from app import rbac

    for email in (AYUSH, SATHWIK, AZHAR, HARIKA, SHOBIT, HASINI, JAVALI):
        assert rbac.user_by_email(email) is not None, email


def test_seed_is_idempotent(seeded):
    """It runs on every start, so a second pass must create nothing."""
    from app.rbac_seed import seed_rbac

    again = seed_rbac()
    assert again == {
        "teams": 0, "roles": 0, "permissions": 0, "steps": 0, "users": 0, "grants": 0,
    }


def test_reseeding_never_restores_a_permission_an_admin_removed(seeded):
    """The grid is policy an administrator owns. If a restart put back a
    permission they deliberately revoked, the whole 'edit it from a screen'
    promise is a lie."""
    from sqlalchemy import select

    from app.rbac_seed import seed_rbac
    from db.models import AppRole, AppRolePermission

    uid = seeded
    with session_scope() as s:
        role_id = s.execute(
            select(AppRole.id).where(AppRole.key == "pool_author")
        ).scalar_one()
        row = s.get(AppRolePermission, (role_id, "pools.submit"))
        s.delete(row)

    seed_rbac()

    assert not _has(uid(AZHAR), "pools.submit")


def test_entra_oid_is_empty_on_every_seeded_account(seeded):
    """The account is local today and picks up its Microsoft identifier on
    first real sign-in. A seeded oid would be a fabricated identity."""
    from sqlalchemy import select

    from db.models import AppUser

    with session_scope() as s:
        oids = s.execute(select(AppUser.entra_oid)).scalars().all()
    assert all(o is None for o in oids)


def test_default_chain_is_one_step(seeded):
    """One approval is the default; a second level is a row someone adds."""
    from sqlalchemy import select

    from db.models import AppApprovalStep, AppTeam

    with session_scope() as s:
        team_id = s.execute(select(AppTeam.id).where(AppTeam.key == "*")).scalar_one()
        steps = s.execute(
            select(AppApprovalStep).where(AppApprovalStep.team_id == team_id)
        ).scalars().all()
    assert [st.step_no for st in steps] == [1]


# ── the checks ───────────────────────────────────────────────────────────


def _has(user_id, permission, team=None):
    from app import rbac

    return rbac.has_permission(user_id, permission, team)


def test_author_can_edit_and_submit_but_never_approve(seeded):
    uid = seeded
    azhar = uid(AZHAR)
    assert _has(azhar, "pools.edit", "backend")
    assert _has(azhar, "pools.submit", "backend")
    assert not _has(azhar, "pools.approve", "backend")
    assert not _has(azhar, "pools.publish", "backend")


def test_checker_is_scoped_to_their_own_team(seeded):
    """The refusal that makes team scoping real rather than decorative:
    Harika checks for Backend, so Hasini's QA pool is not hers to approve."""
    uid = seeded
    harika = uid(HARIKA)
    assert _has(harika, "pools.approve", "backend")
    assert not _has(harika, "pools.approve", "qa")


def test_a_central_checker_covers_every_team(seeded):
    """One grant on `*`, not one row per team."""
    uid = seeded
    shobit = uid(SHOBIT)
    assert _has(shobit, "pools.approve", "backend")
    assert _has(shobit, "pools.approve", "qa")


def test_hr_holds_no_pool_permission_at_all(seeded):
    """The point of the HR persona: the person who books the interview has no
    hand in what gets asked in it. Asserted over the whole pools.* family, so
    a permission added later is caught here."""
    from app.rbac import POOL_PERMISSIONS

    uid = seeded
    javali = uid(JAVALI)
    for permission in POOL_PERMISSIONS:
        assert not _has(javali, permission), permission
        assert not _has(javali, permission, "backend"), permission
    # ...and does hold what the persona exists for.
    assert _has(javali, "interviews.schedule")


def test_admin_holds_everything(seeded):
    from app.rbac import ALL_PERMISSIONS

    uid = seeded
    ayush = uid(AYUSH)
    for permission in ALL_PERMISSIONS:
        assert _has(ayush, permission, "backend"), permission


def test_authors_and_checkers_cannot_administer(seeded):
    uid = seeded
    for email in (AZHAR, HARIKA, SHOBIT, HASINI, JAVALI):
        assert not _has(uid(email), "admin.users"), email
        assert not _has(uid(email), "admin.permissions"), email


def test_no_team_means_anywhere(seeded):
    """A menu asks 'can they do this at all'. A list endpoint filters rows
    itself afterwards."""
    uid = seeded
    assert _has(uid(HARIKA), "pools.approve")          # yes: for backend
    assert not _has(uid(AZHAR), "pools.approve")       # no: nowhere


def test_unknown_permission_fails_closed(seeded):
    """A typo in a route decorator must lock the route, not 500 it."""
    uid = seeded
    assert not _has(uid(AYUSH), "pools.aprove", "backend")


def test_no_user_fails_closed(seeded):
    assert not _has(None, "pools.view")
    assert not _has(0, "pools.view")
    assert not _has(999999, "pools.view")


def test_a_deactivated_account_holds_nothing(seeded):
    """Off is off — not partially on."""
    from db.models import AppUser

    uid = seeded
    harika = uid(HARIKA)
    assert _has(harika, "pools.approve", "backend")
    with session_scope() as s:
        s.get(AppUser, harika).is_active = False
    assert not _has(harika, "pools.approve", "backend")
    assert _has(uid(SHOBIT), "pools.approve", "backend")   # unaffected


def test_permitted_teams_reports_the_scope(seeded):
    from app import rbac

    uid = seeded
    assert rbac.permitted_teams(uid(HARIKA), "pools.approve") == {"backend"}
    assert rbac.permitted_teams(uid(SHOBIT), "pools.approve") == {"*"}
    assert rbac.permitted_teams(uid(JAVALI), "pools.approve") == set()


def test_describe_user_reports_roles_and_permissions(seeded):
    from app import rbac

    uid = seeded
    info = rbac.describe_user(uid(HARIKA))
    assert info["email"] == HARIKA
    assert info["roles"] == [
        {
            "role": "pool_checker",
            "role_name": "Question Checker",
            "team": "backend",
            "team_name": "Backend Engineering",
        }
    ]
    assert info["permissions"]["pools.approve"] == ["backend"]
    assert "pools.edit" not in info["permissions"]


def test_a_person_holds_the_union_of_several_roles(seeded):
    """One human is routinely an Author for their own team and a Checker for
    another."""
    from sqlalchemy import select

    from db.models import AppRole, AppTeam, AppUserRole

    uid = seeded
    azhar = uid(AZHAR)
    assert not _has(azhar, "pools.approve", "qa")
    with session_scope() as s:
        role_id = s.execute(
            select(AppRole.id).where(AppRole.key == "pool_checker")
        ).scalar_one()
        team_id = s.execute(select(AppTeam.id).where(AppTeam.key == "qa")).scalar_one()
        s.add(AppUserRole(user_id=azhar, role_id=role_id, team_id=team_id))

    assert _has(azhar, "pools.approve", "qa")        # gained
    assert _has(azhar, "pools.edit", "backend")      # kept
    assert not _has(azhar, "pools.approve", "backend")  # still not on his own team


# ── the cookie ───────────────────────────────────────────────────────────


def test_cookie_carries_the_user_id(monkeypatch):
    from app import auth

    monkeypatch.setenv("ADMIN_SECRET_KEY", "test-secret-for-rbac")
    token = auth.issue_cookie("harika@example.com", user_id=42)
    assert auth.read_cookie(token) == "harika@example.com"

    class _Req:
        cookies = {auth.COOKIE_NAME: token}

    assert auth.get_current_user_id(_Req()) == 42


def test_a_legacy_cookie_has_no_identity_to_authorise(monkeypatch):
    """The old shared login stays a way IN, not a set of rights: it carries no
    user id, so every permission check fails closed."""
    from app import auth

    monkeypatch.setenv("ADMIN_SECRET_KEY", "test-secret-for-rbac")
    token = auth.issue_cookie("admin")          # no user_id — as it always was

    class _Req:
        cookies = {auth.COOKIE_NAME: token}

    assert auth.get_current_user(_Req()) == "admin"     # still signed in
    assert auth.get_current_user_id(_Req()) is None     # but authorises nothing


# ── the HTTP layer ───────────────────────────────────────────────────────


def sign_in_as(client, email: str) -> None:
    """Give `client` the session cookie a Microsoft sign-in ends with: the
    person's email plus their `app_users.id`, which every check reads."""
    from app import auth, rbac

    user = rbac.user_by_email(email)
    assert user is not None, email
    client.cookies.set(auth.COOKIE_NAME, auth.issue_cookie(user["email"], user_id=user["id"]))


@pytest.fixture()
def client(seeded, monkeypatch):
    """A TestClient over the admin app."""
    from fastapi.testclient import TestClient

    monkeypatch.setenv("ADMIN_SECRET_KEY", "test-secret-for-rbac")
    from app.main import app

    return TestClient(app), seeded


def test_the_shared_password_login_is_an_admin(client, monkeypatch):
    """The username/password login signs in as a real account holding `admin`
    on every team, not as an identity-less session, and signing in again
    reuses that account rather than creating another."""
    monkeypatch.setenv("ADMIN_USERNAME", "admin")
    monkeypatch.setenv("ADMIN_PASSWORD_HASH", "")          # dev password
    c, _ = client

    assert c.post("/api/login", json={"username": "admin", "password": "centific123"}).status_code == 200
    me = c.get("/api/me/permissions").json()
    assert me["legacy"] is False
    assert [(r["role"], r["team"]) for r in me["roles"]] == [("admin", "*")]
    assert me["permissions"]["pools.approve"] == ["*"]
    assert me["permissions"]["admin.users"] == ["*"]
    first = me["id"]

    c.cookies.clear()
    assert c.post("/api/login", json={"username": "admin", "password": "centific123"}).status_code == 200
    assert c.get("/api/me/permissions").json()["id"] == first

    c.cookies.clear()
    assert c.post("/api/login", json={"username": "admin", "password": "nope"}).status_code == 401


def test_a_seeded_email_cannot_sign_in_with_the_admin_password(client, monkeypatch):
    """The seeded people have no passwords; they sign in with Microsoft. The
    shared password must not double as everyone's password."""
    monkeypatch.setenv("ADMIN_PASSWORD_HASH", "")
    monkeypatch.setenv("DEV_LOGIN_ENABLED", "1")            # the old switch does nothing
    c, _ = client
    r = c.post("/api/login", json={"username": HARIKA, "password": "centific123"})
    assert r.status_code == 401


def test_there_is_no_passwordless_dev_sign_in(seeded, monkeypatch):
    """The seeded-account chooser let anyone become any person, admins
    included, with no password. It is removed, not switched off: even with the
    old switch set, the routes do not exist and the login page is not offered
    the chooser."""
    from fastapi.testclient import TestClient

    monkeypatch.setenv("DEV_LOGIN_ENABLED", "1")
    from app.main import app

    c = TestClient(app)
    assert c.get("/api/dev/accounts").status_code == 404
    assert c.post("/api/dev/login", json={"email": HARIKA}).status_code in (404, 405)
    assert "dev" not in c.get("/api/auth/methods").json()


def test_permissions_endpoint_needs_a_session(client):
    c, _ = client
    assert c.get("/api/me/permissions").status_code == 401


def test_require_dependency_allows_and_refuses(client):
    """The dependency routes actually use: 401 signed out, 403 for the wrong
    person, 200 for the right one — including the team-scoped case."""
    from fastapi import Depends, FastAPI
    from fastapi.testclient import TestClient

    from app import rbac

    probe = FastAPI()

    @probe.get("/can-approve/{team}")
    def can_approve(uid: int = Depends(rbac.require("pools.approve", "team"))):
        return {"user_id": uid}

    @probe.get("/can-edit")
    def can_edit(uid: int = Depends(rbac.require("pools.edit"))):
        return {"user_id": uid}

    c, uid = client
    pc = TestClient(probe)

    assert pc.get("/can-edit").status_code == 401           # signed out

    sign_in_as(pc, HARIKA)
    assert pc.get("/can-approve/backend").status_code == 200   # her team
    assert pc.get("/can-approve/qa").status_code == 403        # not her team
    assert pc.get("/can-edit").status_code == 403              # checkers don't edit

    sign_in_as(pc, JAVALI)                                    # HR
    assert pc.get("/can-approve/backend").status_code == 403
    assert pc.get("/can-edit").status_code == 403


def test_the_legacy_shared_login_authorises_nothing(client):
    """It stays a way in, so old routes keep working — but it holds no
    permissions, because it is not a person."""
    from app import auth

    c, _ = client
    c.cookies.set(auth.COOKIE_NAME, auth.issue_cookie("admin"))
    me = c.get("/api/me/permissions")
    assert me.status_code == 200
    assert me.json()["legacy"] is True
    assert me.json()["permissions"] == {}
