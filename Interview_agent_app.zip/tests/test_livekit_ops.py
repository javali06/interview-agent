"""Operating LiveKit interviews: metrics from replicas Prometheus can't reach,
and knowing whether a server recording actually landed."""
from __future__ import annotations

import asyncio

import pytest
from prometheus_client.parser import text_string_to_metric_families


@pytest.fixture
def redis():
    import fakeredis.aioredis as fr
    from app import coordination as coord
    coord.set_redis(fr.FakeRedis(decode_responses=True))
    yield
    coord.set_redis(None)


_REPLICA_TEXT = """# HELP interview_handoffs_total Hand-offs.
# TYPE interview_handoffs_total counter
interview_handoffs_total{{reason="drain_ws"}} {n}
# HELP interview_loop_lag_ms Lag.
# TYPE interview_loop_lag_ms gauge
interview_loop_lag_ms {lag}
"""


# ── pool / worker metrics through Redis ───────────────────────────────────────
@pytest.mark.asyncio
async def test_pushed_metrics_merge_into_one_valid_document_labelled_by_replica(redis):
    from app.coordination import metrics_push
    await metrics_push.publish("pool-a", "session-pool", _REPLICA_TEXT.format(n=2, lag=5))
    await metrics_push.publish("worker-1", "worker", _REPLICA_TEXT.format(n=0, lag=9))
    body = metrics_push.merge(await metrics_push.collect()).decode()

    # Each family once (concatenating the texts would repeat HELP/TYPE, which
    # Prometheus rejects), and every sample says which replica it came from.
    assert body.count("# TYPE interview_loop_lag_ms gauge") == 1
    fams = {f.name: f for f in text_string_to_metric_families(body)}
    lag = {s.labels["instance"]: (s.labels["tier"], s.value) for s in fams["interview_loop_lag_ms"].samples}
    assert lag == {"pool-a": ("session-pool", 5.0), "worker-1": ("worker", 9.0)}
    handoffs = [s for s in fams["interview_handoffs"].samples if s.name == "interview_handoffs_total"]
    assert {(s.labels["instance"], s.labels["reason"], s.value) for s in handoffs} == {
        ("pool-a", "drain_ws", 2.0), ("worker-1", "drain_ws", 0.0)}


@pytest.mark.asyncio
async def test_a_replica_that_stops_publishing_drops_out(redis, monkeypatch):
    from app.coordination import client, metrics_push
    monkeypatch.setenv("METRICS_PUSH_INTERVAL_S", "1")
    await metrics_push.publish("pool-a", "session-pool", _REPLICA_TEXT.format(n=1, lag=1))
    ttl = await client.get_redis().ttl("metrics:pushed:pool-a")
    assert 0 < ttl <= metrics_push.ttl_s(), "an expiring key, so a dead replica's last values don't freeze"


@pytest.mark.asyncio
async def test_one_malformed_replica_does_not_blank_the_rest(redis):
    from app.coordination import metrics_push
    await metrics_push.publish("pool-a", "session-pool", _REPLICA_TEXT.format(n=1, lag=1))
    await metrics_push.publish("pool-b", "session-pool", "this is { not metrics")
    body = metrics_push.merge(await metrics_push.collect()).decode()
    assert 'instance="pool-a"' in body and "pool-b" not in body


@pytest.mark.asyncio
async def test_publish_loop_never_raises_and_stops(redis, monkeypatch):
    from app.coordination import metrics_push
    monkeypatch.setenv("METRICS_PUSH_INTERVAL_S", "0.01")
    calls = []

    async def render():
        calls.append(1)
        if len(calls) == 1:
            raise RuntimeError("a bad scrape must not stop the loop")
        return _REPLICA_TEXT.format(n=1, lag=1).encode()
    stop = asyncio.Event()
    task = asyncio.create_task(metrics_push.publish_loop("pool-a", "session-pool", render, stop))
    await asyncio.sleep(0.1)
    stop.set()
    await asyncio.wait_for(task, 1)
    assert len(calls) >= 2 and "pool-a" in await metrics_push.collect()


class _Req:
    def __init__(self, auth=""):
        self.headers = {"authorization": auth} if auth else {}


@pytest.mark.asyncio
async def test_gateway_serves_pushed_metrics_with_the_placement_queue(redis, monkeypatch):
    pytest.importorskip("deploy.gateway_app")
    from deploy import gateway_app
    from app.coordination import client, metrics_push
    from app.session_tier import placement
    monkeypatch.delenv("METRICS_TOKEN", raising=False)
    await metrics_push.publish("pool-a", "session-pool", _REPLICA_TEXT.format(n=1, lag=1))
    await client.get_redis().rpush(placement.SHARED_QUEUE, "{}", "{}")
    body = (await gateway_app._pushed_metrics(_Req())).body.decode()
    fams = {f.name: f for f in text_string_to_metric_families(body)}
    assert fams["interview_placement_queue_depth"].samples[0].value == 2
    assert fams["interview_pushed_replicas"].samples[0].value == 1
    assert "interview_loop_lag_ms" in fams


@pytest.mark.asyncio
async def test_gateway_pushed_metrics_require_the_token_when_one_is_set(redis, monkeypatch):
    pytest.importorskip("deploy.gateway_app")
    from deploy import gateway_app
    monkeypatch.setenv("METRICS_TOKEN", "s3cret")
    assert (await gateway_app._pushed_metrics(_Req())).status_code == 401
    assert (await gateway_app._pushed_metrics(_Req("Bearer nope"))).status_code == 401
    assert (await gateway_app._pushed_metrics(_Req("Bearer s3cret"))).status_code == 200


# ── server-recording state ───────────────────────────────────────────────────
def _statuses(monkeypatch, names, manifests):
    from engine.orchestrator.livekit import egress
    monkeypatch.setattr(egress, "read_manifest", lambda blob: manifests.get(blob))
    return egress.part_statuses(names)


def test_part_states_follow_the_manifest_until_the_file_lands(monkeypatch):
    a = "tok/recording/livekit-audio-100.ogg"
    b = "tok/recording/livekit-audio-200.ogg"
    c = "tok/recording/livekit-audio-300.ogg"
    names = [a, a + ".json", b + ".json", c + ".json", "tok/recording/camera.webm"]
    got = _statuses(monkeypatch, names, {
        a: {"status": "processing"},            # stale: the file is there → ready
        b: {"status": "processing"},            # no file yet → still uploading
        c: {"status": "failed", "error": "egress aborted"},
    })
    assert [(p["part"], p["status"]) for p in got] == [(0, "ready"), (None, "processing"), (None, "failed")]
    assert got[2]["error"] == "egress aborted"


def test_a_saved_recording_this_server_cannot_see_is_unavailable_not_failed(monkeypatch):
    # LiveKit saved it (e.g. to real Azure while a local stack's blob store is
    # the disk fallback): the recording didn't fail, it just isn't here.
    a = "tok/recording/livekit-audio-100.ogg"
    got = _statuses(monkeypatch, [a + ".json"], {a: {"status": "ready", "duration_s": 12}})
    assert got[0] == {"part": None, "status": "unavailable", "duration_s": 12, "error": ""}


def test_a_part_from_before_manifests_existed_is_ready(monkeypatch):
    got = _statuses(monkeypatch, ["tok/recording/livekit-audio.ogg"], {})
    assert got == [{"part": 0, "status": "ready", "duration_s": None, "error": ""}]


# ── recording_finalize job ───────────────────────────────────────────────────
@pytest.fixture
def finalize(monkeypatch):
    api = pytest.importorskip("livekit.api")
    from engine.orchestrator.livekit import egress
    for k, v in {"LIVEKIT_URL": "wss://x", "LIVEKIT_API_KEY": "k", "LIVEKIT_API_SECRET": "s"}.items():
        monkeypatch.setenv(k, v)
    written = {}
    monkeypatch.setattr(egress, "write_manifest",
                        lambda blob, status, **f: written.update(blob=blob, status=status, **f))
    infos = []

    async def info(lk, egress_id):
        return infos.pop(0) if len(infos) > 1 else infos[0]
    monkeypatch.setattr(egress, "egress_info", info)
    return api, infos, written


@pytest.mark.asyncio
async def test_finalize_records_a_completed_recording(finalize, monkeypatch):
    from app.jobs import jobs
    api, infos, written = finalize
    infos.append(api.EgressInfo(egress_id="EG1", status=api.EgressStatus.EGRESS_COMPLETE,
                                file_results=[api.FileInfo(duration=263_400_000_000, size=1_048_576)]))
    out = await jobs.dispatch(jobs.RECORDING_FINALIZE,
                              {"token": "tok", "egress_id": "EG1", "blob": "tok/recording/livekit-audio-1.ogg"})
    assert out["status"] == "ready"
    assert written == {"blob": "tok/recording/livekit-audio-1.ogg", "status": "ready",
                       "egress_id": "EG1", "duration_s": 263.4, "size_bytes": 1_048_576}


@pytest.mark.asyncio
async def test_finalize_records_why_a_recording_failed(finalize):
    from app.jobs import jobs
    api, infos, written = finalize
    infos.append(api.EgressInfo(egress_id="EG1", status=api.EgressStatus.EGRESS_FAILED,
                                error="upload to azure failed"))
    out = await jobs.dispatch(jobs.RECORDING_FINALIZE, {"token": "tok", "egress_id": "EG1", "blob": "b.ogg"})
    assert out["status"] == "failed" and written["error"] == "upload to azure failed"


@pytest.mark.asyncio
async def test_finalize_retries_while_the_upload_is_still_running(finalize, monkeypatch):
    from app.jobs import jobs
    api, infos, written = finalize
    monkeypatch.setenv("RECORDING_FINALIZE_WAIT_S", "0")
    infos.append(api.EgressInfo(egress_id="EG1", status=api.EgressStatus.EGRESS_ENDING))
    with pytest.raises(jobs.EgressStillRunning):
        await jobs.dispatch(jobs.RECORDING_FINALIZE, {"token": "tok", "egress_id": "EG1", "blob": "b.ogg"})
    assert written == {}, "nothing is decided while LiveKit is still uploading"


@pytest.mark.asyncio
async def test_finalize_waits_for_the_upload_then_records_it(finalize, monkeypatch):
    from app.jobs import jobs
    api, infos, written = finalize
    sleeps = []

    async def no_sleep(s):
        sleeps.append(s)
    monkeypatch.setattr(jobs.asyncio, "sleep", no_sleep)
    infos.extend([api.EgressInfo(status=api.EgressStatus.EGRESS_ENDING),
                  api.EgressInfo(status=api.EgressStatus.EGRESS_COMPLETE,
                                 file_results=[api.FileInfo(duration=1_000_000_000, size=10)])])
    out = await jobs.dispatch(jobs.RECORDING_FINALIZE, {"token": "tok", "egress_id": "EG1", "blob": "b.ogg"})
    assert out["status"] == "ready" and sleeps == [2.0]


# ── the dashboard's metrics exist under the names it queries ─────────────────
def test_dashboard_queries_only_metrics_that_exist():
    import json
    import re
    from pathlib import Path
    from engine.brain.observability import prom
    exported = set()
    for fam in prom.REGISTRY.collect():
        # A labelled metric has no samples until first used: derive its names.
        exported |= {s.name for s in fam.samples} | {fam.name}
        exported |= {fam.name + sfx for sfx in {"counter": ("_total",),
                                                 "histogram": ("_bucket", "_sum", "_count")}.get(fam.type, ())}
    exported |= {"interview_placement_queue_depth", "interview_pushed_replicas"}  # gateway's own
    dash = json.loads(Path("deploy/observability/dashboards/interview.json").read_text())
    row = [p for p in dash["panels"] if p["id"] in (18, 19, 20, 21, 22)]
    assert len(row) == 5
    for p in row:
        for t in p["targets"]:
            for name in re.findall(r"\binterview_[a-z_]+", t["expr"]):
                assert name in exported, f"panel {p['id']} queries {name}, which nothing exports"


# ── avatars over LiveKit ─────────────────────────────────────────────────────
@pytest.mark.asyncio
async def test_audio_end_carries_the_utterance_length_when_known():
    # On LiveKit the page hears a live track and can't count the bytes: the
    # avatar's lip timing needs the length from the server.
    from engine.orchestrator.web.broadcaster import WebBroadcaster
    b = WebBroadcaster(host="(embedded)", port=0, sample_rate_hz=16000)
    sent = []
    b._enqueue_out = sent.append
    b.emit_audio_end(sub_id="slow-1-1", duration_ms=2837)
    b.emit_audio_end(sub_id="slow-1-2")
    assert sent[0] == ("json", {"type": "audio_end", "sub_id": "slow-1-1", "duration_ms": 2837})
    assert sent[1] == ("json", {"type": "audio_end", "sub_id": "slow-1-2"}), "unknown → absent, not 0"


def test_the_lobby_probe_never_reaches_a_shard(monkeypatch):
    # The lobby times a WebSocket opening. Proxied like a real connection, a
    # shard claimed the interview from the lobby — holding a Speech slot and
    # leaving a WebSocket session that made Start skip LiveKit.
    pytest.importorskip("deploy.gateway_app")
    from fastapi.testclient import TestClient
    from deploy import gateway_app
    from app.gateway import ws_proxy
    proxied = []

    async def fake_proxy(ws, *a, **k):
        proxied.append(a)
        await ws.accept()
        await ws.close()
    monkeypatch.setattr(ws_proxy, "proxy", fake_proxy)
    c = TestClient(gateway_app.app)  # no lifespan: nothing here needs it
    with c.websocket_connect("/ws/candidate/probe?probe=1"):
        pass
    assert proxied == []
    with c.websocket_connect("/ws/candidate/abc?token=tok&client=tab"):
        pass
    assert len(proxied) == 1, "a real connection is still proxied"
