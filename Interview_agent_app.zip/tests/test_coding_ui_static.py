"""Static UI tests for the coding panel.

Without Node/Playwright we can't drive a real browser, but we can verify:

  1. Every interactive [data-action] button in the HTML has at least one
     JS handler wired (no orphan buttons).
  2. Every JS sendWS / event-handler reference points to a real DOM
     element (no dangling selectors).
  3. No CSS rule applies `display: none` to the controls / Run / Submit /
     Hint buttons in the default state.
  4. The flex column layout pins the controls / status bar with
     `flex: 0 0 auto` so they're guaranteed visible.
  5. The minimum total height of the always-visible rows leaves room for
     the editor in a 100vh viewport.
  6. The Centific brand header is present.

Run with: `.venv\\Scripts\\python.exe -m pytest tests/test_coding_ui_static.py -v`
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest
from bs4 import BeautifulSoup


REPO = Path(__file__).resolve().parent.parent
HTML = REPO / "ui" / "candidate" / "coding" / "coding_panel.html"
CSS = REPO / "ui" / "candidate" / "coding" / "coding_panel.css"
JS = REPO / "ui" / "candidate" / "coding" / "coding_panel.js"
EDITOR_JS = REPO / "ui" / "candidate" / "coding" / "editor_wrapper.js"


@pytest.fixture
def soup():
    return BeautifulSoup(HTML.read_text(encoding="utf-8"), "html.parser")


@pytest.fixture
def js_src():
    return JS.read_text(encoding="utf-8")


@pytest.fixture
def css_src():
    return CSS.read_text(encoding="utf-8")


# ── presence of expected elements ────────────────────────────────────


EXPECTED_BUTTONS = {
    "force-talk": "Talk to AI",
    "toggle-minimize": "Hide / show",
    "hint": "Hint",
    "run": "Run",
    "submit": "Submit",
}

EXPECTED_BINDS = {
    "title",
    "prompt",
    "time-budget",
    "test-count",
    "runtime",
    "stdout",
    "stderr",
    "test-results",
    "status",
    "toggle-label",
}


def test_all_buttons_present(soup):
    for action in EXPECTED_BUTTONS:
        btn = soup.find("button", attrs={"data-action": action})
        assert btn is not None, (
            f"Missing button [data-action={action!r}] in coding_panel.html"
        )


def test_all_binds_present(soup):
    for bind in EXPECTED_BINDS:
        el = soup.find(attrs={"data-bind": bind})
        assert el is not None, f"Missing element [data-bind={bind!r}]"


def test_editor_mount_present(soup):
    el = soup.find(attrs={"data-mount": "editor"})
    assert el is not None, "Missing editor mount [data-mount='editor']"


# ── every button has a JS handler ─────────────────────────────────────


@pytest.mark.parametrize("action", list(EXPECTED_BUTTONS))
def test_button_has_js_handler(js_src, action):
    # Either the panel module references the element via els.{action}Btn
    # OR via [data-action="{action}"] querySelector. Both are valid.
    # Acceptable variants:
    #   els.runBtn / els.submitBtn / els.hintBtn / els.toggleBtn / els.forceTalkBtn
    #   root.querySelector('[data-action="run"]')  etc.
    camel = "".join(
        part.capitalize() if i else part
        for i, part in enumerate(action.replace("-", "_").split("_"))
    )
    candidates = [
        f"data-action=\"{action}\"",
        f"els.{camel}Btn",
        f"els.{camel}",  # toggleBtn / forceTalkBtn variants
    ]
    assert any(c in js_src for c in candidates), (
        f"No JS reference found for [data-action={action!r}]. "
        f"Tried selectors: {candidates}"
    )


# ── visibility / not hidden by default ────────────────────────────────


def _extract_rules(css_src: str) -> list[tuple[str, str]]:
    # Strip /* ... */ comments, then split on `}` and capture selector +
    # body. Returns [(selector, body), ...].
    no_comments = re.sub(r"/\*.*?\*/", "", css_src, flags=re.DOTALL)
    rules: list[tuple[str, str]] = []
    for chunk in no_comments.split("}"):
        if "{" not in chunk:
            continue
        selector, body = chunk.split("{", 1)
        rules.append((selector.strip(), body.strip()))
    return rules


CONTROLS_TARGETS = {
    ".coding-controls",
    ".coding-btn-primary",
    ".coding-btn-secondary",
    ".coding-btn-submit",
    "[data-action=\"run\"]",
    "[data-action=\"submit\"]",
    "[data-action=\"hint\"]",
}

# State-scoped selectors are OK — `[data-minimized="1"]` intentionally
# hides the controls, `[data-coding-state="submitted"]` greys them.
STATE_SCOPE_TOKENS = ("[data-minimized", "[data-coding-state", ":hover", ":disabled")


def test_no_default_display_none_on_controls(css_src):
    bad: list[tuple[str, str]] = []
    for selector, body in _extract_rules(css_src):
        if "display: none" not in body and "display:none" not in body:
            continue
        # Selector may be a comma-joined list — split and check each branch.
        for branch in [b.strip() for b in selector.split(",")]:
            if not any(t in branch for t in CONTROLS_TARGETS):
                continue
            if any(scope in branch for scope in STATE_SCOPE_TOKENS):
                continue  # state-scoped hide is intentional
            bad.append((branch, body[:80]))
    assert not bad, (
        "Found unconditional display:none rule(s) on controls: "
        + repr(bad)
    )


def test_controls_have_flex_zero_zero_auto(css_src):
    # Confirm the flex shorthand on the always-visible rows (controls,
    # status, info, hint banner) sits in the `flex: 0 0 auto` group so
    # they can never be squeezed off-screen by the editor or output.
    # Should appear in a single combined selector at the top of the file.
    m = re.search(
        r"\.coding-portal-header,\s*\.coding-question,\s*\.coding-controls,"
        r"\s*\.coding-info-banner,\s*\.coding-status-bar,"
        r"\s*\.coding-hint-display\s*\{[^}]*flex\s*:\s*0\s+0\s+auto",
        css_src,
        re.DOTALL,
    )
    assert m is not None, (
        "Expected a combined selector pinning .coding-controls, "
        ".coding-status-bar, etc. to flex: 0 0 auto — without this the "
        "Run/Submit row can be pushed off-screen by a long output."
    )


def test_panel_is_flex_column(css_src):
    # The flex-column layout is the prerequisite for the always-visible
    # guarantee above. If someone reverts to grid, this regresses.
    m = re.search(
        r"\.coding-panel\s*\{[^}]*display\s*:\s*flex[^}]*"
        r"flex-direction\s*:\s*column",
        css_src,
        re.DOTALL,
    )
    assert m is not None, ".coding-panel must use display:flex / column"


def test_body_is_two_column_grid(css_src):
    # 2-column layout: 30% sidebar + 70% main (editor/output/controls).
    m = re.search(
        r"\.coding-body\s*\{[^}]*display\s*:\s*grid"
        r"[^}]*grid-template-columns",
        css_src,
        re.DOTALL,
    )
    assert m is not None, (
        ".coding-body must be a 2-column grid (sidebar 30% + main 70%)"
    )


def test_main_is_two_column_grid(css_src):
    # Right area: editor (left) + output (right), side-by-side. Original
    # 70/30 was nudged to 65/35 so test result rows have more horizontal
    # breathing room without dominating the editor.
    m = re.search(
        r"\.coding-main\s*\{[^}]*display\s*:\s*grid"
        r"[^}]*grid-template-columns\s*:\s*(\d+)fr\s+(\d+)fr",
        css_src,
        re.DOTALL,
    )
    assert m is not None, ".coding-main must use grid-template-columns with two fr units"
    a, b = int(m.group(1)), int(m.group(2))
    total = a + b
    assert 0.55 <= a / total <= 0.75, (
        f"Editor column should be 55-75% of right area (got {a}/{total} ≈ {a/total:.0%})"
    )
    assert 0.25 <= b / total <= 0.45, (
        f"Output column should be 25-45% of right area (got {b}/{total} ≈ {b/total:.0%})"
    )
    # And the grid-areas should pin controls/status to span both columns.
    areas = re.search(
        r"\.coding-main\s*\{[^}]*grid-template-areas[^}]*"
        r"\"editor output\"[^}]*"
        r"\"controls controls\"[^}]*"
        r"\"status\s+status\"",
        css_src,
        re.DOTALL,
    )
    assert areas is not None, (
        "Expected grid-template-areas: 'editor output' / 'controls controls' "
        "/ 'status status' so the buttons + status bar span full width."
    )


def test_editor_and_output_both_scrollable(css_src):
    # Editor uses Monaco's internal scroll (overflow: hidden on container);
    # output has overflow-y: auto.
    editor_rule = re.search(
        r"\.coding-main \.coding-editor-shell\s*\{[^}]*overflow\s*:\s*hidden",
        css_src,
        re.DOTALL,
    )
    output_rule = re.search(
        r"\.coding-main \.coding-output\s*\{[^}]*overflow-y\s*:\s*auto",
        css_src,
        re.DOTALL,
    )
    assert editor_rule is not None, "Editor container needs overflow: hidden"
    assert output_rule is not None, "Output pane needs overflow-y: auto"


def test_controls_pinned_sticky_bottom(css_src):
    # Run/Submit/Hint must NEVER be covered or pushed off-screen. They're
    # pinned to the bottom of .coding-main with position: sticky + a
    # background so anything that scrolls beneath them stays underneath.
    m = re.search(
        r"\.coding-main\s+\.coding-controls\s*\{[^}]*"
        r"position\s*:\s*sticky[^}]*bottom\s*:\s*0",
        css_src,
        re.DOTALL,
    )
    assert m is not None, (
        ".coding-controls inside .coding-main must be position: sticky; "
        "bottom: 0 so the Run / Submit / Hint buttons are always visible."
    )


def test_output_has_minimum_height(css_src):
    # Output pane must have a non-trivial min-height so test results don't
    # collapse to a single visible line on small viewports.
    m = re.search(
        r"\.coding-main\s+\.coding-output\s*\{[^}]*"
        r"min-height\s*:\s*(\d+)px",
        css_src,
        re.DOTALL,
    )
    assert m is not None, ".coding-output should declare a min-height"
    px = int(m.group(1))
    assert px >= 160, (
        f".coding-output min-height too small ({px}px) — test results "
        "won't have room to render"
    )


def test_sidebar_is_scrollable(css_src):
    # Long prompts shouldn't push the meta or info banner off-screen.
    m = re.search(
        r"\.coding-sidebar\s*\{[^}]*overflow-y\s*:\s*auto",
        css_src,
        re.DOTALL,
    )
    assert m is not None, "Sidebar should have overflow-y: auto for long content"


# ── anti-cheat wiring ────────────────────────────────────────────────


def test_paste_blocked_at_dom_level(js_src):
    # editor_wrapper.js wires capture-phase paste blocking. Confirm the
    # event handler calls preventDefault.
    src = EDITOR_JS.read_text(encoding="utf-8")
    assert "addEventListener(\"paste\"" in src, (
        "editor_wrapper.js should attach a paste listener"
    )
    assert "preventDefault" in src
    # Capture phase (third arg true) is critical — without it Monaco's
    # internal handler runs first and the paste lands.
    assert re.search(
        r"addEventListener\(\"paste\",\s*\w+,\s*true\)", src,
    ), "paste handler must use the capture phase (3rd arg true)"


def test_context_menu_blocked_in_panel(js_src):
    assert "addEventListener(\"contextmenu\"" in js_src, (
        "coding_panel.js should attach a contextmenu blocker"
    )


def test_visibility_change_listener(js_src):
    assert "addEventListener(\"visibilitychange\"" in js_src


def test_anti_cheat_helper_present(js_src):
    # The toast + persistent badge are wrapped in an `antiCheat` IIFE.
    assert "antiCheat.recordViolation" in js_src
    assert "coding-anti-cheat-badge" in js_src
    assert "coding-anti-cheat-toast" in js_src


# ── Centific brand on the coding screen ───────────────────────────────


def test_centific_brand_present(soup):
    header = soup.find(class_="coding-portal-header")
    assert header is not None, (
        "Coding panel must have a .coding-portal-header for Centific branding"
    )
    brand_mark = header.find(class_="brand-mark")
    brand_name = header.find(class_="brand-name")
    assert brand_mark is not None and "C" in brand_mark.text
    assert brand_name is not None and "Centific" in brand_name.text
    subtitle = header.find(class_="coding-portal-subtitle")
    assert subtitle is not None and "Interview" in subtitle.text


def test_portal_header_styled(css_src):
    m = re.search(r"\.coding-portal-header\s*\{", css_src)
    assert m is not None, ".coding-portal-header needs CSS styling"
    # Confirm minimized state hides it (matches the 300x64 widget)
    m2 = re.search(
        r"\.coding-host\[data-minimized=\"1\"\]\s+\.coding-portal-header",
        css_src,
    )
    assert m2 is not None, (
        "Minimized state should hide the portal header so the widget "
        "stays compact"
    )


# ── viewport math: right column has room for editor + output ──────


def test_right_column_chrome_under_viewport(soup):
    # In the 2-column layout, the editor lives ONLY in the right column.
    # Right column's pinned chrome = controls (~58px) + status (~38px)
    # + 3 grid gaps (12 each = 36) = ~132px. Plus portal-header (~46px)
    # and panel padding (32px) above the body. ~210px chrome → editor
    # gets ~570px on a 768px viewport. Comfortable.
    right_col_pinned = 58 + 38 + 36
    panel_chrome = 46 + 32
    total_pinned = right_col_pinned + panel_chrome
    assert total_pinned <= 260, (
        f"Right-column chrome consumes ~{total_pinned}px — leaves the "
        "editor + output too little space on small viewports."
    )
    # Also confirm the 2-column structure exists in the HTML — sanity
    # check that the test is exercising the right layout.
    assert soup.find(class_="coding-sidebar") is not None
    assert soup.find(class_="coding-main") is not None
