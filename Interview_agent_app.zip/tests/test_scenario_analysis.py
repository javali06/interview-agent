"""Unit tests for the Visual Scenario Analysis phase (schema + upload/serve rules).

Covers: schema load/dump round-trip, every validation rule (item count,
question text, coverage tags, media kind/mime agreement, max_followups range,
mutual exclusivity with coding/written_response/adaptive, text-modality
rejection), the video asset upload rule, the default-ordering builder, and the
eval sectioner's phase-mode labeling. No LLM calls, no network — pure schema
and pure-function tests, like test_adaptive_difficulty.py. Written to run
either under pytest OR directly as a script.

Runtime dispatch (showing the media, asking the rephrased question, scoring)
is a LATER layer and is intentionally NOT covered here — see the module
docstrings on schema.ScenarioItem / cadence_service.append_scenario_analysis_phase.
"""
from __future__ import annotations

import pytest
from pydantic import ValidationError

from engine.brain.cadence import question_types as qt
from engine.brain.cadence.schema import (
    CadencePlan,
    PhaseDef,
    ScenarioItem,
    ScenarioMedia,
)
from app.cadence_service import (
    _insert_idx_before_coding_or_wrap_up,
    append_scenario_analysis_phase,
)
from features.eval.sectioner import _cadence_phase_modes


def _item(iid: str = "diagram_1", kind: str = "image", ref: str = "arch1.png",
          mime: str = "image/png", tags=("load balancer",), followups: int = 2) -> dict:
    return {
        "id": iid,
        "media": {"kind": kind, "ref": ref, "filename": ref, "mime_type": mime},
        "question": "What is missing here?",
        "coverage_tags": list(tags),
        "max_followups": followups,
    }


def _plan_with(items: list[dict], timed: bool = True, extra_phase: dict | None = None) -> dict:
    phases = [
        {"id": "warm_up", "duration_s": 60, "intent": "warm up",
         "question_mode": "generic", "generic_prompts": ["hi"]},
    ]
    if extra_phase:
        phases.append(extra_phase)
    phases.append({"id": "scenario_analysis", "duration_s": 300, "intent": "scenario",
                    "question_mode": "generic", "scenario_items": items})
    phases.append({"id": "wrap_up", "duration_s": 60, "intent": "wrap up",
                   "question_mode": "generic", "generic_prompts": ["bye"]})
    total = sum(p["duration_s"] for p in phases)
    return {"total_duration_s": total, "phases": phases, "timed": timed}


# ── schema round-trip ────────────────────────────────────────────────────────


def test_scenario_phase_loads_and_round_trips():
    data = _plan_with([_item("diagram_1"), _item("clip_1", kind="video", ref="demo.mp4", mime="video/mp4")])
    plan = CadencePlan.model_validate(data)
    phase = plan.get_phase("scenario_analysis")
    assert phase.is_scenario_analysis
    assert [i.id for i in phase.scenario_items] == ["diagram_1", "clip_1"]
    # generic_prompts was supplied (none here) -> auto-filled by the validator
    assert phase.generic_prompts

    dumped = plan.model_dump(mode="json")
    reloaded = CadencePlan.model_validate(dumped)
    assert reloaded == plan


def test_scenario_phase_keeps_admin_supplied_prompts():
    data = _plan_with([_item()])
    data["phases"][1]["generic_prompts"] = ["Show them the diagram and ask them to react."]
    plan = CadencePlan.model_validate(data)
    assert plan.get_phase("scenario_analysis").generic_prompts == [
        "Show them the diagram and ask them to react."
    ]


# ── validation: item-level ───────────────────────────────────────────────────


def test_empty_coverage_tags_rejected():
    with pytest.raises(ValidationError):
        ScenarioItem(
            id="a",
            media=ScenarioMedia(kind="image", ref="x.png", filename="x.png", mime_type="image/png"),
            question="q",
            coverage_tags=["  ", ""],
        )


def test_coverage_tags_deduped_and_trimmed():
    item = ScenarioItem(
        id="a",
        media=ScenarioMedia(kind="image", ref="x.png", filename="x.png", mime_type="image/png"),
        question="q",
        coverage_tags=[" caching ", "caching", "redundancy"],
    )
    assert item.coverage_tags == ["caching", "redundancy"]


def test_blank_question_rejected():
    with pytest.raises(ValidationError):
        ScenarioItem(
            id="a",
            media=ScenarioMedia(kind="image", ref="x.png", filename="x.png", mime_type="image/png"),
            question="",
            coverage_tags=["t"],
        )


@pytest.mark.parametrize("followups", [-1, 6])
def test_max_followups_out_of_range_rejected(followups):
    with pytest.raises(ValidationError):
        ScenarioItem(
            id="a",
            media=ScenarioMedia(kind="image", ref="x.png", filename="x.png", mime_type="image/png"),
            question="q",
            coverage_tags=["t"],
            max_followups=followups,
        )


@pytest.mark.parametrize("followups", [0, 2, 5])
def test_max_followups_in_range_accepted(followups):
    item = ScenarioItem(
        id="a",
        media=ScenarioMedia(kind="image", ref="x.png", filename="x.png", mime_type="image/png"),
        question="q",
        coverage_tags=["t"],
        max_followups=followups,
    )
    assert item.max_followups == followups


def test_media_kind_mismatched_with_mime_rejected():
    with pytest.raises(ValidationError):
        ScenarioMedia(kind="image", ref="x.mp4", filename="x.mp4", mime_type="video/mp4")


def test_media_kind_matches_mime_accepted():
    for kind, mime in (("image", "image/png"), ("video", "video/mp4"), ("audio", "audio/mpeg")):
        ScenarioMedia(kind=kind, ref="x", filename="x", mime_type=mime)


# ── validation: phase-level ──────────────────────────────────────────────────


def test_duplicate_item_id_rejected():
    with pytest.raises(ValidationError):
        CadencePlan.model_validate(_plan_with([_item("a"), _item("a")]))


def test_scenario_and_coding_mutually_exclusive():
    phase = {"id": "p", "duration_s": 300, "intent": "x", "question_mode": "generic",
              "coding_question_ids": ["two_sum"], "scenario_items": [_item()]}
    with pytest.raises(ValidationError):
        CadencePlan.model_validate({"total_duration_s": 300, "phases": [phase]})


def test_scenario_and_written_response_mutually_exclusive():
    phase = {
        "id": "p", "duration_s": 300, "intent": "x", "question_mode": "generic",
        "scenario_items": [_item()],
        "written_response": {"question_type": "comprehensive", "char_limit": 500},
        "question_pool": [{"id": "q1", "text": "write something"}],
    }
    with pytest.raises(ValidationError):
        CadencePlan.model_validate({"total_duration_s": 300, "phases": [phase]})


def test_scenario_phase_cannot_be_adaptive():
    phase = {"id": "p", "duration_s": 300, "intent": "x", "question_mode": "generic",
              "scenario_items": [_item()], "adaptive_difficulty": True}
    with pytest.raises(ValidationError):
        CadencePlan.model_validate({"total_duration_s": 300, "phases": [phase]})


def test_scenario_phase_cannot_have_both_generic_prompts_and_question_pool():
    phase = {
        "id": "p", "duration_s": 300, "intent": "x", "question_mode": "generic",
        "scenario_items": [_item()],
        "generic_prompts": ["intro"],
        "question_pool": [{"id": "q1", "text": "unrelated"}],
    }
    with pytest.raises(ValidationError):
        CadencePlan.model_validate({"total_duration_s": 300, "phases": [phase]})


# ── validation: modality gate ────────────────────────────────────────────────


def test_scenario_phase_rejected_in_text_interview():
    with pytest.raises(ValidationError, match="voice/video"):
        CadencePlan.model_validate(_plan_with([_item()], timed=False))


def test_scenario_phase_allowed_in_voice_interview():
    plan = CadencePlan.model_validate(_plan_with([_item()], timed=True))
    assert plan.get_phase("scenario_analysis").is_scenario_analysis


def test_text_interview_without_scenario_phase_still_allowed():
    # The gate is scoped to phases that actually carry scenario_items — an
    # ordinary untimed/text cadence with no such phase is unaffected.
    plan = CadencePlan.model_validate({
        "total_duration_s": 60, "timed": False,
        "phases": [{"id": "p", "duration_s": 60, "intent": "x",
                    "question_mode": "generic", "generic_prompts": ["hi"]}],
    })
    assert not plan.get_phase("p").is_scenario_analysis


# ── media upload rule (question_types.ASSET_RULES / check_asset) ────────────


def test_check_asset_video_accepts_within_limits():
    assert qt.check_asset("video", "clip.mp4", 5_000_000) is None
    assert qt.check_asset("video", "clip.mov", 1) is None


def test_check_asset_video_rejects_oversized():
    err = qt.check_asset("video", "clip.mp4", 200 * 1024 * 1024)
    assert err is not None and "100 MB" in err


def test_check_asset_video_rejects_bad_extension():
    err = qt.check_asset("video", "clip.avi", 1000)
    assert err is not None and "must be one of" in err


def test_video_asset_rule_excludes_webm_to_avoid_media_type_ambiguity():
    # .webm is claimed by the audio rule; a video upload must use an
    # unambiguous container (see the comment on ASSET_RULES["video"]).
    assert ".webm" not in qt.ASSET_RULES["video"].extensions
    assert ".webm" in qt.ASSET_RULES["audio"].extensions


def test_api_catalog_exposes_video_asset_rule():
    rules = qt.api_catalog()["asset_rules"]
    assert rules["video"]["extensions"] == [".mp4", ".mov", ".m4v"]
    assert rules["video"]["max_bytes"] == 100 * 1024 * 1024


# ── ordering: append_scenario_analysis_phase / insertion index ──────────────


def test_insert_index_before_wrap_up_when_no_coding_phase():
    phases = [{"id": "warm_up"}, {"id": "wrap_up"}]
    assert _insert_idx_before_coding_or_wrap_up(phases) == 1


def test_insert_index_before_coding_phase_when_present():
    phases = [{"id": "warm_up"}, {"id": "coding_round", "coding_question_ids": ["two_sum"]},
              {"id": "code_discussion"}, {"id": "wrap_up"}]
    assert _insert_idx_before_coding_or_wrap_up(phases) == 1


def test_append_scenario_analysis_phase_lands_before_wrap_up():
    import yaml
    base = yaml.safe_dump({
        "total_duration_s": 120,
        "phases": [
            {"id": "warm_up", "duration_s": 60, "intent": "x",
             "question_mode": "generic", "generic_prompts": ["hi"]},
            {"id": "wrap_up", "duration_s": 60, "intent": "x",
             "question_mode": "generic", "generic_prompts": ["bye"]},
        ],
    })
    out = append_scenario_analysis_phase(base, [_item()])
    data = yaml.safe_load(out)
    ids = [p["id"] for p in data["phases"]]
    assert ids == ["warm_up", "scenario_analysis", "wrap_up"]
    assert data["total_duration_s"] == 120 + 180  # +3 min for the one item
    # Round-trips through the real schema.
    plan = CadencePlan.model_validate(data)
    assert plan.get_phase("scenario_analysis").is_scenario_analysis


def test_append_scenario_analysis_phase_lands_before_coding_round():
    import yaml
    base = yaml.safe_dump({
        "total_duration_s": 720,  # 60 + 600 + 60
        "phases": [
            {"id": "warm_up", "duration_s": 60, "intent": "x",
             "question_mode": "generic", "generic_prompts": ["hi"]},
            {"id": "coding_round", "duration_s": 600, "intent": "x",
             "question_mode": "generic", "generic_prompts": ["code"],
             "coding_question_ids": ["two_sum"]},
            {"id": "wrap_up", "duration_s": 60, "intent": "x",
             "question_mode": "generic", "generic_prompts": ["bye"]},
        ],
    })
    out = append_scenario_analysis_phase(base, [_item(), _item("clip_1")], duration_s=240)
    data = yaml.safe_load(out)
    ids = [p["id"] for p in data["phases"]]
    assert ids == ["warm_up", "scenario_analysis", "coding_round", "wrap_up"]
    assert data["total_duration_s"] == 720 + 240


def test_append_scenario_analysis_phase_requires_items():
    import yaml
    base = yaml.safe_dump({"total_duration_s": 60, "phases": [
        {"id": "warm_up", "duration_s": 60, "intent": "x",
         "question_mode": "generic", "generic_prompts": ["hi"]},
    ]})
    with pytest.raises(ValueError):
        append_scenario_analysis_phase(base, [])


# ── eval sectioner phase-mode labeling ───────────────────────────────────────


def test_sectioner_labels_scenario_phase():
    cadence = _plan_with([_item()])
    modes = _cadence_phase_modes(cadence)
    assert modes["scenario_analysis"] == "scenario_analysis"
    assert modes["warm_up"] == "generic"


def test_sectioner_coding_still_wins_over_scenario_label_path():
    # Sanity: the two overrides don't interfere with each other when a plan
    # has both kinds of phase.
    cadence = _plan_with(
        [_item()],
        extra_phase={"id": "coding_round", "duration_s": 60, "intent": "x",
                     "question_mode": "generic", "generic_prompts": ["code"],
                     "coding_question_ids": ["two_sum"]},
    )
    modes = _cadence_phase_modes(cadence)
    assert modes["coding_round"] == "coding"
    assert modes["scenario_analysis"] == "scenario_analysis"


# ── phase blacklist registration ─────────────────────────────────────────────


def test_scenario_analysis_is_blacklisted_from_chat_creation():
    from app.cadence_agents.phase_tools import blacklist_entry, load_phase_blacklist

    load_phase_blacklist.cache_clear()
    entry = blacklist_entry("scenario_analysis")
    assert entry is not None
    assert "media" in entry["reason"].lower()


# ── script runner (so we can run without pytest installed) ───────────────────

if __name__ == "__main__":
    import traceback

    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    failed = 0
    for fn in fns:
        try:
            fn()
            print(f"PASS {fn.__name__}")
        except Exception:
            failed += 1
            print(f"FAIL {fn.__name__}")
            traceback.print_exc()
    print(f"\n{len(fns) - failed}/{len(fns)} passed")
    raise SystemExit(1 if failed else 0)
