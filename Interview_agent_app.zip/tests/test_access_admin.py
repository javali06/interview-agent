"""Access administration: the refusals that keep roles honest.

Sign-in is the same cookie Microsoft sign-in issues.
"""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from db.engine import reset_engine

AYUSH = "ayush.kothiyal@centific.com"
SATHWIK = "sathwik.badda@centific.com"
AZHAR = "md.azhar@centific.com"
HARIKA = "puchalapalli.harika@centific.com"
SHOBIT = "sai.kambampati@centific.com"
JAVALI = "javali.manda@centific.com"


@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    monkeypatch.delenv("DATABASE_URL", raising=False)
    monkeypatch.setenv("ADMIN_SECRET_KEY", "test-secret-for-access")
    reset_engine()
    from db.engine import create_all
    create_all()
    from app.rbac_seed import seed_rbac
    seed_rbac()
    from app.main import app
    from app import rbac

    def uid(email: str) -> int:
        row = rbac.user_by_email(email)
        assert row is not None
        return row["id"]

    yield TestClient(app), uid
    reset_engine()


def _as(c: TestClient, email: str) -> TestClient:
    """Sign in as `email` with the session cookie Microsoft sign-in issues."""
    from app import auth, rbac

    user = rbac.user_by_email(email)
    assert user is not None, email
    c.cookies.set(auth.COOKIE_NAME, auth.issue_cookie(user["email"], user_id=user["id"]))
    return c


def test_every_permission_has_a_label_for_the_grid():
    from app.rbac import ALL_PERMISSIONS, PERMISSION_LABELS
    assert set(PERMISSION_LABELS) == set(ALL_PERMISSIONS)


def test_hr_cannot_open_access_and_a_stranger_cannot_either(client):
    c, _ = client
    assert c.get("/api/access/people").status_code == 401
    _as(c, JAVALI)
    assert c.get("/api/access/people").status_code == 403
    assert c.get("/api/access/teams").status_code == 403
    assert c.get("/api/access/roles").status_code == 403


def test_an_author_and_a_checker_are_not_the_same_person_on_one_team(client):
    c, uid = client
    _as(c, AYUSH)
    azhar = uid(AZHAR)

    same = c.post(f"/api/access/people/{azhar}/grants", json={"role": "pool_checker", "team": "backend"})
    assert same.status_code == 409
    assert "same team" in same.json()["detail"]

    other = c.post(f"/api/access/people/{azhar}/grants", json={"role": "pool_checker", "team": "qa"})
    assert other.status_code == 200
    grants = { (g["role"], g["team"]) for g in next(p["grants"] for p in other.json()["people"] if p["id"] == azhar) }
    assert ("pool_author", "backend") in grants
    assert ("pool_checker", "qa") in grants

    star = c.post(f"/api/access/people/{azhar}/grants", json={"role": "pool_checker", "team": "*"})
    assert star.status_code == 409


def test_a_checker_for_every_team_cannot_also_author_a_team(client):
    c, uid = client
    _as(c, AYUSH)
    refused = c.post(
        f"/api/access/people/{uid(SHOBIT)}/grants",
        json={"role": "pool_author", "team": "backend"},
    )
    assert refused.status_code == 409


def test_the_last_platform_admin_cannot_be_removed(client):
    c, uid = client
    _as(c, AYUSH)
    ayush, sathwik = uid(AYUSH), uid(SATHWIK)

    assert c.delete(f"/api/access/people/{sathwik}/grants", params={"role": "admin", "team": "*"}).status_code == 200
    last = c.delete(f"/api/access/people/{ayush}/grants", params={"role": "admin", "team": "*"})
    assert last.status_code == 409
    assert "assign roles" in last.json()["detail"]

    off = c.patch(f"/api/access/people/{ayush}", json={"is_active": False})
    assert off.status_code == 409


def test_a_restart_does_not_give_back_a_removed_role(client):
    """The seed runs on every startup; it must not undo the Access page."""
    from app.rbac_seed import seed_rbac

    c, uid = client
    _as(c, AYUSH)
    sathwik = uid(SATHWIK)
    assert c.delete(f"/api/access/people/{sathwik}/grants", params={"role": "admin", "team": "*"}).status_code == 200

    seed_rbac()

    person = next(p for p in c.get("/api/access/people").json()["people"] if p["id"] == sathwik)
    assert ("admin", "*") not in {(g["role"], g["team"]) for g in person["grants"]}


def test_a_global_role_is_not_granted_on_one_team(client):
    c, uid = client
    _as(c, AYUSH)
    refused = c.post(
        f"/api/access/people/{uid(JAVALI)}/grants",
        json={"role": "hr", "team": "backend"},
    )
    assert refused.status_code == 400


def test_a_team_in_use_is_not_deleted_and_an_unused_one_is(client):
    c, _ = client
    _as(c, AYUSH)
    assert c.delete("/api/access/teams/backend").status_code == 409
    assert c.delete("/api/access/teams/*").status_code == 409

    made = c.post("/api/access/teams", json={"name": "Data Science"})
    assert made.status_code == 200
    keys = {team["key"] for team in made.json()["teams"]}
    assert "data_science" in keys

    gone = c.delete("/api/access/teams/data_science")
    assert gone.status_code == 200
    assert "data_science" not in {team["key"] for team in gone.json()["teams"]}


def test_a_chain_is_replaced_and_the_fallback_cannot_be_emptied(client):
    c, _ = client
    _as(c, AYUSH)
    saved = c.put("/api/access/teams/qa/chain", json={"steps": [
        {"name": "Technical review", "role": "pool_checker"},
        {"name": "Second look", "role": "pool_checker"},
    ]})
    assert saved.status_code == 200
    assert [step["step_no"] for step in saved.json()["chain"]] == [1, 2]

    cleared = c.put("/api/access/teams/qa/chain", json={"steps": []})
    assert cleared.status_code == 200
    assert cleared.json()["chain"] == []

    fallback = c.put("/api/access/teams/*/chain", json={"steps": []})
    assert fallback.status_code == 409


def test_the_admin_role_keeps_the_access_permissions(client):
    c, _ = client
    _as(c, AYUSH)
    locked = c.put("/api/access/roles/admin", json={"permission": "admin.users", "enabled": False})
    assert locked.status_code == 409

    changed = c.put("/api/access/roles/hr", json={"permission": "pools.view", "enabled": True})
    assert changed.status_code == 200
    hr = next(role for role in changed.json()["roles"] if role["key"] == "hr")
    assert "pools.view" in hr["permissions"]

    invented = c.put("/api/access/roles/hr", json={"permission": "pools.destroy", "enabled": True})
    assert invented.status_code == 400


def test_more_grant_refusals(client):
    """Author on every team, admin on one team, a duplicate, and missing rows."""
    c, uid = client
    _as(c, AYUSH)

    author_star = c.post(
        f"/api/access/people/{uid(AZHAR)}/grants",
        json={"role": "pool_author", "team": "*"},
    )
    assert author_star.status_code == 400

    admin_team = c.post(
        f"/api/access/people/{uid(AYUSH)}/grants",
        json={"role": "admin", "team": "backend"},
    )
    assert admin_team.status_code == 400

    duplicate = c.post(
        f"/api/access/people/{uid(HARIKA)}/grants",
        json={"role": "pool_checker", "team": "backend"},
    )
    assert duplicate.status_code == 409

    missing_person = c.post("/api/access/people/999999/grants", json={"role": "hr", "team": "*"})
    assert missing_person.status_code == 404

    missing_grant = c.delete(
        f"/api/access/people/{uid(AZHAR)}/grants",
        params={"role": "pool_checker", "team": "qa"},
    )
    assert missing_grant.status_code == 404

    missing_role = c.post(
        f"/api/access/people/{uid(AZHAR)}/grants",
        json={"role": "nope", "team": "backend"},
    )
    assert missing_role.status_code == 404


def test_team_keys_rename_and_a_switched_off_team(client):
    c, uid = client
    _as(c, AYUSH)

    assert c.post("/api/access/teams", json={"name": "   "}).status_code == 400
    assert c.post("/api/access/teams", json={"name": "!!!"}).status_code == 400
    assert c.post("/api/access/teams", json={"name": "Everyone", "key": "*"}).status_code == 400
    assert c.post("/api/access/teams", json={"name": "Other", "key": "backend"}).status_code == 409

    made = c.post("/api/access/teams", json={"name": "Speech", "key": "Speech_Lab"})
    assert made.status_code == 200
    assert any(team["key"] == "speech_lab" for team in made.json()["teams"])

    renamed = c.patch("/api/access/teams/backend", json={"name": "Backend Platform"})
    assert renamed.status_code == 200
    row = next(team for team in renamed.json()["teams"] if team["key"] == "backend")
    assert row["name"] == "Backend Platform"
    people = c.get("/api/access/people").json()
    azhar = next(person for person in people["people"] if person["id"] == uid(AZHAR))
    assert any(grant["team"] == "backend" for grant in azhar["grants"])

    assert c.patch("/api/access/teams/*", json={"name": "All"}).status_code == 409

    assert c.patch("/api/access/teams/speech_lab", json={"is_active": False}).status_code == 200
    refused = c.post(
        f"/api/access/people/{uid(AZHAR)}/grants",
        json={"role": "pool_checker", "team": "speech_lab"},
    )
    assert refused.status_code == 409
    # The grant they already hold is still in force. Deactivate blocks new ones.
    from app import rbac
    assert rbac.has_permission(uid(AZHAR), "pools.edit", "backend")


def test_a_chain_warns_when_nobody_holds_the_role(client):
    c, uid = client
    _as(c, AYUSH)
    assert c.delete(
        f"/api/access/people/{uid(SHOBIT)}/grants",
        params={"role": "pool_checker", "team": "*"},
    ).status_code == 200
    assert c.delete(
        f"/api/access/people/{uid(HARIKA)}/grants",
        params={"role": "pool_checker", "team": "backend"},
    ).status_code == 200

    saved = c.put("/api/access/teams/qa/chain", json={"steps": [
        {"name": "Review", "role": "pool_checker"},
    ]})
    assert saved.status_code == 200
    assert saved.json()["warnings"] == ["Nobody can sign step 1 (Review) yet."]

    unknown = c.put("/api/access/teams/qa/chain", json={"steps": [
        {"name": "Review", "role": "not_a_role"},
    ]})
    assert unknown.status_code == 400
    # The bad save did not wipe the chain that was just stored.
    kept = c.get("/api/access/teams/qa/chain")
    assert [step["name"] for step in kept.json()["chain"]] == ["Review"]


def test_each_access_tab_checks_its_own_permission(client):
    c, _ = client
    _as(c, AYUSH)
    assert c.put(
        "/api/access/roles/admin",
        json={"permission": "admin.teams", "enabled": False},
    ).status_code == 409
    assert c.put(
        "/api/access/roles/admin",
        json={"permission": "admin.permissions", "enabled": False},
    ).status_code == 409

    given = c.put(
        "/api/access/roles/pool_checker",
        json={"permission": "admin.users", "enabled": True},
    )
    assert given.status_code == 200
    _as(c, HARIKA)
    assert c.get("/api/access/people").status_code == 200
    assert c.get("/api/access/teams").status_code == 403
    assert c.get("/api/access/roles").status_code == 403


def test_a_grid_tick_is_what_the_next_request_uses(client):
    c, _ = client
    _as(c, JAVALI)
    assert c.get("/api/question-pools").status_code == 403

    _as(c, AYUSH)
    assert c.put(
        "/api/access/roles/hr",
        json={"permission": "pools.view", "enabled": True},
    ).status_code == 200
    _as(c, JAVALI)
    assert c.get("/api/question-pools").status_code == 200

    _as(c, AYUSH)
    cleared = c.put(
        "/api/access/roles/hr",
        json={"permission": "pools.view", "enabled": False},
    )
    assert cleared.status_code == 200
    hr = next(role for role in cleared.json()["roles"] if role["key"] == "hr")
    assert "pools.view" not in hr["permissions"]
    missing = c.put(
        "/api/access/roles/nope",
        json={"permission": "pools.view", "enabled": True},
    )
    assert missing.status_code == 404

    _as(c, JAVALI)
    assert c.get("/api/question-pools").status_code == 403


def test_turning_someone_off_refuses_their_next_request(client):
    c, uid = client
    _as(c, AYUSH)
    assert c.patch(
        f"/api/access/people/{uid(HARIKA)}",
        json={"is_active": False},
    ).status_code == 200
    _as(c, HARIKA)
    assert c.get("/api/question-pools").status_code == 403

    _as(c, AYUSH)
    assert c.patch(
        f"/api/access/people/{uid(HARIKA)}",
        json={"is_active": True},
    ).status_code == 200
    _as(c, HARIKA)
    assert c.get("/api/question-pools").status_code == 200


def test_a_person_with_no_role_is_told_and_refused(client):
    from db.engine import session_scope
    from db.models import AppUser

    c, _ = client
    with session_scope() as s:
        s.add(AppUser(
            email="new.person@centific.com",
            display_name="New Person",
            is_active=True,
        ))
    _as(c, "new.person@centific.com")
    me = c.get("/api/me/permissions")
    assert me.status_code == 200
    assert me.json()["permissions"] == {}

    for path in ("/api/sessions", "/api/access/people", "/api/question-pools"):
        refused = c.get(path)
        assert refused.status_code == 403, path
        assert refused.json()["error"] == "no_access"


def test_a_chain_step_must_be_a_role_that_can_review(client):
    c, _ = client
    _as(c, AYUSH)
    listed = c.get("/api/access/teams/*/chain")
    assert listed.status_code == 200
    keys = {role["key"] for role in listed.json()["roles"]}
    assert keys == {"admin", "pool_checker"}

    refused = c.put("/api/access/teams/qa/chain", json={"steps": [
        {"name": "Review", "role": "pool_author"},
    ]})
    assert refused.status_code == 400
    assert "cannot review" in refused.json()["detail"]
    # The chain that was already there is unchanged.
    kept = c.get("/api/access/teams/qa/chain").json()["chain"]
    assert kept == [] or kept[0]["role"] == "pool_checker"


def test_turning_a_team_off_pauses_its_grants(client):
    c, uid = client
    _as(c, AYUSH)
    from app import rbac

    assert rbac.has_permission(uid(AZHAR), "pools.edit", "backend")
    assert c.patch("/api/access/teams/backend", json={"is_active": False}).status_code == 200
    assert not rbac.has_permission(uid(AZHAR), "pools.edit", "backend")
    # A checker for every team still covers Backend. Their grant is on *.
    assert rbac.has_permission(uid(SHOBIT), "pools.approve", "backend")
    people = c.get("/api/access/people").json()
    azhar = next(person for person in people["people"] if person["id"] == uid(AZHAR))
    assert any(grant["team"] == "backend" for grant in azhar["grants"])

    assert c.patch("/api/access/teams/backend", json={"is_active": True}).status_code == 200
    assert rbac.has_permission(uid(AZHAR), "pools.edit", "backend")


def test_a_paused_team_cannot_supply_the_signer(client):
    c, uid = client
    _as(c, AYUSH)
    assert c.delete(
        f"/api/access/people/{uid(SHOBIT)}/grants",
        params={"role": "pool_checker", "team": "*"},
    ).status_code == 200
    assert c.patch("/api/access/teams/backend", json={"is_active": False}).status_code == 200
    saved = c.put("/api/access/teams/backend/chain", json={"steps": [
        {"name": "Review", "role": "pool_checker"},
    ]})
    assert saved.status_code == 200
    assert saved.json()["warnings"] == ["Nobody can sign step 1 (Review) yet."]


def test_a_new_grant_records_who_added_it(client):
    c, uid = client
    _as(c, AYUSH)
    added = c.post(
        f"/api/access/people/{uid(AZHAR)}/grants",
        json={"role": "pool_checker", "team": "qa"},
    )
    assert added.status_code == 200
    grant = next(
        g for p in added.json()["people"] if p["id"] == uid(AZHAR)
        for g in p["grants"]
        if g["role"] == "pool_checker" and g["team"] == "qa"
    )
    assert grant["granted_by_name"] == "Ayush Kothiyal"
    assert grant["granted_at"]


def test_interview_pages_check_the_interview_permission(client):
    c, _ = client
    from app import auth, rbac

    assert rbac.interview_permission("GET", "/api/sessions") == "interviews.view"
    assert rbac.interview_permission("DELETE", "/api/sessions/abc") == "interviews.cancel"
    assert rbac.interview_permission("POST", "/api/schedule") == "interviews.schedule"
    assert rbac.interview_permission("GET", "/api/roles") == "interviews.view"
    assert rbac.interview_permission("POST", "/api/roles/x/match") == "interviews.schedule"
    assert rbac.interview_permission("POST", "/api/sessions/abc/recording") is None
    assert rbac.interview_permission("GET", "/api/sessions/abc/phase-asset/clip.mp3") is None
    assert rbac.interview_permission("GET", "/api/question-pools") is None

    _as(c, AZHAR)  # author: pools only
    assert c.get("/api/sessions").status_code == 403
    assert c.get("/api/roles").status_code == 403
    assert c.post("/api/schedule", json={}).status_code == 403
    upload = c.post(
        "/api/sessions/no-such-token/recording?kind=camera&seq=0",
        files={"file": ("a.webm", b"x", "video/webm")},
    )
    assert upload.status_code == 404

    _as(c, JAVALI)  # HR holds the interview permissions
    assert c.get("/api/sessions").status_code == 200
    assert c.get("/api/roles").status_code == 200

    c.cookies.set(auth.COOKIE_NAME, auth.issue_cookie("admin"))
    assert c.get("/api/sessions").status_code == 200
