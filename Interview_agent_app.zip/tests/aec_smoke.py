"""AEC smoke harness — parse events.jsonl and tally barge-in signals.

Built for the speaker-tolerant voice-agent experiments tracked under `.lab/`.
Run after a 5-min "silent candidate, speakers on, no headphones" session.
Counts false-barge-in evidence so we can compare experiments quantitatively.

Primary metric:
    false_bargein_per_minute = ai_response_barged_in / minutes

Why these specific events:
    - ai_response_barged_in        the AI's TTS was actually cancelled
    - barge_in_strike_increment    VAD fired during TTS but didn't reach cancel
                                   (near-miss — the 400ms warmup absorbed it)
    - protected_response_mode_entered
                                   too many strikes → system gave up trying
    - audio_end_grace_blocked_barge_in
                                   the 200ms grace window caught a late VAD trip
                                   (a save — counts as defended, not failed)
    - tts_cancelled                might be a real cancel or a real candidate
                                   barge-in; reported but excluded from primary.

In a *silent-candidate* test, all of the above except tts_cancelled-from-error
indicate the AI is hearing itself through the speakers.

Usage
-----
    python tests/aec_smoke.py                         # parse /tmp/integration/events.jsonl
    python tests/aec_smoke.py /path/to/events.jsonl
    python tests/aec_smoke.py --label exp_0_trial_1   # record this run in .lab/results.tsv
    python tests/aec_smoke.py --duration-minutes 5    # override auto-detected duration

Results.tsv columns (when --label is passed):
    experiment | parent | hypothesis | metric_value | secondary_metrics | status |
    duration | description | insight
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

# Event kinds we care about (mirrors stream_b_new/contracts/events.py)
BARGED_IN = "ai_response_barged_in"
STRIKE = "barge_in_strike_increment"
PROTECTED_ENTER = "protected_response_mode_entered"
PROTECTED_EXIT = "protected_response_mode_exited"
GRACE_BLOCKED = "audio_end_grace_blocked_barge_in"
TTS_CANCELLED = "tts_cancelled"
SESSION_STARTED = "session_started"
SESSION_ENDED = "session_ended"
STT_FINAL = "stt_final"

# Events that carry AI speech text in payload.text. Used to detect when STT
# is transcribing the AI's own voice as a candidate utterance.
AI_TEXT_KINDS = (
    "ai_utterance",
    "tts_speak_chunk_sent",
    "filler_dispatched",
    "apology_dispatched",
)

# Echo-detection knobs.
ECHO_WINDOW_S = 60.0
ECHO_NGRAM_N = 4

# Events flagging false-barge-in signal — these are what we want at ZERO.
PRIMARY_KINDS = (BARGED_IN,)
NEAR_MISS_KINDS = (STRIKE, PROTECTED_ENTER, GRACE_BLOCKED)


def _tokens(text: str) -> list[str]:
    """Lowercase wordlike tokens; punctuation stripped."""
    if not text:
        return []
    return re.findall(r"[a-z']+", text.lower())


def _ngrams(toks: list[str], n: int) -> set[tuple[str, ...]]:
    if len(toks) < n:
        return set()
    return {tuple(toks[i : i + n]) for i in range(len(toks) - n + 1)}


def count_fake_candidate_utterances(events: list[dict]) -> tuple[int, list[str]]:
    """Detect 'AI voice transcribed as candidate' — the second loop failure.

    Walks events in order. Maintains a sliding window of AI-speech texts from
    AI_TEXT_KINDS over the last ECHO_WINDOW_S seconds. For each stt_final, if
    its ECHO_NGRAM_N-grams overlap with any windowed AI text, count it as an
    echo.

    Returns:
        (count, sample_texts)  — sample_texts has up to 5 example echo lines
                                 for the summary printout.
    """
    ai_window: list[tuple[float, str]] = []  # (epoch_seconds, text)
    fake_count = 0
    samples: list[str] = []
    for e in events:
        kind = e.get("kind", "")
        ts_str = e.get("ts", "")
        try:
            t = datetime.fromisoformat(ts_str).timestamp()
        except (ValueError, TypeError):
            continue
        payload = e.get("payload") or {}
        text = payload.get("text", "") or ""
        # Drop AI window entries older than the window.
        ai_window = [(et, etext) for et, etext in ai_window if (t - et) <= ECHO_WINDOW_S]
        if kind in AI_TEXT_KINDS and text:
            ai_window.append((t, text))
        elif kind == STT_FINAL and text:
            cand_ngrams = _ngrams(_tokens(text), ECHO_NGRAM_N)
            if not cand_ngrams:
                continue
            for et, etext in ai_window:
                if cand_ngrams & _ngrams(_tokens(etext), ECHO_NGRAM_N):
                    fake_count += 1
                    if len(samples) < 5:
                        samples.append(text)
                    break
    return fake_count, samples


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Tally barge-in signals from an events.jsonl run.")
    p.add_argument(
        "events_path",
        nargs="?",
        default="/tmp/integration/events.jsonl",
        help="Path to events.jsonl (default: /tmp/integration/events.jsonl)",
    )
    p.add_argument(
        "--label",
        default=None,
        help="Experiment label; if set, appends a row to .lab/results.tsv",
    )
    p.add_argument(
        "--parent",
        default="",
        help="Parent experiment label (for tree of derivations).",
    )
    p.add_argument(
        "--hypothesis",
        default="",
        help="One-line hypothesis to log alongside the result.",
    )
    p.add_argument(
        "--description",
        default="",
        help="Free-text description of the experiment run.",
    )
    p.add_argument(
        "--duration-minutes",
        type=float,
        default=None,
        help="Override auto-detected session duration (used for rate computation).",
    )
    p.add_argument(
        "--results-tsv",
        default=None,
        help="Path to results.tsv (default: <events_path_dir>/../.lab/results.tsv if --label set)",
    )
    return p.parse_args()


def load_events(path: Path) -> list[dict]:
    """Read JSONL, tolerating partially-flushed last line."""
    if not path.exists():
        sys.stderr.write(f"ERROR: events file not found: {path}\n")
        sys.exit(2)
    events: list[dict] = []
    for line_no, line in enumerate(path.read_text().splitlines(), start=1):
        line = line.strip()
        if not line:
            continue
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError as e:
            sys.stderr.write(f"WARNING: skipping malformed line {line_no}: {e}\n")
    return events


def compute_duration_minutes(events: list[dict]) -> float | None:
    """Use SESSION_STARTED/ENDED if present; else first→last event timestamps."""
    starts = [e for e in events if e.get("kind") == SESSION_STARTED]
    ends = [e for e in events if e.get("kind") == SESSION_ENDED]
    if starts and ends:
        s_ts = datetime.fromisoformat(starts[0]["ts"])
        e_ts = datetime.fromisoformat(ends[-1]["ts"])
    elif events:
        s_ts = datetime.fromisoformat(events[0]["ts"])
        e_ts = datetime.fromisoformat(events[-1]["ts"])
    else:
        return None
    seconds = (e_ts - s_ts).total_seconds()
    return seconds / 60.0 if seconds > 0 else None


def summarise(events: list[dict], override_minutes: float | None) -> dict:
    counts: Counter[str] = Counter(e.get("kind", "<unknown>") for e in events)
    duration_min = override_minutes or compute_duration_minutes(events)

    primary_count = sum(counts[k] for k in PRIMARY_KINDS)
    near_miss = {k: counts[k] for k in NEAR_MISS_KINDS}
    near_miss_total = sum(near_miss.values())
    tts_cancelled = counts[TTS_CANCELLED]

    fp_per_min = (primary_count / duration_min) if duration_min else None
    echo_count, echo_samples = count_fake_candidate_utterances(events)
    echo_per_min = (echo_count / duration_min) if duration_min else None

    return {
        "duration_minutes": duration_min,
        "primary_count": primary_count,
        "primary_per_minute": fp_per_min,
        "near_miss": near_miss,
        "near_miss_total": near_miss_total,
        "tts_cancelled": tts_cancelled,
        "fake_candidate_count": echo_count,
        "fake_candidate_per_minute": echo_per_min,
        "fake_candidate_samples": echo_samples,
        "all_event_counts": dict(counts),
    }


def print_summary(label: str | None, path: Path, summary: dict) -> None:
    print()
    print(f"=== AEC smoke summary: {label or '(unlabeled)'} ===")
    print(f"events file:           {path}")
    print(f"duration (minutes):    {summary['duration_minutes']:.2f}" if summary['duration_minutes'] else "duration (minutes):    UNKNOWN")
    print()
    print("--- primary metric (lower is better) ---")
    print(f"  false_bargein_count:        {summary['primary_count']}   (kind: ai_response_barged_in)")
    if summary["primary_per_minute"] is not None:
        print(f"  false_bargein_per_minute:   {summary['primary_per_minute']:.2f}")
    else:
        print("  false_bargein_per_minute:   N/A (no duration)")
    print()
    print("--- secondary (near-miss / partial defense) ---")
    for k, v in summary["near_miss"].items():
        print(f"  {k:42s}  {v}")
    print(f"  {'tts_cancelled':42s}  {summary['tts_cancelled']}  (informational; not all are FPs)")
    print()
    print("--- second-loop failure: AI voice transcribed as candidate ---")
    print(f"  fake_candidate_utterances:  {summary['fake_candidate_count']}")
    if summary["fake_candidate_per_minute"] is not None:
        print(f"  fake_candidate_per_minute:  {summary['fake_candidate_per_minute']:.2f}")
    if summary["fake_candidate_samples"]:
        print("  sample echo-transcriptions (up to 5):")
        for s in summary["fake_candidate_samples"]:
            print(f"    - {s[:80]!r}")
    print()
    print("--- all event-kind counts (top 15) ---")
    for kind, count in sorted(summary["all_event_counts"].items(), key=lambda kv: -kv[1])[:15]:
        print(f"  {kind:42s}  {count}")
    print()


def append_to_results_tsv(
    results_path: Path,
    label: str,
    parent: str,
    hypothesis: str,
    description: str,
    summary: dict,
) -> None:
    """Append a single experiment row to .lab/results.tsv."""
    duration_min = summary["duration_minutes"]
    metric_value = (
        f"{summary['primary_per_minute']:.2f}"
        if summary["primary_per_minute"] is not None
        else "N/A"
    )
    near_miss_summary = ";".join(
        f"{k.replace('_response_mode', '').replace('barge_in_', '').replace('audio_end_grace_blocked_', 'grace_')}={v}"
        for k, v in summary["near_miss"].items()
    )
    secondary = (
        f"primary_count={summary['primary_count']};"
        f"{near_miss_summary};"
        f"tts_cancelled={summary['tts_cancelled']};"
        f"fake_candidate={summary['fake_candidate_count']}"
    )
    duration_str = f"{duration_min * 60:.0f}s" if duration_min else "?s"
    insight = ""  # filled in by reflection later

    # Determine status post-hoc: KEEP if primary count is 0 and we have a parent
    # to compare against; CRASH if duration < 60s (something blew up early); else
    # leave blank and human/AI fills in during reflection.
    if duration_min is None or duration_min < 1.0:
        status = "crash"
    else:
        status = ""

    row = "\t".join(
        [
            label,
            parent,
            hypothesis,
            metric_value,
            secondary,
            status,
            duration_str,
            description,
            insight,
        ]
    )
    with results_path.open("a") as f:
        f.write(row + "\n")
    print(f"Appended to {results_path}")


def main() -> int:
    args = parse_args()
    events_path = Path(args.events_path)
    events = load_events(events_path)
    if not events:
        sys.stderr.write("ERROR: no events parsed — empty or malformed file.\n")
        return 3

    summary = summarise(events, args.duration_minutes)
    print_summary(args.label, events_path, summary)

    if args.label:
        # Default results path: <demo_root>/.lab/results.tsv
        if args.results_tsv:
            results_path = Path(args.results_tsv)
        else:
            # Walk up from events_path looking for .lab/ (handle the dev case
            # where events.jsonl lives in /tmp/integration/).
            repo_root = Path(__file__).resolve().parent.parent
            results_path = repo_root / ".lab" / "results.tsv"
        if not results_path.exists():
            sys.stderr.write(f"WARNING: {results_path} not found — skipping TSV append.\n")
        else:
            append_to_results_tsv(
                results_path,
                args.label,
                args.parent,
                args.hypothesis,
                args.description,
                summary,
            )

    return 0


if __name__ == "__main__":
    sys.exit(main())
