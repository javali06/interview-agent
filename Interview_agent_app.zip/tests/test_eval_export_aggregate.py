"""AB#34151 — one downloadable JSON for the whole evaluation.

Covers the aggregation + download half of the story:
  - every plugin that ran contributes its section to ONE document
  - the admin download serves that one file (not a file per plugin)
  - the exported numbers agree with the internal benchmark path (the
    "no regression" guarantee — two paths, one truth)
  - non-scored segments stay non-scored all the way to the file

No LLM: the export reads already-computed SegmentEvaluations.
"""
from __future__ import annotations

import json

import pytest
from fastapi.testclient import TestClient

from features.eval import export as X
from features.eval.plugins.base import SegmentEvaluation
from features.eval.sectioner import Segment


def _seg(segment_id: str, phase_id: str, question_id: str | None = "q1") -> Segment:
    return Segment(segment_id=segment_id, kind="question", phase_id=phase_id,
                   question_id=question_id, start_event_index=0,
                   end_event_index=1, turns=[])


def _ev(plugin_id: str, segment_id: str, phase_id: str, **kw) -> SegmentEvaluation:
    base = dict(plugin_id=plugin_id, segment_id=segment_id, phase_id=phase_id,
                state="scored", marks_earned=3.0, marks_possible=5.0,
                rationale="because")
    base.update(kw)
    return SegmentEvaluation(**base)


def _session_pairs():
    """A session touching BOTH plugin families plus a phase that never ran."""
    return [
        (_seg("warm::0", "warm_up", None),
         _ev("conversational_rubric", "warm::0", "warm_up",
             marks_earned=2.8, marks_possible=5.0,
             sub_scores={"communication_clarity": 7.0, "role_fit": 4.0},
             view_payload={"dimensions": {"communication_clarity": 7.0, "role_fit": 4.0},
                           "mean_0_10": 5.5, "rationale": "clear"})),
        (_seg("tech::q1", "technical_questions"),
         _ev("dynamic_difficulty", "tech::q1", "technical_questions",
             marks_earned=4.0, marks_possible=8.0,
             view_payload={"difficulty": "medium", "base_marks": 8.0, "follow_ups": 2,
                           "covered": ["overfitting"], "still_missed": ["regularization"],
                           "verifier_alignment": "agree", "coverage_source": "question",
                           "tags": ["overfitting", "regularization"]})),
        (_seg("tech::q2", "technical_questions"),
         _ev("coverage_tags", "tech::q2", "technical_questions",
             marks_earned=2.0, marks_possible=4.0,
             view_payload={"tags": [{"label": "batching", "delta": 2.0, "detail": "covered"},
                                    {"label": "quantisation", "delta": 0.0, "detail": "missing"}],
                           "matched": 1, "total": 2})),
        (_seg("coding::q1", "coding_round"),
         _ev("rubric_marks", "coding::q1", "coding_round",
             state="not_observed", marks_earned=0.0, marks_possible=30.0,
             rationale="Phase did not run.")),
    ]


# ── aggregation ─────────────────────────────────────────────────────────────
def test_one_document_collects_a_section_from_every_plugin_that_ran():
    r = X.build_report(_session_pairs(), session={"token": "t1", "role": "AI Engineer"})
    # One file, every plugin — not one file per plugin.
    assert len(r.sections) == 4
    assert [s.plugin_id for s in r.sections] == [
        "conversational_rubric", "dynamic_difficulty", "coverage_tags", "rubric_marks"]
    # Each section names the declared key it conforms to.
    assert [s.section for s in r.sections] == [
        "rubric_dimensions", "difficulty_breakdown", "coverage_tags", "rubric_options"]


def test_the_document_carries_the_schema_for_every_section_it_contains():
    # Self-describing: a consumer validates what it received without fetching
    # the contract from us separately.
    r = X.build_report(_session_pairs())
    for s in r.sections:
        assert s.section in r.section_schemas
        assert r.section_schemas[s.section]["json_schema"].get("properties")


def test_exported_totals_match_the_internal_benchmark_arithmetic():
    """AC: no regression — the export and the internal path must not disagree.

    Both sum the same rule (scored only), so if these ever diverge one of them
    has changed its definition of a score."""
    pairs = _session_pairs()
    r = X.build_report(pairs)

    # Recompute the way plugin_aggregate does: scored segments only.
    scored = [ev for _s, ev in pairs if ev.state == "scored"]
    expected_earned = round(sum(e.marks_earned for e in scored), 2)
    expected_possible = round(sum(e.marks_possible for e in scored), 2)

    assert r.totals.marks_earned == expected_earned == 8.8
    assert r.totals.marks_possible == expected_possible == 17.0
    assert r.totals.pct == round(100.0 * 8.8 / 17.0, 1)
    # The unobserved 30 marks are absent from BOTH.
    assert r.totals.marks_possible != 47.0


def test_a_non_scored_segment_survives_to_the_file_as_a_state_not_a_zero():
    r = X.build_report(_session_pairs())
    doc = json.loads(r.model_dump_json())
    missed = next(s for s in doc["sections"] if s["segment_id"] == "coding::q1")
    assert missed["state"] == "not_observed"
    assert missed["marks_earned"] is None, "0 would read as 'they scored nothing'"
    assert missed["marks_possible"] is None
    assert missed["not_scored_reason"]


def test_the_whole_document_is_valid_json_and_reparses():
    r = X.build_report(_session_pairs(), session={"token": "t1"})
    doc = json.loads(r.model_dump_json())
    assert X.EvaluationReport.model_validate(doc)


# ── the download endpoint ───────────────────────────────────────────────────
@pytest.fixture()
def api(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path / "sessions"))
    monkeypatch.setenv("BLOB_ENABLED", "0")
    import importlib
    from app import blob_store, paths
    importlib.reload(paths)
    importlib.reload(blob_store)
    import app.main as M
    importlib.reload(M)
    return M, TestClient(M.app)


def _make_session(M, tmp_path, token="tok-export-1", with_export=True):
    monkey_row = {"token": token, "role": "AI Engineer", "candidate_name": "Sam",
                  "status": "completed", "event_log_path": "events.jsonl",
                  "modality": "voice"}
    sdir = M.session_dir(token)
    sdir.mkdir(parents=True, exist_ok=True)
    if with_export:
        r = X.build_report(_session_pairs(), session={"token": token, "role": "AI Engineer"})
        (sdir / "evaluation_export.json").write_text(r.model_dump_json(indent=2),
                                                     encoding="utf-8")
    return monkey_row


def test_download_serves_one_file_for_the_whole_evaluation(api, tmp_path, monkeypatch):
    M, c = api
    row = _make_session(M, tmp_path)
    monkeypatch.setattr(M.db, "get", lambda t: row if t == row["token"] else None)
    monkeypatch.setattr(M, "_require_user_or_redirect", lambda r: None)

    resp = c.get(f"/admin/sessions/{row['token']}/evaluation-export.json")
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("application/json")
    # ONE file, named for the session — not a file per plugin.
    assert "attachment" in resp.headers["content-disposition"]
    assert f"evaluation-{row['token'][:8]}.json" in resp.headers["content-disposition"]

    doc = resp.json()
    assert doc["report_version"] == X.REPORT_VERSION
    assert len(doc["sections"]) == 4
    assert doc["totals"]["marks_earned"] == 8.8


def test_inline_renders_instead_of_downloading(api, tmp_path, monkeypatch):
    M, c = api
    row = _make_session(M, tmp_path)
    monkeypatch.setattr(M.db, "get", lambda t: row if t == row["token"] else None)
    monkeypatch.setattr(M, "_require_user_or_redirect", lambda r: None)
    resp = c.get(f"/admin/sessions/{row['token']}/evaluation-export.json?inline=1")
    assert resp.status_code == 200
    assert "content-disposition" not in {k.lower() for k in resp.headers}


def test_missing_export_is_a_clear_404_not_an_empty_file(api, tmp_path, monkeypatch):
    M, c = api
    row = _make_session(M, tmp_path, token="tok-none", with_export=False)
    monkeypatch.setattr(M.db, "get", lambda t: row if t == row["token"] else None)
    monkeypatch.setattr(M, "_require_user_or_redirect", lambda r: None)
    resp = c.get(f"/admin/sessions/{row['token']}/evaluation-export.json")
    assert resp.status_code == 404
    assert "run the evaluation" in resp.json()["detail"]


def test_unknown_session_is_404(api, monkeypatch):
    M, c = api
    monkeypatch.setattr(M.db, "get", lambda t: None)
    monkeypatch.setattr(M, "_require_user_or_redirect", lambda r: None)
    assert c.get("/admin/sessions/nope/evaluation-export.json").status_code == 404


# ── the UI renders from the export (AC: one source of truth) ────────────────
def test_evaluation_view_serves_the_export_verbatim(api, tmp_path, monkeypatch):
    """The screen and the downloadable file must be the SAME document.

    Not "equivalent" — byte-identical. If the view endpoint ever rebuilt the
    scores instead of serving the stored artefact, the two could drift and
    nobody would notice until a customer compared them."""
    M, c = api
    row = _make_session(M, tmp_path, token="tok-view-1")
    monkeypatch.setattr(M.db, "get", lambda t: row if t == row["token"] else None)
    monkeypatch.setattr(M, "_require_user_or_redirect", lambda r: None)

    download = c.get(f"/admin/sessions/{row['token']}/evaluation-export.json?inline=1")
    view = c.get(f"/api/sessions/{row['token']}/evaluation-view")
    assert download.status_code == 200 and view.status_code == 200

    # The `export` block IS the file.
    assert view.json()["export"] == download.json()


def test_evaluation_view_evidence_is_separate_from_the_export(api, tmp_path, monkeypatch):
    # Evidence is served to an authenticated admin, never written into the
    # export — docs/eval-export-pii-decision.md.
    M, c = api
    row = _make_session(M, tmp_path, token="tok-view-2")
    monkeypatch.setattr(M.db, "get", lambda t: row if t == row["token"] else None)
    monkeypatch.setattr(M, "_require_user_or_redirect", lambda r: None)

    body = c.get(f"/api/sessions/{row['token']}/evaluation-view").json()
    assert set(body) >= {"export", "evidence"}
    # No transcript leaked into the exported half.
    exported = json.dumps(body["export"])
    assert "turns" not in exported and "question_text" not in exported
    # Evidence degrades to empty rather than failing the whole view when the
    # event log is absent (this fixture has none).
    assert isinstance(body["evidence"], dict)


def test_evaluation_view_404s_before_an_evaluation_exists(api, tmp_path, monkeypatch):
    M, c = api
    row = _make_session(M, tmp_path, token="tok-view-3", with_export=False)
    monkeypatch.setattr(M.db, "get", lambda t: row if t == row["token"] else None)
    monkeypatch.setattr(M, "_require_user_or_redirect", lambda r: None)
    r = c.get(f"/api/sessions/{row['token']}/evaluation-view")
    assert r.status_code == 404 and "run the evaluation" in r.json()["detail"]
