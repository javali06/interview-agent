"""Unit tests for the Visual Scenario Analysis per-item state machine
(engine/brain/core/scenario_cursor.py). Pure logic — no LLM, no asyncio, no
WS. The verifier's judge/rephrase results are supplied as plain strings/lists,
exactly as Director would pass them in after a real fast-LLM call; this file
never calls one.

Run with: python -m pytest tests/test_scenario_cursor.py -v
"""
from __future__ import annotations

import pytest

from engine.brain.cadence.schema import ScenarioItem, ScenarioMedia
from engine.brain.core.scenario_cursor import GOOD_ENOUGH_INTENTS, ScenarioCursor, ScenarioStage


def _item(iid: str, kind: str = "image", tags=("load balancer", "redundancy"), max_followups: int = 2) -> ScenarioItem:
    return ScenarioItem(
        id=iid,
        media=ScenarioMedia(kind=kind, ref=f"{iid}.bin", filename=f"{iid}.bin",
                             mime_type={"image": "image/png", "video": "video/mp4", "audio": "audio/mpeg"}[kind]),
        question=f"question about {iid}",
        coverage_tags=list(tags),
        max_followups=max_followups,
    )


def _cursor(*items: ScenarioItem, **kw) -> ScenarioCursor:
    return ScenarioCursor(items=list(items), phase_id="scenario_analysis", **kw)


# ── construction / item order ────────────────────────────────────────────


def test_starts_on_first_item_awaiting_media_intro():
    c = _cursor(_item("a"), _item("b"))
    assert c.index == 0
    assert c.stage is ScenarioStage.AWAIT_MEDIA_INTRO
    assert c.current_item().id == "a"
    assert c.next_action() == {"action": "show_media", "item": c.current_item()}


def test_items_are_walked_in_order():
    c = _cursor(_item("a"), _item("b"), _item("c"))
    for expected in ("a", "b", "c"):
        assert c.current_item().id == expected
        c.media_intro_dispatched(0.0)     # image → immediate
        c.question_dispatched("q")
        c.record_answer("good", "answered", [])
    assert c.is_phase_done()
    assert c.current_item() is None
    assert c.next_action() == {"action": "end_phase"}


# ── image vs video/audio media wait ──────────────────────────────────────


def test_image_needs_no_media_wait():
    c = _cursor(_item("a", kind="image"))
    c.media_intro_dispatched(0.0)
    assert c.stage is ScenarioStage.READY_TO_ASK
    assert not c.needs_media_wait(now_s=0.0)


def test_video_needs_media_wait_until_ack():
    c = _cursor(_item("a", kind="video"))
    c.media_intro_dispatched(now_s=10.0)
    assert c.stage is ScenarioStage.AWAIT_MEDIA_ACK
    assert c.needs_media_wait(now_s=10.5)
    c.media_ack("ended")
    assert c.stage is ScenarioStage.READY_TO_ASK
    assert not c.needs_media_wait(now_s=11.0)


def test_audio_needs_media_wait_same_as_video():
    c = _cursor(_item("a", kind="audio"))
    c.media_intro_dispatched(now_s=0.0)
    assert c.stage is ScenarioStage.AWAIT_MEDIA_ACK
    assert c.needs_media_wait(now_s=1.0)


def test_media_wait_has_a_bound_and_does_not_block_forever():
    c = _cursor(_item("a", kind="video"), media_wait_timeout_s=30.0)
    c.media_intro_dispatched(now_s=100.0)
    assert c.needs_media_wait(now_s=110.0)          # 10s in, still waiting
    assert not c.needs_media_wait(now_s=131.0)       # 31s in, bound exceeded
    assert c.media_wait_timed_out(now_s=131.0)


def test_media_error_skips_the_item_immediately():
    c = _cursor(_item("a", kind="video"), _item("b"))
    c.media_intro_dispatched(now_s=0.0)
    c.media_ack("error")
    assert c.current_item().id == "b"
    assert c.records[0].outcome == "skipped_media_error"
    assert c.records[0].media_ack == "error"


def test_media_skipped_by_candidate_still_lets_the_question_be_asked():
    # "skipped" (candidate manually stopped playback) is NOT a media error —
    # the item continues normally to the question, matching the spec's
    # "candidate can stop it, then still answer" allowance.
    c = _cursor(_item("a", kind="video"))
    c.media_intro_dispatched(now_s=0.0)
    c.media_ack("skipped")
    assert c.stage is ScenarioStage.READY_TO_ASK
    assert c.current_record().outcome == "in_progress"


# ── follow-up counting up to max_followups ───────────────────────────────


def test_followup_counting_up_to_max_then_forces_completion():
    item = _item("a", max_followups=2)
    c = _cursor(item)
    c.media_intro_dispatched(0.0)
    c.question_dispatched("q")

    r1 = c.record_answer("partial 1", "partial_answer", ["load balancer"])
    assert r1["item_done"] is False
    assert c.stage is ScenarioStage.ASK_FOLLOWUP
    assert c.followups_used == 1

    c.followup_dispatched("follow-up 1")
    r2 = c.record_answer("partial 2", "partial_answer", ["load balancer"])
    assert r2["item_done"] is False
    assert c.followups_used == 2

    # third strike: follow-ups (2) are now exhausted (used == cap) — forced done
    c.followup_dispatched("follow-up 2")
    r3 = c.record_answer("still partial", "partial_answer", ["load balancer"])
    assert r3["item_done"] is True
    assert c.records[0].outcome == "followups_exhausted"
    assert c.is_phase_done()  # only one item in this cursor


def test_zero_max_followups_means_no_followup_at_all():
    item = _item("a", max_followups=0)
    c = _cursor(item)
    c.media_intro_dispatched(0.0)
    c.question_dispatched("q")
    r = c.record_answer("meh", "partial_answer", ["load balancer"])
    assert r["item_done"] is True
    assert c.records[0].outcome == "followups_exhausted"


# ── good-enough early exit ────────────────────────────────────────────────


def test_good_enough_on_first_try_skips_followups_entirely():
    c = _cursor(_item("a"), _item("b"))
    c.media_intro_dispatched(0.0)
    c.question_dispatched("q")
    r = c.record_answer("great answer covering everything", "answered", [])
    assert r["item_done"] is True
    assert c.records[0].outcome == "good_enough"
    assert c.records[0].tags_covered == ["load balancer", "redundancy"]
    assert c.records[0].tags_missing == []
    assert c.current_item().id == "b"


def test_default_answered_counts_as_good_enough():
    c = _cursor(_item("a"))
    c.media_intro_dispatched(0.0)
    c.question_dispatched("q")
    r = c.record_answer("answer", "default_answered", [])
    assert r["item_done"] is True
    assert c.records[0].outcome == "good_enough"


def test_partial_answer_skip_is_a_good_enough_intent_mirroring_director_promotion():
    # Director promotes partial_answer -> partial_answer_skip once its OWN
    # cap is hit; the cursor treats that promoted verdict as "move on" too.
    assert "partial_answer_skip" in GOOD_ENOUGH_INTENTS
    c = _cursor(_item("a", max_followups=5))
    c.media_intro_dispatched(0.0)
    c.question_dispatched("q")
    r = c.record_answer("still not enough", "partial_answer_skip", ["redundancy"])
    assert r["item_done"] is True
    assert c.records[0].outcome == "good_enough"  # cursor can't tell "forced" from "genuine"
    assert c.records[0].tags_missing == []  # good_enough path clears missing tags


def test_partial_tags_covered_and_missing_split_correctly():
    c = _cursor(_item("a", tags=("x", "y", "z"), max_followups=0))
    c.media_intro_dispatched(0.0)
    c.question_dispatched("q")
    c.record_answer("partial", "partial_answer", ["y", "z"])
    rec = c.records[0]
    assert rec.outcome == "followups_exhausted"
    assert rec.tags_covered == ["x"]
    assert rec.tags_missing == ["y", "z"]


# ── skip handling (one nudge, then grant) ────────────────────────────────


def test_skip_request_grants_only_after_one_nudge():
    c = _cursor(_item("a"), _item("b"))
    c.media_intro_dispatched(0.0)
    c.question_dispatched("q")
    assert c.request_skip() is False   # first ask -> nudge, not granted
    assert not c.is_phase_done()
    assert c.current_item().id == "a"  # still on item a
    assert c.request_skip() is True    # asked again -> granted
    assert c.current_item().id == "b"
    assert c.records[0].outcome == "skipped_by_candidate"


def test_skip_nudge_flag_resets_per_item():
    c = _cursor(_item("a"), _item("b"))
    c.media_intro_dispatched(0.0)
    c.question_dispatched("q")
    c.request_skip()          # nudge on item a
    c.request_skip()          # granted -> advances to item b
    c.media_intro_dispatched(0.0)
    c.question_dispatched("q")
    assert c.request_skip() is False  # fresh nudge on item b, not carried over


# ── time-up mid-item ──────────────────────────────────────────────────────


def test_time_up_mid_item_wraps_current_and_skips_the_rest():
    c = _cursor(_item("a"), _item("b"), _item("c"))
    c.media_intro_dispatched(0.0)
    c.question_dispatched("q")
    c.time_up(now_s=42.0)
    assert c.is_phase_done()
    assert c.records[0].outcome == "skipped_time_budget"
    assert c.records[0].ended_at_s == 42.0
    assert [r.outcome for r in c.records[1:]] == ["not_reached", "not_reached"]
    assert c.next_action() == {"action": "end_phase"}


def test_time_up_when_already_done_is_a_noop_on_the_finished_item():
    c = _cursor(_item("a"))
    c.media_intro_dispatched(0.0)
    c.question_dispatched("q")
    c.record_answer("great", "answered", [])
    assert c.is_phase_done()
    c.time_up(now_s=99.0)  # should not crash / re-finish an already-done cursor
    assert c.records[0].outcome == "good_enough"  # untouched


def test_should_wrap_up_now_true_only_near_the_floor():
    c = _cursor(_item("a"))
    assert c.should_wrap_up_now(remaining_phase_s=5.0, floor_s=20.0)
    assert not c.should_wrap_up_now(remaining_phase_s=60.0, floor_s=20.0)


def test_time_budget_hint_splits_remaining_across_remaining_items():
    c = _cursor(_item("a"), _item("b"), _item("c"))
    hint = c.time_budget_hint(remaining_phase_s=90.0)
    assert "3 scenario items remain" in hint
    assert "30s each" in hint


def test_time_budget_hint_empty_on_last_item():
    c = _cursor(_item("a"))
    assert c.time_budget_hint(remaining_phase_s=90.0) == ""


# ── playback-wait gating (dispatch suppression) ──────────────────────────


def test_needs_media_wait_false_before_intro_dispatched():
    # AWAIT_MEDIA_INTRO itself is not a wait state — Director must still be
    # ALLOWED to dispatch the framing turn.
    c = _cursor(_item("a", kind="video"))
    assert not c.needs_media_wait(now_s=0.0)


def test_needs_media_wait_false_once_ready_to_ask():
    c = _cursor(_item("a", kind="image"))
    c.media_intro_dispatched(0.0)
    assert not c.needs_media_wait(now_s=0.0)


# ── serialization shape (for a future resume extension) ──────────────────


def test_to_dict_round_trips_the_essential_shape():
    c = _cursor(_item("a"), _item("b"))
    c.media_intro_dispatched(0.0)
    c.question_dispatched("q")
    c.record_answer("partial", "partial_answer", ["load balancer"])
    d = c.to_dict()
    assert d["phase_id"] == "scenario_analysis"
    assert d["index"] == 0
    assert d["stage"] == "ask_followup"
    assert d["followups_used"] == 1
    assert len(d["records"]) == 1
    assert d["records"][0]["attempts"][0]["missing_tags"] == ["load balancer"]


# ── next_action() shape stability (Director's dispatch table) ───────────


def test_next_action_shapes():
    c = _cursor(_item("a", kind="video"))
    assert c.next_action()["action"] == "show_media"
    c.media_intro_dispatched(0.0)
    assert c.next_action()["action"] == "await_media"
    c.media_ack("ended")
    assert c.next_action()["action"] == "ask_question"
    c.question_dispatched("q")
    assert c.next_action()["action"] == "await_answer"
    c.record_answer("partial", "partial_answer", ["load balancer"])
    action = c.next_action()
    assert action["action"] == "ask_followup"
    assert action["missing_tags"] == ["load balancer"]
