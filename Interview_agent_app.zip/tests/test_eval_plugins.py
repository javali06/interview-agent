"""Unit tests for the evaluation plugin framework + built-in plugins.

Runs under pytest OR directly (`python tests/test_eval_plugins.py`).
"""
from __future__ import annotations

import asyncio

import features.eval.plugins as P
from features.eval.plugins.base import EvalContext
from features.eval.plugins.builtins.rubric_marks import Criterion, RubricMarksConfig
from features.eval.sectioner import build_segments


def _question_segment(coverage_tags, answer, *, qid="q1", difficulty="medium"):
    events = [
        {"kind": "session_started", "payload": {"initial_phase": "tech"}, "ts": "t"},
        {"kind": "question_dispatched", "payload": {
            "phase_id": "tech", "question_id": qid, "question_text": "q?",
            "difficulty": difficulty, "coverage_tags": coverage_tags}, "ts": "t"},
        {"kind": "ai_utterance", "payload": {"text": "ask"}, "ts": "t"},
    ]
    if answer is not None:
        events.append({"kind": "stt_final", "payload": {"text": answer}, "ts": "t"})
    events.append({"kind": "session_ended", "payload": {}, "ts": "t"})
    iv = build_segments(events)
    return next(s for _, s in iv.iter_segments() if s.question_id == qid)


def test_catalog_exposes_schema_and_assumptions():
    cat = {c["id"]: c for c in P.plugin_catalog()}
    assert "coverage_tags" in cat
    ct = cat["coverage_tags"]
    assert ct["method"] == "python"
    assert ct["view_id"] == "tag_checklist"
    assert "marks_per_tag" in ct["config_json_schema"]["properties"]
    assert {a["key"] for a in ct["assumptions"]} == {"tags", "candidate_answer"}
    # default_config is JSON-serializable and matches the schema defaults
    assert ct["default_config"]["marks_per_tag"] == 2.0


def test_every_plugin_ships_self_explanatory_help():
    # Each plugin must be self-explanatory in the UI: a full PluginHelp (not just
    # the one-line description) so a TA knows what it's for without guessing.
    for c in P.plugin_catalog():
        h = c.get("help") or {}
        assert h.get("summary"), f"{c['id']} missing help.summary"
        assert h.get("best_for"), f"{c['id']} missing help.best_for"
        assert h.get("how_it_works"), f"{c['id']} missing help.how_it_works"
        assert h.get("you_configure"), f"{c['id']} missing help.you_configure"
        assert h.get("evidence"), f"{c['id']} missing help.evidence"
    # The free-form-phase recommendation is discoverable by name + best_for.
    conv = next(c for c in P.plugin_catalog() if c["id"] == "conversational_rubric")
    assert "free-form" in conv["name"].lower() or "free-form" in conv["help"]["best_for"].lower()


def test_registry_lookup():
    assert P.has_plugin("coverage_tags")
    assert not P.has_plugin("nope")
    assert P.get_plugin("coverage_tags").id == "coverage_tags"
    try:
        P.get_plugin("nope")
        assert False, "expected KeyError"
    except KeyError:
        pass


def test_coverage_tags_scoring():
    seg = _question_segment(["softmax", "scaling", "qkv"], "It uses softmax over scaled dot products.")
    plug = P.get_plugin("coverage_tags")()
    res = asyncio.run(plug.run(seg, {"marks_per_tag": 2.0}, ctx=EvalContext()))
    assert res.state == "scored"
    assert res.marks_possible == 6.0
    assert res.marks_earned == 2.0  # only "softmax" present
    covered = {b.label for b in res.breakdown if b.detail == "covered"}
    assert covered == {"softmax"}
    assert res.evidence_refs  # points at the candidate turn


def test_coverage_tags_full_marks():
    seg = _question_segment(["a", "b"], "mentions a and b clearly")
    plug = P.get_plugin("coverage_tags")()
    res = asyncio.run(plug.run(seg, {"marks_per_tag": 5.0}, ctx=EvalContext()))
    assert res.marks_earned == res.marks_possible == 10.0


def test_assumptions_unmet_when_no_answer():
    seg = _question_segment(["a"], None)  # no candidate turn
    plug = P.get_plugin("coverage_tags")()
    res = asyncio.run(plug.run(seg, {}, ctx=EvalContext()))
    assert res.state == "assumptions_unmet"
    assert res.view_payload.get("unmet")


def test_assumptions_unmet_when_no_tags():
    seg = _question_segment([], "some answer with no tags configured")
    plug = P.get_plugin("coverage_tags")()
    res = asyncio.run(plug.run(seg, {"required_tags": []}, ctx=EvalContext()))
    assert res.state == "assumptions_unmet"


def test_invalid_config_yields_error_state():
    seg = _question_segment(["a"], "answer")
    plug = P.get_plugin("coverage_tags")()
    res = asyncio.run(plug.run(seg, {"marks_per_tag": -5}, ctx=EvalContext()))  # ge=0 violated
    assert res.state == "error"


def test_rubric_marks_sums_author_defined_options():
    # The rubric is entirely author-defined: the LLM only returns which option
    # NUMBERS apply; the Python script sums the marks. No LLM here → we exercise
    # the pure scoring path directly with a known set of applicable numbers.
    cfg = RubricMarksConfig(criteria=[
        Criterion(description="discusses tradeoffs", marks=2),      # option 1
        Criterion(description="states complexity", marks=1),        # option 2
        Criterion(description="ignores edge cases", marks=-1),      # option 3
    ], min_marks=0)
    plug = P.get_plugin("rubric_marks")()
    # applicable {1, 3} → +2 (opt1) +0 (opt2 not applied) -1 (opt3) = 1;
    # possible = 2 + 1 = 3 (only positive options count toward the max).
    earned, possible, _ = plug._score(cfg, {1, 3})
    assert earned == 1.0
    assert possible == 3.0
    # nothing applicable → 0 earned, possible unchanged
    assert plug._score(cfg, set())[0] == 0.0


def test_rubric_marks_floor_and_cap():
    plug = P.get_plugin("rubric_marks")()
    cfg = RubricMarksConfig(criteria=[
        Criterion(description="major gap", marks=-10),      # option 1
        Criterion(description="above and beyond", marks=3),  # option 2
    ], min_marks=0, max_marks=2)
    # both applied → -10 + 3 = -7, capped to 2 then floored to 0.
    assert plug._score(cfg, {1, 2})[0] == 0.0
    # only option 2 → +3, capped to 2.
    assert plug._score(cfg, {2})[0] == 2.0


def test_rubric_marks_in_catalog():
    assert P.has_plugin("rubric_marks")
    entry = next(c for c in P.plugin_catalog() if c["id"] == "rubric_marks")
    assert entry["view_id"] == "rubric_options"
    assert "criteria" in entry["config_json_schema"]["properties"]
    assert "use_verifier" in entry["config_json_schema"]["properties"]


def test_rubric_marks_judges_by_option_number_with_structured_prompt():
    # Proves (a) the judge is handed a STRUCTURED view (question / initial /
    # follow-ups / verifier), and (b) it returns option NUMBERS which the script
    # sums — by capturing the prompt and stubbing the LLM.
    events = [
        {"kind": "session_started", "payload": {"initial_phase": "tech"}, "ts": "t"},
        {"kind": "question_dispatched", "payload": {"phase_id": "tech", "question_id": "q1",
            "question_text": "Explain attention", "coverage_tags": ["a"]}, "ts": "t"},
        {"kind": "ai_utterance", "payload": {"text": "Explain attention"}, "ts": "t"},
        {"kind": "stt_final", "payload": {"text": "it weights tokens"}, "ts": "t"},
        {"kind": "verifier_classified", "payload": {"intent": "partial_answer", "missing_tags": ["a"]}, "ts": "t"},
        {"kind": "ai_utterance", "payload": {"text": "how is it scaled?"}, "ts": "t"},
        {"kind": "stt_final", "payload": {"text": "by sqrt d_k"}, "ts": "t"},
        {"kind": "session_ended", "payload": {}, "ts": "t"},
    ]
    seg = next(s for _, s in build_segments(events).iter_segments() if s.question_id == "q1")
    captured = {}

    async def fake_llm(system, user):
        captured["system"], captured["user"] = system, user
        return '{"applicable": [2], "notes": {"2": "said sqrt d_k"}}'

    ctx = EvalContext(llm_complete=fake_llm)
    res = asyncio.run(P.get_plugin("rubric_marks")().run(
        seg, {"criteria": [{"description": "mentions weighting", "marks": 1},
                           {"description": "explains scaling", "marks": 2}],
              "use_verifier": True}, ctx=ctx))
    # option 2 applies → +2 (option 1 not returned → +0)
    assert res.state == "scored" and res.marks_earned == 2.0
    assert res.view_payload["applicable"] == [2]
    u = captured["user"]
    assert "QUESTION: Explain attention" in u
    assert "CANDIDATE'S INITIAL ANSWER: it weights tokens" in u
    assert "PROBE: how is it scaled?" in u and "RESPONSE: by sqrt d_k" in u
    assert "2. explains scaling" in u  # options are numbered in the prompt
    assert "LIVE VERIFIER VERDICT:" in u and "missing=['a']" in u


def test_assumptions_carry_author_actionable_flag():
    # The UI shows only author-actionable requirements; runtime/dev preconditions
    # (candidate answer present, LLM key set) are flagged so the UI can hide them.
    dd = next(c for c in P.plugin_catalog() if c["id"] == "dynamic_difficulty")
    by_key = {a["key"]: a for a in dd["assumptions"]}
    assert by_key["difficulty"]["author_actionable"] is True
    assert by_key["coverage_tags"]["author_actionable"] is True
    assert by_key["candidate_answer"]["author_actionable"] is False
    assert by_key["coverage_source"]["author_actionable"] is False


def _run_all():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn()
        print(f"  ok  {fn.__name__}")
    print(f"\n{len(fns)} plugin tests passed.")


if __name__ == "__main__":
    _run_all()
