"""Tests for the rubric/ module + admin rubric endpoints.

Run with: .venv/bin/python -m pytest tests/test_rubric_endpoints.py -v

Coverage:
  - rubric.schema validation rules (dims vocabulary, anchors, weights)
  - rubric.heuristic classification + quarantine guards
  - rubric.storage round-trip + history append
  - GET/POST/PUT /api/rubric/{token} (404, generate-from-cadence, TA edit)
  - heuristic fallback path when no LLM key is configured
"""
from __future__ import annotations

import json
import os

import pytest
import yaml


_CADENCE = """\
total_duration_s: 240
phases:
  - id: warm_up
    duration_s: 30
    intent: Put the candidate at ease and learn what they work on.
    question_mode: generic
    generic_prompts: ["Greet the candidate."]
  - id: technical_questions
    duration_s: 180
    intent: Gauge technical depth on AI fundamentals.
    question_mode: specific
    question_pool:
      - id: q1
        text: Explain attention.
  - id: wrap_up
    duration_s: 30
    intent: Close the interview gracefully and mention next steps.
    question_mode: generic
    generic_prompts: ["Thank the candidate."]
"""


# ── schema ─────────────────────────────────────────────────────────────


def test_schema_rejects_unknown_dimension():
    from features.eval import validate_rubric_dict

    bad = {
        "seniority_bar": "Independent senior engineer.",
        "sections": [{
            "phase_id": "p1", "purpose": "Check enthusiasm levels.",
            "score_dimensions": ["enthusiasm"], "weight": 1.0, "anchors": [],
        }],
    }
    rub, err = validate_rubric_dict(bad)
    assert rub is None
    assert "unknown dimension" in err


def test_schema_rejects_all_quarantined():
    from features.eval import validate_rubric_dict

    bad = {
        "seniority_bar": "Independent senior engineer.",
        "sections": [{
            "phase_id": "p1", "purpose": "Warm up only here.",
            "score_dimensions": [], "weight": 0.0, "anchors": [],
        }],
    }
    rub, err = validate_rubric_dict(bad)
    assert rub is None
    assert "weight > 0" in err


def test_schema_requires_five_anchors_in_order():
    from features.eval import validate_rubric_dict

    bad = {
        "seniority_bar": "Independent senior engineer.",
        "sections": [{
            "phase_id": "p1", "purpose": "Technical depth probing.",
            "score_dimensions": ["technical_depth"], "weight": 1.0,
            "anchors": [{"level": "solid", "description": "Does fine work here."}],
        }],
    }
    rub, err = validate_rubric_dict(bad)
    assert rub is None
    assert "anchors" in err


# ── heuristic ──────────────────────────────────────────────────────────


def test_heuristic_quarantines_warmup_and_wrapup():
    from features.eval import heuristic_rubric

    r = heuristic_rubric(yaml.safe_load(_CADENCE), role="Senior AI Engineer")
    by_id = {s.phase_id: s for s in r.sections}
    assert by_id["warm_up"].weight == 0.0
    assert by_id["wrap_up"].weight == 0.0
    assert by_id["technical_questions"].weight > 0
    assert by_id["technical_questions"].score_dimensions
    assert len(by_id["technical_questions"].anchors) == 5


def test_heuristic_never_quarantines_only_phase():
    from features.eval import heuristic_rubric

    solo = {
        "phases": [{
            "id": "warm_up", "duration_s": 60,
            "intent": "Warm intro chat.", "question_mode": "generic",
        }]
    }
    r = heuristic_rubric(solo)
    assert r.sections[0].weight > 0


def test_heuristic_coding_phase_gets_code_quality():
    from features.eval import heuristic_rubric

    cad = yaml.safe_load(_CADENCE)
    cad["phases"].insert(2, {
        "id": "coding_q1", "duration_s": 600,
        "intent": "Candidate solves a Python question.",
        "question_mode": "generic", "coding_question_ids": ["running_sum"],
    })
    r = heuristic_rubric(cad)
    lens = {s.phase_id: s for s in r.sections}["coding_q1"]
    assert "code_quality" in lens.score_dimensions
    assert lens.weight >= 1.0


# ── fingerprint ────────────────────────────────────────────────────────


def test_fingerprint_ignores_volatile_fields_but_sees_semantic_changes():
    from features.eval import heuristic_rubric, rubric_fingerprint

    r = heuristic_rubric(yaml.safe_load(_CADENCE), role="AI Engineer").model_dump(mode="json")
    fp1 = rubric_fingerprint(r)

    # Volatile metadata changes do NOT change the fingerprint (no false
    # "rubric changed" banners on a no-op re-save).
    resaved = dict(r, generated_at="2099-01-01T00:00:00Z", source="ta_edited")
    assert rubric_fingerprint(resaved) == fp1

    # A semantic edit (weight bump) DOES change it.
    import copy
    edited = copy.deepcopy(r)
    edited["sections"][1]["weight"] = 2.0
    assert rubric_fingerprint(edited) != fp1


# ── storage ────────────────────────────────────────────────────────────


def test_storage_round_trip_and_history(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    # Re-import storage with the env override applied at call time.
    from features.eval import storage

    assert storage.load_rubric("tok1") is None
    storage.save_rubric("tok1", {"version": "1", "marker": "a"})
    assert storage.load_rubric("tok1")["marker"] == "a"
    storage.save_rubric("tok1", {"version": "1", "marker": "b"})
    assert storage.load_rubric("tok1")["marker"] == "b"
    envelope = json.loads((tmp_path / "tok1" / "rubric.json").read_text())
    assert [h["marker"] for h in envelope["history"]] == ["a"]


# ── generator fallback ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_generator_falls_back_to_heuristic_without_llm(monkeypatch):
    import features.eval.generator as gen

    monkeypatch.setattr(gen, "_resolve_llm", lambda: None)
    r = await gen.generate_rubric(cadence_yaml=_CADENCE, role="AI Engineer")
    assert r.source == "heuristic"
    assert [s.phase_id for s in r.sections] == ["warm_up", "technical_questions", "wrap_up"]


# ── admin endpoints ────────────────────────────────────────────────────


@pytest.fixture
def admin_client(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    from fastapi.testclient import TestClient
    from app import auth, main

    client = TestClient(main.app)
    cookie_value = auth.issue_cookie("test_admin")
    client.cookies.set(auth.COOKIE_NAME, cookie_value)
    return client


@pytest.fixture
def seeded_token(admin_client):
    """Insert a minimal session row directly via admin.db."""
    from app import db

    db.init_db()  # TestClient never fires the startup event that creates the schema
    token = "rubrictest0001"
    existing = db.get(token)
    if existing is None:
        db.insert({
            "token": token,
            "candidate_name": "Rubric Test",
            "role": "Senior AI Engineer",
            "jd_text": "Builds LLM systems.",
            "resume_path": "resume.pdf",
            "cadence_yaml": _CADENCE,
            "status": "draft",
            "created_at": db.now_iso(),
        })
    yield token
    try:
        db.delete(token)
    except Exception:
        pass


def test_rubric_get_404_when_missing(admin_client):
    r = admin_client.get("/api/rubric/no-such-token")
    assert r.status_code == 404


def test_rubric_generate_validate_and_put(admin_client, seeded_token, monkeypatch):
    # Force the deterministic path — endpoint behavior must not depend on
    # an LLM key being present in the test environment.
    import features.eval.generator as gen
    monkeypatch.setattr(gen, "_resolve_llm", lambda: None)

    r = admin_client.post(
        f"/api/rubric/{seeded_token}/generate", json={"yaml": _CADENCE}
    )
    assert r.status_code == 200, r.text
    data = r.json()
    assert data["ok"] is True
    rubric = data["rubric"]
    assert [s["phase_id"] for s in rubric["sections"]] == [
        "warm_up", "technical_questions", "wrap_up"
    ]
    assert "technical_depth" in data["dims"]

    # GET now returns it
    r2 = admin_client.get(f"/api/rubric/{seeded_token}")
    assert r2.status_code == 200
    assert r2.json()["rubric"]["sections"][1]["phase_id"] == "technical_questions"

    # TA edit: bump a weight, save via PUT
    rubric["sections"][1]["weight"] = 2.0
    r3 = admin_client.put(f"/api/rubric/{seeded_token}", json={"rubric": rubric})
    assert r3.status_code == 200, r3.text
    saved = r3.json()["rubric"]
    assert saved["source"] == "ta_edited"
    assert saved["sections"][1]["weight"] == 2.0

    # Invalid edit (unknown dim) is rejected with 400
    bad = json.loads(json.dumps(saved))
    bad["sections"][1]["score_dimensions"] = ["vibes"]
    r4 = admin_client.put(f"/api/rubric/{seeded_token}", json={"rubric": bad})
    assert r4.status_code == 400


def test_rubric_generate_rejects_invalid_cadence(admin_client, seeded_token):
    r = admin_client.post(
        f"/api/rubric/{seeded_token}/generate", json={"yaml": "phases: []"}
    )
    assert r.status_code == 400
