"""Unit tests for features/eval/sectioner.py.

Runs either under pytest OR directly as a script
(`python tests/test_sectioner.py`) since pytest isn't always installed in the
runtime venv.
"""
from __future__ import annotations

import json
from pathlib import Path

from features.eval.sectioner import build_segments

FIXTURES = Path(__file__).resolve().parent / "fixtures"


def _read(name: str) -> list[dict]:
    out: list[dict] = []
    with (FIXTURES / name).open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


def _seg(phase, qid):
    return next((s for s in phase.segments if s.question_id == qid), None)


# ── main fixture: phases, question boundaries, multi-party, coding ───────────


def test_phase_tree_shape():
    iv = build_segments(_read("events_segmentation.jsonl"), token="tok")
    assert [p.phase_id for p in iv.phases] == ["warm_up", "tech", "coding"]
    # warm_up: a single generic segment (no questions ever dispatched)
    wu = iv.phases[0]
    assert [s.kind for s in wu.segments] == ["generic"]
    assert wu.segments[0].has_candidate_input()


def test_specific_phase_question_segments():
    iv = build_segments(_read("events_segmentation.jsonl"))
    tech = iv.phases[1]
    assert tech.question_mode == "specific"
    qids = [s.question_id for s in tech.segments if s.kind == "question"]
    # rag_basic appears once despite the duplicate (barge-in) marker
    assert qids == ["attn_basic", "rag_basic"], qids
    # a warm-up segment holds the phase-intro chatter before the first question
    assert tech.segments[0].kind == "warmup"


def test_segment_carries_all_parties_and_metadata():
    iv = build_segments(_read("events_segmentation.jsonl"))
    tech = iv.phases[1]
    attn = _seg(tech, "attn_basic")
    speakers = {t.speaker for t in attn.turns}
    # candidate, AI, and verifier turns are all captured as evidence
    assert {"candidate", "ai", "verifier"} <= speakers, speakers
    assert attn.difficulty == "medium"
    assert attn.coverage_tags == ["qkv roles", "softmax weighting"]
    # the verifier's missed-tag note survives into turn.meta
    vt = attn.verifier_turns()[0]
    assert vt.meta.get("missing_tags") == ["softmax weighting"]
    # observer/TA turn is captured in the rag segment
    rag = _seg(tech, "rag_basic")
    assert any(t.speaker == "interviewer_ta" for t in rag.turns)


def test_coding_segments_route_by_question_id():
    iv = build_segments(_read("events_segmentation.jsonl"))
    coding = iv.phases[2]
    assert coding.question_mode == "coding"
    codes = {s.question_id: s for s in coding.segments if s.kind == "coding"}
    assert set(codes) == {"running_sum", "two_sum"}
    # running_sum: one submission (2/2 passed)
    rs_sub = [t for t in codes["running_sum"].turns if t.kind == "coding_code_submitted"]
    assert len(rs_sub) == 1 and rs_sub[0].meta["passed"] == 2 and rs_sub[0].meta["total"] == 2
    # two_sum: a hint (ai) AND a submission (candidate) routed to the right segment
    two = codes["two_sum"]
    assert any(t.kind == "coding_hint_delivered" for t in two.turns)
    assert any(t.kind == "coding_code_submitted" and t.meta["passed"] == 1 for t in two.turns)


def test_event_index_monotonic_and_matches_lines():
    events = _read("events_segmentation.jsonl")
    iv = build_segments(events)
    for _, s in iv.iter_segments():
        # within a segment, turns are in chronological (non-decreasing) order
        idxs = [t.event_index for t in s.turns]
        assert idxs == sorted(idxs), f"{s.segment_id} turns out of order: {idxs}"
        # turn indices stay within the segment's [start, end] span
        for t in s.turns:
            assert s.start_event_index <= t.event_index <= s.end_event_index
            # every index points at a real event row of the expected kind
            assert 0 <= t.event_index < len(events)
            assert events[t.event_index]["kind"] == t.kind


def test_two_session_ended_does_not_truncate():
    # The coding phase (last) must still be sealed past the first session_ended.
    iv = build_segments(_read("events_segmentation.jsonl"))
    coding = iv.phases[2]
    assert coding.end_event_index >= coding.start_event_index
    # both submissions survived (nothing dropped by an early break)
    subs = [t for _, s in iv.iter_segments() for t in s.turns if t.kind == "coding_code_submitted"]
    assert len(subs) == 2


# ── old-log fallback (no question_dispatched markers) ────────────────────────


def test_oldlog_falls_back_to_whole_phase_segment():
    iv = build_segments(_read("events_segmentation_oldlog.jsonl"))
    assert [p.phase_id for p in iv.phases] == ["tech"]
    tech = iv.phases[0]
    # no markers → a single generic segment holding all the Q&A
    assert [s.kind for s in tech.segments] == ["generic"]
    cand = tech.segments[0].candidate_turns()
    assert len(cand) == 2


# ── adaptive_question_asked alias (old adaptive logs) ────────────────────────


def test_adaptive_alias_creates_question_segments():
    events = [
        {"kind": "session_started", "payload": {"initial_phase": "tech"}, "ts": "t0"},
        {"kind": "adaptive_question_asked", "payload": {"phase": "tech", "question_id": "q1", "difficulty": "easy"}, "ts": "t1"},
        {"kind": "ai_utterance", "payload": {"text": "easy q"}, "ts": "t2"},
        {"kind": "stt_final", "payload": {"text": "easy answer"}, "ts": "t3"},
        {"kind": "adaptive_question_asked", "payload": {"phase": "tech", "question_id": "q2", "difficulty": "hard"}, "ts": "t4"},
        {"kind": "ai_utterance", "payload": {"text": "hard q"}, "ts": "t5"},
        {"kind": "stt_final", "payload": {"text": "hard answer"}, "ts": "t6"},
        {"kind": "session_ended", "payload": {}, "ts": "t7"},
    ]
    iv = build_segments(events)
    tech = iv.phases[0]
    qids = [s.question_id for s in tech.segments if s.kind == "question"]
    assert qids == ["q1", "q2"], qids


def test_structured_qa_splits_question_answer_followups():
    events = [
        {"kind": "session_started", "payload": {"initial_phase": "tech"}, "ts": "t"},
        {"kind": "question_dispatched", "payload": {"phase_id": "tech", "question_id": "q1",
            "question_text": "Explain X", "coverage_tags": ["a"]}, "ts": "t"},
        {"kind": "ai_utterance", "payload": {"text": "Explain X"}, "ts": "t"},
        {"kind": "stt_final", "payload": {"text": "initial ans"}, "ts": "t"},
        {"kind": "verifier_classified", "payload": {"intent": "partial_answer", "missing_tags": ["a"]}, "ts": "t"},
        {"kind": "ai_utterance", "payload": {"text": "probe more?"}, "ts": "t"},
        {"kind": "stt_final", "payload": {"text": "followup ans"}, "ts": "t"},
        {"kind": "session_ended", "payload": {}, "ts": "t"},
    ]
    seg = next(s for _, s in build_segments(events).iter_segments() if s.question_id == "q1")
    qa = seg.structured_qa()
    assert qa["question"] == "Explain X"
    assert qa["initial_answer"] == "initial ans"
    assert len(qa["follow_ups"]) == 1 and qa["follow_ups"][0]["answer"] == "followup ans"
    assert qa["verifier_missing"] == ["a"]


def test_empty_event_stream():
    iv = build_segments([])
    assert iv.phases == []


def _run_all():
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for fn in fns:
        fn()
        print(f"  ok  {fn.__name__}")
    print(f"\n{len(fns)} sectioner tests passed.")


if __name__ == "__main__":
    _run_all()
