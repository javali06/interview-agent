"""LiveKitAudioSink honours the same contract as BrowserSpeakerAudioSink.

The brain keys the silence timer and the wrap-up hold off the sink's playout
ack and bytes_buffered(); on LiveKit those must behave exactly as on the
WebSocket path or the farewell gets cut off again. Runs on a fake rtc, so no
LiveKit SDK or network is needed (the live check is a separate manual run).
"""
import asyncio

import pytest

from engine.orchestrator.livekit.transport import LiveKitAudioSink


class _Frame:
    def __init__(self, data, rate, channels, samples):
        assert len(data) == samples * 2 * channels
        self.data, self.rate, self.samples = bytes(data), rate, samples


class _Rtc:
    AudioFrame = _Frame


class _OutSource:
    def __init__(self):
        self.frames, self.cleared = [], 0
        self.gate = asyncio.Event()
        self.gate.set()

    async def capture_frame(self, frame):
        await self.gate.wait()
        self.frames.append(frame)

    def clear_queue(self):
        self.cleared += 1

    queued_duration = 0.0


class _Transport:
    def __init__(self):
        self._rtc = _Rtc()
        self._out_source = _OutSource()
        self._out_rate = 16000


async def _settle():
    for _ in range(20):
        await asyncio.sleep(0)


@pytest.mark.asyncio
async def test_play_sync_sends_whole_20ms_frames_in_order():
    t = _Transport()
    sink = LiveKitAudioSink(t)
    pcm = bytes(range(256)) * 10            # 2560 bytes, not a multiple of 640
    sink.play_sync(pcm[:1001])              # odd length: last byte carried over
    sink.play_sync(pcm[1001:])
    await _settle()
    sent = b"".join(f.data for f in t._out_source.frames)
    assert sent == pcm
    assert all(len(f.data) <= 640 and len(f.data) % 2 == 0 for f in t._out_source.frames)


@pytest.mark.asyncio
async def test_busy_until_both_sent_and_acked():
    t = _Transport()
    sink = LiveKitAudioSink(t)
    t._out_source.gate.clear()              # LiveKit hasn't taken the audio yet
    sink.expect_playout("u1")
    sink.play_sync(b"\x01\x00" * 1600)
    assert sink.bytes_buffered() > 0 and not sink.playout_done_event.is_set()

    sink.mark_played("u1")                  # browser acked, but audio still queued here
    assert sink.playout_done_event.is_set()
    assert sink.bytes_buffered() > 0

    t._out_source.gate.set()
    await _settle()
    assert sink.bytes_buffered() == 0


@pytest.mark.asyncio
async def test_ack_for_a_stale_utterance_does_not_release_the_wait():
    sink = LiveKitAudioSink(_Transport())
    sink.expect_playout("u1")
    sink.expect_playout("u2")
    sink.mark_played("u1")
    assert sink.bytes_buffered() == 1 and not sink.playout_done_event.is_set()
    sink.mark_played("u2")
    assert sink.bytes_buffered() == 0


@pytest.mark.asyncio
async def test_flush_drops_queued_audio_and_releases_the_wait():
    t = _Transport()
    sink = LiveKitAudioSink(t)
    t._out_source.gate.clear()
    sink.expect_playout("u1")
    sink.play_sync(b"\x01\x00" * 16000)     # 2 s queued behind the closed gate
    await _settle()
    await sink.flush()
    assert sink.bytes_buffered() == 0
    assert sink.playout_done_event.is_set()
    assert sink.remaining_playout_s() == 0.0
    assert t._out_source.cleared == 1

    t._out_source.gate.set()
    await _settle()
    # At most the one frame already handed to capture_frame gets through.
    assert len(t._out_source.frames) <= 1


@pytest.mark.asyncio
async def test_remaining_playout_tracks_real_time_duration():
    sink = LiveKitAudioSink(_Transport())
    sink.play_sync(b"\x00\x00" * 16000)     # 1 s of audio
    assert 0.9 < sink.remaining_playout_s() <= 1.0


def test_session_uses_the_non_blocking_path():
    # InterviewSession._on_pcm falls back to one create_task(play()) per chunk
    # when play_sync is missing — the pattern that piled up tasks before.
    assert callable(getattr(LiveKitAudioSink, "play_sync", None))


# ── the source follows the candidate's newest mic track ──────────────────────
# A refresh rejoins the room with the same identity: LiveKit drops the old
# participant and the candidate publishes a NEW track. The brain must hear it.

class _Stream:
    """Stands in for rtc.AudioStream: yields the frames its track was given,
    then blocks like a live track (until cancelled)."""
    def __init__(self, track, **kw):
        self._frames = list(track.frames)

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self._frames:
            data = self._frames.pop(0)
            return type("E", (), {"frame": type("F", (), {"data": data})()})()
        await asyncio.Event().wait()

    async def aclose(self):
        pass


class _Track:
    def __init__(self, *frames):
        self.frames = list(frames)


def _source():
    from engine.orchestrator.livekit.transport import LiveKitAudioSource
    t = _Transport()
    t._rtc.AudioStream = _Stream
    return LiveKitAudioSource(t)


async def _take(src, n):
    out, it = [], src.frames().__aiter__()
    for _ in range(n):
        out.append(await asyncio.wait_for(it.__anext__(), 1))
    return out


@pytest.mark.asyncio
async def test_source_switches_to_the_new_track_after_a_refresh():
    src = _source()
    await src.start()
    src._follow(_Track(b"old1", b"old2"))
    assert await _take(src, 2) == [b"old1", b"old2"]
    src._follow(_Track(b"new1"))          # the refreshed page's track
    assert await _take(src, 1) == [b"new1"]


@pytest.mark.asyncio
async def test_source_drops_audio_from_before_the_interview_started():
    # While the candidate joins (before the greeting), their audio answers nothing.
    src = _source()
    src._follow(_Track(b"early"))
    await _settle()
    await src.start()
    src._follow(_Track(b"after-start"))
    assert await _take(src, 1) == [b"after-start"]


@pytest.mark.asyncio
async def test_source_ends_cleanly_on_stop():
    src = _source()
    await src.start()
    src._follow(_Track())
    await src.stop()
    assert [f async for f in src.frames()] == []


def test_egress_needs_all_three_settings_and_can_be_switched_off(monkeypatch):
    from engine.orchestrator.livekit import egress
    for k, v in (("LIVEKIT_EGRESS_AZURE_ACCOUNT_NAME", "acct"),
                 ("LIVEKIT_EGRESS_AZURE_ACCOUNT_KEY", "k"),
                 ("LIVEKIT_EGRESS_AZURE_CONTAINER", "sessions")):
        monkeypatch.setenv(k, v)
    monkeypatch.delenv("LIVEKIT_EGRESS", raising=False)
    assert egress.egress_settings() == egress.EgressSettings("acct", "k", "sessions")
    monkeypatch.setenv("LIVEKIT_EGRESS", "0")
    assert egress.egress_settings() is None
    monkeypatch.delenv("LIVEKIT_EGRESS")
    monkeypatch.delenv("LIVEKIT_EGRESS_AZURE_ACCOUNT_KEY")
    assert egress.egress_settings() is None
    # Next to the browser recording, so one listing finds both — one file per
    # runner, so the replica that resumes a handed-off interview can't overwrite
    # what was recorded before the hand-off.
    assert egress.egress_blob_name("tok", 1700000000.7) == "tok/recording/livekit-audio-1700000000.ogg"
    assert egress.egress_part_names([
        "tok/recording/livekit-audio-200.ogg", "tok/recording/screen.webm",
        "tok/recording/livekit-audio.ogg", "tok/recording/livekit-audio-100.ogg",
    ]) == ["tok/recording/livekit-audio.ogg", "tok/recording/livekit-audio-100.ogg",
           "tok/recording/livekit-audio-200.ogg"]


# ── the source heals a reader stuck on a dead stream ─────────────────────────
# Seen live: after the agent's room connection was rebuilt on a flaky network,
# no candidate audio arrived again, so the speech detector waited forever for
# the end of a sentence and the interview froze.

class _Pub:
    def __init__(self, track, muted=False):
        self.track, self.muted = track, muted


class _Participant:
    def __init__(self, pub):
        self.track_publications = {"TR_1": pub}


def _healing_source(monkeypatch, *, muted):
    from engine.orchestrator.livekit.transport import LiveKitAudioSource
    t = _Transport()
    opened = []

    class _Stream2(_Stream):
        def __init__(self, track, **kw):
            opened.append(track)
            # The first reader is stuck (yields nothing); a re-read works.
            self._frames = [] if len(opened) == 1 else [b"\x10\x00" * 320]

    class _RemoteAudioTrack(_Track):
        pass
    t._rtc.AudioStream = _Stream2
    t._rtc.RemoteAudioTrack = _RemoteAudioTrack
    track = _RemoteAudioTrack()
    t._room = type("R", (), {"remote_participants": {"candidate-tab": _Participant(_Pub(track, muted))}})()
    t._cand_track = track
    monkeypatch.setattr(LiveKitAudioSource, "_STALL_S", 0.3)
    src = LiveKitAudioSource(t)
    return src, track, opened


@pytest.mark.asyncio
async def test_a_stalled_reader_is_restarted_and_audio_flows_again(monkeypatch):
    src, track, opened = _healing_source(monkeypatch, muted=False)
    await src.start()
    src._follow(track)
    got = await asyncio.wait_for(src.frames().__anext__(), 3)
    assert got == b"\x10\x00" * 320
    assert len(opened) == 2 and src.stats()["stall_heals"] == 1
    assert src.mic_health()["packets_in"] == 1
    await src.stop()


@pytest.mark.asyncio
async def test_a_muted_candidate_is_not_healed(monkeypatch):
    src, track, opened = _healing_source(monkeypatch, muted=True)
    await src.start()
    src._follow(track)
    await asyncio.sleep(1.5)
    assert len(opened) == 1 and src.stats()["stall_heals"] == 0
    await src.stop()
