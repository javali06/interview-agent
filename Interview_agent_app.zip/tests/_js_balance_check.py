"""Lightweight static checks on JS files we edited.

A character-by-character tokenizer (not a full parser) that correctly skips
strings, template literals (including ${...} substitutions), line + block
comments, and regex literals. Then counts () [] {} and reports imbalances.

Catches missing/extra braces after edits — the common refactor mistake.
"""
from __future__ import annotations

import sys
from pathlib import Path


JS_FILES = [
    "app/static/admin.js",
    "ui/candidate/coding/coding_panel.js",
    "ui/candidate/app.js",
]

# When the previous non-whitespace token ends with one of these, a `/` is
# the start of a regex literal. Otherwise it's division.
REGEX_PREV_END = set("([{,;=:!&|?+-*^~<>")
REGEX_PREV_KEYWORDS = {
    "return", "typeof", "in", "of", "void", "delete", "new",
    "throw", "case", "yield", "await", "do", "else",
}


def check(text: str) -> tuple[dict[str, int], list[str]]:
    """Return (counts, errors). counts has 'paren', 'bracket', 'brace' keys
    holding signed open-minus-close balance; positive = unclosed opens,
    negative = extra closes. errors is a list of string descriptions."""
    counts = {"paren": 0, "bracket": 0, "brace": 0}
    errors: list[str] = []
    i = 0
    n = len(text)
    # Track previous non-whitespace token ending — needed for regex vs div.
    prev_nonws = ""
    # Track context for template substitutions: stack of "${" we're inside.
    # When we hit `}` inside one, we resume scanning the template string.
    template_depth: list[int] = []  # holds brace depth at template entry

    def is_regex_position() -> bool:
        # Walk back from prev_nonws to find the token ending.
        if not prev_nonws:
            return True  # start of file
        last = prev_nonws[-1]
        if last in REGEX_PREV_END:
            return True
        # Word token — check keyword
        # Walk back to find the start of the word.
        j = len(prev_nonws) - 1
        while j >= 0 and (prev_nonws[j].isalnum() or prev_nonws[j] == "_"):
            j -= 1
        word = prev_nonws[j + 1:]
        if word in REGEX_PREV_KEYWORDS:
            return True
        return False

    while i < n:
        c = text[i]
        # Comments
        if c == "/" and i + 1 < n and text[i + 1] == "/":
            j = text.find("\n", i + 2)
            i = n if j == -1 else j + 1
            continue
        if c == "/" and i + 1 < n and text[i + 1] == "*":
            j = text.find("*/", i + 2)
            i = n if j == -1 else j + 2
            continue
        # Strings (single + double)
        if c in ("'", '"'):
            quote = c
            i += 1
            while i < n:
                if text[i] == "\\":
                    i += 2
                    continue
                if text[i] == quote:
                    i += 1
                    break
                i += 1
            prev_nonws = quote  # treat as a closed token (value)
            continue
        # Template literals — handle ${...} substitutions
        if c == "`":
            i += 1
            while i < n:
                if text[i] == "\\":
                    i += 2
                    continue
                if text[i] == "`":
                    i += 1
                    break
                if text[i] == "$" and i + 1 < n and text[i + 1] == "{":
                    # Enter substitution; ${ pushes a marker. The matching }
                    # will be balanced against {. Use the brace counter
                    # naturally; just remember to resume in template mode
                    # when this substitution closes.
                    template_depth.append(counts["brace"])
                    counts["brace"] += 1
                    i += 2
                    # Switch to "in substitution" — just recurse the outer
                    # loop by setting a sentinel. Easiest: break and let
                    # outer loop handle. We use a substring trick instead:
                    # scan inner content with recursive parse until brace
                    # depth returns to template_depth top.
                    # We do this by continuing the outer loop with the
                    # template flag — but our state is implicit. Simplest
                    # correct path: process the substitution inline.
                    sub_target = template_depth[-1] + 1
                    while i < n and counts["brace"] >= sub_target:
                        cc = text[i]
                        if cc == "{":
                            counts["brace"] += 1
                            i += 1
                            continue
                        if cc == "}":
                            counts["brace"] -= 1
                            i += 1
                            continue
                        # Recurse-ish: re-use the top of loop logic for
                        # strings / regex / etc. We handle the most common
                        # cases inline; for simplicity skip rare nested
                        # template literals (unlikely in admin.js).
                        if cc == "'" or cc == '"':
                            q = cc
                            i += 1
                            while i < n and text[i] != q:
                                if text[i] == "\\":
                                    i += 2
                                else:
                                    i += 1
                            i += 1
                            continue
                        if cc == "(":
                            counts["paren"] += 1; i += 1; continue
                        if cc == ")":
                            counts["paren"] -= 1; i += 1; continue
                        if cc == "[":
                            counts["bracket"] += 1; i += 1; continue
                        if cc == "]":
                            counts["bracket"] -= 1; i += 1; continue
                        i += 1
                    template_depth.pop()
                    continue
                i += 1
            prev_nonws = "`"
            continue
        # Regex literal (heuristic)
        if c == "/" and is_regex_position():
            i += 1
            in_class = False
            while i < n:
                if text[i] == "\\":
                    i += 2
                    continue
                if text[i] == "[":
                    in_class = True
                    i += 1
                    continue
                if text[i] == "]":
                    in_class = False
                    i += 1
                    continue
                if text[i] == "/" and not in_class:
                    i += 1
                    # Skip flags
                    while i < n and text[i].isalpha():
                        i += 1
                    break
                if text[i] == "\n":
                    # Unterminated — bail
                    break
                i += 1
            prev_nonws = "/"
            continue
        # Bracket counting
        if c == "(":
            counts["paren"] += 1
        elif c == ")":
            counts["paren"] -= 1
        elif c == "[":
            counts["bracket"] += 1
        elif c == "]":
            counts["bracket"] -= 1
        elif c == "{":
            counts["brace"] += 1
        elif c == "}":
            counts["brace"] -= 1
        # Update prev_nonws if c is non-whitespace
        if not c.isspace():
            prev_nonws = (prev_nonws + c)[-32:]
        i += 1

    if counts["paren"] != 0:
        errors.append(f"() imbalance: {counts['paren']} (positive = unclosed opens)")
    if counts["bracket"] != 0:
        errors.append(f"[] imbalance: {counts['bracket']}")
    if counts["brace"] != 0:
        errors.append(f"{{}} imbalance: {counts['brace']}")
    return counts, errors


def main() -> int:
    root = Path(__file__).resolve().parent.parent
    all_errors = 0
    for rel in JS_FILES:
        p = root / rel
        if not p.exists():
            print(f"MISSING: {rel}")
            all_errors += 1
            continue
        text = p.read_text(encoding="utf-8", errors="replace")
        counts, errs = check(text)
        if errs:
            print(f"FAIL: {rel}")
            for e in errs:
                print(f"  - {e}")
            all_errors += 1
        else:
            print(f"OK: {rel} ({len(text)} bytes, {text.count(chr(10))} lines)")
    print()
    if all_errors:
        print(f"{all_errors} file(s) with imbalance — investigate.")
        return 1
    print("All bracket/brace/paren pairs balanced (regex-aware, template-aware).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
