"""LiveKit on /session-info, and who gets a room token.

1. `livekit-api` (token minting) must be in the requirements the tiered images
   install (it once was only in the monolith's file).
2. The candidate's /session-info is answered by the GATEWAY (app.main); both
   handlers call one helper, `livekit_offer`, so they cannot drift.
3. Phase 2: /session-info only OFFERS LiveKit — it carries no token. It is
   unauthenticated and answers every tab, so a token there would let a second
   tab join the room as the candidate. The token comes from the shard, per tab,
   after the one-tab check (`candidate_room_access`).

Both are given ONLY for a real, live interview — LiveKit bills by the minute.

Run with: .venv/bin/python -m pytest tests/test_livekit_session_info.py -v
"""
from __future__ import annotations

from pathlib import Path

import pytest

pytest.importorskip("livekit.api")  # minting needs livekit-api

REPO = Path(__file__).resolve().parents[1]

_ENV = {
    "MEDIA_TRANSPORT": "livekit",
    "LIVEKIT_URL": "wss://test-project.livekit.cloud",
    "LIVEKIT_API_KEY": "APItestkey00000",
    "LIVEKIT_API_SECRET": "s" * 43,
}


@pytest.fixture
def livekit_on(monkeypatch):
    for k, v in _ENV.items():
        monkeypatch.setenv(k, v)


@pytest.fixture
def livekit_off(monkeypatch):
    for k, v in _ENV.items():
        monkeypatch.setenv(k, v)
    monkeypatch.delenv("MEDIA_TRANSPORT")


def _claims(token: str) -> dict:
    import jwt  # PyJWT, installed by livekit-api

    return jwt.decode(token, _ENV["LIVEKIT_API_SECRET"], algorithms=["HS256"])


def _row(status="ready", **extra):
    return {"status": status, "role": "AI Engineer", "is_template": False, **extra}


# ── gap 1: the package is where the tiered images will install it ──────────
def test_livekit_api_is_in_the_requirements_every_tier_installs():
    """Every tier image is FROM the base image, which installs base.txt — so a
    package in base.txt is in the gateway AND the session shard, the two tiers
    that mint. deploy/requirements.txt is the monolith's file and does not count."""
    base = (REPO / "deploy/requirements/base.txt").read_text().splitlines()
    pins = [l.strip() for l in base if l.strip().startswith("livekit-api")]
    assert pins, "livekit-api must be in deploy/requirements/base.txt"
    assert "deploy/requirements/base.txt" in (REPO / "deploy/Dockerfile.base").read_text()


# ── the offer, and the per-tab token ───────────────────────────────────────
@pytest.mark.parametrize("status", ["ready", "in_progress"])
def test_a_live_interview_is_offered_livekit_without_a_token(livekit_on, status):
    from engine.orchestrator.livekit.tokens import livekit_offer

    assert livekit_offer("tok-123", _row(status)) == {"enabled": True}


@pytest.mark.parametrize("status", ["ready", "in_progress"])
def test_the_room_token_is_for_this_room_and_this_tab_only(livekit_on, status):
    from engine.orchestrator.livekit.tokens import candidate_room_access

    info = candidate_room_access("tok-123", "tab-a1", _row(status))
    assert info["url"] == _ENV["LIVEKIT_URL"]
    c = _claims(info["token"])
    assert c["iss"] == _ENV["LIVEKIT_API_KEY"]
    assert c["sub"] == "candidate-tab-a1", "one identity per tab: a refresh rejoins as itself"
    assert c["name"] == "AI Engineer"
    video = c["video"]
    assert video["room"] == "tok-123", "the token must be scoped to THIS interview's room"
    assert video.get("roomJoin") is True
    assert video.get("canPublishData") is True, "control messages ride the data channel"


def test_a_tab_id_cannot_smuggle_characters_into_the_identity(livekit_on):
    from engine.orchestrator.livekit.tokens import candidate_identity

    assert candidate_identity("tab/../agent") == "candidate-tabagent"
    assert candidate_identity("") == "candidate-tab"
    assert len(candidate_identity("x" * 500)) <= len("candidate-") + 40


def test_switch_off_means_no_livekit_block(livekit_off):
    from engine.orchestrator.livekit.tokens import livekit_offer

    assert livekit_offer("tok-123", _row()) is None


def test_incomplete_credentials_mean_no_livekit(livekit_on, monkeypatch):
    from engine.orchestrator.livekit.tokens import candidate_room_access, livekit_offer

    monkeypatch.setenv("LIVEKIT_API_SECRET", "")
    assert livekit_offer("tok-123", _row()) is None
    assert candidate_room_access("tok-123", "tab", _row()) is None


@pytest.mark.parametrize("row", [
    None,                                   # no such interview
    _row("draft"),                          # no link issued yet
    _row("generating"),
    _row("completed"),                      # over
    _row("cancelled"),
    _row("ready", is_template=True),        # a role's plan, not an interview
])
def test_livekit_is_offered_only_for_a_real_live_interview(livekit_on, row):
    """The endpoint is open, so offering for any string would hand out free
    rooms on our LiveKit account."""
    from engine.orchestrator.livekit.tokens import livekit_offer

    assert livekit_offer("tok-123", row) is None


@pytest.mark.parametrize("row", [None, _row("cancelled"), _row("ready", is_template=True)])
def test_the_shard_never_mints_for_unknown_cancelled_or_template(livekit_on, row):
    from engine.orchestrator.livekit.tokens import candidate_room_access

    assert candidate_room_access("tok-123", "tab", row) is None


def test_a_handed_off_interview_reading_completed_still_gets_its_room(livekit_on):
    """A crashed or handed-off runner's teardown can leave `completed` on a
    resumable interview; the shard has already decided it may run
    (interview_over), so the token helper must not refuse it — that refusal
    once turned every resume into a hand-off loop."""
    from engine.orchestrator.livekit.tokens import candidate_room_access

    assert candidate_room_access("tok-123", "tab", _row("completed")) is not None


def test_no_room_means_nothing(livekit_on):
    from engine.orchestrator.livekit.tokens import livekit_offer

    assert livekit_offer(None, _row()) is None
    assert livekit_offer("", _row()) is None


def test_a_failed_mint_degrades_to_the_websocket(livekit_on, monkeypatch):
    from engine.orchestrator.livekit import tokens

    def _boom(*a, **k):
        raise RuntimeError("signing failed")

    monkeypatch.setattr(tokens, "candidate_token", _boom)
    assert tokens.candidate_room_access("tok-123", "tab", _row()) is None


# ── the handler the candidate actually reaches carries it ───────────
@pytest.fixture
def gateway(tmp_path, monkeypatch):
    """app.main is what the gateway serves (deploy/gateway_app.py imports it)."""
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    from db.engine import create_all, reset_engine

    reset_engine()
    create_all()
    from fastapi.testclient import TestClient
    from app import db as admin_db
    from app import main

    base = dict(candidate_name="Jane", role="AI Engineer", jd_path=None, jd_text=None,
                resume_path="r.txt", cadence_requirements_path=None,
                cadence_requirements_text=None, cadence_yaml="phases: []\n",
                pid=None, ws_port=None, http_port=None, created_at=admin_db.now_iso(),
                started_at=None, ended_at=None, event_log_path="events.jsonl",
                record_enabled=True, modality="voice", is_template=False)
    admin_db.insert({**base, "token": "live-tok", "status": "ready"})
    admin_db.insert({**base, "token": "done-tok", "status": "completed"})
    return TestClient(main.app)


def test_the_gateway_session_info_offers_the_room_but_no_token(gateway, livekit_on):
    body = gateway.get("/session-info", params={"token": "live-tok"}).json()
    assert body["livekit"] == {"enabled": True}, (
        "the gateway's /session-info is what the candidate reaches — without the "
        "offer the page never tries LiveKit")
    assert "token" not in body["livekit"], "a token here would let any tab join as the candidate"
    # The fields the lobby already depended on are untouched.
    assert body["role"] == "AI Engineer" and body["modality"] == "voice"


def test_the_gateway_refuses_finished_and_unknown_interviews(gateway, livekit_on):
    assert gateway.get("/session-info", params={"token": "done-tok"}).json()["livekit"] is None
    assert gateway.get("/session-info", params={"token": "made-up"}).json()["livekit"] is None


def test_the_gateway_stays_on_websocket_when_the_switch_is_off(gateway, livekit_off):
    assert gateway.get("/session-info", params={"token": "live-tok"}).json()["livekit"] is None
