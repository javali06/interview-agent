"""Quick check that python-dotenv strips quotes from AZURE_SPEECH_KEY."""
from dotenv import dotenv_values

v = dotenv_values(".env")
ak = v.get("AZURE_SPEECH_KEY", "")
print("AZURE_SPEECH_KEY parsed length:", len(ak))
print("First 4:", repr(ak[:4]))
print("Last 4:", repr(ak[-4:]))
print("Starts with quote?", ak.startswith('"'))
print("AZURE_SPEECH_REGION:", repr(v.get("AZURE_SPEECH_REGION")))
print("AZURE_SPEECH_VOICE:", repr(v.get("AZURE_SPEECH_VOICE")))
