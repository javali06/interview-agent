"""A page that starts recording again (the candidate refreshed, or reopened the
link on a new device after a crash) must not overwrite what was recorded
before. Each fresh start asks for `part=new` and gets the next free part; an
interview recorded in one go stays in the original `<kind>.webm`."""
from __future__ import annotations

import pytest


@pytest.fixture
def client(tmp_path, monkeypatch):
    monkeypatch.setenv("SESSIONS_DIR", str(tmp_path))
    monkeypatch.delenv("BLOB_ENABLED", raising=False)
    import app.paths
    monkeypatch.setattr(app.paths, "SESSIONS_DIR", tmp_path)
    from db.engine import create_all, reset_engine
    reset_engine()
    create_all()
    from app import db, main
    db.insert({"token": "tok", "candidate_name": "Jane", "role": "AI Engineer",
               "resume_path": "", "cadence_yaml": "", "status": "in_progress",
               "created_at": db.now_iso()})
    monkeypatch.setattr(main.auth, "get_current_user", lambda r: "admin@example.com")
    from fastapi.testclient import TestClient
    return TestClient(main.app), tmp_path


def _up(c, kind, seq, data, part=None):
    q = {"kind": kind, "seq": seq}
    if part is not None:
        q["part"] = part
    r = c.post("/api/sessions/tok/recording", params=q, files={"file": ("x.webm", data)})
    assert r.status_code == 200
    return r.json()["part"]


def test_one_go_recording_keeps_its_original_name(client):
    c, root = client
    assert _up(c, "screen", 0, b"AA", "new") == 0
    _up(c, "screen", 1, b"BB", 0)
    assert (root / "tok/recording/screen.webm").read_bytes() == b"AABB"


def test_a_refresh_starts_a_new_part_and_keeps_the_old_one(client):
    c, root = client
    _up(c, "screen", 0, b"before", "new")
    _up(c, "screen", 1, b"-more", 0)
    # The page reloads: its sequence restarts at 0.
    assert _up(c, "screen", 0, b"after", "new") == 1
    _up(c, "screen", 1, b"-more", 1)
    assert (root / "tok/recording/screen.webm").read_bytes() == b"before-more"
    assert (root / "tok/recording/screen.part1.webm").read_bytes() == b"after-more"
    # Tracks are independent: the camera still starts at part 0.
    assert _up(c, "camera", 0, b"cam", "new") == 0


def test_a_page_without_parts_behaves_as_before(client):
    # An old bundle still open mid-deploy sends no part: seq 0 recreates part 0.
    c, root = client
    _up(c, "camera", 0, b"one")
    _up(c, "camera", 0, b"two")
    assert (root / "tok/recording/camera.webm").read_bytes() == b"two"


def test_parts_are_listed_and_each_one_downloads(client):
    c, _ = client
    _up(c, "screen", 0, b"first", "new")
    _up(c, "screen", 0, b"second", "new")
    _up(c, "camera", 0, b"cam", "new")
    assert c.get("/api/sessions/tok/recording-parts").json() == {
        "camera": [0], "screen": [0, 1], "livekit": [], "livekit_parts": []}
    assert c.get("/api/sessions/tok/recording/screen").content == b"first"
    assert c.get("/api/sessions/tok/recording/screen", params={"part": 1}).content == b"second"


def test_part_listing_needs_an_admin(client, monkeypatch):
    c, _ = client
    from app import main
    monkeypatch.setattr(main.auth, "get_current_user", lambda r: None)
    assert c.get("/api/sessions/tok/recording-parts").status_code == 401


def test_server_recordings_are_listed_in_order_and_served_as_audio(client):
    # LiveKit egress writes them straight to storage; the page never uploads them.
    # Two parts: the interview was handed off to another replica mid-way.
    c, root = client
    rec = root / "tok/recording"
    rec.mkdir(parents=True, exist_ok=True)
    (rec / "livekit-audio-200.ogg").write_bytes(b"OggS-second")
    (rec / "livekit-audio-100.ogg").write_bytes(b"OggS-first")
    assert c.get("/api/sessions/tok/recording-parts").json()["livekit"] == [0, 1]
    first = c.get("/api/sessions/tok/recording/livekit", params={"part": 0})
    assert first.status_code == 200 and first.content == b"OggS-first"
    assert first.headers["content-type"].startswith("audio/ogg")
    assert c.get("/api/sessions/tok/recording/livekit", params={"part": 1}).content == b"OggS-second"
    assert c.get("/api/sessions/tok/recording/livekit", params={"part": 2}).status_code == 404
