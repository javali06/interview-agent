"""Tests for the Visual Scenario Analysis glue added to `Director`
(engine/brain/core/director.py) — the pieces that are pure/synchronous and
don't require driving the full async tick loop (there is no existing
Director integration-test harness in this repo to extend — the only prior
"Director test" is a trivial `hasattr` check in test_coding_endpoints.py).

Covers: the deterministic skip-phrase matcher, the media-ack forwarder, and
the item-dispatch emit helper — using a REAL Director constructed with a
real SessionStore/SessionState/CadenceTracker and lightweight stand-ins for
Tracer/LatencyOrchestrator (Director only calls `.event(...)` /
`.start_turn(...)` on those, which the stand-ins provide; no LLM, no WS, no
asyncio needed for what's tested here).

Run with: python -m pytest tests/test_scenario_director_glue.py -v
"""
from __future__ import annotations

import pytest

from engine.brain.cadence.schema import CadencePlan
from engine.brain.contracts.session_state import SessionState
from engine.brain.core.cadence_tracker import CadenceTracker
from engine.brain.core.director import Director
from engine.brain.core.scenario_cursor import ScenarioStage
from engine.brain.core.session_store import SessionStore


class _FakeTracer:
    """Captures every `.event()` call — a stand-in for the real Tracer,
    which needs a JsonlEventLog + EventBus (file/pub-sub plumbing unrelated
    to what's under test here)."""

    def __init__(self) -> None:
        self.events: list[tuple[str, dict]] = []

    def event(self, kind, **payload) -> None:
        self.events.append((str(kind), payload))


class _FakeLatency:
    """Director stores this but never calls it in the methods under test."""


def _plan() -> CadencePlan:
    return CadencePlan.model_validate({
        "total_duration_s": 60,
        "phases": [{
            "id": "scenario_analysis", "duration_s": 60, "intent": "scenario",
            "question_mode": "generic", "scenario_items": [
                {"id": "diagram_1",
                 "media": {"kind": "image", "ref": "arch.png", "filename": "arch.png", "mime_type": "image/png"},
                 "question": "What is missing?", "coverage_tags": ["load balancer"]},
                {"id": "clip_1",
                 "media": {"kind": "video", "ref": "demo.mp4", "filename": "demo.mp4", "mime_type": "video/mp4"},
                 "question": "How to scale?", "coverage_tags": ["caching"], "max_followups": 1},
            ],
        }],
    })


def _director() -> tuple[Director, _FakeTracer, CadenceTracker]:
    tracker = CadenceTracker(_plan(), now_ms_provider=lambda: 0)
    store = SessionStore(SessionState())
    tracer = _FakeTracer()
    d = Director(
        store=store, tracer=tracer, latency=_FakeLatency(), tracker=tracker,
        elapsed_ms_provider=lambda: 0,
    )
    return d, tracer, tracker


# ── skip-phrase matcher (deterministic, no dependencies) ────────────────


@pytest.mark.parametrize("text", [
    "I don't know",
    "hmm, not sure, can we skip this one?",
    "let's just move on",
    "I'll pass on this",
    "no idea honestly",
])
def test_matches_skip_phrase_true_cases(text):
    assert Director._matches_skip_phrase(text)


@pytest.mark.parametrize("text", [
    "",
    "the answer is a load balancer",
    "I know this — it's about caching",
    "next, let's talk about how caching works here",  # "next" alone must NOT match (no "next question")
])
def test_matches_skip_phrase_false_cases(text):
    assert not Director._matches_skip_phrase(text)


def test_matches_ending_phrase_unaffected_by_the_new_skip_list():
    # Regression guard: adding _SCENARIO_SKIP_PHRASES must not touch the
    # pre-existing ending-phrase matcher's own behaviour.
    assert Director._matches_ending_phrase("let's wrap up") == "let's wrap up"
    assert Director._matches_ending_phrase("I don't know") is None


# ── on_scenario_media_ack ─────────────────────────────────────────────────


def test_on_scenario_media_ack_forwards_to_the_cursor():
    d, tracer, tracker = _director()
    cursor = tracker.scenario_cursor()
    cursor.media_intro_dispatched(0.0)  # image -> READY_TO_ASK already; force video path instead
    # Re-drive onto the video item directly for this test:
    cursor.question_dispatched("q")
    cursor.record_answer("great", "answered", [])  # advance to clip_1 (video)
    assert cursor.current_item().id == "clip_1"
    cursor.media_intro_dispatched(0.0)
    assert cursor.stage is ScenarioStage.AWAIT_MEDIA_ACK

    d.on_scenario_media_ack("scenario_media_ended")
    assert cursor.stage is ScenarioStage.READY_TO_ASK
    kinds = [k for k, _ in tracer.events]
    assert "scenario_media_ack" in kinds


def test_on_scenario_media_ack_is_a_noop_outside_a_scenario_phase():
    plan = CadencePlan.model_validate({
        "total_duration_s": 30,
        "phases": [{"id": "p", "duration_s": 30, "intent": "x",
                    "question_mode": "generic", "generic_prompts": ["hi"]}],
    })
    tracker = CadenceTracker(plan, now_ms_provider=lambda: 0)
    store = SessionStore(SessionState())
    tracer = _FakeTracer()
    d = Director(store=store, tracer=tracer, latency=_FakeLatency(), tracker=tracker,
                 elapsed_ms_provider=lambda: 0)
    d.on_scenario_media_ack("scenario_media_ended")  # must not raise
    assert tracer.events == []


def test_on_scenario_media_ack_error_skips_the_item():
    d, tracer, tracker = _director()
    cursor = tracker.scenario_cursor()
    assert cursor.current_item().id == "diagram_1"
    # Force the current item to video-like ack handling by driving to clip_1:
    cursor.media_intro_dispatched(0.0)
    cursor.question_dispatched("q")
    cursor.record_answer("great", "answered", [])
    cursor.media_intro_dispatched(0.0)
    d.on_scenario_media_ack("scenario_media_error")
    assert cursor.records[1].outcome == "skipped_media_error"
    assert cursor.is_phase_done()


# ── _emit_scenario_item_dispatch ──────────────────────────────────────────


def test_emit_scenario_item_dispatch_fires_once_and_advances_stage():
    d, tracer, tracker = _director()
    cursor = tracker.scenario_cursor()
    assert cursor.stage is ScenarioStage.AWAIT_MEDIA_INTRO

    d._emit_scenario_item_dispatch(cursor)
    assert cursor.stage is ScenarioStage.READY_TO_ASK  # image -> immediate
    kinds = [k for k, _ in tracer.events]
    assert kinds.count("scenario_item_dispatched") == 1
    _, payload = next(e for e in tracer.events if e[0] == "scenario_item_dispatched")
    assert payload["item_id"] == "diagram_1"
    assert payload["item_index"] == 0
    assert payload["item_total"] == 2
    assert payload["media"]["kind"] == "image"
    assert payload["coverage_tags"] == ["load balancer"]

    # Calling again is a harmless no-op — next_action() no longer says
    # "show_media" once the stage has moved on.
    d._emit_scenario_item_dispatch(cursor)
    assert kinds.count("scenario_item_dispatched") == 1  # unchanged (still using the stale `kinds` list, recompute)
    assert [k for k, _ in tracer.events].count("scenario_item_dispatched") == 1


def test_emit_scenario_item_dispatch_noop_when_not_awaiting_media_intro():
    d, tracer, tracker = _director()
    cursor = tracker.scenario_cursor()
    cursor.media_intro_dispatched(0.0)  # -> READY_TO_ASK
    d._emit_scenario_item_dispatch(cursor)  # should do nothing (action != show_media)
    assert tracer.events == []
