"""Coordination-plane unit tests (fakeredis — no real Redis needed).

Covers the four primitives that make the session tier multi-replica:
registry (token->shard pointer + TTL), admission (capped cluster counters),
locks (single-winner claim).
"""
from __future__ import annotations


import pytest

from app import coordination as coord
from app.coordination import admission, locks, registry


@pytest.fixture()
def fake_redis():
    """Inject a fresh fakeredis client for each test; clear afterwards."""
    import fakeredis.aioredis as fr

    client = fr.FakeRedis(decode_responses=True)
    coord.set_redis(client)
    yield client
    coord.set_redis(None)


# ── registry ──────────────────────────────────────────────────────────────
@pytest.mark.asyncio
async def test_registry_claim_get_release(fake_redis):
    assert await registry.get("tok1") is None

    loc = await registry.claim("tok1", shard="session-2",
                               fqdn="session-2.internal:8080", now=1000.0)
    assert loc.shard == "session-2"

    got = await registry.get("tok1")
    assert got is not None
    assert got.shard == "session-2"
    assert got.fqdn == "session-2.internal:8080"
    assert got.created_at == 1000.0

    await registry.release("tok1")
    assert await registry.get("tok1") is None


@pytest.mark.asyncio
async def test_registry_renew_extends_our_own_lease(fake_redis):
    loc = await registry.claim("tok1", "session-0", "s0:8080", ttl_s=50)
    ttl = await fake_redis.ttl(registry._key("tok1"))
    assert 0 < ttl <= 50
    assert await registry.renew(loc, ttl_s=100) == registry.RENEWED
    assert await fake_redis.ttl(registry._key("tok1")) > 50


@pytest.mark.asyncio
async def test_each_claim_takes_a_higher_fence(fake_redis):
    a = await registry.claim("tok1", "session-0", "s0:8080")
    b = await registry.claim("tok1", "session-1", "s1:8080")
    assert b.fence == a.fence + 1
    assert (await registry.get("tok1")).fence == b.fence


@pytest.mark.asyncio
async def test_a_replaced_owner_cannot_renew_or_delete(fake_redis):
    # session-0 was cut off long enough for session-1 to take the interview.
    old = await registry.claim("tok1", "session-0", "s0:8080")
    new = await registry.claim("tok1", "session-1", "s1:8080")
    assert await registry.renew(old) == registry.LOST
    await registry.release("tok1", old)
    assert (await registry.get("tok1")).shard == "session-1", "the new owner's entry stays"
    assert await registry.renew(new) == registry.RENEWED


@pytest.mark.asyncio
async def test_a_lost_entry_is_restored_only_if_nobody_claimed_since(fake_redis):
    loc = await registry.claim("tok1", "session-0", "s0:8080")
    await fake_redis.delete(registry._key("tok1"))       # Redis lost it
    assert await registry.renew(loc) == registry.RESTORED
    assert (await registry.get("tok1")).shard == "session-0"

    # Lost again — but this time another replica claimed and then finished it.
    other = await registry.claim("tok1", "session-1", "s1:8080")
    await registry.release("tok1", other)
    assert await registry.renew(loc) == registry.LOST, "a newer claim existed: don't come back"
    assert await registry.get("tok1") is None


# ── admission ─────────────────────────────────────────────────────────────
@pytest.mark.asyncio
async def test_admission_cap_and_release(fake_redis):
    key = admission.speech_key_counter("k1")
    cap = 5

    # First five acquire; sixth is rejected.
    for _ in range(cap):
        assert await admission.try_acquire(key, cap) is True
    assert await admission.try_acquire(key, cap) is False
    assert await admission.value(key) == cap  # overshoot was rolled back

    # Release frees a slot back up.
    await admission.release(key)
    assert await admission.value(key) == cap - 1
    assert await admission.try_acquire(key, cap) is True


@pytest.mark.asyncio
async def test_admission_release_floors_at_zero(fake_redis):
    key = admission.ACTIVE_SESSIONS
    await admission.release(key)  # release with nothing acquired
    assert await admission.value(key) == 0
    await admission.release(key)
    assert await admission.value(key) == 0


@pytest.mark.asyncio
async def test_admission_uncapped_always_ok(fake_redis):
    for _ in range(100):
        assert await admission.try_acquire(admission.LLM_INFLIGHT, None) is True


@pytest.mark.asyncio
async def test_least_loaded_shard(fake_redis):
    shards = ["session-0", "session-1", "session-2"]
    # Load session-0 heavily, session-1 lightly, session-2 not at all.
    for _ in range(3):
        await admission.try_acquire(admission.shard_counter("session-0"), None)
    await admission.try_acquire(admission.shard_counter("session-1"), None)

    assert await admission.least_loaded_shard(shards) == "session-2"


# ── locks ─────────────────────────────────────────────────────────────────
@pytest.mark.asyncio
async def test_lock_single_winner(fake_redis):
    key = locks.session_lock_key("tokX")
    fence_a = await locks.acquire(key)
    assert fence_a is not None

    # Second acquirer loses while the first holds it.
    assert await locks.acquire(key) is None

    # Only the holder can release; a wrong fence is a no-op.
    assert await locks.release(key, "not-the-fence") is False
    assert await locks.release(key, fence_a) is True

    # Now it's free again.
    fence_b = await locks.acquire(key)
    assert fence_b is not None


@pytest.mark.asyncio
async def test_session_lock_contextmanager(fake_redis):
    async with locks.session_lock("tokY") as fence:
        assert fence is not None
        # A competing claim inside the critical section fails.
        async with locks.session_lock("tokY") as inner:
            assert inner is None
    # Lock released on exit → re-acquirable.
    async with locks.session_lock("tokY") as again:
        assert again is not None
