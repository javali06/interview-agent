"""Hybrid scorer: blends deterministic skill coverage with the LLM's semantic score.

Flow (unchanged from the resume_scorer branch; only the LLM client changed):
1. The LLM evaluates fit *and* extracts the JD's actual required/preferred skills.
2. We deterministically check how many of those skills literally appear in the
   resume (no hardcoded skill list; falls back to generic extraction if the LLM
   returned none).
3. The two signals are blended into the final score.

The LLM weight comes from SHORTLIST_LLM_WEIGHT (default 0.65). The model/provider
are resolved inside LLMScorer from SLOW_PROVIDER/SLOW_MODEL — one LLM stack.
"""
from __future__ import annotations

import os

from .keyword_scorer import compute_coverage, extract_skills_offline
from .llm_scorer import LLMScorer
from .models import ScoreResponse


def _llm_weight() -> float:
    try:
        return max(0.0, min(1.0, float(os.environ.get("SHORTLIST_LLM_WEIGHT", "0.65"))))
    except (TypeError, ValueError):
        return 0.65


class HybridScorer:
    def __init__(self, llm: LLMScorer | None = None, llm_weight: float | None = None):
        # Lazy default so importing this module never resolves an LLM key.
        self._llm = llm
        self.llm_weight = _llm_weight() if llm_weight is None else max(0.0, min(1.0, llm_weight))

    @property
    def llm(self) -> LLMScorer:
        if self._llm is None:
            self._llm = LLMScorer()
        return self._llm

    def score(self, resume_text: str, job_description: str) -> ScoreResponse:
        llm = self.llm.score(resume_text, job_description)

        required = llm.required_skills
        preferred = llm.preferred_skills
        if not required and not preferred:
            required = extract_skills_offline(job_description)

        coverage = compute_coverage(resume_text, required, preferred)

        w = self.llm_weight
        final = w * llm.overall_score + (1.0 - w) * coverage.score

        return ScoreResponse(
            final_score=round(final, 2),
            coverage=coverage,
            llm=llm,
            weights={"llm": round(w, 2), "coverage": round(1.0 - w, 2)},
            model=self.llm.model,
        )
