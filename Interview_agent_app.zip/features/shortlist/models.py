"""Pydantic schemas for requests, responses, and the LLM structured output."""

from __future__ import annotations

from pydantic import BaseModel, Field


# --------------------------------------------------------------------------- #
# Request bodies
# --------------------------------------------------------------------------- #
class TextScoreRequest(BaseModel):
    """Score a resume supplied as plain text (no file upload)."""

    resume_text: str = Field(..., min_length=1, description="Resume content as text.")
    job_description: str = Field(
        ..., min_length=1, description="The job description to score against."
    )


# --------------------------------------------------------------------------- #
# Skill-coverage component (deterministic)
# --------------------------------------------------------------------------- #
class SkillCoverage(BaseModel):
    """Deterministic coverage of the JD's actual skills by the resume.

    The skills themselves are extracted from the JD by the LLM (so the set is
    not limited to any hardcoded list); the presence check against the resume is
    fully deterministic and explainable.
    """

    score: float = Field(..., ge=0, le=100, description="Weighted coverage, 0–100.")
    required_matched: list[str] = Field(default_factory=list)
    required_missing: list[str] = Field(default_factory=list)
    preferred_matched: list[str] = Field(default_factory=list)
    preferred_missing: list[str] = Field(default_factory=list)
    required_total: int = 0
    preferred_total: int = 0


# --------------------------------------------------------------------------- #
# LLM (semantic) component — this is the schema the model is forced to return.
# --------------------------------------------------------------------------- #
class DimensionScore(BaseModel):
    name: str = Field(..., description="Dimension being evaluated.")
    score: float = Field(..., ge=0, le=100)
    rationale: str = Field(..., description="Why this score was given.")


class Candidate(BaseModel):
    """Candidate identity extracted from the resume (empty if not found)."""

    name: str = ""
    email: str = ""
    phone: str = ""


class LLMScore(BaseModel):
    """Semantic evaluation produced by the LLM."""

    overall_score: float = Field(..., ge=0, le=100)
    summary: str = Field(..., description="One-paragraph fit assessment.")
    dimensions: list[DimensionScore] = Field(default_factory=list)
    strengths: list[str] = Field(default_factory=list)
    gaps: list[str] = Field(default_factory=list)
    recommendation: str = Field(
        ..., description="Hire-funnel recommendation, e.g. strong/maybe/weak fit."
    )
    # Skills extracted from the JD — these drive the deterministic coverage check.
    required_skills: list[str] = Field(
        default_factory=list, description="Must-have skills named in the JD."
    )
    preferred_skills: list[str] = Field(
        default_factory=list, description="Nice-to-have skills named in the JD."
    )
    # Candidate identity extracted from the resume (if present).
    candidate: Candidate = Field(default_factory=Candidate)


# --------------------------------------------------------------------------- #
# Final blended response
# --------------------------------------------------------------------------- #
class ScoreResponse(BaseModel):
    final_score: float = Field(..., ge=0, le=100, description="Blended score, 0–100.")
    coverage: SkillCoverage
    llm: LLMScore
    weights: dict[str, float] = Field(
        ..., description="Weights used to blend the components."
    )
    model: str = Field(..., description="Model used for the semantic component.")
    # Set for batch results — the source filename this score came from.
    source: str | None = Field(
        default=None, description="Originating resume filename (batch mode)."
    )


# --------------------------------------------------------------------------- #
# Batch (folder) processing
# --------------------------------------------------------------------------- #
class BatchResultItem(BaseModel):
    """One resume's outcome in a batch run."""

    source: str = Field(..., description="Resume filename that was processed.")
    status: str = Field(..., description='"scored" or "error".')
    candidate: Candidate | None = Field(
        default=None, description="Extracted candidate identity (if scored)."
    )
    result: ScoreResponse | None = Field(
        default=None, description="Full score (present when status == 'scored')."
    )
    error: str | None = Field(
        default=None, description="Error message (present when status == 'error')."
    )


class BatchScoreResponse(BaseModel):
    input_dir: str
    processed_dir: str
    total: int = Field(..., description="Resume files picked up this run.")
    scored: int
    failed: int
    results: list[BatchResultItem] = Field(default_factory=list)
