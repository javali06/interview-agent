"""Semantic resume<->JD scoring on the project's OpenAI-compatible client.

Ported off LiteLLM onto the same stack the interview side uses: one OpenAI
SDK call against a provider base_url resolved from SLOW_PROVIDER/SLOW_MODEL
(Groq / OpenRouter / OpenAI), JSON-object response mode, plus the same
OpenRouter tuning (reasoning effort low + throughput routing) used by
rubric/generator.py and admin/evaluation_service.py. One LLM stack for the
whole product — no litellm dependency.
"""
from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path

from .models import Candidate, DimensionScore, LLMScore

logger = logging.getLogger("shortlist.llm")

_REPO_ROOT = Path(__file__).resolve().parents[2]

# provider -> (base_url, key-env-var). Mirrors the interview stack's resolvers.
_PROVIDER_ENDPOINTS = {
    "groq": ("https://api.groq.com/openai/v1", "GROQ_API_KEY"),
    "openrouter": ("https://openrouter.ai/api/v1", "OPENROUTER_API_KEY"),
    "openai": ("https://api.openai.com/v1", "OPENAI_API_KEY"),
}


def _env_or_dotenv(name: str) -> str:
    val = (os.environ.get(name) or "").strip()
    if val:
        return val
    env_file = _REPO_ROOT / ".env"
    if env_file.is_file():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith(f"{name}="):
                return line.split("=", 1)[1].strip()
    return ""


def _resolve_llm() -> tuple[str, str, str]:
    """(api_key, base_url, model). SLOW_PROVIDER/SLOW_MODEL first, then legacy
    Groq -> OpenRouter fallback. Raises if no key is configured."""
    provider = (os.environ.get("SLOW_PROVIDER") or "").strip().lower()
    model = (os.environ.get("SLOW_MODEL") or "").strip()
    if provider in _PROVIDER_ENDPOINTS and model:
        base_url, key_env = _PROVIDER_ENDPOINTS[provider]
        key = _env_or_dotenv(key_env)
        if key:
            return key, base_url, model.split(":", 1)[0]
    groq = _env_or_dotenv("GROQ_API_KEY")
    if groq:
        return groq, "https://api.groq.com/openai/v1", "openai/gpt-oss-120b"
    openrouter = _env_or_dotenv("OPENROUTER_API_KEY")
    if openrouter:
        return openrouter, "https://openrouter.ai/api/v1", "deepseek/deepseek-v3.2"
    raise ScoringError(
        "No LLM key found. Set GROQ_API_KEY or OPENROUTER_API_KEY (with "
        "SLOW_PROVIDER/SLOW_MODEL) to enable resume scoring."
    )


SYSTEM_PROMPT = """\
You are an expert technical recruiter and hiring manager. You evaluate how well a \
candidate's resume matches a specific job description.

Score objectively and evidence-based. Reward concrete, demonstrated experience over \
buzzwords. Penalize missing must-have requirements. Be specific in rationales — cite \
what the resume does or does not show.

Evaluate these dimensions, each scored 0–100:
- "Skills & Technologies": overlap between required skills and what the resume demonstrates.
- "Relevant Experience": depth and relevance of past roles to this job's responsibilities.
- "Seniority & Scope": whether the candidate's level matches what the role needs.
- "Education & Certifications": fit of credentials to any stated requirements.
- "Domain & Industry": familiarity with the role's domain or industry.

Then give an overall_score (0–100) reflecting holistic fit (not a strict average — \
weight must-have requirements heavily), a one-paragraph summary, key strengths, key \
gaps, and a recommendation of exactly one of: "strong fit", "possible fit", or "weak fit".

Also extract the concrete skills the job description names, split into:
- "required_skills": must-have skills/technologies (from "required", "must have", core \
responsibilities).
- "preferred_skills": nice-to-have skills (from "preferred", "bonus", "plus", "nice to have").

CRITICAL formatting rules for skills:
- Each entry is a SHORT canonical name of 1–3 words: a technology, tool, language, \
or named method. NEVER a sentence or a description.
- Strip qualifiers like "strong", "advanced", "deep", "knowledge of", "experience with", \
"proficiency in". Remove trailing punctuation.
- Split compound requirements into separate entries: "Pandas, NumPy, Scikit-Learn" \
becomes three entries; "AWS, GCP, or Azure" becomes three entries.
- GOOD: "Python", "SQL", "Pandas", "Scikit-Learn", "A/B testing", "PyTorch", "Tableau", \
"Docker", "CI/CD", "hypothesis testing".
- BAD: "advanced Python skills using Pandas for ML models", "Strong SQL knowledge with \
large datasets", "team player".
Do not invent skills the JD does not mention.

Finally, extract the candidate's identity FROM THE RESUME into "candidate":
- "name": the candidate's full name (usually at the top of the resume).
- "email": their email address.
- "phone": their phone number.
Use an empty string "" for any field not present in the resume. Do not guess.

Return ONLY a single JSON object with these keys, and nothing else (no prose, no
markdown fences):
  overall_score (number 0-100), summary (string),
  dimensions (array of {name, score, rationale}),
  strengths (array of string), gaps (array of string),
  recommendation (string), required_skills (array of string),
  preferred_skills (array of string), candidate ({name, email, phone}).
"""


class ScoringError(RuntimeError):
    """Raised when the model's output cannot be parsed into a score."""


def _clamp(value) -> float:
    try:
        return max(0.0, min(100.0, float(value)))
    except (TypeError, ValueError):
        return 0.0


def _lenient_loads(s: str) -> dict:
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        return json.loads(re.sub(r",(\s*[}\]])", r"\1", s))  # tolerate trailing commas


def _extract_json(text: str) -> dict:
    if not text:
        raise ScoringError("Model returned empty content.")
    stripped = text.strip()
    fence = re.match(r"^```[a-zA-Z]*\s*(.*?)\s*```$", stripped, re.DOTALL)
    if fence:
        stripped = fence.group(1).strip()
    try:
        return _lenient_loads(stripped)
    except json.JSONDecodeError:
        pass
    start, end = stripped.find("{"), stripped.rfind("}")
    if start != -1 and end != -1 and end > start:
        try:
            return _lenient_loads(stripped[start : end + 1])
        except json.JSONDecodeError as exc:
            raise ScoringError(f"Could not parse JSON from model output: {exc}") from exc
    raise ScoringError("Model output did not contain a JSON object.")


class LLMScorer:
    """One OpenAI-compatible call returning a structured fit assessment.

    Sync (the scorer pipeline is sync; FastAPI routes run it in a threadpool).
    Provider/model/key resolve from env via _resolve_llm unless explicitly
    passed (tests pass nothing and monkeypatch the client)."""

    def __init__(self, model: str | None = None, api_key: str | None = None,
                 base_url: str | None = None):
        if model and api_key and base_url:
            self.api_key, self.base_url, self.model = api_key, base_url, model
        else:
            self.api_key, self.base_url, self.model = _resolve_llm()

    def score(self, resume_text: str, job_description: str) -> LLMScore:
        from openai import OpenAI

        client = OpenAI(api_key=self.api_key, base_url=self.base_url, timeout=90.0)
        user_prompt = (
            "Evaluate the following resume against the job description.\n\n"
            f"=== JOB DESCRIPTION ===\n{job_description}\n\n"
            f"=== RESUME ===\n{resume_text}\n"
        )
        extra_body = (
            {"reasoning": {"effort": "low"}, "provider": {"sort": "throughput"}}
            if "openrouter" in self.base_url else {}
        )
        resp = client.chat.completions.create(
            model=self.model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.0,
            max_tokens=4096,
            response_format={"type": "json_object"},
            extra_body=extra_body,
        )
        return self._to_model(_extract_json(resp.choices[0].message.content or ""))

    @staticmethod
    def _to_model(data: dict) -> LLMScore:
        dimensions = [
            DimensionScore(
                name=str(d.get("name", "")),
                score=_clamp(d.get("score", 0)),
                rationale=str(d.get("rationale", "")),
            )
            for d in data.get("dimensions", [])
            if isinstance(d, dict)
        ]
        return LLMScore(
            overall_score=_clamp(data.get("overall_score", 0)),
            summary=str(data.get("summary", "")),
            dimensions=dimensions,
            strengths=[str(s) for s in data.get("strengths", [])],
            gaps=[str(g) for g in data.get("gaps", [])],
            recommendation=str(data.get("recommendation", "")),
            required_skills=[str(s) for s in data.get("required_skills", [])],
            preferred_skills=[str(s) for s in data.get("preferred_skills", [])],
            candidate=_candidate_from(data.get("candidate")),
        )


def _candidate_from(raw) -> Candidate:
    if not isinstance(raw, dict):
        return Candidate()
    return Candidate(
        name=str(raw.get("name", "")),
        email=str(raw.get("email", "")),
        phone=str(raw.get("phone", "")),
    )
