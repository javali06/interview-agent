"""Persist scored results onto the shared db/ layer.

Re-homed from the resume_scorer branch's app/db.py: same normalized shape
(candidate deduped by email, JD deduped by content hash, one scores row + one
score_dimensions row per LLM dimension, full ScoreResponse kept losslessly in
scores.result), but writing through the product-wide engine in db/ instead of
a private one. No db_url plumbing — the engine is the shared singleton (tests
call db.engine.reset_engine to point at a throwaway DB).
"""
from __future__ import annotations

import hashlib
import uuid

from sqlalchemy import select
from sqlalchemy.orm import Session

from db import models as m
from db.engine import session_scope

from .models import ScoreResponse


def _get_or_create_candidate(session: Session, score: ScoreResponse) -> m.Candidate:
    candidate = score.llm.candidate
    email = (candidate.email or "").strip()
    if email:
        existing = session.scalar(
            select(m.Candidate).where(m.Candidate.email == email).order_by(m.Candidate.id)
        )
        if existing is not None:
            return existing
    row = m.Candidate(name=candidate.name, email=email, phone=candidate.phone)
    session.add(row)
    session.flush()  # assign id + public_id
    return row


def _get_or_create_job_description(session: Session, text: str | None) -> m.JobDescription | None:
    if not text or not text.strip():
        return None
    content_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
    existing = session.scalar(
        select(m.JobDescription).where(m.JobDescription.content_hash == content_hash)
    )
    if existing is not None:
        return existing
    row = m.JobDescription(content_hash=content_hash, text=text)
    session.add(row)
    session.flush()
    return row


def save_score(
    score: ScoreResponse,
    *,
    job_description: str | None = None,
    role_id: int | None = None,
    resume_path: str | None = None,
    resume_text: str | None = None,
) -> str:
    """Persist one scored result. Returns the candidate's stable public_id hex.

    role_id ties the score to a role (role-centric Shortlist); resume_path /
    resume_text are stamped onto the candidate so a matched person can be sent
    to interview without re-uploading."""
    with session_scope() as session:
        candidate = _get_or_create_candidate(session, score)
        if resume_path is not None:
            candidate.resume_path = resume_path
        if resume_text is not None:
            candidate.resume_text = resume_text
        jd = _get_or_create_job_description(session, job_description)
        row = m.Score(
            candidate=candidate,
            job_description=jd,
            role_id=role_id,
            final_score=score.final_score,
            llm_score=score.llm.overall_score,
            coverage_score=score.coverage.score,
            recommendation=score.llm.recommendation,
            model=score.model,
            source=score.source,
            weights=score.weights,
            coverage=score.coverage.model_dump(),
            result=score.model_dump(),
            dimensions=[
                m.ScoreDimension(name=d.name, score=d.score, rationale=d.rationale)
                for d in score.llm.dimensions
            ],
        )
        session.add(row)
        session.flush()
        return candidate.public_id.hex


def list_recent_scores(limit: int = 50) -> list[m.Score]:
    with session_scope() as session:
        return list(
            session.scalars(select(m.Score).order_by(m.Score.created_at.desc()).limit(limit))
        )


def get_scores_for_candidate(public_id: str) -> list[m.Score]:
    # public_id may arrive as a hex string (what save_score returns) or a UUID;
    # the column is a native UUID type, so coerce to uuid.UUID for binding.
    try:
        pid = public_id if isinstance(public_id, uuid.UUID) else uuid.UUID(str(public_id))
    except (ValueError, AttributeError, TypeError):
        return []
    with session_scope() as session:
        candidate = session.scalar(
            select(m.Candidate).where(m.Candidate.public_id == pid)
        )
        if candidate is None:
            return []
        return list(
            session.scalars(
                select(m.Score)
                .where(m.Score.candidate_id == candidate.id)
                .order_by(m.Score.created_at.desc())
            )
        )
