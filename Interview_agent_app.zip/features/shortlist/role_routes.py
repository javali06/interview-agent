"""Role-centric Shortlist HTTP API — mounted by the admin app under /api/roles
(auth applied at mount time). Drives the role-first screens: create a role with
a threshold, upload a JD, match a batch of resumes against it, see the ranked
fits. Reuses the shortlist scorer + resume parsing.
"""
from __future__ import annotations

import logging
import os
import re
import uuid
from pathlib import Path

from fastapi import APIRouter, File, Form, HTTPException, Request, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from . import role_store, store
from .routes import _get_scorer, _upload_to_text

logger = logging.getLogger("shortlist.roles")

router = APIRouter(prefix="/api/roles", tags=["roles"])


def _sessions_dir() -> Path:
    repo_root = Path(__file__).resolve().parent.parent.parent
    return Path(os.environ.get("SESSIONS_DIR", str(repo_root / "sessions")))


def _safe_name(name: str) -> str:
    base = re.sub(r"[^A-Za-z0-9._-]", "_", (name or "resume").strip()) or "resume"
    return base[:120]


class _CreateRole(BaseModel):
    title: str
    jd_text: str = ""
    threshold: float = 70.0
    # voice (spoken) or text (typed chat). Chosen once for the role: every
    # candidate takes the same interview, and the cadence template + every
    # interview created from it inherit this.
    modality: str = "voice"


class _UpdateRole(BaseModel):
    title: str | None = None
    jd_text: str | None = None
    threshold: float | None = None
    status: str | None = None


@router.get("")
def list_roles():
    return {"roles": role_store.list_roles()}


@router.post("")
def create_role(body: _CreateRole):
    return role_store.create_role(body.title, jd_text=body.jd_text,
                                 threshold=body.threshold, modality=body.modality)


@router.get("/{public_id}")
def get_role(public_id: str):
    role = role_store.get_role(public_id)
    if role is None:
        raise HTTPException(404, "role not found")
    return {**role, "candidates": role_store.list_candidates_for_role(public_id)}


@router.put("/{public_id}")
def update_role(public_id: str, body: _UpdateRole):
    role = role_store.update_role(
        public_id,
        title=body.title,
        jd_text=body.jd_text,
        threshold=body.threshold,
        status=body.status,
    )
    if role is None:
        raise HTTPException(404, "role not found")
    return role


@router.get("/{public_id}/candidates")
def role_candidates(public_id: str):
    if role_store.get_role(public_id) is None:
        raise HTTPException(404, "role not found")
    return {"candidates": role_store.list_candidates_for_role(public_id)}


@router.post("/{public_id}/jd")
async def upload_jd(public_id: str, jd_file: UploadFile = File(...)):
    """Replace the role's JD from an uploaded file (txt/md/pdf/docx)."""
    if role_store.get_role(public_id) is None:
        raise HTTPException(404, "role not found")
    jd_text = await _upload_to_text(jd_file, "Job description")
    role = role_store.update_role(public_id, jd_text=jd_text)
    return role


@router.post("/{public_id}/match")
async def match_resumes(public_id: str, resumes: list[UploadFile] = File(...)):
    """Score a batch of resumes against the role's JD, store each (tied to the
    role, with the resume kept), and return the ranked candidates."""
    rm = role_store.get_role_for_match(public_id)
    if rm is None:
        raise HTTPException(404, "role not found")
    _require_open(role_store.get_role(public_id) or {})
    role_id, jd_text, threshold = rm
    if not jd_text.strip():
        raise HTTPException(400, "Add a job description to this role before matching.")

    resume_dir = _sessions_dir() / "roles" / public_id / "resumes"
    resume_dir.mkdir(parents=True, exist_ok=True)
    scorer = _get_scorer()

    processed = 0
    errors: list[dict] = []
    for up in resumes:
        if not up or not up.filename:
            continue
        try:
            text = await _upload_to_text(up, "Resume")
            # _upload_to_text consumed the stream; re-read isn't needed — persist
            # the parsed text + a copy of the original bytes for the interview.
            await up.seek(0)
            raw = await up.read()
            fname = f"{uuid.uuid4().hex[:8]}_{_safe_name(up.filename)}"
            dest = resume_dir / fname
            if raw:
                dest.write_bytes(raw)
            rel_path = str(dest.relative_to(_sessions_dir()))
            score = await run_in_threadpool(scorer.score, text, jd_text)
            if up.filename:
                score.source = up.filename
            store.save_score(
                score,
                job_description=jd_text,
                role_id=role_id,
                resume_path=rel_path,
                resume_text=text,
            )
            processed += 1
        except HTTPException as e:
            errors.append({"file": up.filename, "error": e.detail})
        except Exception as e:  # provider/parse/etc — don't fail the whole batch
            logger.warning("[roles] match failed for %s: %s", up.filename, e)
            errors.append({"file": up.filename, "error": str(e)})

    return {
        "processed": processed,
        "errors": errors,
        "threshold": threshold,
        "candidates": role_store.list_candidates_for_role(public_id),
    }


class _InterviewsBody(BaseModel):
    candidate_public_ids: list[str]



def _copy_eval_plan(from_token: str, to_token: str) -> None:
    """Give the new interview the role's evaluation plugins.

    Carried separately from the cadence because it lives in its own artefact
    (evaluation_plan.json), and it is the half that decides whether anything is
    scored at all — an interview created without it scores 0/0 with no error
    anywhere, which is a failure mode this project has already shipped once."""
    try:
        from features.eval.plan_storage import load_plan, save_plan

        plan = load_plan(from_token)
        if plan is not None:
            save_plan(to_token, plan)
    except Exception as e:      # a missing plan must not lose the interview
        logger.warning("[roles] could not copy evaluation plan to %s: %s", to_token, e)

# ── the role's cadence template ─────────────────────────────────────────────
# One interview plan, authored once, applied verbatim to every candidate in the
# role. The reason is comparability: the Shortlist exists to RANK people, and
# candidates who answered different questions against different rubrics cannot
# be ranked against each other. Generating a cadence per candidate (what this
# flow used to do) quietly destroyed that, and cost an LLM call per person.
#
# The template is a real session row (`is_template=True`) so it reuses the
# cadence editor, the revise-with-AI agents and the evaluation-plugin panel
# exactly as they are, rather than growing a second role-scoped copy of each.


def _template_state(role: dict) -> dict:
    """What the SPA needs to gate 'Create interviews' on."""
    from app import db as admin_db

    token = role.get("template_token") or ""
    row = admin_db.get(token) if token else None
    if row is None:
        return {"token": "", "status": "missing", "ready": False}
    return {
        "token": token,
        "status": row.get("status") or "",
        "modality": row.get("modality") or "voice",
        # 'ready' is what the normal approve path sets. For a template that
        # means "a person has reviewed this plan", not "an interview is live" —
        # is_template keeps it out of every interview list and count.
        "ready": (row.get("status") == "ready"),
    }


@router.post("/{public_id}/cadence-template")
async def ensure_cadence_template(public_id: str):
    """Get, or create, the role's cadence template, and return its token.

    Idempotent: a second call returns the existing template rather than a second
    one, so the admin can leave and come back to the same plan. Generation is the
    ordinary path — from the role's JD, with no resume, because the plan must not
    be shaped by any one candidate."""
    role = role_store.get_role(public_id)
    if role is None:
        raise HTTPException(404, "role not found")
    _require_open(role)

    from app import db as admin_db
    from app import sessions as admin_sessions

    existing = role.get("template_token") or ""
    if existing and admin_db.get(existing) is not None:
        # Idempotent, and the modality of an existing template is NOT changed:
        # it is baked into the cadence (text is untimed) and into every interview
        # already created from it.
        return {"token": existing, **_template_state(role)}

    # Inherited from the role, not chosen here: every candidate for the role
    # takes the same interview, so the mode is a property of the role.
    modality = role.get("modality") or "voice"

    from io import BytesIO

    from starlette.datastructures import UploadFile as StarletteUploadFile

    # create_draft always stores a resume; a template has no candidate, so this
    # placeholder is what stands in its place. It is never read: the template is
    # never run, and the cadence is generated from the JD alone.
    stub = StarletteUploadFile(
        BytesIO(b"(role cadence template - no candidate resume)"),
        filename="template.txt",
    )
    form = admin_sessions.ScheduleForm(
        candidate_name=f"{role['title']} - cadence template",
        role=role["title"],
        jd_text=role.get("jd_text") or "",
        jd_upload=None,
        resume_upload=stub,
        cadence_requirements_text="",
        cadence_requirements_upload=None,
        is_template=True,
        modality=modality,
        # A text interview has no camera or screen to record.
        record_enabled=(modality != "text"),
    )
    token, _yaml = await admin_sessions.create_draft(form)
    role_store.set_template_token(public_id, token)
    refreshed = role_store.get_role(public_id) or role
    return {"token": token, **_template_state(refreshed)}


@router.get("/{public_id}/cadence-template")
def get_cadence_template(public_id: str):
    role = role_store.get_role(public_id)
    if role is None:
        raise HTTPException(404, "role not found")
    return _template_state(role)


@router.post("/{public_id}/interviews")
async def create_interviews(public_id: str, body: _InterviewsBody):
    """Batch-create draft interview sessions for the selected matched
    candidates — each using the candidate's stored resume + the role's JD +
    title (cadence generated per candidate). Returns the tokens so the SPA can
    send the operator to review/approve each (the existing cadence screen)."""
    role = role_store.get_role(public_id)
    if role is None:
        raise HTTPException(404, "role not found")
    _require_open(role)

    # The role's cadence is REQUIRED, and must have been reviewed by a person.
    # Refusing here rather than falling back to per-candidate generation is the
    # point of the step: it is what guarantees every candidate in this role
    # answers the same interview, scored by the same plugins, so their results
    # are comparable — and it is what stops an interview being created with an
    # unreviewed plan or an empty evaluation plan (the 0/0 scorecard).
    tpl = _template_state(role)
    if not tpl["token"]:
        raise HTTPException(409, "set the role's interview cadence before creating interviews")
    if not tpl["ready"]:
        raise HTTPException(
            409,
            "the role's interview cadence has not been approved yet — review and "
            "approve it, then create the interviews",
        )
    from app import db as admin_db

    template_row = admin_db.get(tpl["token"]) or {}
    template_yaml = (template_row.get("cadence_yaml") or "").strip()
    template_modality = template_row.get("modality") or "voice"
    if not template_yaml:
        raise HTTPException(409, "the role's interview cadence is empty — author it first")

    from io import BytesIO

    from starlette.datastructures import UploadFile as StarletteUploadFile

    from app import sessions as admin_sessions

    created: list[dict] = []
    errors: list[dict] = []
    for cpid in body.candidate_public_ids:
        cand = role_store.get_candidate_for_interview(cpid)
        if cand is None:
            errors.append({"candidate": cpid, "error": "not found"})
            continue
        data: bytes | None = None
        fname = "resume.txt"
        if cand["resume_path"]:
            p = _sessions_dir() / cand["resume_path"]
            if p.exists():
                data = p.read_bytes()
                fname = p.name
        if data is None and cand["resume_text"]:
            data = cand["resume_text"].encode("utf-8")
        if not data:
            errors.append({"candidate": cand["name"], "error": "no resume on file"})
            continue
        try:
            up = StarletteUploadFile(BytesIO(data), filename=fname)
            form = admin_sessions.ScheduleForm(
                candidate_name=cand["name"],
                role=role["title"],
                jd_text=role["jd_text"],
                jd_upload=None,
                resume_upload=up,
                cadence_requirements_text="",
                cadence_requirements_upload=None,
                # Verbatim, not regenerated — see _template_state above.
                cadence_yaml=template_yaml,
                # Inherited, not defaulted: a text role must not quietly create
                # voice interviews (the cadence it carries is untimed).
                modality=template_modality,
                record_enabled=(template_modality != "text"),
                # Links the interview back to its role — what the role's state
                # and its interview list are derived from.
                role_public_id=str(public_id),
                candidate_public_id=str(cpid),
                # So the automated invite email (app/notifications) has an
                # address to send to — same email the response below reports
                # as a "guess" to the admin.
                candidate_email=cand.get("email", "") or "",
            )
            token, _yaml = await admin_sessions.create_draft(form)
            _copy_eval_plan(tpl["token"], token)
            created.append({
                "token": token,
                "candidate_name": cand["name"],
                "candidate_public_id": str(cpid),
                # Extracted from the resume, so it is a guess — the screen makes
                # it editable because it decides who actually gets the link.
                "candidate_email": cand.get("email", ""),
            })
        except Exception as e:
            logger.warning("[roles] create interview failed for %s: %s", cand["name"], e)
            errors.append({"candidate": cand["name"], "error": str(e)})

    return {"created": created, "errors": errors}




def _require_open(role: dict) -> None:
    """A closed role takes no new work.

    Closing is how a recruiter says "this opening is finished", so it must stop
    new CVs being matched and new interviews being created or sent. It does NOT
    touch interviews that already exist: candidates holding a link have been
    told they are being interviewed, and revoking that silently would be worse
    than the role staying tidy. Reopening the role lifts this."""
    if (role.get("status") or "open") == "closed":
        raise HTTPException(
            409,
            "this role is closed — reopen it to match more resumes or create interviews",
        )

def _candidate_of(row: dict) -> dict:
    """Name + editable email for an interview's candidate.

    `sessions.candidate_name` is a display copy taken at creation; the EMAIL
    lives on the candidate row, which is the thing an admin corrects."""
    cpid = row.get("candidate_public_id") or ""
    cand = role_store.get_candidate_for_interview(cpid) if cpid else None
    return {
        "candidate_name": (cand or {}).get("name") or row.get("candidate_name", ""),
        "candidate_public_id": cpid,
        "candidate_email": (cand or {}).get("email", ""),
    }


class _CandidateEmail(BaseModel):
    email: str = ""



@router.delete("/{public_id}/candidates/{candidate_public_id}")
def remove_candidate(public_id: str, candidate_public_id: str):
    """Drop a candidate from THIS role's shortlist.

    Scoped deliberately: the person, their resume and their standing on other
    roles survive, because the same CV is regularly matched against several
    openings. Interviews already created for them are also untouched — an
    interview that happened is a record, and deleting it here would lose a
    scorecard somebody may need."""
    if role_store.get_role(public_id) is None:
        raise HTTPException(404, "role not found")
    removed = role_store.remove_candidate_from_role(public_id, candidate_public_id)
    if not removed:
        raise HTTPException(404, "candidate is not on this role")
    return {"ok": True, "removed": removed}

@router.put("/{public_id}/candidates/{candidate_public_id}/email")
def set_candidate_email(public_id: str, candidate_public_id: str, body: _CandidateEmail):
    """Correct the address a candidate's interview link goes to.

    Extracted from the resume by an LLM, so it is regularly wrong or missing —
    and it is the field that decides whether a real person gets their interview."""
    if role_store.get_role(public_id) is None:
        raise HTTPException(404, "role not found")
    updated = role_store.update_candidate_email(candidate_public_id, body.email)
    if updated is None:
        raise HTTPException(404, "candidate not found")
    return updated


class _ApproveBatch(BaseModel):
    tokens: list[str] = []



@router.get("/{public_id}/interviews")
def list_interviews(request: Request, public_id: str):
    """The role's interviews — its own dashboard.

    The setup screen used to show the batch it had just created, held in the
    browser's memory, so navigating away lost it and coming back showed the
    empty picker instead. Reading them from the server means the role's
    interviews are there on any visit, which is what makes "go back to the
    role" a useful destination after editing or approving one."""
    from app import db as admin_db

    if role_store.get_role(public_id) is None:
        raise HTTPException(404, "role not found")

    base = str(request.base_url).rstrip("/")
    rows = [r for r in admin_db.list_recent(limit=500)
            if r.get("role_public_id") == str(public_id) and not r.get("is_template")]

    out = []
    for r in rows:
        token = r["token"]
        ready = r.get("status") == "ready"
        out.append({
            "token": token,
            "status": r.get("status") or "",
            # A link only exists once the interview has been approved — showing
            # one for a draft would hand out a URL that does not work yet.
            "candidate_link": f"{base}/app/candidate?token={token}" if ready else "",
            "created_at": r.get("created_at") or "",
            **_candidate_of(r),
        })
    out.sort(key=lambda x: x["created_at"], reverse=True)
    return {"interviews": out}

@router.post("/{public_id}/interviews/approve")
async def approve_interviews(request: Request, public_id: str, body: _ApproveBatch):
    """Approve a batch of the role's interviews and return each one's links.

    Every candidate already has the role's approved cadence, so this is the last
    step: turn the drafts into live interviews and hand back a link per person.
    It runs each through the SAME `_approve_session` the single-interview screen
    uses — the coding backfill, cadence validation and evaluation-plan gate are
    exactly the checks that must not be skipped when a link goes out, so they
    are not reimplemented here.

    Partial success is reported rather than hidden: one candidate's bad plan
    must not silently deny links to the rest."""
    import json as _json

    from app import db as admin_db
    from app.main import _approve_session

    role = role_store.get_role(public_id)
    if role is None:
        raise HTTPException(404, "role not found")
    _require_open(role)

    # LOCAL single-laptop mode runs one interview at a time (the orchestrator
    # binds fixed ports). Approving a batch there makes the single-active guard
    # CANCEL each previously approved sibling as the next one launches — so say
    # so instead of silently mangling the batch. Inert in every container
    # deploy, which sets CLOUD_MODE=1.
    import os as _os

    if _os.environ.get("CLOUD_MODE", "") != "1" and len(body.tokens) > 1:
        raise HTTPException(
            409,
            "this deployment runs one interview at a time — approve them one at a "
            "time from each candidate's cadence page",
        )

    approved: list[dict] = []
    errors: list[dict] = []
    for token in body.tokens:
        row = admin_db.get(token)
        if row is None:
            errors.append({"token": token, "error": "interview not found"})
            continue
        if row.get("role_public_id") not in (None, "", str(public_id)):
            errors.append({"token": token, "candidate_name": row.get("candidate_name", ""),
                           "error": "belongs to a different role"})
            continue
        if row.get("status") == "ready":
            # Already approved — return its links rather than relaunching it.
            base = str(request.base_url).rstrip("/")
            approved.append({"token": token, **_candidate_of(row),
                             "candidate_link": f"{base}/app/candidate?token={token}"})
            continue
        resp = await _approve_session(request, token, row, row.get("cadence_yaml") or "")
        payload = _json.loads(bytes(resp.body))
        if payload.get("ok"):
            approved.append({"token": token, **_candidate_of(row),
                             "candidate_link": payload.get("candidate_link", "")})
        else:
            errors.append({"token": token, "candidate_name": row["candidate_name"],
                           "error": payload.get("error", "approve failed")})
    return {"approved": approved, "errors": errors}


@router.post("/{public_id}/interviews/{token}/send-email")
async def send_interview_email(request: Request, public_id: str, token: str) -> JSONResponse:
    """(Re)send this candidate their interview link by email, on demand.

    Approving an interview already enqueues this once automatically (see
    `app.main._maybe_enqueue_invite`), off whatever email existed at that
    moment. This exists for everything that happens AFTER that: a blank or
    wrong address corrected here later, or a candidate who simply never got
    the first one. Reads the email from `_candidate_of` — the CANDIDATE row,
    the same live source this screen displays and the inline editor writes to
    — not the session's own `candidate_email` column, which is only ever set
    once at creation and would otherwise silently re-send to a stale address.
    """
    from app import db as admin_db

    if role_store.get_role(public_id) is None:
        raise HTTPException(404, "role not found")
    row = admin_db.get(token)
    if row is None:
        raise HTTPException(404, "interview not found")
    if row.get("role_public_id") not in (None, "", str(public_id)):
        raise HTTPException(404, "interview not found")
    if row.get("status") != "ready":
        raise HTTPException(409, "this interview has no link yet — approve it first")

    cand = _candidate_of(row)
    email = (cand["candidate_email"] or "").strip()
    if not email:
        raise HTTPException(400, "no email on file for this candidate")

    base = str(request.base_url).rstrip("/")
    link = f"{base}/app/candidate?token={token}"

    from app.jobs import jobs as _jobs
    await _jobs.enqueue(
        _jobs.INVITE_DISPATCH,
        {
            "token": token,
            "to": email,
            "candidate_name": cand["candidate_name"] or row.get("candidate_name", ""),
            "role": row.get("role", ""),
            "link": link,
        },
        token=token,
    )
    return JSONResponse({"ok": True, "email": email})
