"""Deterministic skill-coverage scoring.

Skills are not guessed from a hardcoded list. They are extracted from the job
description by the LLM (see ``llm_scorer``) so any skill the JD actually names is
captured — "Snowflake", "LangGraph", "event-driven architecture", whatever. This
module's job is the *deterministic, explainable* half: given those skills, check
which literally appear in the resume and compute a weighted coverage score.

``extract_skills_offline`` is a generic n-gram fallback used only when LLM
extraction yields nothing, so the coverage signal degrades gracefully instead of
disappearing.
"""

from __future__ import annotations

import re

from .models import SkillCoverage

# Filler words that should never count as a skill on their own.
_STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from", "has", "have",
    "in", "is", "it", "its", "of", "on", "or", "that", "the", "to", "with", "will",
    "you", "your", "we", "our", "their", "they", "this", "these", "those", "but",
    "not", "all", "any", "can", "should", "must", "may", "who", "what", "when",
    "where", "which", "able", "work", "working", "experience", "experiences",
    "year", "years", "team", "teams", "role", "job", "candidate", "candidates",
    "ability", "strong", "good", "great", "excellent", "plus", "etc", "including",
    "include", "includes", "such", "using", "use", "used", "across", "within",
    "into", "per", "via", "also", "well", "more", "most", "least", "new", "other",
    "preferred", "required", "requirements", "responsibilities", "skills",
    "need", "needs", "needed", "looking", "seeking", "seek", "require", "requires",
    "want", "wants", "like", "prefer", "prefers", "knowledge", "understanding",
    "familiarity", "proficiency", "proficient", "expertise", "demonstrated",
}

_TOKEN_RE = re.compile(r"[a-zA-Z][a-zA-Z0-9+#.\-]*[a-zA-Z0-9+#]|[a-zA-Z]")

# How much required vs preferred skills count toward the coverage score.
_REQUIRED_WEIGHT = 0.8
_PREFERRED_WEIGHT = 0.2


def _normalize(text: str) -> str:
    return text.lower().strip()


def _present(resume: str, skill: str) -> bool:
    """Whether a skill literally appears in the (normalized) resume."""
    skill = _normalize(skill)
    if not skill:
        return False
    # Multi-word or punctuated skills: substring containment.
    if " " in skill or "/" in skill:
        return skill in resume
    # Single token: word-boundary match so "go" doesn't hit "google".
    return re.search(rf"(?<![a-z0-9]){re.escape(skill)}(?![a-z0-9])", resume) is not None


def _split(resume: str, skills: list[str]) -> tuple[list[str], list[str]]:
    matched, missing = [], []
    seen: set[str] = set()
    for skill in skills:
        key = _normalize(skill)
        if not key or key in seen:
            continue
        seen.add(key)
        (matched if _present(resume, skill) else missing).append(skill)
    return matched, missing


def compute_coverage(
    resume_text: str,
    required_skills: list[str],
    preferred_skills: list[str],
) -> SkillCoverage:
    """Deterministically score how well the resume covers the JD's skills."""
    resume = _normalize(resume_text)

    req_matched, req_missing = _split(resume, required_skills)
    pref_matched, pref_missing = _split(resume, preferred_skills)

    req_total = len(req_matched) + len(req_missing)
    pref_total = len(pref_matched) + len(pref_missing)

    req_cov = (len(req_matched) / req_total) if req_total else None
    pref_cov = (len(pref_matched) / pref_total) if pref_total else None

    if req_cov is not None and pref_cov is not None:
        coverage = _REQUIRED_WEIGHT * req_cov + _PREFERRED_WEIGHT * pref_cov
    elif req_cov is not None:
        coverage = req_cov
    elif pref_cov is not None:
        coverage = pref_cov
    else:
        coverage = 0.0

    return SkillCoverage(
        score=round(coverage * 100.0, 2),
        required_matched=req_matched,
        required_missing=req_missing,
        preferred_matched=pref_matched,
        preferred_missing=pref_missing,
        required_total=req_total,
        preferred_total=pref_total,
    )


def extract_skills_offline(job_description: str) -> list[str]:
    """Generic, list-free fallback skill extraction from a JD.

    Captures arbitrary single tokens and adjacent two-word phrases (where both
    words carry signal). Not as precise as LLM extraction, but it depends on no
    hardcoded vocabulary, so it works for any domain.
    """
    jd = _normalize(job_description)
    tokens = [
        t
        for t in _TOKEN_RE.findall(jd)
        if len(t) >= 2 and t not in _STOPWORDS and not t.isdigit()
    ]

    skills: list[str] = []
    seen: set[str] = set()

    # Adjacent content-word bigrams (e.g. "distributed systems").
    raw = _TOKEN_RE.findall(jd)
    for a, b in zip(raw, raw[1:]):
        if a in _STOPWORDS or b in _STOPWORDS or a.isdigit() or b.isdigit():
            continue
        if len(a) < 2 or len(b) < 2:
            continue
        phrase = f"{a} {b}"
        if phrase not in seen:
            skills.append(phrase)
            seen.add(phrase)

    # Single tokens.
    for t in tokens:
        if t not in seen:
            skills.append(t)
            seen.add(t)

    return skills
