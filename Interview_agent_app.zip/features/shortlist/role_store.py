"""Role-centric persistence for the Shortlist + AI-Interview flows.

A Role is a job opening (title + JD + match threshold). Resumes are matched
against the role's JD via the existing HybridScorer; each match is a Score row
tied to the role (Score.role_id) with the resume stamped on the Candidate so a
matched person can be sent straight to interview. Built on the shared db/ layer.
"""
from __future__ import annotations

import uuid

from sqlalchemy import select

from db import models as m
from db.engine import create_all, session_scope


def _coerce(public_id) -> uuid.UUID | None:
    try:
        return public_id if isinstance(public_id, uuid.UUID) else uuid.UUID(str(public_id))
    except (ValueError, AttributeError, TypeError):
        return None


# The three states a role moves through. Derived, not stored — except the last,
# which is a DECISION: a role whose interviews have all finished but where no
# offer is out is genuinely not closed, so a person closes it.
ROLE_STATES = ("sourcing", "interviewing", "closed")


def role_state(role: m.Role, *, interviews: int = 0) -> str:
    """sourcing → interviewing → closed.

    sourcing     — matching resumes and authoring the interview plan.
    interviewing — at least one interview has been created for this role.
    closed       — the admin closed it; overrides the rest.
    """
    if (role.status or "open") == "closed":
        return "closed"
    return "interviewing" if interviews > 0 else "sourcing"


def _role_dict(role: m.Role, *, matched: int | None = None, total: int | None = None,
               interviews: "dict[str, int] | None" = None) -> dict:
    return {
        "public_id": role.public_id.hex,
        "title": role.title,
        "jd_text": role.jd_text or "",
        "threshold": float(role.threshold),
        "status": role.status,
        "created_at": role.created_at.isoformat() if role.created_at else None,
        "candidate_count": total,
        "matched_count": matched,
        # The role's cadence-template session, or "" when none has been
        # authored yet (every pre-existing role).
        "template_token": role.template_token or "",
        "modality": role.modality or "voice",
        "interview_count": (interviews or {}).get("total", 0),
        # Per-stage counts for the role's own chart.
        "interview_states": interviews or {},
        "state": role_state(role, interviews=(interviews or {}).get("total", 0)),
    }


def _best_by_candidate(session, role_id: int) -> dict[int, m.Score]:
    """Each candidate's single best score against this role."""
    rows = list(session.scalars(select(m.Score).where(m.Score.role_id == role_id)))
    best: dict[int, m.Score] = {}
    for sc in rows:
        cur = best.get(sc.candidate_id)
        if cur is None or sc.final_score > cur.final_score:
            best[sc.candidate_id] = sc
    return best


def create_role(title: str, jd_text: str = "", threshold: float = 70.0, created_by: str = "",
                modality: str = "voice") -> dict:
    create_all()
    with session_scope() as s:
        role = m.Role(
            modality=(modality if modality in ('voice', 'text') else 'voice'),
            title=(title or "").strip() or "Untitled role",
            jd_text=jd_text or "",
            threshold=float(threshold),
            created_by=created_by or "",
        )
        s.add(role)
        s.flush()
        return _role_dict(role, matched=0, total=0)


def list_roles() -> list[dict]:
    create_all()
    with session_scope() as s:
        roles = list(s.scalars(select(m.Role).order_by(m.Role.created_at.desc())))
        counts = _interview_counts(s)
        out = []
        for role in roles:
            best = _best_by_candidate(s, role.id)
            matched = sum(1 for sc in best.values() if sc.final_score >= role.threshold)
            out.append(_role_dict(role, matched=matched, total=len(best),
                                  interviews=counts.get(role.public_id.hex)))
        return out


# Raw session status -> the stage shown on a role. Three stages only: a pie
# with four slices cannot be made colourblind-safe on this surface (all 70
# four-hue combinations of the palette fail the all-pairs check), and merging
# two stages is a smaller loss than shipping two slices a reader cannot tell
# apart. `cancelled` is deliberately absent — a cancelled interview has left
# the pipeline, so it is reported separately rather than inflating a slice.
# Each stage means exactly one thing, matching what the platform actually does:
#   ready       — approve issued the candidate link; it has not been used yet
#   in_progress — the candidate has STARTED the interview
#   completed   — finished and scored
# `draft` is NOT one of them: an interview created from the role template has no
# link until somebody approves it, so calling it "ready to send" would be a lie.
# It is reported under the chart instead, with `cancelled`, because both sit
# outside the send → interview → done pipeline.
_ROLE_STAGE = {
    "ready": "ready_to_send",
    "in_progress": "in_progress",
    "completed": "completed",
}
ROLE_INTERVIEW_STAGES = ("ready_to_send", "in_progress", "completed")


def _interview_counts(session) -> dict[str, dict[str, int]]:
    """Per role: the count in each stage, plus `total` and `cancelled`.

    Templates are excluded — a role's own cadence template is not somebody
    being interviewed, so it must not move the role into `interviewing`."""
    from sqlalchemy import func

    rows = session.execute(
        select(m.InterviewSession.role_public_id,
               m.InterviewSession.status,
               func.count())
        .where(m.InterviewSession.role_public_id.is_not(None),
               m.InterviewSession.is_template.is_(False))
        .group_by(m.InterviewSession.role_public_id, m.InterviewSession.status)
    ).all()

    out: dict[str, dict[str, int]] = {}
    for rid, status, n in rows:
        if not rid:
            continue
        bucket = out.setdefault(str(rid), {k: 0 for k in ROLE_INTERVIEW_STAGES}
                                | {"cancelled": 0, "awaiting_approval": 0, "total": 0})
        n = int(n)
        bucket["total"] += n
        status = str(status)
        if status == "cancelled":
            bucket["cancelled"] += n
        elif status in ("draft", "generating"):
            bucket["awaiting_approval"] += n
        else:
            stage = _ROLE_STAGE.get(status)
            # An unrecognised status is counted in the total but given no stage,
            # so a new status has to be mapped here deliberately rather than
            # silently landing in whichever bucket happens to be first.
            if stage:
                bucket[stage] += n
    return out


def get_role(public_id) -> dict | None:
    pid = _coerce(public_id)
    if pid is None:
        return None
    create_all()
    with session_scope() as s:
        role = s.scalar(select(m.Role).where(m.Role.public_id == pid))
        if role is None:
            return None
        return _role_dict(role, interviews=_interview_counts(s).get(role.public_id.hex))


def get_role_for_match(public_id) -> tuple[int, str, float] | None:
    """(role_id, jd_text, threshold) for the matcher, or None."""
    pid = _coerce(public_id)
    if pid is None:
        return None
    create_all()
    with session_scope() as s:
        role = s.scalar(select(m.Role).where(m.Role.public_id == pid))
        if role is None:
            return None
        return role.id, role.jd_text or "", float(role.threshold)


def update_role(public_id, *, title=None, jd_text=None, threshold=None, status=None) -> dict | None:
    pid = _coerce(public_id)
    if pid is None:
        return None
    create_all()
    with session_scope() as s:
        role = s.scalar(select(m.Role).where(m.Role.public_id == pid))
        if role is None:
            return None
        if title is not None:
            role.title = title.strip()
        if jd_text is not None:
            role.jd_text = jd_text
        if threshold is not None:
            role.threshold = float(threshold)
        if status is not None:
            role.status = status
        s.flush()
        return _role_dict(role)


def get_candidate_for_interview(public_id) -> dict | None:
    """Name + stored resume for a matched candidate, so an interview can be
    scheduled without re-uploading."""
    pid = _coerce(public_id)
    if pid is None:
        return None
    create_all()
    with session_scope() as s:
        cand = s.scalar(select(m.Candidate).where(m.Candidate.public_id == pid))
        if cand is None:
            return None
        return {
            "name": cand.name or "Candidate",
            "email": cand.email or "",
            "resume_path": cand.resume_path or "",
            "resume_text": cand.resume_text or "",
        }


def list_candidates_for_role(public_id) -> list[dict]:
    """Ranked (best score desc) candidates matched to the role."""
    pid = _coerce(public_id)
    if pid is None:
        return []
    create_all()
    with session_scope() as s:
        role = s.scalar(select(m.Role).where(m.Role.public_id == pid))
        if role is None:
            return []
        best = _best_by_candidate(s, role.id)
        out = []
        for sc in best.values():
            cand = sc.candidate
            out.append({
                "candidate_public_id": cand.public_id.hex,
                "name": cand.name or "(unnamed)",
                "email": cand.email or "",
                "final_score": round(sc.final_score, 1),
                "llm_score": round(sc.llm_score, 1),
                "coverage_score": round(sc.coverage_score, 1),
                "recommendation": sc.recommendation or "",
                "above_threshold": sc.final_score >= role.threshold,
                "has_resume": bool(cand.resume_path or cand.resume_text),
                "source": sc.source or "",
            })
        out.sort(key=lambda r: r["final_score"], reverse=True)
        return out


def set_template_token(public_id, token: str) -> None:
    """Point a role at its cadence-template session."""
    pid = _coerce(public_id)
    if pid is None:
        return
    with session_scope() as db:
        role = db.query(m.Role).filter(m.Role.public_id == pid).first()
        if role is not None:
            role.template_token = token


def get_role_by_template_token(token: str) -> dict | None:
    """The role whose cadence template this session is, if any."""
    if not token:
        return None
    with session_scope() as db:
        role = db.query(m.Role).filter(m.Role.template_token == token).first()
        return _role_dict(role) if role is not None else None


def update_candidate_email(public_id, email: str) -> dict | None:
    """Correct the email a candidate's interview link gets sent to.

    The address is EXTRACTED from the resume by an LLM, so it is a guess that is
    sometimes wrong or missing — and it is the one field here that decides
    whether a real person receives their interview. It has to be correctable.
    """
    pid = _coerce(public_id)
    if pid is None:
        return None
    with session_scope() as db:
        cand = db.query(m.Candidate).filter(m.Candidate.public_id == pid).first()
        if cand is None:
            return None
        cand.email = (email or "").strip()
        return {"public_id": cand.public_id.hex, "name": cand.name or "", "email": cand.email}


def remove_candidate_from_role(role_public_id, candidate_public_id) -> int:
    """Drop a candidate from ONE role's shortlist. Returns rows removed.

    Deletes that candidate's scores for this role only — the person, their
    resume, and their standing on any other role are untouched, because the
    same CV is regularly matched against several openings. Interviews already
    created for them are also left alone: an interview that happened is a
    record, not a shortlist entry, and deleting it here would lose a scorecard.
    """
    rid = _coerce(role_public_id)
    cid = _coerce(candidate_public_id)
    if rid is None or cid is None:
        return 0
    with session_scope() as db:
        role = db.query(m.Role).filter(m.Role.public_id == rid).first()
        cand = db.query(m.Candidate).filter(m.Candidate.public_id == cid).first()
        if role is None or cand is None:
            return 0
        rows = (db.query(m.Score)
                  .filter(m.Score.role_id == role.id, m.Score.candidate_id == cand.id)
                  .all())
        for row in rows:
            db.delete(row)          # score_dimensions cascade
        return len(rows)
