"""Shortlist HTTP API — score a resume against a JD, persist the result.

A FastAPI APIRouter mounted by the admin app under /api/shortlist (auth is
applied at mount time, so this module stays decoupled from admin/auth).

Ported from the resume_scorer branch's app/main.py:
- /score/text : JSON in (resume_text + job_description), ScoreResponse out.
- /score      : multipart (resume file [+ JD text or file]), ScoreResponse out.
Resume/JD files are converted to text with the project's existing
orchestrator_new.resume_parser (one parser for the whole app) instead of
resume_scorer's private document-conversion stack.

Folder/batch + SharePoint ingest is a deferred sub-task (needs the connector);
the React UI's /score/batch call will point at a multi-upload endpoint added
there.
"""
from __future__ import annotations

import logging
import tempfile
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.concurrency import run_in_threadpool

from .llm_scorer import ScoringError
from .models import ScoreResponse, TextScoreRequest
from .scorer import HybridScorer
from . import store

logger = logging.getLogger("shortlist.routes")

router = APIRouter(prefix="/api/shortlist", tags=["shortlist"])

_scorer: Optional[HybridScorer] = None


def _get_scorer() -> HybridScorer:
    global _scorer
    if _scorer is None:
        _scorer = HybridScorer()  # resolves the LLM key lazily on first score
    return _scorer


def _persist(score: ScoreResponse, jd: Optional[str]) -> None:
    """Best-effort persistence — a save failure must not fail the score."""
    try:
        store.save_score(score, job_description=jd)
    except Exception as e:  # pragma: no cover - defensive
        logger.warning("[shortlist] persist failed (ignored): %s", e)


async def _upload_to_text(upload: UploadFile, label: str) -> str:
    data = await upload.read()
    if not data:
        raise HTTPException(status_code=400, detail=f"{label} file is empty.")
    if len(data) > 10 * 1024 * 1024:
        raise HTTPException(status_code=413, detail=f"{label} exceeds 10 MB.")
    suffix = Path(upload.filename or "").suffix or ".txt"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=True) as tmp:
        tmp.write(data)
        tmp.flush()
        try:
            from engine.orchestrator.resume_parser import parse_resume
            return parse_resume(Path(tmp.name))
        except Exception as exc:
            raise HTTPException(status_code=422, detail=f"Could not read {label}: {exc}") from exc


def _run_scoring(resume_text: str, jd_text: str) -> ScoreResponse:
    try:
        score = _get_scorer().score(resume_text, jd_text)
    except ScoringError as exc:
        raise HTTPException(status_code=502, detail=f"Scoring failed: {exc}") from exc
    except Exception as exc:  # provider/auth/etc.
        raise HTTPException(status_code=502, detail=f"LLM error: {exc}") from exc
    _persist(score, jd_text)
    return score


@router.post("/score/text", response_model=ScoreResponse)
async def score_text(req: TextScoreRequest) -> ScoreResponse:
    """Score a resume supplied as plain text."""
    return await run_in_threadpool(_run_scoring, req.resume_text, req.job_description)


@router.post("/score", response_model=ScoreResponse)
async def score_file(
    resume: UploadFile = File(..., description="Resume file (pdf/docx/txt/…)."),
    job_description: str | None = Form(None, description="JD as text."),
    job_description_file: UploadFile | None = File(None, description="JD as a file."),
) -> ScoreResponse:
    """Score an uploaded resume against a JD (JD as text field OR file)."""
    resume_text = await _upload_to_text(resume, "Resume")
    if job_description_file is not None and job_description_file.filename:
        jd_text = await _upload_to_text(job_description_file, "Job description")
    elif job_description and job_description.strip():
        jd_text = job_description
    else:
        raise HTTPException(
            status_code=400,
            detail="Provide a job description via 'job_description' (text) or "
            "'job_description_file' (file).",
        )
    return await run_in_threadpool(_run_scoring, resume_text, jd_text)
