"""Shortlist — score resumes against a role/JD and persist ranked candidates.

Ported from the resume_scorer branch onto the product's shared stack:
- one LLM client (OpenAI-compatible, SLOW_PROVIDER/SLOW_MODEL) — no litellm
- one database (db/ shared SQLAlchemy layer) — candidates/JDs/scores

Public surface:
    from features.shortlist import HybridScorer, save_score, ScoreResponse
"""
from features.shortlist.keyword_scorer import compute_coverage, extract_skills_offline
from features.shortlist.llm_scorer import LLMScorer, ScoringError
from features.shortlist.models import (
    Candidate,
    LLMScore,
    ScoreResponse,
    SkillCoverage,
    TextScoreRequest,
)
from features.shortlist.scorer import HybridScorer
from features.shortlist.store import (
    get_scores_for_candidate,
    list_recent_scores,
    save_score,
)

__all__ = [
    "HybridScorer",
    "LLMScorer",
    "ScoringError",
    "ScoreResponse",
    "SkillCoverage",
    "LLMScore",
    "Candidate",
    "TextScoreRequest",
    "compute_coverage",
    "extract_skills_offline",
    "save_score",
    "list_recent_scores",
    "get_scores_for_candidate",
]
