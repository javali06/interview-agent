"""Deterministic rubric fallback — no LLM required.

Classifies each cadence phase by id/intent/content and assigns a sensible
default lens. Used when the LLM is unavailable or its output fails
validation, so the cadence-review page ALWAYS has a rubric to show.

Quarantine guards (fairness — see docs/evaluation_rubric.md §3b):
  - warm-up/wrap-up style phases get weight 0, but never the only phase
    and never the longest phase
  - if everything ended up quarantined, the longest phase is restored
    to weight 1.0
"""
from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from typing import Any

from features.eval.schema import ANCHOR_LEVELS, BehavioralAnchor, Rubric, SectionLens

logger = logging.getLogger(__name__)

_WARM_RE = re.compile(r"warm|intro|greet|rapport|ice.?break", re.I)
_WRAP_RE = re.compile(r"wrap|clos|outro|conclu|next.?steps|farewell", re.I)
_DESIGN_RE = re.compile(r"design|architect|system|scal", re.I)
_DEEPDIVE_RE = re.compile(r"resume|project|experience|deep.?dive|background|past.?work", re.I)

# Generic anchor descriptions, formatted with the section's focus noun.
_ANCHOR_TEXT: dict[str, str] = {
    "below_bar": "Cannot make progress on {focus} even with prompting; detail collapses at the first probe.",
    "approaching": "Handles {focus} only with help; reactive, needs prompting, answers feel bolted together.",
    "mixed": "Some independent work on {focus}, but explanations thin out under the second probe.",
    "solid": "Independent at the role's level on {focus}; proactive and coherent, detail survives probing.",
    "exceptional": "Above the role's level on {focus}; offers alternatives and tradeoffs unprompted.",
}


def build_anchors(focus: str) -> list[BehavioralAnchor]:
    """5 templated anchors around a short focus phrase (e.g. 'the coding
    exercise'). Shared with the LLM generator, which asks the model for just
    the focus phrase instead of 5 sentences per phase — anchor prose is the
    bulk of a rubric's output tokens and on reasoning models (gpt-oss-120b)
    that cost is paid twice (hidden chain-of-thought + answer)."""
    return [
        BehavioralAnchor(level=lvl, description=_ANCHOR_TEXT[lvl].format(focus=focus))
        for lvl in ANCHOR_LEVELS
    ]


# Internal alias kept for the classifier code below.
_anchors = build_anchors


def _is_coding(phase: dict[str, Any]) -> bool:
    return bool(phase.get("coding_question_ids") or phase.get("coding_question_id"))


def _classify(phase: dict[str, Any], idx: int, n: int) -> SectionLens:
    pid = str(phase.get("id") or f"phase_{idx + 1}")
    intent = str(phase.get("intent") or "")
    text = f"{pid} {intent}"

    if _is_coding(phase):
        return SectionLens(
            phase_id=pid,
            purpose="Can the candidate produce working, structured code and show their process?",
            score_dimensions=["code_quality", "problem_solving_process"],
            ignore_dimensions=["communication_clarity: silent typing phase — speech is incidental"],
            weight=1.5,
            anchors=_anchors("the coding exercise"),
        )

    # Code-discussion / coding-review: the AI walks the candidate through
    # their just-submitted code. Communication + depth dominate here (they
    # have to explain decisions, complexity, edges) — code is already
    # captured in the previous coding section, so we don't double-score it.
    if pid in ("code_discussion", "coding_review", "code_review") or pid.startswith("code_discussion_") or pid.startswith("coding_review_"):
        return SectionLens(
            phase_id=pid,
            purpose="Probing the candidate's understanding of their solution — complexity, edge cases, tradeoffs.",
            score_dimensions=["technical_depth", "communication_clarity"],
            ignore_dimensions=["code_quality: already scored in the coding section"],
            weight=0.8,
            anchors=_anchors("their own code submission"),
        )

    if idx == 0 and _WARM_RE.search(text):
        return SectionLens(
            phase_id=pid,
            purpose="Settle nerves and calibrate pace so later sections produce valid signal.",
            score_dimensions=[],
            ignore_dimensions=["all competence dimensions: rapport phase — first-impression bias lives here"],
            weight=0.0,
            anchors=[],
        )

    if idx == n - 1 and _WRAP_RE.search(text):
        return SectionLens(
            phase_id=pid,
            purpose="Close gracefully; candidate questions are context, not competence.",
            score_dimensions=[],
            ignore_dimensions=["all competence dimensions: logistics phase"],
            weight=0.0,
            anchors=[],
        )

    # Deep-dive beats design: a resume/project phase whose intent happens to
    # mention "system design choices" is still an ownership phase. The id is
    # the stronger signal, so check it on its own first.
    if _DEEPDIVE_RE.search(pid) or (_DEEPDIVE_RE.search(intent) and not _DESIGN_RE.search(pid)):
        return SectionLens(
            phase_id=pid,
            purpose="Did they actually do the work they claim — does detail survive probing?",
            score_dimensions=["ownership_specificity", "technical_depth"],
            ignore_dimensions=["role_fit: brand names and titles are not evidence"],
            weight=1.5,
            anchors=_anchors("their own past work"),
        )

    if _DESIGN_RE.search(text):
        return SectionLens(
            phase_id=pid,
            purpose="Can they navigate an ambiguous design problem and reason about tradeoffs?",
            score_dimensions=["problem_solving_process", "technical_depth", "role_fit"],
            ignore_dimensions=["communication_clarity: style-loaded — judged only as reconstructability inside the scored dims"],
            weight=1.5,
            anchors=_anchors("the design problem"),
        )

    if phase.get("question_mode") == "specific" or phase.get("question_pool"):
        return SectionLens(
            phase_id=pid,
            purpose="Do fundamentals hold up under 2-3 levels of follow-up probing?",
            score_dimensions=["technical_depth", "problem_solving_process"],
            ignore_dimensions=["ownership_specificity: bank questions carry no ownership signal"],
            weight=1.0,
            anchors=_anchors("the question topics"),
        )

    return _generic_lens(pid)


def _generic_lens(pid: str) -> SectionLens:
    return SectionLens(
        phase_id=pid,
        purpose="General assessment of reasoning and clarity for this phase's intent.",
        score_dimensions=["technical_depth", "communication_clarity"],
        ignore_dimensions=["role_fit: insufficient probing structure in a generic phase"],
        weight=1.0,
        anchors=_anchors("this phase's topics"),
    )


def heuristic_rubric(cadence: dict[str, Any], *, role: str = "", seniority_bar: str = "") -> Rubric:
    """Build a deterministic rubric from a parsed cadence dict."""
    phases = cadence.get("phases") or []
    if not isinstance(phases, list) or not phases:
        raise ValueError("cadence has no phases")

    n = len(phases)
    sections = [_classify(p if isinstance(p, dict) else {}, i, n) for i, p in enumerate(phases)]

    # Guard: never quarantine the only phase or the longest phase. The
    # generic lens is forced directly — re-classifying would just match the
    # same warm-up/wrap-up patterns on the phase id again.
    durations = [int((p or {}).get("duration_s") or 0) if isinstance(p, dict) else 0 for p in phases]
    longest = max(range(n), key=lambda i: durations[i]) if n else 0
    for i, lens in enumerate(sections):
        if lens.weight == 0.0 and (n == 1 or i == longest):
            sections[i] = _generic_lens(lens.phase_id)
    if not any(s.weight > 0 for s in sections):
        sections[longest] = _generic_lens(sections[longest].phase_id)

    bar = seniority_bar.strip() or (
        f"Independent {role.strip()} at the level the JD describes; owns work end-to-end."
        if role.strip()
        else "Independent at the level the JD describes; owns work end-to-end."
    )
    return Rubric(
        seniority_bar=bar,
        source="heuristic",
        generated_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        sections=sections,
    )


def extend_rubric_with_new_phases(
    rubric_dict: dict[str, Any],
    cadence_dict: dict[str, Any],
    *,
    role: str = "",
) -> dict[str, Any]:
    """Append heuristic SectionLenses for any cadence phase whose id is NOT
    already present in `rubric_dict['sections']`. Use case: after the admin
    adds a coding round (+ paired code_discussion) via the modal, the
    existing rubric becomes stale. Calling this inserts proper, scored
    sections for the new phases — no LLM round-trip needed; the admin can
    still hit "Regenerate rubric" later if they want LLM-tuned anchors.

    Sections for phases that ALREADY exist are left untouched. Order is
    preserved by walking cadence_dict.phases and emitting in cadence order
    for the new ones (existing ones stay where they were)."""
    existing = {s.get("phase_id") for s in rubric_dict.get("sections", []) if isinstance(s, dict)}
    phases = cadence_dict.get("phases") or []
    n = len(phases)
    appended: list[dict[str, Any]] = []
    for idx, ph in enumerate(phases):
        if not isinstance(ph, dict):
            continue
        pid = str(ph.get("id") or f"phase_{idx + 1}")
        if pid in existing:
            continue
        try:
            lens = _classify(ph, idx, n)
            appended.append(lens.model_dump())
        except Exception as e:
            logger.warning("[rubric] extend: classify failed for phase %r: %s", pid, e)
    if not appended:
        return rubric_dict
    rubric_dict.setdefault("sections", []).extend(appended)
    # Source stays as whatever it was (Rubric.source is a constrained
    # Literal — only "derived" / "heuristic" / "ta_edited" allowed). Bump
    # the timestamp so callers know the rubric was touched.
    rubric_dict["generated_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
    return rubric_dict
