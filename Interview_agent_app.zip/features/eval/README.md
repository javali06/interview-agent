# rubric/ — cadence-driven evaluation rubric

Generates a per-section **evaluation lens** for any cadence: what each phase
is FOR, which canonical dimensions to score (and which to deliberately
ignore), its weight in the composite, and 5 behaviorally anchored levels
calibrated to the role's seniority bar. Companion doc:
`docs/evaluation_rubric.md` (the team-facing rubric reference).

## Shape

```
rubric/
  __init__.py       public API
  feature_flag.py   RUBRIC_ENABLED (ON by default; set 0 to disable)
  schema.py         pydantic: Rubric / SectionLens / BehavioralAnchor + CANONICAL_DIMS
  heuristic.py      deterministic fallback — classifies phases, no LLM needed
  generator.py      LLM derivation (slow LLM, temp 0, 1 retry) -> heuristic fallback
  storage.py        sessions/<token>/rubric.json  ({current, history[]} envelope)
```

## Flow

1. Admin generates/edits a cadence on `/admin/schedule/<token>/cadence`.
2. The page fetches `GET /api/rubric/<token>`; on 404 it calls
   `POST /api/rubric/<token>/generate` with the current cadence YAML —
   the rubric renders beside the cadence preview.
3. TA edits inline (weights, dimensions, purpose, anchors) → `PUT
   /api/rubric/<token>` (source flips to `ta_edited`; prior version goes
   to `history`).
4. If the cadence's phase ids drift from the rubric's, the panel shows an
   out-of-sync warning with one-click regenerate.
5. `admin/evaluation_service.generate_evaluation` injects the saved rubric
   into the eval LLM's prompt so post-interview scoring follows the lenses
   (weight-0 phases excluded from the overall judgment).

## Design rules (enforced in schema validation)

- Dimensions come from `CANONICAL_DIMS` only — no affect-class dims
  (energy/enthusiasm/culture-fit are introversion/culture proxies).
- Exactly 5 anchors (`below_bar..exceptional`), hire bar = `solid`.
- Weight 0 = quarantined (warm-up/wrap-up); never the only/longest phase;
  at least one section must be weight > 0.
- Anchor text must avoid forbidden proxy signals (pronouns, clarifying-
  question counting, hedging, brand names, fluency, speed) — the generator
  prompt bans them; the heuristic templates never contain them.

## Future (not yet wired)

- Per-section evaluation passes producing evidence-anchored section cards
  (see `docs/evaluation_v2_design.md`) — this module's lenses are the
  input contract for that pipeline.
- Per-cadence-template lens freezing for cross-candidate consistency when
  cadence templates are reused verbatim.
