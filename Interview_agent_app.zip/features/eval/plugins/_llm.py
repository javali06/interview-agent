"""Small shared helpers for llm_judge plugins: robust JSON extraction, and the
shared answer-scoring LLM caller (transcription/translation/image_description
ground-truth plugins).

LLMs sometimes wrap JSON in ```fences``` or add a sentence of preamble. These
helpers pull the first JSON object out of a response defensively so a plugin
can stay focused on its scoring logic.
"""
from __future__ import annotations

import json
import re
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from features.eval.plugins.base import EvalContext

_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)\s*```", re.DOTALL)


def extract_json_object(text: Optional[str]) -> Optional[dict]:
    """Return the first JSON object found in `text`, or None.

    Tries, in order: the whole string, a fenced block, then the first
    balanced ``{...}`` span.
    """
    if not text:
        return None
    text = text.strip()
    for candidate in _candidates(text):
        try:
            obj = json.loads(candidate)
            if isinstance(obj, dict):
                return obj
        except Exception:
            continue
    return None


def _candidates(text: str):
    yield text
    m = _FENCE_RE.search(text)
    if m:
        yield m.group(1)
    start = text.find("{")
    if start != -1:
        depth = 0
        for i in range(start, len(text)):
            c = text[i]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    yield text[start:i + 1]
                    break


# ── shared answer-scoring LLM caller ────────────────────────────────────────
# TODO: set the LLM model to use for ground-truth answer scoring (transcription /
# translation / image_description). Left blank on purpose — call_scoring_llm()
# below refuses to run until this is set. This is the ONE place to configure it;
# nothing else needs to change once a model is chosen.
SCORING_LLM_MODEL = "openai/gpt-oss-120b"


async def call_scoring_llm(ctx: "EvalContext", prompt: str) -> dict:
    """Shared LLM caller for the three ground-truth answer-scoring plugins.

    Calls `SCORING_LLM_MODEL` at temperature=0 (for reproducible scoring, unlike
    the interview's general-purpose `ctx.complete` which runs at 0.2) and expects
    a single JSON object back. Routed through `ctx.score_with_llm` — never a
    direct network call — so these plugins stay inside the same "no I/O beyond
    ctx" sandbox every plugin honors (AUTHORING.md §6).

    Raises ValueError (turned into `state="error"` by EvalPlugin.run(), visible
    on the scorecard) if SCORING_LLM_MODEL isn't configured, no LLM key is
    available, or the response isn't valid JSON — never silently defaults."""
    if not SCORING_LLM_MODEL.strip():
        raise ValueError(
            "SCORING_LLM_MODEL is not set — configure it in "
            "features/eval/plugins/_llm.py before running answer scoring."
        )
    if not ctx.has_scoring_llm:
        raise ValueError("No LLM is configured (no API key) — cannot run answer scoring.")
    raw = await ctx.score_with_llm(SCORING_LLM_MODEL, prompt)
    parsed = extract_json_object(raw)
    if parsed is None:
        raise ValueError(f"scoring LLM returned invalid JSON: {(raw or '')[:300]!r}")
    return parsed
