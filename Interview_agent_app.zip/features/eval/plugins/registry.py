"""Plugin registry + UI discovery catalog.

Built-in plugins register themselves at import time via the `@register`
decorator (see features/eval/plugins/builtins/). `plugin_catalog()` returns the
JSON-schema + defaults + declared assumptions for each, so the evaluation UI can
render config forms generically with no per-plugin frontend code.
"""
from __future__ import annotations

from typing import Any

from features.eval.plugins.base import EvalPlugin

_REGISTRY: dict[str, type[EvalPlugin]] = {}


def register(plugin_cls: type[EvalPlugin]) -> type[EvalPlugin]:
    if not getattr(plugin_cls, "id", ""):
        raise ValueError(f"{plugin_cls.__name__} must set a non-empty `id`")
    _REGISTRY[plugin_cls.id] = plugin_cls
    return plugin_cls


def get_plugin(plugin_id: str) -> type[EvalPlugin]:
    try:
        return _REGISTRY[plugin_id]
    except KeyError:
        raise KeyError(f"unknown eval plugin id {plugin_id!r} (known: {sorted(_REGISTRY)})")


def has_plugin(plugin_id: str) -> bool:
    return plugin_id in _REGISTRY


def list_plugins() -> list[type[EvalPlugin]]:
    return [_REGISTRY[k] for k in sorted(_REGISTRY)]


def export_schemas() -> dict[str, dict[str, Any]]:
    """Every export section declared across the registered plugins, keyed by
    section key: `{title, version, plugin_id, json_schema}`.

    This is the export's self-description — what a consumer validates the
    emitted document against. Plugins that declare no section are simply
    absent. Raises if two plugins claim the same section key, which would make
    the export ambiguous."""
    schemas: dict[str, dict[str, Any]] = {}
    for p in list_plugins():
        desc = p.export_descriptor()
        if desc is None:
            continue
        if desc.key in schemas:
            raise ValueError(
                f"export section key {desc.key!r} is claimed by both "
                f"{schemas[desc.key]['plugin_id']!r} and {p.id!r}"
            )
        schemas[desc.key] = {
            "title": desc.title,
            "version": desc.version,
            "plugin_id": p.id,
            "json_schema": desc.json_schema(),
            # What a human reviewer may edit on this section. Travels with the
            # document so the UI renders the right affordance from the plugin's
            # own declaration rather than a hardcoded per-section list.
            "adjustable": desc.adjustable.model_dump(),
        }
    return schemas


def plugin_catalog() -> list[dict[str, Any]]:
    """One entry per plugin for the UI: identity + config JSON-schema +
    defaults + assumptions + view_id."""
    catalog: list[dict[str, Any]] = []
    for p in list_plugins():
        export = p.export_descriptor()
        catalog.append({
            "id": p.id,
            "name": p.name,
            "description": p.description,
            "method": p.method,
            "view_id": p.view_id,
            # None until a plugin declares an export section (see export.py).
            "export_section": export.key if export else None,
            "config_json_schema": p.config_schema().model_json_schema(),
            "default_config": p.default_config().model_dump(mode="json"),
            "assumptions": [a.model_dump() for a in p.assumptions()],
            "help": p.help().model_dump(),
        })
    return catalog


def export_models() -> dict[str, type]:
    """Section key -> the pydantic model its owning plugin declared.

    The read-back counterpart to `export_schemas()`: parsing a stored document
    dispatches each section to the contract it says it conforms to, instead of
    the shared envelope (which is closed, and would reject every real payload)."""
    out: dict[str, type] = {}
    for p in list_plugins():
        desc = p.export_descriptor()
        if desc is not None:
            out[desc.key] = desc.model
    return out
