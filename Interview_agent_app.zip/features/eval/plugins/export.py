"""The shared export contract: how a plugin contributes its slice of the
machine-readable evaluation JSON.

A `SegmentEvaluation` (base.py) is shaped for the *UI* — marks, a breakdown, a
`view_payload` a React template renders. The **export** is the other consumer:
a stable, self-describing JSON document that leaves the portal and is read by
something that has never seen our UI. It therefore needs what the UI payload
deliberately doesn't have — a declared schema, a version, and an explicit
representation of "this was not scored".

Two pieces per plugin (see `EvalPlugin.export_descriptor` / `.export_section`):

  - the **descriptor** (`ExportSection`) — class-level, static: the section key
    this plugin owns in the export, its version, and the pydantic model that IS
    its declared schema (`descriptor.json_schema()` for the JSON-Schema form).
  - the **fill method** — per-segment: turns one `SegmentEvaluation` into an
    instance of that model.

Every section model subclasses `ExportSectionModel`, so the common envelope
(identity, method, state, marks) is identical across the whole pipeline and only
the plugin-specific payload differs.

Two invariants are enforced by the model itself, not by plugin discipline:

  1. **A non-scored segment never exports a number.** `marks_earned` /
     `marks_possible` are `None` unless `state == "scored"` — `not_observed`,
     `insufficient_evidence`, `assumptions_unmet` and `error` carry a
     `not_scored_reason` instead. A 0 in this document always means "earned
     zero marks", never "we couldn't grade this".
  2. **Sections are closed.** `extra="forbid"` means an undeclared key is a
     validation error rather than a silent passenger, so the emitted JSON and
     the declared schema cannot drift apart.

Candidate PII in the export is governed by a recorded decision — see
`docs/eval-export-pii-decision.md`. Short version: event-index pointers yes,
transcript text no, except the one answer a ground-truth score is computed from.

NOTE: the Rubric & Coverage story owns the definitive version of this contract
and is expected to land it in `base.py`. This module is the minimal form the
Ground-truth & Coding family needed in order to ship, kept in its own file on
purpose so that adopting the definitive version is an import change here rather
than a merge conflict in `base.py`.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

from features.eval.plugins.base import EvalState, Method, SegmentEvaluation
from features.eval.sectioner import Segment


class ExportBreakdownItem(BaseModel):
    """One line of how marks were earned or deducted."""

    model_config = ConfigDict(extra="forbid")

    label: str
    delta: float = 0.0
    detail: str = ""


# ── human review ────────────────────────────────────────────────────────────
# The LLM produces a score; a human reviewer must be able to correct it. The
# correction is recorded BESIDE the model's number, never over it: `marks_earned`
# on a section keeps meaning "what the model said", forever, and the review block
# carries what a person changed it to. Three reasons that is not negotiable —
# audit (a raised score and an AI score are different claims), measurement (every
# adjustment is a labelled example of where the model is wrong, and overwriting
# destroys the label), and regeneration (re-running the evaluation rewrites every
# AI value, which would silently erase corrections stored in the same field).

ReasonKind = Literal[
    "ai_misread",        # the model misunderstood what was actually said
    "rubric_wrong",      # the model applied the rubric correctly; the rubric is wrong
    "evidence_missing",  # real evidence the model never saw (audio gap, off-transcript)
    "calibration",       # right judgement, wrong severity for this role/seniority
    "other",
]


class ReviewedItem(BaseModel):
    """One breakdown line a reviewer moved, with the AI's value kept beside it."""

    model_config = ConfigDict(extra="forbid")

    label: str
    ai_value: Optional[float] = None
    human_value: float
    reason: str = ""


class SectionReview(BaseModel):
    """A human's verdict on one section. Absent (`review is None`) is the common
    case and means nobody has touched this section — there is no "empty review"
    state to disambiguate."""

    model_config = ConfigDict(extra="forbid")

    final_state: EvalState
    final_marks_earned: Optional[float] = None
    final_marks_possible: Optional[float] = None
    items: list[ReviewedItem] = Field(default_factory=list)
    reason_kind: Optional[ReasonKind] = None
    reason: str = ""
    notes: list[str] = Field(default_factory=list)
    reviewer: str = ""
    reviewed_at: str = ""
    stale: bool = Field(
        default=False,
        description="The AI's value changed after this review was recorded — confirm or redo.",
    )

    @model_validator(mode="after")
    def _final_marks_only_when_scored(self) -> "SectionReview":
        # The SAME rule as the envelope's. A human cannot turn "we couldn't
        # grade this" into a zero any more than the model can: a reviewer may
        # change the STATE (there was enough to judge after all), but marks and
        # a non-scored state still cannot coexist.
        if self.final_state == "scored":
            if self.final_marks_earned is None or self.final_marks_possible is None:
                raise ValueError("a scored review must carry final marks")
            if self.final_marks_earned < 0:
                raise ValueError("final_marks_earned must not be negative")
            if self.final_marks_earned > self.final_marks_possible:
                raise ValueError(
                    "final_marks_earned must not exceed final_marks_possible — "
                    "what a question is worth is a cadence edit, not a review"
                )
        elif self.final_marks_earned is not None or self.final_marks_possible is not None:
            raise ValueError(
                f"final_state={self.final_state!r} must not carry marks — a non-scored "
                "segment is absent from the totals, not a zero"
            )
        return self


class AdjustableSpec(BaseModel):
    """What a reviewer is allowed to edit on this plugin's section.

    Declared by the plugin, the same way its schema is: a reviewer should not be
    offered a slider for a unit-test result. `recompute` says how the section's
    marks follow from its items, so the reviewer moves the judgement they
    actually have an opinion about and the arithmetic stays the system's job."""

    model_config = ConfigDict(extra="forbid")

    marks: bool = True
    items: bool = False
    item_scale: Optional[tuple[float, float]] = None
    item_label_noun: str = "item"
    recompute: Literal["none", "mean_scaled", "sum_deltas"] = "none"


class ExportSectionModel(BaseModel):
    """The envelope every exported section carries, whatever plugin produced it.

    Subclass it to add the plugin-specific payload; the subclass is that
    section's declared schema."""

    model_config = ConfigDict(extra="forbid")

    section: str = Field(description="The section key this plugin owns in the export.")
    schema_version: str = Field(description="Version of THIS section's shape, bumped by its owner.")
    plugin_id: str
    segment_id: str
    phase_id: str
    question_id: Optional[str] = None
    method: Method = Field(description='How the verdict was reached: "llm_judge" or "python".')
    state: EvalState

    # Explicitly nullable — see invariant 1 in the module docstring. A number
    # here is a real score; absence is the ONLY way "not scored" is expressed.
    marks_earned: Optional[float] = None
    marks_possible: Optional[float] = None
    not_scored_reason: Optional[str] = Field(
        default=None,
        description="Why the segment was not scored. Set for every non-scored state, never alongside marks.",
    )

    # Event indices into the session's event stream, NOT transcript text — the
    # deliberate privacy line drawn in docs/eval-export-pii-decision.md.
    evidence_refs: list[int] = Field(default_factory=list)

    # How the marks were reached, itemised. Scoring data, not transcript: each
    # line is the grader's own label for a point it awarded or withheld. A
    # consumer given only a total cannot check the arithmetic; with this it can.
    breakdown: list["ExportBreakdownItem"] = Field(default_factory=list)

    # A human reviewer's correction, if one was made. Never replaces the fields
    # above: `marks_earned` stays the model's number and `review.final_marks_earned`
    # is what counts. Absent means the section is pure AI output.
    review: Optional["SectionReview"] = None

    @model_validator(mode="after")
    def _marks_only_when_scored(self) -> "ExportSectionModel":
        if self.state == "scored":
            if self.marks_earned is None or self.marks_possible is None:
                raise ValueError("a scored section must carry marks_earned and marks_possible")
        else:
            if self.marks_earned is not None or self.marks_possible is not None:
                raise ValueError(
                    f"state={self.state!r} must not carry marks — a non-scored segment is "
                    "absent from the totals, not a zero"
                )
            if not (self.not_scored_reason or "").strip():
                raise ValueError(f"state={self.state!r} must carry a not_scored_reason")
        return self


@dataclass(frozen=True)
class ExportSection:
    """A plugin's static declaration of the section it contributes."""

    key: str
    title: str
    version: str
    model: type[ExportSectionModel]
    # What a human reviewer may edit on this section. Defaults to total-only,
    # which is the safe reading for a plugin that has not thought about it.
    adjustable: AdjustableSpec = field(default_factory=AdjustableSpec)

    def json_schema(self) -> dict[str, Any]:
        """The section's declared schema in JSON-Schema form (what a consumer
        validates against). Derived from `model`, so the schema and the emitted
        section can never be defined in two places."""
        return self.model.model_json_schema()


def envelope(descriptor: ExportSection, segment: Segment, ev: SegmentEvaluation) -> dict[str, Any]:
    """The common envelope fields for one segment's section.

    The single place invariant 1 is applied, so no plugin has to remember it:
    marks are carried through only for a `scored` verdict, and every other state
    gets its reason instead. Spread into the section model's constructor:

        return MyExport(**envelope(desc, segment, ev), my_field=...)
    """
    scored = ev.state == "scored"
    return {
        "section": descriptor.key,
        "schema_version": descriptor.version,
        "plugin_id": ev.plugin_id,
        "segment_id": ev.segment_id,
        "phase_id": ev.phase_id,
        "question_id": segment.question_id,
        "method": ev.method,
        "state": ev.state,
        "marks_earned": ev.marks_earned if scored else None,
        "marks_possible": ev.marks_possible if scored else None,
        "not_scored_reason": None if scored else ((ev.rationale or "").strip() or ev.state),
        "evidence_refs": list(ev.evidence_refs or []),
        "breakdown": [
            ExportBreakdownItem(label=b.label, delta=b.delta, detail=b.detail)
            for b in (ev.breakdown or [])
        ],
    }


# ── the ground-truth family's one shared shape ───────────────────────────────
# transcription / translation / image_description all answer the same question —
# "how does what the candidate produced compare with what we expected?" — so they
# export the SAME model, not three lookalikes. What differs between them is only
# `expected_kind` and what one comparison item means:
#
#   reference_transcript  -> one item per word-level diff against the reference
#   accepted_translations -> one item per accepted reference translation
#   key_elements          -> one item per key element on the checklist

ExpectedKind = Literal["reference_transcript", "accepted_translations", "key_elements"]


class GroundTruthItem(BaseModel):
    """One expected-vs-actual comparison point."""

    model_config = ConfigDict(extra="forbid")

    expected: Optional[str] = Field(default=None, description="The reference value, when this point has one.")
    actual: Optional[str] = Field(default=None, description="What the candidate gave for it, when anything.")
    matched: bool
    note: str = ""


class GroundTruthComparison(BaseModel):
    """Expected vs actual, in the one shape all three ground-truth plugins use.

    `matched_count` / `total_count` are the score's numerator and denominator in
    each plugin's own natural unit, which `expected_kind` identifies:

      reference_transcript  → words matched / words in the reference
      accepted_translations → 1 or 0 / 1  (the references are alternatives, so
                              there is one thing to get right, not N)
      key_elements          → elements covered / elements on the checklist

    `items` lists the comparison points the plugin can actually name and is NOT
    required to be `total_count` long — transcription lists only the diffs, not
    every word of the reference.
    """

    model_config = ConfigDict(extra="forbid")

    expected_kind: ExpectedKind
    expected: list[str] = Field(
        description="The ground truth, always a list (a single reference is a one-item list)."
    )
    # The candidate's answer, as it was graded. This IS the graded artifact —
    # the counts below are unverifiable without it — and is the one documented
    # exception to "no transcript text in the export".
    actual: str
    items: list[GroundTruthItem] = Field(default_factory=list)
    matched_count: int = Field(ge=0)
    total_count: int = Field(ge=0)


class GroundTruthExport(ExportSectionModel):
    """The export section for every ground-truth answer-scoring plugin."""

    comparison: Optional[GroundTruthComparison] = None

    @model_validator(mode="after")
    def _comparison_present_when_scored(self) -> "GroundTruthExport":
        if self.state == "scored" and self.comparison is None:
            raise ValueError("a scored ground-truth section must carry its comparison")
        return self
