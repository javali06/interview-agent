"""coverage_tags — the minimal pure-Python reference plugin.

Deterministic keyword/concept coverage over the candidate's answers: award
`marks_per_tag` for every required tag that appears. This is the smallest
complete example of the standard contract — copy it to start a new Python
plugin. See ../../AUTHORING.md.
"""
from __future__ import annotations

from pydantic import BaseModel, Field

from features.eval.plugins.base import (
    Assumption,
    BreakdownItem,
    EvalContext,
    EvalPlugin,
    PluginHelp,
    PrecheckResult,
    SegmentEvaluation,
)
from features.eval.plugins.export import (
    AdjustableSpec,
    ExportSection,
    ExportSectionModel,
    envelope,
)
from features.eval.plugins.registry import register
from features.eval.sectioner import Segment


class CoverageTagsConfig(BaseModel):
    marks_per_tag: float = Field(default=2.0, ge=0, description="Marks awarded per covered tag.")
    required_tags: list[str] = Field(
        default_factory=list,
        description="Concepts a complete answer must mention. If empty, the "
                    "question's own coverage_tags (from the cadence) are used.",
    )
    case_sensitive: bool = False


class CoverageTagItem(BaseModel):
    tag: str = Field(description="The concept the answer was checked for.")
    covered: bool = Field(description="Whether the candidate's answer contained it.")
    marks: float = Field(default=0.0, description="Marks awarded for this tag.")


class CoverageTagsExport(ExportSectionModel):
    """Export payload — which required concepts the answer did and didn't cover."""

    tags: list[CoverageTagItem] = Field(default_factory=list)
    matched: int = Field(default=0, description="How many tags were covered.")
    total: int = Field(default=0, description="How many tags were required.")


_EXPORT = ExportSection(
    key="coverage_tags",
    title="Required concepts and whether the answer covered them",
    version="1.0",
    model=CoverageTagsExport,
    # marks_earned is exactly the sum of the per-tag deltas, so flipping "they
    # DID cover quantisation" recomputes the section correctly.
    adjustable=AdjustableSpec(marks=True, items=True, item_label_noun="concept",
                              recompute="sum_deltas"),
)


@register
class CoverageTagsPlugin(EvalPlugin):
    id = "coverage_tags"
    name = "Coverage Tags"
    description = "Deterministic concept-coverage scorer: +marks per required tag the candidate mentions."
    method = "python"
    view_id = "tag_checklist"

    @classmethod
    def help(cls) -> PluginHelp:
        return PluginHelp(
            summary="Checks whether the candidate mentioned each required concept, by literal "
                    "keyword match. No LLM — fully deterministic and repeatable.",
            best_for="Quick factual checks where 'did they say X?' is enough. Uses the question's "
                     "coverage_tags from the cadence, or your own list.",
            how_it_works=[
                "Takes a list of required concept tags (yours, or the question's coverage_tags).",
                "Searches the candidate's answers for each tag as plain text.",
                "Awards marks_per_tag for every tag found; score = tags found × marks_per_tag.",
            ],
            you_configure=[
                "marks_per_tag — points for each concept found",
                "required_tags — concepts to look for (optional; defaults to the question's coverage_tags)",
                "case_sensitive — match exact case or not",
            ],
            evidence="Each tag flagged covered/missing, with the candidate turn where it was found.",
        )

    @classmethod
    def config_schema(cls) -> type[BaseModel]:
        return CoverageTagsConfig

    @classmethod
    def assumptions(cls) -> list[Assumption]:
        return [
            Assumption(key="tags", description="`required_tags` configured, OR the question carries coverage_tags."),
            Assumption(key="candidate_answer", description="The segment has at least one candidate answer.", author_actionable=False),
        ]

    @classmethod
    def export_descriptor(cls) -> ExportSection:
        return _EXPORT

    def export_section(self, segment: Segment, ev: SegmentEvaluation) -> CoverageTagsExport:
        base = envelope(_EXPORT, segment, ev)
        if ev.state != "scored":
            return CoverageTagsExport(**base)
        vp = ev.view_payload or {}
        return CoverageTagsExport(
            **base,
            tags=[
                CoverageTagItem(
                    tag=str(t.get("label") or ""),
                    # `detail` is the rendered word; the delta is the truth.
                    covered=float(t.get("delta") or 0) > 0,
                    marks=float(t.get("delta") or 0),
                )
                for t in (vp.get("tags") or [])
            ],
            matched=int(vp.get("matched") or 0),
            total=int(vp.get("total") or 0),
        )

    def precheck_cadence(self, phase: dict, config: CoverageTagsConfig) -> PrecheckResult:
        if config.required_tags:
            return PrecheckResult(ok=True)
        pool = phase.get("question_pool") or []
        if any((q.get("coverage_tags") if isinstance(q, dict) else None) for q in pool):
            return PrecheckResult(ok=True)
        # Reaching here means NO question in this phase's pool has coverage_tags
        # (the check above already covers "some questions have tags") — so unlike
        # dynamic_difficulty's own coverage_tags check, there is never a real tag
        # to source from this phase; always the labeled placeholder.
        return PrecheckResult(ok=False, unmet=[
            "Add `coverage_tags` to this phase's questions in the cadence.",
            'Example: { "coverage_tags": ["<short concept phrase this question covers>"] }',
            "Or, in the Evaluation panel's Coverage Tags card, set Required Tags to the concepts a "
            "complete answer must mention, one per line — e.g. train vs validation gap, scaled "
            "dot-product scores.",
        ])

    def precheck(self, segment: Segment, config: CoverageTagsConfig, *, ctx: EvalContext) -> PrecheckResult:
        unmet: list[str] = []
        tags = config.required_tags or segment.coverage_tags or ctx.question_meta(segment.question_id).get("coverage_tags") or []
        if not tags:
            unmet.append("No required_tags configured and the question has no coverage_tags.")
        if not segment.has_candidate_input():
            unmet.append("Segment has no candidate answer to score.")
        return PrecheckResult(ok=not unmet, unmet=unmet)

    async def evaluate(self, segment: Segment, config: CoverageTagsConfig, *, ctx: EvalContext) -> SegmentEvaluation:
        tags = list(config.required_tags or segment.coverage_tags or ctx.question_meta(segment.question_id).get("coverage_tags") or [])
        cand = segment.candidate_turns()
        hay = "\n".join(t.text for t in cand)
        hay_cmp = hay if config.case_sensitive else hay.lower()

        breakdown: list[BreakdownItem] = []
        evidence: list[int] = []
        matched = 0
        for tag in tags:
            needle = tag if config.case_sensitive else tag.lower()
            hit = bool(needle) and needle in hay_cmp
            if hit:
                matched += 1
                for t in cand:
                    body = t.text if config.case_sensitive else t.text.lower()
                    if needle in body:
                        evidence.append(t.event_index)
                        break
            breakdown.append(BreakdownItem(
                label=tag,
                delta=config.marks_per_tag if hit else 0.0,
                detail="covered" if hit else "missing",
            ))

        marks_possible = len(tags) * config.marks_per_tag
        marks_earned = matched * config.marks_per_tag
        return self.result(
            segment,
            state="scored",
            marks_earned=marks_earned,
            marks_possible=marks_possible,
            breakdown=breakdown,
            rationale=f"{matched}/{len(tags)} required concepts covered.",
            evidence_refs=sorted(set(evidence)) or segment.event_indices(),
            view_payload={
                "tags": [b.model_dump() for b in breakdown],
                "matched": matched,
                "total": len(tags),
            },
            raw={"matched_tags": matched, "total_tags": len(tags)},
        )
