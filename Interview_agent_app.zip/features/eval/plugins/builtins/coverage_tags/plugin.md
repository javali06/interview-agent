# coverage_tags

**Method:** python · **view_id:** `tag_checklist`

Deterministic concept-coverage scorer. Awards `marks_per_tag` for every required
concept that appears in the candidate's answers within the segment.

## Config
| field | default | meaning |
|---|---|---|
| `marks_per_tag` | 2.0 | marks per covered tag |
| `required_tags` | `[]` | concepts a complete answer must mention; if empty, the question's own `coverage_tags` (from the cadence) are used |
| `case_sensitive` | false | match casing exactly |

## Scoring
`marks_earned = (#tags matched) × marks_per_tag`, `marks_possible = (#tags) × marks_per_tag`.
`breakdown[]` lists each tag as covered/missing; `evidence_refs` point at the
candidate turns that mention a matched tag.

## Assumptions
- `required_tags` configured **or** the question carries `coverage_tags`.
- The segment has at least one candidate answer.

## Example
```json
{ "marks_per_tag": 2.0, "required_tags": ["query/key/value", "softmax", "scaling"], "case_sensitive": false }
```
