"""Built-in evaluation plugins. Importing this package registers them all.

Each plugin is a self-contained folder (config schema + evaluation script +
declared assumptions + view_id + plugin.md). Add a new built-in by creating a
folder here and importing it below.
"""
from __future__ import annotations

# Importing each module runs its `@register` decorator.
from features.eval.plugins.builtins import coverage_tags  # noqa: F401
from features.eval.plugins.builtins import rubric_marks  # noqa: F401
from features.eval.plugins.builtins import dynamic_difficulty  # noqa: F401
from features.eval.plugins.builtins import conversational_rubric  # noqa: F401
from features.eval.plugins.builtins import coding  # noqa: F401
from features.eval.plugins.builtins import transcription_scoring  # noqa: F401
from features.eval.plugins.builtins import translation_scoring  # noqa: F401
from features.eval.plugins.builtins import image_description_scoring  # noqa: F401

__all__ = [
    "coverage_tags", "rubric_marks", "dynamic_difficulty", "conversational_rubric", "coding",
    "transcription_scoring", "translation_scoring", "image_description_scoring",
]
