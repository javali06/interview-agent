"""transcription_scoring — strict word-for-word fidelity scoring against a
reference transcript, for the text-interview transcription phase's `ground_truth`
(see engine/brain/cadence/question_types.py). LLM finds the diffs; code turns
the diff count into a 0-10 score. See ../../AUTHORING.md.
"""
from __future__ import annotations

import re

from pydantic import BaseModel

from features.eval.plugins._ground_truth import resolve_ground_truth
from features.eval.plugins._llm import call_scoring_llm
from features.eval.plugins.base import (
    Assumption,
    BreakdownItem,
    EvalContext,
    EvalPlugin,
    PluginHelp,
    PrecheckResult,
    SegmentEvaluation,
)
from features.eval.plugins.export import (
    ExportSection,
    GroundTruthComparison,
    GroundTruthExport,
    GroundTruthItem,
    envelope,
)
from features.eval.plugins.registry import register
from features.eval.sectioner import Segment

_VALID_DIFF_TYPES = ("substitution", "deletion", "insertion")

_EXPORT = ExportSection(
    key="transcription_scoring",
    title="Transcription fidelity vs reference",
    version="1.0",
    model=GroundTruthExport,
)


class TranscriptionScoringConfig(BaseModel):
    """No admin-configured knobs — the scoring formula is fixed (see
    AUTHORING.md's "LLMs judge, Python computes"). One config class per the
    standard plugin contract even though it carries nothing to set."""


# Lowercase, strip punctuation, collapse whitespace, and drop thousands-
# separator commas in numbers — so wording case, punctuation, and "1,000" vs
# "1000" never get flagged as fidelity errors on their own. Applied to BOTH
# ground_truth and the candidate's answer before either reaches the LLM.
_PUNCT_RE = re.compile(r"[^\w\s]")
_WS_RE = re.compile(r"\s+")
_THOUSANDS_RE = re.compile(r"(?<=\d),(?=\d{3}\b)")


def _opt_str(value) -> str | None:
    """None stays None (a deletion/insertion has no counterpart); anything else
    becomes a string."""
    return None if value is None else str(value)


def _normalize(text: str) -> str:
    t = _THOUSANDS_RE.sub("", text or "")
    t = t.lower()
    t = _PUNCT_RE.sub(" ", t)
    return _WS_RE.sub(" ", t).strip()


_SYSTEM = """\
You are grading a TRANSCRIPTION exercise: the candidate listened to an audio clip \
and typed what they heard. Your ONLY job is a strict WORD-FOR-WORD fidelity check \
against the reference transcript below — this is NOT a meaning-comparison task.

A paraphrase that preserves the meaning but changes the wording is WRONG for this \
task and MUST be flagged as one error per changed word/phrase. Do not give credit \
for "close enough" wording — only exact word matches (after normalization) count.

Worked example (follow this exactly):
  REFERENCE: "the quick brown fox jumps over the lazy dog"
  CANDIDATE: "a fast brown fox leaps over the lazy dog"
  This is a paraphrase — meaning preserved, wording changed — and must be scored as
  THREE separate substitution errors, not zero:
  {"reference_word_count": 9, "diffs": [
    {"type": "substitution", "reference": "the", "candidate": "a"},
    {"type": "substitution", "reference": "quick", "candidate": "fast"},
    {"type": "substitution", "reference": "jumps", "candidate": "leaps"}
  ]}

Both texts below have already been lowercased and stripped of punctuation, so do
not flag case or punctuation differences.

Return STRICT JSON only, no prose, in exactly this shape:
{"reference_word_count": <int, the word count of the reference>,
 "diffs": [{"type": "substitution" | "deletion" | "insertion",
            "reference": "<word/phrase from the reference, or null for an insertion>",
            "candidate": "<word/phrase from the candidate, or null for a deletion>"}]}
An exact match has an empty "diffs" list."""


@register
class TranscriptionScoringPlugin(EvalPlugin):
    id = "transcription_scoring"
    name = "Transcription Ground-Truth Scoring"
    description = ("Strict word-for-word fidelity check against the question's ground_truth "
                    "reference transcript. An LLM finds the diffs; the score is computed from "
                    "the diff count, not the LLM's opinion.")
    method = "llm_judge"
    view_id = "tag_checklist"

    @classmethod
    def help(cls) -> PluginHelp:
        return PluginHelp(
            summary="Compares the candidate's transcription against the question's exact "
                    "reference transcript, word for word. Paraphrasing counts against the score.",
            best_for="Transcription questions only — requires a `ground_truth` reference "
                     "transcript on the question (set when authoring it).",
            how_it_works=[
                "Both the reference and the candidate's answer are normalized (lowercase, "
                "punctuation stripped) before comparison.",
                "An LLM lists every substitution/deletion/insertion versus the reference.",
                "score_out_of_10 = round(max(0, 1 - diffs/reference_word_count) * 10, 1) — "
                "computed in code from the diff count, never the LLM's own opinion.",
            ],
            you_configure=["Nothing — the scoring formula is fixed in code. Just give the "
                          "question a ground_truth reference transcript when authoring it."],
            evidence="Every word-level diff (substitution/deletion/insertion), reference vs "
                     "candidate wording.",
        )

    @classmethod
    def config_schema(cls) -> type[BaseModel]:
        return TranscriptionScoringConfig

    @classmethod
    def assumptions(cls) -> list[Assumption]:
        return [
            Assumption(key="ground_truth", description="The question has a `ground_truth` reference transcript set."),
            Assumption(key="candidate_answer", description="The segment has a candidate answer.", author_actionable=False),
            Assumption(key="llm", description="An LLM key is configured.", author_actionable=False),
        ]

    def precheck_cadence(self, phase: dict, config: TranscriptionScoringConfig) -> PrecheckResult:
        pool = phase.get("question_pool") or []
        phase_gt = ((phase.get("written_response") or {}).get("ground_truth") or "").strip() \
            if isinstance(phase.get("written_response"), dict) else ""
        if phase_gt:
            return PrecheckResult(ok=True)
        for q in pool:
            wr = q.get("written_response") if isinstance(q, dict) else None
            if isinstance(wr, dict) and str(wr.get("ground_truth") or "").strip():
                continue
            return PrecheckResult(ok=False, unmet=[
                f"Question '{q.get('id')}' has no `ground_truth` reference transcript — "
                "add one in the question's Ground Truth (exact transcript) field.",
            ])
        return PrecheckResult(ok=True)

    # ── export ───────────────────────────────────────────────────────────
    @classmethod
    def export_descriptor(cls) -> ExportSection:
        return _EXPORT

    def export_section(self, segment: Segment, evaluation: SegmentEvaluation) -> GroundTruthExport:
        """One comparison item per word-level diff. The reference and answer are
        the NORMALIZED forms the score was actually computed on, not the raw
        text — exporting the raw ones would not reproduce these numbers."""
        comparison = None
        if evaluation.state == "scored":
            raw = evaluation.raw or {}
            diffs = raw.get("diffs") or []
            total = int(raw.get("reference_word_count") or 0)
            comparison = GroundTruthComparison(
                expected_kind="reference_transcript",
                expected=[str(raw.get("normalized_reference") or "")],
                actual=str(raw.get("normalized_candidate") or ""),
                items=[
                    GroundTruthItem(
                        # str()-coerced: these come straight from the LLM's diff
                        # list, and a stray number would otherwise fail
                        # validation here — outside run()'s error handling.
                        expected=_opt_str(d.get("reference")),
                        actual=_opt_str(d.get("candidate")),
                        matched=False,          # an item exists here only BECAUSE it differed
                        note=str(d.get("type") or ""),
                    )
                    for d in diffs
                    if isinstance(d, dict)
                ],
                matched_count=max(0, total - len(diffs)),
                total_count=total,
            )
        return GroundTruthExport(**envelope(_EXPORT, segment, evaluation), comparison=comparison)

    def precheck(self, segment: Segment, config: TranscriptionScoringConfig, *, ctx: EvalContext) -> PrecheckResult:
        unmet: list[str] = []
        gt, err = resolve_ground_truth(segment, ctx)
        if err:
            unmet.append(f"ground truth unavailable: {err}")
        elif not isinstance(gt, str):
            unmet.append("this question's ground_truth must be a single string for transcription "
                          "(the cadence has a list — check how it was authored).")
        if not segment.has_candidate_input():
            unmet.append("Segment has no candidate answer to score.")
        if not ctx.has_scoring_llm:
            unmet.append("No LLM configured.")
        return PrecheckResult(ok=not unmet, unmet=unmet)

    async def evaluate(self, segment: Segment, config: TranscriptionScoringConfig, *, ctx: EvalContext) -> SegmentEvaluation:
        gt, _ = resolve_ground_truth(segment, ctx)
        reference = _normalize(str(gt))
        candidate_raw = " ".join(t.text for t in segment.candidate_turns()).strip()
        candidate = _normalize(candidate_raw)

        prompt = f"{_SYSTEM}\n\nREFERENCE: {reference}\nCANDIDATE: {candidate}\n\nReturn the JSON now."
        parsed = await call_scoring_llm(ctx, prompt)

        diffs_raw = parsed.get("diffs")
        if not isinstance(diffs_raw, list):
            raise ValueError(f"scoring LLM response missing a 'diffs' list: {parsed!r}")
        diffs = [d for d in diffs_raw if isinstance(d, dict) and d.get("type") in _VALID_DIFF_TYPES]

        ref_word_count = parsed.get("reference_word_count")
        if not isinstance(ref_word_count, int) or ref_word_count <= 0:
            # The LLM's count is a convenience, not load-bearing — fall back to
            # our own count of the (already normalized) reference rather than
            # failing the whole score over one missing/malformed field.
            ref_word_count = len(reference.split()) or 1

        score = round(max(0, 1 - (len(diffs) / ref_word_count)) * 10, 1)

        breakdown = [
            BreakdownItem(
                label=d.get("type", "diff"),
                delta=-1.0,
                detail=f"reference: {d.get('reference')!r} → candidate: {d.get('candidate')!r}",
            )
            for d in diffs
        ]

        return self.result(
            segment,
            state="scored",
            marks_earned=score,
            marks_possible=10.0,
            breakdown=breakdown,
            rationale=f"{len(diffs)} word-level error(s) against a {ref_word_count}-word reference.",
            evidence_refs=segment.event_indices(),
            view_payload={
                "tags": [b.model_dump() for b in breakdown],
                "matched": max(0, ref_word_count - len(diffs)),
                "total": ref_word_count,
            },
            raw={"reference_word_count": ref_word_count, "diffs": diffs,
                 "normalized_reference": reference, "normalized_candidate": candidate},
        )
