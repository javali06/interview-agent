"""coding — wraps features/coding/evaluator.py for coding-question segments.

A python(+optional LLM-judge) plugin. Reads the candidate's submission from the
segment (the `coding_code_submitted` turn the sectioner captured), runs the
existing deterministic + LLM-judge scorer, and maps the composite to benchmark
marks. This is what makes the old transcript-LLM "score-overwrite hack"
obsolete — coding is scored natively on its own segment. view_id="coding_card".
"""
from __future__ import annotations

import asyncio
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field

from features.coding.evaluator import evaluate_submission
from features.coding.questions.loader import load_library
from features.eval.plugins.base import (
    Assumption,
    BreakdownItem,
    EvalContext,
    EvalPlugin,
    PluginHelp,
    PrecheckResult,
    SegmentEvaluation,
)
from features.eval.plugins.export import ExportSection, ExportSectionModel, envelope
from features.eval.plugins.registry import register
from features.eval.sectioner import Segment, Turn

_DIMS = ("correctness", "readability", "idiomatic", "edge_cases")


# ── export section ───────────────────────────────────────────────────────────
# Coding is the `method="python"` member of the export family: the same envelope
# as the three llm_judge ground-truth plugins, a different payload. Its two
# required pieces (story AC) are the per-test results and the judge verdict, and
# they stay SEPARATE fields — the tests are deterministic fact, the judge is an
# opinion, and a consumer must be able to tell them apart.


class CodingTestResult(BaseModel):
    """One test case's outcome, as the in-browser runner reported it.

    `stdout`/`stderr` and the submitted source are deliberately NOT here — see
    docs/eval-export-pii-decision.md."""

    model_config = ConfigDict(extra="forbid")

    name: str = ""
    input: Optional[str] = None
    expected: Optional[str] = None
    actual: Optional[str] = None
    passed: bool
    error: str = ""


class CodingJudgeVerdict(BaseModel):
    """The LLM judge's code-quality opinion, absent when it did not run."""

    model_config = ConfigDict(extra="forbid")

    dimensions: dict[str, float] = Field(default_factory=dict, description="0-10 per quality dimension.")
    composite_0_10: Optional[float] = None
    rationale: str = ""


class CodingExport(ExportSectionModel):
    tests: list[CodingTestResult] = Field(default_factory=list)
    tests_passed: Optional[int] = None
    tests_total: Optional[int] = None
    pass_rate: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    # None means the judge did not run (use_llm_judge off, or no LLM key) —
    # distinct from a judge that ran and scored badly.
    judge: Optional[CodingJudgeVerdict] = None
    runs_used: Optional[int] = None
    hints_used: Optional[int] = None


_EXPORT = ExportSection(
    key="coding",
    title="Coding submission: test results and judge verdict",
    version="1.0",
    model=CodingExport,
)


def _export_test_rows(segment: Segment) -> list[CodingTestResult]:
    """The submission's per-test rows. Accepts both `passed` and `pass` keys —
    the runner emits `passed`, but older logs carry `pass` (the same tolerance
    `_normalize_results` applies on the scoring path)."""
    sub = _latest_submission(segment)
    rows = (sub.meta.get("final_test_results") if sub else None) or []
    out: list[CodingTestResult] = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        flag = r.get("passed") if r.get("passed") is not None else r.get("pass")
        out.append(CodingTestResult(
            name=str(r.get("name") or ""),
            input=r.get("input"),
            expected=r.get("expected"),
            actual=r.get("actual"),
            passed=bool(flag),
            error=str(r.get("error") or ""),
        ))
    return out


class CodingConfig(BaseModel):
    marks_possible: float = Field(default=10.0, ge=0)
    use_llm_judge: bool = True
    dimension_weights: dict[str, float] = Field(
        default_factory=lambda: {d: 1.0 for d in _DIMS},
        description="Relative weights for the LLM-judge dimensions in the composite.",
    )


def _latest_submission(segment: Segment) -> Optional[Turn]:
    subs = [t for t in segment.turns if t.kind == "coding_code_submitted"]
    return subs[-1] if subs else None


def _normalize_results(results) -> list[dict]:
    """Coerce event test-result rows to evaluate_submission's {passed: bool}."""
    out = []
    for r in results or []:
        if isinstance(r, dict):
            out.append({"passed": bool(r.get("passed") if r.get("passed") is not None else r.get("pass"))})
    return out


@register
class CodingPlugin(EvalPlugin):
    id = "coding"
    name = "Coding (tests + LLM judge)"
    description = "Scores a coding submission on test pass-rate and LLM-judged code quality."
    method = "python"
    view_id = "coding_card"

    @classmethod
    def help(cls) -> PluginHelp:
        return PluginHelp(
            summary="Scores a coding submission by combining the test pass-rate with LLM-judged code "
                    "quality (correctness, readability, idiomatic style, edge cases).",
            best_for="Coding phases — any phase with a coding round (coding_question_ids in the cadence).",
            how_it_works=[
                "Reads the candidate's final submission and test results from the segment.",
                "Computes a composite from the test pass-rate and (optionally) LLM-judged quality dimensions.",
                "Maps the composite onto marks_possible.",
            ],
            you_configure=[
                "marks_possible — points the coding question is worth",
                "use_llm_judge — add code-quality judging on top of the tests",
                "dimension_weights — relative weight of each quality dimension",
            ],
            evidence="Test pass-rate, per-dimension quality scores, runs/hints used, and the submitted code.",
        )

    @classmethod
    def config_schema(cls) -> type[BaseModel]:
        return CodingConfig

    @classmethod
    def assumptions(cls) -> list[Assumption]:
        return [Assumption(key="submission", description="The segment contains a coding submission.", author_actionable=False)]

    def precheck_cadence(self, phase: dict, config: CodingConfig) -> PrecheckResult:
        if phase.get("coding_question_ids") or phase.get("coding_question_id"):
            return PrecheckResult(ok=True)
        # Real id from the vetted library where possible, never invented — falls
        # back to a labeled placeholder if library.yaml can't load so a bad/missing
        # file can never break this message.
        example_id = "<a question id from features/coding/questions/library.yaml>"
        try:
            library = load_library()
            if library:
                example_id = next(iter(library))
        except Exception:
            pass
        return PrecheckResult(ok=False, unmet=[
            "This phase has no coding questions — add a coding round (coding_question_ids) in the cadence.",
            f'Example: {{ "coding_question_ids": ["{example_id}"] }}',
        ])

    # ── export ───────────────────────────────────────────────────────────
    @classmethod
    def export_descriptor(cls) -> ExportSection:
        return _EXPORT

    def export_section(self, segment: Segment, evaluation: SegmentEvaluation) -> CodingExport:
        if evaluation.state != "scored":
            return CodingExport(**envelope(_EXPORT, segment, evaluation))

        vp = evaluation.view_payload or {}
        tests = _export_test_rows(segment)
        dimensions = {k: float(v) for k, v in (vp.get("dimensions") or {}).items()}
        judge = CodingJudgeVerdict(
            dimensions=dimensions,
            composite_0_10=vp.get("composite_0_10"),
            rationale=evaluation.rationale,
        ) if vp.get("used_llm_judge") else None

        return CodingExport(
            **envelope(_EXPORT, segment, evaluation),
            tests=tests,
            tests_passed=sum(1 for t in tests if t.passed),
            tests_total=len(tests),
            pass_rate=vp.get("pass_rate"),
            judge=judge,
            runs_used=vp.get("runs_used"),
            hints_used=vp.get("hints_used"),
        )

    def precheck(self, segment: Segment, config: CodingConfig, *, ctx: EvalContext) -> PrecheckResult:
        if _latest_submission(segment) is None:
            return PrecheckResult(ok=False, unmet=["No coding submission found in this segment."])
        return PrecheckResult(ok=True)

    def _composite_0_10(self, score, config: CodingConfig) -> tuple[float, dict[str, float], bool]:
        """Return (composite 0-10, per-dim sub_scores, used_llm)."""
        dims = {d: getattr(score, d) for d in _DIMS if getattr(score, d) is not None}
        if dims:
            num = sum(dims[d] * config.dimension_weights.get(d, 1.0) for d in dims)
            den = sum(config.dimension_weights.get(d, 1.0) for d in dims) or 1.0
            return num / den, {d: float(dims[d]) for d in dims}, True
        return score.pass_rate * 10.0, {}, False

    async def evaluate(self, segment: Segment, config: CodingConfig, *, ctx: EvalContext) -> SegmentEvaluation:
        sub = _latest_submission(segment)
        meta = sub.meta
        hints = sum(1 for t in segment.turns if t.kind == "coding_hint_delivered")

        score = await asyncio.to_thread(
            evaluate_submission,
            question_id=segment.question_id or meta.get("question_id") or "",
            final_code=meta.get("final_code") or "",
            test_results=_normalize_results(meta.get("final_test_results")),
            runs_used=int(meta.get("runs_used") or 0),
            hints_used=hints,
            use_llm_judge=config.use_llm_judge and ctx.has_llm,
            question_prompt=segment.question_text or "",
        )

        composite, sub_scores, used_llm = self._composite_0_10(score, config)
        marks_earned = round(composite / 10.0 * config.marks_possible, 2)

        breakdown: list[BreakdownItem] = [
            BreakdownItem(label="Tests passed", delta=0.0, detail=f"{score.pass_rate * 100:.0f}% pass rate"),
        ]
        for d, v in sub_scores.items():
            breakdown.append(BreakdownItem(label=d, delta=v, detail=f"{v:g}/10"))

        return self.result(
            segment,
            state="scored",
            marks_earned=marks_earned,
            marks_possible=config.marks_possible,
            sub_scores=sub_scores,
            breakdown=breakdown,
            rationale=score.rationale or (f"{score.pass_rate * 100:.0f}% of tests passed."),
            evidence_refs=[sub.event_index],
            view_payload={
                "pass_rate": score.pass_rate,
                "dimensions": sub_scores,
                "composite_0_10": round(composite, 2),
                "runs_used": score.runs_used,
                "hints_used": hints,
                "used_llm_judge": used_llm,
            },
            raw={
                "pass_rate": score.pass_rate,
                "correctness": score.correctness, "readability": score.readability,
                "idiomatic": score.idiomatic, "edge_cases": score.edge_cases,
                "runs_used": score.runs_used, "hints_used": hints,
                "anti_cheat_signals": score.anti_cheat_signals,
            },
        )
