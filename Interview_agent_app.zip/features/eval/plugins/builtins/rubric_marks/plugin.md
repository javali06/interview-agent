# rubric_marks

**Method:** llm_judge · **view_id:** `rubric_options`

The configurable rubric: **you** define the options and the marks. Nothing about
the scoring is hard-coded — change the options and the rubric changes with them.

## How it works
1. In the UI you add **options** one at a time, each `{description, marks}`
   (e.g. `"Explains retry/backoff" → +2`, `"Ignores edge cases entirely" → -1`).
   Each option gets a number (1, 2, 3 …).
2. At grading time the **LLM-as-judge** reads one question segment and returns
   the **numbers of the options that apply** to the candidate's answer (plus a
   short note each). It never adds up marks.
3. A **Python script** sums the marks of the applicable options, then clamps to
   `[min_marks, max_marks]`. `marks_possible` = the sum of all positive-marks
   options (the best achievable score).

Penalties are just options with negative marks (e.g. "Ignores edge cases → -1"):
the judge selects them when true, and the script subtracts them.

## Reliable extraction
The judge is handed a **structured view** of the segment from
`Segment.structured_qa()` — the QUESTION, the candidate's INITIAL ANSWER, each
FOLLOW-UP probe + response, and (optionally) the live VERIFIER's verdict — not a
flat transcript. So it reliably distinguishes the question from the answer from a
follow-up.

## Config
| field | default | meaning |
|---|---|---|
| `criteria` | `[]` | your options: each `{description, marks}` |
| `min_marks` | none | optional floor on the question score |
| `max_marks` | none | optional cap on the question score |
| `use_verifier` | true | show the judge the live verifier's verdict (intent + missed tags) as a hint |

## Requirements
- Add at least one rubric option.
- (Runtime, dev-guaranteed: the segment has a candidate answer; an LLM key is set.)

## Evidence
The full question transcript plus the option list flagged applied/not, with each
one's marks delta and the judge's note — rendered by the `rubric_options` view.

## Example
```json
{ "min_marks": 0, "use_verifier": true,
  "criteria": [
    { "description": "Discusses tradeoffs of the approach", "marks": 2 },
    { "description": "States time/space complexity correctly", "marks": 1 },
    { "description": "Ignores edge cases entirely", "marks": -1 }
  ] }
```
