"""translation_scoring — meaning-equivalence scoring against one or more accepted
reference translations, for the text-interview translation phase's `ground_truth`
(see engine/brain/cadence/question_types.py). The LLM classifies meaning
preservation + match quality against the references; code maps that classification
to a 0-10 score via a fixed, named table — never the LLM's own numeric opinion.
See ../../AUTHORING.md.
"""
from __future__ import annotations

from pydantic import BaseModel

from features.eval.plugins._ground_truth import resolve_ground_truth
from features.eval.plugins._llm import call_scoring_llm
from features.eval.plugins.base import (
    Assumption,
    BreakdownItem,
    EvalContext,
    EvalPlugin,
    PluginHelp,
    PrecheckResult,
    SegmentEvaluation,
)
from features.eval.plugins.export import (
    ExportSection,
    GroundTruthComparison,
    GroundTruthExport,
    GroundTruthItem,
    envelope,
)
from features.eval.plugins.registry import register
from features.eval.sectioner import Segment

_EXPORT = ExportSection(
    key="translation_scoring",
    title="Translation meaning-equivalence vs accepted references",
    version="1.0",
    model=GroundTruthExport,
)

# The one place this scoring is calibrated — recalibrate here, never by touching
# the LLM-calling logic above. `meaning_preserved=False` always scores 0
# regardless of match_quality (handled in code, not via this table).
MATCH_QUALITY_SCORES: dict[str, float] = {
    "exact": 10.0,
    "close": 8.0,
    "partial": 5.0,
    "poor": 2.0,
}


class TranslationScoringConfig(BaseModel):
    """No admin-configured knobs — see MATCH_QUALITY_SCORES above to recalibrate."""


_SYSTEM = """\
You are grading a TRANSLATION exercise. Judge whether the candidate's translation \
preserves the MEANING of the source text, by comparing it against a numbered list \
of accepted reference translations. Different word choice, synonyms, and \
formal/informal register are all ACCEPTABLE as long as the meaning is preserved — \
this is a meaning-equivalence judgement, not an exact-wording match.

For each reference, consider how closely the candidate's translation matches it in
meaning. Then report:
  - which reference (if any) the candidate's answer is CLOSEST to,
  - whether the meaning is preserved at all,
  - and an overall match_quality: "exact" (meaning and phrasing both very close to
    a reference), "close" (meaning fully preserved, phrasing differs), "partial"
    (meaning mostly but not fully preserved — a notable gap or inaccuracy), or
    "poor" (meaning substantially wrong or missing, but SOME translation attempt
    was made).

Return STRICT JSON only, no prose, in exactly this shape:
{"best_matching_reference_index": <0-based int, or null if none are close at all>,
 "meaning_preserved": true | false,
 "match_quality": "exact" | "close" | "partial" | "poor"}"""


@register
class TranslationScoringPlugin(EvalPlugin):
    id = "translation_scoring"
    name = "Translation Ground-Truth Scoring"
    description = ("Meaning-equivalence check against the question's accepted reference "
                    "translations. An LLM classifies match quality; the score comes from a "
                    "fixed, recalibratable table — never the LLM's own number.")
    method = "llm_judge"
    view_id = "default"

    @classmethod
    def help(cls) -> PluginHelp:
        return PluginHelp(
            summary="Compares the candidate's translation against the question's accepted "
                    "reference translations for MEANING, not exact wording.",
            best_for="Translation questions only — requires one or more `ground_truth` "
                     "reference translations on the question (set when authoring it).",
            how_it_works=[
                "An LLM judges which reference the answer is closest to, whether meaning is "
                "preserved, and an overall match quality (exact / close / partial / poor).",
                f"Code maps that classification to a score: {MATCH_QUALITY_SCORES}. Meaning not "
                "preserved always scores 0, regardless of match_quality.",
            ],
            you_configure=["Nothing — the match_quality → score mapping is fixed in code "
                          "(MATCH_QUALITY_SCORES). Just give the question one or more "
                          "ground_truth accepted translations when authoring it."],
            evidence="Which reference matched best, whether meaning was preserved, and the "
                     "match-quality classification.",
        )

    @classmethod
    def config_schema(cls) -> type[BaseModel]:
        return TranslationScoringConfig

    @classmethod
    def assumptions(cls) -> list[Assumption]:
        return [
            Assumption(key="ground_truth", description="The question has one or more `ground_truth` accepted translations set."),
            Assumption(key="candidate_answer", description="The segment has a candidate answer.", author_actionable=False),
            Assumption(key="llm", description="An LLM key is configured.", author_actionable=False),
        ]

    def precheck_cadence(self, phase: dict, config: TranslationScoringConfig) -> PrecheckResult:
        pool = phase.get("question_pool") or []
        phase_wr = phase.get("written_response") if isinstance(phase.get("written_response"), dict) else {}
        phase_gt = phase_wr.get("ground_truth") if isinstance(phase_wr, dict) else None
        if isinstance(phase_gt, list) and any(str(v).strip() for v in phase_gt):
            return PrecheckResult(ok=True)
        for q in pool:
            wr = q.get("written_response") if isinstance(q, dict) else None
            gt = wr.get("ground_truth") if isinstance(wr, dict) else None
            if isinstance(gt, list) and any(str(v).strip() for v in gt):
                continue
            return PrecheckResult(ok=False, unmet=[
                f"Question '{q.get('id')}' has no `ground_truth` accepted translations — "
                "add at least one in the question's Accepted Translations field.",
            ])
        return PrecheckResult(ok=True)

    # ── export ───────────────────────────────────────────────────────────
    @classmethod
    def export_descriptor(cls) -> ExportSection:
        return _EXPORT

    def export_section(self, segment: Segment, evaluation: SegmentEvaluation) -> GroundTruthExport:
        """One comparison item per accepted reference, with `matched` on the one
        the judge picked. The references are ALTERNATIVES, not a checklist, so
        the denominator is 1 ("did the translation land?") — unlike the other two
        plugins, where every expected item has to be accounted for."""
        comparison = None
        if evaluation.state == "scored":
            vp = evaluation.view_payload or {}
            references = [str(r) for r in (vp.get("references") or [])]
            best = vp.get("best_matching_reference_index")
            preserved = bool(vp.get("meaning_preserved"))
            quality = str(vp.get("match_quality") or "")
            comparison = GroundTruthComparison(
                expected_kind="accepted_translations",
                expected=references,
                actual=" ".join(t.text for t in segment.candidate_turns()).strip(),
                items=[
                    GroundTruthItem(
                        expected=ref,
                        actual=None,          # the answer is compared as a whole, not per reference
                        matched=(i == best and preserved),
                        note=quality if i == best else "",
                    )
                    for i, ref in enumerate(references)
                ],
                matched_count=1 if preserved else 0,
                total_count=1,
            )
        return GroundTruthExport(**envelope(_EXPORT, segment, evaluation), comparison=comparison)

    def precheck(self, segment: Segment, config: TranslationScoringConfig, *, ctx: EvalContext) -> PrecheckResult:
        unmet: list[str] = []
        gt, err = resolve_ground_truth(segment, ctx)
        if err:
            unmet.append(f"ground truth unavailable: {err}")
        elif not (isinstance(gt, list) and any(isinstance(v, str) and v.strip() for v in gt)):
            unmet.append("this question's ground_truth must be a non-empty list of accepted "
                          "translations for translation (the cadence has a single string — "
                          "check how it was authored).")
        if not segment.has_candidate_input():
            unmet.append("Segment has no candidate answer to score.")
        if not ctx.has_scoring_llm:
            unmet.append("No LLM configured.")
        return PrecheckResult(ok=not unmet, unmet=unmet)

    async def evaluate(self, segment: Segment, config: TranslationScoringConfig, *, ctx: EvalContext) -> SegmentEvaluation:
        gt, _ = resolve_ground_truth(segment, ctx)
        references = [str(v) for v in gt if isinstance(v, str) and v.strip()]
        candidate_answer = " ".join(t.text for t in segment.candidate_turns()).strip()

        ref_list = "\n".join(f"{i}. {r}" for i, r in enumerate(references))
        prompt = (
            f"{_SYSTEM}\n\n"
            f"ACCEPTED REFERENCE TRANSLATIONS:\n{ref_list}\n\n"
            f"CANDIDATE'S TRANSLATION:\n{candidate_answer or '(no answer)'}\n\n"
            "Return the JSON now."
        )
        parsed = await call_scoring_llm(ctx, prompt)

        meaning_preserved = bool(parsed.get("meaning_preserved"))
        quality = str(parsed.get("match_quality") or "").strip().lower()
        if not meaning_preserved:
            score = 0.0
        else:
            if quality not in MATCH_QUALITY_SCORES:
                raise ValueError(f"scoring LLM returned an unexpected match_quality {quality!r}")
            score = MATCH_QUALITY_SCORES[quality]

        idx = parsed.get("best_matching_reference_index")
        best_ref = references[idx] if isinstance(idx, int) and 0 <= idx < len(references) else None

        breakdown = [
            BreakdownItem(label="meaning preserved", delta=0.0, detail="yes" if meaning_preserved else "no"),
            BreakdownItem(label="match quality", delta=score, detail=quality or "(none reported)"),
            BreakdownItem(label="best matching reference", delta=0.0,
                          detail=best_ref if best_ref is not None else "(none close enough)"),
        ]

        return self.result(
            segment,
            state="scored",
            marks_earned=score,
            marks_possible=max(MATCH_QUALITY_SCORES.values()),
            breakdown=breakdown,
            rationale=(f"Meaning preserved: {meaning_preserved}; match quality: "
                       f"{quality or 'n/a'}" + (f"; best match: {best_ref!r}" if best_ref else "")),
            evidence_refs=segment.event_indices(),
            view_payload={"references": references, "best_matching_reference_index": idx,
                          "meaning_preserved": meaning_preserved, "match_quality": quality},
            raw=parsed,
        )
