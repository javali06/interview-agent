"""image_description_scoring — key-element coverage scoring against a checklist
of facts, for the text-interview image-description phase's `ground_truth` (see
engine/brain/cadence/question_types.py). The LLM judges per-element coverage;
code turns the coverage count into a 0-10 score. Mirrors the coverage_tags
plugin's shape, with LLM judgement in place of literal keyword match (an image
element is rarely stated in the cadence's exact words). See ../../AUTHORING.md.
"""
from __future__ import annotations

from pydantic import BaseModel

from features.eval.plugins._ground_truth import resolve_ground_truth
from features.eval.plugins._llm import call_scoring_llm
from features.eval.plugins.base import (
    Assumption,
    BreakdownItem,
    EvalContext,
    EvalPlugin,
    PluginHelp,
    PrecheckResult,
    SegmentEvaluation,
)
from features.eval.plugins.export import (
    ExportSection,
    GroundTruthComparison,
    GroundTruthExport,
    GroundTruthItem,
    envelope,
)
from features.eval.plugins.registry import register
from features.eval.sectioner import Segment

_EXPORT = ExportSection(
    key="image_description_scoring",
    title="Image-description key-element coverage",
    version="1.0",
    model=GroundTruthExport,
)


class ImageDescriptionScoringConfig(BaseModel):
    """No admin-configured knobs — the scoring formula is fixed (see
    AUTHORING.md's "LLMs judge, Python computes")."""


_SYSTEM = """\
You are grading an IMAGE DESCRIPTION exercise. You are given a checklist of KEY \
ELEMENTS/FACTS the image is known to contain, and the candidate's written \
description of the image (they cannot re-look at the image; you are judging their \
description against the checklist, not the image itself).

For EACH key element in the checklist, decide whether the candidate's description \
mentions it OR clearly implies it (e.g. describing "cyclist riding down a street" \
clearly implies a bicycle, even without the word "bicycle"). Do not require exact \
wording — judge whether the FACT is conveyed.

Return STRICT JSON only, no prose, in exactly this shape, with ONE entry per key
element IN THE SAME ORDER AND EXACT TEXT as given:
{"element_coverage": [{"element": "<the exact key element text>", "covered": true | false}]}"""


@register
class ImageDescriptionScoringPlugin(EvalPlugin):
    id = "image_description_scoring"
    name = "Image Description Ground-Truth Scoring"
    description = ("Checks the candidate's description against the question's key-element "
                    "checklist. An LLM judges per-element coverage; the score is the fraction "
                    "of elements covered.")
    method = "llm_judge"
    view_id = "tag_checklist"

    @classmethod
    def help(cls) -> PluginHelp:
        return PluginHelp(
            summary="Checks whether the candidate's description covers each key element/fact "
                    "in the question's checklist, judged by an LLM (not literal keyword match).",
            best_for="Image description questions only — requires one or more `ground_truth` "
                     "key elements on the question (set when authoring it).",
            how_it_works=[
                "An LLM judges, per key element, whether the candidate's description mentions "
                "or clearly implies it.",
                "score_out_of_10 = round((elements covered / total elements) * 10, 1) — "
                "computed in code from the coverage count, never the LLM's own opinion.",
            ],
            you_configure=["Nothing — the scoring formula is fixed in code. Just give the "
                          "question one or more ground_truth key elements when authoring it."],
            evidence="Each key element flagged covered/not covered.",
        )

    @classmethod
    def config_schema(cls) -> type[BaseModel]:
        return ImageDescriptionScoringConfig

    @classmethod
    def assumptions(cls) -> list[Assumption]:
        return [
            Assumption(key="ground_truth", description="The question has one or more `ground_truth` key elements set."),
            Assumption(key="candidate_answer", description="The segment has a candidate answer.", author_actionable=False),
            Assumption(key="llm", description="An LLM key is configured.", author_actionable=False),
        ]

    def precheck_cadence(self, phase: dict, config: ImageDescriptionScoringConfig) -> PrecheckResult:
        pool = phase.get("question_pool") or []
        phase_wr = phase.get("written_response") if isinstance(phase.get("written_response"), dict) else {}
        phase_gt = phase_wr.get("ground_truth") if isinstance(phase_wr, dict) else None
        if isinstance(phase_gt, list) and any(str(v).strip() for v in phase_gt):
            return PrecheckResult(ok=True)
        for q in pool:
            wr = q.get("written_response") if isinstance(q, dict) else None
            gt = wr.get("ground_truth") if isinstance(wr, dict) else None
            if isinstance(gt, list) and any(str(v).strip() for v in gt):
                continue
            return PrecheckResult(ok=False, unmet=[
                f"Question '{q.get('id')}' has no `ground_truth` key elements — add at least "
                "one in the question's Key Elements / Facts field.",
            ])
        return PrecheckResult(ok=True)

    # ── export ───────────────────────────────────────────────────────────
    @classmethod
    def export_descriptor(cls) -> ExportSection:
        return _EXPORT

    def export_section(self, segment: Segment, evaluation: SegmentEvaluation) -> GroundTruthExport:
        """One comparison item per key element. Read off `breakdown`, which
        `evaluate` builds from the cadence's element list in code — the LLM's own
        `element_coverage` echo in `raw` can be short or reordered."""
        comparison = None
        if evaluation.state == "scored":
            items = [
                GroundTruthItem(
                    expected=b.label,
                    actual=None,             # coverage is judged against the answer as a whole
                    matched=(b.detail == "covered"),
                    note=b.detail,
                )
                for b in evaluation.breakdown
            ]
            comparison = GroundTruthComparison(
                expected_kind="key_elements",
                expected=[b.label for b in evaluation.breakdown],
                actual=" ".join(t.text for t in segment.candidate_turns()).strip(),
                items=items,
                matched_count=sum(1 for i in items if i.matched),
                total_count=len(items),
            )
        return GroundTruthExport(**envelope(_EXPORT, segment, evaluation), comparison=comparison)

    def precheck(self, segment: Segment, config: ImageDescriptionScoringConfig, *, ctx: EvalContext) -> PrecheckResult:
        unmet: list[str] = []
        gt, err = resolve_ground_truth(segment, ctx)
        if err:
            unmet.append(f"ground truth unavailable: {err}")
        elif not (isinstance(gt, list) and any(isinstance(v, str) and v.strip() for v in gt)):
            unmet.append("this question's ground_truth must be a non-empty list of key elements "
                          "for image_description (the cadence has a single string — check how it "
                          "was authored).")
        if not segment.has_candidate_input():
            unmet.append("Segment has no candidate answer to score.")
        if not ctx.has_scoring_llm:
            unmet.append("No LLM configured.")
        return PrecheckResult(ok=not unmet, unmet=unmet)

    async def evaluate(self, segment: Segment, config: ImageDescriptionScoringConfig, *, ctx: EvalContext) -> SegmentEvaluation:
        gt, _ = resolve_ground_truth(segment, ctx)
        elements = [str(v) for v in gt if isinstance(v, str) and v.strip()]
        candidate_answer = " ".join(t.text for t in segment.candidate_turns()).strip()

        checklist = "\n".join(f"- {e}" for e in elements)
        prompt = (
            f"{_SYSTEM}\n\n"
            f"KEY ELEMENTS CHECKLIST:\n{checklist}\n\n"
            f"CANDIDATE'S DESCRIPTION:\n{candidate_answer or '(no answer)'}\n\n"
            "Return the JSON now."
        )
        parsed = await call_scoring_llm(ctx, prompt)

        coverage_raw = parsed.get("element_coverage")
        if not isinstance(coverage_raw, list) or not coverage_raw:
            raise ValueError(f"scoring LLM response missing an 'element_coverage' list: {parsed!r}")

        total = len(elements)
        per_element = coverage_raw[:total] if len(coverage_raw) >= total else coverage_raw
        marks_per_element = 10.0 / total if total else 0.0

        breakdown: list[BreakdownItem] = []
        covered_count = 0
        for i, element in enumerate(elements):
            item = per_element[i] if i < len(per_element) else {}
            covered = bool(isinstance(item, dict) and item.get("covered"))
            if covered:
                covered_count += 1
            breakdown.append(BreakdownItem(
                label=element,
                delta=marks_per_element if covered else 0.0,
                detail="covered" if covered else "not mentioned",
            ))

        score = round((covered_count / total) * 10, 1) if total else 0.0

        return self.result(
            segment,
            state="scored",
            marks_earned=score,
            marks_possible=10.0,
            breakdown=breakdown,
            rationale=f"{covered_count}/{total} key elements covered.",
            evidence_refs=segment.event_indices(),
            view_payload={
                "tags": [b.model_dump() for b in breakdown],
                "matched": covered_count,
                "total": total,
            },
            raw={"element_coverage": coverage_raw},
        )
