"""Shared ground-truth lookup for the transcription / translation /
image_description answer-scoring plugins.

Resolves a segment's question against the cadence's `written_response` config:
the question's own ground_truth if it set one, else the phase-level default —
the same phase-default-then-question-override shape as
`engine.brain.cadence.schema.WrittenResponse.resolved_for`. Duck-typed on plain
dicts (see base.py's `EvalContext.cadence` docstring: "CadencePlan-like or
dict; duck-typed") rather than importing the cadence schema module — no
existing plugin does that, so this keeps the plugin layer decoupled from it.
"""
from __future__ import annotations

from typing import Any, Optional

from features.eval.plugins.base import EvalContext
from features.eval.sectioner import Segment


def _blank(value: Any) -> bool:
    """Same "is this actually set" rule used by the cadence schema's own
    `_is_blank` (engine/brain/cadence/schema.py): None, a blank/whitespace-only
    string, or an empty-or-all-blank list all count as unset."""
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    if isinstance(value, list):
        return not any(isinstance(v, str) and v.strip() for v in value)
    return False


def _written_response_dict(holder: Any) -> dict:
    if holder is None:
        return {}
    wr = holder.get("written_response") if isinstance(holder, dict) else getattr(holder, "written_response", None)
    if isinstance(wr, dict):
        return wr
    return {}


def resolve_ground_truth(segment: Segment, ctx: EvalContext) -> tuple[Optional[Any], Optional[str]]:
    """The question's resolved `ground_truth` — a question-level value if it set
    one, else the phase-level default — or `(None, reason)` when neither the
    question nor the phase has one. Never raises; callers (each plugin's
    `precheck`) decide what a missing/wrong-shaped value means."""
    cadence = ctx.cadence
    phases = cadence.get("phases") if isinstance(cadence, dict) else getattr(cadence, "phases", None)
    phase = next(
        (p for p in (phases or [])
         if (p.get("id") if isinstance(p, dict) else getattr(p, "id", None)) == segment.phase_id),
        None,
    )
    if phase is None:
        return None, "the phase could not be found in the cadence"

    phase_gt = _written_response_dict(phase).get("ground_truth")
    question_meta = ctx.question_meta(segment.question_id)
    question_gt = _written_response_dict(question_meta).get("ground_truth")

    ground_truth = question_gt if not _blank(question_gt) else phase_gt
    if _blank(ground_truth):
        return None, "no ground_truth is set for this question in the cadence"
    return ground_truth, None
