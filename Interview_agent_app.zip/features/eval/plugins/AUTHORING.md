# Authoring an evaluation plugin

A **plugin** scores one interview *segment* (a single question, a coding
question, or a whole generic phase) and returns benchmark marks plus the
evidence behind them. Plugins are how a TA configures *what* and *how much* each
phase is worth, with the scoring method being either an **LLM-as-judge** or a
**pure Python script**.

This is the guide for adding a new one. The smallest complete example is
[`builtins/coverage_tags/`](builtins/coverage_tags/__init__.py) — copy it.

---

## 1. What a plugin is

Each plugin lives in its own folder under `builtins/<plugin_id>/`:

```
builtins/my_plugin/
  __init__.py    # the plugin class: config schema + assumptions + evaluate()
  plugin.md      # what it does, its assumptions, its view_id, an example config
```

A plugin subclasses `EvalPlugin` (`base.py`) and sets five class attributes,
implements `config_schema()` + `evaluate()`, and registers with `@register`.

```python
from pydantic import BaseModel, Field
from features.eval.plugins.base import EvalPlugin, EvalContext, SegmentEvaluation, PluginHelp
from features.eval.plugins.registry import register
from features.eval.sectioner import Segment

class MyConfig(BaseModel):
    marks_possible: float = Field(default=10.0, ge=0)
    # ...whatever the TA should configure (marks, weights, thresholds)...

@register
class MyPlugin(EvalPlugin):
    id = "my_plugin"                 # stable, unique
    name = "My Plugin"
    description = "One-line summary shown on the plugin picker."
    method = "python"               # or "llm_judge"
    view_id = "tag_checklist"       # FOREIGN KEY into the UI template catalog

    @classmethod
    def help(cls):                   # ← self-explanatory help, shown in the UI (see §1b)
        return PluginHelp(
            summary="What it does, in one or two plain sentences.",
            best_for="When a TA should pick this (phase type / question style).",
            how_it_works=["Step 1.", "Step 2.", "Step 3."],
            you_configure=["marks_possible — points the segment is worth", "..."],
            evidence="What shows up as evidence in the report.",
        )

    @classmethod
    def config_schema(cls): return MyConfig

    async def evaluate(self, segment: Segment, config: MyConfig, *, ctx: EvalContext) -> SegmentEvaluation:
        return self.result(segment, state="scored", marks_earned=7, marks_possible=config.marks_possible,
                           rationale="...", evidence_refs=segment.event_indices())
```

Then import it from `builtins/__init__.py` so it registers on startup.

---

## 1b. Make it self-explanatory (required)

A TA picking a plugin should never have to guess what it does. Two things make a
plugin self-explanatory in the UI, and you must provide both:

- **`help()`** returns a `PluginHelp` rendered at the **top of the plugin card**
  (collapsible, open by default): `summary`, `best_for`, `how_it_works[]`,
  `you_configure[]`, `evidence`. Keep it jargon-free — interviewers read this,
  not engineers. Don't restate cadence requirements here; `assumptions()` (§4)
  already drives the "Needs from the cadence" list.
- **`Field(..., description=...)`** on every config field. The generic
  `SchemaForm` renders each field's description inline, so the knobs explain
  themselves with no bespoke frontend.

`plugin_catalog()` exposes `help` + the JSON-schema to the UI automatically once
you set them — no frontend change needed.

---

## 2. The `view_id` is a foreign key — you do not ship a template

`view_id` references a result-view **template that already exists in the
evaluation UI** (`ui/web/src/components/eval-views/`). The UI owns the
templates; your plugin only names which one renders its `view_payload`.

- **Reuse** an existing `view_id` when one fits (e.g. `tag_checklist`,
  `rubric_options`, `difficulty_breakdown`, `dimension_card`, `coding_card`).
- Only when you need a genuinely new visualization do you ask for a new template
  to be added to the catalog — and once it exists, any plugin may reference it.
- An unknown `view_id` falls back to a generic `DefaultView` (and is flagged).

Put everything the template needs into `SegmentEvaluation.view_payload`.

---

## 3. Scoring rules (guidelines)

- **Benchmark, not percentage.** Return `marks_earned` and `marks_possible`.
  The aggregator sums these across segments → phase → grand total. Never return
  a 0–100 score.
- **LLMs judge, Python computes.** In an `llm_judge` plugin, the LLM should
  *select/classify* (e.g. which rubric criteria apply); your code does the
  arithmetic. Never ask the LLM to add up marks.
- **Cite evidence.** Populate `evidence_refs` with the `event_index` of the
  turns that justify the score so the UI can deep-link to the transcript.
- **Don't score absence as 0.** If the segment can't be judged, return a state
  other than `scored`:
  - `not_observed` — the question/phase wasn't reached.
  - `insufficient_evidence` — too little to judge.
  - `assumptions_unmet` — a required input is missing (see §4).
  These are excluded from totals (a no-data marker, not a zero).
- **Itemize.** Use `breakdown` (a list of `BreakdownItem{label, delta, detail}`)
  so the detail view can show how each mark was earned or deducted.

---

## 4. Declare your assumptions

Override `assumptions()` to list the inputs you require, and `precheck()` to
validate them against the segment + cadence. Unmet assumptions short-circuit to
`state="assumptions_unmet"` with a clear message (shown on the phase tile), so a
plugin is never silently mis-applied.

```python
@classmethod
def assumptions(cls):
    return [Assumption(key="difficulty", description="Question has a difficulty in the cadence.")]

def precheck(self, segment, config, *, ctx):
    if not (segment.difficulty or ctx.question_meta(segment.question_id).get("difficulty")):
        return PrecheckResult(ok=False, unmet=["Question has no difficulty — add it to the cadence YAML."])
    return PrecheckResult(ok=True)
```

---

## 5. Inputs available to you

`evaluate(segment, config, *, ctx)`:

- **`segment`** (`features/eval/sectioner.py`): the unit to grade.
  - `.turns` — the full multi-party transcript, in order. Each `Turn` has
    `speaker` ∈ {candidate, ai, interviewer_ta, verifier, system}, `text`,
    `event_index`, and `meta` (e.g. a verifier turn's `missing_tags`, a coding
    submission's `final_code`/`passed`/`total`/`runs_used`).
  - Helpers: `.candidate_turns()`, `.verifier_turns()`, `.has_candidate_input()`,
    `.event_indices()`, `.transcript_text()`.
  - `.structured_qa()` → `{question, initial_answer, follow_ups: [{probe, answer}],
    verifier_missing}` — a LABELED split of the segment (question vs initial
    answer vs each follow-up round vs the verifier's missed tags). Prefer this
    over the flat `.transcript_text()` when an LLM judge needs to tell the
    question from the answer from a follow-up.
  - `.question_id`, `.question_text`, `.topic`, `.difficulty`, `.coverage_tags`.
- **`config`**: an instance of your `config_schema()`, already validated.
- **`ctx`** (`EvalContext`): `role`, `jd_text`, `resume_summary`,
  `seniority_bar`, `cadence`, `ctx.question_meta(question_id)` (cadence lookup
  fallback), and `await ctx.complete(system, user)` for LLM calls
  (`ctx.has_llm` is False when no key is configured — degrade gracefully).

---

## 5b. Contribute your export section (optional, but do it)

`SegmentEvaluation` is shaped for the UI. The **export** is the other consumer:
a machine-readable JSON document that leaves the portal, so it needs a declared
schema, a version, and an explicit "not scored" — see
[`export.py`](export.py) for the contract. Two pieces:

```python
from features.eval.plugins.export import ExportSection, ExportSectionModel, envelope

class MyExport(ExportSectionModel):        # the envelope + your payload
    my_field: list[str] = []

_EXPORT = ExportSection(key="my_plugin", title="What this section holds",
                        version="1.0", model=MyExport)

    @classmethod
    def export_descriptor(cls): return _EXPORT

    def export_section(self, segment, evaluation) -> MyExport:
        if evaluation.state != "scored":
            return MyExport(**envelope(_EXPORT, segment, evaluation))
        return MyExport(**envelope(_EXPORT, segment, evaluation), my_field=[...])
```

Rules the contract enforces for you, so don't work around them:

- **Never export a 0 for something you couldn't grade.** `envelope()` drops the
  marks and fills `not_scored_reason` for every non-`scored` state, and the model
  *rejects* marks alongside one. This is §3's "don't score absence as 0", made
  structural.
- **Sections are closed** (`extra="forbid"`), so the emitted JSON can't drift
  from `descriptor.json_schema()`. Add a field to the model, not to the dict.
- **Bump `version`** when you change your section's shape. You own that number;
  nobody else's section is affected.
- **Reuse a shape if one fits.** The three ground-truth plugins all export the
  same `GroundTruthExport`/`GroundTruthComparison` rather than three lookalikes —
  a consumer reads expected-vs-actual once. Prefer widening a shared shape over
  inventing a parallel one.
- **Mind what you put in it.** The export leaves the portal: event-index
  pointers yes, transcript text no, bar the documented exceptions. Read
  [`docs/eval-export-pii-decision.md`](../../../docs/eval-export-pii-decision.md)
  before adding any field that carries the candidate's own words.

Declaring no descriptor is fine — your plugin simply contributes no section, and
`export_schemas()` (the export's self-description) leaves it out.

---

## 6. System restrictions

- **No I/O beyond `ctx`.** Don't read files, hit the network, or touch global
  state. The only external call allowed is `ctx.complete(...)` for `llm_judge`
  plugins.
- **Be deterministic** in the Python path (no `random`, no wall-clock-dependent
  branches) so re-runs are reproducible and the revise loop is stable.
- **Degrade, don't crash.** `run()` wraps `evaluate()` and turns any exception
  into `state="error"`, but prefer returning an explicit non-`scored` state.
- **Stay within your segment.** Score only the segment you were given; cross-
  segment/phase synthesis is the aggregator's job.
