"""features/eval/plugins/ — pluggable, per-phase evaluation.

A plugin grades one interview `Segment` (from features/eval/sectioner.py) and
returns benchmark marks + evidence. Plugins are LLM-as-judge or pure Python and
all conform to the one standard contract in `base.py`. Importing this package
registers every built-in plugin.

Public API:
    EvalPlugin, EvalContext, SegmentEvaluation, BreakdownItem, Assumption
    register, get_plugin, has_plugin, list_plugins, plugin_catalog
    ExportSection, ExportSectionModel, export_schemas   (the export contract)
    is_enabled()        -> bool   (EVAL_PLUGINS_ENABLED feature flag)
"""
from features.eval.plugins.base import (
    Assumption,
    BreakdownItem,
    EvalContext,
    EvalPlugin,
    PrecheckResult,
    SegmentEvaluation,
)
from features.eval.plugins.export import (
    ExportSection,
    ExportSectionModel,
    GroundTruthComparison,
    GroundTruthExport,
    GroundTruthItem,
)
from features.eval.plugins.feature_flag import is_enabled
from features.eval.plugins.registry import (
    export_schemas,
    get_plugin,
    has_plugin,
    list_plugins,
    plugin_catalog,
    register,
)

# Trigger built-in registration on package import.
from features.eval.plugins import builtins  # noqa: F401,E402

__all__ = [
    "EvalPlugin",
    "EvalContext",
    "SegmentEvaluation",
    "BreakdownItem",
    "Assumption",
    "PrecheckResult",
    "ExportSection",
    "ExportSectionModel",
    "GroundTruthComparison",
    "GroundTruthExport",
    "GroundTruthItem",
    "register",
    "get_plugin",
    "has_plugin",
    "list_plugins",
    "plugin_catalog",
    "export_schemas",
    "is_enabled",
]
