"""The one standard contract every evaluation plugin conforms to.

A plugin is a self-contained unit of *(config schema + evaluation script +
declared assumptions + view_id)*. It grades ONE pre-extracted interview
`Segment` (see features/eval/sectioner.py) and returns a `SegmentEvaluation`
with **benchmark-style** marks (`marks_earned` / `marks_possible`), itemized
`breakdown`, a `rationale`, and `evidence_refs` (event indices) pointing back
at the transcript rows that justify the score.

Method is either:
  - "llm_judge": an LLM makes the judgement, code computes the score.
  - "python":    a deterministic script computes everything.

`view_id` is a FOREIGN KEY into the evaluation UI's template catalog (the UI
owns the templates). The plugin never defines a template — it only names which
one should render its `view_payload`.

See AUTHORING.md for the author-facing guide.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Awaitable, Callable, ClassVar, Literal, Optional

from pydantic import BaseModel, Field

from features.eval.sectioner import Segment

if TYPE_CHECKING:  # export.py imports FROM here, so keep this type-only
    from features.eval.plugins.export import ExportSection, ExportSectionModel

Method = Literal["llm_judge", "python"]
EvalState = Literal["scored", "not_observed", "insufficient_evidence", "assumptions_unmet", "error"]


class Assumption(BaseModel):
    """A declared input a plugin requires. Surfaced in the UI tile so the
    author knows what a plugin needs before assigning it to a phase.

    `author_actionable` marks whether the TA can actually do something about it
    (e.g. add `difficulty` to the cadence, or configure the rubric options). Set
    it False for runtime/developer preconditions the TA can't control (a
    candidate answer being present, an LLM key being configured) — the UI hides
    those so the requirements list shows only what the author can act on."""

    key: str
    description: str
    author_actionable: bool = True


class PluginHelp(BaseModel):
    """Plain-language, author-facing help shown at the TOP of the plugin card in
    the UI, so a TA understands what a plugin is for and when to use it instead
    of guessing from its name. Surfaced via `plugin_catalog()`.

    Keep every field jargon-free and concrete — this is read by interviewers, not
    engineers. `assumptions()` already covers "what the cadence must provide", so
    don't repeat that here."""

    summary: str = ""              # 1-2 sentences: what it does, in plain words
    best_for: str = ""             # when to pick it (phase type / question style)
    how_it_works: list[str] = Field(default_factory=list)   # the scoring steps, in order
    you_configure: list[str] = Field(default_factory=list)  # the knobs the author sets
    evidence: str = ""             # what shows up as evidence/detail in the report


class PrecheckResult(BaseModel):
    ok: bool
    unmet: list[str] = Field(default_factory=list)


class BreakdownItem(BaseModel):
    """One line of how marks were earned/deducted (for the detail view)."""

    label: str
    delta: float = 0.0
    detail: str = ""


class SegmentEvaluation(BaseModel):
    """A plugin's verdict on one segment. Numbers are benchmark marks; the
    aggregator sums them in code. Non-`scored` states are excluded from totals
    (never counted as 0)."""

    plugin_id: str
    segment_id: str
    phase_id: str
    state: EvalState = "scored"
    marks_earned: float = 0.0
    marks_possible: float = 0.0
    sub_scores: dict[str, float] = Field(default_factory=dict)
    breakdown: list[BreakdownItem] = Field(default_factory=list)
    rationale: str = ""
    evidence_refs: list[int] = Field(default_factory=list)
    method: Method = "python"
    view_id: str = "default"
    view_payload: dict[str, Any] = Field(default_factory=dict)
    raw: dict[str, Any] = Field(default_factory=dict)

    @property
    def is_scored(self) -> bool:
        return self.state == "scored"


@dataclass
class EvalContext:
    """Shared services handed to every plugin so they don't each re-resolve
    role/JD/LLM. The orchestrator (app/plugin_evaluation.py) builds this."""

    role: str = ""
    jd_text: str = ""
    resume_summary: str = ""
    seniority_bar: str = ""
    cadence: Any = None  # CadencePlan-like or dict; duck-typed
    # Async LLM accessor injected by the orchestrator. Signature:
    #   async def(system: str, user: str) -> str
    # None when no LLM key is configured (llm_judge plugins then degrade).
    llm_complete: Optional[Callable[..., Awaitable[str]]] = field(default=None, repr=False)
    # A SECOND, separate raw completion accessor for answer-scoring plugins
    # (transcription/translation/image_description ground-truth scoring) that
    # need their OWN explicitly-configured model + temperature=0, independent of
    # the interview's SLOW_MODEL/temperature=0.2 used by `llm_complete`. Injected
    # by the same orchestrator, over the same credentials. Signature:
    #   async def(model: str, prompt: str) -> str
    # None when no LLM key is configured. Plugins should go through
    # `features.eval.plugins._llm.call_scoring_llm` rather than this directly.
    score_llm_raw: Optional[Callable[[str, str], Awaitable[str]]] = field(default=None, repr=False)

    @property
    def has_llm(self) -> bool:
        return self.llm_complete is not None

    @property
    def has_scoring_llm(self) -> bool:
        """Whether `score_with_llm` (and therefore `call_scoring_llm`) can
        actually reach an LLM. Deliberately separate from `has_llm` — a plugin
        that only ever calls `score_with_llm` must not check `has_llm`, which
        reflects the OTHER accessor."""
        return self.score_llm_raw is not None

    async def complete(self, system: str, user: str) -> Optional[str]:
        if self.llm_complete is None:
            return None
        return await self.llm_complete(system=system, user=user)

    async def score_with_llm(self, model: str, prompt: str) -> Optional[str]:
        if self.score_llm_raw is None:
            return None
        return await self.score_llm_raw(model, prompt)

    def question_meta(self, question_id: Optional[str]) -> dict[str, Any]:
        """Look up a pool question's metadata (difficulty/coverage_tags/topic)
        from the cadence by id — the fallback when a log lacks the identifiers
        on `question_dispatched`. Returns {} when unknown."""
        if not question_id or self.cadence is None:
            return {}
        cad = self.cadence
        phases = cad.get("phases") if isinstance(cad, dict) else getattr(cad, "phases", None)
        for p in phases or []:
            pool = p.get("question_pool") if isinstance(p, dict) else getattr(p, "question_pool", None)
            for q in pool or []:
                qid = q.get("id") if isinstance(q, dict) else getattr(q, "id", None)
                if qid == question_id:
                    if isinstance(q, dict):
                        return dict(q)
                    return {
                        "difficulty": getattr(q, "difficulty", None),
                        "coverage_tags": list(getattr(q, "coverage_tags", []) or []),
                        "topic": getattr(q, "topic", ""),
                    }
        return {}


class EvalPlugin:
    """Base class for evaluation plugins. Subclass, set the class attributes,
    implement `config_schema()` and `evaluate()`, and register with
    `@register`. Override `assumptions()`/`precheck()` to declare required
    inputs."""

    id: ClassVar[str] = ""
    name: ClassVar[str] = ""
    description: ClassVar[str] = ""
    method: ClassVar[Method] = "python"
    view_id: ClassVar[str] = "default"

    # ── config ───────────────────────────────────────────────────────────
    @classmethod
    def config_schema(cls) -> type[BaseModel]:
        raise NotImplementedError

    @classmethod
    def default_config(cls) -> BaseModel:
        """Default config instance. Works when every field has a default;
        override for plugins whose config has required fields."""
        return cls.config_schema()()

    @classmethod
    def parse_config(cls, data: Any) -> BaseModel:
        schema = cls.config_schema()
        if data is None:
            return cls.default_config()
        if isinstance(data, schema):
            return data
        if isinstance(data, BaseModel):
            data = data.model_dump()
        return schema.model_validate(data)

    # ── help (author-facing, shown in the UI) ────────────────────────────
    @classmethod
    def help(cls) -> "PluginHelp":
        """Plain-language help shown at the top of the plugin card. Default
        derives a bare summary from `description`; every built-in overrides this
        with a full, self-explanatory guide (best_for / how_it_works / etc.)."""
        return PluginHelp(summary=cls.description)

    # ── assumptions ──────────────────────────────────────────────────────
    @classmethod
    def assumptions(cls) -> list[Assumption]:
        return []

    def precheck(self, segment: Segment, config: BaseModel, *, ctx: EvalContext) -> PrecheckResult:
        return PrecheckResult(ok=True)

    def precheck_cadence(self, phase: dict, config: BaseModel) -> PrecheckResult:
        """Authoring-time check: does the CADENCE phase (a plain dict from the
        cadence YAML) provide what this plugin needs? Used by the per-phase
        tiles UI to flag, deterministically, when the chosen plugin can't score
        the current cadence (e.g. dynamic_difficulty needs difficulty +
        coverage_tags on every question). Default: ok. Plugins with cadence
        requirements override. NOT called for disabled (not-scored) phases."""
        return PrecheckResult(ok=True)

    # ── export (machine-readable evaluation JSON) ────────────────────────
    # A plugin's verdict has two audiences: the UI (`view_id`/`view_payload`
    # above) and the export document. These two hooks are the second audience —
    # see export.py for the contract, and why it lives in its own module.
    # Returning None (the default) simply means this plugin contributes no
    # section yet; the export skips it rather than emitting a half-shape.
    @classmethod
    def export_descriptor(cls) -> Optional["ExportSection"]:
        """This plugin's static declaration of the export section it owns."""
        return None

    def export_section(
        self, segment: Segment, evaluation: SegmentEvaluation
    ) -> Optional["ExportSectionModel"]:
        """Fill this plugin's export section from one segment's verdict. Must
        return an instance of `export_descriptor().model`, or None."""
        return None

    # ── scoring ──────────────────────────────────────────────────────────
    async def evaluate(self, segment: Segment, config: BaseModel, *, ctx: EvalContext) -> SegmentEvaluation:
        raise NotImplementedError

    async def run(self, segment: Segment, config: Any, *, ctx: EvalContext) -> SegmentEvaluation:
        """Public entry point: parse config → precheck → evaluate, with
        precheck + error handling centralized so every plugin behaves
        consistently. The orchestrator calls this."""
        try:
            cfg = self.parse_config(config)
        except Exception as e:
            return self.result(segment, state="error", rationale=f"invalid config: {e}")
        pre = self.precheck(segment, cfg, ctx=ctx)
        if not pre.ok:
            return self.result(
                segment, state="assumptions_unmet",
                rationale="; ".join(pre.unmet) or "assumptions not met",
                view_payload={"unmet": pre.unmet},
            )
        try:
            return await self.evaluate(segment, cfg, ctx=ctx)
        except Exception as e:  # never let one plugin crash the run
            return self.result(segment, state="error", rationale=f"plugin error: {e}")

    # ── helper ───────────────────────────────────────────────────────────
    def result(self, segment: Segment, **kw: Any) -> SegmentEvaluation:
        """Construct a SegmentEvaluation pre-filled with this plugin's id /
        method / view_id and the segment's ids."""
        kw.setdefault("method", self.method)
        kw.setdefault("view_id", self.view_id)
        return SegmentEvaluation(
            plugin_id=self.id,
            segment_id=segment.segment_id,
            phase_id=segment.phase_id,
            **kw,
        )
