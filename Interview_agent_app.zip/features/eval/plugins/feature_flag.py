"""Feature flag for the plugin-based evaluation pipeline (v2).

OFF by default during rollout — the current single-pass evaluator
(app/evaluation_service.py) stays the default until v2 reaches parity. Set
EVAL_PLUGINS_ENABLED=1 (or true/yes/on) to route post-session evaluation and
the evaluate/revise routes through the plugin pipeline.
"""
from __future__ import annotations

import os

_TRUTHY = {"1", "true", "yes", "on", "enabled"}


def is_enabled() -> bool:
    """Return True only when EVAL_PLUGINS_ENABLED explicitly enables v2."""
    return os.environ.get("EVAL_PLUGINS_ENABLED", "").strip().lower() in _TRUTHY
