"""features/eval/ — evaluation-rubric module (cadence-driven, per-section lenses).

Self-contained, mirrors the coding/ module pattern: pure logic + storage
helpers here, thin integration touchpoints in admin/. Nothing in the live
interview path imports this module.

Public API:
    is_enabled()              -> bool                      (feature flag)
    generate_rubric(...)      -> Rubric                    (LLM, falls back to heuristic)
    heuristic_rubric(...)     -> Rubric                    (deterministic, no LLM)
    validate_rubric_dict(...) -> tuple[Rubric|None, str|None]
    load_rubric(token)        -> dict | None
    save_rubric(token, ...)   -> dict                      (appends prior to history)
    CANONICAL_DIMS            -> dict[str, str]
"""
from features.eval.feature_flag import is_enabled
from features.eval.schema import (
    CANONICAL_DIMS,
    BehavioralAnchor,
    Rubric,
    SectionLens,
    rubric_fingerprint,
    validate_rubric_dict,
)
from features.eval.heuristic import heuristic_rubric
from features.eval.generator import generate_rubric
from features.eval.storage import load_rubric, rubric_path, save_rubric

__all__ = [
    "is_enabled",
    "CANONICAL_DIMS",
    "BehavioralAnchor",
    "Rubric",
    "SectionLens",
    "validate_rubric_dict",
    "rubric_fingerprint",
    "heuristic_rubric",
    "generate_rubric",
    "load_rubric",
    "save_rubric",
    "rubric_path",
]
