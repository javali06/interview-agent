"""Rubric persistence — sessions/<token>/rubric.json.

Same persistence home as cadence.yaml/events.jsonl so cloud deploys with
SESSIONS_DIR on a persistent volume keep rubrics across restarts.

The file is a small append-history envelope:
    {"current": {...rubric...}, "history": [{...prior rubrics...}]}
Edits never silently destroy what the TA (or the LLM) wrote before.
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("rubric")

_MAX_HISTORY = 20


def _sessions_dir() -> Path:
    repo_root = Path(__file__).resolve().parent.parent
    return Path(os.environ.get("SESSIONS_DIR", str(repo_root / "sessions")))


def rubric_path(token: str) -> Path:
    return _sessions_dir() / token / "rubric.json"


def load_rubric(token: str) -> Optional[dict[str, Any]]:
    """Return the CURRENT rubric dict, or None if absent/corrupt."""
    path = rubric_path(token)
    if not path.is_file():
        return None
    try:
        envelope = json.loads(path.read_text(encoding="utf-8"))
        cur = envelope.get("current")
        return cur if isinstance(cur, dict) else None
    except Exception as e:
        logger.warning("[rubric] failed to read %s: %s", path, e)
        return None


def save_rubric(token: str, rubric: dict[str, Any]) -> dict[str, Any]:
    """Persist `rubric` as current; prior current (if any) is appended to
    history. Returns the rubric as saved. Caller validates first."""
    path = rubric_path(token)
    path.parent.mkdir(parents=True, exist_ok=True)

    history: list[dict[str, Any]] = []
    if path.is_file():
        try:
            envelope = json.loads(path.read_text(encoding="utf-8"))
            history = [h for h in envelope.get("history", []) if isinstance(h, dict)]
            prev = envelope.get("current")
            if isinstance(prev, dict):
                history.append(prev)
        except Exception as e:
            logger.warning("[rubric] could not preserve history of %s: %s", path, e)

    envelope = {"current": rubric, "history": history[-_MAX_HISTORY:]}
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(envelope, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)
    return rubric
