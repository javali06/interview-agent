"""Feature flag for the rubric module.

ON by default — the module only touches admin pages (cadence review +
evaluation prompt guidance) and degrades to a deterministic heuristic when
no LLM key is configured, so there is no hard runtime dependency. Set
RUBRIC_ENABLED=0 (or false/no/off) to hide the rubric panel and skip all
rubric generation.
"""
from __future__ import annotations

import os


_FALSY = {"0", "false", "no", "off", "disabled"}


def is_enabled() -> bool:
    """Return True unless RUBRIC_ENABLED explicitly disables the feature."""
    raw = os.environ.get("RUBRIC_ENABLED", "").strip().lower()
    return raw not in _FALSY
