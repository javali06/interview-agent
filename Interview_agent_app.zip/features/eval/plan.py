"""Evaluation plan — which plugin(s) + config score each cadence phase.

The plan is the per-session contract the v2 evaluator consumes. It is created by
migrating an existing rubric (`plan_from_rubric`) or, when none exists, built
straight from the cadence (`plan_from_cadence`). A plan ALWAYS exists so every
session keeps scoring.

Validation resolves each `plugin_id` against the registry and validates its
`config` against that plugin's own schema — analogous to `validate_rubric_dict`.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field

# Importing the plugins package registers every built-in so the registry is
# populated for validation/migration.
import features.eval.plugins as _plugins  # noqa: F401
from features.eval.heuristic import _is_coding, heuristic_rubric
from features.eval.plugins.registry import get_plugin, has_plugin


class PluginAssignment(BaseModel):
    # Empty plugin_id == "no plugin chosen" == not scored. Allowed so a TA can
    # leave a phase ungraded without it failing validation/save.
    plugin_id: str = ""
    config: dict[str, Any] = Field(default_factory=dict)
    enabled: bool = True


class PhasePlan(BaseModel):
    phase_id: str = Field(..., min_length=1)
    # Multiple plugins per phase are supported; one is the common case.
    plugins: list[PluginAssignment] = Field(default_factory=list)


class EvaluationPlan(BaseModel):
    version: str = "1"
    source: Literal["migrated", "ta_edited", "default", "ai_generated"] = "default"
    generated_at: Optional[str] = None
    phases: list[PhasePlan] = Field(..., min_length=1)


def validate_plan_dict(data: dict) -> tuple[Optional[EvaluationPlan], Optional[str]]:
    """Parse + validate a plan dict, including each assignment's config against
    its plugin schema. Returns (plan, None) or (None, error)."""
    try:
        plan = EvaluationPlan.model_validate(data)
    except Exception as e:
        return None, str(e)
    for ph in plan.phases:
        for a in ph.plugins:
            if not a.enabled or not a.plugin_id:
                continue  # not-scored / no-plugin phases are not validated
            if not has_plugin(a.plugin_id):
                return None, f"phase {ph.phase_id!r}: unknown plugin {a.plugin_id!r}"
            try:
                get_plugin(a.plugin_id).parse_config(a.config)
            except Exception as e:
                return None, f"phase {ph.phase_id!r} / {a.plugin_id}: invalid config: {e}"
    return plan, None


def validate_plan_against_cadence(plan: dict, cadence: dict) -> list[dict]:
    """Deterministically check each ENABLED plugin's declared assumptions against
    the current cadence (e.g. dynamic_difficulty needs difficulty + coverage_tags
    on every question). Returns per-phase results so the UI can show hints in the
    matching plugin card. Disabled (not-scored) assignments are skipped."""
    phases_by_id = {p.get("id"): p for p in (cadence.get("phases") or []) if isinstance(p, dict)}
    out: list[dict] = []
    for ph in plan.get("phases", []) or []:
        pid = ph.get("phase_id")
        phase_dict = phases_by_id.get(pid) or {"id": pid}
        plugin_results: list[dict] = []
        for a in (ph.get("plugins") or []):
            if not a.get("enabled", True):
                continue
            plugin_id = a.get("plugin_id")
            if not plugin_id:
                continue
            if not has_plugin(plugin_id):
                plugin_results.append({"plugin_id": plugin_id, "ok": False, "unmet": [f"unknown plugin {plugin_id!r}"]})
                continue
            cls = get_plugin(plugin_id)
            # Every unmet message is prefixed with its phase/plugin here — the ONE
            # shared place — so a message copied out of context (e.g. pasted into
            # "Revise with AI") is still self-describing. Applied to every element,
            # including a rule's appended example line, not just the first.
            prefix = f"{pid} / {plugin_id}: "
            try:
                cfg = cls.parse_config(a.get("config") or {})
            except Exception as e:
                plugin_results.append({"plugin_id": plugin_id, "ok": False, "unmet": [f"{prefix}invalid config: {e}"]})
                continue
            res = cls().precheck_cadence(phase_dict, cfg)
            plugin_results.append({"plugin_id": plugin_id, "ok": res.ok, "unmet": [f"{prefix}{u}" for u in res.unmet]})
        out.append({"phase_id": pid, "plugins": plugin_results})
    return out


def plan_fingerprint(data: dict) -> str:
    """Stable hash of a plan's SEMANTIC content (phases + assignments),
    excluding version/source/generated_at. Stored on evaluation.json so the UI
    can flag 'plan changed since this evaluation'."""
    phases = []
    for ph in data.get("phases", []) or []:
        phases.append({
            "phase_id": ph.get("phase_id"),
            "plugins": [
                {"plugin_id": a.get("plugin_id"), "config": a.get("config"), "enabled": a.get("enabled", True)}
                for a in (ph.get("plugins") or [])
            ],
        })
    blob = json.dumps({"phases": phases}, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ── migration ───────────────────────────────────────────────────────────


def _conversational_config_from_lens(section: dict, seniority_bar: str) -> dict:
    weight = float(section.get("weight") or 0.0)
    return {
        "marks_possible": round(weight * 10.0, 1) if weight > 0 else 0.0,
        "purpose": section.get("purpose") or "",
        "seniority_bar": seniority_bar or "",
        "score_dimensions": list(section.get("score_dimensions") or []),
        "ignore_dimensions": list(section.get("ignore_dimensions") or []),
        "anchors": list(section.get("anchors") or []),
    }


def _assignment_for_phase(section: dict, phase: dict, seniority_bar: str) -> PluginAssignment:
    """Pick a sensible default plugin for one phase during migration.

    Coding phases → the coding plugin. Everything else → conversational_rubric
    (the faithful port of the existing lens). Weight-0 (quarantined) phases are
    carried as disabled so the UI still shows them but they don't score.
    """
    if _is_coding(phase):
        weight = float(section.get("weight") or 1.5)
        return PluginAssignment(plugin_id="coding", config={"marks_possible": round(weight * 10.0, 1) or 15.0})
    weight = float(section.get("weight") or 0.0)
    return PluginAssignment(
        plugin_id="conversational_rubric",
        config=_conversational_config_from_lens(section, seniority_bar),
        enabled=weight > 0,
    )


def plan_from_rubric(rubric: dict, cadence: dict) -> EvaluationPlan:
    """Migrate an existing rubric → an evaluation plan (one assignment/phase)."""
    seniority_bar = rubric.get("seniority_bar") or ""
    sections = {s.get("phase_id"): s for s in (rubric.get("sections") or []) if isinstance(s, dict)}
    phases_out: list[PhasePlan] = []
    for ph in cadence.get("phases") or []:
        if not isinstance(ph, dict):
            continue
        pid = ph.get("id")
        if not pid:
            continue
        section = sections.get(pid, {"phase_id": pid, "weight": 1.0})
        phases_out.append(PhasePlan(phase_id=pid, plugins=[_assignment_for_phase(section, ph, seniority_bar)]))
    if not phases_out:
        raise ValueError("cadence has no phases to plan")
    return EvaluationPlan(source="migrated", generated_at=_now(), phases=phases_out)


def plan_from_cadence(cadence: dict, *, role: str = "", seniority_bar: str = "") -> EvaluationPlan:
    """Default plan for a cadence: every phase UNASSIGNED (not scored). The
    operator explicitly picks a plugin per phase in the editor — "only score
    what I pick". A phase left unassigned is skipped at eval time (see
    plugin_evaluation._plan_index, which drops empty/disabled assignments).

    Previously this defaulted every non-coding phase to conversational_rubric
    (via the heuristic rubric), which silently scored phases nobody configured.
    """
    phases_out: list[PhasePlan] = []
    for ph in cadence.get("phases") or []:
        if not isinstance(ph, dict):
            continue
        pid = ph.get("id")
        if not pid:
            continue
        phases_out.append(PhasePlan(
            phase_id=pid,
            plugins=[PluginAssignment(plugin_id="", config={}, enabled=False)],
        ))
    if not phases_out:
        raise ValueError("cadence has no phases to plan")
    return EvaluationPlan(source="default", generated_at=_now(), phases=phases_out)


def extend_plan_with_new_phases(plan: dict, cadence: dict, *, role: str = "", seniority_bar: str = "") -> dict:
    """Append UNASSIGNED (not-scored) entries for any cadence phase missing from
    the plan (e.g. after a coding round is added). Existing phases are left
    untouched; the operator picks a plugin for the new phase ("only score what
    I pick")."""
    existing = {p.get("phase_id") for p in plan.get("phases", []) if isinstance(p, dict)}
    appended = []
    for ph in cadence.get("phases") or []:
        if not isinstance(ph, dict):
            continue
        pid = ph.get("id")
        if not pid or pid in existing:
            continue
        appended.append(PhasePlan(
            phase_id=pid,
            plugins=[PluginAssignment(plugin_id="", config={}, enabled=False)],
        ).model_dump())
    if appended:
        plan.setdefault("phases", []).extend(appended)
        plan["generated_at"] = _now()
    return plan
