"""Deterministic sectioner: events.jsonl → phase → segment tree.

The single source of segment structure for post-interview evaluation. It
splits the raw event stream into:

    interview → phases[] → segments[]

where a *segment* is the unit of evaluation AND the unit of evidence:

  - "specific" phase  → one segment per pool question (from the question's
                        `question_dispatched` marker until the next question
                        or phase change). Spans every follow-up turn.
  - "generic"  phase  → one segment for the whole phase.
  - "coding"   phase  → one segment per coding question.
  - "warmup"          → pre-first-question chatter inside a specific phase
                        (dropped if empty).

Each segment carries the COMPLETE multi-party transcript for that span —
candidate (STT), AI, observer/TA, and verifier turns — with each turn's
`event_index` (its 0-based position in the parsed event stream) so the UI can
deep-link a score back to the exact Interview-Trace row. `event_index` is
consistent with `app.event_viewer.annotate()`, which numbers rows the same way.

This module deliberately does NOT import the cadence package (which pulls in
heavy runtime deps). The optional `cadence` argument is duck-typed: it may be a
`CadencePlan`-like object (``.phases`` each with ``.id`` / ``.question_mode`` /
``.coding_question_ids``) or a plain dict, or ``None`` — segmentation works
either way (phase mode is also inferred from the events themselves).
"""
from __future__ import annotations

from typing import Any, Iterator, Literal, Optional

from pydantic import BaseModel, Field

SpeakerRole = Literal["candidate", "ai", "interviewer_ta", "verifier", "system"]
SegmentKind = Literal["question", "generic", "coding", "warmup"]


class Turn(BaseModel):
    """One content-bearing contribution by one party, in chronological order."""

    event_index: int
    ts: str = ""
    speaker: SpeakerRole
    kind: str
    text: str
    meta: dict[str, Any] = Field(default_factory=dict)


class Segment(BaseModel):
    """The unit graded by a plugin and shown as evidence."""

    segment_id: str
    kind: SegmentKind
    phase_id: str
    question_id: Optional[str] = None
    question_text: Optional[str] = None
    topic: Optional[str] = None
    difficulty: Optional[str] = None
    coverage_tags: list[str] = Field(default_factory=list)
    start_event_index: int
    end_event_index: int
    turns: list[Turn] = Field(default_factory=list)

    # ── ergonomic accessors used by plugins ──────────────────────────────
    def candidate_turns(self) -> list[Turn]:
        return [t for t in self.turns if t.speaker == "candidate"]

    def verifier_turns(self) -> list[Turn]:
        return [t for t in self.turns if t.speaker == "verifier"]

    def has_candidate_input(self) -> bool:
        return any(t.speaker == "candidate" and t.text.strip() for t in self.turns)

    def event_indices(self) -> list[int]:
        return [t.event_index for t in self.turns]

    def structured_qa(self) -> dict[str, Any]:
        """Split the segment into a labeled Q&A for a judge prompt:
        ``{question, initial_answer, follow_ups: [{probe, answer}], verifier_missing}``.

        The first AI turn is the question; candidate turns before the first
        follow-up probe form the initial answer; each later AI turn is a probe
        with the candidate turns that follow it; verifier missing-tag notes are
        aggregated. This gives plugins a clean, structured input (question vs
        initial answer vs follow-ups vs verifier verdict) instead of a flat
        transcript blob — the key to reliable rubric judging."""
        question = self.question_text or ""
        initial: list[str] = []
        follow_ups: list[dict[str, str]] = []
        seen_ask = False
        cur: Optional[dict[str, str]] = None
        for t in self.turns:
            if t.speaker == "ai":
                if not seen_ask:
                    seen_ask = True
                    if not question:
                        question = t.text
                    continue
                cur = {"probe": t.text, "answer": ""}
                follow_ups.append(cur)
            elif t.speaker == "candidate":
                if cur is None:
                    initial.append(t.text)
                else:
                    cur["answer"] = (cur["answer"] + " " + t.text).strip()
        verifier_missing: list[str] = []
        for t in self.verifier_turns():
            for tag in (t.meta.get("missing_tags") or []):
                if tag and tag not in verifier_missing:
                    verifier_missing.append(tag)
        return {
            "question": question,
            "initial_answer": " ".join(initial).strip(),
            "follow_ups": follow_ups,
            "verifier_missing": verifier_missing,
        }

    def transcript_text(self) -> str:
        """Human-readable multi-party transcript for this segment."""
        label = {
            "candidate": "Candidate",
            "ai": "AI",
            "interviewer_ta": "Interviewer (TA)",
            "verifier": "Verifier",
            "system": "System",
        }
        return "\n".join(f"{label.get(t.speaker, t.speaker)}: {t.text}" for t in self.turns)


class Phase(BaseModel):
    phase_id: str
    question_mode: str = "unknown"  # generic | specific | coding | scenario_analysis |
                                     # a written type (comprehensive/transcription/…) | unknown
    start_event_index: int
    end_event_index: int
    segments: list[Segment] = Field(default_factory=list)


class InterviewSegments(BaseModel):
    token: Optional[str] = None
    phases: list[Phase] = Field(default_factory=list)

    def iter_segments(self) -> Iterator[tuple[Phase, Segment]]:
        for ph in self.phases:
            for seg in ph.segments:
                yield ph, seg


# ── cadence duck-typing helpers (no cadence-package import) ──────────────


def _cadence_phase_modes(cadence: Any) -> dict[str, str]:
    """Map phase_id -> mode (generic|specific|coding|scenario_analysis|a written
    type) from a CadencePlan-like object or dict. Coding phases
    (coding_question_ids) and Visual Scenario Analysis phases (scenario_items)
    both win over the raw question_mode — neither changes question_mode away
    from "generic", so without this override every such phase would report as
    indistinguishable from an ordinary generic phase. Returns {} when no
    cadence is supplied."""
    if cadence is None:
        return {}
    phases = cadence.get("phases") if isinstance(cadence, dict) else getattr(cadence, "phases", None)
    out: dict[str, str] = {}
    for p in phases or []:
        pid = p.get("id") if isinstance(p, dict) else getattr(p, "id", None)
        if not pid:
            continue
        coding = p.get("coding_question_ids") if isinstance(p, dict) else getattr(p, "coding_question_ids", None)
        if coding:
            out[pid] = "coding"
            continue
        scenario = p.get("scenario_items") if isinstance(p, dict) else getattr(p, "scenario_items", None)
        if scenario:
            out[pid] = "scenario_analysis"
            continue
        mode = p.get("question_mode") if isinstance(p, dict) else getattr(p, "question_mode", None)
        out[pid] = mode or "generic"
    return out


def _first_cadence_phase(cadence: Any) -> Optional[str]:
    if cadence is None:
        return None
    phases = cadence.get("phases") if isinstance(cadence, dict) else getattr(cadence, "phases", None)
    if not phases:
        return None
    p0 = phases[0]
    return p0.get("id") if isinstance(p0, dict) else getattr(p0, "id", None)


def _seg_id(phase_id: str, kind: str, qid: Optional[str], ordinal: int) -> str:
    if kind == "question":
        return f"{phase_id}::q::{qid or ordinal}"
    if kind == "coding":
        return f"{phase_id}::coding::{qid or ordinal}"
    return f"{phase_id}::{kind}::{ordinal}"


# ── multi-party turn extraction ─────────────────────────────────────────


def _to_turn(idx: int, e: dict) -> Optional[Turn]:
    """Map a content-bearing event to a normalized Turn, else None.

    Non-content events (fillers, tts/vad lifecycle, llm_call_*, barge-ins,
    director ticks, …) return None — they are plumbing, not evidence.
    """
    kind = e.get("kind", "")
    p = e.get("payload") or {}
    ts = e.get("ts", "")

    def mk(speaker: SpeakerRole, text: str, meta: Optional[dict] = None) -> Turn:
        return Turn(event_index=idx, ts=ts, speaker=speaker, kind=kind, text=text, meta=meta or {})

    if kind == "ai_utterance":
        t = (p.get("text") or "").strip()
        return mk("ai", t) if t else None

    if kind == "interviewer_turn":
        t = (p.get("text") or p.get("transcript") or "").strip()
        return mk("interviewer_ta", t) if t else None

    if kind == "stt_final":
        t = (p.get("text") or p.get("transcript") or "").strip()
        if not t:
            return None
        if p.get("speaker") == "interviewer":  # legacy observer PTT
            return mk("interviewer_ta", t, {"confidence": p.get("confidence")})
        return mk("candidate", t, {"confidence": p.get("confidence"), "audio_ms": p.get("audio_ms")})

    if kind == "verifier_classified":
        intent = p.get("intent") or "?"
        instr = (p.get("instruction") or "").strip()
        text = f"[verifier: {intent}]" + (f" {instr}" if instr else "")
        return mk("verifier", text, {
            "intent": intent,
            "confidence": p.get("confidence"),
            "missing_tags": p.get("missing_tags"),
            "reason": p.get("reason"),
            "model": p.get("model"),
        })

    if kind == "phase_override_decided":
        ov = p.get("override")
        reason = (p.get("reason") or "").strip()
        return mk("system", f"[phase_override: {ov}]" + (f" {reason}" if reason else ""), {
            "override": ov, "raw_override": p.get("raw_override"), "confidence": p.get("confidence"),
        })

    if kind == "guardrail_triggered":
        reason = p.get("reason") or "?"
        ctext = (p.get("candidate_text") or "").strip()
        return mk("system", f"[guardrail: {reason}]" + (f" {ctext}" if ctext else ""), {"reason": reason})

    if kind == "coding_code_submitted":
        results = p.get("final_test_results") or []
        if isinstance(results, list):
            passed = sum(1 for r in results if isinstance(r, dict) and (r.get("pass") or r.get("passed")))
            total = len(results)
        else:
            passed, total = 0, 0
        runs = p.get("runs_used") or 0
        code = (p.get("final_code") or "").rstrip()
        text = f"[submitted code — {passed}/{total} tests passed, {runs} run(s)]"
        if code:
            cap = 4000
            body = code[:cap] + (f"\n... (truncated, {len(code) - cap} more chars)" if len(code) > cap else "")
            text += "\n```\n" + body + "\n```"
        return mk("candidate", text, {
            "question_id": p.get("question_id"),
            "passed": passed, "total": total,
            "runs_used": runs, "auto_submitted": p.get("auto_submitted"),
            "final_test_results": results, "final_code": p.get("final_code"),
        })

    if kind == "coding_hint_delivered":
        lvl = p.get("hint_level")
        txt = (p.get("hint_text") or "").strip()
        return mk("ai", f"[hint {lvl}] {txt}", {"hint_level": lvl, "question_id": p.get("question_id")}) if txt else None

    if kind == "coding_anti_cheat":
        reason = p.get("reason") or "?"
        return mk("system", f"[anti-cheat] {reason}", {"reason": reason, "metadata": p.get("metadata")})

    # coding_phase_started is handled as a boundary in build_segments (and a
    # system turn is added there); everything else is non-content.
    return None


_QUESTION_BOUNDARY_KINDS = ("question_dispatched", "adaptive_question_asked")
_CODING_ROUTED_KINDS = ("coding_code_submitted", "coding_hint_delivered", "coding_anti_cheat")


def build_segments(events: list[dict], *, cadence: Any = None, token: Optional[str] = None) -> InterviewSegments:
    """Split a parsed event stream into the phase → segment tree.

    `events` is the list produced by reading events.jsonl (same parsing as
    `app.evaluation_service._read_events` / `app.event_viewer.annotate`), so a
    Turn's `event_index` equals the trace row's `index`.
    """
    modes = _cadence_phase_modes(cadence)
    phases: list[Phase] = []
    cur_phase: Optional[Phase] = None
    cur_seg: Optional[Segment] = None
    coding_segs: dict[str, Segment] = {}
    last_qkey: Optional[tuple] = None
    n = len(events)

    def seed_kind_for(pid: str) -> SegmentKind:
        return "warmup" if modes.get(pid) == "specific" else "generic"

    def open_phase(pid: str, i: int) -> Phase:
        nonlocal coding_segs, last_qkey
        ph = Phase(phase_id=pid, question_mode=modes.get(pid, "unknown"),
                   start_event_index=i, end_event_index=i)
        phases.append(ph)
        coding_segs = {}
        last_qkey = None
        return ph

    def open_segment(ph: Phase, kind: SegmentKind, i: int, **kw) -> Segment:
        seg = Segment(
            segment_id=_seg_id(ph.phase_id, kind, kw.get("question_id"), len(ph.segments)),
            kind=kind, phase_id=ph.phase_id, start_event_index=i, end_event_index=i, **kw,
        )
        ph.segments.append(seg)
        return seg

    def close_seg(seg: Optional[Segment], end_i: int) -> None:
        if seg is not None and end_i >= seg.start_event_index:
            seg.end_event_index = end_i

    def close_or_drop_seed(ph: Phase, seg: Optional[Segment], i: int) -> None:
        """Close the current segment at i-1; if it was an empty seed, drop it.
        A non-empty seed in a specific/coding phase is reclassified to warmup
        (pre-question chatter)."""
        if seg is None:
            return
        if not seg.turns and seg in ph.segments:
            ph.segments.remove(seg)
            return
        if seg.kind == "generic":
            seg.kind = "warmup"  # pre-question chatter, not the whole phase
        close_seg(seg, i - 1)

    for i, e in enumerate(events):
        kind = e.get("kind", "")
        p = e.get("payload") or {}

        if kind == "session_started":
            init = p.get("initial_phase") or p.get("phase") or _first_cadence_phase(cadence) or "intro"
            cur_phase = open_phase(init, i)
            cur_seg = open_segment(cur_phase, seed_kind_for(init), i)
            continue

        if cur_phase is None:  # events before session_started
            pid = _first_cadence_phase(cadence) or "intro"
            cur_phase = open_phase(pid, i)
            cur_seg = open_segment(cur_phase, seed_kind_for(pid), i)

        if kind == "phase_changed":
            # Ignore the QUEUED pre-announcement. The director emits phase_changed
            # TWICE per transition: a queued one (queued=True) the instant the
            # phase clock expires — fired ungated, even mid-utterance — then the
            # real APPLIED one (reason="natural", no queued flag) once the
            # candidate stops speaking (director.py:746 vs 2264/2277/1841/1864).
            # A candidate's answer to the OLD phase finalizes BETWEEN the two, so
            # segmenting on the queued marker misfiles that answer into the NEW
            # phase's warmup seed (then dropped at seal). Segment on the applied
            # marker only, so the straddling answer stays in its question segment.
            if p.get("queued") is True:
                continue
            to_p = p.get("to_phase") or p.get("to") or p.get("new_phase")
            if not to_p or to_p == cur_phase.phase_id:
                continue  # missing/duplicate marker
            close_seg(cur_seg, i - 1)
            cur_phase.end_event_index = i - 1
            cur_phase = open_phase(to_p, i)
            cur_seg = open_segment(cur_phase, seed_kind_for(to_p), i)
            continue

        if kind in _QUESTION_BOUNDARY_KINDS:
            qid = p.get("question_id")
            qkey = (cur_phase.phase_id, qid)
            if qkey == last_qkey:
                continue  # dual-emit (question_dispatched + adaptive) or barge-in re-ask
            last_qkey = qkey
            cur_phase.question_mode = "specific"
            close_or_drop_seed(cur_phase, cur_seg, i)
            cur_seg = open_segment(
                cur_phase, "question", i,
                question_id=qid,
                question_text=p.get("question_text"),
                topic=p.get("topic"),
                difficulty=p.get("difficulty"),
                coverage_tags=list(p.get("coverage_tags") or []),
            )
            continue

        if kind == "coding_phase_started":
            cur_phase.question_mode = "coding"
            close_or_drop_seed(cur_phase, cur_seg, i)
            qs = p.get("questions")
            if not isinstance(qs, list) or not qs:
                qs = [{"question_id": p.get("question_id"),
                       "question_prompt": p.get("question_prompt") or p.get("prompt")}]
            coding_segs = {}
            first: Optional[Segment] = None
            for q in qs:
                qid = q.get("question_id")
                seg = open_segment(cur_phase, "coding", i, question_id=qid,
                                   question_text=q.get("question_prompt") or q.get("prompt"))
                prompt = (q.get("question_prompt") or q.get("prompt") or "").strip()
                if prompt:
                    seg.turns.append(Turn(event_index=i, ts=e.get("ts", ""), speaker="system",
                                          kind=kind, text=f"[coding question {qid}] {prompt}",
                                          meta={"question_id": qid}))
                if qid is not None:
                    coding_segs[qid] = seg
                if first is None:
                    first = seg
            cur_seg = first
            continue

        if kind == "session_ended":
            cur_phase.end_event_index = i  # stamp; do NOT break (two-session_ended quirk)
            continue

        # ── content turn ────────────────────────────────────────────────
        turn = _to_turn(i, e)
        if turn is None:
            continue
        target = cur_seg
        if kind in _CODING_ROUTED_KINDS:
            qid = p.get("question_id")
            if qid is not None and qid in coding_segs:
                target = coding_segs[qid]
            elif coding_segs:
                target = next(iter(coding_segs.values()))
        if target is None:  # no open segment (defensive) — start a generic one
            target = open_segment(cur_phase, "generic", i)
            cur_seg = target
        target.turns.append(turn)
        close_seg(target, i)

    # ── final seal ──────────────────────────────────────────────────────
    last_i = n - 1 if n else 0
    close_seg(cur_seg, last_i)
    if cur_phase is not None and cur_phase.end_event_index < last_i:
        cur_phase.end_event_index = last_i
    # Drop only empty warm-up seeds; keep empty question/coding/generic
    # segments so downstream scoring can mark them "not_observed" (≠ 0).
    for ph in phases:
        ph.segments = [s for s in ph.segments if s.turns or s.kind != "warmup"]
    return InterviewSegments(token=token, phases=phases)
