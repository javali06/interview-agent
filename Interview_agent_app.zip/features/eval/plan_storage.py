"""Evaluation-plan persistence — sessions/<token>/evaluation_plan.json.

The plan maps each cadence phase to the plugin(s) + config that score it. Same
append-history envelope as rubric storage (storage.py) — TA edits never silently
destroy prior plans. Lives alongside rubric.json (a new file, not a replacement)
so an existing rubric stays a valid v1 artifact.
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger("eval_plan")

_MAX_HISTORY = 20


def _sessions_dir() -> Path:
    """The session artefact directory — the SAME one the rest of the app uses.

    This used to recompute the repo root as `Path(__file__).parent.parent`,
    which from `features/eval/plan_storage.py` is `<repo>/features`, not the
    repo root. Plans were therefore written to `<repo>/features/sessions/...`
    while every other artefact lives in `<repo>/sessions/...`.

    In a container that directory is INSIDE the image and `/app/sessions` is
    the mounted volume, so each image rebuild silently destroyed every saved
    evaluation plan. The next evaluation then derived the "nothing is scored"
    default (plan.plan_from_cadence), persisted it, and every run after that
    scored 0/0 — with no error anywhere, because an unassigned phase is a
    legitimate state.

    Deferring to `app.paths` instead of recomputing means there is one
    definition of where session data lives, and SESSIONS_DIR keeps working.
    """
    try:
        from app.paths import SESSIONS_DIR
        return SESSIONS_DIR
    except Exception:      # features/ must stay importable without app/
        repo_root = Path(__file__).resolve().parent.parent.parent
        return Path(os.environ.get("SESSIONS_DIR", str(repo_root / "sessions")))


def plan_path(token: str) -> Path:
    return _sessions_dir() / token / "evaluation_plan.json"


def load_plan(token: str) -> Optional[dict[str, Any]]:
    """Return the CURRENT evaluation plan dict, or None if absent/corrupt."""
    path = plan_path(token)
    if not path.is_file():
        # Cold session dir (a different replica, or a restarted container).
        # Blob is the durable copy — WITHOUT this fallback the caller derives
        # the "nothing is scored" default, persists it, and the good plan is
        # overwritten in blob too. That is silent: an unassigned phase is a
        # legitimate state, so nothing errors and the interview simply scores 0.
        return _load_from_blob(token)
    try:
        envelope = json.loads(path.read_text(encoding="utf-8"))
        cur = envelope.get("current")
        return cur if isinstance(cur, dict) else None
    except Exception as e:
        logger.warning("[eval_plan] failed to read %s: %s", path, e)
        return None


def _load_from_blob(token: str) -> Optional[dict[str, Any]]:
    """The plan as mirrored to blob, or None. Best-effort: blob being absent or
    unreachable must never be worse than having no plan at all."""
    try:
        from app import blob_store
        raw = blob_store.download_bytes(f"{token}/evaluation_plan.json")
        if not raw:
            return None
        envelope = json.loads(raw)
        cur = envelope.get("current")
        if isinstance(cur, dict):
            logger.info("[eval_plan] %s: local copy missing, restored from blob", token)
            return cur
    except Exception as e:
        logger.debug("[eval_plan] blob fallback unavailable for %s: %s", token, e)
    return None


def save_plan(token: str, plan: dict[str, Any]) -> dict[str, Any]:
    """Persist `plan` as current; prior current (if any) goes to history.
    Caller validates first."""
    path = plan_path(token)
    path.parent.mkdir(parents=True, exist_ok=True)

    history: list[dict[str, Any]] = []
    if path.is_file():
        try:
            envelope = json.loads(path.read_text(encoding="utf-8"))
            history = [h for h in envelope.get("history", []) if isinstance(h, dict)]
            prev = envelope.get("current")
            if isinstance(prev, dict):
                history.append(prev)
        except Exception as e:
            logger.warning("[eval_plan] could not preserve history of %s: %s", path, e)

    envelope = {"current": plan, "history": history[-_MAX_HISTORY:]}
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(envelope, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)
    return plan
