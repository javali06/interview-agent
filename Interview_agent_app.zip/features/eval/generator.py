"""LLM rubric derivation from a cadence + role/JD.

One non-streaming JSON call on the slow LLM (same resolution order as
coding/evaluator.py / admin/cadence_service.py: SLOW_PROVIDER/SLOW_MODEL,
then legacy Groq/OpenRouter fallbacks). Output is pydantic-validated; one
retry with the validation error quoted; final fallback is the
deterministic heuristic so callers always get a rubric.
"""
from __future__ import annotations

import json
import logging
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import yaml

from features.eval.heuristic import build_anchors, heuristic_rubric
from features.eval.schema import CANONICAL_DIMS, Rubric

logger = logging.getLogger("rubric")

_REPO_ROOT = Path(__file__).resolve().parent.parent


def _resolve_llm() -> Optional[tuple[str, str, str]]:
    """Returns (api_key, base_url, model) or None if no key configured.
    Mirrors admin/cadence_service._resolve_llm priority order, with one
    addition: RUBRIC_PROVIDER/RUBRIC_MODEL override SLOW_* so ops can point
    rubric derivation at a faster model (it's a tiny structured-extraction
    task — a small instruct model is fine) without touching the live
    interviewer's model."""
    slow_provider = (
        os.environ.get("RUBRIC_PROVIDER") or os.environ.get("SLOW_PROVIDER") or ""
    ).strip().lower()
    slow_model = (
        os.environ.get("RUBRIC_MODEL") or os.environ.get("SLOW_MODEL") or ""
    ).strip()

    if slow_provider == "openrouter" and slow_model:
        key = (os.environ.get("OPENROUTER_API_KEY") or "").strip()
        if key:
            return key, "https://openrouter.ai/api/v1", slow_model.split(":", 1)[0]
    if slow_provider == "groq" and slow_model:
        key = (os.environ.get("GROQ_API_KEY") or "").strip()
        if key:
            return key, "https://api.groq.com/openai/v1", slow_model

    def _from_env_file(var: str) -> str:
        val = (os.environ.get(var) or "").strip()
        if val:
            return val
        env_file = _REPO_ROOT / ".env"
        if env_file.is_file():
            for line in env_file.read_text(encoding="utf-8").splitlines():
                if line.strip().startswith(f"{var}="):
                    return line.strip().split("=", 1)[1].strip()
        return ""

    groq = _from_env_file("GROQ_API_KEY")
    if groq:
        return groq, "https://api.groq.com/openai/v1", "openai/gpt-oss-120b"
    openrouter = _from_env_file("OPENROUTER_API_KEY")
    if openrouter:
        return openrouter, "https://openrouter.ai/api/v1", "deepseek/deepseek-v3.2"
    return None


_SYSTEM_PROMPT = f"""You design evaluation rubrics for AI-conducted job interviews.
Given an interview cadence (ordered phases) plus the role and JD, emit ONE compact JSON
object: a per-phase evaluation lens saying what each phase is FOR, which dimensions to
score, which to deliberately ignore, and its weight. Be terse — no prose beyond the
fields requested.

DIMENSIONS — use ONLY these (subset per phase, 1-3 each):
{json.dumps(CANONICAL_DIMS, indent=2)}

FORBIDDEN PROXY SIGNALS — never let a purpose or focus reference these (they confound
style/culture with competence): pronoun choice ("I vs we"), energy/enthusiasm/passion,
counting clarifying questions, think-aloud volume, hedging/confidence wording, company
research, employer brand names or titles, accent/fluency/grammar, typing speed or time
used.

RULES:
- One lens per cadence phase, same order, phase_id copied exactly.
- Rapport/logistics phases (warm-up style openers, wrap-up closers) get weight 0,
  empty score_dimensions, focus_noun "" — they are quarantined from scoring.
- Never quarantine the only phase or the longest phase.
- Every weight>0 lens needs: 1-3 score_dimensions, at least one ignore_dimensions
  entry ("dim_or_signal: reason"), and a focus_noun — a 2-6 word noun phrase naming
  what the phase examines (e.g. "the coding exercise", "their RAG project work",
  "the system-design tradeoffs"). Behavioral anchor text is templated around it
  downstream, so make it specific to THIS phase's topics.
- Weights: 0 quarantined, 0.5 context, 1.0 standard, 1.5 important, 2.0 core to the JD.
- Coding phases (coding_question_ids present): score code_quality +
  problem_solving_process; note that speech is incidental there.

OUTPUT (strict JSON, no markdown fences):
{{"seniority_bar": "<one line: the bar this rubric calibrates to>",
  "sections": [{{"phase_id": "...", "purpose": "<one sentence>",
                 "score_dimensions": ["..."], "ignore_dimensions": ["signal: reason"],
                 "weight": 1.0, "focus_noun": "<2-6 words>"}}]}}
"""


def _strip_fences(text: str) -> str:
    text = text.strip()
    m = re.match(r"^```(?:json)?\s*(.*?)\s*```$", text, re.S)
    return m.group(1) if m else text


async def generate_rubric(
    *,
    cadence_yaml: str,
    role: str = "",
    jd_text: str = "",
    timeout_s: float = 90.0,
    token: Optional[str] = None,
) -> Rubric:
    """Derive a rubric from a cadence via the slow LLM.

    Always returns a valid Rubric: LLM (1 retry on validation failure)
    -> heuristic fallback. Raises only if the cadence itself is unusable.

    `token` (the schedule token) is optional — passed through so this call's
    cost/Langfuse trace is attributed to the right interview's "cost for
    setting up interview" table.
    """
    cadence: dict[str, Any] = yaml.safe_load(cadence_yaml) or {}
    if not cadence.get("phases"):
        raise ValueError("cadence YAML has no phases")

    resolved = _resolve_llm()
    if resolved is None:
        logger.info("[rubric] no LLM key — using heuristic rubric")
        return heuristic_rubric(cadence, role=role)

    api_key, base_url, model = resolved
    user_prompt = (
        f"ROLE: {role.strip() or '(unspecified)'}\n\n"
        f"JOB DESCRIPTION (may be empty):\n{(jd_text or '')[:3000]}\n\n"
        f"CADENCE YAML:\n```yaml\n{cadence_yaml}\n```"
    )

    try:
        from openai import AsyncOpenAI

        client = AsyncOpenAI(api_key=api_key, base_url=base_url, timeout=timeout_s)
        messages = [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ]
        # OpenRouter tuning for this one-shot batch call:
        # - reasoning effort low: gpt-oss-style models burn most latency on
        #   hidden chain-of-thought; this is structured extraction. Ignored
        #   by non-reasoning models.
        # - provider sort throughput: route to the fastest serving provider
        #   (Groq/Cerebras-class) instead of whoever is cheapest — default
        #   routing has landed on slow providers for gpt-oss-120b.
        extra_body = (
            {"reasoning": {"effort": "low"}, "provider": {"sort": "throughput"}}
            if "openrouter" in base_url else {}
        )
        last_err = ""
        for attempt in (1, 2):
            from app.setup_cost_tracker import trace_call

            with trace_call(
                token=token, purpose="generate_rubric", model=model, input_data=messages,
            ) as finish:
                resp = await client.chat.completions.create(
                    model=model,
                    messages=messages,
                    temperature=0.0,
                    # Content is tiny (~250 tokens) but on OpenRouter reasoning
                    # tokens count INSIDE max_tokens — leave headroom or the
                    # content gets clipped mid-field.
                    max_tokens=3000,
                    response_format={"type": "json_object"},
                    extra_body=extra_body,
                )
                finish(resp)
            raw = _strip_fences(resp.choices[0].message.content or "")
            if not raw:
                last_err = "empty response from model"
                logger.warning("[rubric] attempt %d: empty response", attempt)
                continue
            try:
                data = json.loads(raw)
                data.setdefault("version", "1")
                data["source"] = "derived"
                data["generated_at"] = datetime.now(timezone.utc).isoformat(timespec="seconds")
                # Expand each section's focus_noun into the 5 templated
                # anchors (the LLM no longer writes anchor prose — see
                # _SYSTEM_PROMPT). Quarantined sections stay anchor-free.
                for sec in data.get("sections", []):
                    if not isinstance(sec, dict):
                        continue
                    focus = str(sec.pop("focus_noun", "") or "").strip()
                    if float(sec.get("weight") or 0) > 0 and not sec.get("anchors"):
                        sec["anchors"] = [
                            a.model_dump() for a in build_anchors(focus or "this phase's topics")
                        ]
                rubric = Rubric.model_validate(data)
                # Phase-id parity check: every cadence phase needs a lens.
                cadence_ids = [str((p or {}).get("id") or "") for p in cadence["phases"]]
                rubric_ids = [s.phase_id for s in rubric.sections]
                if rubric_ids != cadence_ids:
                    raise ValueError(
                        f"sections must match cadence phases in order; cadence={cadence_ids}, rubric={rubric_ids}"
                    )
                return rubric
            except Exception as e:
                last_err = str(e)
                logger.warning("[rubric] attempt %d invalid: %s", attempt, last_err[:500])
                messages.append({"role": "assistant", "content": raw[:6000]})
                messages.append({
                    "role": "user",
                    "content": f"Your JSON failed validation: {last_err[:1500]}\nEmit the corrected full JSON object only.",
                })
        logger.error("[rubric] LLM failed twice (%s) — falling back to heuristic", last_err[:300])
    except Exception as e:
        logger.exception("[rubric] LLM call failed: %s", e)

    return heuristic_rubric(cadence, role=role)
