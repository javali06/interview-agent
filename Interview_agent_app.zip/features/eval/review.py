"""Human review of an LLM evaluation — the ledger, and the merge into the export.

The model produces a score. A reviewer must be able to say "that's wrong, here
is the right mark, and here is why", and that correction has to be durable,
auditable, and later learnable from.

THE ONE RULE: the AI's number is never overwritten. `marks_earned` on an
exported section keeps meaning *what the model said*, forever; the adjustment is
recorded beside it and `review.final_marks_earned` is what counts. Audit (a
raised score and an AI score are different claims), measurement (each adjustment
is a labelled example of where the model is wrong) and regeneration (which
rewrites every AI value) all break the moment the two share a field.

Two stores, joined at read time:

  - `sessions/<token>/evaluation_export.json` — immutable per evaluation run.
  - the `evaluation_reviews` table — append-only, and queryable ACROSS sessions,
    which is what "how far off is `role_fit` over 200 interviews?" needs and a
    per-session file cannot answer without scanning.

`apply_reviews()` joins them, and BOTH the scorecard endpoint and the download
call it — so the screen and the file stay the same document, as their test
requires.

One submission = one coherent statement about a section: the items moved, an
optional direct total, one reason. It supersedes that section's previous active
records rather than layering on top, so "what does this section say now" has
exactly one answer and the history is still on disk.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, Iterable, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

from features.eval.plugins.export import ReasonKind, ReviewedItem, SectionReview

REVIEW_VERSION = "1.0"

RecordKind = Literal["mark", "state", "note"]


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class ReviewTarget(BaseModel):
    """WHAT was adjusted: one section, optionally one line within it.

    `item_label = None` means the section's total. A line-level target is the
    one worth encouraging — "role_fit was 4, it should be 9" is specific enough
    to learn from; "this phase felt low" is not."""

    model_config = ConfigDict(extra="forbid")

    segment_id: str
    section: str
    item_label: Optional[str] = None


class ReviewSubmission(BaseModel):
    """One reviewer's verdict on one section, as the UI posts it."""

    model_config = ConfigDict(extra="forbid")

    segment_id: str
    section: str
    # label -> the reviewer's value for that breakdown line.
    items: dict[str, float] = Field(default_factory=dict)
    # A direct override of the section's total. When present it WINS over the
    # recompute from `items` — it is the more explicit statement, and keeping
    # one rule means the displayed number is never the result of two edits
    # racing.
    marks_earned: Optional[float] = None
    # "I can judge this after all", or the reverse. A state change is its own
    # act, not a side effect of typing a number.
    state: Optional[str] = None
    reason_kind: ReasonKind
    reason: str
    note: str = ""

    @model_validator(mode="after")
    def _must_say_something_and_why(self) -> "ReviewSubmission":
        if not (self.items or self.marks_earned is not None or self.state or self.note):
            raise ValueError("a review must change a mark, a state, or leave a note")
        if not self.reason.strip():
            # Without a reason an adjustment is unusable for the learning loop
            # and indefensible in an audit. It is required, not encouraged.
            raise ValueError("a reason is required")
        return self


class ReviewRecord(BaseModel):
    """One append-only row. Changing your mind writes a new row that supersedes
    this one; there is no UPDATE."""

    model_config = ConfigDict(extra="forbid")

    record_id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    token: str
    target: ReviewTarget
    kind: RecordKind

    # kind="mark": the number that moved. `ai_value` is FROZEN at review time —
    # it is what makes staleness detectable after a regenerate.
    ai_value: Optional[float] = None
    human_value: Optional[float] = None

    # kind="state"
    ai_state: Optional[str] = None
    human_state: Optional[str] = None

    # kind="note"
    body: str = ""

    reason_kind: ReasonKind
    reason: str

    reviewer: str = ""
    created_at: str = Field(default_factory=_now)

    # Provenance: which AI output was being corrected.
    evaluation_generated_at: str = ""
    ai_rationale: str = ""

    status: Literal["active", "superseded"] = "active"
    supersedes: Optional[str] = None


# ── building records from a submission ──────────────────────────────────────
def records_from_submission(
    token: str,
    sub: ReviewSubmission,
    section_doc: dict[str, Any],
    *,
    reviewer: str,
    generated_at: str = "",
) -> list[ReviewRecord]:
    """Expand one submission into its append-only rows, freezing the AI values
    it is correcting so a later regenerate can tell whether it still applies."""
    ai_items = {b.get("label"): b.get("delta") for b in (section_doc.get("breakdown") or [])}
    common = dict(
        token=token, reason_kind=sub.reason_kind, reason=sub.reason.strip(),
        reviewer=reviewer, evaluation_generated_at=generated_at,
        ai_rationale=str(section_doc.get("rationale") or section_doc.get("not_scored_reason") or ""),
    )
    out: list[ReviewRecord] = []
    for label, value in sub.items.items():
        out.append(ReviewRecord(
            target=ReviewTarget(segment_id=sub.segment_id, section=sub.section, item_label=label),
            kind="mark", ai_value=_as_float(ai_items.get(label)), human_value=float(value), **common))
    if sub.marks_earned is not None:
        out.append(ReviewRecord(
            target=ReviewTarget(segment_id=sub.segment_id, section=sub.section),
            kind="mark", ai_value=_as_float(section_doc.get("marks_earned")),
            human_value=float(sub.marks_earned), **common))
    if sub.state:
        out.append(ReviewRecord(
            target=ReviewTarget(segment_id=sub.segment_id, section=sub.section),
            kind="state", ai_state=str(section_doc.get("state") or ""),
            human_state=sub.state, **common))
    if sub.note.strip():
        out.append(ReviewRecord(
            target=ReviewTarget(segment_id=sub.segment_id, section=sub.section),
            kind="note", body=sub.note.strip(), **common))
    return out


def _as_float(v: Any) -> Optional[float]:
    try:
        return None if v is None else float(v)
    except (TypeError, ValueError):
        return None


# ── the merge ───────────────────────────────────────────────────────────────
def recompute_marks(section_doc: dict[str, Any], adjustable: dict[str, Any],
                    item_values: dict[str, float]) -> Optional[float]:
    """The section's marks implied by its (possibly adjusted) breakdown lines.

    Each plugin declares how its marks follow from its items, so the reviewer
    moves the judgement they have an opinion about and the arithmetic stays the
    system's job. Returns None when the plugin declares no derivation, in which
    case only a direct total override can change the marks."""
    mode = adjustable.get("recompute") or "none"
    labels = [b.get("label") for b in (section_doc.get("breakdown") or [])]
    if not labels or mode == "none":
        return None
    ai = {b.get("label"): _as_float(b.get("delta")) or 0.0
          for b in (section_doc.get("breakdown") or [])}
    vals = [float(item_values.get(str(l), ai.get(l, 0.0))) for l in labels]
    possible = _as_float(section_doc.get("marks_possible"))
    if mode == "mean_scaled":
        scale = (adjustable.get("item_scale") or [0.0, 10.0])[1] or 10.0
        if possible is None:
            return None
        return round(sum(vals) / len(vals) / float(scale) * possible, 2)
    if mode == "sum_deltas":
        return round(sum(vals), 2)
    return None


def _clamp(value: float, possible: Optional[float]) -> float:
    """Marks stay inside the section's own range. `marks_possible` is never
    editable — changing what a question is worth is a cadence edit, because two
    candidates scored out of different denominators aren't comparable."""
    value = max(value, 0.0)
    if possible is not None:
        value = min(value, possible)
    return round(value, 2)


def apply_reviews(doc: dict[str, Any], records: Iterable[ReviewRecord],
                  *, adjustable_by_section: Optional[dict[str, dict[str, Any]]] = None,
                  ) -> dict[str, Any]:
    """Join the immutable export with the review ledger.

    Returns a NEW document; `doc` is not mutated. A section nobody reviewed is
    returned byte-identical, with `review` left null — so an unreviewed
    evaluation reads exactly as it did before this feature existed."""
    if adjustable_by_section is None:
        from features.eval.plugins.registry import export_schemas
        adjustable_by_section = {k: (v.get("adjustable") or {})
                                 for k, v in export_schemas().items()}

    by_target: dict[tuple[str, str], list[ReviewRecord]] = {}
    for r in records:
        if r.status != "active":
            continue
        by_target.setdefault((r.target.segment_id, r.target.section), []).append(r)
    if not by_target:
        return doc

    out = dict(doc)
    sections: list[dict[str, Any]] = []
    touched = False
    for sec in doc.get("sections") or []:
        rs = by_target.get((sec.get("segment_id"), sec.get("section")))
        if not rs:
            sections.append(sec)
            continue
        merged = dict(sec)
        review = _section_review(sec, rs, adjustable_by_section.get(sec.get("section"), {}))
        if review is not None:
            merged["review"] = review.model_dump(mode="json")
            touched = True
        sections.append(merged)
    out["sections"] = sections

    if touched:
        out["review_status"] = "human_reviewed"
        out["totals_after_review"] = _totals_after_review(sections)
    return out


def _section_review(sec: dict[str, Any], records: list[ReviewRecord],
                    adjustable: dict[str, Any]) -> Optional[SectionReview]:
    """Fold one section's active records into the block the document carries."""
    latest = max(records, key=lambda r: r.created_at)
    possible = _as_float(sec.get("marks_possible"))

    item_values: dict[str, float] = {}
    items: list[ReviewedItem] = []
    direct: Optional[float] = None
    state = str(sec.get("state") or "scored")
    notes: list[str] = []
    stale = False

    ai_items = {b.get("label"): _as_float(b.get("delta"))
                for b in (sec.get("breakdown") or [])}
    for r in sorted(records, key=lambda r: r.created_at):
        if r.kind == "note":
            notes.append(r.body)
        elif r.kind == "state" and r.human_state:
            state = r.human_state
            # The AI's state moved under a state override — the reviewer was
            # correcting a different verdict than the one on screen now.
            if r.ai_state and r.ai_state != str(sec.get("state") or ""):
                stale = True
        elif r.kind == "mark" and r.human_value is not None:
            if r.target.item_label is None:
                direct = float(r.human_value)
                if _drifted(r.ai_value, _as_float(sec.get("marks_earned"))):
                    stale = True
            else:
                label = r.target.item_label
                item_values[label] = float(r.human_value)
                items.append(ReviewedItem(label=label, ai_value=ai_items.get(label),
                                          human_value=float(r.human_value), reason=r.reason))
                if _drifted(r.ai_value, ai_items.get(label)):
                    stale = True

    if state != "scored":
        # A non-scored review carries no marks, exactly as a non-scored section
        # carries none. Enforced by SectionReview's validator too; this is the
        # branch that makes it reachable rather than a construction error.
        return SectionReview(final_state=state, items=items, notes=notes,
                             reason_kind=latest.reason_kind, reason=latest.reason,
                             reviewer=latest.reviewer, reviewed_at=latest.created_at,
                             stale=stale)

    final = direct
    if final is None and item_values:
        final = recompute_marks(sec, adjustable, item_values)
    if final is None:
        final = _as_float(sec.get("marks_earned"))
    if final is None or possible is None:
        # Defensive: a scored section always carries both marks (the envelope's
        # validator refuses to construct one that doesn't), so there is nothing
        # numeric to state here. Record nothing rather than invent a number.
        return None

    return SectionReview(
        final_state="scored",
        final_marks_earned=_clamp(final, possible),
        final_marks_possible=possible,
        items=items, notes=notes,
        reason_kind=latest.reason_kind, reason=latest.reason,
        reviewer=latest.reviewer, reviewed_at=latest.created_at, stale=stale,
    )


def _drifted(frozen: Optional[float], current: Optional[float]) -> bool:
    """Did the AI change its mind since this correction was recorded?

    A regenerate rewrites every AI value. A correction to a judgement the model
    no longer makes is neither safe to drop (the reviewer's work vanishes) nor
    safe to re-apply, so it is flagged and the reviewer decides."""
    if frozen is None or current is None:
        return False
    return abs(frozen - current) > 1e-9


def _totals_after_review(sections: list[dict[str, Any]]) -> dict[str, Any]:
    """Totals over the reviewed values, by the same rule as the AI totals:
    scored sections only, a non-scored one shrinking the denominator rather
    than scoring zero."""
    earned = possible = 0.0
    by_state: dict[str, int] = {}
    scored = 0
    for sec in sections:
        rev = sec.get("review") or {}
        state = rev.get("final_state") or sec.get("state") or ""
        by_state[state] = by_state.get(state, 0) + 1
        if state != "scored":
            continue
        scored += 1
        earned += float(rev.get("final_marks_earned") if rev.get("final_marks_earned") is not None
                        else (sec.get("marks_earned") or 0.0))
        possible += float(rev.get("final_marks_possible") if rev.get("final_marks_possible") is not None
                          else (sec.get("marks_possible") or 0.0))
    earned, possible = round(earned, 2), round(possible, 2)
    return {
        "marks_earned": earned,
        "marks_possible": possible,
        "pct": round(100.0 * earned / possible, 1) if possible > 0 else None,
        "segments_total": len(sections),
        "segments_scored": scored,
        "segments_not_scored": len(sections) - scored,
        "by_state": by_state,
    }
