"""Pydantic schema for the evaluation rubric.

A rubric = one SectionLens per cadence phase. The lens says what that
section is FOR evaluatively: which dimensions to score, which to
deliberately ignore, its weight in the composite, and 5 behaviorally
anchored levels calibrated to the role's seniority bar.

Design rules baked into validation (see docs/evaluation_rubric.md):
  - dimensions come from a small canonical vocabulary (anti-halo: judges
    can't invent affect-class dims like "enthusiasm")
  - exactly 5 anchors per section (cross-candidate comparability)
  - weight 0 == quarantined (warm_up/wrap_up) — section is shown but its
    levels never enter the composite
  - at least one section must carry weight > 0
"""
from __future__ import annotations

from typing import Literal, Optional

from pydantic import BaseModel, Field, model_validator

# Canonical dimension vocabulary. Names are load-bearing: the UI renders
# these as toggle chips and the evaluation prompt quotes the definitions.
# Affect-class dimensions (energy, enthusiasm, culture fit, presence) are
# deliberately absent — they proxy introversion/culture, not competence.
CANONICAL_DIMS: dict[str, str] = {
    "technical_depth": "Causal understanding that survives probing — mechanism explanations, not buzzwords.",
    "problem_solving_process": "How they attack a problem: decomposition, handling ambiguity (asking OR stating assumptions), recovery.",
    "communication_clarity": "Could a listener reconstruct the answer? Load-bearing facts present — never accent/fluency/style.",
    "ownership_specificity": "Did THEY do it — specifics under probing (the decision made, alternatives weighed). Never pronouns.",
    "role_fit": "Operated at the role's altitude, evidenced by probed verifiable facts vs the JD. Never brand names/titles.",
    "code_quality": "Working, well-structured code: tests passed, decomposition, edge-case awareness. Never speed/idiom-style.",
}

# Anchor level names are fixed across all sections — comparability beats
# per-section creativity. Descriptions are section-specific.
ANCHOR_LEVELS: tuple[str, ...] = ("below_bar", "approaching", "mixed", "solid", "exceptional")
HIRE_BAR_LEVEL = "solid"

WEIGHT_MIN = 0.0
WEIGHT_MAX = 2.0


class BehavioralAnchor(BaseModel):
    level: str = Field(..., min_length=1)
    description: str = Field(..., min_length=5)

    @model_validator(mode="after")
    def _known_level(self) -> "BehavioralAnchor":
        if self.level not in ANCHOR_LEVELS:
            raise ValueError(f"anchor level must be one of {ANCHOR_LEVELS}, got {self.level!r}")
        return self


class SectionLens(BaseModel):
    phase_id: str = Field(..., min_length=1)
    purpose: str = Field(..., min_length=5, description="What hiring question this section answers.")
    score_dimensions: list[str] = Field(default_factory=list, max_length=3)
    ignore_dimensions: list[str] = Field(
        default_factory=list,
        description='Deliberately-unscored signals, "name: reason" strings.',
    )
    weight: float = Field(default=1.0, ge=WEIGHT_MIN, le=WEIGHT_MAX)
    anchors: list[BehavioralAnchor] = Field(default_factory=list)

    @model_validator(mode="after")
    def _consistent(self) -> "SectionLens":
        for d in self.score_dimensions:
            if d not in CANONICAL_DIMS:
                raise ValueError(
                    f"phase {self.phase_id!r}: unknown dimension {d!r} "
                    f"(allowed: {', '.join(CANONICAL_DIMS)})"
                )
        if self.weight > 0 and not self.score_dimensions:
            raise ValueError(f"phase {self.phase_id!r}: weight > 0 requires at least one score dimension")
        # Quarantined sections carry no anchors/dims — that's the point.
        if self.weight > 0:
            if len(self.anchors) != len(ANCHOR_LEVELS):
                raise ValueError(
                    f"phase {self.phase_id!r}: exactly {len(ANCHOR_LEVELS)} anchors required, got {len(self.anchors)}"
                )
            seen = [a.level for a in self.anchors]
            if seen != list(ANCHOR_LEVELS):
                raise ValueError(
                    f"phase {self.phase_id!r}: anchors must be exactly {list(ANCHOR_LEVELS)} in order, got {seen}"
                )
        return self


class Rubric(BaseModel):
    version: str = "1"
    seniority_bar: str = Field(..., min_length=5, description="The bar anchors are calibrated to.")
    source: Literal["derived", "heuristic", "ta_edited"] = "heuristic"
    generated_at: Optional[str] = None
    sections: list[SectionLens] = Field(..., min_length=1)

    @model_validator(mode="after")
    def _composite_possible(self) -> "Rubric":
        ids = [s.phase_id for s in self.sections]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate phase_id in rubric sections")
        if not any(s.weight > 0 for s in self.sections):
            raise ValueError("at least one section must have weight > 0 (all-quarantined rubric can't score)")
        return self


def validate_rubric_dict(data: dict) -> tuple[Optional[Rubric], Optional[str]]:
    """Parse + validate a rubric dict. Returns (rubric, None) or (None, error)."""
    try:
        return Rubric.model_validate(data), None
    except Exception as e:  # pydantic ValidationError or anything else
        return None, str(e)


def rubric_fingerprint(data: dict) -> str:
    """Stable hash of a rubric's SEMANTIC content (seniority_bar + sections).

    Deliberately excludes generated_at/source/version so a no-op re-save
    doesn't read as a rubric change. Evaluations store this fingerprint;
    the Performance tab compares it against the current rubric's to offer
    'regenerate — the rubric changed since this evaluation'."""
    import hashlib
    import json

    core = {"seniority_bar": data.get("seniority_bar"), "sections": data.get("sections")}
    blob = json.dumps(core, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]
