"""The evaluation export DOCUMENT — the envelope around the plugin sections.

Two layers, deliberately separate:

  - `features/eval/plugins/export.py` (owned by the plugin contract) defines
    what ONE plugin contributes: `ExportSection` (its declaration) and
    `ExportSectionModel` (the shape it emits, with the invariants baked into
    the model itself).
  - THIS module defines the whole DOCUMENT: session metadata, the sections in
    interview order, the self-describing schema map, and the totals.

`sessions/<token>/evaluation.json` (app/plugin_evaluation.py) is an INTERNAL
shape that exists to feed our own UI and changes whenever the UI does. This is
the opposite: a stable, versioned document an outside consumer — an ATS, a bias
auditor, a customer's pipeline — can be built against.

NON-SCORED IS NOT ZERO. A segment that was never observed, had too little
evidence, or whose plugin assumptions weren't met is not a zero. That invariant
is enforced one level down, by `ExportSectionModel`'s validator, which refuses
to construct a non-scored section carrying marks at all. So the totals here
cannot accidentally count one: there is no number to add. Flattening them to 0
would make a candidate whose coding round never ran look like they failed it.

The document carries `section_schemas` so it validates itself — a consumer
never has to fetch the contract separately from the data.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Iterable, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, SerializeAsAny, model_validator

from features.eval.plugins.base import SegmentEvaluation
from features.eval.plugins.export import ExportSectionModel
from features.eval.plugins.registry import (
    export_models, export_schemas, get_plugin, has_plugin,
)
from features.eval.sectioner import Segment

# Bump on any BREAKING change to the envelope (a field removed or its meaning
# changed). Additive fields do not require a bump — consumers must ignore
# unknown keys.
REPORT_VERSION = "1.0"

# The states that carry no marks. Kept as a tuple (not "anything != scored") so
# a NEW state has to be classified deliberately rather than silently counting
# as a zero.
NON_SCORED_STATES: tuple[str, ...] = (
    "not_observed",
    "insufficient_evidence",
    "assumptions_unmet",
    "error",
)

# Why a segment carries no marks, in words a non-engineer reading the report
# can act on.
_STATE_REASON: dict[str, str] = {
    "not_observed": "This part of the interview did not take place.",
    "insufficient_evidence": "There was not enough of an answer to judge.",
    "assumptions_unmet": "The scoring method's requirements were not met for this phase.",
    "error": "Scoring failed for this segment.",
}


class ExportedTotals(BaseModel):
    """Totals over SCORED segments only."""

    marks_earned: float = 0.0
    marks_possible: float = 0.0
    pct: Optional[float] = Field(
        default=None,
        description="marks_earned / marks_possible as a percentage; null when nothing was scored.",
    )
    segments_total: int = 0
    segments_scored: int = 0
    segments_not_scored: int = 0
    by_state: dict[str, int] = Field(
        default_factory=dict,
        description="Segment count per state — makes exclusions auditable.",
    )


class SessionMeta(BaseModel):
    token: str = ""
    role: str = ""
    candidate_name: str = ""
    modality: str = "voice"
    cadence_id: str = ""
    started_at: str = ""
    completed_at: str = ""


class _UnknownSection(ExportSectionModel):
    """Read-back fallback for a section whose owning plugin is no longer
    registered (removed, renamed, or a document written by a newer build).

    The envelope is still enforced — identity, state, and "a non-scored segment
    carries no marks" all still hold — but the payload is kept rather than
    rejected, so an old document stays readable instead of becoming garbage the
    day a plugin is retired."""

    model_config = ConfigDict(extra="allow")


class EvaluationReport(BaseModel):
    """The exported document. Versioned; consumers ignore unknown fields."""

    report_version: str = REPORT_VERSION
    generated_at: str = ""
    session: SessionMeta = Field(default_factory=SessionMeta)
    # In INTERVIEW ORDER — the order the sectioner produced them, which is the
    # order they happened. Never re-sorted by score or phase id.
    # SerializeAsAny is load-bearing, not a style choice: each entry is really a
    # PLUGIN SUBCLASS carrying its own payload (dimensions, criteria, tags...).
    # Declared as the base type alone, pydantic serialises to the base's fields
    # and silently DROPS every plugin-specific key — so the emitted document
    # would not validate against the `section_schemas` it ships with, and the
    # UI would render empty payloads. Duck-typed serialisation keeps them.
    sections: list[SerializeAsAny[ExportSectionModel]] = Field(default_factory=list)
    # The document describes itself: every declared section schema travels with
    # the data, so a consumer can validate what it received without fetching
    # anything from us.
    section_schemas: dict[str, Any] = Field(default_factory=dict)
    totals: ExportedTotals = Field(default_factory=ExportedTotals)

    # Totals recomputed from the HUMAN-adjusted marks. null means no section has
    # been reviewed, so there is nothing to recompute — a consumer that only
    # wants the operative number reads `totals_after_review or totals`. Same
    # model and same arithmetic as `totals`, so the two cannot diverge in how
    # they are computed; only the value each section contributes differs.
    totals_after_review: Optional[ExportedTotals] = None
    review_status: Literal["ai_only", "human_reviewed"] = "ai_only"

    @model_validator(mode="before")
    @classmethod
    def _parse_sections_against_their_declared_schema(cls, data: Any) -> Any:
        """Reading a stored document back validates each section against the
        model its OWN plugin declared, not against the shared envelope.

        The envelope is `extra="forbid"` on purpose — that is what stops a
        plugin emitting keys its schema doesn't declare. But every real section
        IS a subclass carrying a payload, so parsing the whole document through
        the base alone would reject exactly the documents we emit. Dispatching
        on the `section` key makes "the document validates itself" true in both
        directions rather than only on the way out."""
        if not isinstance(data, dict):
            return data
        raw = data.get("sections")
        if not isinstance(raw, list):
            return data
        try:
            models = export_models()
        except Exception:
            return data
        parsed = []
        for sec in raw:
            if not isinstance(sec, dict):
                parsed.append(sec)
                continue
            model = models.get(sec.get("section"), _UnknownSection)
            parsed.append(model.model_validate(sec))
        return {**data, "sections": parsed}


# ── building ────────────────────────────────────────────────────────────────
def build_totals(sections: Iterable[ExportSectionModel], *,
                 final: bool = False) -> ExportedTotals:
    """Sum the SCORED sections.

    A non-scored section cannot carry marks at all (`ExportSectionModel`'s
    validator forbids it), so "excluded from totals" is enforced by the type
    rather than by remembering to filter here.

    `final=True` sums what a human reviewer left instead of what the model said,
    falling back to the model's value on any section nobody reviewed. It is the
    SAME function deliberately: the AI totals and the reviewed totals must not
    be two implementations that can disagree about what a total is."""
    secs = list(sections)

    def state_of(x: ExportSectionModel) -> str:
        return x.review.final_state if (final and x.review) else x.state

    def earned_of(x: ExportSectionModel) -> float:
        if final and x.review:
            return x.review.final_marks_earned or 0.0
        return x.marks_earned or 0.0

    def possible_of(x: ExportSectionModel) -> float:
        if final and x.review:
            return x.review.final_marks_possible or 0.0
        return x.marks_possible or 0.0

    scored = [x for x in secs if state_of(x) == "scored"]
    earned = round(sum(earned_of(x) for x in scored), 2)
    possible = round(sum(possible_of(x) for x in scored), 2)
    by_state: dict[str, int] = {}
    for x in secs:
        st = state_of(x)
        by_state[st] = by_state.get(st, 0) + 1
    return ExportedTotals(
        marks_earned=earned,
        marks_possible=possible,
        pct=round(100.0 * earned / possible, 1) if possible > 0 else None,
        segments_total=len(secs),
        segments_scored=len(scored),
        segments_not_scored=len(secs) - len(scored),
        by_state=by_state,
    )


def build_report(
    pairs: Iterable[tuple[Segment, SegmentEvaluation]],
    *,
    session: Optional[dict[str, Any]] = None,
    generated_at: Optional[str] = None,
) -> EvaluationReport:
    """Assemble the export document from (segment, evaluation) pairs.

    Pairs arrive in INTERVIEW ORDER and that order is preserved. Each plugin
    fills its own section via `export_section`; a plugin that declares none is
    skipped rather than emitting a half-shape."""
    sections: list[ExportSectionModel] = []
    for segment, ev in pairs:
        if not (ev.plugin_id and has_plugin(ev.plugin_id)):
            continue
        plugin_cls = get_plugin(ev.plugin_id)
        if plugin_cls.export_descriptor() is None:
            continue
        sec = plugin_cls().export_section(segment, ev)
        if sec is not None:
            sections.append(sec)

    return EvaluationReport(
        report_version=REPORT_VERSION,
        generated_at=generated_at or datetime.now(timezone.utc).isoformat(timespec="seconds"),
        session=SessionMeta.model_validate(session or {}),
        sections=sections,
        section_schemas=export_schemas(),
        totals=build_totals(sections),
    )
