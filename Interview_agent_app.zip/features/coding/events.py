"""Event-bus kinds emitted by the coding module.

These flow through the existing event bus (same one used by STT/TTS/director).
Consumers: director (advance on submit), event_log (persist for eval),
broadcaster (forward to browser via WS).

Naming: all coding events start with "coding_" so a grep finds them quickly.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ---- Event kind constants (string event names on the bus) -------------------

CODING_PHASE_STARTED = "coding_phase_started"
"""Director entered a coding phase. Payload: CodingPhaseStartedEvent."""

CODING_PHASE_ENDED = "coding_phase_ended"
"""Coding phase finished — either by Submit, time budget, or director force-end."""

CODING_CODE_EDIT = "coding_code_edit"
"""Candidate edited code (debounced ~500ms). Optional — may be off for privacy."""

CODING_CODE_RUN = "coding_code_run"
"""Candidate clicked Run. Includes the code at run time."""

CODING_CODE_RUN_RESULT = "coding_code_run_result"
"""Pyodide finished executing — stdout/stderr/test results in payload."""

CODING_CODE_SUBMITTED = "coding_code_submitted"
"""Candidate clicked Submit — terminal event for the phase. Director advances."""

CODING_HINT_REQUESTED = "coding_hint_requested"
"""Candidate asked for a hint (explicit click or 'help' voice intent)."""

CODING_HINT_DELIVERED = "coding_hint_delivered"
"""AI delivered a hint via TTS. Tracks hint_level for next-stuck escalation."""

CODING_ANTI_CHEAT = "coding_anti_cheat"
"""Browser flagged a signal (paste, focus loss, devtools). Informational only."""


# ---- Event payload dataclasses ----------------------------------------------
# These mirror the bus event format used elsewhere in the codebase.
# Keep them simple — they cross the asyncio boundary.


@dataclass
class CodingPhaseStartedEvent:
    """Emitted when director enters a coding phase."""

    phase_id: str
    question_id: str
    question_prompt: str
    starter_code: str
    test_case_count: int
    time_budget_s: int


@dataclass
class CodingPhaseEndedEvent:
    """Emitted when coding phase wraps up. reason tells you why."""

    phase_id: str
    reason: str  # "submitted" | "time_budget" | "director_force_end" | "session_end"
    duration_s: float


@dataclass
class CodingCodeEditEvent:
    """Debounced snapshot of editor state. Optional (controlled by feature flag)."""

    phase_id: str
    code: str
    edit_count: int  # monotonic counter for ordering


@dataclass
class CodingCodeRunEvent:
    """Candidate clicked Run."""

    phase_id: str
    code: str
    run_count: int  # monotonic counter — how many Runs in this phase


@dataclass
class CodingCodeRunResultEvent:
    """Pyodide returned execution results."""

    phase_id: str
    run_count: int
    stdout: str
    stderr: str
    runtime_ms: int
    test_results: list[dict[str, Any]] = field(default_factory=list)
    # test_results: [{name: str, passed: bool, expected: str, actual: str}]


@dataclass
class CodingCodeSubmittedEvent:
    """Terminal event — director advances on this."""

    phase_id: str
    final_code: str
    final_test_results: list[dict[str, Any]] = field(default_factory=list)
    runs_used: int = 0
    time_to_submit_s: float = 0.0


@dataclass
class CodingHintRequestedEvent:
    """Candidate explicitly asked for a hint."""

    phase_id: str
    current_hint_level: int


@dataclass
class CodingHintDeliveredEvent:
    """AI delivered hint via TTS."""

    phase_id: str
    hint_level: int
    hint_text: str


@dataclass
class CodingAntiCheatEvent:
    """Browser-side signal. Informational only — never blocks."""

    phase_id: str
    reason: str  # "paste" | "tab_focus_lost" | "devtools_opened"
    metadata: dict[str, Any] = field(default_factory=dict)
