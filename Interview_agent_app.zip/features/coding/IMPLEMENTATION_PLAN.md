# Coding module — Implementation Plan

> **Status as of this writing:** plan approved, execution paused at user
> request after Tier 1 items #4 (R4 — ai_activity reset) and #2 (S2 — filler
> gate) landed. Tier 1 #5 (R3 — cloud parity) is partially in progress
> (closure-scoped `_hint_levels` + `tracer_ref` added; handlers pending).
>
> Mirror copy of `C:\Users\RaghuDasigi\.claude\plans\tingly-booping-pearl.md`,
> placed in the repo so it can be reviewed alongside the code.

---

## Context

The `coding/` module (Pyodide-in-browser Python + Monaco editor for an
in-interview coding phase) ships as a vertical slice with feature flag
`CODING_ENABLED`. The basic plumbing is wired (cadence schema accepts the
fields, director has phase-entry/exit hooks, both WS dispatchers route
coding messages). But a deeper audit found that the slice does **not**
hold up end-to-end against the live interview flow. The `INTEGRATION_GUIDE.md`
is stale, the ROADMAP "Completed" section overstates the wiring of items
#1 and #6, and several adjacent systems (latency orchestrator, slow LLM
context, session-end logic, admin event viewer) are not yet aware that
a coding phase exists.

This plan covers what it actually takes to integrate `coding/` into the
flow for a pilot — not just close the cloud WS gap.

Pilot target: both **local-dev** (`run_app.sh` / `run_app.bat`) and **Azure
cloud deploy**. Operator persona: admin (Talent Acquisition / hiring
manager) uses the admin scheduler UI; coding phases get inserted via a
new question-picker (auto-emission via cadence-LLM is deferred).

---

## Progress

| Item | Status | Files touched |
|---|---|---|
| Tier 1 #4 (R4): ai_activity reset on coding-phase exit | ✅ done | `stream_b_new/core/director.py:431-454` |
| Tier 1 #2 (S2): gate STT-wait filler during coding | ✅ done | `stream_b_new/core/director.py:1229-1242` |
| Tier 1 #5 (R3): cloud WS parity (force_talk + hint TTS) | 🔄 in progress (closure vars added; handlers pending) | `deploy/azure_app.py:1012-1023` |
| Tier 1 #3 (S3): terminal coding-phase session end | ⏳ pending | — |
| Tier 1 #1 (S1): plumb submitted code into slow-LLM context | ⏳ pending | — |
| Tier 2 #6 (S4): wire coding eval into admin/evaluation_service.py | ⏳ pending | — |
| Tier 2 #7 (R1): gate phase_override during coding | ⏳ pending | — |
| Tier 2 #8 (R2): preload Pyodide during warm_up | ⏳ pending | — |
| Tier 2 #9 (R5): admin event-viewer rows for coding events | ⏳ pending | — |
| Tier 3 #10 (R6): default coding panel to minimized + maximize button | ⏳ pending | — |
| Tier 3 #11: fallback generic_prompts for coding phases | ⏳ pending | — |
| Tier 3 #12a/b: GET /admin/coding/questions + /question/{id} endpoints | ⏳ pending | — |
| Tier 3 #12c: inline question preview on cadence-review | ⏳ pending | — |
| Tier 3 #12d: question-picker modal + "Add coding phase" button | ⏳ pending | — |
| Tier 3 #13: drop coding_time_budget_s from schema | ⏳ pending | — |

---

## Activation flow — how the coding screen comes up (and goes away)

**The coding UI is not a separate page, separate URL, separate socket, or
separate service.** It is an overlay panel inside the existing candidate
page, lazy-loaded when needed.

### Server → browser (activation)

```
1. Director enters coding phase
   stream_b_new/core/director.py:449-502
   → emits bus event `coding_phase_started` with full payload
     (phase_id, question_id, question_prompt, starter_code,
      test_cases, function_name, time_budget_s, test_case_count)
   → mutates ai_activity = AIActivityState.CODING

2. WS bus subscriber forwards bus event → WS message
   orchestrator_new/web/launcher.py:269-313 (local)
   deploy/azure_app.py:1029-1063 (cloud)
   mapping: `coding_phase_started` → WS type `coding_phase_start`

3. Browser receives WS message on the SAME socket that carries audio,
   STT, TTS, phase-change events
   ui/candidate/app.js:669-672

4. Browser lazy-imports the coding module (NOT in default bundle)
   ui/candidate/app.js:706-710:
   import("./coding/coding_panel.js")
   ~10 KB glue + ~6 MB Pyodide WASM via worker

5. Browser creates a host div and appends to document.body
   ui/candidate/app.js:719-727:
   <div id="codingHost" class="coding-host"></div>
   CSS: position: fixed; inset: 0; z-index: 9999
   (overlays everything; avatar + chat stay in DOM underneath)

6. mountCodingPanel({hostEl, phaseStartMsg, sendWS}) fetches the
   HTML template, injects CSS, wires Monaco + Pyodide worker
   + Run/Submit/Hint/Talk-to-AI button handlers
   ui/candidate/coding/coding_panel.js:57+
```

### Browser → server (during coding)

Same WebSocket. New message types only:

| Browser sends | Server publishes to bus | Side effect |
|---|---|---|
| `coding_code_edit` (debounced 500 ms) | `coding_code_edit` | Persisted to events.jsonl (replay) |
| `coding_code_run` | `coding_code_run` | Logged |
| `coding_code_run_result` | `coding_code_run_result` | Logged |
| `coding_code_submitted` | `coding_code_submitted` | **Auto-advances phase** |
| `coding_hint_request` | `coding_hint_requested` | Dispatches hint TTS + banner |
| `coding_force_talk` | `coding_force_talk_requested` | Unblocks AI dispatch |
| `coding_anti_cheat` | `coding_anti_cheat` | Logged for TA review |
| `coding_preload_ready` | `coding_preload_ready` | Confirms warm_up preload landed |

### Server → browser (deactivation)

```
1. Director exits coding phase (Submit auto-advance or duration_s elapsed)
   stream_b_new/core/director.py:431-454
   → emits bus event `coding_phase_ended`
   → resets ai_activity = AIActivityState.IDLE (Tier 1 #4 ✅)

2. WS forwarder → WS type `coding_phase_end`

3. Browser app.js:674-676 → _unmountCodingPanel()
   → sets display:none on the host
   → existing live-screen flexbox layout reflows
   → avatar + chat are visible again, AI resumes talking in the
     next (non-coding) phase
```

### What is "separate" vs "shared"

| Concern | Status |
|---|---|
| Candidate URL | **Shared** — same `/candidate?token=...` |
| WebSocket | **Shared** — same socket, multiplexed message types |
| Audio pipeline (Stream A on 8010/8011/8012) | **Shared and active** — STT keeps running during coding |
| Avatar widget (`#avatar`) | **Shared** — in DOM, hidden under overlay by default (Tier 3 #10 minimizes overlay so avatar stays visible) |
| Chat transcript | **Shared** — in DOM, hidden under overlay |
| Server FastAPI app | **Shared** — no new endpoints, no new services |
| Frontend bundle | **Lazy-loaded** — `coding/coding_panel.js` + Pyodide loaded only when needed (or preloaded during warm_up after Tier 2 #8) |
| Pyodide worker | **Module-level singleton in coding_panel.js** — survives mount/unmount within a session |
| Code subdirectory (browser) | **Separate folder** for organization: `ui/candidate/coding/` holds the editor + worker; not a separate app |
| Backend module | **Separate folder** `coding/` for organization (mirrors `admin/` pattern); integrates via 6 well-defined hooks per `coding/README.md` |

### What the candidate sees, end-to-end

1. **Pre-coding phases** — Avatar speaks, candidate replies via mic.
   Normal interview UI.
2. **Coding phase entry** — Avatar finishes its intro line ("Briefly
   tell the candidate we're going to do a short coding exercise…"
   from `generic_prompts`). Editor overlay slides in.
3. **During coding** — Editor minimized to bottom-right by default
   (Tier 3 #10) so avatar stays visible. Candidate types, clicks Run
   to test, sees pass/fail. Can click Hint (AI voices a hint) or
   Talk-to-AI (AI resumes conversation). STT is hot the whole time —
   voice can be used to ask questions.
4. **Submit** — Browser sends `coding_code_submitted`. Server
   auto-advances phase. Editor unmounts. Avatar + chat reappear.
5. **`code_discussion` phase** — AI now talks about the code the
   candidate just wrote (Tier 1 #1 plumbs the code into the slow
   LLM's context).

---

## Admin control plane — how a coding phase gets into a session

### Today (without this PR)

- **Global gate**: `CODING_ENABLED=1` env var. Operator-level, not in admin UI.
- **Per-session enable**: admin hand-edits the cadence YAML in the
  cadence-review screen to add `coding_question_id: <id>` to a phase.
  Cadence-LLM does NOT auto-insert coding phases (ROADMAP #6 mis-marked
  complete).
- **Question selection**: admin must know question IDs from
  `coding/questions/library.yaml`. No picker, no preview.

### After this PR (Tier 3 #12 expanded)

- **"Add coding phase" button** on cadence-review (between phase cards).
- **Question-picker modal**: filter by topic / difficulty / role_fit;
  inline preview of prompt + starter code; click to insert.
- **Inline preview** on existing coding phases: question prompt
  truncated to ~200 chars + collapsed starter-code block, plus a
  "Change question" button.
- Admin never touches YAML directly.

### Still NOT in this PR (deferred to follow-up)

- Cadence-LLM auto-emission of coding phases (ROADMAP #6 — wait for
  pilot feedback to design the JD heuristic).

---

## Cadence placement — where the coding phase actually lives

The current default cadence (`stream_b_new/cadence/default.yaml`) is
`warm_up → resume_deep_dive → technical_questions → wrap_up` (240 s).
For an interview WITH coding, the recommended slot is a
`coding_q1 + code_discussion` **pair** between `resume_deep_dive` and
`technical_questions`:

```
warm_up → resume_deep_dive → coding_q1 → code_discussion → technical_questions → wrap_up
  30 s         60 s            300–600 s      60 s              120 s              30 s
```

Why this slot:

- **After `warm_up`**: candidate's mic / VAD / TTS confirmed before AI
  goes silent in the coding phase.
- **After `resume_deep_dive`**: AI has context before testing them; the
  candidate has warmed up intellectually on their own resume.
- **Before `technical_questions`**: the broader Q&A can ground in what
  they just wrote ("you used a dict here — how does that compare to…").
- **Pair `coding_q1` with `code_discussion`**: during coding the AI is
  silent (director gates dispatches); the discussion phase is where the
  AI resumes talking and where you actually evaluate the candidate.
  Submitting auto-advances into this phase.

---

## Gap inventory (audited; ground-truth, not from docs)

### Showstoppers — feature does not work without these

| # | Gap | File(s) | Symptom |
|---|---|---|---|
| **S1** | Slow LLM has **zero access** to submitted code or test results | `stream_b_new/core/conversation_context.py:26-86`, `stream_b_new/agents/question_agent.py:509-620` | `code_discussion` phase is a pantomime — AI asks generic "tell me about your approach" with no knowledge of the actual code |
| **S2** ✅ | STT-wait filler ladder fires during coding | `stream_b_new/core/director.py:1229-1242` | After 10 s of candidate humming/coughing during typing, AI speaks "Give me a moment to process that." over them |
| **S3** | Session hangs if a coding phase is terminal | `orchestrator_new/web/launcher.py:469-478` sets `ai_activity=AUDIO_DONE` on submit but **never sets `_end_request_ts_ms`** | Candidate submits on the final phase; session never terminates |
| **S4** | `coding.evaluate_submission` has zero callers in `admin/` | Defined in `coding/evaluator.py:48-167` but `admin/evaluation_service.py` doesn't import it | Session evaluation has no coding quality score |

### Risks — interview may misbehave even when feature appears to work

| # | Risk | File(s) | Failure mode |
|---|---|---|---|
| **R1** | `phase_override_agent` is LLM-based, no coding-phase awareness | `stream_b_new/agents/phase_override_agent.py` | Candidate mumbling "I'm done with this" while typing can emit `end_now` → director terminates entire interview |
| **R2** | Pyodide preload never fires during `warm_up` | `case "coding_preload"` exists at `ui/candidate/app.js:665-667` but server never emits it | Candidate sees ~6 MB WASM download (~10 s spinner) when coding phase begins |
| **R3** 🔄 | Cloud WS dispatch missing `coding_force_talk` + hint→TTS | `deploy/azure_app.py:1064-1123` | On cloud: "Talk to AI" → silence; "Hint" → text-only, no avatar voice |
| **R4** ✅ | `ai_activity` not reset on non-submit coding-phase exit | `stream_b_new/core/director.py:431-454` | (Fixed) Time-budget exit no longer leaves next phase mute |
| **R5** | Admin event-viewer has no coding handlers | `admin/event_viewer.py:24-40` | TA sees empty `coding_code_submitted` rows; submitted code invisible in admin UI |
| **R6** | Avatar + chat hidden behind coding overlay | `ui/candidate/coding/coding_panel.css:6-15` | Candidate cannot see avatar or earlier conversation while coding |

---

## Scope: all three tiers (confirmed)

### Tier 1 — must-have, no pilot without these

1. **S1**: Plumb submitted code into slow-LLM context. New
   `last_coding_submission` field on `SessionState`. Update
   `conversation_context.py` to surface it. Update `question_agent.py`
   to include a "Candidate just submitted this code:" block. Only
   inject during the phase immediately following a coding phase.
2. **S2** ✅: Gate `start_stt_wait_filler` on `ai_activity != CODING`.
3. **S3**: Set `_end_request_ts_ms` when terminal coding phase
   submits, in both launcher and azure_app submit handlers.
4. **R4** ✅: Reset `ai_activity = IDLE` in director's coding-phase
   exit hook.
5. **R3** 🔄: Port `coding_force_talk` + hint→TTS into `azure_app.py`.
   Mirror `launcher.py:376-454`.

### Tier 2 — should-have for a credible pilot

6. **S4**: Wire `coding.evaluate_submission` into
   `admin/evaluation_service.py`. Attach `CodingScore` to eval JSON
   under `coding_quality`.
7. **R1**: Skip `phase_override_agent` entirely when
   `ai_activity == CODING` (matches verifier gating). Candidate
   can still submit via the editor button.
8. **R2**: Emit `coding_preload` WS message during `warm_up` phase
   entry when next phase is a coding phase.
9. **R5**: Add coding event entries to `admin/event_viewer.py`.
   Render submitted code in a collapsed `<details>` block.

### Tier 3 — polish (in scope; lands last)

10. **R6**: Default coding panel to `data-minimized="1"` on mount.
    Add a "maximize" button alongside minimize.
11. **Fallback `generic_prompts`** for coding phases when admin
    leaves them empty.
12. **Cadence-review admin UI** for coding phases:
    - 12a. `GET /admin/coding/questions` endpoint (filter by
      topic/difficulty/role_fit; strips `solution`).
    - 12b. `GET /admin/coding/question/{id}` endpoint.
    - 12c. Inline preview on existing coding phases in cadence-review.
    - 12d. Question-picker modal + "Add coding phase" button.
      Inserts coding_q1 + code_discussion pair into the cadence at
      the chosen position.
13. **Drop `coding_time_budget_s` from schema.** Single source of
    truth = `duration_s`.

---

## Risk analysis

- **Tier 1 touches both halves of the conversation pipeline** (context
  builder + director). Director changes are historically fragile.
  Run baseline cadence with `CODING_ENABLED=0` after every director
  edit to confirm no regression on the non-coding interview path.
- **S1 (code → LLM context)**: scope creep risk. Keep injection
  surgical — only one block in the prompt, only present when
  `state.last_coding_submission` is set and the current phase is
  immediately downstream of the coding phase. Don't carry it through
  the entire rest of the interview.
- **S2 (filler gate)** ✅: low risk. Single `if` check; filler ladder
  already conditional on other states.
- **S3 (terminal-phase end)**: verify `_on_session_end_requested`
  works without a `wrap_up`-named phase. Path probably works because
  session-end is just `_tracer.event("session_ended", ...)` + cleanup,
  not name-dependent — but check.
- **R1 (phase_override gating)**: skipping it during coding removes
  voice barge-in for "I'm done". Submit button is the primary path;
  voice was nice-to-have.
- **`broadcaster.set_coding_inbound_callback` is last-write-wins**.
  Launcher + azure_app are never wired in the same process under any
  known entry point — confirm with a process-startup grep before
  shipping.

---

## Files touched (all three tiers)

Reads (reference, not edited):
- `orchestrator_new/web/launcher.py:269-494` — port source for Tier 1 #5
- `orchestrator_new/web/broadcaster.py:105-119` — callback semantics
- `coding/__init__.py`, `coding/evaluator.py` — public API for Tier 2 #6
- `coding/questions/library.yaml` — Tier 3 #12 question source

Edits:
- `deploy/azure_app.py` — Tier 1 #5 (force_talk + hint TTS), #3 (terminal end)
- `stream_b_new/core/director.py` — Tier 1 #2 ✅, #4 ✅, #1 (preload hook in Tier 2 #8), #13 (budget field)
- `stream_b_new/core/conversation_context.py` — Tier 1 #1 (code in context)
- `stream_b_new/agents/question_agent.py` — Tier 1 #1 (prompt block)
- `stream_b_new/contracts/session_state.py` — Tier 1 #1 (new `last_coding_submission` field)
- `orchestrator_new/web/launcher.py` — Tier 1 #1 (capture submission), #3 (terminal end)
- `admin/evaluation_service.py` — Tier 2 #6 (eval pipeline)
- `admin/event_viewer.py` — Tier 2 #9 (admin rows)
- `admin/main.py` — Tier 3 #12a/b (endpoints)
- `admin/static/admin.js` — Tier 3 #12c (preview)
- `admin/static/coding_picker.js` (new) — Tier 3 #12d (picker modal)
- `admin/templates/_coding_picker.html` (new) — Tier 3 #12d (modal partial)
- `admin/templates/cadence_review.html` — Tier 3 #12d (include modal)
- `admin/static/admin.css` — Tier 3 #12d (picker styling)
- `stream_b_new/agents/phase_override_agent.py` OR `director.py` — Tier 2 #7
- `stream_b_new/cadence/schema.py` — Tier 3 #11, #13
- `ui/candidate/coding/coding_panel.js` — Tier 3 #10 (default minimized + maximize)
- `ui/candidate/coding/coding_panel.css` — Tier 3 #10 (maximize styling)
- `coding/example_cadence.yaml` — Tier 3 #13 (drop field)

---

## Verification

Three smoke runs against `coding/example_cadence.yaml` (with
`CODING_ENABLED=1`), once on local and once on cloud:

1. **Happy path — submit.** warm_up → coding_q1 → Submit before time
   budget → `code_discussion` enters → AI references the actual code
   the candidate wrote (Tier 1 #1 working) → wrap_up → session ends.
2. **Time-budget exit.** Set `duration_s: 30` on coding_q1. Sit idle
   30 s. Expect phase to auto-advance AND AI to dispatch the next
   phase (Tier 1 #4 ✅).
3. **Terminal coding phase.** Hand-edit a cadence where coding_q1 is
   the last phase. Submit. Expect session to terminate cleanly
   within ~5 s (Tier 1 #3 working).

Audio behavior tests (local first, then cloud):

4. **Filler ladder muted during coding.** Enter coding phase, sit
   silent except for one cough (>1.5 s) every 10 s for 60 s. Expect
   NO filler/apology utterances (Tier 1 #2 ✅).
5. **Hint TTS on cloud.** Click Hint button. Expect avatar voice
   ("Hint: …") + banner text (Tier 1 #5 working).
6. **Force-talk on cloud.** Click "Talk to AI". Expect AI to
   respond within ~2 s (Tier 1 #5 working).

Eval pipeline test:

7. **Score in eval JSON.** Complete a session with coding phase.
   Verify the post-session eval includes
   `coding_quality: {correctness, readability, idiomatic, edge_cases, rationale}`
   (Tier 2 #6 working).

Admin UI tests:

8. **Event viewer rows.** Open session detail in admin UI.
   `coding_code_submitted` row shows the candidate's code in an
   expandable block (Tier 2 #9 working).
9. **Question picker.** On cadence-review, click "Add coding phase".
   Modal opens listing all questions with topic/difficulty filters.
   Pick one → cadence updates with a coding_q1 + code_discussion
   pair (Tier 3 #12d working).
10. **Inline preview.** Existing coding phase shows prompt + starter
    code preview and "Change question" button (Tier 3 #12c working).

UX tests (Tier 3):

11. **Avatar visible during coding.** Enter coding phase — panel
    mounts minimized; avatar stays visible. "Maximize" → full-screen
    editor; "minimize" → avatar returns (Tier 3 #10).
12. **Schema fallback for empty `generic_prompts`.** Submit cadence
    with coding phase but no `generic_prompts`. Schema accepts +
    injects default opener (Tier 3 #11).

Regression (final safety net):

13. **Non-coding cadence still works.** Run a session with default
    cadence (no coding phase). Confirm warm_up → resume_deep_dive →
    technical_questions → wrap_up runs identically to pre-change
    behavior. This is the critical safety net for director edits.
14. **`coding_time_budget_s` removal (Tier 3 #13).** Confirm
    existing cadences without the field still load; example_cadence.yaml
    updated.

---

## Out of scope (explicit defer)

- Stuck detector (90 s idle → AI offers hint). ROADMAP #2 dispatch
  is wired but the trigger is not.
- Cadence-LLM auto-emission of coding phases (ROADMAP #6 mis-marked
  complete; deferred until pilot feedback informs the JD heuristic).
- Anti-cheat UI rendering in admin (`coding_anti_cheat` events land
  in events.jsonl but admin UI doesn't surface them).
- Code-replay scrub timeline (ROADMAP #5).
- Multi-language support (Pyodide → Piston swap-out).
