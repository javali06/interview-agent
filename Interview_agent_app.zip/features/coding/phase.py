"""CodingPhase state machine.

A CodingPhase is a single coding question instance within an interview session.
Owned by the director: created when entering the phase, mutated by WS events,
destroyed when the phase ends.

Pure data + transitions. No IO, no asyncio. Director persists / emits events
on its own.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class CodingPhaseState(str, Enum):
    """Lifecycle of a single coding phase."""

    PENDING = "pending"          # phase declared in cadence, not yet entered
    ACTIVE = "active"            # candidate has the editor, can run/submit
    SUBMITTED = "submitted"      # candidate clicked Submit; awaiting director advance
    ENDED = "ended"              # director has moved on; this phase is closed


@dataclass
class TestCase:
    """One test case for a coding question. The candidate never sees `solution`."""

    name: str
    input: str  # textual representation of input — eval'd against function
    expected: str  # textual representation of expected output
    # Test runner builds: f"func({input})" and compares repr(result) == expected
    # Keep simple for now — see ROADMAP for richer harnesses.


@dataclass
class CodingPhase:
    """Runtime state for one coding question in a session.

    Created by director on phase enter; updated by WS event handlers.
    """

    phase_id: str
    question_id: str
    question_prompt: str
    starter_code: str
    test_cases: list[TestCase]
    time_budget_s: int
    function_name: str = ""  # e.g., "running_sum" — used by test harness
    hints: list[str] = field(default_factory=list)

    # Runtime state
    state: CodingPhaseState = CodingPhaseState.PENDING
    started_at_ms: int = 0
    ended_at_ms: int = 0
    current_code: str = ""
    last_run_result: "dict[str, Any] | None" = None
    runs_used: int = 0
    edits_count: int = 0
    hint_level: int = 0  # 0 = no hints used; increments each delivery
    final_code: str = ""
    final_test_results: list[dict[str, Any]] = field(default_factory=list)

    # ---- Lifecycle transitions ----

    def begin(self) -> None:
        """Move to ACTIVE. Called by director on phase enter."""
        if self.state != CodingPhaseState.PENDING:
            raise RuntimeError(f"CodingPhase.begin from invalid state {self.state}")
        self.state = CodingPhaseState.ACTIVE
        self.started_at_ms = _now_ms()
        self.current_code = self.starter_code

    def record_edit(self, code: str) -> None:
        """Called on each debounced code_edit message from browser."""
        if self.state != CodingPhaseState.ACTIVE:
            return  # ignore late edits
        self.current_code = code
        self.edits_count += 1

    def record_run(self, code: str, result: dict[str, Any]) -> None:
        """Called when browser returns a run result."""
        if self.state != CodingPhaseState.ACTIVE:
            return
        self.current_code = code
        self.last_run_result = result
        self.runs_used += 1

    def submit(self, code: str, test_results: list[dict[str, Any]]) -> None:
        """Candidate clicked Submit — terminal for the candidate side."""
        if self.state != CodingPhaseState.ACTIVE:
            return
        self.state = CodingPhaseState.SUBMITTED
        self.final_code = code
        self.final_test_results = test_results

    def end(self, reason: str = "submitted") -> None:
        """Director closing the phase out. reason for event log."""
        if self.state == CodingPhaseState.ENDED:
            return
        self.state = CodingPhaseState.ENDED
        self.ended_at_ms = _now_ms()
        self._end_reason = reason  # type: ignore[attr-defined]

    # ---- Derived properties ----

    @property
    def elapsed_s(self) -> float:
        if self.started_at_ms == 0:
            return 0.0
        end = self.ended_at_ms if self.ended_at_ms else _now_ms()
        return (end - self.started_at_ms) / 1000.0

    @property
    def is_time_budget_exceeded(self) -> bool:
        return self.elapsed_s >= self.time_budget_s

    @property
    def passed_all_tests(self) -> bool:
        if not self.final_test_results:
            return False
        return all(r.get("passed") for r in self.final_test_results)

    def to_event_payload(self) -> dict[str, Any]:
        """Snapshot for emitting bus events / serializing to events.jsonl."""
        return {
            "phase_id": self.phase_id,
            "question_id": self.question_id,
            "state": self.state.value,
            "elapsed_s": round(self.elapsed_s, 2),
            "runs_used": self.runs_used,
            "edits_count": self.edits_count,
            "hint_level": self.hint_level,
            "final_code": self.final_code,
            "final_test_results": self.final_test_results,
            "passed_all_tests": self.passed_all_tests,
        }


def _now_ms() -> int:
    return int(time.time() * 1000)
