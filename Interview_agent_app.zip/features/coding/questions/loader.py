"""Loads + validates the vetted question library from library.yaml.

Public API:
    load_library() -> dict[str, Question]
    get_question(question_id) -> Question
    pick_question(topic=..., difficulty=..., role_fit=...) -> Question

NEVER expose `solution` to the browser — that field is library-internal,
used only for reference validation (ROADMAP #4) and possibly server-side
sanity-check of submissions.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any, Optional

import yaml


_LIBRARY_PATH = Path(__file__).parent / "library.yaml"


# Default per-question time budget by difficulty, in seconds. Library
# entries can override with `estimated_time_s`. The cadence YAML can
# further override per-question via `coding_question_time_overrides`.
_DEFAULT_TIME_BY_DIFFICULTY: dict[str, int] = {
    "easy": 600,
    "medium": 1200,
    "hard": 1800,
}


@dataclass
class Question:
    """A single coding question. Mirrors library.yaml schema."""

    id: str
    title: str
    prompt: str
    starter_code: str
    function_name: str
    test_cases: list[dict[str, str]] = field(default_factory=list)
    hints: list[str] = field(default_factory=list)
    difficulty: str = "easy"
    topic: list[str] = field(default_factory=list)
    role_fit: list[str] = field(default_factory=list)
    estimated_time_s: int = 0      # 0 → derive from difficulty default
    _solution: str = ""  # leading underscore: library-internal, not exposed

    @property
    def time_budget_s(self) -> int:
        """Per-question time budget. Honors library override; else falls
        back to the difficulty default."""
        if self.estimated_time_s and self.estimated_time_s > 0:
            return self.estimated_time_s
        return _DEFAULT_TIME_BY_DIFFICULTY.get(self.difficulty, 600)

    def to_browser_payload(self) -> dict[str, Any]:
        """Safe-to-send-to-browser projection — strips solution + hints."""
        return {
            "id": self.id,
            "title": self.title,
            "prompt": self.prompt.strip(),
            "starter_code": self.starter_code,
            "function_name": self.function_name,
            "test_cases": [
                {"name": tc["name"], "input": tc["input"], "expected": tc["expected"]}
                for tc in self.test_cases
            ],
            "difficulty": self.difficulty,
            "time_budget_s": self.time_budget_s,
            "hint_count": len(self.hints),
        }


class QuestionLibraryError(RuntimeError):
    """Raised when library.yaml fails to load or validate."""


@lru_cache(maxsize=1)
def load_library() -> dict[str, Question]:
    """Load + validate library.yaml. Cached after first call.

    Raises QuestionLibraryError if the file is missing/malformed.
    """
    if not _LIBRARY_PATH.exists():
        raise QuestionLibraryError(f"library.yaml not found at {_LIBRARY_PATH}")

    try:
        with _LIBRARY_PATH.open("r", encoding="utf-8") as fp:
            raw = yaml.safe_load(fp)
    except yaml.YAMLError as e:
        raise QuestionLibraryError(f"library.yaml is not valid YAML: {e}") from e

    if not isinstance(raw, dict) or "questions" not in raw:
        raise QuestionLibraryError("library.yaml must have a top-level 'questions' key")

    questions: dict[str, Question] = {}
    for entry in raw["questions"]:
        try:
            q = _parse_question(entry)
        except KeyError as e:
            raise QuestionLibraryError(
                f"Question {entry.get('id', '?')} missing required field: {e}"
            ) from e
        if q.id in questions:
            raise QuestionLibraryError(f"Duplicate question id: {q.id}")
        questions[q.id] = q

    if not questions:
        raise QuestionLibraryError("library.yaml has no questions")

    return questions


def get_question(question_id: str) -> Question:
    """Look up a question by id. Raises KeyError if missing."""
    lib = load_library()
    if question_id not in lib:
        raise KeyError(f"No such question: {question_id}")
    return lib[question_id]


def resolve_question(question_id: str, inline: Optional[dict] = None) -> Question:
    """A question by id, preferring a definition EMBEDDED in the cadence.

    `inline` is `PhaseDef.coding_questions_inline` — full definitions copied
    into the cadence when the admin pulled the question from an authored pool.
    Checking it first is what makes a pooled question work with no change to the
    browser payload, the Pyodide runner or the evaluator: whichever source it
    came from, they all receive the same `Question`.

    Falls back to the built-in library, so every existing cadence — which has no
    inline map at all — resolves exactly as before.
    """
    if inline:
        entry = inline.get(question_id)
        if entry is not None:
            # pydantic model or plain dict, depending on whether the cadence was
            # loaded through the schema or read as raw YAML.
            data = entry if isinstance(entry, dict) else entry.model_dump()
            return _question_from_inline(question_id, data)
    return get_question(question_id)


def _question_from_inline(question_id: str, data: dict[str, Any]) -> Question:
    """Build a Question from an embedded cadence definition."""
    return Question(
        id=question_id,
        title=str(data.get("title") or question_id),
        prompt=str(data.get("prompt") or ""),
        starter_code=str(data.get("starter_code") or ""),
        function_name=str(data.get("function_name") or ""),
        test_cases=[
            {"name": str(tc.get("name") or f"test {i}"),
             "input": str(tc.get("input") or ""),
             "expected": str(tc.get("expected") or "")}
            for i, tc in enumerate(data.get("test_cases") or [], start=1)
        ],
        hints=[str(h) for h in (data.get("hints") or [])],
        difficulty=str(data.get("difficulty") or "easy"),
        topic=list(data.get("topic") or []),
        role_fit=list(data.get("role_fit") or []),
        estimated_time_s=int(data.get("estimated_time_s") or 0),
        _solution=str(data.get("solution") or ""),
    )


def pick_question(
    topic: Optional[str] = None,
    difficulty: Optional[str] = None,
    role_fit: Optional[str] = None,
    exclude_ids: Optional[set] = None,
    rng: Optional[random.Random] = None,
) -> Question:
    """Pick a random question matching the filters.

    Filters are AND-ed. None = no filter on that dim.
    exclude_ids: don't pick anything in this set (use to avoid repeats within a session).

    Raises QuestionLibraryError if no questions match.
    """
    lib = load_library()
    excludes = exclude_ids or set()

    def matches(q: Question) -> bool:
        if q.id in excludes:
            return False
        if topic and topic not in q.topic:
            return False
        if difficulty and q.difficulty != difficulty:
            return False
        if role_fit and role_fit not in q.role_fit:
            return False
        return True

    candidates = [q for q in lib.values() if matches(q)]
    if not candidates:
        raise QuestionLibraryError(
            f"No questions match filters: topic={topic} difficulty={difficulty} role_fit={role_fit}"
        )

    rng = rng or random.Random()
    return rng.choice(candidates)


# ---- internal helpers -------------------------------------------------------


def _parse_question(entry: dict[str, Any]) -> Question:
    """Parse a single YAML entry into a Question dataclass."""
    return Question(
        id=str(entry["id"]),
        title=str(entry["title"]),
        prompt=str(entry["prompt"]),
        starter_code=str(entry["starter_code"]),
        function_name=str(entry["function_name"]),
        test_cases=list(entry.get("test_cases", [])),
        hints=list(entry.get("hints", [])),
        difficulty=str(entry.get("difficulty", "easy")),
        topic=list(entry.get("topic", [])),
        role_fit=list(entry.get("role_fit", [])),
        estimated_time_s=int(entry.get("estimated_time_s") or 0),
        _solution=str(entry.get("solution", "")),
    )
