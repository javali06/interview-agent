# Coding Module — Roadmap

This file tracks deferred work for the `coding/` feature. The initial vertical
slice ships with: phase state machine, Pyodide browser execution, Monaco editor,
3 starter questions, director gating, WS plumbing, feature flag.

**Everything below is intentionally NOT in the first slice** but MUST be picked
up later. Each item has scope + acceptance criteria so a future engineer (or
future Claude session) can implement without re-deriving the design.

---

## 1. LLM-judge rubric for code quality

**Why:** Test pass/fail is binary. We want graduated signal on candidate skill.

**Scope:**
- Add `coding_quality` scoring to `admin/evaluation_service.py`
- LLM-judge prompt scores 4 sub-dimensions, each 0–10:
  - **Correctness** — does it handle the test cases + obvious edge cases?
  - **Readability** — naming, structure, length appropriate for the problem
  - **Idiomatic Python** — uses list comprehensions, dict ops, `enumerate`, etc. vs C-style loops
  - **Edge-case awareness** — empty input, single element, negatives, etc.
- Each score has 1-2 sentence rationale string
- Composite score weighted into overall interview score (weight TBD with TA team)

**Acceptance:**
- Eval JSON for a session with coding phase contains `coding_quality: {correctness:N, readability:N, idiomatic:N, edge_cases:N, rationale:"..."}`
- Tested with 3 known-good and 3 known-bad code submissions
- LLM prompt cached so cost stays ~$0.001/eval

**Files to touch:** `admin/evaluation_service.py`, `coding/evaluator.py` (extend), `admin/templates/session_detail.html` (display)

---

## 2. Stuck-detector + hint dispatcher

**Why:** Candidate freezes at the editor with no signal that AI can help. Current behavior is "silent until Submit" which feels cold.

**Scope:**
- New agent or director hook: monitor candidate activity during CODING phase
- Stuck signal: NO keystroke AND NO speech for `STUCK_THRESHOLD_S` (default 90s)
- On stuck: AI says (via TTS) "Want a hint? Just say 'yes' or keep working."
- If candidate says yes → AI reads `hints[hint_level]` from current question
- `hint_level` increments on each subsequent stuck cycle (graduated: nudge → direction → near-answer)
- Question YAML schema already has `hints: [str]` — populate during library expansion (see #4)

**Acceptance:**
- Candidate idle 90s during coding → AI offers hint
- "Yes" → hint[0] delivered via TTS
- Next 90s idle → AI offers hint[1]
- Hint exhaustion (e.g., 3 hints used) → AI does not offer more

**Files to touch:** `coding/stuck_detector.py` (new), `stream_b_new/director.py` (subscribe), `coding/questions/library.yaml` (populate hints)

---

## 3. Anti-cheat (paste detection + focus loss)

**Why:** Pilot is honor-system. For external candidates, we want at least informational signals.

**Scope:**
- Browser-side events posted via WS:
  - Paste >50 chars into editor → `code_paste_detected` event
  - `document.visibilitychange` to hidden → `tab_focus_lost` event (with duration on return)
  - `window.devtools.opened` (heuristic via debugger detection) → `devtools_opened` event
- Server logs to `events.jsonl` and adds to eval context
- NOT blocking — purely informational signal for TA
- Visible in admin session detail with timeline

**Acceptance:**
- `events.jsonl` contains `coding_anti_cheat` events with `reason` + `ts` + `metadata`
- Eval JSON has `anti_cheat_signals: [{reason, ts, severity}]` array
- Admin session detail shows red-flag badge if any signals present

**Files to touch:** `ui/candidate/coding/coding_panel.js` (event capture), `coding/ws_router.py` (handle), `admin/templates/session_detail.html` (display)

**Out of scope:** blocking submission, automated cheating verdict, ML-based detection. Signal only.

---

## 4. Expand question library to 30+

**Why:** 3 questions = candidates discover repeats across interviews.

**Scope:**
- Curated library covering:
  - **Strings** (5+): reverse, palindrome, anagram, substring search, char frequency
  - **Lists** (5+): running sum, max subarray, deduplication, in-place reverse, two-sum
  - **Dicts** (4+): word frequency, group by, two-sum (hash variant), inverted index
  - **Recursion** (3+): factorial, fibonacci, simple tree traversal
  - **Basic algo** (5+): binary search, bubble sort (educational), quicksort outline, BFS sketch
  - **Numpy basics** (3+): array sum, broadcasting, indexing
  - **Edge case-heavy** (5+): handle empty/single/null gracefully
- Each tagged by `difficulty: easy|medium`, `topic: [list,string,...]`, `role_fit: [ai,backend,data]`
- Each with 3+ test cases including 1 edge case
- Each with 2-3 hints (nudge / direction / near-answer)

**Acceptance:**
- 30+ entries in `coding/questions/library.yaml`
- All test cases pass against a reference solution stored alongside (`solution:` field for internal verification, never shipped to candidate)
- `coding/questions/loader.py` filters by `topic + difficulty + role_fit`

**Files to touch:** `coding/questions/library.yaml` (data), `coding/questions/loader.py` (filter API), `tests/test_question_library.py` (new — runs each ref solution against its test cases)

---

## 5. TA-side replay of code typing timeline

**Why:** TA wants to debug "did they paste this in?" or "how did they iterate?"

**Scope:**
- Frontend debounces `code_edit` events to WS every 500ms (already in the slice as a future hook — wire it up)
- Server appends to `events.jsonl` with `kind: code_edit_snapshot, code: <full>, ts: <ms>`
- Admin `session_detail.html` gets new "Code Replay" tab
- Tab UI: scrubber timeline showing code state at each snapshot, like a video
- Bonus: highlight diffs between adjacent snapshots

**Acceptance:**
- During interview, code edits get snapshotted every 500ms
- TA opens session detail → "Code Replay" tab → can scrub through coding session
- Diff view between any two snapshots

**Files to touch:** `ui/candidate/coding/editor_wrapper.js` (debounce), `coding/ws_router.py` (persist), `admin/templates/session_detail.html` (new tab), `admin/static/code_replay.js` (new)

**Privacy note:** Document this in candidate consent — they're being recorded keystroke-by-keystroke during coding.

---

## 6. Cadence LLM auto-emits coding phases

**Why:** First slice ships with manual YAML edit to include coding phase. Want it automatic based on JD.

**Scope:**
- Update `admin/cadence_service.py` system prompt:
  - Teach LLM about `coding` phase type
  - Heuristic: if JD mentions Python, coding, programming, software engineering → insert 1-2 coding phases
  - LLM picks question by calling `coding.questions.loader.pick(role_fit=..., difficulty=..., topic=...)` (via tool call OR by referencing library IDs)
  - Place coding phase after warm_up + technical conversation, before behavioral
- Cadence review UI lets TA see + edit the picked question before approval

**Acceptance:**
- TA uploads "Senior AI Engineer" JD → generated cadence includes 1 medium-difficulty coding phase with AI-relevant question
- TA uploads "Junior Backend Dev" JD → generated cadence includes 2 easy-difficulty coding phases
- Non-coding JDs (e.g., "Customer Success Manager") → no coding phases

**Files to touch:** `admin/cadence_service.py` (prompt + tool def), `coding/questions/loader.py` (pick function), `admin/templates/cadence_review.html` (display picked Q)

---

## Tracking

These also live as deferred tasks in the session task list (#47–52 as of slice
landing). If the task list rolls over to a new session, this file is the source
of truth. Update this file as items are completed; don't delete entries (move
to "Completed" section below).

## Completed

- **#1 LLM-judge rubric for code quality** — `coding.evaluate_submission(use_llm_judge=True, question_prompt=...)` now calls the configured slow LLM with a rubric prompt, returns correctness/readability/idiomatic/edge_cases (0-10) + rationale. Self-configuring via SLOW_PROVIDER/SLOW_MODEL env vars; falls back to deterministic-only if no API key. ~$0.002/submission.
- **#2 Hint dispatcher (voice + text)** — `coding/launcher.py` per-session hint state tracks per-phase level. On `coding_hint_request`: emits `coding_hint_delivered` bus event (browser shows text in `.coding-hint-display` banner) AND calls `session._tts.speak_chunk()` so AI voices the hint via TTS (same pattern as filler agent). Hint level graceful-exhausts with a "use Talk to AI" fallback message.
- **#3 Anti-cheat signals** — paste detection (`onDidPaste` in editor_wrapper) + tab visibility loss (`document.visibilitychange`) in `ui/candidate/coding/coding_panel.js`. Sent via `coding_anti_cheat` WS messages. Launcher persists to bus → events.jsonl. `coding.extract_anti_cheat_signals(jsonl_path, phase_id)` + `coding.summarize_anti_cheat(signals)` helpers for admin/eval consumption. _Admin UI rendering of signals is deferred — events.jsonl is the source._
- **#4 Question library expanded to 23** — `coding/questions/library.yaml`. Coverage: 6 strings, 7 lists, 4 dicts, 3 recursion, 8 algo, 3 numpy. 16 easy + 7 medium. Tagged by role_fit (ai/backend/data/generalist). `coding.pick_question(topic=, difficulty=, role_fit=)` filters work. _Target was 30+; quality and topic-coverage hit, can append more in a follow-up if pilot exposes gaps._
- **#6 Cadence-LLM auto-emits coding phases** — `stream_b_new/cadence/loader.py` `_SYSTEM_PROMPT` extended with CODING PHASES section. Teaches the LLM about `coding_question_id` + `coding_time_budget_s` fields, lists the 21 available question ids grouped by difficulty/topic, and gives a role→question heuristic. Cadence-gen LLM will now insert a coding phase + code_discussion phase when JD mentions Python / engineering / coding.

## Still pending

- **#5 TA-side replay of code typing timeline** — Frontend already debounces `code_edit` events and ships them to `events.jsonl` via `coding_code_edit` WS messages. Server-side: events land via launcher's coding inbound callback. _What's missing: admin/session_detail.html UI work to render a scrub timeline with diff view between snapshots._ Estimated: ~1.5 days. Hand-off: `admin/templates/session_detail.html`, `admin/static/code_replay.js` (new), `admin/main.py` (new GET `/admin/sessions/{token}/code_events` route).
