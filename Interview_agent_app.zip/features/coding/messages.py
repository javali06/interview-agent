"""WebSocket message types for the coding panel.

Contract between browser (ui/candidate/coding/) and server (coding/ws_router).

All messages have a `type: str` field starting with "coding_" so the WS
dispatcher in deploy/azure_app.py can route them based on prefix without
knowing the details. (Same `type` field convention as existing WS protocol —
see ui/candidate/app.js header.)

JSON shape — keep flat and serializable. dataclasses_asdict() should work
without custom encoders.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


# ---- Message kind constants -------------------------------------------------

# Server → browser
TYPE_PHASE_START = "coding_phase_start"
TYPE_PHASE_END = "coding_phase_end"
TYPE_HINT = "coding_hint"
TYPE_PRELOAD = "coding_preload"  # tell browser to start downloading Pyodide

# Browser → server
TYPE_PRELOAD_READY = "coding_preload_ready"  # Pyodide loaded, ready to receive phase_start
TYPE_CODE_EDIT = "coding_code_edit"
TYPE_CODE_RUN = "coding_code_run"
TYPE_CODE_RUN_RESULT = "coding_code_run_result"
TYPE_CODE_SUBMITTED = "coding_code_submitted"
TYPE_HINT_REQUEST = "coding_hint_request"
TYPE_ANTI_CHEAT = "coding_anti_cheat"


# ---- Server → browser messages ----------------------------------------------


@dataclass
class PhaseStartMsg:
    """Tell browser: enter coding phase, show editor with this question."""

    type: str = TYPE_PHASE_START
    phase_id: str = ""
    question_id: str = ""
    question_prompt: str = ""
    starter_code: str = ""
    test_cases: list[dict[str, Any]] = field(default_factory=list)
    time_budget_s: int = 600
    # test_cases shape: [{name: str, input: str, expected: str}]
    # IMPORTANT: do NOT include `solution:` — that's library-internal only


@dataclass
class PhaseEndMsg:
    """Tell browser: coding phase over, unmount editor."""

    type: str = TYPE_PHASE_END
    phase_id: str = ""
    reason: str = "submitted"  # "submitted" | "time_budget" | "director_force_end"


@dataclass
class HintMsg:
    """Deliver a hint to the browser (also TTS'd by AI, but text shown in UI)."""

    type: str = TYPE_HINT
    phase_id: str = ""
    hint_level: int = 0
    hint_text: str = ""


@dataclass
class PreloadMsg:
    """Tell browser to start preloading Pyodide during warm_up phase."""

    type: str = TYPE_PRELOAD


# ---- Browser → server messages ----------------------------------------------


@dataclass
class PreloadReadyMsg:
    type: str = TYPE_PRELOAD_READY
    load_time_ms: int = 0


@dataclass
class CodeEditMsg:
    type: str = TYPE_CODE_EDIT
    phase_id: str = ""
    code: str = ""
    edit_count: int = 0


@dataclass
class CodeRunMsg:
    type: str = TYPE_CODE_RUN
    phase_id: str = ""
    code: str = ""
    run_count: int = 0


@dataclass
class CodeRunResultMsg:
    type: str = TYPE_CODE_RUN_RESULT
    phase_id: str = ""
    run_count: int = 0
    stdout: str = ""
    stderr: str = ""
    runtime_ms: int = 0
    test_results: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class CodeSubmittedMsg:
    type: str = TYPE_CODE_SUBMITTED
    phase_id: str = ""
    final_code: str = ""
    final_test_results: list[dict[str, Any]] = field(default_factory=list)
    runs_used: int = 0


@dataclass
class HintRequestMsg:
    type: str = TYPE_HINT_REQUEST
    phase_id: str = ""


@dataclass
class AntiCheatMsg:
    type: str = TYPE_ANTI_CHEAT
    phase_id: str = ""
    reason: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


# ---- Codec helpers ----------------------------------------------------------


def encode(msg: Any) -> dict[str, Any]:
    """Serialize a message dataclass to a JSON-safe dict."""
    return asdict(msg)


def is_coding_message(payload: dict[str, Any]) -> bool:
    """True if this is a coding-namespaced WS message (type starts with 'coding_')."""
    t = payload.get("type", "")
    return isinstance(t, str) and t.startswith("coding_")
