"""Code quality evaluator with LLM-judge rubric.

Pure-deterministic baseline: pass_rate from test_results.
LLM-judged dimensions: correctness, readability, idiomatic, edge_cases (0–10
each) with a rationale string.

The LLM call is best-effort — if no API key / call fails, falls back to
deterministic-only scoring (the LLM fields stay None). admin/evaluation_service
should treat None as "not LLM-scored" and exclude from composite.

API key resolution mirrors admin/cadence_service._resolve_llm:
  1. SLOW_PROVIDER=openrouter + SLOW_MODEL → OpenRouter (strips :variant suffix)
  2. SLOW_PROVIDER=groq + SLOW_MODEL → Groq
  3. Legacy fallback: Groq w/ GROQ_API_KEY, else OpenRouter

Cost: one ~600-token prompt + ~200-token response ≈ $0.002 per submission
on the production model (openai/gpt-oss-120b).
"""
from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass
from typing import Any, Optional

logger = logging.getLogger(__name__)


@dataclass
class CodingScore:
    """Per-question score for a coding submission."""

    question_id: str
    pass_rate: float  # fraction of test cases passed, 0.0–1.0
    correctness: Optional[int] = None  # 0–10 (None = not LLM-scored yet)
    readability: Optional[int] = None  # 0–10
    idiomatic: Optional[int] = None  # 0–10
    edge_cases: Optional[int] = None  # 0–10
    rationale: str = ""  # LLM-generated narrative; empty when not scored
    runs_used: int = 0
    time_to_submit_s: float = 0.0
    hints_used: int = 0
    anti_cheat_signals: Optional[list] = None


def evaluate_submission(
    *,
    question_id: str,
    final_code: str,
    test_results: list,
    runs_used: int = 0,
    time_to_submit_s: float = 0.0,
    hints_used: int = 0,
    anti_cheat_signals: Optional[list] = None,
    use_llm_judge: bool = True,
    question_prompt: str = "",
) -> CodingScore:
    """Evaluate a single coding submission.

    Deterministic component: pass_rate from test_results (always set).
    LLM-judged component: correctness/readability/idiomatic/edge_cases (0–10
    each) + rationale. Only fills if `use_llm_judge=True` and an LLM API key
    is configured. On any LLM failure, returns deterministic-only — the
    LLM fields stay None.

    question_prompt is the question text — needed by the LLM-judge for
    fair scoring. Caller should pass it from coding.get_question(qid).prompt.

    The signature is the stable contract — admin/evaluation_service.py
    calls this. Don't change it without a coordinated migration.
    """
    total = len(test_results)
    if total == 0:
        pass_rate = 0.0
    else:
        passed = sum(1 for r in test_results if r.get("passed"))
        pass_rate = passed / total

    score = CodingScore(
        question_id=question_id,
        pass_rate=pass_rate,
        runs_used=runs_used,
        time_to_submit_s=time_to_submit_s,
        hints_used=hints_used,
        anti_cheat_signals=anti_cheat_signals,
    )

    if use_llm_judge and final_code.strip():
        try:
            llm_scores = _llm_judge(
                question_id=question_id,
                question_prompt=question_prompt,
                final_code=final_code,
                pass_rate=pass_rate,
                test_results=test_results,
            )
            if llm_scores:
                score.correctness = llm_scores.get("correctness")
                score.readability = llm_scores.get("readability")
                score.idiomatic = llm_scores.get("idiomatic")
                score.edge_cases = llm_scores.get("edge_cases")
                score.rationale = llm_scores.get("rationale", "")
        except Exception as e:
            logger.warning("[coding.eval] LLM-judge failed (returning deterministic only): %s", e)

    return score


# ─── LLM judge ───────────────────────────────────────────────────────────────


_JUDGE_SYSTEM_PROMPT = """\
You are a senior Python interviewer scoring a candidate's code submission.

For each of four dimensions, return an integer 0-10:
- correctness: handles the prompt's intent + obvious edge cases (empty/single/none)
- readability: naming, structure, length appropriate to the problem
- idiomatic: pythonic constructs (comprehensions, dict.get, enumerate, slicing) vs C-style
- edge_cases: shows awareness of edge cases (empty input, single element, negatives, etc.)

Output ONLY a JSON object — no prose, no markdown fences. Schema:
{
  "correctness": 0-10,
  "readability": 0-10,
  "idiomatic": 0-10,
  "edge_cases": 0-10,
  "rationale": "2-3 sentences summarising the strengths and weaknesses"
}
"""


def _resolve_llm() -> Optional[tuple[str, str, str]]:
    """Returns (api_key, base_url, model) or None if no keys configured.

    Mirrors admin/cadence_service._resolve_llm priority order.
    """
    slow_provider = (os.environ.get("SLOW_PROVIDER") or "").strip().lower()
    slow_model = (os.environ.get("SLOW_MODEL") or "").strip()

    if slow_provider == "openrouter" and slow_model:
        key = (os.environ.get("OPENROUTER_API_KEY") or "").strip()
        if key:
            # Strip variant suffix (e.g. :nitro) for one-shot batch calls
            return (key, "https://openrouter.ai/api/v1", slow_model.split(":", 1)[0])

    if slow_provider == "groq" and slow_model:
        key = (os.environ.get("GROQ_API_KEY") or "").strip()
        if key:
            return (key, "https://api.groq.com/openai/v1", slow_model)

    # Legacy fallback
    groq_key = (os.environ.get("GROQ_API_KEY") or "").strip()
    if groq_key:
        return (groq_key, "https://api.groq.com/openai/v1", "openai/gpt-oss-120b")
    or_key = (os.environ.get("OPENROUTER_API_KEY") or "").strip()
    if or_key:
        return (or_key, "https://openrouter.ai/api/v1", "deepseek/deepseek-v3.2-exp")
    return None


def _llm_judge(
    *,
    question_id: str,
    question_prompt: str,
    final_code: str,
    pass_rate: float,
    test_results: list,
) -> Optional[dict[str, Any]]:
    """Call the slow LLM with a rubric prompt. Returns dict or None on failure."""
    resolved = _resolve_llm()
    if not resolved:
        logger.info("[coding.eval] no LLM API key configured — skipping judge")
        return None
    api_key, base_url, model = resolved

    try:
        from openai import OpenAI
    except ImportError:
        logger.warning("[coding.eval] openai package not available")
        return None

    # Compact test-result summary for the LLM
    test_summary = [
        f"{'PASS' if r.get('passed') else 'FAIL'} {r.get('name', '?')}: "
        f"got={r.get('actual', '?')} expected={r.get('expected', '?')}"
        + (f" err={r.get('error', '')}" if r.get('error') else '')
        for r in (test_results or [])
    ]

    user_msg = f"""Question id: {question_id}
Question prompt:
{question_prompt}

Candidate's submission:
```python
{final_code}
```

Deterministic test results (pass_rate={pass_rate:.2f}):
{chr(10).join(test_summary) if test_summary else '(no tests ran)'}

Score this submission per the rubric. Return JSON only."""

    client = OpenAI(api_key=api_key, base_url=base_url, timeout=30.0)
    try:
        resp = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": _JUDGE_SYSTEM_PROMPT},
                {"role": "user", "content": user_msg},
            ],
            temperature=0.1,
            max_tokens=400,
        )
    except Exception as e:
        logger.warning("[coding.eval] LLM call failed: %s", e)
        return None

    content = (resp.choices[0].message.content or "").strip()
    if not content:
        return None

    # Tolerate ```json fences if the model adds them despite the instruction
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", content, re.DOTALL)
    raw_json = m.group(1) if m else content

    try:
        parsed = json.loads(raw_json)
    except json.JSONDecodeError as e:
        logger.warning("[coding.eval] LLM returned non-JSON: %s (content=%r)", e, content[:200])
        return None

    # Validate + clamp 0-10
    out: dict[str, Any] = {}
    for dim in ("correctness", "readability", "idiomatic", "edge_cases"):
        v = parsed.get(dim)
        if isinstance(v, (int, float)):
            out[dim] = max(0, min(10, int(round(v))))
    out["rationale"] = str(parsed.get("rationale", "")).strip()
    return out


# ─── Anti-cheat helpers ──────────────────────────────────────────────────────


def extract_anti_cheat_signals(
    events_jsonl_path: str,
    phase_id: Optional[str] = None,
) -> list[dict[str, Any]]:
    """Scan the session's events.jsonl for `coding_anti_cheat` events.

    Returns a list of {ts, reason, metadata} dicts, optionally filtered to
    one phase. admin/evaluation_service.py should call this and pass the
    result into evaluate_submission(anti_cheat_signals=...).

    Signals captured by the browser today:
      - reason="paste"            metadata={pasted_text_length: int}
      - reason="tab_focus_lost"   metadata={duration_ms: int}

    `paste` >50 chars is the candidate-pasted-from-elsewhere signal.
    `tab_focus_lost` is informational; long durations suggest off-screen
    consultation. No automated verdict — just signals for the TA to review.
    """
    signals: list[dict[str, Any]] = []
    try:
        with open(events_jsonl_path, "r", encoding="utf-8") as fp:
            for line in fp:
                line = line.strip()
                if not line:
                    continue
                try:
                    evt = json.loads(line)
                except json.JSONDecodeError:
                    continue
                kind = evt.get("kind") or ""
                if kind != "coding_anti_cheat":
                    continue
                p = evt.get("payload") or {}
                if phase_id is not None and p.get("phase_id") != phase_id:
                    continue
                signals.append({
                    "ts": evt.get("ts"),
                    "reason": p.get("reason", "unknown"),
                    "metadata": p.get("metadata", {}),
                })
    except FileNotFoundError:
        return []
    except Exception as e:
        logger.warning("[coding.eval] failed reading anti-cheat from %s: %s",
                       events_jsonl_path, e)
        return []
    return signals


def summarize_anti_cheat(signals: list[dict[str, Any]]) -> dict[str, Any]:
    """Compact summary of anti-cheat signals for eval JSON output.

    Returns: {paste_count, large_paste_count, focus_lost_count, total_focus_lost_ms}
    """
    paste_count = 0
    large_paste_count = 0  # > 50 chars
    focus_lost_count = 0
    total_focus_lost_ms = 0
    for s in signals:
        if s.get("reason") == "paste":
            paste_count += 1
            md = s.get("metadata") or {}
            if isinstance(md.get("pasted_text_length"), int) and md["pasted_text_length"] > 50:
                large_paste_count += 1
        elif s.get("reason") == "tab_focus_lost":
            focus_lost_count += 1
            md = s.get("metadata") or {}
            if isinstance(md.get("duration_ms"), int):
                total_focus_lost_ms += md["duration_ms"]
    return {
        "paste_count": paste_count,
        "large_paste_count": large_paste_count,
        "focus_lost_count": focus_lost_count,
        "total_focus_lost_ms": total_focus_lost_ms,
    }
