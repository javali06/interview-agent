# Coding Module

Browser-side Python execution + Monaco editor for coding phases in interviews.

**Status:** Initial vertical slice. See `ROADMAP.md` for deferred work.

---

## Why a separate module

Mirrors the `admin/` pattern: self-contained, owns its data model + state +
event surface. Integration points with the rest of the system are intentionally
few and well-defined (see "Integration Points" below). Swap-out goal: replacing
Pyodide with a server sandbox or hosted execution API should touch
`pyodide_worker.js` + maybe `ws_router.py` only, leaving everything else stable.

---

## What it does

1. Cadence YAML can declare a `coding` phase with a Python question
2. When director enters that phase, browser shows a Monaco editor + Run button
3. Code executes in browser via Pyodide (WASM Python) — zero server-side exec
4. Test cases run against candidate's function → pass/fail surfaced to AI
5. Submit → director advances to next phase; AI gets the code + results in context

---

## Public API (what other modules import)

```python
from coding import (
    CodingPhase,          # dataclass — phase state + lifecycle
    load_question_library, # loads + validates questions YAML
    pick_question,         # filter API: topic/difficulty/role_fit
    handle_ws_message,     # entry point for inbound WS messages
    is_enabled,            # feature flag check (CODING_ENABLED env var)
)

from coding.events import (
    CODING_PHASE_STARTED,
    CODING_PHASE_ENDED,
    CODING_CODE_EDIT,
    CODING_CODE_RUN,
    CODING_CODE_SUBMITTED,
    CODING_HINT_REQUESTED,
)

from coding.messages import (
    # Server → browser
    PhaseStartMsg,
    PhaseEndMsg,
    HintMsg,
    # Browser → server
    CodeEditMsg,
    CodeRunMsg,
    CodeRunResultMsg,
    CodeSubmittedMsg,
    HintRequestMsg,
)
```

Everything else in `coding/` is module-private.

---

## Integration points

| File | What it does | Why minimal |
|---|---|---|
| `admin/cadence_service.py` | Validates `coding` phase type in cadence YAML | Cadence engine doesn't need to know HOW coding works |
| `stream_b_new/director.py` | Activity state `CODING` gates silence/filler/apology agents | Director only cares about candidate activity, not editor internals |
| `stream_b_new/runtime/interview_session.py` | Subscribes coding events to event bus | Events flow through the existing bus |
| `deploy/azure_app.py` | Routes coding-kind WS messages to `coding.handle_ws_message()` | Single WS endpoint — coding is a message kind, not a new socket |
| `ui/candidate/app.js` | On `phase_start` of type coding, lazy-imports `coding/coding_panel.js` | Frontend coding code is loaded ONLY when needed |
| `admin/evaluation_service.py` | Reads coding submissions from event log into eval context | Eval is just another consumer of events.jsonl |

If you find yourself adding a 7th integration point — pause and consider whether
the abstraction is leaking.

---

## Feature flag

`CODING_ENABLED=1` env var (off by default). When off:
- Cadence schema rejects `coding` phase type
- WS router ignores coding messages
- Frontend never lazy-imports the coding panel
- Existing interview flows are 100% unchanged

---

## Files

```
coding/
├── README.md                ← you are here
├── ROADMAP.md               ← deferred work (don't forget!)
├── __init__.py              ← public API exports
├── phase.py                 ← CodingPhase dataclass + state
├── events.py                ← bus event kinds
├── messages.py              ← WS message dataclasses + codec
├── ws_router.py             ← inbound WS message handler (pure)
├── evaluator.py             ← code quality scoring (stub for now)
├── feature_flag.py          ← is_enabled() helper
└── questions/
    ├── __init__.py
    ├── loader.py            ← YAML loader + filter API
    └── library.yaml         ← vetted question library

ui/candidate/coding/
├── coding_panel.html        ← layout fragment
├── coding_panel.css         ← styles
├── coding_panel.js          ← UI coordinator
├── editor_wrapper.js        ← Monaco wrapper
└── pyodide_worker.js        ← WebWorker for Python execution
```

---

## How a coding phase plays out

```
1. Cadence YAML declares:
   - id: coding_q1
     type: coding
     duration_s: 600
     question_id: running_sum

2. Director enters phase → emits CODING_PHASE_STARTED with question payload
3. Server forwards PhaseStartMsg over WS to browser
4. Browser lazy-imports coding_panel.js
5. Panel loads Pyodide (preloaded during warm_up — cache hit)
6. Panel mounts Monaco editor with starter_code
7. AI speaks the question via TTS (existing TTS pipeline)
8. Director sets candidate activity = CODING → gates speech-related agents

9. Candidate types → optional code_edit events to server (deferred — see ROADMAP)
10. Candidate clicks Run → pyodide_worker executes code + test cases →
    posts CodeRunResultMsg to server
11. Candidate clicks Submit → CodeSubmittedMsg to server → director sees
    CODING_CODE_SUBMITTED bus event → advances to next phase
12. Panel unmounts, existing audio/chat UI returns
13. Next phase: AI discusses the code with candidate (regular conversation phase)
14. Eval at session end reads code + test results from events.jsonl
```

---

## Testing locally

```bash
# Enable the feature
export CODING_ENABLED=1

# Run with a cadence that includes a coding phase
# (until ROADMAP item #6 lands, you must hand-edit the cadence YAML)
./run_app.sh

# Open candidate URL, run through interview
```

---

## Security notes

- **Pyodide runs in browser sandbox** — no server-side execution risk
- **Question library is hard-coded YAML** — no user input flows into code execution
- **Code submissions are stored in events.jsonl** — same persistence as transcripts
- **No filesystem/network access from Pyodide** — by default, Pyodide can't
  reach the host filesystem or make network calls. We don't enable those.

---

## When to swap Pyodide for something else

Pyodide is the right call for "1-2 simple Python questions in an interview."
Reasons to revisit:

- **Need ML libs** (torch, TF, sklearn beyond basic) — Pyodide doesn't support these well
- **Need 4+ GB memory** — browser memory cap is a wall
- **Anti-cheat hardening** — server execution gives you exact runtime metrics + no client manipulation
- **Multi-language support** — Pyodide is Python-only; Piston supports 60+ languages

The swap-out path: replace `pyodide_worker.js` with a WS-based client that
sends code to a server endpoint, which proxies to (e.g.) Piston API. Everything
else — phase state, events, messages, panel UI, director gating — stays.
