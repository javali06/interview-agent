# Coding Module — Integration Guide

This file is for the engineer who picks up the remaining 2 integration points
that the initial vertical slice did NOT land. Once these two are done, the
feature works end-to-end (gated by `CODING_ENABLED=1`).

**Two remaining hooks. Both are surgical — small additions, no rewrites.**

---

## What's already integrated

| Component | File(s) | Status |
|---|---|---|
| Python module (`coding/`) | 11 files | ✅ done, imports cleanly |
| Frontend module (`ui/candidate/coding/`) | 5 files | ✅ done |
| Cadence schema accepts `coding_question_id` | `stream_b_new/cadence/schema.py` | ✅ done |
| Candidate UI listens for `coding_phase_start` etc. | `ui/candidate/app.js` | ✅ done |
| Feature flag (`CODING_ENABLED`) | `coding/feature_flag.py` | ✅ done |
| `AIActivityState.CODING` enum value | `stream_b_new/contracts/session_state.py` | ✅ done |
| WS broadcaster: inbound dispatch + outbound emit | `orchestrator_new/web/broadcaster.py` | ✅ done |
| Launcher: bus subscribe + inbound callback wiring | `orchestrator_new/web/launcher.py` | ✅ done |
| Director: phase-entry hook → emit `coding_phase_started` | `stream_b_new/core/director.py` | ✅ done |
| Standalone demo page (no backend) | `ui/candidate/coding/demo.html` | ✅ done |
| Example cadence YAML with coding phase | `coding/example_cadence.yaml` | ✅ done |

---

## What's left (do these for full auto-advance — currently candidate voice-advances)

**Important context:** The slice as it stands DOES work end-to-end with one
caveat — the phase does NOT auto-advance when the candidate clicks Submit.
The candidate's `Submit` click sends a WS message, the launcher publishes it
to the session bus, the event log captures it. But the director has no
handler to ACT on it. To advance the phase today, the candidate needs to
voice-say "I'm done" / "next" / "let's move on" and the existing
`phase_override` agent advances the phase.

The 3 hooks below complete the auto-advance + agent gating.

---

### A. Server-side WS message dispatch — `deploy/azure_app.py`

**Goal:** Route inbound coding messages from the browser to `coding.handle_ws_message()`,
and ensure outbound coding bus events get forwarded as WS messages to the browser.

**Where to add the inbound hook:**

`deploy/azure_app.py` hands the WS off to `WebBroadcaster.handle_client_via_adapter()`
(line ~647). That class lives in `orchestrator_new/web/broadcaster.py` and is where the
existing JSON message dispatch happens server-side. Either:

1. **Preferred (least invasive):** Add a per-session `MessageInterceptor` hook to the
   broadcaster — a callable that gets first crack at every inbound JSON. The interceptor
   calls `coding.is_coding_message(payload)` and dispatches if true.

2. **Alternative:** Add a coding-aware dispatcher directly inside `WebBroadcaster`'s
   message loop, guarded by `coding.is_enabled()` so non-coding deploys are unaffected.

```python
# Pseudocode for the interceptor (in deploy/azure_app.py, around the
# candidate_ws function where the broadcaster is set up):

from coding import handle_ws_message, is_enabled as coding_is_enabled
from coding.messages import is_coding_message

def _make_coding_interceptor(session_state):
    """Returns a function the broadcaster calls before its own dispatch."""
    if not coding_is_enabled():
        return lambda payload: False  # no-op; broadcaster proceeds

    def intercept(payload: dict) -> bool:
        if not is_coding_message(payload):
            return False  # not for us; broadcaster handles
        result = handle_ws_message(
            payload,
            get_current_phase=lambda: session_state.get("current_coding_phase"),
        )
        if result is None:
            return True  # consumed but no event
        # Emit to bus — same mechanism the rest of the system uses
        if result.bus_event_kind and not result.log_only:
            session_state["event_bus"].publish(
                result.bus_event_kind, result.bus_event_payload
            )
        if result.log_only and result.bus_event_kind:
            # Persist to events.jsonl without firing director consumers
            session_state["event_log"].write(
                {"kind": result.bus_event_kind, "payload": result.bus_event_payload}
            )
        return True  # message consumed; broadcaster skips its own handling

    return intercept
```

**Where to add the outbound hook:**

The bus emits `CODING_PHASE_STARTED` when the director enters a coding phase
(see hook B below). We need to forward it as a `coding_phase_start` WS message.

In `WebBroadcaster._subscribe_to_bus` (or wherever bus events get forwarded to
the WS clients today — likely `_wire_bus_to_broadcaster` at `azure_app.py:929`),
add:

```python
async def _on_coding_phase_started(payload):
    msg = {
        "type": "coding_phase_start",
        "phase_id": payload.phase_id,
        "question_id": payload.question_id,
        "question_prompt": payload.question_prompt,
        "starter_code": payload.starter_code,
        "test_cases": payload.test_cases,  # safe projection only
        "function_name": payload.function_name,
        "time_budget_s": payload.time_budget_s,
    }
    await broadcaster.send_json(msg)  # however broadcaster sends WS JSON

bus.subscribe("coding_phase_started", _on_coding_phase_started)
# Similar for "coding_phase_ended" → coding_phase_end
# Similar for "coding_hint_delivered" → coding_hint
```

**Estimated effort:** half a day. Read `orchestrator_new/web/broadcaster.py`,
identify the existing JSON dispatch pattern, add the interceptor + the outbound
forwarder for the 3 server→browser events.

---

**Note:** for local dev the launcher already does inbound dispatch correctly.
The above is for the CLOUD deploy path (`deploy/azure_app.py`) which uses a
separate WS handler — when ready to ship cloud, mirror the same callback
wiring there.

---

### B. Director auto-advance + agent gating — `stream_b_new/core/director.py`

**Goal:** When entering a coding phase, gate the agents that pester the candidate
(silence prompter, filler, apology) and watch for the `coding_code_submitted`
bus event to advance.

**What to read first:**

- `stream_b_new/director.py` — find the activity-state enum (likely something like
  `CandidateActivity` or in the bus state), the agents that get ticked per-loop, and
  the phase-advance logic
- `stream_b_new/runtime/interview_session.py:262-340` — the section that creates
  per-agent runtimes; coding phase needs a `CodingPhase` object instantiated and
  stored where the WS router can reach it via the session_state interceptor

**Concrete changes:**

1. **Detect coding phase on entry.** Where the director checks `phase.id` /
   `phase.question_mode` on `phase_enter`, add a branch:
   ```python
   if phase.coding_question_id is not None:
       q = coding.get_question(phase.coding_question_id)
       coding_phase = coding.CodingPhase(
           phase_id=phase.id,
           question_id=q.id,
           question_prompt=q.prompt,
           starter_code=q.starter_code,
           test_cases=[coding.TestCase(**tc) for tc in q.test_cases],
           time_budget_s=phase.coding_time_budget_s or phase.duration_s,
           function_name=q.function_name,
           hints=q.hints,
       )
       coding_phase.begin()
       session_state["current_coding_phase"] = coding_phase
       # Emit the bus event so the broadcaster forwards to browser
       bus.publish("coding_phase_started", coding.events.CodingPhaseStartedEvent(
           phase_id=phase.id, question_id=q.id, question_prompt=q.prompt,
           starter_code=q.starter_code,
           test_case_count=len(q.test_cases), time_budget_s=coding_phase.time_budget_s,
       ))
       session_state["activity"] = "CODING"
   ```

2. **Gate the speech-prompting agents.** Wherever silence_prompter / filler /
   apology agents are ticked, add:
   ```python
   if session_state.get("activity") == "CODING":
       continue  # candidate is typing, not silent
   ```

3. **Listen for `coding_code_submitted`.** Subscribe a handler on the bus:
   ```python
   async def _on_code_submitted(payload):
       # Advance the phase tracker
       await tracker.force_advance(reason="coding_submitted")
       session_state["activity"] = "TALKING"  # back to normal
       session_state["current_coding_phase"].end("submitted")
       session_state["current_coding_phase"] = None
       bus.publish("coding_phase_ended", ...)
   ```

4. **Verifier integration (optional).** If the verifier agent should NOT run during
   coding (it watches STT_FINAL events that aren't relevant), gate it the same way
   as #2.

**Concrete remaining changes (precise):**

1. **Subscribe to `coding_code_submitted` bus event** (director constructor or
   wherever session._bus subscriptions happen). Handler sets pending_phase to
   the next phase via `self._tracker.plan.next_phase_id(state.phase)`:
   ```python
   # In InterviewSession._setup_director or similar, after director created:
   async def _on_coding_submitted(evt):
       payload = evt.payload or {}
       next_id = director._tracker.plan.next_phase_id(state.phase)
       if next_id:
           async def _set_pending(s):
               s.pending_phase = next_id
               s.ai_activity = AIActivityState.AUDIO_DONE  # unlock apply gate
           await director._store.mutate(_set_pending)
   session._bus.subscribe(lambda e: _on_coding_submitted(e) if e.kind == "coding_code_submitted" else None)
   ```

2. **Gate filler/apology agents** in `stream_b_new/core/latency/orchestrator.py:257-272`:
   ```python
   if trigger == "endpoint":
       # ADD: skip during coding phase
       if state.ai_activity == AIActivityState.CODING:
           return  # candidate is typing, not silent
       ...existing filler/apology code...
   ```

3. **Gate verifier agent** in `director.py` `_run_post_stt_agents` (around line 599-622):
   ```python
   tasks: list = []
   if self._verifier_agent is not None:
       # ADD: skip during coding — verifier watches STT_FINAL which is noise
       if state.ai_activity != AIActivityState.CODING:
           tasks.append(("verifier", self._verifier_agent.verify(ctx)))
   # phase_override stays — candidate can still say "stop" / "next" verbally
   if self._phase_override_agent is not None:
       tasks.append(("override", self._phase_override_agent.decide(...)))
   ```

4. **Restore ai_activity on phase exit** — when phase advances OUT of a coding
   phase, set `ai_activity = AIActivityState.IDLE` so subsequent agents work
   normally. Add to the phase-transition code in director.py after the existing
   coding-entry hook:
   ```python
   # If LEAVING a coding phase:
   try:
       prev = self._tracker.plan.get_phase(from_p)
       if prev and getattr(prev, "coding_question_id", None):
           async def _reset(s):
               s.ai_activity = AIActivityState.IDLE
           await self._store.mutate(_reset)
   except Exception:
       pass
   ```

**Estimated effort:** 1 day, careful. Director is fragile (wrap_up termination
bug lives here). Run baseline interview with `CODING_ENABLED=0` first to prove
no regression, then `=1` with `coding/example_cadence.yaml`.

---

## Test cadence YAML for the smoke test

Once both hooks land, create `/tmp/test_cadence_coding.yaml`:

```yaml
version: 1
phases:
  - id: warm_up
    duration_s: 30
    intent: Greet and confirm candidate readiness.
    question_mode: generic
    generic_prompts:
      - "Welcome the candidate by name and ask how they're doing today."
  - id: coding_q1
    duration_s: 600
    intent: Candidate solves one Python question; AI observes silently.
    question_mode: generic
    generic_prompts:
      - "Brief intro to the coding exercise; then wait for submission."
    coding_question_id: running_sum
    coding_time_budget_s: 600
  - id: code_discussion
    duration_s: 60
    intent: Walk through the candidate's solution and approach.
    question_mode: generic
    generic_prompts:
      - "Ask the candidate to explain their approach and runtime."
  - id: wrap_up
    duration_s: 30
    intent: Thank candidate, close out.
    question_mode: generic
    generic_prompts:
      - "Thank the candidate and tell them we'll be in touch."
```

Then:

```bash
export CODING_ENABLED=1
# Hand-feed the cadence to a fresh session (admin upload won't work until
# ROADMAP item #6 lands — cadence-LLM auto-emitting coding phases)
./run_app.sh
```

Acceptance:
- Browser shows Monaco editor when phase coding_q1 starts
- Pyodide loads (preloaded during warm_up, near-instant)
- Click Run → tests pass/fail visible
- Click Submit → director advances to code_discussion
- AI asks about the approach (regular conversation)
- Session ends; events.jsonl contains coding_code_submitted event

---

## Risks / what to watch for

- **Director changes are fragile** — the wrap_up termination bug from the prior
  audit lives here. Re-test that bug isn't reintroduced.
- **Single-worker invariant** — `current_coding_phase` lives in session state.
  If anyone bumps `WEB_CONCURRENCY > 1`, this will silently break (same risk as
  `_token_sessions`).
- **WS broadcaster dispatch** — the existing JSON message types don't have a
  prefix convention. Coding messages all start with `coding_` so the interceptor
  match is robust, but make sure no other type starts with that prefix.

---

## When done

- Run the smoke test above
- Update `coding/ROADMAP.md` "Completed" section
- Mark tasks #41, #43, #46 as completed (or whatever they're called by then)
- Commit as `feat(coding): wire WS dispatch + director gating — slice end-to-end`
