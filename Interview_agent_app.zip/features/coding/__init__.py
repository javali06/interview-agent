"""Coding module — Python execution + Monaco editor for interview coding phases.

See README.md for architecture overview and ROADMAP.md for deferred work.

Public API:
    is_enabled()             — feature flag check
    CodingPhase              — phase state machine
    load_question_library()  — load + cache library.yaml
    get_question(id)         — by-id lookup
    pick_question(...)       — filtered random pick
    handle_ws_message(...)   — WS message dispatch entry point
    evaluate_submission(...) — code-quality scoring (stub today)

Module-private: everything not listed above.
"""
from features.coding.feature_flag import is_enabled
from features.coding.phase import CodingPhase, CodingPhaseState, TestCase
from features.coding.questions import (
    Question,
    load_library as load_question_library,
    get_question,
    resolve_question,
    pick_question,
)
from features.coding.ws_router import handle_ws_message, HandleResult
from features.coding.evaluator import (
    evaluate_submission,
    CodingScore,
    extract_anti_cheat_signals,
    summarize_anti_cheat,
)

__all__ = [
    "is_enabled",
    "CodingPhase",
    "CodingPhaseState",
    "TestCase",
    "Question",
    "load_question_library",
    "get_question",
    "resolve_question",
    "pick_question",
    "handle_ws_message",
    "HandleResult",
    "evaluate_submission",
    "CodingScore",
    "extract_anti_cheat_signals",
    "summarize_anti_cheat",
]
