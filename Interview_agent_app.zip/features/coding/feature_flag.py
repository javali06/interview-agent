"""Feature flag for the coding module.

Off by default. Set CODING_ENABLED=1 (or true/yes/on) in env to enable.
When off, the coding module is inert — cadence rejects coding phases,
WS router ignores coding messages, frontend never lazy-loads the panel.
"""
from __future__ import annotations

import os


_TRUTHY = {"1", "true", "yes", "on", "enabled"}


def is_enabled() -> bool:
    """Return True if the coding feature is enabled via env."""
    raw = os.environ.get("CODING_ENABLED", "").strip().lower()
    return raw in _TRUTHY
