"""WS message router for the coding module.

Pure handler functions: take an incoming WS payload + session context,
return either:
- a bus event to emit (for director / event log to consume), or
- None (silent / state-only update)

Why pure: testable without FastAPI / websockets. The actual WS send is
done by the caller in deploy/azure_app.py — this module just decides
what to do based on the message.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable, Optional

from features.coding import events as coding_events
from features.coding import messages as coding_msgs
from features.coding.phase import CodingPhase, CodingPhaseState


logger = logging.getLogger(__name__)


@dataclass
class HandleResult:
    """What ws_router decides for an incoming message.

    bus_event_kind: which bus event to emit (None = no event)
    bus_event_payload: payload for the bus event
    log_only: if True, just persist to events.jsonl (no director impact)
    """

    bus_event_kind: Optional[str] = None
    bus_event_payload: Any = None
    log_only: bool = False


# Type alias for the session-side accessor — caller supplies a function
# that returns the active CodingPhase for the session (or None).
GetCurrentPhase = Callable[[], Optional[CodingPhase]]


def handle_ws_message(
    payload: dict[str, Any],
    get_current_phase: GetCurrentPhase,
) -> Optional[HandleResult]:
    """Handle one inbound WS message from the browser.

    Returns a HandleResult (the caller emits the bus event), or None if
    the message is not coding-related / should be silently ignored.
    """
    if not coding_msgs.is_coding_message(payload):
        return None

    msg_type = payload.get("type")

    if msg_type == coding_msgs.TYPE_PRELOAD_READY:
        return _handle_preload_ready(payload)
    if msg_type == coding_msgs.TYPE_CODE_EDIT:
        return _handle_code_edit(payload, get_current_phase)
    if msg_type == coding_msgs.TYPE_CODE_RUN:
        return _handle_code_run(payload, get_current_phase)
    if msg_type == coding_msgs.TYPE_CODE_RUN_RESULT:
        return _handle_code_run_result(payload, get_current_phase)
    if msg_type == coding_msgs.TYPE_CODE_SUBMITTED:
        return _handle_code_submitted(payload, get_current_phase)
    if msg_type == coding_msgs.TYPE_HINT_REQUEST:
        return _handle_hint_request(payload, get_current_phase)
    if msg_type == coding_msgs.TYPE_ANTI_CHEAT:
        return _handle_anti_cheat(payload, get_current_phase)

    logger.warning("coding.ws_router: unknown message type %r", msg_type)
    return None


# ---- Per-kind handlers ------------------------------------------------------


def _handle_preload_ready(payload: dict[str, Any]) -> HandleResult:
    """Browser finished loading Pyodide. Log only — no director impact."""
    load_time_ms = int(payload.get("load_time_ms", 0))
    return HandleResult(
        bus_event_kind="coding_preload_ready",
        bus_event_payload={"load_time_ms": load_time_ms},
        log_only=True,
    )


def _handle_code_edit(
    payload: dict[str, Any], get_current_phase: GetCurrentPhase
) -> Optional[HandleResult]:
    phase = get_current_phase()
    if phase is None or phase.state != CodingPhaseState.ACTIVE:
        return None
    code = str(payload.get("code", ""))
    phase.record_edit(code)
    return HandleResult(
        bus_event_kind=coding_events.CODING_CODE_EDIT,
        bus_event_payload=coding_events.CodingCodeEditEvent(
            phase_id=phase.phase_id,
            code=code,
            edit_count=phase.edits_count,
        ),
        log_only=True,
    )


def _handle_code_run(
    payload: dict[str, Any], get_current_phase: GetCurrentPhase
) -> Optional[HandleResult]:
    phase = get_current_phase()
    if phase is None or phase.state != CodingPhaseState.ACTIVE:
        return None
    code = str(payload.get("code", ""))
    # Note: actual results come back via CODE_RUN_RESULT — this just logs the attempt
    return HandleResult(
        bus_event_kind=coding_events.CODING_CODE_RUN,
        bus_event_payload=coding_events.CodingCodeRunEvent(
            phase_id=phase.phase_id,
            code=code,
            run_count=phase.runs_used + 1,  # will be incremented on result
        ),
        log_only=True,
    )


def _handle_code_run_result(
    payload: dict[str, Any], get_current_phase: GetCurrentPhase
) -> Optional[HandleResult]:
    phase = get_current_phase()
    if phase is None or phase.state != CodingPhaseState.ACTIVE:
        return None

    result = {
        "stdout": str(payload.get("stdout", "")),
        "stderr": str(payload.get("stderr", "")),
        "runtime_ms": int(payload.get("runtime_ms", 0)),
        "test_results": list(payload.get("test_results", [])),
    }
    phase.record_run(payload.get("code", phase.current_code), result)

    return HandleResult(
        bus_event_kind=coding_events.CODING_CODE_RUN_RESULT,
        bus_event_payload=coding_events.CodingCodeRunResultEvent(
            phase_id=phase.phase_id,
            run_count=phase.runs_used,
            stdout=result["stdout"],
            stderr=result["stderr"],
            runtime_ms=result["runtime_ms"],
            test_results=result["test_results"],
        ),
        log_only=True,
    )


def _handle_code_submitted(
    payload: dict[str, Any], get_current_phase: GetCurrentPhase
) -> Optional[HandleResult]:
    """Terminal event — director will see this and advance to next phase."""
    phase = get_current_phase()
    if phase is None or phase.state != CodingPhaseState.ACTIVE:
        return None

    final_code = str(payload.get("final_code", ""))
    final_test_results = list(payload.get("final_test_results", []))
    phase.submit(final_code, final_test_results)

    return HandleResult(
        bus_event_kind=coding_events.CODING_CODE_SUBMITTED,
        bus_event_payload=coding_events.CodingCodeSubmittedEvent(
            phase_id=phase.phase_id,
            final_code=final_code,
            final_test_results=final_test_results,
            runs_used=phase.runs_used,
            time_to_submit_s=phase.elapsed_s,
        ),
        log_only=False,  # director consumes this
    )


def _handle_hint_request(
    payload: dict[str, Any], get_current_phase: GetCurrentPhase
) -> Optional[HandleResult]:
    """Candidate clicked Hint button. Hint dispatcher (deferred — ROADMAP #2)
    is responsible for actually delivering. We just emit the request."""
    phase = get_current_phase()
    if phase is None or phase.state != CodingPhaseState.ACTIVE:
        return None
    return HandleResult(
        bus_event_kind=coding_events.CODING_HINT_REQUESTED,
        bus_event_payload=coding_events.CodingHintRequestedEvent(
            phase_id=phase.phase_id,
            current_hint_level=phase.hint_level,
        ),
        log_only=False,
    )


def _handle_anti_cheat(
    payload: dict[str, Any], get_current_phase: GetCurrentPhase
) -> Optional[HandleResult]:
    """Anti-cheat signal from browser (ROADMAP #3). Informational only."""
    phase = get_current_phase()
    if phase is None:
        return None
    return HandleResult(
        bus_event_kind=coding_events.CODING_ANTI_CHEAT,
        bus_event_payload=coding_events.CodingAntiCheatEvent(
            phase_id=phase.phase_id,
            reason=str(payload.get("reason", "unknown")),
            metadata=dict(payload.get("metadata", {})),
        ),
        log_only=True,
    )
