# Centific Interview Portal

A voice-driven AI interview agent. An admin schedules a candidate, the system
generates a tailored interview cadence (warm-up → project deep-dive →
challenges → scenario → gen-AI basics → wrap-up), spawns a real-time speech
pipeline, and the candidate has a natural spoken conversation with the AI
through a browser. Logs are captured per-session and rendered with
highlighted phase transitions, barge-ins, and slow/fast LLM turns.

> If you're reading this for the first time and want to **just run it**:
> jump to [Quick start](#quick-start) — five minutes to your first interview.

---

## Table of contents

1. [What this is](#what-this-is)
2. [Architecture at a glance](#architecture-at-a-glance)
3. [End-to-end flow](#end-to-end-flow)
4. [Quick start](#quick-start)
5. [Code layout](#code-layout)
6. [Configuration](#configuration)
7. [Where to make changes](#where-to-make-changes)
8. [Troubleshooting](#troubleshooting)
9. [Advanced — internals & dev paths](#advanced--internals--dev-paths)

---

## What this is

A single-laptop deployment of three cooperating processes that, together,
run live voice interviews:

| Process | Role | Port |
|---|---|---|
| **Admin web app** | FastAPI scheduler UI. Login, schedule, cadence review/edit, session history. | `:8000` |
| **Stream A** | Three local speech services: STT (Whisper-via-Groq), VAD (Silero), TTS (Kokoro). | `:8010` / `:8011` / `:8012` |
| **Orchestrator** *(per interview)* | The "brain": runs the LLM, drives turn-taking, owns the candidate UI. Spawned on admin approve. | `:8090` (static UI) + `:9100` (WS) |

The whole system runs on one machine. Stream A is heavy to boot (~30–60 s
model load on cold start) so it stays warm for the whole work session. A
fresh orchestrator subprocess is spawned per scheduled interview so each
session has its own isolated terminal window with full logs.

---

## Architecture at a glance

```
┌────────────────────────────────────────────────────────────────────────────┐
│                         Operator's laptop                                  │
│                                                                            │
│   ┌──────────────┐         spawns          ┌──────────────────────────┐    │
│   │  Admin app   │ ──────────────────────► │  Orchestrator subproc    │    │
│   │  FastAPI     │  (new terminal window   │  (one per interview)     │    │
│   │  :8000       │   per scheduled         │                          │    │
│   │              │   interview, on admin   │  • Loads cadence YAML    │    │
│   │  • Login     │   approve)              │  • Connects to Stream A  │    │
│   │  • Schedule  │                         │  • Static UI :8090       │    │
│   │  • Cadence   │                         │  • WebSocket :9100       │    │
│   │  • History   │                         │  • Runs InterviewSession │    │
│   └─┬────────────┘                         │    (LLM + policy + TTS)  │    │
│     │  shared SQLite + sessions/<token>/   └──┬──────────────────┬────┘    │
│     │                                         │                  │         │
│     │                              connects to│                  │ serves  │
│     │                                         ▼                  │ UI to   │
│     │                            ┌─────────────────────┐         │         │
│     │                            │   Stream A          │         │         │
│     │                            │   STT :8010         │         │         │
│     │                            │   VAD :8011         │         │         │
│     │                            │   TTS :8012         │         │         │
│     │                            │   (own terminal     │         │         │
│     │                            │    window; boots    │         │         │
│     │                            │    once at startup) │         │         │
│     │                            └─────────────────────┘         │         │
│     │                                                            │         │
└─────┼────────────────────────────────────────────────────────────┼─────────┘
      │                                                            │
      ▼                                                            ▼
  Admin browser                                              Candidate browser
  http://localhost:8000                                      http://localhost:8090
  /admin/login                                               /?token=...&ws=9100
```

### Shared state

```
sessions/
├── sessions.db                      ← SQLite (one row per scheduled session)
└── <token>/                         ← per-interview artifacts
    ├── resume.pdf
    ├── jd.txt                       ← optional
    ├── cadence_requirements.txt     ← optional
    ├── cadence.yaml                 ← approved cadence
    └── events.jsonl                 ← runtime event log (read by admin)
```

Both the admin app and the orchestrator subprocess read/write this same
SQLite DB and shared filesystem. They don't talk to each other directly —
they coordinate through these shared records.

---

## End-to-end flow

The lifecycle of a single interview, from operator-runs-app to
candidate-leaves-call:

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  STEP 1 — Operator types ONE command:                                        │
│             Windows:  .\run_app.bat                                          │
│             macOS:    ./run_app.sh                                           │
│                                                                              │
│  → Boots Stream A in a separate terminal window (STT/VAD/TTS, ~30–60 s)      │
│  → Waits for all 3 /healthz green                                            │
│  → Starts admin server (uvicorn :8000) in THIS terminal                      │
│  → Opens browser to http://localhost:8000/admin/login                        │
│                                                                              │
└─────────────────────────────────┬────────────────────────────────────────────┘
                                  │
                                  ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  STEP 2 — Admin signs in (default: admin / centific123), clicks              │
│           "Schedule interview", fills the form:                              │
│                                                                              │
│             • candidate name, role                                           │
│             • resume (drag-and-drop)                                         │
│             • JD             (optional)                                      │
│             • cadence requirements (optional)                                │
│                                                                              │
│  → POST /admin/schedule:                                                     │
│        files saved to sessions/<token>/                                      │
│        slow LLM generates cadence YAML from (role + JD + resume + req)       │
│        — OR — if no JD and no cadence req text, default.yaml is used         │
│           directly (skip the LLM call, predictable & fast)                   │
│                                                                              │
└─────────────────────────────────┬────────────────────────────────────────────┘
                                  │
                                  ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  STEP 3 — Cadence review page:                                               │
│             • Plain YAML in a textarea                                       │
│             • "Validate" button → pydantic schema check                      │
│             • "Revise with feedback ↻" → admin types feedback, slow LLM      │
│                                            iterates the YAML                 │
│             • "Approve & Generate Link" → final commit                       │
│                                                                              │
│  On approve:                                                                 │
│     • status = 'ready' in SQLite                                             │
│     • cadence.yaml written to sessions/<token>/                              │
│     • app/spawner.py opens a NEW terminal window running:                  │
│         scripts/run_orchestrator.bat --scheduled-token <uuid> --web ...      │
│     • candidate link displayed for admin to copy                             │
│                                                                              │
└─────────────────────────────────┬────────────────────────────────────────────┘
                                  │
                                  ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  STEP 4 — Orchestrator subprocess boots:                                     │
│             • Loads session row from SQLite                                  │
│             • Connects to Stream A (already warm)                            │
│             • Starts WS broadcaster (:9100) + static server (:8090)          │
│             • BLOCKS on the candidate's Start click                          │
│                                                                              │
│  Terminal prints:                                                            │
│     "waiting for candidate → click 'Start Interview' in the browser…"        │
│                                                                              │
└─────────────────────────────────┬────────────────────────────────────────────┘
                                  │
                                  ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  STEP 5 — Admin sends the link to candidate (Slack, email, etc.).            │
│           Candidate opens it:                                                │
│                                                                              │
│             http://localhost:8000/candidate?token=<uuid>                     │
│                                                                              │
│  Admin route /candidate validates the token and 302-redirects to the         │
│  orchestrator's lobby:                                                       │
│                                                                              │
│             http://localhost:8090/?token=<uuid>&ws=9100&name=…&role=…        │
│                                                                              │
└─────────────────────────────────┬────────────────────────────────────────────┘
                                  │
                                  ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  STEP 6 — Candidate lobby:                                                   │
│             • Mic check  (click "Enable" → grants getUserMedia)              │
│             • Speaker check (click "Test" → plays a chime)                   │
│             • Browser detect  (auto)                                         │
│             • Connection probe (auto, opens a WS to :9100)                   │
│             • "Start Interview" button unlocks when all 4 are green          │
│                                                                              │
│  Candidate clicks Start →                                                    │
│     Browser sends {"type":"start"} over WS →                                 │
│     orchestrator's wait_for_candidate() unblocks →                           │
│     InterviewSession instantiates →                                          │
│     Director fires first turn with trigger="greeting" →                      │
│     QuestionAgent injects <session_start/> as the first user message →       │
│     Slow LLM streams: "Hi <name>, thanks so much for joining today! …"       │
│     TTS streams PCM → WebBroadcaster forwards to browser → audible greeting  │
│                                                                              │
└─────────────────────────────────┬────────────────────────────────────────────┘
                                  │
                                  ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  STEP 7 — The interview runs through cadence phases. Per-phase logic:        │
│                                                                              │
│      warm_up           generic prompts, low pressure                         │
│      project_arch      candidate walks through one resume project            │
│      challenges_faced  what was hardest, how it was solved                   │
│      scenario_based    a role-relevant design/debug scenario                 │
│      genai_basics      specific question pool (LLMs, RAG, evals)             │
│      wrap_up           AI asks "any questions?" → end                        │
│                                                                              │
│  Verifier (fast LLM) classifies each candidate reply →                       │
│      tells the slow LLM how to react: push deeper / move on / etc.           │
│                                                                              │
│  CadenceTracker (deterministic, time-based) advances phases on its own;      │
│  the slow LLM doesn't decide when to move on.                                │
│                                                                              │
└─────────────────────────────────┬────────────────────────────────────────────┘
                                  │
                                  ▼
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  STEP 8 — Wrap-up:                                                           │
│      Candidate says "no questions, thanks" → verifier fires                  │
│      wrap_up_complete intent → director emits SESSION_ENDED →                │
│      candidate browser swaps to "Done" screen →                              │
│      orchestrator updates SQLite row (status='completed', ended_at=now) →    │
│      orchestrator process exits, terminal window stays open (cmd /k)         │
│                                                                              │
│  Admin dashboard now shows the row in history. Click into the session →      │
│  events.jsonl is rendered with category highlighting:                        │
│      phase changes ▸ orange  ·  barge-ins ▸ red                              │
│      AI slow LLM ▸ blue       ·  AI filler ▸ yellow                          │
│      candidate STT ▸ green    ·  anomalies ▸ pink                            │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## Quick start

### Prerequisites

| | Windows 10/11 | macOS (Intel or Apple Silicon) |
|---|---|---|
| Python | 3.11 or 3.12 (3.13 has wheel issues) | 3.11 or 3.12 |
| `uv`  | `pip install uv` or [uv install docs](https://docs.astral.sh/uv/) | `brew install uv` |
| `curl` | Built-in on Windows 10 1803+ | Built-in |
| Sound | Mic + speakers (or headphones recommended) | Mic + speakers |
| Optional | [Windows Terminal](https://aka.ms/terminal) for nicer log windows | Terminal.app (built-in) |

### 1. One-time setup

Open a terminal in the project root and run:

```bash
# Create venv with the right Python version
uv venv --python 3.12 .venv

# Install all runtime + dev deps
uv pip install -e ".[dev]"

# Pre-download the Whisper model (~1.5 GB on first run)
.venv/bin/python -c "from huggingface_hub import snapshot_download; snapshot_download('Systran/faster-distil-whisper-large-v3')"
#   On Windows PowerShell: .venv\Scripts\python.exe -c "..."

# Create .env from the example, fill in keys
cp .env.example .env       # macOS / Linux
copy .env.example .env     # Windows
```

Edit `.env` and set at minimum:

```
GROQ_API_KEY=gsk_...
```

Get a free Groq key at [console.groq.com](https://console.groq.com). The
slow LLM (`openai/gpt-oss-120b`) and the fast filler LLM both run through Groq.

Optional — change the admin password (default is `admin / centific123`):

```bash
.venv/bin/python scripts/admin_password.py YourSecretPassword
# Paste the printed bcrypt hash into .env as ADMIN_PASSWORD_HASH=
```

### 2. Run it

**One command. Every day.**

| OS | Command |
|---|---|
| Windows | `.\run_app.bat` |
| macOS / Linux | `./run_app.sh` |

What happens:

1. A second terminal window opens for Stream A — let it finish booting
   (~30–60 s the first time after a reboot). It prints `STREAM A READY`
   when done.
2. The main terminal continues: admin web server starts on `:8000`.
3. Your browser auto-opens to `http://localhost:8000/admin/login`.
4. Sign in with `admin / centific123` (or your custom password).

```
┌──────────────────────────┐    ┌───────────────────────────┐
│  Stream A logs           │    │  Admin server logs        │
│  (separate window)       │    │  (the window you typed in)│
│                          │    │                           │
│  STT / VAD / TTS         │    │  uvicorn :8000            │
│  startup, healthz polls, │    │  request log              │
│  per-utterance audio     │    │                           │
└──────────────────────────┘    └───────────────────────────┘
```

### 3. Run an interview end-to-end

1. **Schedule:** Dashboard → **+ Schedule interview**. Fill the form, upload a resume (drag-and-drop works), submit.
2. **Review cadence:** YAML appears in a textarea. Click **Validate**, edit if you want, or type feedback like *"make the gen-AI phase 2 minutes"* and click **Revise with feedback ↻** — the AI rewrites the YAML in place.
3. **Approve:** Click **Approve & Generate Link**. A third terminal window opens (the orchestrator) and prints `waiting for candidate → click 'Start Interview' in the browser`. A success page shows the candidate's link.
4. **Share the link.** Paste it in another tab to simulate the candidate joining. The lobby appears — enable mic, test speaker, click **Start Interview**.
5. **Interview runs.** Watch the orchestrator's terminal window for live logs.
6. **End:** Either the candidate says "no questions, thanks" (wraps up automatically) or clicks **End ✕**. Back in the admin dashboard, the session now shows `completed`. Click it for the highlighted event log.

### 4. Stop everything

The simplest way: close all three terminal windows. Stream A and the admin
server are independent processes; closing their terminal stops them. Any
running orchestrator window can also be closed individually.

---

## Code layout

```
.
├── run_app.bat / run_app.sh          ← single entry point (boot Stream A + app)
├── pyproject.toml                    ← deps, package config
├── .env.example                      ← copy to .env, fill in keys
│
├── app/                              ← FastAPI composition root (was admin/)
│   ├── main.py                       ← routes: login, /api/*, /admin/* (Jinja), SPA mount at /app
│   ├── auth.py                       ← bcrypt + itsdangerous signed cookies
│   ├── db.py                         ← session CRUD on the shared db/ layer
│   ├── sessions.py                   ← ScheduleForm → DB + filesystem
│   ├── cadence_service.py            ← LLM-driven cadence generate / revise
│   ├── evaluation_service.py         ← post-interview evaluation (uses features/eval)
│   ├── spawner.py                    ← cross-platform new-terminal launcher
│   ├── event_viewer.py               ← parse events.jsonl → annotated rows
│   ├── paths.py                      ← single source of paths
│   ├── templates/  static/           ← Jinja2 console + legacy assets
│
├── engine/                           ← interview runtime
│   ├── speech/                       ← Stream A (STT/VAD/TTS); standalone, run via cwd + `-m services.speech_io.*`
│   │   ├── services/speech_io/{stt,vad,tts}_service/main.py   ← :8010 / :8011 / :8012
│   │   └── models/silero_vad.onnx
│   ├── brain/                        ← the "brain" (agentic interviewer; was engine/brain/)
│   │   ├── runtime/interview_session.py   ← top-level coordinator
│   │   ├── core/                     ← director, cadence_tracker, policy/, latency/, session_store
│   │   ├── agents/                   ← question / verifier / filler / phase_override / apology
│   │   ├── cadence/                  ← default.yaml, schema, loader, questions_pool/
│   │   ├── prompts/  llm/  streamA_bridge/  observability/  contracts/
│   └── orchestrator/                 ← thin shim: mic/speaker + browser transport (was engine/orchestrator/)
│       ├── live_main.py              ← CLI; --scheduled-token loads from DB
│       ├── resume_parser.py
│       └── web/                      ← launcher, broadcaster (WS), http_server, audio source/sink
│
├── features/                         ← product features on the shared core
│   ├── shortlist/                    ← resume → role scoring + persistence
│   ├── coding/                       ← Pyodide coding assessment (was coding/)
│   └── eval/                         ← cadence-driven evaluation rubric (was rubric/)
│
├── db/                               ← shared SQLAlchemy layer (engine + models; sessions + shortlist + roles)
│
├── ui/
│   ├── web/                          ← React SPA (Vite + TS + Tailwind); built to dist/, served at /app
│   └── candidate/                    ← legacy vanilla candidate client (some assets reused by the SPA)
│
├── deploy/                           ← Dockerfile, azure_app.py (cloud entry: gunicorn deploy.azure_app:app), startup.sh
├── config/                           ← system_config.yaml + prompts.yaml + llm_models.yaml (read by engine.brain)
├── scripts/                          ← run_stream_a_only, run_orchestrator, run_live_v2, admin_password
├── sessions/                         ← per-interview artifacts + sessions.db (gitignored)
├── tests/                            ← pytest suite (120 tests)
├── NEW_STREAM_B.md  HOW_TO_TEST_V2.md
└── README.md                         ← you are here
```

---

## Configuration

### `.env` keys

| Key | Purpose | Required? |
|---|---|---|
| `GROQ_API_KEY` | Slow + fast LLM. Free tier at console.groq.com. | **Yes** (or `OPENROUTER_API_KEY`) |
| `OPENROUTER_API_KEY` | Fallback if Groq isn't set. | optional |
| `ADMIN_USERNAME` | Admin login (default `admin`) | optional |
| `ADMIN_PASSWORD_HASH` | bcrypt hash; if unset, falls back to literal `centific123` | optional |
| `ADMIN_SECRET_KEY` | Signs the session cookie; if unset, dev-mode insecure fallback | optional |
| `LANGFUSE_*`, `WANDB_*` | Observability dashboards — legacy, not used by the admin path | optional |

To generate strong values:

```bash
.venv/bin/python scripts/admin_password.py MySecurePassword
.venv/bin/python -c "import secrets; print(secrets.token_urlsafe(32))"
```

### Default cadence

`engine/brain/cadence/default.yaml` defines the fallback flow used when the
admin leaves cadence requirements blank:

```
warm_up (30s) → project_architecture (75s) → challenges_faced (60s) →
scenario_based (90s) → genai_basics (75s) → wrap_up (30s)        [360s total]
```

Wrap-up is intentionally short and **does not summarize** — it asks
"any questions?" and ends.

### Ports

| Port | Service |
|---|---|
| 8000 | Admin web app (FastAPI / uvicorn) |
| 8010 | Stream A — STT |
| 8011 | Stream A — VAD |
| 8012 | Stream A — TTS |
| 8090 | Orchestrator — candidate UI static server |
| 9100 | Orchestrator — candidate WebSocket |

These are **fixed**. Running two interviews at the same time will collide
on 8090/9100. The admin UI enforces single-interview-at-a-time via a guard
on the Approve button.

---

## Where to make changes

| You want to… | Edit |
|---|---|
| Change admin login look | `app/templates/login.html`, `app/static/admin.css` |
| Change candidate lobby look | `ui/candidate/index.html`, `ui/candidate/style.css` |
| Add a new admin page / route | `app/main.py` (route) + `app/templates/<name>.html` |
| Change cadence default phases | `engine/brain/cadence/default.yaml` |
| Change cadence-LLM behavior | `engine/brain/cadence/loader.py` (`_SYSTEM_PROMPT`) |
| Change AI interviewer persona / rules | `engine/brain/prompts/system_prompt.md` |
| Change how AI greets on session start | `<session_start/>` block in `system_prompt.md` + `_build_messages` in `engine/brain/agents/question_agent.py` |
| Change how interview ends | `wrap_up_end_grace_ms` in `interview_session.py` + wrap-up YAML prompts |
| Add per-session event highlighting | `_CATEGORY_MAP` in `app/event_viewer.py` + CSS classes in `app/static/admin.css` |
| Add a new admin form field | Form HTML + `ScheduleForm` dataclass in `admin/sessions.py` + DB schema in `app/db.py` |
| Tune barge-in / latency | `engine/brain/core/latency/orchestrator.py` + `engine/brain/runtime/interview_session.py` |

The admin uvicorn runs with `--reload` so Python edits inside `admin/`
hot-reload. Edits to `engine/brain/` / `engine/orchestrator/` need a fresh
orchestrator spawn (schedule + approve a new interview). Static files
(`ui/candidate/*`, `app/static/*`, `app/templates/*`) take effect on
browser refresh.

---

## Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| `'run_app.bat' is not recognized` | Run from the project root, not a subdir. |
| `goto :waithealth` label-not-found | The `.bat` file got LF line endings. Re-save as CRLF (`PowerShell: $c = [IO.File]::ReadAllText("run_app.bat"); [IO.File]::WriteAllText("run_app.bat", $c -replace "\r?\n","\`r\`n")`). |
| Browser doesn't open / port 8000 in use | `netstat -ano \| findstr :8000` (Windows) or `lsof -ti :8000` (macOS) → kill the PID, try again. |
| Stream A hangs on `still waiting on: STT` | First run downloads ~1.5 GB Whisper model. Check the Stream A window for HF download progress. After first run it's cached. |
| Candidate hears no audio | Make sure the lobby's **Test** button plays a chime (confirms speakers + AudioContext). If yes but interview audio is silent, check the orchestrator log for `[TTS] audio_start` events. |
| AI doesn't greet on Start click | Check the orchestrator terminal for `waiting for candidate → click 'Start Interview'`. If absent, the orchestrator never blocked — `--web-no-wait-for-ui` may have been added back to `app/spawner.py`. |
| AI keeps asking the same question | Verifier is returning `partial_answer` repeatedly. Check `[VERIFIER]` lines in the orchestrator log; you may need to be more specific in your answer or rewrite the question. |
| Cadence YAML validation rejects edit | Common: `sum of duration_s ≠ total_duration_s`. Pydantic error message in the page tells you which field. |
| `ERROR: scheduled-token <uuid> not found` | The orchestrator was spawned with a token that no longer exists in SQLite (admin DB reset). Schedule a fresh interview. |
| Phantom "Hi." caption before clicking Start | `--prewarm` enabled for the web path. Should be `args.prewarm = False` in `engine/orchestrator/live_main.py` for the `--scheduled-token` branch. |

---

## Advanced — internals & dev paths

### Direct CLI interview (no admin)

The orchestrator runs standalone — no admin server, no scheduling. Useful
for backend dev:

```bash
# Boot Stream A (separate window)
scripts/run_stream_a_only.bat     # or .sh on macOS/Linux

# Run a one-shot interview with sounddevice (local mic + speakers)
.venv/Scripts/python.exe -m engine.orchestrator.live_main \
    --candidate-name "Ayush" --role "Backend Engineer" \
    --resume-path docs/sample_resume.pdf \
    --cadence-path engine/brain/cadence/default.yaml

# Or with the browser UI but no admin / SQLite
.venv/Scripts/python.exe -m engine.orchestrator.live_main \
    --candidate-name "Ayush" --role "Backend Engineer" \
    --web
```

See `python -m engine.orchestrator.live_main --help` for the full flag list.

### Where the brain logic lives

Read [NEW_STREAM_B.md](NEW_STREAM_B.md) for the in-depth design of:

- The 3-LLM split (slow / fast / verifier)
- The Director's turn-taking policy (rules −1 through 4)
- LatencyOrchestrator state machine (filler vs apology timers)
- CadenceTracker — deterministic phase advancement
- Event log + tag rendering conventions
- Edge cases §8 (mic dropout, false endpoints, protected response mode, etc.)

### Per-session event log format

Each interview writes a `events.jsonl` file. Each line is one JSON object
matching `engine.brain.contracts.events.Event`:

```json
{"session_id": "…", "ts": "2026-05-19T…", "kind": "tts_audio_start",
 "payload": {"turn_id": "turn-1", "request_id": "slow-1-1"}}
```

The admin session-detail page parses this. To add highlighting for a new
event kind, edit `_CATEGORY_MAP` in `app/event_viewer.py`.

### Tests

```bash
pytest tests/                            # full suite
pytest tests/engine/brain/cadence/ -v    # cadence-only
```

Tests target `engine/brain` (the brain) primarily. The admin app is
manually tested through the UI.

### Resetting state

```bash
rm -rf sessions/                  # clears SQLite + all session artifacts
rm -rf /tmp/integration_logs /tmp/integration   # macOS/Linux
# Windows: del /Q %TEMP%\integration_logs\*  %TEMP%\integration\*
```

Re-running `run_app.bat` / `run_app.sh` recreates everything.

---

## Glossary

- **Cadence** — the interview's phase structure (warm_up → … → wrap_up) plus per-phase prompts. Defined in YAML, validated by pydantic, advanced deterministically by `CadenceTracker`.
- **Director** — owns the turn-taking decision. Asks: "should the AI fire now?"
- **LatencyOrchestrator** — schedules the slow LLM + fast filler so first-token latency stays low.
- **Verifier** — fast LLM that classifies each candidate reply (`answered`, `partial_answer`, `off_topic`, `wrap_up_complete`, …) and tells the slow LLM how to react.
- **Slow LLM / fast LLM** — `openai/gpt-oss-120b` for substantive turns; `llama-3.1-8b-instant` for fillers and meta-classifiers. Both via Groq.
- **Stream A** — the speech I/O layer (STT/VAD/TTS) inherited from an upstream project. Runs as three FastAPI services.
- **Stream B / engine/brain** — the agent brain. `engine/brain` is the current code; `stream_b/` is a legacy snapshot kept for reference.
- **Track B** — the browser-based candidate UI (vs. local sounddevice). Activated by `--web`.
- **Scheduled token** — UUID per scheduled interview. The admin generates one, the orchestrator subprocess is spawned with `--scheduled-token <uuid>`, and the candidate link carries it.

---

## License & ownership

Internal Centific tool. See `pyproject.toml` for runtime dependencies and
their licenses.
