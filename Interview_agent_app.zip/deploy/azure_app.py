"""deploy.azure_app — single ASGI entry point for Azure App Service.

Azure App Service routes ALL external traffic through ONE port (`$PORT`,
typically 8080). The local dev path runs FOUR ports (VAD :8011, TTS :8012,
static :8090, candidate WS :9100) — we need to fold those into a single
FastAPI app for Azure:

  • Static files (`ui/candidate/`)        →  GET /                        (HTML/CSS/JS/wasm)
  • Candidate WebSocket                    →  WS  /ws/candidate/{session_id}
  • Health check (App Service probes)      →  GET /health
  • VAD subprocess                         →  spawned on :8011 (internal-only)
  • TTS subprocess                         →  spawned on :8012 (internal-only)
  • Stream B's InterviewSession            →  spawned per-WS connection,
                                              connects to local VAD/TTS via
                                              the existing client classes.

The same WebSocket protocol the standalone broadcaster on :9100 uses (the
`{"type":"hello"}` handshake, binary mic frames, `{"type":"audio_start"}`
text messages, etc.) is preserved — `ui/candidate/` works unchanged. We
reuse `orchestrator_new.web.broadcaster.WebBroadcaster` via its new
`start_embedded()` + `handle_client_via_adapter()` methods so the per-client
protocol logic lives in one place.

Why a per-WS broadcaster + per-WS session?
------------------------------------------
A candidate's interview is statefully bound to ONE InterviewSession (cadence
tracker, turn history, FSM, etc.). Multi-tenancy = one session per
WebSocket. Stream A's VAD/TTS subprocesses are shared across sessions —
they're stateless WS services that route per-connection by session_id in
the URL path.

Lifecycle
---------
  app startup  → spawn VAD + TTS subprocesses, wait for /healthz
  WS connect   → create per-session WebBroadcaster (embedded mode),
                 spawn a session-runner task that waits for the
                 {"type":"start"} signal then boots an InterviewSession
                 wired to this broadcaster's source/sink.
  WS disconnect → cancel session-runner, broadcaster.stop()
  app shutdown → terminate VAD + TTS subprocesses

Environment variables (set on the App Service)
----------------------------------------------
  GROQ_API_KEY              required (or OPENROUTER_API_KEY)
  OPENROUTER_API_KEY        required when SLOW_PROVIDER=openrouter, OR
                            when you want fast LLM auto-routed via
                            OpenRouter (recommended — avoids Groq direct
                            429 storms on Verifier + PhaseOverride + Filler)
  SLOW_MODEL                defaults to openai/gpt-oss-20b
  FAST_MODEL                defaults to meta-llama/llama-3.1-8b-instruct
                            (OpenRouter id for Llama-3.1-8b-instruct routed
                            to Groq). For direct Groq, set
                            FAST_MODEL=llama-3.1-8b-instant AND
                            FAST_BASE_URL=https://api.groq.com/openai/v1.
  SLOW_PROVIDER             groq | openrouter | openai | (unset)
  FAST_BASE_URL             OpenAI-compat URL for the fast LLM. Defaults to
                            OpenRouter when OPENROUTER_API_KEY is set, else
                            to the primary LLM URL.
  FAST_PROVIDER_ORDER       Comma-separated OpenRouter provider order. Only
                            applied when FAST_BASE_URL points at OpenRouter.
                            Defaults to "Groq" (force Groq, no fallback).
                            Example: "Groq,Cerebras".
  SLOW_PROVIDER_ORDER       Comma-separated OpenRouter provider order for the
                            slow LLM. Only applied when SLOW_BASE_URL points at
                            OpenRouter. Default "Groq" (set in system_config.yaml
                            llm.slow.provider_order). Use this to keep
                            gpt-oss-120b on the Groq route (caching enabled at
                            $0.075/M cache_read).
  MAX_FOLLOW_UPS_PER_QUESTION
                            Max consecutive follow-up turns on a single
                            specific-mode pool question before the Director
                            auto-promotes to `partial_answer_skip` and the
                            tracker pops the question. Default 1 (one push,
                            then move on). 0 disables follow-ups entirely.
  CADENCE_PATH              absolute path to YAML; defaults to
                            stream_b_new/cadence/default.yaml in the deploy
  HF_HUB_OFFLINE            set to 1 (skip the Kokoro HF HEAD timeout)
  KMP_DUPLICATE_LIB_OK      set to TRUE (avoid OpenMP conflict on Linux)
  WEB_CONCURRENCY           gunicorn workers (set to 1 — InterviewSession is
                            stateful per process; multi-worker breaks the
                            per-WS routing)
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import subprocess
import sys
from contextlib import asynccontextmanager
from pathlib import Path
from typing import AsyncIterator
from uuid import UUID, uuid4

import httpx
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from prometheus_client import CONTENT_TYPE_LATEST, Gauge, generate_latest
from engine.brain.observability import prom as _prom
from engine.brain.observability.prom import REGISTRY as _METRICS_REGISTRY

# ──────────────────────────────────────────────────────────────────────────
# Layout — assumes deploy/ sits at the repo root alongside ui/, engine/speech/,
# stream_b_new/, orchestrator_new/.
# ──────────────────────────────────────────────────────────────────────────
REPO_ROOT = Path(__file__).resolve().parent.parent
UI_DIR    = REPO_ROOT / "ui" / "candidate"
STREAM_A_DIR = REPO_ROOT / "engine" / "speech"
SILERO_MODEL_PATH = STREAM_A_DIR / "models" / "silero_vad.onnx"

# Make sure the orchestrator imports resolve when uvicorn runs from this dir.
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(STREAM_A_DIR))

# Imported AFTER sys.path is set so the orchestrator's packages resolve.
from engine.orchestrator.web.broadcaster import WebBroadcaster
from engine.orchestrator.web.audio_source import BrowserMicAudioSource
from engine.orchestrator.web.audio_sink import BrowserSpeakerAudioSink
from engine.brain.cadence import load_cadence
from engine.brain.contracts.session_state import CandidateProfile
from engine.brain.runtime import InterviewSession, SessionConfig

# Session tier: shard identity + the distributed claim/heartbeat/release that
# replaces the single-replica _token_sessions new-session logic. Imports are
# lazy about Redis (get_redis() only connects on first use).
from app.session_tier import identity as shard_identity
from app.session_tier import lifecycle as session_lifecycle

logger = logging.getLogger("deploy.azure_app")
logging.basicConfig(
    level=os.environ.get("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
# Quiet the Azure SDK's per-request HTTP logging (Blob/Queue) — INFO-level noise
# that floods the console; WARNING keeps real errors. Override AZURE_LOG_LEVEL.
logging.getLogger("azure").setLevel(os.environ.get("AZURE_LOG_LEVEL", "WARNING"))

# ──────────────────────────────────────────────────────────────────────────
# Stream A subprocess lifecycle
# ──────────────────────────────────────────────────────────────────────────
_stream_a_procs: dict[str, subprocess.Popen] = {}


def _spawn_stream_a() -> None:
    """Boot the VAD :8011 subprocess (Silero, onnxruntime). STT + TTS are Azure
    Speech (network) on the tiered deploy, so there is NO local Kokoro/Whisper
    subprocess — the heavy torch/Kokoro stack is not in the session image.
    Each subprocess inherits the current env plus the flags Stream A reads.

    Logging: subprocess stdout/stderr are INHERITED from this parent process so
    they end up in the container log stream (`az containerapp logs`). Stream A's
    own structlog [VAD] prefix identifies its lines.
    """
    env = os.environ.copy()
    env["STREAM_A_FAKE_BACKENDS"] = "0"
    env["KMP_DUPLICATE_LIB_OK"]   = "TRUE"
    env["HF_HUB_OFFLINE"]         = env.get("HF_HUB_OFFLINE", "1")
    env["SILERO_MODEL_PATH"]      = str(SILERO_MODEL_PATH)
    env["PYTHONUNBUFFERED"]       = "1"   # children flush log lines immediately

    py = sys.executable  # the gunicorn/uvicorn-managed interpreter

    logger.info("[deploy] spawning Stream A (VAD :8011) — STT/TTS are Azure, no local TTS")
    _stream_a_procs["vad"] = subprocess.Popen(
        [py, "-m", "services.speech_io.vad_service.main"],
        cwd=str(STREAM_A_DIR), env=env,
    )


def _kill_stream_a() -> None:
    for name, proc in _stream_a_procs.items():
        if proc.poll() is None:
            logger.info("[deploy] terminating Stream A subprocess: %s (pid=%d)", name, proc.pid)
            try:
                proc.send_signal(signal.SIGTERM)
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
    _stream_a_procs.clear()


async def _wait_for_stream_a(timeout_s: int = 180) -> None:
    """Poll /healthz on VAD. STT + TTS are Azure (network), so there's no local
    TTS subprocess to wait on — VAD (Silero/onnx) loads in ~1s."""
    urls = ["http://127.0.0.1:8011/healthz"]
    deadline = asyncio.get_event_loop().time() + timeout_s
    async with httpx.AsyncClient(timeout=2.0) as client:
        while asyncio.get_event_loop().time() < deadline:
            all_up = True
            for url in urls:
                try:
                    r = await client.get(url)
                    if r.status_code != 200:
                        all_up = False
                        break
                except Exception:
                    all_up = False
                    break
            if all_up:
                logger.info("[deploy] Stream A is healthy")
                return
            await asyncio.sleep(1.0)
    raise RuntimeError(f"Stream A failed to come up in {timeout_s}s — check /tmp/integration_logs/")


# ──────────────────────────────────────────────────────────────────────────
# Env → SessionConfig defaults
# ──────────────────────────────────────────────────────────────────────────
def _env_int(name: str, kwargs: dict, key: str) -> None:
    """If env var `name` is set, override kwargs[key] with its int value."""
    v = os.environ.get(name)
    if v not in (None, ""):
        kwargs[key] = int(v)


def _env_str(name: str, kwargs: dict, key: str) -> None:
    v = os.environ.get(name)
    if v not in (None, ""):
        kwargs[key] = v


def _build_session_config(candidate_name: str, role: str, resume_text: str) -> SessionConfig:
    """Compose a SessionConfig from config/system_config.yaml, then apply
    Azure App Setting (env-var) overrides on top, then secrets/per-session.

    Precedence: system_config.yaml defaults < env-var override < per-session.
    Secrets (LLM keys, AZURE_SPEECH_KEY) are always sourced from env.
    """
    from engine.brain.config import (
        load_system_config,
        resolve_providers,
        tuning_kwargs,
    )

    cfg = load_system_config()              # SYSTEM_CONFIG_PATH env or repo default
    tuning = tuning_kwargs(cfg)

    # ── Env-var overrides of tuning knobs (preserve existing App Settings) ──
    _env_str("STT_PROVIDER", tuning, "stt_provider")
    _env_str("STT_MODEL", tuning, "stt_model")
    _env_str("STT_LANGUAGE", tuning, "stt_language")
    _env_str("STT_URL", tuning, "stt_url")
    _env_str("TTS_PROVIDER", tuning, "tts_provider")
    _env_str("TTS_URL", tuning, "tts_url")
    _env_int("TTS_SAMPLE_RATE", tuning, "tts_sample_rate_hz")
    _env_str("VAD_URL", tuning, "vad_url")
    _env_str("AZURE_SPEECH_REGION", tuning, "azure_speech_region")
    _env_str("AZURE_SPEECH_VOICE", tuning, "azure_speech_voice")
    _env_str("SLOW_MODEL", tuning, "slow_model")
    _env_int("SLOW_LLM_MAX_TOKENS", tuning, "slow_llm_max_tokens")
    _env_str("FAST_MODEL", tuning, "fast_model")
    _env_int("FILLER_THRESHOLD_MS", tuning, "filler_threshold_ms")
    _env_int("APOLOGY_THRESHOLD_MS", tuning, "apology_threshold_ms")
    _env_int("SILENCE_PROMPT_MS", tuning, "silence_prompt_ms")
    _env_int("MAX_FOLLOW_UPS_PER_QUESTION", tuning, "max_follow_ups_per_question")
    if os.environ.get("NO_FILLER") == "1":
        tuning["use_filler"] = False
    if os.environ.get("CANNED_FILLER") == "1":
        tuning["use_canned_filler"] = True

    # ── Cloud-specific defaults (differ from local; env still overrides) ──
    # Barge-in warm-up + STT noise-rejection threshold (shared knob): a
    # speech burst shorter than this is treated as noise (cough / click)
    # — barge-in is cancelled AND no candidate Turn is appended for it.
    tuning["barge_in_warmup_ms"] = int(os.environ.get("BARGE_IN_WARMUP_MS", "1500"))
    # Endpoint tail: longer on cloud (network jitter).
    tuning["endpoint_tail_ms"] = int(os.environ.get("ENDPOINT_TAIL_MS", "1500"))
    # Azure STT segmentation stays at the client default (1000ms). Azure
    # resets its partial hypothesis after this much silence WITHOUT always
    # firing a usable `recognized`; the Director captures each segment via
    # partial-collapse detection (see _append... in director.py) and joins
    # them at the VAD endpoint. Override via AZURE_STT_SEGMENTATION_SILENCE_MS.
    # No-headphones path → strikes disabled; browser does AEC via getUserMedia.
    tuning["strike_threshold"] = 999_999
    tuning["aec_enabled"] = False
    # Prewarm Kokoro at boot by default on cloud (hide PyTorch JIT cost).
    tuning["prewarm_kokoro"] = os.environ.get("PREWARM_KOKORO", "1") == "1"

    # ── Provider resolution (keys from env; non-secret routing from cfg) ──
    # Apply env overrides onto the cfg routing before resolving.
    llmc = cfg.setdefault("llm", {})
    slowc = llmc.setdefault("slow", {})
    fastc = llmc.setdefault("fast", {})
    if os.environ.get("SLOW_PROVIDER"):
        slowc["provider"] = os.environ["SLOW_PROVIDER"]
    if os.environ.get("SLOW_BASE_URL"):
        slowc["base_url"] = os.environ["SLOW_BASE_URL"]
    if os.environ.get("SLOW_API_KEY_ENV"):
        slowc["api_key_env"] = os.environ["SLOW_API_KEY_ENV"]
    if os.environ.get("SLOW_PROVIDER_ORDER"):
        slowc["provider_order"] = [
            p.strip() for p in os.environ["SLOW_PROVIDER_ORDER"].split(",") if p.strip()
        ]
    if os.environ.get("FAST_BASE_URL"):
        fastc["base_url"] = os.environ["FAST_BASE_URL"]
    if os.environ.get("FAST_PROVIDER_ORDER"):
        fastc["provider_order"] = [
            p.strip() for p in os.environ["FAST_PROVIDER_ORDER"].split(",") if p.strip()
        ]
    providers = resolve_providers(cfg, getenv=lambda n: os.environ.get(n, ""))

    return SessionConfig(
        candidate_profile=CandidateProfile(
            name=candidate_name, role=role, resume_summary=resume_text,
        ),
        cadence=None,  # filled in by the caller after async load
        event_log_path=Path("/tmp/integration/events.jsonl"),
        # azure_speech_key flows through resolve_providers() — keep this
        # one source of truth so we don't get duplicate-kwarg errors.
        **tuning,
        **providers,
    )


# ──────────────────────────────────────────────────────────────────────────
# FastAPI app + lifespan
# ──────────────────────────────────────────────────────────────────────────
_CLOUD_MODE = os.environ.get("CLOUD_MODE", "") == "1"


def _init_admin_storage() -> None:
    """Create the SESSIONS_DIR + initialise SQLite. Idempotent. Skipped
    when admin import fails (no admin/ in image) so the candidate-only
    deploy still boots."""
    try:
        from app import db as admin_db
        from app.paths import ensure_dirs, DB_PATH, SESSIONS_DIR
        ensure_dirs()
        admin_db.init_db()
        logger.info("[deploy] admin DB at %s, sessions dir %s", DB_PATH, SESSIONS_DIR)
        # Access control: teams, roles, the permission grid, the default
        # approval chain, the seeded accounts. This tier COPIES admin routes
        # from app.main rather than importing its app, so app.main's own
        # startup handler never fires here — without this call the tables
        # exist but are empty, every permission check fails closed, and
        # nobody can sign in. Its own try/except so a seed problem cannot
        # stop the tier booting.
        try:
            from app.rbac_seed import seed_rbac

            seed_rbac()
        except Exception:
            logger.exception("[deploy] RBAC seed failed")
    except ImportError:
        logger.info("[deploy] admin/ not present — running in candidate-only mode")
    except Exception as e:
        logger.exception("[deploy] admin DB init failed: %s", e)
        # Don't crash the whole worker — admin routes will 500 individually
        # if they need the DB, but the candidate path keeps working.


# ── Prometheus metrics (scraped at /metrics by the local Grafana stack) ──────
# Gauges register on the SHARED registry (imported above) so they sit on the
# same /metrics as log_timing's per-stage latency histogram.
_G_LOOP_LAG = Gauge(
    "interview_loop_lag_ms", "Event-loop lag (ms), peak since last scrape",
    registry=_METRICS_REGISTRY,
)
_G_ACTIVE = Gauge(
    "interview_active_sessions", "Live interviews cluster-wide (Redis)",
    registry=_METRICS_REGISTRY,
)
_G_SHARD = Gauge(
    "interview_shard_sessions", "Live interviews pinned to this shard (Redis)",
    ["shard"], registry=_METRICS_REGISTRY,
)
_G_LLM = Gauge(
    "interview_llm_inflight", "LLM calls in flight cluster-wide (Redis)",
    registry=_METRICS_REGISTRY,
)
_G_SPEECH = Gauge(
    "interview_speech_inflight", "Azure Speech streams in flight per key (Redis)",
    ["key_id"], registry=_METRICS_REGISTRY,
)
# Container CPU/mem read straight from the cgroup — works inside ANY container
# (Docker Desktop on macOS, where cAdvisor is broken, AND Azure Container Apps),
# so we don't depend on cAdvisor at all. Covers the WHOLE container (main app +
# the VAD subprocess), which is exactly the per-shard number we want.
_G_CPU = Gauge(
    "interview_container_cpu_seconds_total",
    "Cumulative container CPU seconds (cgroup) — use rate() for cores in use",
    registry=_METRICS_REGISTRY,
)
_G_MEM = Gauge(
    "interview_container_memory_bytes", "Container memory in use (cgroup)",
    registry=_METRICS_REGISTRY,
)
# Working set = memory.current − reclaimable page cache (inactive_file). This is
# the "real" memory pressure signal (what Kubernetes/ACA use for OOM decisions):
# it excludes file-backed pages the kernel can drop under pressure, so writing
# events.jsonl / recordings doesn't inflate it. Plot THIS on the dashboard —
# raw memory_bytes climbs with page cache and looks like a leak when it isn't.
_G_MEM_WS = Gauge(
    "interview_container_memory_workingset_bytes",
    "Container working set (cgroup memory.current − inactive_file)",
    registry=_METRICS_REGISTRY,
)
_G_CPULIM = Gauge(
    "interview_container_cpu_limit_cores", "Container CPU limit in cores (cgroup)",
    registry=_METRICS_REGISTRY,
)
# Interviews SCHEDULED but not yet started (DB status='ready'), cluster-wide. A
# scheduled interview isn't pinned to a shard until start, so it has no per-shard
# breakdown; every shard reports the same cluster number → dedupe with max() on
# the dashboard (same pattern as interview_active_sessions). Read from Postgres.
_G_SCHEDULED = Gauge(
    "interview_scheduled_sessions",
    "Interviews scheduled but not yet started (DB status='ready', cluster-wide)",
    registry=_METRICS_REGISTRY,
)
# Deepest candidate mic queue across the live sessions on THIS shard (frames).
# The inbound audio queue backs up first when the event loop can't pump frames
# to STT fast enough — the leading indicator BEFORE frames start dropping
# (interview_mic_frames_dropped_total). `instance` separates shards.
_G_MIC_QDEPTH = Gauge(
    "interview_mic_queue_depth",
    "Deepest candidate mic queue across live sessions on this shard (frames)",
    registry=_METRICS_REGISTRY,
)
_LOOP_LAG_PEAK_MS = 0.0


def _read_cgroup_stats() -> tuple[float | None, float | None, float | None, float | None]:
    """(cpu_seconds_cumulative, mem_bytes, cpu_limit_cores, workingset_bytes) from
    the cgroup. workingset = memory.current − inactive_file (reclaimable page
    cache), the OOM-relevant "real" memory. Tries cgroup v2 (Docker Desktop +
    ACA) then v1. Any failure → None for that field so a /metrics scrape never
    breaks."""
    cpu_s = mem = limit = ws = None
    try:  # cgroup v2
        with open("/sys/fs/cgroup/cpu.stat") as f:
            for line in f:
                if line.startswith("usage_usec"):
                    cpu_s = int(line.split()[1]) / 1e6
                    break
        with open("/sys/fs/cgroup/memory.current") as f:
            mem = float(f.read().strip())
        inactive_file = 0.0
        with open("/sys/fs/cgroup/memory.stat") as f:
            for line in f:
                if line.startswith("inactive_file "):
                    inactive_file = float(line.split()[1])
                    break
        if mem is not None:
            ws = max(0.0, mem - inactive_file)
        with open("/sys/fs/cgroup/cpu.max") as f:
            parts = f.read().split()
            if parts and parts[0] != "max":
                limit = int(parts[0]) / int(parts[1])
    except FileNotFoundError:
        try:  # cgroup v1 fallback
            with open("/sys/fs/cgroup/cpu/cpuacct.usage") as f:
                cpu_s = int(f.read().strip()) / 1e9
            with open("/sys/fs/cgroup/memory/memory.usage_in_bytes") as f:
                mem = float(f.read().strip())
            inactive_file = 0.0
            with open("/sys/fs/cgroup/memory/memory.stat") as f:
                for line in f:
                    if line.startswith("total_inactive_file "):
                        inactive_file = float(line.split()[1])
                        break
            if mem is not None:
                ws = max(0.0, mem - inactive_file)
            with open("/sys/fs/cgroup/cpu/cpu.cfs_quota_us") as f:
                q = int(f.read().strip())
            with open("/sys/fs/cgroup/cpu/cpu.cfs_period_us") as f:
                p = int(f.read().strip())
            if q > 0:
                limit = q / p
        except Exception:
            pass
    except Exception:
        pass
    return cpu_s, mem, limit, ws


async def _event_loop_heartbeat() -> None:
    """Sample event-loop lag — the clearest saturation signal for a load test.

    Every `interval` s we ask to sleep exactly `interval`; the OVERSHOOT
    (actual − interval) is how long the single event loop was too busy/blocked
    to wake us. All interviews on this replica share this one loop, so when the
    overshoot climbs past ~50–100 ms the loop is starved (a blocking call or CPU
    saturation) and per-turn p95 latency will knee. Logs a WARNING on each spike
    and an INFO peak every 10 s. Disable with EVENT_LOOP_HEARTBEAT=0.
    """
    if os.environ.get("EVENT_LOOP_HEARTBEAT", "1") != "1":
        return
    interval = float(os.environ.get("EVENT_LOOP_HEARTBEAT_INTERVAL_S", "0.1"))
    warn_ms = float(os.environ.get("EVENT_LOOP_HEARTBEAT_WARN_MS", "100"))
    global _LOOP_LAG_PEAK_MS
    loop = asyncio.get_running_loop()
    peak_ms, last_report = 0.0, loop.time()
    while True:
        t0 = loop.time()
        await asyncio.sleep(interval)
        lag_ms = (loop.time() - t0 - interval) * 1000.0
        peak_ms = max(peak_ms, lag_ms)
        _LOOP_LAG_PEAK_MS = max(_LOOP_LAG_PEAK_MS, lag_ms)  # exposed at /metrics
        if lag_ms >= warn_ms:
            logger.warning(
                "[loop-lag] event loop stalled %.0fms (threshold %.0fms)",
                lag_ms, warn_ms,
            )
        now = loop.time()
        if now - last_report >= 10.0:
            logger.info("[loop-lag] peak over last 10s: %.0fms", peak_ms)
            peak_ms, last_report = 0.0, now


async def _admission_reconcile_loop() -> None:
    """Periodically heal leaked admission counters against the registry (the
    TTL-backed source of truth). See app.coordination.admission.reconcile. No-op
    if Redis isn't configured (non-tiered run). Interval env-tunable; 0 disables."""
    interval = float(os.environ.get("ADMISSION_RECONCILE_INTERVAL_S", "30"))
    if interval <= 0:
        return
    try:
        from app.coordination import admission
    except Exception:
        return
    while True:
        try:
            await asyncio.sleep(interval)
            await admission.reconcile()
        except asyncio.CancelledError:
            return
        except Exception as e:  # never let a reconcile hiccup kill the task
            logger.warning("[admission] reconcile pass failed: %s", e)


# ── placement + drain (Phase 3) ──────────────────────────────────────────────
# Set when the replica is shutting down (SIGTERM — a deploy, a scale-in): take
# no new interviews, let LiveKit ones finish in place (they need no inbound
# connection), hand the rest off before the grace period ends.
_draining = False


def _placement_capacity() -> int:
    """Interviews this replica takes from the shared queue at once. The measured
    interviews-per-replica (C, plan Phase 0.1 / 1F) belongs here; 4 until then."""
    raw = os.environ.get("SHARD_MAX_SESSIONS") or os.environ.get("PLACEMENT_MAX_SESSIONS") or "4"
    try:
        return max(1, int(raw))
    except ValueError:
        return 4


def _live_sessions() -> list["_SessionHandle"]:
    return [h for h in _token_sessions.values() if not h.runner_task.done()]


def _has_capacity() -> bool:
    if _draining:
        return False
    # PLACEMENT_SHARED_QUEUE=0: this replica doesn't take new LiveKit interviews
    # (addressable shards kept for the WebSocket path when a pool exists).
    if (os.environ.get("PLACEMENT_SHARED_QUEUE") or "1").strip() in ("0", "false", "no"):
        return False
    return len(_live_sessions()) < _placement_capacity()


def _begin_drain(reason: str) -> None:
    """Stop taking interviews. WebSocket interviews are handed off right away:
    their sockets are about to close, and the candidate's reconnect must land on
    a replica that will still be here (it resumes from the checkpoint)."""
    global _draining
    if _draining:
        return
    _draining = True
    ws_sessions = [h for h in _live_sessions() if h.mode != "room"]
    logger.warning("[drain] %s — taking no new interviews; handing off %d WebSocket "
                   "interview(s), %d LiveKit interview(s) finish here",
                   reason, len(ws_sessions), len(_live_sessions()) - len(ws_sessions))
    for h in ws_sessions:
        _hand_off(h, "replica draining", reason="drain_ws")


async def _drain(deadline_s: float) -> None:
    """At shutdown: wait (bounded) for the interviews still running here, then
    hand off whatever is left — their pages rejoin and another replica resumes
    them from the checkpoint."""
    _begin_drain("shutting down")
    end = _time.monotonic() + deadline_s
    while _live_sessions() and _time.monotonic() < end:
        await asyncio.sleep(1.0)
    left = _live_sessions()
    for h in left:
        _hand_off(h, "drain deadline reached", reason="drain_deadline")
    if left:
        await asyncio.wait([asyncio.ensure_future(h.finished.wait()) for h in left], timeout=15)
    logger.info("[drain] done (%d interview(s) handed off at the deadline)", len(left))


def _install_drain_signal() -> None:
    """Start draining the moment SIGTERM arrives — before the server closes its
    sockets — then let the server's own handler shut it down as usual."""
    previous = signal.getsignal(signal.SIGTERM)

    def _on_term(signum, frame):
        try:
            _begin_drain("SIGTERM")
        except Exception as e:  # never block the shutdown
            logger.warning("[drain] begin failed: %s", e)
        if callable(previous):
            previous(signum, frame)
    signal.signal(signal.SIGTERM, _on_term)


async def _room_start_entry(token: str, body: dict) -> tuple[int, dict]:
    """A start that arrived through the placement queue / our inbox."""
    if _draining and not _token_sessions.get(token):
        # Don't START anything while leaving; the gateway falls back.
        return 200, {"transport": "websocket"}
    return await _room_start(token, body)


@asynccontextmanager
async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
    """Spawn Stream A on startup, terminate on shutdown."""
    if _CLOUD_MODE:
        _init_admin_storage()
    _spawn_stream_a()
    try:
        await _wait_for_stream_a(timeout_s=int(os.environ.get("STREAM_A_HEALTH_TIMEOUT_S", "180")))
    except Exception as e:
        logger.error("[deploy] Stream A health-check failed: %s", e)
        _kill_stream_a()
        raise
    # Start the session-orphan reaper for the token-keyed session registry.
    # If a candidate's WS dies and they don't reconnect within
    # SESSION_ORPHAN_TTL_S, this background task cleans up the dead session
    # so we don't leak broadcasters + runner tasks.
    reaper = asyncio.create_task(_evict_session_orphans(), name="session-orphan-reaper")
    heartbeat = asyncio.create_task(_event_loop_heartbeat(), name="event-loop-heartbeat")
    # Self-healing admission reconciler: rebuild the Redis admission counters from
    # the TTL-backed registry so a session that ended without releasing (crash /
    # redeploy / OOM) can't leave phantom active/shard/Speech slots behind. Only
    # runs where Redis is configured (the tiered session tier); harmless no-op
    # otherwise. Disable with ADMISSION_RECONCILE_INTERVAL_S=0.
    reconciler = asyncio.create_task(_admission_reconcile_loop(), name="admission-reconciler")
    # Placement (Phase 3.2): take interview starts from Redis — the shared queue
    # while there's capacity, and always this replica's own inbox.
    placement_stop = asyncio.Event()
    placement_task = metrics_task = None
    if os.environ.get("REDIS_URL"):
        from app.session_tier import placement
        placement_task = asyncio.create_task(placement.serve(
            shard_identity.shard_id(), _room_start_entry,
            has_capacity=_has_capacity, stop=placement_stop), name="placement")
        _install_drain_signal()
        # A pool replica has no ingress, so Prometheus can't scrape it; it
        # publishes its metrics through Redis and the gateway serves them.
        if shard_identity.is_pool():
            from app.coordination import metrics_push
            metrics_task = asyncio.create_task(metrics_push.publish_loop(
                shard_identity.shard_id(), "session-pool", _render_metrics,
                placement_stop), name="metrics-push")
    try:
        yield
    finally:
        # Drain FIRST (Phase 3.3): the interviews need Stream A and the event
        # loop until they're done or handed off.
        # Tiered deploy only: elsewhere there is nobody to hand interviews to.
        if placement_task is not None:
            try:
                await _drain(float(os.environ.get("DRAIN_TIMEOUT_S", "540")))
            except Exception as e:
                logger.warning("[drain] failed: %s", e)
        placement_stop.set()
        if placement_task is not None:
            placement_task.cancel()
        if metrics_task is not None:
            metrics_task.cancel()
        reaper.cancel()
        heartbeat.cancel()
        reconciler.cancel()
        _kill_stream_a()


app = FastAPI(title="Centific Interview Agent", lifespan=lifespan)

# Static files: serve everything under ui/candidate/ from root.
# index.html is served explicitly at GET / so direct path navigation works
# (StaticFiles' default index lookup is finicky behind App Service).
app.mount("/assets",       StaticFiles(directory=str(UI_DIR / "assets")), name="assets") \
    if (UI_DIR / "assets").exists() else None


@app.get("/health")
async def health() -> JSONResponse:
    """Liveness probe target for Azure App Service. Reports VAD/TTS state
    so Azure can flip an instance unhealthy if Stream A crashed."""
    status = {"app": "up"}
    for name, proc in _stream_a_procs.items():
        status[name] = "up" if proc.poll() is None else f"DOWN (rc={proc.returncode})"
    code = 200 if all(v in ("up",) for v in status.values()) else 503
    return JSONResponse(status, status_code=code)


@app.get("/metrics")
async def metrics() -> Response:
    """Prometheus scrape target. Exports the app-level saturation signals the
    infra metrics (cAdvisor/Azure Monitor) can't see: event-loop lag + the live
    Redis concurrency counters. Reads Redis on scrape; every read is guarded so
    a scrape never fails (returns whatever it could gather)."""
    return Response(await _render_metrics(), media_type=CONTENT_TYPE_LATEST)


async def _render_metrics() -> bytes:
    """The /metrics body. Also what a pool replica publishes to Redis (it has
    no ingress to be scraped on). Peaks reset per call, so a replica is either
    scraped or publishes — never both."""
    global _LOOP_LAG_PEAK_MS
    _G_LOOP_LAG.set(_LOOP_LAG_PEAK_MS)
    _LOOP_LAG_PEAK_MS = 0.0  # peak-since-last-scrape, so spikes between scrapes show
    cpu_s, mem_b, cpu_lim, mem_ws = _read_cgroup_stats()
    if cpu_s is not None:
        _G_CPU.set(cpu_s)
    if mem_b is not None:
        _G_MEM.set(mem_b)
    if mem_ws is not None:
        _G_MEM_WS.set(mem_ws)
    if cpu_lim is not None:
        _G_CPULIM.set(cpu_lim)
    # Deepest inbound mic queue across this shard's live sessions (no await,
    # process-local). Snapshot the dict values so a concurrent claim/evict can't
    # mutate it mid-iteration.
    try:
        depth = max(
            (h.broadcaster.mic_queue.qsize() for h in list(_token_sessions.values())),
            default=0,
        )
        _G_MIC_QDEPTH.set(depth)
    except Exception:
        pass
    try:
        from app.coordination import admission
        from app.session_tier import identity
        _G_ACTIVE.set(await admission.value(admission.ACTIVE_SESSIONS))
        _G_LLM.set(await admission.value(admission.LLM_INFLIGHT))
        sid = identity.shard_id()
        _G_SHARD.labels(shard=sid).set(await admission.value(admission.shard_counter(sid)))
        try:
            from app.broker import speech_pool
            for k in speech_pool.parse_keys():
                _G_SPEECH.labels(key_id=k.key_id[:8]).set(
                    await admission.value(admission.speech_key_counter(k.key_id))
                )
        except Exception:
            pass
    except Exception as e:
        logger.debug("[metrics] redis read failed: %s", e)
    # Scheduled-but-not-started backlog (Postgres COUNT). Off-loop via a thread
    # so a slow DB can never add to the very event-loop lag this endpoint reports.
    try:
        from app import db
        _G_SCHEDULED.set(await asyncio.to_thread(db.count_scheduled))
    except Exception as e:
        logger.debug("[metrics] scheduled count failed: %s", e)

    # Publish peak-since-last-scrape LLM concurrency (per key·model) and reset it,
    # so short sub-second calls that finish between scrapes still register.
    try:
        _prom.snapshot_llm_peaks()
    except Exception as e:
        logger.debug("[metrics] llm peak snapshot failed: %s", e)

    body = generate_latest(_METRICS_REGISTRY)
    # Federate the VAD subprocess's metrics onto this endpoint. VAD listens on
    # 127.0.0.1:8011 INSIDE the container, so it's unreachable from another ACA
    # app (one ingress port per app) — exposing it here gives Prometheus a SINGLE
    # scrape target (session :8080) that works identically local and cloud, and
    # attributes VAD latency to the owning shard's `instance`. Best-effort: on any
    # failure return the session metrics alone. vad_* and interview_* names are
    # disjoint, so concatenating the two exposition texts is valid.
    try:
        async with httpx.AsyncClient(timeout=1.0) as _vc:
            r = await _vc.get("http://127.0.0.1:8011/metrics/")
            if r.status_code == 200 and r.content:
                body = body + b"\n" + r.content
    except Exception as e:
        logger.debug("[metrics] VAD federation failed: %s", e)
    return body


@app.get("/")
async def root() -> Response:
    """Root URL.

    In cloud mode (admin is mounted): redirect to /admin/login so TAs
    visiting the bare host land on their portal. Candidates never visit
    the root directly — they arrive via /candidate?token=X, which admin
    issues after approving a cadence.

    In local / candidate-only deploys: serve the candidate UI index so
    `./scripts/run_live_v2.sh --web` keeps working as before."""
    if _CLOUD_MODE:
        try:
            # Verify admin is actually importable before redirecting; if
            # admin/ isn't in the image (candidate-only build), fall back
            # to the candidate UI rather than 404-ing the bare host.
            from app import auth  # noqa: F401
            # The React SPA is the product front door now; it gates auth
            # itself (login when signed out, home when signed in).
            return RedirectResponse(url="/app", status_code=302)
        except ImportError:
            pass
    return FileResponse(UI_DIR / "index.html")


@app.get("/session-info")
async def session_info(token: str | None = None) -> Response:
    """Lightweight pre-interview metadata for the candidate lobby.

    The lobby's "Estimated time" used to be a hardcoded "~30 minutes". This
    derives it from the candidate's actual cadence so a 15- or 45-minute
    plan shows the right number. Resolution order:
      1. `sessions/<token>/cadence.yaml` — the admin-approved plan for THIS
         candidate.
      2. The deploy's default cadence (CADENCE_PATH env or
         stream_b_new/cadence/default.yaml) — for candidate-only/local runs
         with no scheduled token.
      3. 30 (last-resort fallback) if neither loads.

    `total_duration_s` is authoritative (the loader validates it equals the
    sum of phase budgets), so we just round it to whole minutes."""
    duration_min: int | None = None

    def _load_plan(p: Path):
        try:
            if p.exists():
                # Synchronous parse+validate (NOT the async load_cadence,
                # which can invoke the LLM generator).
                from engine.brain.cadence import load_cadence_yaml
                return load_cadence_yaml(p)
        except Exception as e:  # pragma: no cover — never break the lobby
            logger.debug("[session-info] cadence load failed for %s: %s", p, e)
        return None

    # record_enabled is read from the approved cadence.yaml's recording_enabled
    # (stamped in deterministically at generation time — see
    # app.cadence_service.apply_recording_flag), falling back to the DB row
    # for tokens whose cadence hasn't been approved to disk yet. Missing on
    # either → True, matching the mandatory camera+screen behavior every
    # interview had before this flag existed. role is shown in the lobby
    # headline, from the session row.
    from app.coordination import interview_checkpoint as _ckpt
    record_enabled = True
    modality = "voice"
    role = ""
    status: str | None = None
    plan = None
    _row = None
    if token:
        try:
            from app.paths import session_dir
            plan = _load_plan(session_dir(token) / "cadence.yaml")
        except Exception:
            plan = None
        if plan is not None:
            duration_min = max(1, round(plan.total_duration_s / 60))
            record_enabled = bool(plan.recording_enabled)
            modality = "text" if not plan.timed else "voice"
        try:
            from app import db as _db
            _row = _db.get(token)
            role = (_row.get("role") or "").strip() if _row else ""
            if _row and _row.get("modality"):
                modality = _row.get("modality")  # DB row is authoritative
            if plan is None:
                record_enabled = bool(_row and _row.get("record_enabled"))
            # Lets the candidate page recognize an already-finished interview
            # on LOAD (before even attempting a WS connect) and go straight to
            # a Done screen, instead of relying solely on the WS-level refusal.
            if _row:
                status = _row.get("status")
        except Exception:
            pass

    if duration_min is None:
        default_path = Path(
            os.environ.get(
                "CADENCE_PATH",
                REPO_ROOT / "engine" / "brain" / "cadence" / "default.yaml",
            )
        )
        default_plan = _load_plan(default_path)
        duration_min = max(1, round(default_plan.total_duration_s / 60)) if default_plan else None

    # LiveKit media (behind MEDIA_TRANSPORT=livekit): a room-scoped join token so
    # the page can connect; None → the WebSocket audio path. Shared with
    # app/main.py's handler so the two can't drift (see livekit_offer).
    from engine.orchestrator.livekit.tokens import livekit_offer
    livekit = livekit_offer(token, _row)

    return JSONResponse({
        "duration_min": duration_min or 30, "role": role, "record_enabled": record_enabled,
        "modality": modality, "status": status,
        "interview_over": bool(token) and await _ckpt.interview_over(token, status),
        "livekit": livekit,
    })


# ──────────────────────────────────────────────────────────────────────────
# Attach admin routes (cloud mode only) — must happen BEFORE the catch-all
# static handler below so /admin/login etc. aren't swallowed by it.
# ──────────────────────────────────────────────────────────────────────────
def _attach_admin_routes() -> None:
    """In cloud mode, copy admin.main.app's routes onto this FastAPI app.

    This is the no-refactor route — admin/main.py keeps its own
    `app = FastAPI(...)` for standalone (local) use, but in the cloud we
    reuse its already-registered routes by appending them to the parent
    app's routes list. FastAPI matches in registration order, so as long
    as this is called BEFORE the catch-all `/{filename:path}` is
    registered below, admin paths win.

    Skipped if admin/ isn't present (candidate-only image)."""
    if not _CLOUD_MODE:
        return
    try:
        from app.main import app as _admin_app
    except ImportError:
        logger.info("[deploy] admin/ not importable — skipping admin route attach")
        return
    n = 0
    for route in _admin_app.routes:
        # Skip the default 404/405 handler routes Starlette adds automatically;
        # appending them would shadow our parent app's equivalents. They have
        # no `path` attribute — only Mount + APIRoute do.
        if not hasattr(route, "path"):
            continue
        app.routes.append(route)
        n += 1
    logger.info("[deploy] attached %d admin routes (login, schedule, approve, sessions, /candidate, static)", n)


_attach_admin_routes()


# ──────────────────────────────────────────────────────────────────────────
# /candidate/ lobby — serves the candidate UI under a stable, semantic path.
#
# Admin's candidate_join (in CLOUD_MODE) issues 302s of the form
#   /candidate/?token=<uuid>&name=<...>&role=<...>
# so the candidate's URL bar reads "/candidate/?token=..." which is what
# a TA would expect to copy + share. Without these routes, that 302
# target falls through to the catch-all below and 404s.
#
# Both routes must register BEFORE the catch-all `/{filename:path}`
# (FastAPI matches in registration order).
# ──────────────────────────────────────────────────────────────────────────
@app.get("/candidate/")
async def candidate_lobby() -> FileResponse:
    """Serve the candidate UI's index.html at /candidate/.

    The browser then loads relative assets (app.js, style.css,
    mic-worklet.js, ...) which resolve to /candidate/<file> and are
    served by the companion route below."""
    return FileResponse(UI_DIR / "index.html")


@app.get("/candidate/{filename:path}")
async def candidate_static(filename: str) -> FileResponse:
    """Serve any file under ui/candidate/ at /candidate/<file>. Mirrors
    the root catch-all's path-traversal defence."""
    target = (UI_DIR / filename).resolve()
    try:
        target.relative_to(UI_DIR.resolve())
    except ValueError:
        return JSONResponse({"detail": "forbidden"}, status_code=403)
    if not target.is_file():
        return JSONResponse({"detail": "not found"}, status_code=404)
    return FileResponse(target)


@app.get("/{filename:path}")
async def static_passthrough(filename: str) -> FileResponse:
    """Serve any file directly under ui/candidate/ (style.css, app.js, etc.)
    without registering each by name. Falls through to 404 if missing.

    NOTE: this MUST be the last @app.get(...) registered, because it
    matches any path. Admin routes are attached above via
    `_attach_admin_routes()` so they're tried first in cloud mode."""
    target = (UI_DIR / filename).resolve()
    # Defence-in-depth: refuse paths that escape UI_DIR (e.g. ../../.env).
    try:
        target.relative_to(UI_DIR.resolve())
    except ValueError:
        return JSONResponse({"detail": "forbidden"}, status_code=403)
    if not target.is_file():
        return JSONResponse({"detail": "not found"}, status_code=404)
    return FileResponse(target)


# ──────────────────────────────────────────────────────────────────────────
# WebSocket: adapter + handler
# ──────────────────────────────────────────────────────────────────────────
class _FastAPIWebSocketAdapter:
    """Translate FastAPI's `WebSocket` to the `websockets`-style API the
    `WebBroadcaster._handle_client()` method expects.

    Specifically:
      • ``async def send(data: str | bytes)``
      • ``async for msg in adapter`` — yields ``str`` or ``bytes``

    The original handler also catches `websockets.ConnectionClosed`; we
    re-raise FastAPI's `WebSocketDisconnect` as the same exception so the
    handler's `try/except` flow continues to work."""

    def __init__(self, ws: WebSocket) -> None:
        self._ws = ws

    async def send(self, data: str | bytes) -> None:
        try:
            if isinstance(data, (bytes, bytearray)):
                await self._ws.send_bytes(bytes(data))
            else:
                await self._ws.send_text(data)
        except WebSocketDisconnect:
            from websockets.exceptions import ConnectionClosed
            raise ConnectionClosed(None, None)

    def __aiter__(self) -> "_FastAPIWebSocketAdapter":
        return self

    async def __anext__(self) -> str | bytes:
        try:
            msg = await self._ws.receive()
        except WebSocketDisconnect:
            raise StopAsyncIteration
        # FastAPI's receive() returns {"type": "websocket.{receive,disconnect}", "text"|"bytes": ...}
        kind = msg.get("type", "")
        if kind == "websocket.disconnect":
            raise StopAsyncIteration
        if "text" in msg and msg["text"] is not None:
            return msg["text"]
        if "bytes" in msg and msg["bytes"] is not None:
            return msg["bytes"]
        raise StopAsyncIteration


# ──────────────────────────────────────────────────────────────────────────
# Token-keyed session registry — survives WS reconnects.
#
# When a scheduled candidate's browser drops + reconnects (network blip,
# Azure ARR timeout, browser tab background-throttling, the in-app
# reconnect logic firing), we DON'T want to start a fresh InterviewSession
# from warm_up — the candidate just lived through 4 phases of an
# interview and would be furious to be greeted again.
#
# Instead: the broadcaster + InterviewSession runner live in this dict,
# keyed by token. When a new WS arrives with the same token, we cancel
# the old WS handler (if any) and attach a fresh one to the SAME
# broadcaster. The interview state (phase, history, cadence_tracker
# elapsed time) is preserved. The candidate hears "Welcome back" via a
# small JSON resume notice; the AI just picks up where it left off.
#
# Sessions started without a token (ad-hoc smoke tests) get the old
# per-connection lifecycle — no resume, no registry entry.
# ──────────────────────────────────────────────────────────────────────────
import dataclasses
import time as _time


@dataclasses.dataclass
class _SessionHandle:
    """One running interview, possibly across multiple WS connections.

    Lives in THIS shard's memory (the live objects can't be serialized); the
    cross-shard routing pointer for the token lives in Redis (registry). `claim`
    holds the admission + Speech + registry ownership acquired at start, released
    once when the session ends; `hb_task` refreshes the registry TTL meanwhile."""
    token: str
    broadcaster: WebBroadcaster
    runner_task: asyncio.Task
    handler_task: asyncio.Task | None = None  # None when no WS attached
    created_at: float = 0.0
    last_ws_at: float = 0.0
    claim: "session_lifecycle.Claim | None" = None
    hb_task: asyncio.Task | None = None
    hb_stop: asyncio.Event | None = None
    # The browser tab driving the interview (`?client=`, kept in the tab's
    # sessionStorage, so it survives a refresh but differs in another tab or on
    # another device). "" = unknown (an old bundle sends none).
    client_id: str = ""
    # When client_id took ownership: a different tab is refused while the owner
    # is in the room OR may still be joining it (room mode).
    owner_since: float = 0.0
    # "room": started by the page via /api/candidate/{token}/start and torn down
    # by _supervise_session; "ws": started by a WebSocket, whose handler
    # coroutine owns the teardown (as it always did).
    mode: str = "ws"
    room_ready: "asyncio.Future[bool] | None" = None
    finished: asyncio.Event = dataclasses.field(default_factory=asyncio.Event)
    released: bool = False


_token_sessions: dict[str, _SessionHandle] = {}
_token_sessions_lock = asyncio.Lock()
# Maximum quiet period (no WS attached) before the orphan session is
# reaped. Browsers that drop and reconnect within this window get a clean
# resume; anything beyond is treated as "the candidate left" and the
# interview is torn down.
_SESSION_ORPHAN_TTL_S: float = float(os.environ.get("SESSION_ORPHAN_TTL_S", "180"))


async def _release_session(token: str, handle: _SessionHandle) -> None:
    """Stop the heartbeat and give the token's cluster ownership (registry +
    admission + Speech slot) back. Called on natural end and on orphan evict.
    session_lifecycle.release() no-ops for resume/None claims, so this is safe
    to call once per handle."""
    # Idempotent: the orphan reaper and the session's own teardown can both get
    # here, and releasing twice would hand back capacity that is still in use.
    if handle.released:
        return
    handle.released = True
    if handle.hb_stop is not None:
        handle.hb_stop.set()
    if handle.hb_task is not None and not handle.hb_task.done():
        handle.hb_task.cancel()
    try:
        await session_lifecycle.release(token, handle.claim)
    except Exception as e:
        logger.warning("[ws-registry] release hiccup token=%s: %s", token[:8], e)


async def _evict_session_orphans() -> None:
    """Background task — evicts session handles whose WS has been dead
    for longer than the orphan TTL. Runs every 30s. Started from the
    lifespan handler."""
    while True:
        try:
            await asyncio.sleep(30.0)
            now = _time.time()
            async with _token_sessions_lock:
                stale: list[str] = []
                for tok, h in _token_sessions.items():
                    has_ws = h.handler_task and not h.handler_task.done()
                    # A LiveKit interview's page is connected through the
                    # room, not a WebSocket: being in the room counts.
                    if has_ws or h.broadcaster.room_present():
                        h.last_ws_at = now
                    elif (now - h.last_ws_at) > _SESSION_ORPHAN_TTL_S:
                        stale.append(tok)
                for tok in stale:
                    h = _token_sessions.pop(tok)
                    logger.info(
                        "[ws-registry] evicting orphan session token=%s... (no WS for %.0fs)",
                        tok[:8], now - h.last_ws_at,
                    )
                    if not h.runner_task.done():
                        h.runner_task.cancel()
                    try:
                        await h.broadcaster.stop()
                    except Exception:
                        pass
                    # Give the token's registry entry + admission + Speech slot
                    # back so a crashed/left session doesn't leak cluster capacity.
                    await _release_session(tok, h)
        except asyncio.CancelledError:
            return
        except Exception as e:
            logger.warning("[ws-registry] orphan reaper hiccup: %s", e)


async def _ws_require_admin(ws: WebSocket) -> str | None:
    """WebSocket-side mirror of `admin/_require_user_or_redirect`.

    Returns the admin username on success, None on failure (and closes
    the WS with code 4403 in that case). Reads the same `admin_session`
    cookie the HTTP auth path uses.
    """
    from app import auth as _admin_auth
    cookie_val = ws.cookies.get(_admin_auth.COOKIE_NAME)
    if not cookie_val:
        try:
            await ws.close(code=4403)
        except Exception:
            pass
        return None
    user = _admin_auth.read_cookie(cookie_val)
    if not user:
        try:
            await ws.close(code=4403)
        except Exception:
            pass
        return None
    return user


@app.websocket("/ws/candidate/{session_id}")
async def candidate_ws(
    ws: WebSocket,
    session_id: str,
    token: str | None = None,
    client: str | None = None,
    probe: str | None = None,
) -> None:
    """One candidate, one interview — but the interview is keyed by the
    optional ?token=<uuid>, not the WS connection. So a candidate that
    disconnects and reconnects within `_SESSION_ORPHAN_TTL_S` (default
    180 s) gets attached back to the same running InterviewSession —
    same phase, same history, same cadence elapsed time. No restart.

    With token: lookup-or-create in `_token_sessions`, attach a fresh
    WS handler, leave the runner alive across reconnects.

    Without token: per-WS broadcaster + runner, no resume (the ad-hoc
    smoke-test path; same as before this refactor).
    """
    await ws.accept()
    if probe:
        # The lobby's connection check (the gateway answers it in the tiered
        # deploy; this is the single-app one): no session, no claim.
        await ws.close()
        return
    adapter = _FastAPIWebSocketAdapter(ws)
    logger.info(
        "[ws] candidate connected session_id=%s token=%s",
        session_id,
        (token[:8] + "...") if token else "<none>",
    )

    handle: _SessionHandle | None = None
    is_resume = False

    if token:
        # Token-keyed path — find or create session, attach WS. Time the wait to
        # acquire the single global lock: a spike here = a 2nd connect serialized
        # behind another session's claim/teardown holding the lock.
        _lock_t0 = _time.monotonic()
        async with _token_sessions_lock:
            _log_startup_step("session_lock_wait", _lock_t0)
            existing = _token_sessions.get(token)
            if existing is not None and not existing.runner_task.done():
                # RESUME — there's already a running session for this token.
                # The same tab coming back (refresh / network blip) takes the
                # session over. A DIFFERENT tab or device is refused while the
                # owner is still connected: a link opened twice would otherwise
                # steal the interview back and forth, each side's auto-reconnect
                # cancelling the other. Once the owner is gone it may take over,
                # so a candidate whose browser crashed can still finish.
                owner_connected = bool(existing.handler_task and not existing.handler_task.done())
                if (owner_connected and client and existing.client_id
                        and client != existing.client_id):
                    logger.info("[ws] token=%s... refused a second tab — the "
                                "interview is live in another window", token[:8])
                    try:
                        await adapter.send(json.dumps({"type": "session_in_use"}))
                    except Exception:
                        pass
                    await ws.close(code=4409)
                    return
                if client:
                    existing.client_id = client
                if existing.handler_task and not existing.handler_task.done():
                    logger.info(
                        "[ws] token=%s... already had a WS handler — cancelling it before resume",
                        token[:8],
                    )
                    existing.handler_task.cancel()
                    try:
                        await asyncio.wait_for(existing.handler_task, timeout=2.0)
                    except (asyncio.CancelledError, asyncio.TimeoutError):
                        pass
                handle = existing
                is_resume = True
                logger.info(
                    "[ws] RESUME — token=%s..., session running for %.1fs, attaching new WS",
                    token[:8], _time.time() - handle.created_at,
                )
            else:
                # No live session for this token — but that's also exactly
                # what a FINISHED interview looks like once its runner has
                # torn down (see the pop() in the natural-end branch below).
                # Distinguish "hasn't started yet" from "already over" before
                # treating this as a fresh start. Without this, reopening a
                # completed/cancelled link silently started a brand-new
                # interview from warm_up. "Over" is NOT just status=completed:
                # a crashed runner is marked completed too and must stay
                # resumable (interview_checkpoint.interview_over).
                try:
                    from app import db as admin_db
                    row = await asyncio.to_thread(admin_db.get, token)
                except Exception:
                    row = None
                from app.coordination import interview_checkpoint
                if row is not None and await interview_checkpoint.interview_over(
                        token, row.get("status")):
                    logger.info(
                        "[ws] candidate reconnect refused — token=%s... is already %s",
                        token[:8], row.get("status"),
                    )
                    try:
                        await adapter.send(json.dumps({
                            "type": "session_ended", "reason": "interview_over",
                        }))
                    except Exception:
                        pass
                    await ws.close()
                    return
                # NEW SESSION for this token — claim it cluster-wide first
                # (token lock → admission → Speech capacity → registry). If the
                # claim is refused, don't start a brain; tell the client why.
                _claim_t0 = _time.monotonic()
                claim = await session_lifecycle.claim(token)
                _log_startup_step("claim", _claim_t0)
                if not claim.ok:
                    logger.warning("[ws] claim refused token=%s reason=%s",
                                   token[:8], claim.reason)
                    try:
                        await adapter.send(json.dumps({
                            "type": "session_rejected", "reason": claim.reason,
                        }))
                    except Exception:
                        pass
                    await ws.close(code=4409)
                    return
                broadcaster = WebBroadcaster(
                    host="(embedded)", port=0,
                    sample_rate_hz=int(os.environ.get("TTS_SAMPLE_RATE", "16000")),
                )
                # Stamp the interview token so outbound audio_start carries it and
                # the browser records only THIS interview's AI audio (guards
                # cross-interview audio bleed when a shard runs many interviews).
                broadcaster.session_id = token or ""
                await broadcaster.start_embedded()
                runner_task = asyncio.create_task(
                    _session_runner(broadcaster, session_id, scheduled_token=token,
                                    stt=claim.stt),
                    name=f"session-{session_id}",
                )
                hb_task, hb_stop = _start_heartbeat(token, claim, session_id, runner_task, broadcaster)
                handle = _SessionHandle(
                    token=token,
                    broadcaster=broadcaster,
                    runner_task=runner_task,
                    handler_task=None,
                    created_at=_time.time(),
                    last_ws_at=_time.time(),
                    claim=claim,
                    hb_task=hb_task,
                    hb_stop=hb_stop,
                    client_id=client or "",
                )
                _token_sessions[token] = handle
                logger.info("[ws] NEW session for token=%s... on shard=%s",
                            token[:8], shard_identity.shard_id())

            # Attach the new WS handler to the broadcaster (whether resume or new).
            handle.handler_task = asyncio.create_task(
                handle.broadcaster.handle_client_via_adapter(adapter),
                name=f"ws-handler-{session_id}",
            )
            handle.last_ws_at = _time.time()

        # Tell the client we resumed (best-effort; ignore if WS already dead).
        if is_resume:
            try:
                await adapter.send(json.dumps({
                    "type": "resume",
                    "token": token,
                    "session_uptime_s": int(_time.time() - handle.created_at),
                }))
            except Exception:
                pass
    else:
        # No token — per-WS broadcaster + runner, no resume.
        broadcaster = WebBroadcaster(
            host="(embedded)", port=0,
            sample_rate_hz=int(os.environ.get("TTS_SAMPLE_RATE", "16000")),
        )
        await broadcaster.start_embedded()
        runner_task = asyncio.create_task(
            _session_runner(broadcaster, session_id, scheduled_token=None),
            name=f"session-{session_id}",
        )
        handler_task = asyncio.create_task(
            broadcaster.handle_client_via_adapter(adapter),
            name=f"ws-handler-{session_id}",
        )
        handle = _SessionHandle(
            token="", broadcaster=broadcaster, runner_task=runner_task,
            handler_task=handler_task,
            created_at=_time.time(), last_ws_at=_time.time(),
        )

    try:
        # Handler returns when the WS closes; runner returns when the session ends.
        # If the WS dies but the runner is still running AND we have a token,
        # leave the runner alive — a reconnect within _SESSION_ORPHAN_TTL_S
        # will attach back to it.
        done, pending = await asyncio.wait(
            {handle.runner_task, handle.handler_task},  # type: ignore[arg-type]
            return_when=asyncio.FIRST_COMPLETED,
        )
        runner_done = handle.runner_task in done
        if runner_done:
            if handle.mode == "room":
                # A LiveKit interview that fell back to this socket: its
                # supervisor owns the teardown. Let the goodbye reach this
                # socket before closing it.
                try:
                    await asyncio.wait_for(handle.finished.wait(), timeout=5.0)
                except asyncio.TimeoutError:
                    pass
                for t in pending:
                    t.cancel()
                return
            await _finish_session(token or "", handle, pending)
        else:
            # WS closed but runner is still running.
            if token:
                # Keep session alive for orphan TTL — next WS resumes it.
                logger.info(
                    "[ws] WS dropped but session still running (token=%s...) — "
                    "waiting up to %.0fs for reconnect",
                    token[:8], _SESSION_ORPHAN_TTL_S,
                )
                handle.last_ws_at = _time.time()
                # Don't tear down; the eviction loop will eventually if no reconnect.
                # Return early WITHOUT touching the broadcaster.
                return
            else:
                # No-token path: WS gone, kill the runner too.
                handle.runner_task.cancel()
                try:
                    await handle.broadcaster.stop()
                except Exception:
                    pass
                logger.info("[ws] no-token session torn down on WS close")
                return
        for t in done:
            exc = t.exception()
            if exc and not isinstance(exc, (asyncio.CancelledError,)):
                logger.warning("[ws] task %s raised: %r", t.get_name(), exc)
    finally:
        # NOTE: do NOT call broadcaster.stop() here unconditionally.
        # When a token-keyed session is mid-interview and the WS just
        # dropped, we want the broadcaster + runner to keep running so
        # the next WS can resume. The branches above handle their own
        # teardown when appropriate (session ended naturally, or no-token
        # path).
        logger.info("[ws] candidate ws closed session_id=%s", session_id)


def _start_heartbeat(token: str, claim, session_id: str, runner_task: asyncio.Task,
                     broadcaster: WebBroadcaster):
    """Keep the token's fenced lease alive while the interview runs. If the
    lease is lost (another replica took the interview), stop running it here at
    once — two replicas must never drive one interview — as a hand-off, so the
    teardown doesn't mark the interview the other replica is running completed."""
    hb_stop = asyncio.Event()

    def _lost() -> None:
        if not broadcaster.handover:
            _prom.INTERVIEW_HANDOFFS.labels(reason="lease_lost").inc()
        broadcaster.handover = True
        runner_task.cancel()
    hb_task = asyncio.create_task(
        session_lifecycle.heartbeat_loop(token, hb_stop, lease=claim.lease, on_lost=_lost),
        name=f"hb-{session_id}",
    )
    return hb_task, hb_stop


async def _room_start(token: str, body: dict) -> tuple[int, dict]:
    """Start (or rejoin) a LiveKit interview for one browser tab — Phase 2's
    replacement for opening /ws/candidate. Returns (HTTP status, body):

      200 {"transport":"livekit", url, token}  join the room; control messages
                                                go through its data channel
      200 {"transport":"websocket"}            use the WebSocket path instead
      409 {"reason":"session_in_use"}          live in another tab / device
      410 {"reason":"interview_over"}          finished link
      409 {"reason":<claim refusal>, ...}      capacity etc. (gateway may retry)

    The same rules as the WebSocket path, in the same order: an over interview
    is refused; a live one is rejoined only by the tab that owns it (or by any
    tab once the owner has left); otherwise the token is claimed cluster-wide
    and a runner starts. The room token is minted here, after those checks —
    never by /session-info."""
    from engine.orchestrator.livekit import config as lk_config, tokens as lk_tokens
    client = "".join(ch for ch in str(body.get("client") or "") if ch.isalnum() or ch == "-")[:64]
    if not lk_config.livekit_enabled():
        return 200, {"transport": "websocket"}
    from app import db as admin_db
    row = await asyncio.to_thread(admin_db.get, token)
    if row is None or row.get("is_template"):
        return 404, {"reason": "not_found"}

    if body.get("fallback") == "websocket":
        # The page couldn't use the room: hand the interview off so the
        # WebSocket path can start it on an addressable shard.
        handle = _token_sessions.get(token)
        if handle is not None and handle.mode == "room" and not handle.runner_task.done():
            _hand_off(handle, "the page asked for the WebSocket", reason="page_fallback")
            await _wait_finished(handle)
        return 200, {"transport": "websocket"}

    async with _token_sessions_lock:
        handle = _token_sessions.get(token)
        if handle is not None and not handle.runner_task.done():
            if handle.mode != "room" or handle.room_ready is None:
                return 200, {"transport": "websocket"}
            owner = handle.client_id
            if owner and client and owner != client:
                # The owner may be in the room, or still joining it.
                joining = (_time.time() - handle.owner_since) < lk_config.candidate_join_timeout_s()
                if joining or handle.broadcaster.room_present(lk_tokens.candidate_identity(owner)):
                    logger.info("[room] token=%s... refused a second tab", token[:8])
                    return 409, {"reason": "session_in_use"}
            if client and client != owner:
                handle.client_id, handle.owner_since = client, _time.time()
        else:
            from app.coordination import interview_checkpoint
            if await interview_checkpoint.interview_over(token, row.get("status")):
                return 410, {"reason": "interview_over"}
            claim = await session_lifecycle.claim(token)
            if not claim.ok:
                logger.warning("[room] claim refused token=%s reason=%s", token[:8], claim.reason)
                loc = getattr(claim, "location", None)
                return 409, {"reason": claim.reason, "shard": getattr(loc, "fqdn", "") or ""}
            session_id = str(uuid4())
            broadcaster = WebBroadcaster(
                host="(embedded)", port=0,
                sample_rate_hz=int(os.environ.get("TTS_SAMPLE_RATE", "16000")),
            )
            broadcaster.session_id = token
            await broadcaster.start_embedded()
            # The HTTP call IS the "start" — the same message the WebSocket
            # page sends, so the runner sees exactly what it always did.
            await broadcaster.handle_inbound_json({
                "type": "start",
                "visual_mode": body.get("visual_mode"),
                "candidate": body.get("candidate") or {},
            })
            room_ready: asyncio.Future[bool] = asyncio.get_running_loop().create_future()
            runner_task = asyncio.create_task(
                _session_runner(broadcaster, session_id, scheduled_token=token,
                                stt=claim.stt, room_ready=room_ready),
                name=f"session-{session_id}",
            )
            hb_task, hb_stop = _start_heartbeat(token, claim, session_id, runner_task, broadcaster)
            now = _time.time()
            handle = _SessionHandle(
                token=token, broadcaster=broadcaster, runner_task=runner_task,
                created_at=now, last_ws_at=now, claim=claim,
                hb_task=hb_task, hb_stop=hb_stop,
                client_id=client, owner_since=now,
                mode="room", room_ready=room_ready,
            )
            _token_sessions[token] = handle
            asyncio.create_task(_supervise_session(token, handle), name=f"supervise-{session_id}")
            logger.info("[room] NEW session for token=%s... on shard=%s",
                        token[:8], shard_identity.shard_id())

    # Outside the lock: wait (bounded) for the AI to be in the room.
    try:
        ok = await asyncio.wait_for(asyncio.shield(handle.room_ready),
                                    timeout=lk_config.connect_timeout_s() + 5)
    except asyncio.TimeoutError:
        ok = False
    access = lk_tokens.candidate_room_access(token, client, row) if ok else None
    if access is None:
        # The page will take the WebSocket path: let our claim go first, or
        # its start would be refused as "owned elsewhere".
        if not handle.runner_task.done():
            _hand_off(handle, "no usable room", reason="no_room")
        await _wait_finished(handle)
        return 200, {"transport": "websocket"}
    return 200, {"transport": "livekit", **access}


async def _wait_finished(handle: _SessionHandle, timeout_s: float = 15.0) -> None:
    try:
        await asyncio.wait_for(handle.finished.wait(), timeout=timeout_s)
    except asyncio.TimeoutError:
        logger.warning("[room] token=%s teardown still running after %.0fs",
                       handle.token[:8], timeout_s)


async def _finish_session(token: str, handle: _SessionHandle, pending=()) -> bool:
    """Tear an interview down once its runner has finished; returns whether it
    ended cleanly. ONE implementation for both ways an interview runs: the
    WebSocket handler calls it, and _supervise_session does for LiveKit ones.

    Distinguishes a CLEAN finish (wrap-up / browser-end / give-up → the runner
    returned normally) from a CRASH or cancellation (e.g. a shard shutdown
    tearing down STT/TTS, so run_until_signal raised). Only a clean finish may
    drop the durable checkpoint; a crash MUST keep it so the reconnecting
    candidate resumes the phase instead of re-greeting. (Clearing on ANY runner
    completion once silently broke resume — observed 2026-07-30, token c96436f5.)"""
    if handle.runner_task.cancelled():
        runner_crashed = True
    else:
        try:
            runner_crashed = handle.runner_task.exception() is not None
        except Exception:
            runner_crashed = True
    natural_end = not runner_crashed
    # Announce "session ended" ONLY on a clean end. On a crash the page should
    # reconnect QUIETLY into a resumed session — a session_ended frame would
    # send it to the "done" screen and kill resume.
    if natural_end:
        try:
            handle.broadcaster.emit_control("session_ended", reason="natural")
            await asyncio.sleep(0.1)  # let the frame land before stop()
        except Exception:
            pass
    for t in pending:
        t.cancel()
    if token:
        async with _token_sessions_lock:
            if _token_sessions.get(token) is handle:
                _token_sessions.pop(token, None)
        # Free registry + admission + Speech (outside the local lock so the
        # brief Redis round-trip doesn't block other connects).
        await _release_session(token, handle)
        from app.paths import session_dir
        from engine.brain.observability.event_log import append_event_oneshot
        _ev_path = session_dir(token) / "events.jsonl"
        if natural_end:
            # Clean end — drop the durable checkpoint so a later reconnect
            # starts fresh, not a resume of a finished interview.
            try:
                from app.coordination import interview_checkpoint
                await interview_checkpoint.clear(token)
            except Exception as e:
                logger.warning("[checkpoint] clear on natural end failed: %s", e)
            append_event_oneshot(_ev_path, token, "checkpoint_cleared",
                                 {"reason": "natural_end"})
        else:
            # Crash / cancellation — KEEP the checkpoint so the reconnect can
            # resume.
            logger.info("[checkpoint] token=%s runner ended abnormally "
                        "(cancelled/crashed) — KEEPING checkpoint for resume",
                        token[:8])
            append_event_oneshot(_ev_path, token, "checkpoint_kept",
                                 {"reason": "runner_crash_or_cancel"})
    try:
        await handle.broadcaster.stop()
    except Exception:
        pass
    handle.finished.set()
    logger.info("[session] %s — torn down (token=%s, %s)",
                "ended naturally" if natural_end else "runner crashed/cancelled",
                (token or "<none>")[:8], handle.mode)
    return natural_end


async def _supervise_session(token: str, handle: _SessionHandle) -> None:
    """A LiveKit interview has no WebSocket coroutine waiting on its runner, so
    this does: when the runner finishes, run the same teardown."""
    try:
        await asyncio.wait({handle.runner_task})
    except asyncio.CancelledError:
        return
    await _finish_session(token, handle)


def _log_startup_step(action: str, t0: float) -> None:
    """Emit interview_stage_latency_ms{service='startup', action=...} for one
    bring-up step, so a slow interview start is attributable to a specific step
    on /metrics (see the 'Startup breakdown' dashboard panel). Never raises."""
    try:
        from engine.brain.observability.timing import log_timing
        log_timing(logger, "startup", action, (_time.monotonic() - t0) * 1000.0)
    except Exception:
        pass


def _load_precomputed_resume(sdir: Path, token: str, session_id: str) -> str:
    """Load the resume artifacts the resume_summary worker precomputed for this
    interview at schedule time, from sessions/{token}/resume/: summary.txt
    (preferred) → parsed.txt TRUNCATED (fallback) → "" (no resume). Reads the
    shared session dir; if a file is missing there, best-effort hydrates it from
    blob ({token}/resume/...). NEVER parses or calls the LLM — that all happened
    async at schedule time, so the candidate's start path stays fast. Sync (run
    via asyncio.to_thread) since the blob fallback is blocking I/O."""
    rdir = sdir / "resume"
    cap = int(os.environ.get("RESUME_FALLBACK_CHARS", "4000"))

    def _read(name: str) -> str:
        fp = rdir / name
        try:
            if fp.is_file():
                return fp.read_text(encoding="utf-8", errors="ignore").strip()
        except Exception:
            pass
        try:  # cross-tier fallback if the shared mount doesn't have it yet
            from app import blob_store
            data = blob_store.download_bytes(f"{token}/resume/{name}")
            if data:
                return data.decode("utf-8", "ignore").strip()
        except Exception:
            pass
        return ""

    summary = _read("summary.txt")
    if summary:
        logger.info("[session %s] resume: precomputed summary (%d chars)", session_id, len(summary))
        return summary
    parsed = _read("parsed.txt")
    if parsed:
        logger.info(
            "[session %s] resume: summary unavailable — truncated parsed (%d→%d chars)",
            session_id, len(parsed), min(len(parsed), cap),
        )
        return parsed[:cap]
    logger.info("[session %s] resume: no precomputed artifacts — no resume context", session_id)
    return ""


class _HandOff(Exception):
    """The runner stops so the interview can continue elsewhere — another
    replica, or the WebSocket path. Never marks it completed; the teardown
    keeps its checkpoint (it's a crash, from the checkpoint's point of view)."""


def _hand_off(handle: "_SessionHandle", why: str, *, reason: str) -> None:
    """Stop running an interview here so it can continue elsewhere. ``reason``
    is the metric label (a short fixed word); ``why`` is for the log."""
    logger.info("[session] hand-off token=%s: %s", (handle.token or "-")[:8], why)
    if not handle.broadcaster.handover:   # count each interview's hand-off once
        _prom.INTERVIEW_HANDOFFS.labels(reason=reason).inc()
    handle.broadcaster.handover = True
    if not handle.runner_task.done():
        handle.runner_task.cancel()


async def _start_livekit_egress(lk, token: str, session_id: str) -> tuple[str, str]:
    """Start the server-side audio recording; returns (egress id, blob name),
    ("", "") when off or it failed. Logged to events.jsonl either way so the
    interview's record says which happened."""
    from engine.orchestrator.livekit import egress
    from engine.brain.observability.event_log import append_event_oneshot
    from app.paths import session_dir
    eg = egress.egress_settings()
    if eg is None:
        return "", ""
    ev_path = session_dir(token) / "events.jsonl"
    blob_name = egress.egress_blob_name(token, _time.time())
    try:
        egress_id = await egress.start_audio_egress(lk, eg, token, blob_name)
    except Exception as e:
        logger.warning("[session %s] LiveKit egress start failed: %r", session_id, e)
        _prom.LIVEKIT_EGRESS.labels(outcome="start_failed").inc()
        append_event_oneshot(ev_path, token, "livekit_egress_failed", {"error": repr(e)[:300]})
        return "", ""
    logger.info("[session %s] LiveKit egress started id=%s", session_id, egress_id)
    _prom.LIVEKIT_EGRESS.labels(outcome="started").inc()
    append_event_oneshot(ev_path, token, "livekit_egress_started",
                         {"egress_id": egress_id, "blob": blob_name})
    await asyncio.to_thread(egress.write_manifest, blob_name, "recording", egress_id=egress_id)
    return egress_id, blob_name


async def _wait_livekit_egress_active(lk, egress_id: str, session_id: str) -> bool:
    """Hold the greeting (bounded) until the recorder is actually capturing.
    If it doesn't get there in time the interview goes ahead — the browser
    recording still has everything."""
    from livekit import api
    deadline = _time.monotonic() + float(os.getenv("LIVEKIT_EGRESS_START_WAIT_S", "10"))
    client = api.LiveKitAPI(lk.url, lk.api_key, lk.api_secret)
    try:
        while _time.monotonic() < deadline:
            res = await client.egress.list_egress(api.ListEgressRequest(egress_id=egress_id))
            status = res.items[0].status if res.items else None
            if status == api.EgressStatus.EGRESS_ACTIVE:
                return True
            if status in (api.EgressStatus.EGRESS_FAILED, api.EgressStatus.EGRESS_ABORTED):
                logger.warning("[session %s] LiveKit egress %s ended early: %s",
                               session_id, egress_id, res.items[0].error)
                return False
            await asyncio.sleep(0.5)
        logger.warning("[session %s] LiveKit egress %s not active after wait — "
                       "starting anyway", session_id, egress_id)
    except Exception as e:
        logger.warning("[session %s] LiveKit egress status check failed: %r", session_id, e)
    finally:
        await client.aclose()
    return False


async def _stop_livekit_egress(lk, egress_id: str, session_id: str, *, token: str,
                               blob: str, grace_s: float | None = None) -> None:
    # The recorder hears the room a beat behind the agent; stopping the instant
    # the goodbye finished playing would clip its last words from the file.
    if grace_s is None:
        grace_s = float(os.getenv("LIVEKIT_EGRESS_STOP_GRACE_S", "1.5"))
    if grace_s > 0:
        await asyncio.sleep(grace_s)
    from engine.orchestrator.livekit import egress
    try:
        await egress.stop_egress(lk, egress_id)
        logger.info("[session %s] LiveKit egress stopped id=%s", session_id, egress_id)
        _prom.LIVEKIT_EGRESS.labels(outcome="stopped").inc()
    except Exception as e:  # never break teardown
        logger.warning("[session %s] LiveKit egress stop failed: %r", session_id, e)
        _prom.LIVEKIT_EGRESS.labels(outcome="stop_failed").inc()
    # LiveKit uploads the file a few seconds AFTER the stop, and nothing here
    # waits for that. The worker confirms it landed (or records why not) so
    # the admin's player can say "ready" / "failed" instead of guessing.
    # Enqueued even when the stop failed: the egress may have ended on its own.
    await asyncio.to_thread(egress.write_manifest, blob, "processing", egress_id=egress_id)
    try:
        from app.jobs import jobs as _jobs
        await _jobs.enqueue(_jobs.RECORDING_FINALIZE,
                            {"token": token, "egress_id": egress_id, "blob": blob},
                            token=token)
    except Exception as e:
        logger.warning("[session %s] recording_finalize enqueue failed: %r", session_id, e)


async def _session_runner(
    broadcaster: WebBroadcaster,
    session_id: str,
    scheduled_token: str | None = None,
    stt: "session_lifecycle.stt_fallback.SttLease | None" = None,
    room_ready: "asyncio.Future[bool] | None" = None,
) -> None:
    """Block until the candidate clicks Start; then boot an InterviewSession
    wired to this broadcaster's audio source/sink and watch its lifecycle.

    If ``scheduled_token`` is set, the candidate's identity (name, role,
    resume) and the cadence YAML are pulled from the admin SQLite row +
    the session_dir on disk. Otherwise we fall back to the env/URL-param
    defaults that the candidate-only deploy has always used."""
    await broadcaster.start_signal.wait()
    # Full bring-up clock: start-click → first AI audio. Stashed on the broadcaster
    # so the first-audio handler (in _wire_bus_to_broadcaster) measures the WHOLE
    # window; the per-step _log_startup_step calls below break it down.
    _run_t0 = _time.monotonic()
    broadcaster._startup_run_t0 = _run_t0  # type: ignore[attr-defined]

    # Resolve identity + cadence path + resume text.
    candidate_name: str
    role: str
    cadence_path: Path
    resume_text: str
    scheduled_row = None
    # Set True when we load a precomputed resume summary (schedule-time worker job)
    # so the on-the-fly summarize step below is skipped — no resume LLM at start.
    used_precomputed = False
    if scheduled_token:
        try:
            from app import db as admin_db
            from app.paths import session_dir
        except ImportError:
            logger.error("[session %s] token=%s but admin/ not importable — refusing", session_id, scheduled_token)
            return
        _t0 = _time.monotonic()
        scheduled_row = await asyncio.to_thread(admin_db.get, scheduled_token)
        _log_startup_step("db_get", _t0)
        if scheduled_row is None:
            logger.error("[session %s] scheduled-token %r not in DB — refusing", session_id, scheduled_token)
            return
        sdir = session_dir(scheduled_token)
        candidate_name = scheduled_row["candidate_name"]
        role           = scheduled_row["role"]
        cadence_path   = sdir / "cadence.yaml"
        # Pull the PRECOMPUTED resume artifacts (parsed + summary) the
        # resume_summary worker wrote to sessions/{token}/resume/ at schedule
        # time. NO live parse/LLM here — just load: summary → truncated parsed →
        # nothing. Off-loop (tiny file reads + a best-effort blob fallback).
        used_precomputed = True
        _t0 = _time.monotonic()
        resume_text = await asyncio.to_thread(
            _load_precomputed_resume, sdir, scheduled_token, session_id,
        )
        _log_startup_step("resume_load", _t0)
        logger.info(
            "[session %s] scheduled-token loaded: candidate=%r role=%r cadence=%s resume_chars=%d",
            session_id, candidate_name, role, cadence_path, len(resume_text),
        )
    else:
        meta = broadcaster.candidate_meta or {}
        candidate_name = meta.get("name") or os.environ.get("DEFAULT_CANDIDATE_NAME", "Candidate")
        role           = meta.get("role") or os.environ.get("DEFAULT_ROLE",           "AI Engineer")
        cadence_path = Path(
            os.environ.get("CADENCE_PATH", REPO_ROOT / "engine" / "brain" / "cadence" / "default.yaml")
        )
        # Resume — defer to env-supplied text (deploy-side) or empty for v1.
        # Future: accept a resume upload over WS before {"type":"start"}.
        resume_text = os.environ.get("RESUME_TEXT", "")

    _t0 = _time.monotonic()
    cadence = await load_cadence(
        cadence_path=cadence_path,
        cadence_description_path=None,
        role=role,
        candidate_name=candidate_name,
        api_key=os.environ.get("GROQ_API_KEY", os.environ.get("OPENROUTER_API_KEY", "")),
        base_url=("https://api.groq.com/openai/v1"
                  if os.environ.get("GROQ_API_KEY") else "https://openrouter.ai/api/v1"),
        model=os.environ.get("SLOW_MODEL", "openai/gpt-oss-20b"),
    )
    _log_startup_step("cadence_load", _t0)

    # Resume → compact structured template (name + project headings + tech
    # stack). Keeps the slow LLM's system prompt small. Uses the SAME
    # provider/model the slow LLM uses — SLOW_MODEL is typically an
    # OpenRouter id (e.g. gpt-oss-120b:nitro), so it must hit the matching
    # endpoint. summarize_resume falls back to raw text internally on any
    # failure, so this never blocks the interview.
    if resume_text and not used_precomputed:
        from engine.orchestrator.resume_parser import summarize_resume
        _or_key   = os.environ.get("OPENROUTER_API_KEY", "")
        _groq_key = os.environ.get("GROQ_API_KEY", "")
        _slow_provider = os.environ.get("SLOW_PROVIDER", "").lower()
        if _slow_provider == "openai":
            _summ_key, _summ_base = os.environ.get("OPENAI_API_KEY", ""), "https://api.openai.com/v1"
        elif _slow_provider == "groq":
            _summ_key, _summ_base = _groq_key, "https://api.groq.com/openai/v1"
        elif _slow_provider == "openrouter" or _or_key:
            _summ_key, _summ_base = _or_key, "https://openrouter.ai/api/v1"
        else:
            _summ_key, _summ_base = _groq_key, "https://api.groq.com/openai/v1"
        _t0 = _time.monotonic()
        resume_text = await summarize_resume(
            resume_text,
            candidate_name=candidate_name,
            api_key=_summ_key,
            base_url=_summ_base,
            model=os.environ.get("SLOW_MODEL", "openai/gpt-oss-20b"),
        )
        _log_startup_step("resume_summarize", _t0)
        logger.info(
            "[session %s] resume summarized to compact template (%d chars)",
            session_id, len(resume_text),
        )

    config = _build_session_config(candidate_name, role, resume_text)
    config.cadence = cadence

    # Capacity broker: use the Speech key/provider leased for THIS session, so
    # the fleet stays inside the per-key stream cap (admission already granted
    # the slot in session_lifecycle.claim). Falls back to Groq STT when the
    # Azure pool was full at claim time.
    if stt is not None:
        try:
            if stt.provider == "azure":
                config.stt_provider = "azure"
                config.azure_speech_key = stt.key
                config.azure_speech_region = stt.region
            elif stt.provider == "groq":
                config.stt_provider = "groq"
            logger.info("[session %s] STT provider=%s (broker-leased)",
                        session_id, stt.provider)
        except Exception as e:
            logger.warning("[session %s] STT lease injection failed: %s", session_id, e)

    # Redirect the event log into the per-session folder when this is a
    # scheduled interview. `_build_session_config` defaults the path to
    # `/tmp/integration/events.jsonl` (a single shared file useful for
    # ad-hoc smoke tests), but admin's event_viewer + performance
    # evaluation BOTH read from `sessions/{token}/events.jsonl`. Without
    # this redirect the admin session detail page shows "No events"
    # and the performance dashboard scores 0/100 because it sees no
    # transcript. Local mode handles this in live_main.py's
    # --scheduled-token branch; this is the cloud equivalent.
    if scheduled_token:
        try:
            from app.paths import session_dir
            sdir = session_dir(scheduled_token)
            sdir.mkdir(parents=True, exist_ok=True)
            config.event_log_path = sdir / "events.jsonl"
            logger.info(
                "[session %s] event log → %s (per-session, admin-readable)",
                session_id, config.event_log_path,
            )
        except Exception as e:
            logger.warning("[session %s] event_log_path redirect failed: %s", session_id, e)

        # Disable Kokoro prewarm for scheduled sessions. The prewarm
        # synthesises a "Hi." utterance to warm the model — but the audio
        # plays into the WebBroadcaster's sink, which forwards it to the
        # candidate's browser. Result: the candidate hears 5-8 seconds
        # of "Hi." (or just silence-with-caption "Hi.") before the real
        # greeting. Same rationale as orchestrator_new/live_main.py:
        # for scheduled-token runs, `args.prewarm = False`. Cold-start
        # latency is acceptable; a phantom 8-second "Hi." is not.
        config.prewarm_kokoro = False
        logger.info("[session %s] prewarm_kokoro disabled (scheduled-token session)", session_id)

    # ── Media transport ──────────────────────────────────────────────────
    # Audio rides LiveKit (WebRTC) when MEDIA_TRANSPORT=livekit AND creds are
    # present AND this is a scheduled token (the room name). Otherwise the raw-
    # PCM WebSocket path (default, unchanged). Control/video/coding ALWAYS stay
    # on the broadcaster/WS regardless of this switch. The LiveKit imports are
    # lazy so the default path pulls in nothing new.
    # LiveKit only for an interview the page started through the room
    # (`room_ready` is set by the room start). A page that opened a WebSocket
    # gets WebSocket audio — it already chose that path.
    #
    # A room interview never switches to the WebSocket HERE: if LiveKit fails
    # (the agent can't connect, or the candidate never joins) the interview is
    # HANDED OFF — this runner stops without marking it completed, frees its
    # claim, and the page starts over on the WebSocket path, on an addressable
    # shard. That's what lets room interviews run on pool replicas nothing can
    # route a WebSocket to (Phase 3).
    _lk_transport = None
    _lk_egress_id = _lk_egress_blob = ""
    _clean_end = False

    def _report_room(ok: bool) -> None:
        if room_ready is not None and not room_ready.done():
            room_ready.set_result(ok)

    from engine.orchestrator.livekit import config as _lk_config
    if room_ready is not None:
        _lk = _lk_config.livekit_settings()
        try:
            if not (_lk_config.livekit_enabled() and scheduled_token and _lk.is_complete()):
                raise RuntimeError("LiveKit is not configured")
            from engine.orchestrator.livekit.tokens import agent_token
            from engine.orchestrator.livekit.transport import LiveKitTransport
            _agent_jwt = agent_token(_lk, room=scheduled_token)
            _lk_transport = LiveKitTransport(_lk.url, _agent_jwt, room_name=scheduled_token)
            # Bounded: an unreachable LiveKit must cost the candidate a few
            # seconds at start-up, not hang the interview before its greeting.
            _t_join = _time.monotonic()
            await asyncio.wait_for(_lk_transport.connect(),
                                   timeout=_lk_config.connect_timeout_s())
            _prom.LIVEKIT_JOIN_MS.labels(stage="agent_connect").observe(
                (_time.monotonic() - _t_join) * 1000)
            # Control messages ride the room's data channel from here on
            # (Phase 2); the page is told it may join.
            broadcaster.attach_room(_lk_transport.send_control,
                                    _lk_transport.candidate_present)
            _lk_transport.set_control_handler(broadcaster.handle_room_message)
            _report_room(True)
            _t_cand = _time.monotonic()   # the page may join from here
            # Server-side recording of both voices (1E), started NOW so its
            # few-second warm-up overlaps the candidate joining instead of
            # eating the greeting. Best-effort: the browser keeps recording in
            # parallel, so a failed start loses nothing that exists today.
            _lk_egress_t0 = _time.monotonic()
            _lk_egress_id, _lk_egress_blob = await _start_livekit_egress(
                _lk, scheduled_token, session_id)
            # Don't greet into the room before the candidate can hear (an SFU
            # keeps nothing for late joiners). If they never arrive, their
            # network can't reach LiveKit: hand off rather than run a silent
            # interview.
            if not await _lk_transport.wait_candidate_ready(
                    _lk_config.candidate_join_timeout_s()):
                raise TimeoutError("candidate never joined the room")
            _prom.LIVEKIT_JOIN_MS.labels(stage="candidate_ready").observe(
                (_time.monotonic() - _t_cand) * 1000)
            if _lk_egress_id:
                # Measured from the egress start, so it reads as "how long the
                # recorder took to warm up", whatever the candidate did meanwhile.
                if await _wait_livekit_egress_active(_lk, _lk_egress_id, session_id):
                        _prom.LIVEKIT_JOIN_MS.labels(stage="egress_active").observe(
                        (_time.monotonic() - _lk_egress_t0) * 1000)
            source, sink = _lk_transport.source, _lk_transport.sink
            logger.info("[session %s] media transport = LiveKit (room=%s)",
                        session_id, scheduled_token[:8])
        except Exception as e:
            logger.warning("[session %s] LiveKit unavailable (%r) — handing the "
                           "interview off to the WebSocket path", session_id, e)
            if not broadcaster.handover:
                _prom.INTERVIEW_HANDOFFS.labels(reason="livekit_unavailable").inc()
            broadcaster.handover = True
            _report_room(False)
            # A page already in the room only hears this through the room:
            # tell it, or it waits there for nobody.
            if _lk_transport is not None:
                try:
                    await _lk_transport.send_control(json.dumps(
                        {"type": "media_transport", "transport": "websocket"}))
                except Exception:
                    pass
            broadcaster.detach_room()
            if _lk_egress_id:
                await _stop_livekit_egress(_lk, _lk_egress_id, session_id, grace_s=0,
                                           token=scheduled_token, blob=_lk_egress_blob)
            if _lk_transport is not None:
                try:
                    await _lk_transport.close()
                except Exception:
                    pass
            broadcaster.handover = True
            raise _HandOff(str(e)) from e
    else:
        source = BrowserMicAudioSource(broadcaster.mic_queue)
        sink   = BrowserSpeakerAudioSink(broadcaster)
    # Which transport the brain listens on — re-sent to any page that attaches.
    broadcaster.set_media_transport("livekit" if _lk_transport is not None else "websocket")

    logger.info("[session %s] starting interview: %s / %s", session_id, candidate_name, role)
    # Use the admin-issued candidate token as the InterviewSession session_id
    # so Langfuse traces are tagged with the same UUID the admin's "View in
    # Langfuse" deep-link points at. Without this, traces get tagged with a
    # random uuid and the admin link lands on a "session expired" page.
    session_id_override: UUID | None = None
    if scheduled_token:
        try:
            session_id_override = UUID(scheduled_token)
        except ValueError:
            logger.warning(
                "[session %s] scheduled_token %r is not a valid UUID — "
                "Langfuse deep-link from admin will not resolve",
                session_id, scheduled_token,
            )

    # ── Durable resume (feature B) ──
    # A checkpoint existing for this token means its prior runner was lost
    # mid-interview (shard restart / crash / orphan evict) — resume the phase
    # instead of re-greeting. Keyed on checkpoint EXISTENCE, not DB status (the
    # `finally` below can flip status=completed even on a crash). `resume_count`
    # caps repeated crashes at the SAME phase; the writer resets it to 0 on each
    # phase transition (a new phase is a fresh start).
    resume_checkpoint: dict | None = None
    checkpoint_writer = None
    # The incremented resume-attempt count, persisted to Redis ONLY after bring-up
    # succeeds (see below) — so a cold-start bring-up crash never burns the budget.
    _pending_resume_bump: dict | None = None
    if scheduled_token:
        from app.coordination import interview_checkpoint
        _resume_max = int(os.environ.get("RESUME_MAX_ATTEMPTS", "2"))

        async def _write_checkpoint(phase_id: str, jsonable_turns: list,
                                    elapsed_ms: int = 0, kind: str = "phase",
                                    tracker: dict | None = None,
                                    phase_elapsed_ms: int = 0, seq: str = "",
                                    _tok: str = scheduled_token) -> bool:
            # Best-effort: bounded + swallow so a Redis hiccup never breaks a tick.
            # Returns True iff the Redis write actually landed (the caller emits a
            # checkpoint_written event carrying this, so a silent write failure is
            # visible in events.jsonl rather than masquerading as a lost resume).
            # `elapsed_ms_at_phase_entry` = total interview time when this phase
            # started, so a resume continues the cumulative clock instead of
            # restarting at 0 (see InterviewSession._resume_elapsed_offset_ms).
            try:
                await asyncio.wait_for(
                    interview_checkpoint.save(_tok, {
                        "v": 1, "phase_id": phase_id, "turns": jsonable_turns,
                        "resume_count": 0, "ts": _time.time(),
                        # The interview time to continue the cumulative clock from.
                        "elapsed_ms_at_phase_entry": int(elapsed_ms or 0),
                        # Phase 4: "turn" checkpoints carry the question cursor
                        # and the phase time used, so a resume continues
                        # mid-phase; "phase" ones reopen the phase.
                        "kind": kind, "tracker": tracker,
                        "phase_elapsed_ms": int(phase_elapsed_ms or 0), "seq": seq,
                    }),
                    timeout=2.0,
                )
                return True
            except Exception as e:
                logger.warning("[checkpoint] save failed token=%s phase=%s: %s",
                               _tok[:8], phase_id, e)
                return False
        checkpoint_writer = _write_checkpoint

        try:
            _ck = await interview_checkpoint.load(scheduled_token)
        except Exception as e:
            logger.warning("[checkpoint] load failed token=%s: %s",
                           scheduled_token[:8], e)
            _ck = None
        if _ck and (scheduled_row or {}).get("status") != "cancelled":
            _count = int(_ck.get("resume_count", 0) or 0)
            if _count >= _resume_max:
                logger.warning("[resume] token=%s hit resume cap (%d) — give-up",
                               scheduled_token[:8], _count)
                resume_checkpoint = {**_ck, "give_up": True}
            else:
                # Bump the attempt counter, but DON'T persist it yet. A crash
                # during BRING-UP (STT/VAD/TTS still cold-starting in the first
                # seconds after a shard restart) must NOT consume a resume attempt
                # — only a crash AFTER a successful bring-up (a genuinely poisoned
                # checkpoint that keeps crashing the resume itself) should count.
                # So the session gets the bumped count (for its trace/cap logic),
                # but we persist it to Redis only once __aenter__ succeeds (below).
                # The client's own reconnect cap backstops a shard that never comes
                # up, so this can't loop forever. Without this, a handful of
                # cold-start reconnects burned the whole budget and the interview
                # gave up before it could resume (observed 2026-07-30, c10502cc).
                _bumped = {**_ck, "resume_count": _count + 1, "ts": _time.time()}
                resume_checkpoint = _bumped
                _pending_resume_bump = _bumped
                logger.info("[resume] token=%s resuming phase=%s attempt=%d",
                            scheduled_token[:8], _ck.get("phase_id"), _count + 1)

    try:
        # Construct first, then attach DB lifecycle subscribers BEFORE
        # entering the context — `__aenter__` emits SESSION_STARTED, and
        # the bus dispatches via call_soon_threadsafe to subscribers
        # present at publish time. Subscribing AFTER `async with` enters
        # misses that event by milliseconds and the row never flips to
        # `in_progress`. Observed live in 2026-06-11 — every status gate
        # (dashboard counts, the "in progress" stage) relies on this flip.
        _t0 = _time.monotonic()
        _session_pre = InterviewSession(
            config=config, audio_source=source, audio_sink=sink,
            session_id=session_id_override,
            checkpoint_writer=checkpoint_writer,
            resume_checkpoint=resume_checkpoint,
        )
        _log_startup_step("session_construct", _t0)
        if scheduled_token:
            from engine.orchestrator.scheduled_session import attach_db_lifecycle
            attach_db_lifecycle(_session_pre, scheduled_token,
                                is_handover=lambda: broadcaster.handover)
        _t0 = _time.monotonic()
        async with _session_pre as session:
            # (lifecycle hooks already attached above so SESSION_STARTED
            # — emitted inside __aenter__ — reaches them.)
            # bring-up (STT/VAD/TTS connect etc.) happens in __aenter__; its
            # sub-steps are timed inside interview_session.py.
            _log_startup_step("bringup_aenter", _t0)

            # Bring-up succeeded — NOW persist the resume-attempt bump. Persisting
            # here (not before construction) means a bring-up crash during a shard
            # cold-start never consumes the resume budget; only a resume that got
            # this far and then fails counts toward the give-up cap.
            if _pending_resume_bump is not None:
                try:
                    from app.coordination import interview_checkpoint as _ckpt
                    await asyncio.wait_for(
                        _ckpt.save(scheduled_token, _pending_resume_bump), timeout=2.0)
                except Exception as e:
                    logger.warning("[resume] resume_count persist failed: %s", e)

            _wire_bus_to_broadcaster(session, broadcaster)

            async def watch_end() -> None:
                await broadcaster.end_signal.wait()
                logger.info("[session %s] end signal from browser — stopping", session_id)
                session.request_stop()

            end_watcher = asyncio.create_task(watch_end(), name=f"end-watcher-{session_id}")
            try:
                await session.run_until_signal()
                _clean_end = True
            finally:
                end_watcher.cancel()
    finally:
        # The page hears "session_end" through the room, so on a clean end it
        # must go out BEFORE the agent leaves. Not on a crash: the page then
        # sees the agent leave and rejoins, which resumes from the checkpoint.
        if _clean_end and _lk_transport is not None:
            broadcaster.emit_session_end()
            await broadcaster.flush()
        # Disconnect the LiveKit room (agent leaves; egress, if any, stops with
        # the room). The InterviewSession already stopped source/sink in its
        # __aexit__; this releases the WebRTC connection itself.
        if _lk_egress_id:
            await _stop_livekit_egress(_lk, _lk_egress_id, session_id,
                                       token=scheduled_token, blob=_lk_egress_blob)
        if _lk_transport is not None:
            try:
                await _lk_transport.close()
            except Exception as e:  # pragma: no cover — never break teardown
                logger.warning("[session %s] LiveKit close failed: %s", session_id, e)
        # Belt-and-suspenders: ensure status=completed even if the
        # event-bus hook didn't fire (e.g. crashed mid-tick). The shared
        # hook above is idempotent, so a double-write is harmless.
        # Not on a hand-off: the interview goes on elsewhere (another replica
        # took it, or the page restarts it on the WebSocket path), so it isn't
        # completed — and a lost lease means another replica is running it NOW.
        if scheduled_token and not broadcaster.handover:
            try:
                from app import db as admin_db
                await asyncio.to_thread(
                    admin_db.update, scheduled_token,
                    status="completed", ended_at=admin_db.now_iso(),
                )
            except Exception as e:
                logger.warning("[session %s] DB status=completed fallback update failed: %s", session_id, e)

    broadcaster.emit_session_end()
    logger.info("[session %s] interview complete — enqueuing post-session evaluation", session_id)

    # Scoring (~30-60s of LLM) must NOT block the live session tier. Mirror the
    # transcript to Blob first (so the worker, on another container, can read it),
    # then enqueue an eval_v2 job. The worker writes evaluation.json back to Blob;
    # the gateway serves it read-through. Falls back to inline eval only if the
    # queue is unavailable, so a mis-provisioned deploy still produces a score.
    if scheduled_token:
        try:
            from app.blob_store import upload_session_artifacts
            upload_session_artifacts(scheduled_token)
        except Exception as e:
            logger.warning("[session %s] blob artifact mirror failed: %s", session_id, e)
        try:
            from app.jobs import jobs as _jobs
            job_id = await _jobs.enqueue(_jobs.EVAL_V2, {"token": scheduled_token},
                                         token=scheduled_token)
            logger.info("[session %s] eval_v2 enqueued job=%s", session_id, job_id[:8])
        except Exception as e:
            logger.warning("[session %s] eval enqueue failed (%s) — running inline", session_id, e)
            from engine.orchestrator.scheduled_session import generate_post_session_evaluation
            await generate_post_session_evaluation(scheduled_token)


def _wire_bus_to_broadcaster(session, broadcaster: WebBroadcaster) -> None:
    """Same plumbing as WebLauncher.attach + _subscribe_to_bus, inlined.

    Subscribes to the InterviewSession's event bus and translates:
      TTS_AUDIO_START → audio_start (with text from a per-utterance cache)
      TTS_AUDIO_END   → audio_end
      TTS_CANCELLED   → audio_cancel
      STT_PARTIAL     → stt_partial (live transcript)
      STT_FINAL       → stt_final
    """
    from engine.brain.contracts.events import EventKind

    # Per-utterance text cache — fed by patching TTSClient.speak_chunk so
    # filler / apology / STT-wait code paths also publish text the browser
    # can render. See orchestrator_new.web.launcher for rationale.
    sub_text: dict[str, str] = {}
    # sub_id → when the utterance should have finished playing, for the
    # "finished playing" lag: how long after that the page confirmed it (its
    # quiet window, jitter buffer, network). Popped by the ack; bounded in case
    # acks never come.
    _audio_end_at: dict[str, float] = {}
    # Startup timer: wall time from bus-wiring (≈ session start) to the FIRST AI
    # audio. Emitted once via log_timing → shows up as the
    # session/startup_to_first_audio stage on /metrics, making "slow to start"
    # a measurable number instead of a log hunt.
    # Prefer the start-click clock stashed by _session_runner so this measures the
    # WHOLE start-click → first-audio window (bring-up included). Falls back to now
    # for the ad-hoc no-token path that doesn't set it.
    _startup_t0 = getattr(broadcaster, "_startup_run_t0", None) or _time.monotonic()
    _first_audio_seen = [False]
    # Per-session hint counter — mirrors launcher.py. Key=f"{phase_id}::{qid}"
    # so multi-question phases keep an independent hint level per question.
    _hint_levels: dict[str, int] = {}
    # Submitted question ids per phase. Multi-question coding phases only
    # advance once every qid in coding_question_ids has fired a
    # coding_code_submitted.
    _submitted_qids: dict[str, set[str]] = {}
    tracer_ref = session._tracer
    tts = session._tts
    original_speak = tts.speak_chunk

    async def patched_speak_chunk(turn_id, sequence_id, text):
        sub_id = f"{turn_id}-{sequence_id}"
        if text and text.strip():
            sub_text[sub_id] = text
        return await original_speak(turn_id, sequence_id, text)

    tts.speak_chunk = patched_speak_chunk  # type: ignore[method-assign]

    # Coding feature: bus kind → outbound WS type. Mirrors
    # orchestrator_new.web.launcher._subscribe_to_bus. Same mapping.
    _CODING_OUTBOUND: dict[str, str] = {
        "coding_phase_started": "coding_phase_start",
        "coding_phase_ended": "coding_phase_end",
        "coding_hint_delivered": "coding_hint",
        # Fired once per session by the director if the cadence has a
        # coding phase. Browser lazy-imports coding_panel.js + starts
        # Pyodide download in the background.
        "coding_preload": "coding_preload",
    }

    # Visual Scenario Analysis: bus kind → outbound WS type. Mirrors
    # orchestrator_new.web.launcher._subscribe_to_bus's _SCENARIO_OUTBOUND.
    _SCENARIO_OUTBOUND: dict[str, str] = {
        "scenario_item_dispatched": "scenario_item_start",
        "scenario_phase_ended": "scenario_phase_end",
    }

    def _payload_to_dict(payload) -> dict:
        if isinstance(payload, dict):
            return payload
        if hasattr(payload, "__dict__"):
            return {k: v for k, v in vars(payload).items() if not k.startswith("_")}
        return {}

    async def _on_event(evt) -> None:
        try:
            kind = evt.kind.value if hasattr(evt.kind, "value") else evt.kind
            p = evt.payload or {}
            if kind == EventKind.TTS_AUDIO_START.value:
                sub_id = p.get("request_id") or p.get("turn_id_subbed", "")
                _cached = sub_text.pop(sub_id, "")
                # Resume-announce lines are audio-only: spoken + logged
                # server-side (resume_announce event), but MUST NOT appear in the
                # UI transcript/caption. Empty text → the client renders no row;
                # the audio still plays and its playback-finished ack still fires.
                text = "" if str(sub_id).startswith("resume-") else _cached
                broadcaster.emit_audio_start(text, sub_id=sub_id)
                # Await this utterance's real playback-finished ack: bytes_buffered()
                # now reports "still playing" until the browser confirms, so the
                # silence timer + wrap-up gate fire at real playout end, not
                # generation end. Set BEFORE the PCM/drain to avoid a race.
                try:
                    _exp = getattr(session._sink, "expect_playout", None)
                    if callable(_exp):
                        _exp(sub_id)
                except Exception:
                    pass
                if not _first_audio_seen[0]:
                    _first_audio_seen[0] = True
                    try:
                        from engine.brain.observability.timing import log_timing
                        log_timing(logger, "session", "startup_to_first_audio",
                                   (_time.monotonic() - _startup_t0) * 1000.0)
                    except Exception:
                        pass
            elif kind == EventKind.TTS_AUDIO_END.value:
                # When the candidate should stop hearing it: now plus whatever
                # the sink still has to play (TTS finishes generating long
                # before playback does).
                try:
                    _left = float(session._sink.remaining_playout_s())
                except Exception:
                    _left = 0.0
                _audio_end_at[str(p.get("request_id", ""))] = _time.monotonic() + max(0.0, _left)
                broadcaster.emit_audio_end(sub_id=p.get("request_id", ""),
                                           duration_ms=p.get("duration_ms"))
            elif kind == EventKind.TTS_CANCELLED.value:
                broadcaster.emit_audio_cancel(sub_id=p.get("request_id", ""))
            elif kind == EventKind.STT_PARTIAL.value:
                broadcaster.emit_stt_partial(
                    p.get("text") or p.get("transcript") or "",
                    speaker=p.get("speaker") or "",
                )
            elif kind == EventKind.STT_FINAL.value:
                broadcaster.emit_stt_final(
                    p.get("text") or p.get("transcript") or "",
                    speaker=p.get("speaker") or "",
                )
            elif kind == EventKind.PHASE_CHANGED.value:
                # Only the APPLIED transition reflects the live phase — queued
                # (queued=True) phase_changed events haven't taken effect yet.
                if not p.get("queued"):
                    broadcaster.emit_phase(p.get("to_phase") or p.get("to") or "")
            elif isinstance(kind, str) and kind in _CODING_OUTBOUND:
                broadcaster.emit_coding_event(_CODING_OUTBOUND[kind], _payload_to_dict(p))
            elif isinstance(kind, str) and kind in _SCENARIO_OUTBOUND:
                broadcaster.emit_scenario_event(_SCENARIO_OUTBOUND[kind], _payload_to_dict(p))
        except Exception as e:
            logger.warning("[bus->web] event handler error: %s", e)

    session._bus.subscribe(_on_event)

    # Seed the opening phase now. SESSION_STARTED already fired inside
    # __aenter__ (this wiring runs after `async with` enters), so read the
    # current phase off session state directly. Live transitions arrive via
    # the PHASE_CHANGED branch above.
    try:
        broadcaster.emit_phase(getattr(session._state, "phase", "") or "")
    except Exception:
        pass

    # ── Coding feature: install inbound dispatch (parity with launcher) ──
    # Same wiring as orchestrator_new.web.launcher._subscribe_to_bus. Cloud
    # uses this code path instead of the launcher's, so we replicate it.
    try:
        from features.coding import is_enabled as _coding_is_enabled
        from features.coding.messages import is_coding_message as _is_coding_msg
    except ImportError:
        _coding_is_enabled = lambda: False  # type: ignore[assignment]
        _is_coding_msg = lambda _p: False  # type: ignore[assignment]

    if _coding_is_enabled():
        # Tracer (not bus.publish) is the right path: it constructs an
        # Event object and forwards to the bus, AND lands it in
        # events.jsonl. EventBus has no .publish() method — only
        # publish_sync(Event). Mirrors orchestrator_new.web.launcher.
        tracer_ref = session._tracer
        _CODING_INBOUND: dict[str, str] = {
            "coding_code_submitted": "coding_code_submitted",
            "coding_code_run_result": "coding_code_run_result",
            "coding_code_run": "coding_code_run",
            "coding_code_edit": "coding_code_edit",
            "coding_hint_request": "coding_hint_requested",
            "coding_anti_cheat": "coding_anti_cheat",
            "coding_preload_ready": "coding_preload_ready",
            "coding_force_talk": "coding_force_talk_requested",
            "coding_panel_closed": "coding_panel_closed",
        }

        async def _on_coding_inbound(payload: dict) -> None:
            if not _is_coding_msg(payload):
                return
            ws_type = payload.get("type", "")
            bus_kind = _CODING_INBOUND.get(ws_type)
            if bus_kind:
                try:
                    tracer_ref.event(bus_kind, **payload)
                except Exception as e:
                    logger.warning(
                        "[bus->web] coding tracer.event %s failed: %s",
                        bus_kind, e,
                    )

            # Panel-close ack: the browser unmounted the coding editor. Release
            # the director's code-discussion handshake so the next phase's opening
            # turn can dispatch (it was holding so the AI doesn't talk over a live
            # editor). See Director.on_coding_panel_closed.
            if ws_type == "coding_panel_closed":
                try:
                    session._director.on_coding_panel_closed()
                except Exception as e:
                    logger.warning("[coding] panel_closed handling failed: %s", e)

            # Hint request: voice the next hint via TTS and emit
            # coding_hint_delivered for the browser banner. Ported from
            # orchestrator_new.web.launcher:376-432.
            if ws_type == "coding_hint_request":
                try:
                    phase_id = payload.get("phase_id", "")
                    from features.coding import resolve_question
                    from features.coding.events import (
                        CODING_HINT_DELIVERED as _CHD,
                    )
                    cur_phase_obj = session._tracker.plan.get_phase(phase_id)
                    qid = payload.get("question_id") or ""
                    if not qid:
                        qids = getattr(cur_phase_obj, "coding_question_ids", []) or []
                        qid = qids[0] if qids else ""
                    if qid:
                        # Pool-authored questions live in the cadence, not the
                        # built-in library — resolve_question covers both.
                        q = resolve_question(
                            qid,
                            getattr(cur_phase_obj, "coding_questions_inline", None) or {},
                        )
                        hint_key = f"{phase_id}::{qid}"
                        level = _hint_levels.get(hint_key, 0)
                        if level < len(q.hints):
                            hint_text = q.hints[level]
                            _hint_levels[hint_key] = level + 1
                            announce_level = level + 1
                        else:
                            hint_text = (
                                "You've used all available hints. "
                                "Try clicking Talk to AI to ask a specific question."
                            )
                            announce_level = level
                        tracer_ref.event(
                            _CHD,
                            phase_id=phase_id,
                            question_id=qid,
                            hint_level=announce_level,
                            hint_text=hint_text,
                        )
                        try:
                            tts_inst = session._tts
                            turn_id = f"hint-{phase_id}-{qid}-{announce_level}"
                            spoken = f"Hint: {hint_text}"
                            await tts_inst.speak_chunk(turn_id, 1, spoken)
                            logger.info(
                                "[coding] cloud hint TTS dispatched phase=%s qid=%s level=%d",
                                phase_id, qid, announce_level,
                            )
                        except Exception as tts_e:
                            logger.warning(
                                "[coding] cloud hint TTS failed: %s "
                                "(text still delivered to browser)", tts_e,
                            )
                except Exception as e:
                    logger.warning("[coding] cloud hint dispatch failed: %s", e)

            # Force-talk: candidate clicked "Talk to AI" while in coding
            # phase. Unblock the director's dispatch gate so the AI can
            # respond on the next tick.
            if ws_type == "coding_force_talk":
                try:
                    from engine.brain.contracts.session_state import (
                        AIActivityState as _AIState,
                    )
                    async def _unmute_for_force_talk(s):
                        s.ai_activity = _AIState.IDLE
                        s.candidate_spoke_since_last_ai = True
                    await session._store.mutate(_unmute_for_force_talk)
                    logger.info("[coding] cloud force_talk — ai_activity unblocked")
                except Exception as e:
                    logger.warning("[coding] cloud force_talk failed: %s", e)

            # Auto-advance on Submit (same as launcher)
            if ws_type == "coding_code_submitted":
                try:
                    from engine.brain.contracts.session_state import (
                        AIActivityState as _AIState,
                    )
                    # Capture submission into session state so the next
                    # phase's slow LLM sees code + tests. Mirror of
                    # orchestrator_new.web.launcher capture block.
                    try:
                        from features.coding import resolve_question as _cd_resolve_q
                        sub_phase_id = payload.get("phase_id", "")
                        sub_qid = payload.get("question_id") or ""
                        ph = session._tracker.plan.get_phase(sub_phase_id)
                        phase_qids = list(
                            getattr(ph, "coding_question_ids", []) or []
                        )
                        if not sub_qid and phase_qids:
                            sub_qid = phase_qids[0]
                        q_prompt = ""
                        fn_name = ""
                        if sub_qid:
                            _q = _cd_resolve_q(
                                sub_qid,
                                getattr(ph, "coding_questions_inline", None) or {},
                            )
                            q_prompt = _q.prompt or ""
                            fn_name = _q.function_name or ""
                        sub_snapshot = {
                            "phase_id": sub_phase_id,
                            "question_id": sub_qid or "",
                            "question_prompt": q_prompt,
                            "function_name": fn_name,
                            "code": payload.get("final_code", ""),
                            "test_results": payload.get("final_test_results", []),
                            "runs_used": payload.get("runs_used", 0),
                        }
                        async def _capture_submission(s):
                            s.last_coding_submission = sub_snapshot
                        await session._store.mutate(_capture_submission)
                        logger.info(
                            "[coding] cloud captured submission phase=%s qid=%s "
                            "code_len=%d tests=%d",
                            sub_phase_id, sub_qid, len(sub_snapshot["code"]),
                            len(sub_snapshot["test_results"]),
                        )
                        # Wait for ALL questions before advancing.
                        submitted_set = _submitted_qids.setdefault(
                            sub_phase_id, set()
                        )
                        submitted_set.add(sub_qid)
                        remaining = [
                            q for q in phase_qids if q not in submitted_set
                        ]
                        if remaining:
                            logger.info(
                                "[coding] cloud partial submit on phase=%s — "
                                "%d/%d done, waiting on %r",
                                sub_phase_id, len(submitted_set),
                                len(phase_qids), remaining,
                            )
                            return
                        logger.info(
                            "[coding] cloud ALL %d question(s) submitted on "
                            "phase=%s — advancing", len(phase_qids),
                            sub_phase_id,
                        )
                    except Exception as cap_e:
                        logger.warning(
                            "[coding] cloud failed to capture submission: %s",
                            cap_e,
                        )
                    cur_phase = session._store.state.phase
                    next_id = session._tracker.plan.next_phase_id(cur_phase)
                    if next_id is None:
                        # Terminal coding phase: arm the wrap-up auto-end gate
                        # AND dispatch a brief TTS farewell so the candidate
                        # gets a graceful exit. AUDIO_END from that farewell
                        # is what the director's auto-end check waits for.
                        async def _exit_coding(s):
                            s.ai_activity = _AIState.AUDIO_DONE
                        await session._store.mutate(_exit_coding)
                        try:
                            session._director.request_session_end(
                                reason="coding_submit_terminal",
                            )
                            tts_inst = session._tts
                            await tts_inst.speak_chunk(
                                f"end-{cur_phase}", 1,
                                "Thanks for your submission. We'll be in touch soon.",
                            )
                        except Exception as ee:
                            logger.warning(
                                "[coding] cloud terminal-end TTS failed: %s", ee,
                            )
                        logger.info(
                            "[coding] cloud submit on terminal phase %s — "
                            "session end armed", cur_phase,
                        )
                    else:
                        async def _advance(s):
                            s.pending_phase = next_id
                            s.ai_activity = _AIState.AUDIO_DONE
                        await session._store.mutate(_advance)
                        logger.info(
                            "[coding] cloud auto-advance: %s → %s",
                            cur_phase, next_id,
                        )
                except Exception as e:
                    logger.warning("[coding] cloud submit advance failed: %s", e)

        broadcaster.set_coding_inbound_callback(_on_coding_inbound)
        logger.info("[bus->web] coding feature enabled — cloud inbound dispatch installed")

    # ── Visual Scenario Analysis: inbound dispatch (parity with launcher) ──
    # Installed UNCONDITIONALLY (no separate feature flag, unlike coding) —
    # Director.on_scenario_media_ack is already a no-op when no scenario
    # phase is active.
    async def _on_scenario_inbound(payload: dict) -> None:
        ws_type = payload.get("type", "")
        if ws_type not in (
            "scenario_media_ended", "scenario_media_error", "scenario_media_skipped",
        ):
            return
        try:
            session._director.on_scenario_media_ack(ws_type)
        except Exception as e:
            logger.warning("[bus->web] scenario media ack failed: %s", e)

    broadcaster.set_scenario_inbound_callback(_on_scenario_inbound)

    async def _on_audio_ack(parsed: dict) -> None:
        """Candidate browser confirmed TTS playback progress on the speaker.
        On 'audio_playback_finished' we clear the sink's playout wait for that
        sub_id → bytes_buffered() drops to 0 → the orchestrator finalizes the turn
        (AUDIO_DONE, silence-timer start) at REAL playback end, and __aexit__'s
        wrap-up hold is released. 'audio_playback_started' is accepted but unused."""
        try:
            if parsed.get("type") != "audio_playback_finished":
                return
            sub_id = str(parsed.get("sub_id", ""))
            _due = _audio_end_at.pop(sub_id, None)
            # Negative = the page confirmed before the server expected the
            # audio to end: signed in the event log, counted apart in metrics.
            _lag_ms = round((_time.monotonic() - _due) * 1000) if _due is not None else None
            if _lag_ms is not None:
                _tr = broadcaster.media_transport or "websocket"
                if _lag_ms < 0:
                    _prom.PLAYBACK_ACK_EARLY.labels(transport=_tr).inc()
                else:
                    _prom.PLAYBACK_ACK_LAG_MS.labels(transport=_tr).observe(_lag_ms)
            if len(_audio_end_at) > 64:   # acks that never came (barge-in, refresh)
                _audio_end_at.clear()
            # Observability: record the REAL moment the candidate's speaker
            # finished this utterance (the browser ack). This is the reference
            # the silence timer keys off; logging it makes that timing auditable
            # in events.jsonl. `grounded` = the ack came from the audio engine's
            # buffer-ended event (true) vs a wall-clock estimate (false).
            try:
                session._tracer.event(
                    "audio_playback_finished",
                    sub_id=sub_id, grounded=bool(parsed.get("grounded")),
                    via=str(parsed.get("via", "")), lag_ms=_lag_ms,
                )
            except Exception:
                pass
            mark = getattr(session._sink, "mark_played", None)
            if callable(mark):
                mark(sub_id)
        except Exception as e:
            logger.warning("[audio-ack] handler error: %s", e)

    broadcaster.set_audio_ack_callback(_on_audio_ack)

    async def _on_mic_mute(muted: bool) -> None:
        """Candidate muted/unmuted their mic. Forwarded to the director, which
        closes an in-flight utterance on mute — the VAD cannot, because mute
        stops the frames the endpoint is made of."""
        try:
            director = getattr(session, "_director", None)
            if director is not None:
                await director.on_mic_muted(muted)
        except Exception as e:
            logger.warning("[mic-mute] handler error: %s", e)

    broadcaster.set_mic_mute_callback(_on_mic_mute)
