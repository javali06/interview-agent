#!/usr/bin/env bash
# Build the shared base image, then the three tier images on top of it.
#
#   deploy/build_tiers.sh local     # local `docker build`, :local tags (for compose)
#   deploy/build_tiers.sh acr       # `az acr build` → push to ACR (for ACA)
#
# Env: ACR_NAME (default interviewagentacr), RESOURCE_GROUP (AI-COE), TAG,
#   CONTAINER_CMD (default docker — set CONTAINER_CMD=podman on a box where
#   Docker Desktop's engine isn't running but podman is; deploy/local's compose
#   stack only needs the :local image TAGS, so either builder works).
set -euo pipefail
MODE="${1:-local}"
ACR_NAME="${ACR_NAME:-interviewagentacr}"
RG="${RESOURCE_GROUP:-AI-COE}"
TAG="${TAG:-local}"
CONTAINER_CMD="${CONTAINER_CMD:-docker}"
cd "$(dirname "$0")/.."   # repo root (build context)

TIERS=(gateway worker session text)

if [ "$MODE" = "acr" ]; then
  REG="${ACR_NAME}.azurecr.io"
  echo ">> base → ${REG}/interview-agent-base:${TAG}"
  az acr build -r "$ACR_NAME" -g "$RG" \
    -t "interview-agent-base:${TAG}" -f deploy/Dockerfile.base .
  for tier in "${TIERS[@]}"; do
    echo ">> ${tier} → ${REG}/interview-agent-${tier}:${TAG}"
    az acr build -r "$ACR_NAME" -g "$RG" \
      -t "interview-agent-${tier}:${TAG}" -f "deploy/Dockerfile.${tier}" \
      --build-arg BASE_IMAGE="${REG}/interview-agent-base:${TAG}" .
  done
  # Observability images (in-ACA Prometheus + Grafana dashboard). Standalone
  # Dockerfiles (NOT on the shared base) — built at the same TAG so a bump ships
  # scrape-config / dashboard changes too. Cloud-only: local uses the stock
  # prom/grafana images with bind-mounts (docker compose --profile obs).
  for img in prometheus grafana; do
    echo ">> obs:${img} → ${REG}/interview-agent-${img}:${TAG}"
    az acr build -r "$ACR_NAME" -g "$RG" \
      -t "interview-agent-${img}:${TAG}" \
      -f "deploy/aca/observability/Dockerfile.${img}" .
  done
  echo "pushed ${REG}/interview-agent-{base,${TIERS[*]// /,},prometheus,grafana}:${TAG}"
else
  echo ">> base → interview-agent-base:${TAG} (via ${CONTAINER_CMD})"
  "$CONTAINER_CMD" build -f deploy/Dockerfile.base -t "interview-agent-base:${TAG}" .
  for tier in "${TIERS[@]}"; do
    echo ">> ${tier} → interview-agent-${tier}:${TAG}"
    "$CONTAINER_CMD" build -f "deploy/Dockerfile.${tier}" \
      --build-arg BASE_IMAGE="interview-agent-base:${TAG}" \
      -t "interview-agent-${tier}:${TAG}" .
  done
  echo "built interview-agent-{base,${TIERS[*]// /,}}:${TAG}"
fi
