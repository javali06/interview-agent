<#
.SYNOPSIS
  RETIRED — the single-webapp deploy this script performed no longer exists.

.DESCRIPTION
  This used to build one `interview-agent` image and repin the
  `interview-ai-backend` App Service to its digest. That App Service is GONE.
  The app now runs as tiered Azure Container Apps (gateway / session-* / worker)
  behind Front Door, so the old flow fails with `ResourceNotFound`.

  Rather than ship an untested PowerShell ACA deploy, this script now refuses and
  prints the correct procedure. On Windows the simplest path is WSL + the bash
  script `deploy/deploy.sh <tag>`. Full guide: docs/reading/05-cloud-deploy-runbook.md.
#>

$ErrorActionPreference = 'Stop'
$Tag = if ($args.Count -ge 1) { $args[0] } else { 'v<N>' }
$Reg = 'interviewagentacr.azurecr.io'

Write-Host ""
Write-Host "  deploy.ps1 is retired — the single-webapp deploy no longer exists." -ForegroundColor Yellow
Write-Host "  The app runs as tiered Azure Container Apps. Deploy like this:" -ForegroundColor Yellow
Write-Host ""
Write-Host "  Easiest (WSL / Git Bash):"
Write-Host "    bash deploy/deploy.sh $Tag"
Write-Host ""
Write-Host "  Or run the steps directly (build tier images at a NEW tag, then roll the apps):"
Write-Host "    # 1. build + push (base -> gateway/worker/session, then obs)"
Write-Host "    az acr build -r interviewagentacr -g AI-COE -t interview-agent-base:$Tag    -f deploy/Dockerfile.base ."
Write-Host "    foreach (`$t in 'gateway','worker','session') {"
Write-Host "      az acr build -r interviewagentacr -g AI-COE -t interview-agent-`$t`:$Tag -f deploy/Dockerfile.`$t ``"
Write-Host "        --build-arg BASE_IMAGE=$Reg/interview-agent-base:$Tag ."
Write-Host "    }"
Write-Host "    # 2. roll the RUNNING apps (leave a deliberately-stopped shard alone)"
Write-Host "    az containerapp update -g AI-COE -n gateway   --image $Reg/interview-agent-gateway:$Tag"
Write-Host "    az containerapp update -g AI-COE -n worker    --image $Reg/interview-agent-worker:$Tag"
Write-Host "    az containerapp update -g AI-COE -n session-0 --image $Reg/interview-agent-session:$Tag"
Write-Host "    az containerapp update -g AI-COE -n session-1 --image $Reg/interview-agent-session:$Tag"
Write-Host "    # 3. verify"
Write-Host "    `$gw = az containerapp show -g AI-COE -n gateway --query properties.configuration.ingress.fqdn -o tsv"
Write-Host "    curl https://`$gw/healthz/live ; curl https://`$gw/ready"
Write-Host ""
Write-Host "  Full runbook: docs/reading/05-cloud-deploy-runbook.md"
Write-Host ""
exit 2
