"""Gunicorn worker class with looser WebSocket keepalive defaults.

Why a custom class:
    UvicornWorker's CONFIG_KWARGS lets us preset uvicorn kwargs that
    gunicorn's CLI can't pass through. Defaults are
        ws_ping_interval=20.0
        ws_ping_timeout=20.0
    which is too tight for browsers that throttle background tabs —
    a slow pong gets the connection killed mid-interview.

Bumping to 30s ping + 60s timeout:
    - Server pings the client every 30s (keeps Azure ARR's 240s idle
      timer reset).
    - Client has 60s to pong back. Background-throttled Chrome tabs
      typically pong within 5-10s, so this is comfortable.
    - Genuinely-dead clients (browser crashed, network gone) still get
      reaped within ~90s.

Also raising ws_max_size from the 16 MiB default → still 16 MiB but
explicit; mic + AI audio frames are well below this.
"""
from __future__ import annotations

from uvicorn.workers import UvicornWorker


class WSResilientWorker(UvicornWorker):
    """UvicornWorker with WebSocket keepalive tuned for unreliable
    candidate browsers (background throttling, mobile, lossy WiFi)."""

    CONFIG_KWARGS = {
        # Background-tab-throttling-tolerant ping defaults.
        "ws_ping_interval": 30.0,
        "ws_ping_timeout": 60.0,
        # 16 MiB cap — same as uvicorn's default, made explicit.
        "ws_max_size": 16 * 1024 * 1024,
    }
