#!/usr/bin/env bash
# Build the container image and push to Azure Container Registry (ACR).
#
# Two paths — pick whichever fits your setup:
#
#   (A) az acr build  — builds the image IN AZURE on ACR's infra.
#                       No Docker Desktop required. Recommended for first-time
#                       deploys or if you don't want to install Docker locally.
#                       Builds typically take 8-15 min (ACR has fast network +
#                       cached base images).
#
#   (B) docker build + push — local build (~5 min if PyTorch is cached) then
#                       docker push (~1-2 min depending on uplink). Faster for
#                       iterative work if you have Docker Desktop running.
#
# Usage:
#   bash deploy/build_and_push.sh acr     # path (A) — recommended for first time
#   bash deploy/build_and_push.sh local   # path (B) — needs Docker Desktop
#
# Environment variables (override the defaults shown):
#   ACR_NAME       — name of your ACR (no .azurecr.io suffix). Default: interviewagentacr
#   IMAGE_NAME     — repo name inside ACR.                     Default: interview-agent
#   IMAGE_TAG      — tag for this build.                        Default: latest
#   RESOURCE_GROUP — Azure RG containing the ACR.               Default: AI-COE
#
# Examples:
#   ACR_NAME=mycoacr bash deploy/build_and_push.sh acr
#   IMAGE_TAG=$(git rev-parse --short HEAD) bash deploy/build_and_push.sh local

set -euo pipefail

# ── Defaults (override via env) ───────────────────────────────────────────
ACR_NAME="${ACR_NAME:-interviewagentacr}"
IMAGE_NAME="${IMAGE_NAME:-interview-agent}"
IMAGE_TAG="${IMAGE_TAG:-latest}"
RESOURCE_GROUP="${RESOURCE_GROUP:-AI-COE}"

ACR_LOGIN_SERVER="${ACR_NAME}.azurecr.io"
FULL_IMAGE="${ACR_LOGIN_SERVER}/${IMAGE_NAME}:${IMAGE_TAG}"

MODE="${1:-acr}"

# ── Sanity checks ─────────────────────────────────────────────────────────
REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

if [[ ! -f deploy/Dockerfile ]]; then
    echo "ERROR: deploy/Dockerfile not found. Are you running from the repo root?"
    exit 2
fi

# ── Auto-stash directories `az acr build` would otherwise upload ─────────
# `az acr build` 2.70 does NOT honor `.dockerignore` or
# `deploy/Dockerfile.dockerignore` reliably — it ships the entire build
# context to ACR regardless. With `demo/` (a 1 GB stale local worktree
# that lives at the repo root) present, the tar tops out at 313 MB and
# the upload alone takes 10+ minutes.
#
# Workaround: physically move large unwanted dirs to /tmp before the
# upload, restore them afterwards so local dev (`./run_app.sh`, which
# uses `.venv` → demo/.venv) keeps working. Trap on EXIT so a Ctrl-C
# still restores. Each entry is independent — we skip silently if not
# present (so this script works in CI / fresh clones without `demo/`).
_STASH_DIR="/tmp/build_stash_$$"
_stashed_paths=()
mkdir -p "$_STASH_DIR"

stash_if_present() {
    local p="$1"
    if [[ -e "$p" || -L "$p" ]]; then
        mv "$p" "$_STASH_DIR/$(basename "$p")"
        _stashed_paths+=("$p")
        echo "  [stash] $p → $_STASH_DIR/"
    fi
}

restore_stash() {
    # `set -u` is active and `${arr[@]}` on an empty array trips it on
    # older bash; guard with the `:-` default-empty expansion so the
    # trap runs cleanly even when nothing was stashed (e.g. when this
    # script is rerun after a manual stash already happened).
    local p
    for p in "${_stashed_paths[@]:-}"; do
        [[ -z "$p" ]] && continue
        mv "$_STASH_DIR/$(basename "$p")" "$p" 2>/dev/null && echo "  [restore] $p"
    done
    rmdir "$_STASH_DIR" 2>/dev/null || true
}

trap restore_stash EXIT INT TERM

echo "── Stashing local-only dirs out of build context ────────────"
stash_if_present "demo"
stash_if_present ".venv"
echo "  context size: $(du -sh "$REPO_ROOT" 2>/dev/null | awk '{print $1}')"
echo "─────────────────────────────────────────────────────────────"

# ── Path (A): az acr build ────────────────────────────────────────────────
if [[ "$MODE" == "acr" ]]; then
    if ! command -v az >/dev/null 2>&1; then
        echo "ERROR: 'az' (Azure CLI) not found. Install with:"
        echo "  brew install azure-cli       # macOS"
        echo "  https://aka.ms/installazurecli  # other"
        exit 2
    fi

    echo "═══════════════════════════════════════════════════════════════"
    echo "  Building image in ACR (no Docker Desktop required)"
    echo "  Registry : ${ACR_LOGIN_SERVER}"
    echo "  Image    : ${IMAGE_NAME}:${IMAGE_TAG}"
    echo "  Source   : ${REPO_ROOT}"
    echo "═══════════════════════════════════════════════════════════════"

    # 'az acr build' uploads the build context (respecting .dockerignore),
    # builds in ACR Tasks, and pushes the result. One command.
    az acr build \
        --registry "$ACR_NAME" \
        --image "${IMAGE_NAME}:${IMAGE_TAG}" \
        --file deploy/Dockerfile \
        --resource-group "$RESOURCE_GROUP" \
        .

    echo ""
    echo "✓ Image available at:  ${FULL_IMAGE}"
    echo ""
    echo "Next: point your Web App for Containers at this image."
    echo "  See deploy/README.md, step 4."

# ── Path (B): local docker build + push ──────────────────────────────────
elif [[ "$MODE" == "local" ]]; then
    if ! command -v docker >/dev/null 2>&1; then
        echo "ERROR: Docker not found. Install Docker Desktop from"
        echo "  https://www.docker.com/products/docker-desktop/"
        echo "Or use 'bash deploy/build_and_push.sh acr' to build in the cloud."
        exit 2
    fi

    echo "═══════════════════════════════════════════════════════════════"
    echo "  Building locally with Docker Desktop"
    echo "  Image: ${FULL_IMAGE}"
    echo "═══════════════════════════════════════════════════════════════"

    # Linux/amd64 because App Service Linux is amd64. If you're on Apple
    # Silicon, this triggers Rosetta emulation during build — slow but works.
    docker build \
        --platform linux/amd64 \
        --file deploy/Dockerfile \
        --tag "$FULL_IMAGE" \
        --progress plain \
        .

    echo ""
    echo "→ logging into ACR ..."
    az acr login --name "$ACR_NAME"

    echo "→ pushing ${FULL_IMAGE} ..."
    docker push "$FULL_IMAGE"

    echo ""
    echo "✓ Image available at:  ${FULL_IMAGE}"
    echo ""
    echo "Next: point your Web App for Containers at this image."
    echo "  See deploy/README.md, step 4."

else
    echo "Usage: bash deploy/build_and_push.sh [acr|local]"
    echo "  acr   — build in ACR (no Docker Desktop needed)  ★ recommended"
    echo "  local — build locally with Docker Desktop, push to ACR"
    exit 2
fi
