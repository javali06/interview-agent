"""deploy.text_app — the TEXT tier ASGI entry (stateless, autoscaling).

The typed/chat interview tier. It is a thin ASGI wrapper around the already-built,
verified `app.text_service` router (`/text/{token}/{start,turn,state,save}`), which
carries ALL of the logic and is STATELESS per request: every call rebuilds a fresh
engine from the HMAC-signed state blob the browser posts back, and Redis is touched
only at sync points. Because nothing lives in module memory between requests, ANY
text-tier replica can serve ANY /text request — no shard pinning (unlike the voice
session tier) — so this app scales freely on HTTP concurrency and to zero when idle.

Unlike the gateway, this app serves NEITHER the SPA nor the admin/api routes — the
gateway owns those and reverse-proxies /text here (TEXT_TIER_URL). This app exposes
only the text router + a health probe.

Run:  gunicorn -k uvicorn.workers.UvicornWorker deploy.text_app:app
"""
from __future__ import annotations

import logging
import os

# Match the other tiers: the text service reads the same cloud env (Redis, Blob,
# Postgres, HMAC secret). setdefault so a compose/local override still wins.
os.environ.setdefault("CLOUD_MODE", "1")

from fastapi import FastAPI  # noqa: E402
from fastapi.responses import JSONResponse  # noqa: E402

from app.text_service import router as text_router  # noqa: E402

logger = logging.getLogger("deploy.text_app")

app = FastAPI(title="interview-agent-text")


@app.on_event("startup")
async def _ensure_db() -> None:
    """Defensively make the DB engine/tables available the way other tiers do.
    The router's db.get() is fail-soft, but the Postgres schema self-creates on
    first boot (create_all) — do it once here so the shared DB has what it needs.
    Best-effort: a missing DB never blocks the health probe or a /start."""
    try:
        from app import db
        db.init_db()
    except Exception as e:  # DB optional in some contexts — fail soft, like the router
        logger.warning("[text] DB init skipped: %s", e)


# The text router carries all interview logic (/text/{token}/{start,turn,state,save}).
app.include_router(text_router)


@app.get("/healthz")
async def _healthz() -> JSONResponse:
    """Liveness/readiness probe (200). The tier is stateless, so process-alive is
    enough to route traffic — a /start that needs Redis/DB fails its own request."""
    return JSONResponse({"status": "ok"})
