#!/usr/bin/env bash
# deploy.sh — one command: build THIS checkout as the tiered images and roll the
# live Azure Container Apps to them.
#
# ⚠ The old single-webapp flow is GONE. There is no `interview-ai-backend`
# App Service anymore — the app runs as tiered Azure Container Apps
# (gateway / session-* / worker) behind Front Door. This script builds the tier
# images at a new tag, rolls the RUNNING apps to that tag, and verifies.
# Full guide: docs/reading/05-cloud-deploy-runbook.md.
#
# Usage:
#   bash deploy/deploy.sh v37          # build+push :v37, then roll the running apps to it
#   bash deploy/deploy.sh v37 --yes    # skip the "update PROD?" confirm prompt
#
# Env overrides (defaults shown):
#   ACR_NAME=interviewagentacr   RESOURCE_GROUP=AI-COE
#   SUBSCRIPTION=da74e3ed-9c9a-4605-8fae-10f3492c0f5c   # AzureSimple Pactera

set -euo pipefail

TAG="${1:-}"
if [ -z "$TAG" ]; then
  echo "usage: bash deploy/deploy.sh <tag> [--yes]     e.g. bash deploy/deploy.sh v37"
  echo "  (tiered ACA deploy — the old single-webapp deploy is retired)"
  exit 2
fi
ASSUME_YES=0; [ "${2:-}" = "--yes" ] && ASSUME_YES=1

ACR_NAME="${ACR_NAME:-interviewagentacr}"
RG="${RESOURCE_GROUP:-AI-COE}"
SUBSCRIPTION="${SUBSCRIPTION:-da74e3ed-9c9a-4605-8fae-10f3492c0f5c}"
REG="${ACR_NAME}.azurecr.io"
APPS=(gateway worker session-0 session-1)

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

# ── 0. Preconditions ──────────────────────────────────────────────────────
# 'az' is frequently a shell ALIAS that doesn't exist in this non-interactive
# shell (nor in build_tiers.sh's subshell). Put its real bin dir on PATH.
if ! command -v az >/dev/null 2>&1; then
  [ -x "$HOME/azure-cli-env/bin/az" ] && export PATH="$HOME/azure-cli-env/bin:$PATH" || true
fi
command -v az >/dev/null 2>&1 || {
  echo "ERROR: 'az' not on PATH. Run:  export PATH=<your azure-cli bin>:\$PATH  and retry."; exit 2; }

if ! az account show >/dev/null 2>&1; then
  echo "→ not logged in — starting device-code login"
  az login --use-device-code >/dev/null
fi
az account set --subscription "$SUBSCRIPTION"

# ── 1. Build + push all tier images at TAG (base → gateway/worker/session + obs) ──
echo "→ [1/3] build + push ${REG}/interview-agent-*:${TAG}  (~15-25 min)"
echo "        (gateway stage runs tsc && vite build — a TS error fails the build here)"
TAG="$TAG" RESOURCE_GROUP="$RG" ACR_NAME="$ACR_NAME" bash "$REPO_ROOT/deploy/build_tiers.sh" acr

# ── 2. Roll the live apps to the new tag ────────────────────────────────────
echo "→ [2/3] rolling apps to :${TAG}"
if [ "$ASSUME_YES" != 1 ]; then
  read -r -p "    About to update PROD container apps in $RG to :${TAG}. Continue? [y/N] " ok
  [ "$ok" = "y" ] || { echo "aborted — images are built + pushed to ACR, but nothing was rolled."; exit 1; }
fi
for app in "${APPS[@]}"; do
  case "$app" in
    gateway)   img="${REG}/interview-agent-gateway:${TAG}";;
    worker)    img="${REG}/interview-agent-worker:${TAG}";;
    session-*) img="${REG}/interview-agent-session:${TAG}";;
  esac
  state="$(az containerapp show -g "$RG" -n "$app" --query properties.runningStatus -o tsv 2>/dev/null || echo Missing)"
  if [ "$state" = "Missing" ]; then
    echo "  ⏭  $app — not found, skipping"
    continue
  fi
  # Swap the image on every existing app so a stopped shard is ready on the new
  # code when started; a Stopped app stays stopped (the update doesn't start it).
  echo "  → $app (${state}) → :$TAG"
  az containerapp update -g "$RG" -n "$app" --image "$img" -o none
done

# ── 3. Verify ────────────────────────────────────────────────────────────────
echo "→ [3/3] verifying gateway"
GW="$(az containerapp show -g "$RG" -n gateway --query properties.configuration.ingress.fqdn -o tsv)"
for _ in $(seq 1 30); do
  code="$(curl -sk -o /dev/null -w '%{http_code}' "https://$GW/admin/login" || true)"
  if [ "$code" = "200" ]; then
    echo
    echo "✓ gateway live: https://$GW  (also reachable via the Front Door host — see deploy/README.md)"
    curl -s "https://$GW/ready" || true; echo
    exit 0
  fi
  printf '.'; sleep 6
done
echo
echo "⚠ gateway /admin/login not 200 within ~3 min. Check logs:"
echo "  az containerapp logs show -g $RG -n gateway --type console --follow"
exit 1
