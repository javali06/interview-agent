#!/usr/bin/env bash
# Azure App Service startup command for the interview agent.
#
# What runs:
#   gunicorn → uvicorn worker → deploy.azure_app:app   (the ASGI FastAPI app)
#
# The lifespan event inside deploy/azure_app.py is what spawns Stream A's
# VAD + TTS subprocesses on app startup. This script just gets the ASGI
# server listening on $PORT (Azure routes external 443 → $PORT internally).
#
# Environment variables Azure sets for us:
#   PORT             — port to bind on (always 8080 on Linux App Service)
#   HOME             — /home  (persistent storage for HF cache, model files)
#
# Set on the App Service via:
#   az webapp config appsettings set ... --settings GROQ_API_KEY=...

set -euo pipefail

# ── Kokoro cache + Hugging Face offline mode ──────────────────────────────
# Kokoro's KPipeline does a HEAD request to huggingface.co on every load to
# check whether the cached model is up to date. Inside Azure's network that
# either works fine (~100 ms) or times out 5× (~40 s wasted) depending on
# the day. Force-offline mode skips the HEAD entirely; the model is
# downloaded once on first install (see oryx postBuild below) and that's it.
export HF_HUB_OFFLINE=1

# OpenMP libraries from numpy / torch / onnxruntime sometimes load twice on
# Linux App Service Python images. This silences the resulting abort.
export KMP_DUPLICATE_LIB_OK=TRUE

# Tell PyTorch to use the deterministic single-thread CPU backend — gunicorn
# spawns one worker per request anyway, and multi-thread torch on shared
# vCPUs hurts more than it helps on B-tier App Service.
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-1}
export MKL_NUM_THREADS=${MKL_NUM_THREADS:-1}

# ── Bind address ──────────────────────────────────────────────────────────
PORT="${PORT:-8080}"
echo "[startup] binding gunicorn to 0.0.0.0:${PORT}"

# ── Gunicorn with one uvicorn worker ──────────────────────────────────────
# WHY one worker:
#   InterviewSession is stateful in-process. Two workers => same WS URL
#   might land on a different worker than the one that booted the session.
#   For the pilot (one candidate at a time) one worker is enough; vertical
#   scale up to P1v3 if needed, horizontal scale requires a session-routing
#   layer in front (deferred).
#
# WHY uvicorn worker class:
#   FastAPI is an ASGI app, gunicorn's default sync worker can't serve it.
#
# Timeouts:
#   --timeout 120     — long enough for Stream A's first health-check
#                       (Kokoro cold-start can take 60 s)
#   --keep-alive 75   — App Service idle timeout is 240 s; keep below
#
# Worker class: `deploy.uvicorn_worker.WSResilientWorker` — subclass of
# uvicorn's UvicornWorker that overrides the WebSocket ping defaults
# (20s/20s) which were too tight for browsers that throttle background
# tabs. A slow pong was triggering disconnect-mid-interview. With
# 30s ping / 60s timeout the browser has a wider tolerance window while
# the server still reaps genuinely-dead clients reasonably quickly.
exec gunicorn deploy.azure_app:app \
    --worker-class deploy.uvicorn_worker.WSResilientWorker \
    --workers 1 \
    --bind "0.0.0.0:${PORT}" \
    --timeout 120 \
    --graceful-timeout 30 \
    --keep-alive 75 \
    --access-logfile - \
    --error-logfile - \
    --log-level info
