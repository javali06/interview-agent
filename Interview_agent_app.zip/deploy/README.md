# Interview Agent — Azure Deploy Quick Reference

> **⚠ The single-webapp flow is RETIRED.** There is no `interview-ai-backend`
> App Service anymore. The scaled app runs as **tiered Azure Container Apps**
> (gateway / session-\* / worker) behind Front Door. Any older instructions
> about building one `interview-agent` image and repinning a webapp digest are
> **dead** and will fail with `ResourceNotFound`.
>
> **Authoritative, step-by-step guide:** [`docs/reading/05-cloud-deploy-runbook.md`](../docs/reading/05-cloud-deploy-runbook.md)
> (conceptual reference: [`docs/reading/03-deploy-azure.md`](../docs/reading/03-deploy-azure.md)).
> This file is only a quick orientation + the routine code-deploy commands.

## What's running where

| Thing | Value |
|---|---|
| Subscription | AzureSimple Pactera (`da74e3ed-9c9a-4605-8fae-10f3492c0f5c`) |
| Resource group | `AI-COE` (region `eastus`) |
| Container registry | `interviewagentacr` (`interviewagentacr.azurecr.io`) |
| Public URL (Front Door) | `https://interview-cx7zm7mgeu5bi-cheuaabgh3esazc0.a01.azurefd.net` (profile `interview-afd`) |
| ACA apps | `gateway` (public ingress), `session-0` / `session-1` (internal, pinned 1 replica each), `worker` (queue-scaled→0), `grafana` (observability) |
| Tier images | `interview-agent-{base,gateway,worker,session}:vN` — a deploy bumps `vN`. Obs images `interview-agent-{prometheus,grafana}` are versioned separately. |
| Rollback / failover | re-pin a previous tag (below), or the `demo-prod` App Service |

Redis (`interview-redis`), Postgres (`interviewagent-sql`, reused), and Storage
(`interviewagentdata`) are provisioned by the Bicep — see the runbook.

**There is no cloud `.env`.** Env & secrets are **Container App secrets** written
by the Bicep (`deploy/aca/main.bicep`) at provision time — *not* App Service
settings. To change one, edit the Bicep / the value passed to
`deploy/aca/provision.sh` and redeploy. See the runbook, "Where env & secrets live".

## Routine code deploy (build new images + roll the live apps)

One command: **`bash deploy/deploy.sh v<N>`** (builds all tier images at the tag,
then rolls the *running* apps to it, then verifies). Or do it by hand:

```bash
# 'az' is often a shell ALIAS not present in script/non-interactive shells —
# put its real bin dir on PATH first, or build_tiers.sh dies with "az: not found":
export PATH="$HOME/azure-cli-env/bin:$PATH"   # adjust to your az install

# 1. Build + push all tier images at a NEW tag (base → gateway/worker/session → obs).
#    The gateway stage compiles the SPA (tsc && vite build) — a TS error fails here.
TAG=v37 deploy/build_tiers.sh acr

# 2. Roll each RUNNING app to the new tag. Leave a deliberately-stopped shard
#    (e.g. a derouted session-1) alone — swapping its image is fine, it stays stopped.
az containerapp update -g AI-COE -n gateway   --image interviewagentacr.azurecr.io/interview-agent-gateway:v37
az containerapp update -g AI-COE -n worker    --image interviewagentacr.azurecr.io/interview-agent-worker:v37
az containerapp update -g AI-COE -n session-0 --image interviewagentacr.azurecr.io/interview-agent-session:v37
az containerapp update -g AI-COE -n session-1 --image interviewagentacr.azurecr.io/interview-agent-session:v37

# 3. Verify (gateway FQDN and/or the Front Door host):
GW=$(az containerapp show -g AI-COE -n gateway --query properties.configuration.ingress.fqdn -o tsv)
curl -s  "https://$GW/healthz/live"   # {"status":"live"}
curl -s  "https://$GW/ready"          # {"status":"ready","redis":true}
curl -sk -o /dev/null -w '%{http_code}\n' "https://$GW/admin/login"   # 200
```

Heavier alternative (keeps Bicep/IaC in sync, needs all prod secrets):
re-run `deploy/aca/provision.sh` with `IMAGE_TAG=vN` — see the runbook, "Updating code".

## Rollback

```bash
# List tags, then re-pin the running apps to the previous one:
az acr repository show-tags -n interviewagentacr --repository interview-agent-gateway --orderby time_desc -o tsv
az containerapp update -g AI-COE -n gateway   --image interviewagentacr.azurecr.io/interview-agent-gateway:<prev>
az containerapp update -g AI-COE -n worker    --image interviewagentacr.azurecr.io/interview-agent-worker:<prev>
az containerapp update -g AI-COE -n session-0 --image interviewagentacr.azurecr.io/interview-agent-session:<prev>
```

Or fail over to the `demo-prod` App Service.

## Common ops

```bash
# Which image/version is each app on?
for a in gateway worker session-0 session-1; do \
  az containerapp show -g AI-COE -n $a --query "{app:name,img:properties.template.containers[0].image,run:properties.runningStatus}" -o tsv; done

# Live console logs for a tier:
az containerapp logs show -g AI-COE -n gateway --type console --follow

# Start / stop a session shard (session-1 is intentionally stopped when single-sharded):
az containerapp start -g AI-COE -n session-1
az containerapp stop  -g AI-COE -n session-1
```

## Observability

In-cluster Grafana + Prometheus (the `grafana` container app, external + password
gated). Images `interview-agent-{prometheus,grafana}` are built by
`build_tiers.sh` at the same tag but the obs app is versioned/rolled on its own
cadence. See [`docs/reading/08-observability-and-stress-test.md`](../docs/reading/08-observability-and-stress-test.md).

## The two build scripts (don't mix them up)

- **`deploy/build_tiers.sh`** — builds the **tiered ACA** images (base + gateway
  + worker + session + obs). **This is the one you want.**
- **`deploy/build_and_push.sh`** + **`deploy/Dockerfile`** — build the OLD single
  `interview-agent` monolith image. Only relevant for the `demo-prod` App Service
  failover; **not** used by the ACA deploy.

## Contacts

- Cloud / Azure setup: Prabhudev
- Agent brain (`engine/brain/`): Ayush
- Deploy issues: start with `docs/reading/05-cloud-deploy-runbook.md` §Gotchas
