# Interview Agent — Deploy Reference (moved)

> **This file used to document the single-`interview-ai-backend`-webapp deploy.
> That App Service is RETIRED** — the app now runs as tiered Azure Container Apps
> (gateway / session-\* / worker) behind Front Door, so the old instructions no
> longer apply (they fail with `ResourceNotFound`).

It was a near-duplicate of `README.md`, and keeping two copies is exactly how
both drifted out of date. So this is now a pointer, not a second source of truth:

- **Quick reference + routine deploy commands:** [`deploy/README.md`](README.md)
- **Full step-by-step runbook (authoritative):** [`docs/reading/05-cloud-deploy-runbook.md`](../docs/reading/05-cloud-deploy-runbook.md)
- **Conceptual reference:** [`docs/reading/03-deploy-azure.md`](../docs/reading/03-deploy-azure.md)
