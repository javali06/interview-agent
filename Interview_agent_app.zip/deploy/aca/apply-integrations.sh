#!/usr/bin/env bash
# Apply Entra sign-in + SMTP invite-email config to the live ACA apps, from the
# values in .env.integrations.local (repo root). Idempotent — re-run any time to
# update. Secrets (ENTRA_CLIENT_SECRET, SMTP_PASSWORD) are stored as ACA secrets
# and referenced via secretref; everything else is a plain env var.
#
#   Entra → gateway only (it serves /auth/* and /api/*)
#   SMTP  → gateway + worker (the worker sends invite emails from jobs.py)
#
# Usage:  bash deploy/aca/apply-integrations.sh
set -euo pipefail
cd "$(dirname "$0")/../.."                       # repo root
export PATH="/Users/ayush.kothiyal/azure-cli-env/bin:$PATH"   # az is a shell alias otherwise
command -v az >/dev/null 2>&1 || { echo "ERROR: az CLI not found on PATH"; exit 1; }

ENVFILE=".env.integrations.local"
[ -f "$ENVFILE" ] || { echo "ERROR: $ENVFILE not found — fill it in first"; exit 1; }
set -a; . "./$ENVFILE"; set +a

RG=AI-COE
gw_env=(); wk_env=()

# ── Entra (gateway only) ─────────────────────────────────────────────────────
if [ -n "${ENTRA_TENANT_ID:-}" ]; then
  if [ -z "${ENTRA_CLIENT_ID:-}" ] || [ -z "${ENTRA_CLIENT_SECRET:-}" ] || [ -z "${ENTRA_REDIRECT_URI:-}" ]; then
    echo "ERROR: ENTRA_CLIENT_ID / ENTRA_CLIENT_SECRET / ENTRA_REDIRECT_URI must all be set"; exit 1
  fi
  echo ">> Entra: staging client secret on gateway"
  az containerapp secret set -g "$RG" -n gateway \
    --secrets "entra-client-secret=${ENTRA_CLIENT_SECRET}" >/dev/null
  gw_env+=( "ENTRA_TENANT_ID=${ENTRA_TENANT_ID}" "ENTRA_CLIENT_ID=${ENTRA_CLIENT_ID}" \
            "ENTRA_CLIENT_SECRET=secretref:entra-client-secret" \
            "ENTRA_REDIRECT_URI=${ENTRA_REDIRECT_URI}" "ENTRA_ENABLED=${ENTRA_ENABLED:-1}" )
else
  echo ">> Entra: ENTRA_TENANT_ID blank — skipping"
fi

# ── SMTP (gateway + worker) ──────────────────────────────────────────────────
if [ -n "${SMTP_HOST:-}" ]; then
  if [ -z "${SMTP_USERNAME:-}" ] || [ -z "${SMTP_PASSWORD:-}" ] || [ -z "${SMTP_FROM_ADDRESS:-}" ]; then
    echo "ERROR: SMTP_USERNAME / SMTP_PASSWORD / SMTP_FROM_ADDRESS must all be set"; exit 1
  fi
  echo ">> SMTP: staging password on gateway + worker"
  az containerapp secret set -g "$RG" -n gateway --secrets "smtp-password=${SMTP_PASSWORD}" >/dev/null
  az containerapp secret set -g "$RG" -n worker  --secrets "smtp-password=${SMTP_PASSWORD}" >/dev/null
  smtp_env=( "SMTP_HOST=${SMTP_HOST}" "SMTP_PORT=${SMTP_PORT:-587}" \
             "SMTP_USERNAME=${SMTP_USERNAME}" "SMTP_PASSWORD=secretref:smtp-password" \
             "SMTP_FROM_ADDRESS=${SMTP_FROM_ADDRESS}" "SMTP_USE_TLS=${SMTP_USE_TLS:-true}" )
  gw_env+=( "${smtp_env[@]}" )
  wk_env+=( "${smtp_env[@]}" )
else
  echo ">> SMTP: SMTP_HOST blank — skipping"
fi

# ── Apply (one revision per app) ─────────────────────────────────────────────
if [ ${#gw_env[@]} -gt 0 ]; then
  echo ">> gateway: setting ${#gw_env[@]} env vars"
  az containerapp update -g "$RG" -n gateway --set-env-vars "${gw_env[@]}" >/dev/null
fi
if [ ${#wk_env[@]} -gt 0 ]; then
  echo ">> worker: setting ${#wk_env[@]} env vars"
  az containerapp update -g "$RG" -n worker --set-env-vars "${wk_env[@]}" >/dev/null
fi

echo ""
echo "DONE — gateway/worker rolled a new revision."
echo "Verify Entra:  curl -s https://interview-cx7zm7mgeu5bi-cheuaabgh3esazc0.a01.azurefd.net/api/auth/methods"
echo "               → should show \"microsoft\": true, then the Login page shows the Microsoft button."
