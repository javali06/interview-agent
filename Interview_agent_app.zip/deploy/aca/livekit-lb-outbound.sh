#!/usr/bin/env bash
# Give livekit-lb an explicit outbound rule for SNAT headroom (prevents the
# port-exhaustion that made media DTLS-timeout after ~18h of uptime).
#
# Azure requires the inbound LB rules on the shared frontend 'fe' to disable
# their implicit outbound SNAT BEFORE an outbound rule can be attached. That
# leaves a brief window with no VM-initiated outbound, so: run when no interview
# is connecting, and this rolls the SNAT flags back if the outbound rule can't
# be created (so the VM never gets stranded without outbound).
#
# Does NOT touch the media server. Usage:  bash deploy/aca/livekit-lb-outbound.sh
set -uo pipefail
export PATH="/Users/ayush.kothiyal/azure-cli-env/bin:$PATH"
command -v az >/dev/null 2>&1 || { echo "ERROR: az CLI not found on PATH"; exit 1; }
RG=AI-COE; LB=livekit-lb
RULES=(rule-443 rule-7881 rule-7882 rule-80)

if az network lb outbound-rule show -g "$RG" --lb-name "$LB" -n ob-livekit >/dev/null 2>&1; then
  echo "outbound rule 'ob-livekit' already exists — nothing to do."; exit 0
fi

echo ">> Disabling implicit outbound SNAT on inbound LB rules..."
for r in "${RULES[@]}"; do
  echo "   $r"
  az network lb rule update -g "$RG" --lb-name "$LB" -n "$r" --disable-outbound-snat true -o none \
    || { echo "ERROR disabling SNAT on $r — aborting (no changes left half-applied beyond this rule)"; exit 1; }
done

echo ">> Creating outbound rule ob-livekit (10000 SNAT ports)..."
if az network lb outbound-rule create -g "$RG" --lb-name "$LB" -n ob-livekit \
     --frontend-ip-configs fe --address-pool bepool \
     --protocol All --outbound-ports 10000 --idle-timeout 15 --enable-tcp-reset true -o table; then
  echo ">> Verifying the VM still has outbound internet..."
  az vm run-command invoke -g "$RG" -n livekitazurevm --command-id RunShellScript \
    --scripts "curl -s -m 8 https://api.ipify.org || echo NO-OUTBOUND; echo" \
    --query "value[0].message" -o tsv
  echo "DONE — expect 20.25.30.145 above (VM outbound intact, now with SNAT headroom)."
else
  echo "!! outbound-rule create FAILED — rolling back SNAT flags so the VM keeps outbound..."
  for r in "${RULES[@]}"; do
    az network lb rule update -g "$RG" --lb-name "$LB" -n "$r" --disable-outbound-snat false -o none || true
  done
  echo "Rolled back. Tell me the create error and I'll adjust."
  exit 1
fi
