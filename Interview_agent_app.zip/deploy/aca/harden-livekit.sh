#!/usr/bin/env bash
# Harden the self-hosted LiveKit SFU against the two failure modes that caused
# candidates to get stuck "reconnecting" (media/DTLS timeouts):
#
#   1. use_external_ip STUN auto-detection is a coin-flip on each restart — on
#      2026-10-13 it failed to validate and advertised an unreachable IP, so all
#      media failed. FIX: hardcode node_ip = the LB public IP (deterministic).
#   2. The Standard LB had no explicit outbound rule, so the server's outbound
#      ICE traffic (single UDP mux port) relied on default SNAT and could exhaust
#      its ports over hours of uptime → new rooms DTLS-timeout. FIX: an explicit
#      outbound rule with generous SNAT port allocation.
#
# Safe to re-run. Briefly restarts the media server (run it when no interview is
# live). Usage:  bash deploy/aca/harden-livekit.sh
set -euo pipefail
export PATH="/Users/ayush.kothiyal/azure-cli-env/bin:$PATH"
command -v az >/dev/null 2>&1 || { echo "ERROR: az CLI not found on PATH"; exit 1; }
RG=AI-COE; VM=livekitazurevm; LB=livekit-lb; LBIP=20.25.30.145

# ── 1. Hardcode the external IP in LiveKit's config, then restart ────────────
REMOTE=$(mktemp)
cat > "$REMOTE" <<REMOTESH
set -e
cp /etc/livekit/config.yaml /etc/livekit/config.yaml.bak.\$(date +%s)
cat > /etc/livekit/config.yaml <<'CFG'
# LiveKit server configuration.
# Signaling/API bind loopback; nginx terminates TLS on :443 -> 127.0.0.1:7880.
# Media (ICE) uses the RTC ports below. node_ip is HARDCODED to the LB public IP
# so a restart never re-rolls STUN detection (which failed 2026-10-13).
port: 7880
bind_addresses:
  - 127.0.0.1
log_level: info
rtc:
  tcp_port: 7881
  udp_port: 7882
  use_external_ip: false
  node_ip: ${LBIP}
key_file: /var/lib/livekit/keys.yaml
CFG
systemctl restart livekit-server
sleep 4
echo "service: \$(systemctl is-active livekit-server)"
echo "--- effective rtc config ---"
grep -E "use_external_ip|node_ip|tcp_port|udp_port" /etc/livekit/config.yaml
echo "--- listening ---"
ss -tulnp 2>/dev/null | grep -E "7880|7881|7882" || true
REMOTESH

echo ">> [1/2] Hardcoding LiveKit node_ip=${LBIP} + restarting media server..."
az vm run-command invoke -g "$RG" -n "$VM" --command-id RunShellScript \
  --scripts @"$REMOTE" --query "value[0].message" -o tsv
rm -f "$REMOTE"

# ── 2. Explicit LB outbound rule (SNAT headroom) ────────────────────────────
# Azure requires disabling the inbound rules' implicit outbound SNAT first, with
# a rollback guard — that lives in its own script so it can be run on its own
# (it needs no media-server restart).
echo ">> [2/2] LB outbound rule (SNAT headroom) — delegating to livekit-lb-outbound.sh"
bash "$(dirname "$0")/livekit-lb-outbound.sh" \
  || echo "   NOTE: LB outbound step failed — the node_ip fix above still applied."

echo ""
echo "DONE. Verify an interview connects. If media ever degrades again, a plain"
echo "  'systemctl restart livekit-server' now reliably recovers (IP is fixed)."
