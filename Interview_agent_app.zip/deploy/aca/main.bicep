// ════════════════════════════════════════════════════════════════════════
//  Tiered AI Interview Engine — Azure Container Apps + Front Door.
//
//  Provisions the NEW resources (Redis, Postgres, ACA env + apps, Front Door)
//  and wires them to the EXISTING ACR + Storage account. Session shards are
//  single-replica ACA apps with internal ingress so the gateway can proxy a
//  WebSocket to a specific replica; the gateway is external behind Front Door.
//
//  Validate:  az bicep build -f deploy/aca/main.bicep
//  Deploy:    deploy/aca/provision.sh   (wraps `az deployment group create`)
// ════════════════════════════════════════════════════════════════════════

@description('Azure region for the new resources.')
param location string = resourceGroup().location

@description('Existing Azure Container Registry name (images are pushed here).')
param acrName string = 'interviewagentacr'

@description('Existing Storage account name (Blob artifacts + the job queue).')
param storageAccountName string

@description('Image tag to deploy for all tiers.')
param imageTag string = 'latest'

@description('Session shard ids → one single-replica ACA app each.')
param sessionShards array = [ 'session-0', 'session-1' ]

// Session POOL (Phase 3): replicas nothing can address, taking LiveKit
// interviews from the Redis placement queue; deployed only with LiveKit on.
// Scales on interviews per replica — set it from the measured capacity C.
@description('Interviews one pool replica runs at once (set from the measured C).')
param sessionPoolPerReplica int = 4
param sessionPoolMinReplicas int = 1
param sessionPoolMaxReplicas int = 10

@description('Text tier min replicas. 0 → scale to zero when idle (cold-start on first /text); 1 → always warm. The tier is stateless so any replica serves any request.')
param textReplicas int = 1
@description('Text tier max replicas (HTTP-concurrency autoscale ceiling).')
param textMaxReplicas int = 10

@secure()
@description('SQLAlchemy URL of the EXISTING Postgres (reused, not provisioned). e.g. postgresql+psycopg://user:pw@host.postgres.database.azure.com:5432/interview?sslmode=require')
param databaseUrl string

// ── Secrets threaded into the container apps (never hard-coded) ────────────
@secure()
param adminPasswordHash string
@secure()
param adminSecretKey string
@secure()
@description('Comma list of Azure Speech keys (key or key:region) for the pool.')
param azureSpeechKeys string
@secure()
param openrouterApiKey string
@secure()
param groqApiKey string = ''
// Langfuse tracing. All optional — empty keys make the client no-op (no traces),
// which is exactly how it behaved before these were threaded through. BASE_URL +
// PROJECT_ID also power the admin "view trace" link.
@secure()
param langfusePublicKey string = ''
@secure()
param langfuseSecretKey string = ''
param langfuseBaseUrl string = ''
param langfuseProjectId string = ''
param langfuseEnvironment string = 'production'

// LiveKit media plane (Phase 1). 'websocket' = today's audio path, unchanged;
// 'livekit' = audio over WebRTC via LiveKit Cloud, falling back to the
// WebSocket per interview if LiveKit can't be reached. Flip with a re-deploy
// (or `az containerapp update --set-env-vars MEDIA_TRANSPORT=...` on the
// gateway + every session shard) — no image change either way.
@allowed([ 'websocket', 'livekit' ])
param mediaTransport string = 'websocket'
param livekitUrl string = ''
@secure()
param livekitApiKey string = ''
@secure()
param livekitApiSecret string = ''
@secure()
@description('Bearer token Prometheus sends to the gateway /metrics/pushed (pool + worker metrics). Empty = that endpoint is open.')
param metricsToken string = ''

@secure()
@description('Admin password for the in-cluster Grafana (external FQDN, so it MUST be set — anonymous access is off).')
param grafanaAdminPassword string

var acrLoginServer = '${acrName}.azurecr.io'
var redisConn = 'rediss://:${redis.listKeys().primaryKey}@${redis.properties.hostName}:6380/0'
var storageConn = 'DefaultEndpointsProtocol=https;AccountName=${storage.name};AccountKey=${storage.listKeys().keys[0].value};EndpointSuffix=${environment().suffixes.storage}'

// ── Existing resources ────────────────────────────────────────────────────
resource acr 'Microsoft.ContainerRegistry/registries@2023-07-01' existing = {
  name: acrName
}
resource storage 'Microsoft.Storage/storageAccounts@2023-01-01' existing = {
  name: storageAccountName
}

// ── Redis (coordination plane) ─────────────────────────────────────────────
resource redis 'Microsoft.Cache/redis@2024-03-01' = {
  name: 'interview-redis'
  location: location
  properties: {
    sku: { name: 'Standard', family: 'C', capacity: 1 }
    enableNonSslPort: false
    minimumTlsVersion: '1.2'
  }
}

// ── Postgres: REUSED (existing server from a previous iteration) ───────────
// Not provisioned here — passed in as `databaseUrl`. The tiered schema
// (including the new `jobs` table + additive columns) self-creates on first
// boot via db.create_all(), so the existing DB just gains what's missing.
// Ensure the existing server's firewall/private-endpoint allows the ACA env.

// ── ACA managed environment ────────────────────────────────────────────────
resource acaEnv 'Microsoft.App/managedEnvironments@2024-03-01' = {
  name: 'interview-aca-env'
  location: location
  properties: {}
}

// ── Shared session filesystem (Azure Files) ────────────────────────────────
// Per-session files (resume, cadence.yaml, events.jsonl, evaluation.json) live
// under SESSIONS_DIR and are read/written by ALL tiers — the gateway writes the
// draft, the session shard runs the interview, the worker scores it. So
// SESSIONS_DIR must be ONE shared filesystem, not each container's local disk;
// otherwise the session shard can't see the gateway's files and the interview
// fails to start (FileNotFoundError on cadence load). An Azure Files share
// mounted into every tier provides it (the cloud equivalent of the local
// docker-compose 'sessions' volume).
resource fileShare 'Microsoft.Storage/storageAccounts/fileServices/shares@2023-01-01' = {
  name: '${storageAccountName}/default/sessions'
  properties: { shareQuota: 100 }
}
resource envStorage 'Microsoft.App/managedEnvironments/storages@2024-03-01' = {
  parent: acaEnv
  name: 'sessions'
  properties: {
    azureFile: {
      accountName: storageAccountName
      accountKey: storage.listKeys().keys[0].value
      shareName: 'sessions'
      accessMode: 'ReadWrite'
    }
  }
  dependsOn: [ fileShare ]
}

// Volume + mount reused by every tier's container template.
var sessionsVolume = { name: 'sessions-vol', storageType: 'AzureFile', storageName: 'sessions' }
var sessionsMount = { volumeName: 'sessions-vol', mountPath: '/app/sessions' }

// Shared non-secret env for every tier.
var commonEnv = [
  { name: 'REDIS_URL', secretRef: 'redis-url' }
  { name: 'DATABASE_URL', secretRef: 'database-url' }
  { name: 'AZURE_STORAGE_CONNECTION_STRING', secretRef: 'storage-conn' }
  { name: 'BLOB_ENABLED', value: '1' }
  { name: 'BLOB_CONTAINER', value: 'sessions' }
  { name: 'EVAL_PLUGINS_ENABLED', value: '1' }
  { name: 'CODING_ENABLED', value: '1' }   // live coding phase + coding-answer scoring

  // Langfuse tracing — every tier (session=LLM/STT/TTS, worker=eval, gateway=link).
  // No-ops when the keys are empty. Threaded through Bicep so a re-provision can't
  // silently drop tracing (config drift that once left the cloud untraced).
  { name: 'LANGFUSE_PUBLIC_KEY', secretRef: 'langfuse-public-key' }
  { name: 'LANGFUSE_SECRET_KEY', secretRef: 'langfuse-secret-key' }
  { name: 'LANGFUSE_BASE_URL', value: langfuseBaseUrl }
  { name: 'LANGFUSE_PROJECT_ID', value: langfuseProjectId }
  { name: 'LANGFUSE_ENVIRONMENT', value: langfuseEnvironment }

  { name: 'SESSIONS_DIR', value: '/app/sessions' }   // the shared Azure Files mount
  { name: 'SESSION_SHARDS', value: join(sessionShards, ',') }
  { name: 'SESSION_SHARD_FQDNS', value: join(map(sessionShards, s => '${s}.internal.${acaEnv.properties.defaultDomain}'), ',') }
]
var commonSecrets = [
  { name: 'redis-url', value: redisConn }
  { name: 'database-url', value: databaseUrl }
  { name: 'storage-conn', value: storageConn }
  { name: 'openrouter-key', value: openrouterApiKey }
  { name: 'groq-key', value: groqApiKey }
  { name: 'speech-keys', value: azureSpeechKeys }
  { name: 'admin-hash', value: adminPasswordHash }
  { name: 'admin-secret', value: adminSecretKey }
  { name: 'langfuse-public-key', value: langfusePublicKey }
  { name: 'langfuse-secret-key', value: langfuseSecretKey }
  { name: 'grafana-admin-password', value: grafanaAdminPassword }
  { name: 'livekit-api-key', value: livekitApiKey }
  { name: 'livekit-api-secret', value: livekitApiSecret }
  { name: 'metrics-token', value: metricsToken }
  // LiveKit egress writes the server-side recording straight into this same
  // storage account + 'sessions' container (next to the browser recording),
  // so the admin page can serve it with the app's own blob access.
  { name: 'egress-storage-key', value: storage.listKeys().keys[0].value }
  { name: 'acr-password', value: acr.listCredentials().passwords[0].value }
]
var llmEnv = [
  { name: 'OPENROUTER_API_KEY', secretRef: 'openrouter-key' }
  { name: 'GROQ_API_KEY', secretRef: 'groq-key' }
  { name: 'SLOW_PROVIDER', value: 'openrouter' }
  { name: 'SLOW_PROVIDER_ORDER', value: 'Groq' }
  { name: 'FAST_PROVIDER_ORDER', value: 'Groq' }
]
// Gateway: mints the candidate's room token in /session-info. Session shards:
// join the room as the agent and run the egress recording.
var livekitEnv = [
  { name: 'MEDIA_TRANSPORT', value: mediaTransport }
  { name: 'LIVEKIT_URL', value: livekitUrl }
  { name: 'LIVEKIT_API_KEY', secretRef: 'livekit-api-key' }
  { name: 'LIVEKIT_API_SECRET', secretRef: 'livekit-api-secret' }
]
var livekitEgressEnv = [
  { name: 'LIVEKIT_EGRESS_AZURE_ACCOUNT_NAME', value: storage.name }
  { name: 'LIVEKIT_EGRESS_AZURE_ACCOUNT_KEY', secretRef: 'egress-storage-key' }
  { name: 'LIVEKIT_EGRESS_AZURE_CONTAINER', value: 'sessions' }
]
var adminEnv = [
  { name: 'ADMIN_USERNAME', value: 'admin' }
  { name: 'ADMIN_PASSWORD_HASH', secretRef: 'admin-hash' }
  { name: 'ADMIN_SECRET_KEY', secretRef: 'admin-secret' }
]

// ── Gateway (external ingress, stateless, scale on HTTP) ───────────────────
resource gateway 'Microsoft.App/containerApps@2024-03-01' = {
  name: 'gateway'
  location: location
  identity: { type: 'SystemAssigned' }
  properties: {
    managedEnvironmentId: acaEnv.id
    configuration: {
      activeRevisionsMode: 'Single'
      ingress: { external: true, targetPort: 8080, transport: 'auto' }
      registries: [ { server: acrLoginServer, username: acr.listCredentials().username, passwordSecretRef: 'acr-password' } ]
      secrets: commonSecrets
    }
    template: {
      containers: [ {
        name: 'gateway'
        image: '${acrLoginServer}/interview-agent-gateway:${imageTag}'
        resources: { cpu: json('0.5'), memory: '1Gi' }
        // TEXT_TIER_URL: the gateway reverse-proxies /text/* to the stateless text
        // tier's internal ingress (http, in-env). Depends on textApp → gateway waits
        // for it to exist. Stateless round-robin (no shard lookup — that's /ws only).
        env: concat(commonEnv, llmEnv, adminEnv, livekitEnv, [
          { name: 'TEXT_TIER_URL', value: 'http://${textApp.properties.configuration.ingress.fqdn}' }
          // Guards /metrics/pushed (the pool + worker metrics) on this public app.
          { name: 'METRICS_TOKEN', secretRef: 'metrics-token' }
        ])
        volumeMounts: [ sessionsMount ]
      } ]
      volumes: [ sessionsVolume ]
      scale: {
        minReplicas: 1
        maxReplicas: 10
        rules: [ { name: 'http', http: { metadata: { concurrentRequests: '50' } } } ]
      }
    }
  }
}

// ── Worker (no ingress, scale on queue depth → 0) ──────────────────────────
resource worker 'Microsoft.App/containerApps@2024-03-01' = {
  name: 'worker'
  location: location
  identity: { type: 'SystemAssigned' }
  properties: {
    managedEnvironmentId: acaEnv.id
    configuration: {
      activeRevisionsMode: 'Single'
      registries: [ { server: acrLoginServer, username: acr.listCredentials().username, passwordSecretRef: 'acr-password' } ]
      secrets: commonSecrets
    }
    template: {
      containers: [ {
        name: 'worker'
        image: '${acrLoginServer}/interview-agent-worker:${imageTag}'
        resources: { cpu: json('0.5'), memory: '1Gi' }
        // LiveKit: the recording_finalize job asks LiveKit whether a server
        // recording finished uploading.
        env: concat(commonEnv, llmEnv, livekitEnv)
        volumeMounts: [ sessionsMount ]
      } ]
      volumes: [ sessionsVolume ]
      scale: {
        minReplicas: 0
        maxReplicas: 10
        rules: [ {
          name: 'queue'
          custom: {
            type: 'azure-queue'
            metadata: { queueName: 'jobs', queueLength: '5', accountName: storageAccountName }
            auth: [ { secretRef: 'storage-conn', triggerParameter: 'connection' } ]
          }
        } ]
      }
    }
  }
}

// ── Text tier (internal ingress, stateless, HTTP-concurrency autoscale) ────
// The typed/chat interview. STATELESS per request (every /text call rebuilds a
// fresh engine from the browser's signed blob), so — unlike the pinned session
// shards — it has NO shard identity and scales freely on HTTP concurrency (and
// to zero if textReplicas=0). Internal ingress: only the gateway reaches it, and
// it reverse-proxies /text here (TEXT_TIER_URL, wired into the gateway below).
resource textApp 'Microsoft.App/containerApps@2024-03-01' = {
  name: 'text'
  location: location
  identity: { type: 'SystemAssigned' }
  properties: {
    managedEnvironmentId: acaEnv.id
    configuration: {
      activeRevisionsMode: 'Single'
      // Internal-only (gateway → text over the private network); allowInsecure so
      // the gateway's http:// proxy call isn't 301'd to https (traffic stays in-env).
      ingress: { external: false, targetPort: 8080, transport: 'auto', allowInsecure: true }
      registries: [ { server: acrLoginServer, username: acr.listCredentials().username, passwordSecretRef: 'acr-password' } ]
      secrets: commonSecrets
    }
    template: {
      containers: [ {
        name: 'text'
        image: '${acrLoginServer}/interview-agent-text:${imageTag}'
        // No audio/VAD here (text-only) → modest CPU; it waits on the interview LLM.
        resources: { cpu: json('0.5'), memory: '1Gi' }
        // commonEnv carries REDIS_URL / DATABASE_URL / AZURE_STORAGE_CONNECTION_STRING /
        // SESSIONS_DIR / EVAL_PLUGINS_ENABLED; llmEnv carries the SLOW_/FAST_ provider
        // routing + keys. TEXT_STATE_SECRET signs the browser's state blob (HMAC) — it
        // reuses the admin-secret value so it matches ADMIN_SECRET_KEY (the fallback).
        env: concat(commonEnv, llmEnv, [
          { name: 'TEXT_STATE_SECRET', secretRef: 'admin-secret' }
          { name: 'ADMIN_SECRET_KEY', secretRef: 'admin-secret' }
        ])
        volumeMounts: [ sessionsMount ]
      } ]
      volumes: [ sessionsVolume ]
      scale: {
        minReplicas: textReplicas
        maxReplicas: textMaxReplicas
        rules: [ { name: 'http', http: { metadata: { concurrentRequests: '50' } } } ]
      }
    }
  }
}

// ── Session shards (internal ingress, pinned 1 replica each) ───────────────
resource sessionApps 'Microsoft.App/containerApps@2024-03-01' = [for shard in sessionShards: {
  name: shard
  location: location
  identity: { type: 'SystemAssigned' }
  properties: {
    managedEnvironmentId: acaEnv.id
    configuration: {
      activeRevisionsMode: 'Single'
      // Internal-only: only the gateway (same env, private network) proxies here.
      // allowInsecure so the gateway's ws:// upgrade isn't 301'd to https and
      // broken (traffic never leaves the ACA environment).
      ingress: { external: false, targetPort: 8080, transport: 'auto', allowInsecure: true }
      registries: [ { server: acrLoginServer, username: acr.listCredentials().username, passwordSecretRef: 'acr-password' } ]
      secrets: commonSecrets
    }
    template: {
      containers: [ {
        name: 'session'
        image: '${acrLoginServer}/interview-agent-session:${imageTag}'
        // 1 vCPU: STT/LLM/TTS are all offloaded (I/O-bound here), so the shard's
        // only real local CPU work is the Silero VAD. Once the VAD onnxruntime
        // session is pinned to 1 thread (see silero.py — it otherwise thrashes
        // on the cgroup-limited core), 1 vCPU keeps the audio pipeline at
        // real-time for a single interview. Bump only if concurrency needs it.
        resources: { cpu: json('1.0'), memory: '2Gi' }
        env: concat(commonEnv, llmEnv, adminEnv, livekitEnv, livekitEgressEnv, [
          { name: 'DRAIN_TIMEOUT_S', value: '540' }
          { name: 'SHARD_ID', value: shard }
          { name: 'SHARD_FQDN', value: '${shard}.internal.${acaEnv.properties.defaultDomain}' }
          { name: 'AZURE_SPEECH_KEYS', secretRef: 'speech-keys' }
          { name: 'STT_PROVIDER', value: 'azure' }
          { name: 'TTS_PROVIDER', value: 'azure' }
        ])
        volumeMounts: [ sessionsMount ]
      } ]
      volumes: [ sessionsVolume ]
      // A deploy/restart drains first (Phase 3.3): LiveKit interviews finish
      // or hand off within DRAIN_TIMEOUT_S; this is the hard ceiling.
      terminationGracePeriodSeconds: 600
      // Pinned: one replica per shard — they keep the WebSocket path, which
      // needs an address the gateway can route a candidate's socket to.
      scale: { minReplicas: 1, maxReplicas: 1 }
    }
  }
}]

// ── Session pool (Phase 3): scalable, no ingress ───────────────────────────
// Starts reach it through Redis and its interviews' media + control go through
// LiveKit, so it needs no inbound connection at all. Scaled by KEDA on the
// gateway's /scaler/pool number (interviews running on the pool + waiting).
resource sessionPool 'Microsoft.App/containerApps@2024-03-01' = if (mediaTransport == 'livekit') {
  name: 'session-pool'
  location: location
  identity: { type: 'SystemAssigned' }
  properties: {
    managedEnvironmentId: acaEnv.id
    configuration: {
      activeRevisionsMode: 'Single'
      registries: [ { server: acrLoginServer, username: acr.listCredentials().username, passwordSecretRef: 'acr-password' } ]
      secrets: commonSecrets
    }
    template: {
      containers: [ {
        name: 'session'
        image: '${acrLoginServer}/interview-agent-session:${imageTag}'
        resources: { cpu: json('1.0'), memory: '2Gi' }
        env: concat(commonEnv, llmEnv, adminEnv, livekitEnv, livekitEgressEnv, [
          { name: 'SESSION_POOL', value: '1' }
          { name: 'PLACEMENT_MAX_SESSIONS', value: string(sessionPoolPerReplica) }
          { name: 'DRAIN_TIMEOUT_S', value: '540' }
          { name: 'AZURE_SPEECH_KEYS', secretRef: 'speech-keys' }
          { name: 'STT_PROVIDER', value: 'azure' }
          { name: 'TTS_PROVIDER', value: 'azure' }
        ])
        volumeMounts: [ sessionsMount ]
      } ]
      volumes: [ sessionsVolume ]
      terminationGracePeriodSeconds: 600
      scale: {
        minReplicas: sessionPoolMinReplicas
        maxReplicas: sessionPoolMaxReplicas
        rules: [ {
          name: 'interviews-per-replica'
          custom: {
            type: 'metrics-api'
            metadata: {
              url: 'https://${gateway.properties.configuration.ingress.fqdn}/scaler/pool'
              valueLocation: 'value'
              targetValue: string(sessionPoolPerReplica)
            }
          }
        } ]
      }
    }
  }
}

// ── Observability: ONE app, Prometheus + Grafana sidecars (see obs-app.bicep) ─
// Defined in a module so the SAME resource is used by this full provision AND by
// a standalone `az deployment group create -f observability/obs-app.bicep` (roll
// the obs stack without re-running the whole provision). The two containers share
// localhost → Grafana queries Prometheus at http://localhost:9090; Prometheus is
// never exposed, only Grafana's :3000 is external (password-gated, anon off).
module obsApp 'observability/obs-app.bicep' = {
  name: 'obs-app'
  params: {
    location: location
    acaEnvId: acaEnv.id
    acrLoginServer: acrLoginServer
    acrUsername: acr.listCredentials().username
    acrPassword: acr.listCredentials().passwords[0].value
    imageTag: imageTag
    envDomain: acaEnv.properties.defaultDomain
    sessionShards: join(sessionShards, ',')
    grafanaAdminPassword: grafanaAdminPassword
    metricsToken: metricsToken
  }
}

// ACR pull uses admin credentials (see the registries block on each app) rather
// than managed-identity AcrPull role assignments — the deploying user is a
// Contributor and can't create Microsoft.Authorization/roleAssignments. Admin
// creds are fetched inside the template via acr.listCredentials().

// ── Front Door (Standard) → gateway ────────────────────────────────────────
resource afd 'Microsoft.Cdn/profiles@2023-05-01' = {
  name: 'interview-afd'
  location: 'global'
  sku: { name: 'Standard_AzureFrontDoor' }
}
resource afdEndpoint 'Microsoft.Cdn/profiles/afdEndpoints@2023-05-01' = {
  parent: afd
  // Endpoint names collide globally ('interview' was taken) — suffix with a
  // stable per-RG hash. The public hostname keeps its own AFD hash regardless.
  name: 'interview-${uniqueString(resourceGroup().id)}'
  location: 'global'
  properties: { enabledState: 'Enabled' }
}
resource afdOriginGroup 'Microsoft.Cdn/profiles/originGroups@2023-05-01' = {
  parent: afd
  name: 'gateway-og'
  properties: {
    loadBalancingSettings: { sampleSize: 4, successfulSamplesRequired: 3 }
    healthProbeSettings: { probePath: '/healthz/live', probeProtocol: 'Https', probeRequestType: 'GET', probeIntervalInSeconds: 30 }
  }
}
resource afdOrigin 'Microsoft.Cdn/profiles/originGroups/origins@2023-05-01' = {
  parent: afdOriginGroup
  name: 'gateway-origin'
  properties: {
    hostName: gateway.properties.configuration.ingress.fqdn
    originHostHeader: gateway.properties.configuration.ingress.fqdn
    httpsPort: 443
    priority: 1
    weight: 1000
    enabledState: 'Enabled'
  }
}
resource afdRoute 'Microsoft.Cdn/profiles/afdEndpoints/routes@2023-05-01' = {
  parent: afdEndpoint
  name: 'default'
  dependsOn: [ afdOrigin ]
  properties: {
    originGroup: { id: afdOriginGroup.id }
    supportedProtocols: [ 'Http', 'Https' ]
    patternsToMatch: [ '/*' ]  // /* and /ws/* both go to the gateway (which proxies WS)
    forwardingProtocol: 'HttpsOnly'
    httpsRedirect: 'Enabled'
    linkToDefaultDomain: 'Enabled'
  }
}

output frontDoorHostname string = afdEndpoint.properties.hostName
output gatewayFqdn string = gateway.properties.configuration.ingress.fqdn
output redisHost string = redis.properties.hostName
output sessionShardFqdns array = [for s in sessionShards: '${s}.internal.${acaEnv.properties.defaultDomain}']
// Internal FQDN the gateway proxies /text to (TEXT_TIER_URL = http://<this>).
output textTierFqdn string = textApp.properties.configuration.ingress.fqdn
// Open the scaling dashboard here (log in as admin / grafanaAdminPassword).
output grafanaUrl string = obsApp.outputs.grafanaUrl
