#!/usr/bin/env bash
# Provision the tiered stack (Redis + Postgres + ACA env/apps + Front Door) into
# the existing resource group, wiring to the existing ACR + Storage account.
#
# Prereqs:
#   - az login  (subscription: AzureSimple Pactera)
#   - images built + pushed:  TAG=v1 deploy/build_tiers.sh acr
#   - secrets exported (see below) or you'll be prompted.
#
# Usage:
#   RESOURCE_GROUP=AI-COE STORAGE_ACCOUNT=<acct> IMAGE_TAG=v1 \
#     DATABASE_URL='postgresql+psycopg://user:pw@host.postgres.database.azure.com:5432/interview?sslmode=require' \
#     ADMIN_PASSWORD_HASH=... ADMIN_SECRET_KEY=... \
#     AZURE_SPEECH_KEYS='k1:eastus,k2:eastus' OPENROUTER_API_KEY=... GROQ_API_KEY=... \
#     deploy/aca/provision.sh
#
# Postgres is REUSED (your existing server) — pass its URL as DATABASE_URL. The
# tiered schema (jobs table + additive columns) self-creates on first boot.
set -euo pipefail

RG="${RESOURCE_GROUP:-AI-COE}"
LOCATION="${LOCATION:-eastus}"
ACR_NAME="${ACR_NAME:-interviewagentacr}"
STORAGE_ACCOUNT="${STORAGE_ACCOUNT:?set STORAGE_ACCOUNT to the existing storage account name}"
IMAGE_TAG="${IMAGE_TAG:-latest}"
BICEP="$(dirname "$0")/main.bicep"

: "${DATABASE_URL:?set DATABASE_URL to your existing Postgres (postgresql+psycopg://...)}"
: "${ADMIN_PASSWORD_HASH:?set ADMIN_PASSWORD_HASH (python scripts/admin_password.py)}"
: "${ADMIN_SECRET_KEY:?set ADMIN_SECRET_KEY}"
: "${AZURE_SPEECH_KEYS:?set AZURE_SPEECH_KEYS (comma list of key or key:region)}"
: "${OPENROUTER_API_KEY:?set OPENROUTER_API_KEY}"
GROQ_API_KEY="${GROQ_API_KEY:-}"
# Langfuse tracing — optional; empty → tracing no-ops (as before).
LANGFUSE_PUBLIC_KEY="${LANGFUSE_PUBLIC_KEY:-}"
LANGFUSE_SECRET_KEY="${LANGFUSE_SECRET_KEY:-}"
LANGFUSE_BASE_URL="${LANGFUSE_BASE_URL:-}"
LANGFUSE_PROJECT_ID="${LANGFUSE_PROJECT_ID:-}"
LANGFUSE_ENVIRONMENT="${LANGFUSE_ENVIRONMENT:-production}"
# LiveKit media plane — optional. MEDIA_TRANSPORT=websocket (default) keeps
# today's audio path; set livekit + the three LIVEKIT_* to move audio to LiveKit.
MEDIA_TRANSPORT="${MEDIA_TRANSPORT:-websocket}"
LIVEKIT_URL="${LIVEKIT_URL:-}"
LIVEKIT_API_KEY="${LIVEKIT_API_KEY:-}"
LIVEKIT_API_SECRET="${LIVEKIT_API_SECRET:-}"
if [ "$MEDIA_TRANSPORT" = "livekit" ] && { [ -z "$LIVEKIT_URL" ] || [ -z "$LIVEKIT_API_KEY" ] || [ -z "$LIVEKIT_API_SECRET" ]; }; then
  echo "MEDIA_TRANSPORT=livekit needs LIVEKIT_URL, LIVEKIT_API_KEY and LIVEKIT_API_SECRET" >&2; exit 1
fi
# Grafana admin password — REQUIRED. The in-cluster Grafana (scaling dashboard)
# has an EXTERNAL FQDN, so it must be password-gated (anonymous access is off).
: "${GRAFANA_ADMIN_PASSWORD:?set GRAFANA_ADMIN_PASSWORD for the in-cluster Grafana}"

# Pre-create the job queue so the worker can scale from zero (KEDA needs it to exist).
echo ">> ensuring 'jobs' + 'jobs-poison' queues exist on ${STORAGE_ACCOUNT}"
CONN="$(az storage account show-connection-string -g "$RG" -n "$STORAGE_ACCOUNT" --query connectionString -o tsv)"
az storage queue create --name jobs --connection-string "$CONN" -o none || true
az storage queue create --name jobs-poison --connection-string "$CONN" -o none || true

echo ">> what-if (review the plan) ..."
az deployment group what-if -g "$RG" -f "$BICEP" \
  -p acrName="$ACR_NAME" storageAccountName="$STORAGE_ACCOUNT" imageTag="$IMAGE_TAG" \
     location="$LOCATION" databaseUrl="$DATABASE_URL" \
     adminPasswordHash="$ADMIN_PASSWORD_HASH" adminSecretKey="$ADMIN_SECRET_KEY" \
     azureSpeechKeys="$AZURE_SPEECH_KEYS" openrouterApiKey="$OPENROUTER_API_KEY" \
     groqApiKey="$GROQ_API_KEY" \
     langfusePublicKey="$LANGFUSE_PUBLIC_KEY" langfuseSecretKey="$LANGFUSE_SECRET_KEY" \
     langfuseBaseUrl="$LANGFUSE_BASE_URL" langfuseProjectId="$LANGFUSE_PROJECT_ID" \
     langfuseEnvironment="$LANGFUSE_ENVIRONMENT" \
     mediaTransport="$MEDIA_TRANSPORT" livekitUrl="$LIVEKIT_URL" \
     livekitApiKey="$LIVEKIT_API_KEY" livekitApiSecret="$LIVEKIT_API_SECRET" \
     grafanaAdminPassword="$GRAFANA_ADMIN_PASSWORD" || true

read -r -p "Proceed with deployment? [y/N] " ok
[ "$ok" = "y" ] || { echo "aborted"; exit 1; }

az deployment group create -g "$RG" -f "$BICEP" \
  -p acrName="$ACR_NAME" storageAccountName="$STORAGE_ACCOUNT" imageTag="$IMAGE_TAG" \
     location="$LOCATION" databaseUrl="$DATABASE_URL" \
     adminPasswordHash="$ADMIN_PASSWORD_HASH" adminSecretKey="$ADMIN_SECRET_KEY" \
     azureSpeechKeys="$AZURE_SPEECH_KEYS" openrouterApiKey="$OPENROUTER_API_KEY" \
     groqApiKey="$GROQ_API_KEY" \
     langfusePublicKey="$LANGFUSE_PUBLIC_KEY" langfuseSecretKey="$LANGFUSE_SECRET_KEY" \
     langfuseBaseUrl="$LANGFUSE_BASE_URL" langfuseProjectId="$LANGFUSE_PROJECT_ID" \
     langfuseEnvironment="$LANGFUSE_ENVIRONMENT" \
     mediaTransport="$MEDIA_TRANSPORT" livekitUrl="$LIVEKIT_URL" \
     livekitApiKey="$LIVEKIT_API_KEY" livekitApiSecret="$LIVEKIT_API_SECRET" \
     grafanaAdminPassword="$GRAFANA_ADMIN_PASSWORD" \
  --query properties.outputs

echo ">> done. Front Door hostname is in the outputs above."
echo ">> Postgres is reused — the tiered schema (jobs table + additive columns)"
echo "   self-creates on first boot. Only if lifting OLD SQLite data into it:"
echo "     DATABASE_URL=\"\$DATABASE_URL\" python scripts/migrate_sqlite_to_postgres.py --sqlite /path/to/sessions.db"
