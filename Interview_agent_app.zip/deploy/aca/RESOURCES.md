# Azure resources for the tiered deploy

What `deploy/aca/main.bicep` provisions, what it reuses, and rough cost. You run
it against **AzureSimple Pactera** / RG **AI-COE**.

## New resources (created by the Bicep)

| Resource | SKU (default) | Why | Rough cost |
|---|---|---|---|
| **Azure Cache for Redis** `interview-redis` | Standard C1 | Coordination plane: token→shard registry, admission counters, locks, pub-sub. **The scale-out unlock.** | ~$40–80/mo |
| **Azure Container Apps env** `interview-aca-env` | Consumption | Hosts the tier apps | env is free; pay per app usage |
| **ACA app: gateway** | 0.5 vCPU / 1 GiB, 1–10 replicas (HTTP scale) | Stateless front: SPA + /api + WS proxy | ~$15–60/mo (traffic-dependent) |
| **ACA app: worker** | 0.5 vCPU / 1 GiB, 0–10 replicas (queue scale) | Background jobs; scales to **zero** when idle | ~$0 idle + burst |
| **ACA apps: session-0..N** | 1 vCPU / 2 GiB, pinned 1 replica each | Live interviews (pinned, shard-addressed) | ~$35/mo per always-on shard |
| **Azure Front Door** `interview-afd` | Standard | One public address, TLS, routes `/*` + `/ws/*` → gateway | ~$35/mo + traffic |
| **Storage queues** `jobs`, `jobs-poison` | on the existing account | Durable worker queue (created by provision.sh) | ~free |

**Est. baseline (2 session shards, low traffic): ~$130–220/mo.** Dominated by
Redis + the always-on session shards + Front Door. Scale shard count to your
concurrency target (each shard ≈ 20–30 concurrent interviews, CPU-bound).

## Reused (no new spend)

- **Postgres** — your EXISTING server from the previous iteration. Not provisioned; pass its URL as `DATABASE_URL`. The tiered schema (the new `jobs` table + additive columns) self-creates on first boot via `create_all`, so the existing DB just gains what's missing. **Ensure its firewall / private endpoint allows the ACA environment to connect** (e.g. the "Allow Azure services" rule on Flexible Server, or a VNet/private endpoint).
- **ACR** `interviewagentacr` — images pulled via each app's managed identity (AcrPull role assigned in the Bicep).
- **Storage account** (existing) — hosts three things: the **job queue** (`jobs`/`jobs-poison`), Blob artifacts (recordings + durable mirror), and a new **Azure Files share `sessions`** mounted at `SESSIONS_DIR` (`/app/sessions`) on all three tiers. That shared filesystem is load-bearing: the gateway writes a draft's files, the session shard reads them to run the interview, the worker reads events.jsonl to score — they must see the same files. The Bicep creates the share (near-free) + wires the mount.
- **Azure Speech** — add MORE Speech (Cognitive Services) resources to raise the concurrency ceiling: **1 key = 5 concurrent streams**. Pass all keys as `AZURE_SPEECH_KEYS` (comma list of `key` or `key:region`); the broker rotates across them.

## You provide (secrets, passed as secure params)

`DATABASE_URL` (your existing Postgres), `ADMIN_PASSWORD_HASH`
(`python scripts/admin_password.py`), `ADMIN_SECRET_KEY`, `AZURE_SPEECH_KEYS`,
`OPENROUTER_API_KEY`, `GROQ_API_KEY`.

## Steps

```bash
# 1. Build + push the 4 images to ACR
TAG=v1 deploy/build_tiers.sh acr

# 2. Provision (what-if first, then apply) — reuses your existing Postgres
RESOURCE_GROUP=AI-COE STORAGE_ACCOUNT=<existing-acct> IMAGE_TAG=v1 \
  DATABASE_URL='postgresql+psycopg://user:pw@<your-host>.postgres.database.azure.com:5432/interview?sslmode=require' \
  ADMIN_PASSWORD_HASH=... ADMIN_SECRET_KEY=... \
  AZURE_SPEECH_KEYS='k1:eastus,k2:eastus' OPENROUTER_API_KEY=... GROQ_API_KEY=... \
  deploy/aca/provision.sh

# 3. (Only if lifting OLD SQLite data into the existing Postgres)
DATABASE_URL='postgresql+psycopg://user:pw@<your-host>.postgres.database.azure.com:5432/interview?sslmode=require' \
  python scripts/migrate_sqlite_to_postgres.py --sqlite /path/to/sessions.db
```

## Production hardening (follow-ups, not in this scaffold)

- Put Redis + Postgres on **private endpoints** in the ACA env's VNet (the Bicep
  currently uses the Postgres "allow Azure services" firewall rule for simplicity).
- Prefer **managed identity** to Storage/Speech over connection-string secrets
  where the SDK supports it.
- Add the auth-hardening items from `deploy/README.md` before external pilot.
