// ════════════════════════════════════════════════════════════════════════
//  Observability app — ONE ACA app, Prometheus + Grafana as sidecar
//  containers. Used BOTH by deploy/aca/main.bicep (as a module) and deployable
//  standalone (`az deployment group create -f obs-app.bicep -p ...`) so the obs
//  stack can be rolled out/updated without re-running the full provision.
//
//  The two containers share localhost: Grafana queries Prometheus at
//  http://localhost:9090 (no cross-app DNS, no internal ingress) and Prometheus
//  is never exposed — only Grafana's :3000 is external. Prometheus renders its
//  scrape targets at boot from envDomain (prometheus-entrypoint.sh). Grafana is
//  password-gated (anonymous access off). App total = 1.0 vCPU / 2Gi.
// ════════════════════════════════════════════════════════════════════════

@description('Azure region.')
param location string
@description('Resource id of the existing ACA managed environment.')
param acaEnvId string
@description('ACR login server, e.g. interviewagentacr.azurecr.io')
param acrLoginServer string
@description('ACR admin username (for image pull).')
param acrUsername string
@secure()
@description('ACR admin password (for image pull).')
param acrPassword string
@description('Image tag to deploy for the prometheus + grafana images.')
param imageTag string = 'latest'
@description('ACA environment default domain — Prometheus renders shard scrape targets from it.')
param envDomain string
@description('Comma list of session shard ids to scrape, e.g. session-0,session-1')
param sessionShards string = 'session-0,session-1'
@secure()
@description('Grafana admin password (external FQDN → must be set; anonymous access is off).')
param grafanaAdminPassword string
@secure()
@description('Bearer token for the gateway /metrics/pushed scrape (pool + worker metrics). Same value as the gateway METRICS_TOKEN.')
param metricsToken string = ''

resource observabilityApp 'Microsoft.App/containerApps@2024-03-01' = {
  name: 'grafana'
  location: location
  properties: {
    managedEnvironmentId: acaEnvId
    configuration: {
      activeRevisionsMode: 'Single'
      ingress: { external: true, targetPort: 3000, transport: 'auto' }
      registries: [ { server: acrLoginServer, username: acrUsername, passwordSecretRef: 'acr-password' } ]
      secrets: [
        { name: 'acr-password', value: acrPassword }
        { name: 'grafana-admin-password', value: grafanaAdminPassword }
        { name: 'metrics-token', value: metricsToken }
      ]
    }
    template: {
      containers: [
        {
          name: 'prometheus'
          image: '${acrLoginServer}/interview-agent-prometheus:${imageTag}'
          resources: { cpu: json('0.5'), memory: '1Gi' }
          env: [
            { name: 'ACA_ENV_DOMAIN', value: envDomain }
            { name: 'SESSION_SHARDS', value: sessionShards }
            { name: 'METRICS_TOKEN', secretRef: 'metrics-token' }
          ]
        }
        {
          name: 'grafana'
          image: '${acrLoginServer}/interview-agent-grafana:${imageTag}'
          resources: { cpu: json('0.5'), memory: '1Gi' }
          env: [
            { name: 'PROMETHEUS_URL', value: 'http://localhost:9090' }
            { name: 'GF_SECURITY_ADMIN_USER', value: 'admin' }
            { name: 'GF_SECURITY_ADMIN_PASSWORD', secretRef: 'grafana-admin-password' }
            { name: 'GF_AUTH_ANONYMOUS_ENABLED', value: 'false' }
            { name: 'GF_USERS_ALLOW_SIGN_UP', value: 'false' }
          ]
        }
      ]
      scale: { minReplicas: 1, maxReplicas: 1 }
    }
  }
}

output grafanaUrl string = 'https://${observabilityApp.properties.configuration.ingress.fqdn}'
