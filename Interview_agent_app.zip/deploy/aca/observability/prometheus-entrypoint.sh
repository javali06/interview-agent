#!/bin/sh
# Render Prometheus's scrape config from the ACA environment's RUNTIME values,
# then hand off to Prometheus. The session shards' internal FQDNs are
# <shard>.internal.<envDomain>, and the env domain is only known at deploy time
# (it can't be baked into the image), so we generate the config at boot.
# Mirrors deploy/local/observability/prometheus.yml — keep the two in sync.
set -eu

DOMAIN="${ACA_ENV_DOMAIN:?set ACA_ENV_DOMAIN (acaEnv.properties.defaultDomain)}"
SHARDS="${SESSION_SHARDS:-session-0,session-1}"
# Session shards run internal ingress with allowInsecure, so plain http on the
# internal FQDN reaches them (no https redirect). Override with SCRAPE_SCHEME.
SCHEME="${SCRAPE_SCHEME:-http}"
CONFIG="/etc/prometheus/prometheus.yml"

{
  echo "global:"
  echo "  scrape_interval: 5s"
  echo "  evaluation_interval: 5s"
  echo "scrape_configs:"
  echo "  # ONE target per shard — session /metrics exports app signals, cgroup"
  echo "  # CPU/mem, audio backpressure, AND the federated VAD histograms."
  echo "  - job_name: session"
  echo "    scheme: ${SCHEME}"
  echo "    metrics_path: /metrics"
  echo "    static_configs:"
  echo "      - targets:"
  # SESSION_SHARDS is a comma list, e.g. "session-0,session-1".
  OLDIFS="$IFS"; IFS=','
  for s in $SHARDS; do
    echo "          - '${s}.internal.${DOMAIN}'"
  done
  IFS="$OLDIFS"
  echo "        labels:"
  echo "          tier: session"
  echo "  # The session pool (no ingress) and the worker publish their metrics"
  echo "  # through Redis; the gateway serves them merged. honor_labels keeps the"
  echo "  # replica each sample came from (instance) and its tier."
  echo "  - job_name: pushed"
  echo "    scheme: https"
  echo "    metrics_path: /metrics/pushed"
  echo "    honor_labels: true"
  if [ -n "${METRICS_TOKEN:-}" ]; then
    echo "    authorization:"
    echo "      credentials_file: /etc/prometheus/metrics-token"
  fi
  echo "    static_configs:"
  echo "      - targets: ['gateway.${DOMAIN}']"
} > "$CONFIG"
# The token goes in a file, not the config, so `cat "$CONFIG"` below can't log it.
if [ -n "${METRICS_TOKEN:-}" ]; then
  printf '%s' "$METRICS_TOKEN" > /etc/prometheus/metrics-token
fi

echo "[prometheus-entrypoint] scraping ${SHARDS} @ ${SCHEME}://<shard>.internal.${DOMAIN}/metrics"
cat "$CONFIG"

# TSDB is ephemeral (no persistent volume) — this is a live at-scale dashboard,
# not long-term storage; keep retention short so memory stays bounded. Azure
# Files/SMB is unsafe for the TSDB (mmap/locking), so we deliberately don't mount
# a volume here.
exec /bin/prometheus \
  --config.file="$CONFIG" \
  --storage.tsdb.path=/prometheus \
  --storage.tsdb.retention.time="${PROM_RETENTION:-6h}" \
  --web.console.libraries=/usr/share/prometheus/console_libraries \
  --web.console.templates=/usr/share/prometheus/consoles \
  --web.enable-lifecycle
