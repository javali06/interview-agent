// ════════════════════════════════════════════════════════════════════════
//  Standalone deploy of JUST the text tier — for adding it to an EXISTING
//  tiered stack without re-provisioning (and restarting) the other apps.
//
//  Declares only the `text` container app, referencing the EXISTING ACA
//  environment, ACR, and the `sessions` Azure Files env-storage. The other
//  tiers (gateway/worker/session) are untouched; the gateway's TEXT_TIER_URL is
//  set separately via `az containerapp update` after this returns the FQDN.
//  The config mirrors the `text` resource in main.bicep exactly.
//
//  Validate: az bicep build -f deploy/aca/text-app.bicep
// ════════════════════════════════════════════════════════════════════════
param location string = resourceGroup().location
param acrName string = 'interviewagentacr'
param imageTag string = 'v37'
param textReplicas int = 1
param textMaxReplicas int = 10

// Secrets — retrieved from the existing gateway app's secrets and passed in.
@secure()
param redisUrl string
@secure()
param databaseUrl string
@secure()
param storageConn string
@secure()
param openrouterKey string
@secure()
param groqKey string = ''
@secure()
param adminSecret string

// Langfuse tracing is intentionally omitted here — this stack has no Langfuse
// keys, and ACA rejects empty secrets. The tracer no-ops when its env is unset,
// so leaving LANGFUSE_* off simply means the text tier is untraced (add later by
// threading real keys through, like main.bicep does for the other tiers).

var acrLoginServer = '${acrName}.azurecr.io'

resource acr 'Microsoft.ContainerRegistry/registries@2023-07-01' existing = {
  name: acrName
}
resource acaEnv 'Microsoft.App/managedEnvironments@2024-03-01' existing = {
  name: 'interview-aca-env'
}

// Reuses the env-level `sessions` Azure Files storage that already exists (the
// shared per-session filesystem: the gateway wrote cadence.yaml here, the text
// tier reads it + writes events.jsonl for the worker to score).
var sessionsVolume = { name: 'sessions-vol', storageType: 'AzureFile', storageName: 'sessions' }
var sessionsMount = { volumeName: 'sessions-vol', mountPath: '/app/sessions' }

var secrets = [
  { name: 'redis-url', value: redisUrl }
  { name: 'database-url', value: databaseUrl }
  { name: 'storage-conn', value: storageConn }
  { name: 'openrouter-key', value: openrouterKey }
  { name: 'groq-key', value: groqKey }
  { name: 'admin-secret', value: adminSecret }
  { name: 'acr-password', value: acr.listCredentials().passwords[0].value }
]

var env = [
  { name: 'REDIS_URL', secretRef: 'redis-url' }
  { name: 'DATABASE_URL', secretRef: 'database-url' }
  { name: 'AZURE_STORAGE_CONNECTION_STRING', secretRef: 'storage-conn' }
  { name: 'BLOB_ENABLED', value: '1' }
  { name: 'BLOB_CONTAINER', value: 'sessions' }
  { name: 'EVAL_PLUGINS_ENABLED', value: '1' }
  { name: 'CODING_ENABLED', value: '1' }
  { name: 'SESSIONS_DIR', value: '/app/sessions' }
  { name: 'OPENROUTER_API_KEY', secretRef: 'openrouter-key' }
  { name: 'GROQ_API_KEY', secretRef: 'groq-key' }
  { name: 'SLOW_PROVIDER', value: 'openrouter' }
  { name: 'SLOW_PROVIDER_ORDER', value: 'Groq' }
  { name: 'FAST_PROVIDER_ORDER', value: 'Groq' }
  // TEXT_STATE_SECRET signs the browser's state blob (HMAC); reuses admin-secret
  // so it matches ADMIN_SECRET_KEY (the fallback) — same as main.bicep.
  { name: 'TEXT_STATE_SECRET', secretRef: 'admin-secret' }
  { name: 'ADMIN_SECRET_KEY', secretRef: 'admin-secret' }
]

resource textApp 'Microsoft.App/containerApps@2024-03-01' = {
  name: 'text'
  location: location
  identity: { type: 'SystemAssigned' }
  properties: {
    managedEnvironmentId: acaEnv.id
    configuration: {
      activeRevisionsMode: 'Single'
      // Internal-only (gateway → text over the private network); allowInsecure so
      // the gateway's http:// proxy call isn't 301'd to https (traffic stays in-env).
      ingress: { external: false, targetPort: 8080, transport: 'auto', allowInsecure: true }
      registries: [ { server: acrLoginServer, username: acr.listCredentials().username, passwordSecretRef: 'acr-password' } ]
      secrets: secrets
    }
    template: {
      containers: [ {
        name: 'text'
        image: '${acrLoginServer}/interview-agent-text:${imageTag}'
        resources: { cpu: json('0.5'), memory: '1Gi' }
        env: env
        volumeMounts: [ sessionsMount ]
      } ]
      volumes: [ sessionsVolume ]
      scale: {
        minReplicas: textReplicas
        maxReplicas: textMaxReplicas
        rules: [ { name: 'http', http: { metadata: { concurrentRequests: '50' } } } ]
      }
    }
  }
}

output textFqdn string = textApp.properties.configuration.ingress.fqdn
