"""deploy.gateway_app — the Gateway tier ASGI entry (stateless front).

Behind Azure Front Door this serves:
  - the React SPA (/app) + all request/response HTTP (/api/*, auth, cadence +
    rubric review/save, eval-read/results/downloads, bulk/campaign control) —
    reused verbatim from app.main, so there is no route duplication.
  - the candidate lobby static (/candidate/…).
  - /ws/candidate/*  → reverse-proxied to the owning session shard via
    the Redis registry (app.gateway.ws_proxy). The gateway runs NO interview and
    NO Stream A — it just routes.

Run:  gunicorn -k uvicorn.workers.UvicornWorker deploy.gateway_app:app
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

# Gateway serves the admin portal + candidate redirect like the cloud monolith.
os.environ.setdefault("CLOUD_MODE", "1")

import httpx  # noqa: E402
from fastapi import Request, Response, WebSocket  # noqa: E402
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse  # noqa: E402

logger = logging.getLogger("deploy.gateway_app")

# Reuse ALL request/response routes (SPA, /api, auth, eval, bulk, candidate_join).
from app.main import app  # noqa: E402
from app.coordination import ping as _redis_ping  # noqa: E402
from app.gateway import ws_proxy  # noqa: E402

REPO_ROOT = Path(__file__).resolve().parent.parent
UI_DIR = REPO_ROOT / "ui" / "candidate"


# ── candidate lobby static (mirrors the monolith's /candidate/ serving) ──────
@app.get("/candidate/")
async def _candidate_lobby() -> FileResponse:
    return FileResponse(UI_DIR / "index.html")


@app.get("/candidate/{filename:path}")
async def _candidate_static(filename: str) -> FileResponse:
    target = (UI_DIR / filename).resolve()
    # Path-traversal defence: must stay under UI_DIR.
    if not str(target).startswith(str(UI_DIR.resolve())) or not target.is_file():
        return FileResponse(UI_DIR / "index.html")  # SPA-style fallback
    return FileResponse(target)


# ── WebSocket reverse-proxy to the owning session shard ──────────────────────
@app.websocket("/ws/candidate/{session_id}")
async def _candidate_ws(ws: WebSocket, session_id: str, token: str | None = None,
                        client: str | None = None, probe: str | None = None) -> None:
    if probe:
        # The lobby's connection check: it only times the WebSocket opening.
        # Answered here, never proxied — a shard would treat it as the
        # candidate arriving (claim, Speech lease, an idle runner) while they
        # are still in the lobby, and Start would then find that WebSocket
        # session in the way of a LiveKit one.
        await ws.accept()
        await ws.close()
        return
    await ws_proxy.proxy(ws, session_id, token, client)


# ── LiveKit interview start (Phases 2–3) ────────────────────────────────────
# The page starts a LiveKit interview with ONE HTTP call instead of opening a
# WebSocket pinned to a shard. The start travels through Redis (placement): to
# the owner's inbox if the interview is already running, else to the shared
# queue any replica with room takes from — so it works when the session tier
# is a pool of replicas nothing can address. The answer is the tab's room
# token, or {"transport":"websocket"}.
@app.post("/api/candidate/{token}/start")
async def _candidate_room_start(token: str, request: Request) -> JSONResponse:
    from app.session_tier import placement
    from engine.orchestrator.livekit import config as lk_config
    if not lk_config.livekit_enabled():
        return JSONResponse({"transport": "websocket"})
    try:
        body = await request.json()
    except Exception:
        body = {}
    # Covers the AI joining the room (LIVEKIT_CONNECT_TIMEOUT_S) plus a start
    # that has to wait in the queue for a free replica.
    timeout = lk_config.connect_timeout_s() + float(os.environ.get("PLACEMENT_WAIT_S", "15"))
    try:
        status, payload = await placement.request_room_start(
            token, body if isinstance(body, dict) else {}, timeout_s=timeout)
    except Exception as e:
        # The page falls back to the WebSocket path, which shows the real error.
        logger.warning("[gw-room] start for token=%s failed: %s", token[:8], e)
        return JSONResponse({"transport": "websocket"})
    return JSONResponse(payload, status_code=status)


# Autoscaling input for the session pool (Phase 3.4): ACA's KEDA "metrics-api"
# rule reads this and runs ceil(value / interviews-per-replica) replicas. A
# number only, nothing about any interview.
@app.get("/scaler/pool")
async def _pool_scaler() -> JSONResponse:
    from app.session_tier import placement
    try:
        return JSONResponse({"value": await placement.pool_demand()})
    except Exception as e:
        logger.warning("[scaler] pool demand failed: %s", e)
        return JSONResponse({"value": 0}, status_code=503)


# Metrics of the replicas Prometheus can't reach (session pool, worker): each
# publishes to Redis, this serves them merged — see app/coordination/metrics_push.
# The gateway is public, so METRICS_TOKEN (when set) must come as a bearer token.
@app.get("/metrics/pushed")
async def _pushed_metrics(request: Request) -> Response:
    import hmac

    from prometheus_client import CONTENT_TYPE_LATEST, CollectorRegistry, Gauge, generate_latest

    from app.coordination import metrics_push
    from app.session_tier import placement

    want = (os.environ.get("METRICS_TOKEN") or "").strip()
    got = (request.headers.get("authorization") or "").removeprefix("Bearer ").strip()
    if want and not hmac.compare_digest(want, got):
        return Response(status_code=401)
    reg = CollectorRegistry()
    replicas = Gauge("interview_pushed_replicas",
                     "Pool/worker replicas whose metrics reached Redis in the last few pushes.",
                     registry=reg)
    queue = Gauge("interview_placement_queue_depth",
                  "LiveKit interview starts waiting for a pool replica to take them.",
                  registry=reg)
    try:
        pushed = await metrics_push.collect()
        replicas.set(len(pushed))
        queue.set(await placement.queue_length())
    except Exception as e:
        logger.warning("[metrics] pushed metrics unavailable: %s", e)
        pushed = {}
    body = metrics_push.merge(pushed, extra=generate_latest(reg).decode())
    return Response(body, media_type=CONTENT_TYPE_LATEST)


# ── HTTP reverse-proxy to the TEXT tier (stateless typed/chat interview) ─────
# The text tier is STATELESS — any replica serves any /text request — so there is
# NO registry/shard lookup here (that's only for the /ws voice sockets above).
# ACA's ingress round-robins across the text replicas behind TEXT_TIER_URL.
TEXT_TIER_URL = os.environ.get("TEXT_TIER_URL", "").rstrip("/")

# One pooled async client. Timeout is generous: a /start or /turn waits on the
# interview LLM. No retries — POST /turn is not idempotent.
_text_client = httpx.AsyncClient(timeout=httpx.Timeout(120.0))

# Hop-by-hop headers must not be relayed (RFC 7230 §6.1); httpx sets its own
# Host/Content-Length/Transfer-Encoding.
_HOP_BY_HOP = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailers", "transfer-encoding", "upgrade", "host", "content-length",
}


@app.api_route("/text/{path:path}", methods=["GET", "POST"])
async def _text_proxy(path: str, request: Request) -> Response:
    """Forward /text/* (method, path, query, body, headers) to the text tier and
    return its status/body/headers verbatim. Clean 502 when the tier is
    unconfigured or unreachable."""
    if not TEXT_TIER_URL:
        return JSONResponse({"detail": "text tier not configured"}, status_code=502)

    url = f"{TEXT_TIER_URL}/text/{path}"
    fwd_headers = {k: v for k, v in request.headers.items()
                   if k.lower() not in _HOP_BY_HOP}
    body = await request.body()
    # STREAM-THROUGH: /text/{start,turn} return NDJSON that streams token deltas
    # as the AI reply generates. We must NOT buffer the upstream body (that would
    # defeat streaming) — open the upstream in stream mode and relay chunks as
    # they arrive. Works identically for the plain-JSON /state·/save responses.
    req = _text_client.build_request(
        request.method, url,
        params=request.query_params, content=body, headers=fwd_headers,
    )
    try:
        upstream = await _text_client.send(req, stream=True)
    except httpx.HTTPError as e:  # connect refused / timeout / DNS → tier down
        logger.warning("[gw-text] upstream %s failed: %s", url, e)
        return JSONResponse({"detail": "text tier unavailable"}, status_code=502)

    resp_headers = {k: v for k, v in upstream.headers.items()
                    if k.lower() not in _HOP_BY_HOP}

    async def _relay():
        try:
            async for chunk in upstream.aiter_raw():
                yield chunk
        finally:
            await upstream.aclose()

    return StreamingResponse(
        _relay(), status_code=upstream.status_code,
        headers=resp_headers, media_type=upstream.headers.get("content-type"),
    )


# ── health ───────────────────────────────────────────────────────────────────
@app.get("/healthz/live")
async def _live() -> JSONResponse:
    """Process alive? (Front Door liveness)."""
    return JSONResponse({"status": "live"})


@app.get("/ready")
async def _ready() -> JSONResponse:
    """Safe to send traffic? Needs Redis (registry/admission) reachable."""
    ok = await _redis_ping()
    return JSONResponse({"status": "ready" if ok else "degraded", "redis": ok},
                        status_code=200 if ok else 503)
