"""SessionStore — the in-memory source of truth, with a single async lock.

NEW_STREAM_B.md §10.2. All mutations go through here so the director +
sub-agents see a consistent snapshot. v2 day-one is in-memory; the adapter
shape leaves room for Redis later (NEW_STREAM_B.md §13).
"""
from __future__ import annotations

import asyncio
import copy
import logging
from typing import Awaitable, Callable, TypeVar

from engine.brain.contracts.session_state import (
    AIActivityState,
    RecentAudioEvent,
    SessionState,
    Turn,
)

logger = logging.getLogger(__name__)

T = TypeVar("T")


class SessionStore:
    def __init__(self, state: SessionState) -> None:
        self._state = state
        self._lock = asyncio.Lock()

    @property
    def state(self) -> SessionState:
        """Live reference. Most readers should use snapshot() instead."""
        return self._state

    def snapshot(self) -> SessionState:
        """Deep copy for sub-agents to pass to LLMs without races."""
        return copy.deepcopy(self._state)

    async def mutate(self, fn: Callable[[SessionState], Awaitable[T] | T]) -> T:
        """Run `fn(state)` under the lock. Atomic across awaits."""
        async with self._lock:
            result = fn(self._state)
            if asyncio.iscoroutine(result):
                result = await result
            return result  # type: ignore[return-value]

    # ── convenience helpers used from many places ────────────────────────

    async def append_turn(self, turn: Turn) -> None:
        async def _do(s: SessionState) -> None:
            s.turns.append(turn)
        await self.mutate(_do)

    async def set_ai_activity(self, new_state: AIActivityState) -> None:
        async def _do(s: SessionState) -> None:
            s.ai_activity = new_state
        await self.mutate(_do)

    async def set_phase(self, new_phase: str, when_ms: int) -> None:
        async def _do(s: SessionState) -> None:
            s.phase = new_phase
            s.phase_started_at_ms = when_ms
            s.pending_phase = None
            # strikes are scoped to phase — reset on transition
            s.barge_in_strike_count = 0
            s.barge_in_strike_phase = new_phase
        await self.mutate(_do)

    async def push_audio_event(self, event: RecentAudioEvent, *, max_history: int = 12) -> None:
        async def _do(s: SessionState) -> None:
            s.recent_audio_events.append(event)
            if len(s.recent_audio_events) > max_history:
                s.recent_audio_events = s.recent_audio_events[-max_history:]
        await self.mutate(_do)
