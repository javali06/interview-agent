"""Director — the 500ms tick.

NEW_STREAM_B.md §6.1. Reads SessionState, asks `turn_taking.decide()`, and
on YES delegates to LatencyOrchestrator. Stays small (<200 lines) — all the
heavy lifting lives elsewhere.
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from typing import Awaitable, Callable

from engine.brain.contracts.events import EventKind
from engine.brain.contracts.session_state import (
    AIActivityState,
    RecentAudioEvent,
    Speaker,
    SessionState,
    Turn,
    VadState,
)
from engine.brain.contracts.tags import (
    tag_low_confidence,
    tag_no_response_yet,
)
from engine.brain.core.adaptive import AdaptiveConfig, Outcome, classify_outcome
from engine.brain.core.cadence_tracker import CadenceTracker, TickDecision
from engine.brain.core.conversation_context import build_context

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from engine.brain.agents.verifier_agent import VerifierAgent
    from engine.brain.agents.phase_override_agent import PhaseOverrideAgent
    from engine.brain.agents.guardrail_agent import GuardrailAgent
from engine.brain.core.latency.orchestrator import LatencyOrchestrator
from engine.brain.core.policy import Decision, PolicyConfig, PolicyInputs, decide
from engine.brain.core.session_store import SessionStore
from engine.brain.observability.prom import (
    STT_FIRST_PARTIAL_MS,
    STT_PARTIAL_LAG_MS,
    STT_SPOKEN_MS,
)
from engine.brain.observability.timing import log_timing
from engine.brain.observability.tracer import Tracer

logger = logging.getLogger(__name__)


# Benign <think> directive substituted for the verifier's instruction when a
# guardrail trips. The verifier's REAL instruction quotes the candidate's
# adversarial phrase verbatim (see config/prompts.yaml — guardrail
# instructions must START with the verbatim phrase), so persisting it as a
# <think> turn would feed that phrase straight back into the next verifier
# pass and re-trip the guardrail. Paired with scrubbing the candidate's turn
# from the LLM-visible history, this neutral wording (no mention of what was
# said) keeps the slow LLM re-asking the current question without ever seeing
# or echoing the adversarial content.
_GUARDRAIL_REASK_THINK = (
    "The candidate just said something that can't be addressed, so it has "
    "been intentionally left out of the transcript — that is why there is no "
    "candidate message right before this note (you are not speaking twice in "
    "a row by mistake). In your reply, briefly and warmly acknowledge that "
    "you can't address what they just said and won't be engaging with it, "
    "then re-ask the current interview question as if asking it fresh and "
    "continue normally. Do NOT repeat, quote, paraphrase, or guess what they "
    "said."
)

# Resume acknowledgment directive — routed into the per-turn <think> briefing on
# the FIRST turn after a durable resume (via verifier_instruction), so the "we're
# back, picking up where we left off" line is spoken through the NORMAL turn path
# (reliable audio) instead of a special pre-director announce, which produced no
# audio + 20s stalls in every attempt (see interview_session._resume_bringup,
# 2026-07-31). The phase-open (with the question) is still injected alongside, so
# the AI opens with the ack THEN the phase's question in one natural utterance.
_RESUME_ACK_THINK = (
    "The interview was briefly interrupted by a technical hiccup and has just "
    "reconnected. Open your reply with ONE short, warm sentence that you're back "
    "and picking up where you left off (you may reference the current topic "
    "naturally), then immediately continue with the phase's question. Do NOT "
    "mention servers, crashes, checkpoints, or that anything was lost — keep it "
    "light and natural."
)

# Mid-phase resume (Phase 4): the interview resumes at its last turn, not at the
# start of the phase, so the AI continues the conversation instead of reopening
# the phase. Same routing as _RESUME_ACK_THINK.
_RESUME_MIDPHASE_THINK = (
    "The interview was briefly interrupted by a technical hiccup and has just "
    "reconnected, mid-way through this part. Open with ONE short, warm sentence "
    "that you're back. If the candidate's answer is the last message above, "
    "respond to it as you normally would. Otherwise briefly repeat your last "
    "question so they can answer it. Do NOT mention servers, crashes, "
    "checkpoints, or that anything was lost — keep it light and natural."
)

# Silence re-engagement directive — routed into the per-turn <think> briefing
# (via verifier_instruction) on a silence_prompt dispatch, replacing the old
# <silence_ms=N/> user tag. The silence clock now starts at REAL playback end
# (the browser's audio_playback_finished ack), so this only fires when the
# candidate has genuinely gone quiet after the AI finished speaking.
_SILENCE_REASK_THINK = (
    "The candidate has been silent for ~{s}s and has NOT responded to your last "
    "question — there is no candidate message right before this note (you are not "
    "speaking twice by mistake). This turn is a re-engagement, NOT a reply: do not "
    "thank or acknowledge anything (they said nothing). Gently repeat or rephrase "
    "your last question so they can answer."
)


# Muted-mic directive — the muted twin of _SILENCE_REASK_THINK above, on the
# same per-turn <think> channel and the same trigger (silence_prompt). Rule 4
# fires when the candidate has gone quiet; this says WHY when the reason is
# known, instead of re-asking a question they cannot answer.
#
# Deliberately NOT fired at the moment of muting: see on_mic_muted. There it
# would displace the answer to what they just said.
_MUTED_THINK = (
    "The candidate has not replied because their microphone is MUTED — you "
    "cannot hear them, and they may not have noticed. This turn is NOT a reply "
    "and NOT a re-ask: in one short, friendly sentence tell them they appear to "
    "be muted and ask them to unmute whenever they're ready. Do not repeat your "
    "question, and do not thank or acknowledge anything — they said nothing."
)


def build_coding_phase_started_payload(phase_def) -> dict | None:
    """Build the `coding_phase_started` event payload for a phase, or None if
    the phase is not a coding phase, coding is disabled, or a question can't be
    resolved.

    Shared by the Director's phase-transition apply (normal entry into a coding
    phase) AND the durable-resume path (InterviewSession._resume_bringup), so a
    resumed coding phase re-mounts the editor with the exact same payload the
    browser would have received on a live transition."""
    coding_qids: list[str] = list(getattr(phase_def, "coding_question_ids", []) or [])
    if not coding_qids:
        return None
    try:
        from features.coding import (
            is_enabled as _cd_enabled, resolve_question as _cd_resolve,
        )
    except Exception:  # coding feature not importable in this build
        return None
    if not _cd_enabled():
        return None
    overrides: dict[str, int] = getattr(
        phase_def, "coding_question_time_overrides", None,
    ) or {}
    # Definitions copied into THIS cadence from an authored pool (if any) win
    # over the built-in library — see PhaseDef.coding_questions_inline.
    inline: dict = getattr(phase_def, "coding_questions_inline", None) or {}
    questions: list[dict] = []
    for qid in coding_qids:
        q = _cd_resolve(qid, inline)
        t = int(overrides.get(qid) or q.time_budget_s)
        questions.append({
            "question_id": q.id,
            "title": q.title,
            "question_prompt": q.prompt,
            "starter_code": q.starter_code,
            "function_name": q.function_name,
            "difficulty": q.difficulty,
            "test_cases": [
                {"name": tc["name"], "input": tc["input"], "expected": tc["expected"]}
                for tc in q.test_cases
            ],
            "test_case_count": len(q.test_cases),
            "time_budget_s": t,
            "hint_count": len(q.hints),
        })
    if not questions:
        return None
    first = questions[0]
    return {
        "phase_id": phase_def.id,
        "questions": questions,
        "question_count": len(questions),
        "total_time_budget_s": sum(q["time_budget_s"] for q in questions),
        "phase_duration_s": phase_def.duration_s,
        # Legacy top-level fields (first question) — old browser mounts on
        # these; new browser reads `questions`.
        "question_id": first["question_id"],
        "question_prompt": first["question_prompt"],
        "starter_code": first["starter_code"],
        "function_name": first["function_name"],
        "test_cases": first["test_cases"],
        "test_case_count": first["test_case_count"],
        "time_budget_s": first["time_budget_s"],
    }


def _turn_checkpointable(phase_def) -> bool:
    """Phases a turn checkpoint can resume mid-way. A coding round's editor
    state and a scenario phase's media cursor aren't in the checkpoint, so those
    keep the phase-start checkpoint (resume reopens the phase)."""
    if getattr(phase_def, "coding_question_ids", None):
        return False
    if getattr(phase_def, "is_scenario_analysis", False):
        return False
    return True


class Director:
    def __init__(
        self,
        *,
        store: SessionStore,
        tracer: Tracer,
        latency: LatencyOrchestrator,
        tracker: CadenceTracker,
        verifier_agent: "VerifierAgent | None" = None,
        phase_override_agent: "PhaseOverrideAgent | None" = None,
        guardrail_agent: "GuardrailAgent | None" = None,
        elapsed_ms_provider: Callable[[], int],
        # STT provider name ("azure" / "groq" / …) — used only as the
        # `provider` label on the STT latency histograms. Purely for
        # observability; None → labelled "unknown".
        stt_provider: str | None = None,
        tick_interval_ms: int = 500,
        policy_config: PolicyConfig | None = None,
        protected_strike_threshold: int = 3,
        max_follow_ups_per_question: int = 1,
        adaptive_config: AdaptiveConfig | None = None,
        on_speech_start_cancel: Callable[[], asyncio.Future] | None = None,
        on_endpoint_cancel_pending_barge: Callable[[], asyncio.Future] | None = None,
        on_session_end_requested: Callable[[], None] | None = None,
        # Async callable invoked at EACH phase transition with (new_phase_id,
        # snapshot_of_state.turns) so a durable checkpoint can be written to
        # Redis (see app/coordination/interview_checkpoint). Best-effort: the
        # callback owns its own timeout + try/except so a Redis hiccup never
        # breaks a tick. None = checkpointing disabled (local / ad-hoc runs).
        on_checkpoint: Callable[[str, list[Turn]], Awaitable[None]] | None = None,
        wrap_up_end_grace_ms: int = 500,
        # Endpoints whose utterance duration is below this are rejected as
        # noise (cough / paper / door click): no synthesis, no Turn
        # appended, no verifier/slow LLM kicked, and the silence-timer
        # state is rewound to pre-utterance. Mirrors the warmup pattern
        # already used for barge-in. Overridable via NOISE_THRESHOLD_MS
        # in App Settings (and `policy.noise_threshold_ms` in the local
        # system_config.yaml).
        noise_threshold_ms: int = 1500,
    ) -> None:
        self._store = store
        self._tracer = tracer
        self._latency = latency
        self._tracker = tracker
        self._verifier_agent = verifier_agent
        self._phase_override_agent = phase_override_agent
        self._guardrail_agent = guardrail_agent
        # STT provider label for the STT latency histograms (see prom.py).
        self._stt_provider = stt_provider or "unknown"
        # Stashed from the most recent on_stt_final → reset to None once
        # the next dispatch consumes it (so a stale instruction never
        # bleeds into a turn it wasn't computed for).
        self._latest_verifier_instruction: str | None = None
        # The coverage tags the LAST partial_answer verification flagged as
        # missing (and that the AI then re-asked). On the NEXT verification
        # (the follow-up) the verifier is scoped to ONLY these — the rest of
        # the question was already covered. Reset to [] when the question is
        # consumed or the phase changes.
        self._latest_missing_tags: list[str] = []
        self._elapsed_ms = elapsed_ms_provider
        self._tick_ms = tick_interval_ms
        self._cfg = policy_config or PolicyConfig()
        self._protected_threshold = protected_strike_threshold
        # Hard cap on consecutive `partial_answer` verdicts before the
        # Director auto-promotes the next one to `partial_answer_skip`
        # (pop the pool question, move on). Counted in code — NOT
        # delegated to the verifier LLM — so the cap is a strict
        # guarantee, not a soft hint.
        if max_follow_ups_per_question < 0:
            raise ValueError(
                f"max_follow_ups_per_question must be >= 0, got "
                f"{max_follow_ups_per_question}",
            )
        self._max_follow_ups = max_follow_ups_per_question
        # Rubric thresholds for adaptive-difficulty phases. Only consulted when
        # the current phase's pool is adaptive; harmless otherwise. The tracker
        # holds its own copy for level moves — this one is just for the
        # Director's `classify_outcome` call at the consume hook.
        self._adaptive_config = adaptive_config or AdaptiveConfig()
        # Counter for consecutive `partial_answer` verdicts on the
        # CURRENT pool question. Resets on (a) question pop — `answered`
        # or auto-promoted skip, (b) phase change.
        self._partial_count_current_q: int = 0
        # Async callable invoked synchronously on every VAD speech_start to
        # eagerly cancel any in-flight AI turn (the immediate barge-in path).
        # InterviewSession provides this — it has access to TTS state.
        self._on_speech_start_cancel = on_speech_start_cancel
        # Async callable invoked on VAD endpoint_detected — InterviewSession
        # uses it to cancel any still-pending barge-in warm-up task. If
        # endpoint fired before the warm-up expired, the utterance was a
        # short noise burst, not a real barge-in.
        self._on_endpoint_cancel_pending_barge = on_endpoint_cancel_pending_barge
        # Synchronous callable invoked once we've finished the AI's farewell
        # turn in WRAP_UP. InterviewSession passes a method that sets its
        # stop event so `run_until_signal()` returns cleanly.
        self._on_session_end_requested = on_session_end_requested
        # Async checkpoint hook — called at each phase transition. See kwarg doc.
        self._on_checkpoint = on_checkpoint
        # Tiny grace after AI's last sink-drain before we signal end. Lets
        # the audio actually finish reaching the speakers (the AUDIO_DONE
        # transition fires after sink drain, but we wait a hair more so
        # the candidate hears the full farewell before the script exits).
        self._wrap_up_end_grace_ms = wrap_up_end_grace_ms
        self._noise_threshold_ms = noise_threshold_ms
        self._wrap_up_end_fired = False
        self._stop = asyncio.Event()
        self._has_greeted = False
        # Re-arm flag: set ONLY when the most recent phase-transition
        # dispatch's AI turn was barged-in before reaching audio_done.
        # The next natural dispatch (when the candidate finally finishes
        # responding) will be promoted to a phase_transition trigger so
        # the phase intro is retried with the proper truncated history
        # + PHASE BOUNDARY framing. Phase apply itself happens in the
        # YES branch right before dispatch; nothing else sets this flag.
        self._phase_intro_pending = False
        # Set by InterviewSession._resume_bringup when resuming from a durable
        # checkpoint. On the FIRST phase-transition re-open dispatch after a
        # resume, the phase clock is re-anchored to `now_ms` right before the
        # slow-LLM call — so the phase budget starts at the LLM call, excluding
        # bring-up + the resume announce. Cleared after that one re-anchor.
        self._resume_clock_pending = False
        # Set by InterviewSession._resume_bringup: on the FIRST phase-transition
        # re-open after a resume, fold a "we're back, picking up on [topic]"
        # acknowledgment into the normal turn's <think> briefing so it's spoken
        # through the reliable turn path. Cleared after that one turn.
        self._resume_ack_pending = False
        # Mid-phase resume (Phase 4): the first dispatch continues the restored
        # conversation (no phase re-open), and the phase clock resumes with the
        # time the phase had already used.
        self._resume_midphase_pending = False
        self._resume_phase_elapsed_ms = 0
        self._turn_ckpt_task: asyncio.Task | None = None
        # Coding-panel unmount handshake: when leaving a coding phase the apply
        # block awaits this Event (set by on_coding_panel_closed once the browser
        # confirms the editor unmounted) before dispatching the next phase's
        # opening turn — so the AI never talks over a live editor. Bounded by the
        # timeout so a client that never acks can't stall the interview.
        self._coding_close_event = asyncio.Event()
        self._coding_close_timeout_s = float(
            os.getenv("CODING_PANEL_CLOSE_TIMEOUT_S", "2.5")
        )
        # ── mic mute / audio-starvation ──────────────────────────────
        # The VAD decides the candidate has finished by HEARING a tail of
        # silence. Silence is still audio; mute sends nothing at all, so the
        # endpoint that would move SPEAKING/PAUSED → DONE can never fire and
        # `candidate_speaking` latches True — which makes turn_taking return
        # NO on every tick, so the AI is locked out for the rest of the
        # interview. Both of these close that hole.
        self._mic_muted = False
        # True once "you seem to be muted" has been said for the CURRENT mute.
        # Without it the silence prompt would repeat it every ~15s at someone
        # who has stepped away. Cleared on unmute.
        self._muted_prompt_fired = False
        # Wall-clock of the last VAD event of ANY kind. Deliberately not
        # `last_any_speech_ms`, which means "we heard speech" — this means
        # "the VAD is still talking to us at all", which is the question the
        # watchdog actually asks.
        self._last_vad_event_ms = 0
        # The VAD's OWN `ts_ms` from that event — a different clock from
        # `_elapsed_ms()`: it counts audio received and restarts at 0 on each
        # connection, while `_elapsed_ms()` is wall time and carries across a
        # resume (observed 135s apart after one). A synthesized endpoint must
        # stamp THIS one, or events.jsonl gets a timestamp from the wrong clock
        # and anything ordering by it — the transcript, the trace, the eval
        # sectioner — reads a wild outlier. It is also the truer answer: the
        # utterance ended at the last audio we actually received.
        self._last_vad_ts_ms = 0
        # Backstop for every way audio can stop without a mute message: a
        # dropped socket, a revoked mic permission, a tab the OS suspended.
        # Well clear of a normal endpoint, which needs only the VAD's tail.
        self._audio_starved_timeout_ms = int(
            os.getenv("AUDIO_STARVED_TIMEOUT_MS", "5000")
        )
        self._audio_starved_fired = False
        # Timestamp (ms since session start) of the most recent EXPLICIT
        # request to end the interview — set when the verifier returns
        # `wrap_up_complete` on the terminal phase OR when phase_override
        # fires `end_now`. The wrap-up auto-end check waits until the AI
        # has produced an audio_end AFTER this timestamp (= the farewell
        # turn has finished playing) before requesting session shutdown.
        # Stays None until something explicitly asks to end — preventing
        # the auto-end from firing just because we entered wrap_up.
        self._end_request_ts_ms: int | None = None
        # Turn id of the most recent phase_transition dispatch. Used to
        # detect when the phase-intro AI turn was barged_in before it
        # could deliver the new phase's opening: in that case the next
        # tick re-arms `_phase_intro_pending` so the AI gets ONE more
        # chance to open the new phase cleanly. Without this, a single
        # mid-transition barge would silently leave us in the new phase
        # with the slow LLM still anchored on the old phase's history.
        self._phase_intro_turn_id: str | None = None
        # Task kicked off by on_stt_final that runs the verifier + phase-
        # override agents in parallel. The director awaits this task BEFORE
        # dispatching the slow LLM so the verifier instruction is always
        # available in the slow LLM's context. Set to None when no STT-
        # triggered agents are in flight.
        self._post_stt_agents_task: asyncio.Task | None = None
        # Dedupe flag for the dual-signal coordinator. Set to the
        # last_speech_start_ts_ms of the utterance we've already
        # dispatched the post-STT pipeline for. Prevents a second STT
        # partial (or a duplicate VAD endpoint) from re-firing the
        # pipeline within the same utterance.
        self._post_stt_dispatched_for_speech_start_ms: int = 0
        self._last_endpoint_ms: int | None = None
        # Sticky timestamp of the most recent VAD endpoint, for STT-latency
        # timing. Distinct from _last_endpoint_ms which gets cleared when a
        # turn dispatches. This one is read once by on_stt_final to compute
        # endpoint→final latency.
        self._last_stt_endpoint_ts_ms: int | None = None
        # When ms_since_last_endpoint is consumed (turn fired), clear it.
        # STT-wait state. After 3 fills of "give me a moment" with no STT
        # delivery, we escalate to "Could you say that again?" and discard
        # any late STT delivery for the abandoned utterance. Cleared on
        # the next VAD speech_start (= candidate is starting fresh).
        self._stt_wait_escalated: bool = False
        # ── Utterance segmentation → conversation history (2026-06-02) ─
        # Azure STT segments a single spoken answer into MULTIPLE
        # `recognized` finals on mid-thought pauses. Rather than buffer
        # the segments and merge them into one Turn (a buffer that kept
        # dropping earlier segments under various Azure quirks), we append
        # EACH `recognized` segment to the conversation history as its own
        # candidate Turn immediately, with the existing
        # `<no_response_yet/>` tagging that tells the LLM to treat
        # consecutive candidate turns as ONE combined message. The
        # verifier / tracker / slow LLM are still NOT triggered per
        # segment — only at the VAD endpoint, where the trailing
        # un-finalized partial (if any) is appended as a final candidate
        # Turn and the post-STT pipeline kicks once. The slow LLM then
        # sees the full multi-turn answer in history and responds to all
        # of it.
        #
        # All of these reset on the FIRST speech_start of a new utterance
        # (prev_state IDLE/DONE) and after each endpoint.
        # ── Segment detection via Azure phrase OFFSET ─────────────────
        # Azure's recognizing partials carry the phrase START offset, which
        # is ~stable across one segment's partial chain and JUMPS forward
        # (by the silence gap) when Azure starts the next segment — even
        # when Azure doesn't fire a usable `recognized`. We track the
        # current segment's offset + latest partial; on an offset jump we
        # COMMIT the current segment to `_utterance_segments` and start a
        # new one. At the VAD endpoint we commit the active segment and join
        # the buffer into ONE candidate Turn.
        self._seg_offset_ms: int | None = None   # current segment phrase offset
        self._seg_text: str = ""                 # current segment latest partial
        self._seg_end_ms: int = 0
        self._utterance_segments: list[str] = []  # committed segments (buffer)
        self._utterance_min_conf: float = 1.0
        # Total audio duration (ms) of the current utterance, summed across
        # its committed segments. Azure's `recognized` events rarely fire in
        # this deployment, so the STT client's per-segment cost emission
        # (azure_stt_client._dispatch_final) almost never runs — STT cost
        # would stay $0. Instead we own STT cost HERE: each committed segment
        # contributes (end_ms - offset_ms), and at the VAD endpoint we emit
        # ONE Langfuse `stt.final` carrying this total so both Langfuse and
        # the cost_tracker rollup get a real STT cost.
        self._utterance_audio_ms: int = 0
        # An offset jump larger than this (ms) marks a new segment. Within a
        # segment the offset is ~constant; a new segment after the ~1000ms
        # segmentation silence jumps by >=1s, so 250ms is a safe margin that
        # ignores any tiny within-segment offset wobble.
        self._seg_offset_jump_ms: int = 250
        # Dedupe: speech_start ts of the utterance we've already finalized
        # at endpoint, so a duplicate endpoint can't double-append.
        self._utterance_finalized_for_speech_start_ms: int = 0
        # Pre-utterance silence-timer snapshot + the timestamp of the
        # FIRST speech_start of the current utterance (the one where
        # prev_state was IDLE or DONE). VAD fires multiple speech_start
        # / speech_end pairs inside one logical utterance (breath gaps,
        # glottal stops, mid-thought pauses) — only the first transition
        # OUT of silence matters for "when did the utterance begin".
        # The endpoint handler:
        #   - uses (now_ms - _current_utterance_start_ts_ms) for the
        #     noise-rejection duration check
        #   - restores _pre_utterance_* if the duration was below
        #     noise_threshold_ms
        # Reset to 0 after each endpoint so the next utterance starts
        # tracking from its own first speech_start.
        self._current_utterance_start_ts_ms: int = 0
        # STT head-lag metric: whether the FIRST partial of the current
        # utterance has been seen yet. Reset to False on each new utterance's
        # first speech_start; set True when the first partial arrives (we
        # observe speech_start → first-partial into STT_FIRST_PARTIAL_MS then).
        self._first_partial_seen: bool = False
        # STT per-partial-lag metric: the streaming recognizer's audio-stream
        # offset (ms) at the utterance's FIRST partial, used to anchor the
        # per-partial recognition lag (see on_stt_partial / STT_PARTIAL_LAG_MS).
        # None until the first partial of the current utterance arrives; reset
        # on each new utterance's first speech_start.
        self._utterance_stream_start_ms: int | None = None
        self._pre_utterance_any_speech_ms: int = 0
        self._pre_utterance_candidate_spoke: bool = False

    def request_stop(self) -> None:
        self._stop.set()

    # Candidate-said-ending-phrase detector — short, high-confidence phrases
    # that mean "we're done with this interview". Used as a deterministic
    # fallback when the verifier/phase_override LLMs miss the signal.
    # Two lists: STRONG (match anywhere in utterance) and WEAK (match only
    # in short utterances <=8 words so we don't trip on "thanks for the
    # explanation, can you talk more about X?").
    _ENDING_PHRASES_STRONG: tuple[str, ...] = (
        "end the interview",
        "end interview",
        "stop the interview",
        "no more questions",
        "that's all from me",
        "that's all i have",
        "that's everything",
        "i'm done with the interview",
        "i am done with the interview",
        "let's wrap up",
        "let's wrap this up",
        "let's call it",
        "we can wrap up",
        "i need to go",
        "i have to leave",
        "i have to go",
    )
    _ENDING_PHRASES_WEAK: tuple[str, ...] = (
        "thank you",
        "thanks for your time",
        "thanks so much",
        "thank you so much",
        "thanks a lot",
        "appreciate your time",
        "appreciate it",
        "i'm done",
        "i am done",
        "we're done",
        "we are done",
        "goodbye",
        "good bye",
        "bye",
        "have a good day",
        "have a good one",
        "talk to you soon",
        "talk soon",
    )

    @classmethod
    def _matches_ending_phrase(cls, text: str) -> str | None:
        # Returns the matched phrase (for logging) or None.
        #
        # STRONG phrases: substring match anywhere — these are unambiguous
        # ("no more questions", "let's wrap up", "I'm done with this interview").
        #
        # WEAK phrases: must be the WHOLE utterance (after stripping
        # punctuation/whitespace). "thank you" said as a polite opener
        # ("Yeah, hi, thank you for asking") must NOT end the interview;
        # only "Thank you." said alone — when the candidate is signing off
        # — should.
        if not text:
            return None
        norm = text.lower().strip()
        # Strip trailing punctuation runs like "Thank you." or "Thanks!!"
        norm = re.sub(r"[\s.!?,;]+$", "", norm)
        for phrase in cls._ENDING_PHRASES_STRONG:
            if phrase in norm:
                return phrase
        for phrase in cls._ENDING_PHRASES_WEAK:
            if norm == phrase:
                return phrase
        return None

    # Scenario-analysis skip phrases: a candidate asking to move on from an
    # item, or admitting they don't know. Substring match (unlike the ending
    # phrases' WEAK list) since these are typically said alongside part of an
    # attempted answer ("hmm, I'm not sure, can we just skip this one?"),
    # not necessarily as the whole utterance.
    _SCENARIO_SKIP_PHRASES: tuple[str, ...] = (
        "i don't know", "i dont know", "not sure", "no idea",
        "can we skip", "let's skip", "lets skip", "skip this",
        "skip it", "move on", "next question", "pass on this",
        "i'll pass", "ill pass",
    )

    @classmethod
    def _matches_skip_phrase(cls, text: str) -> bool:
        if not text:
            return False
        norm = text.lower().strip()
        return any(phrase in norm for phrase in cls._SCENARIO_SKIP_PHRASES)

    def request_session_end(self, *, reason: str = "external") -> None:
        # Arm the wrap-up auto-end gate from outside the director (e.g., the
        # WS submit handler when a terminal coding-phase candidate clicks
        # Submit and there's no verifier wrap_up_complete signal because the
        # verifier was gated off during CODING). Idempotent — first caller
        # wins, so a later phase_override end_now can't overwrite an earlier
        # coding-submit request and reset the audio-end wait.
        if self._end_request_ts_ms is None:
            self._end_request_ts_ms = self._elapsed_ms()
            self._tracer.event(
                "session_end_requested_external",
                reason=reason,
                ts_ms=self._end_request_ts_ms,
            )
            logger.info(
                "[end] external session end requested (reason=%s ts=%dms)",
                reason, self._end_request_ts_ms,
            )

    async def run(self) -> None:
        # Pyodide preload: if any phase in this cadence has a coding
        # question AND the feature is enabled, emit one `coding_preload`
        # event so the browser starts downloading the ~6 MB WASM in the
        # background. Without this, the candidate sees ~10 s of spinner
        # when the coding phase actually starts.
        try:
            from features.coding import is_enabled as _cd_enabled
            if _cd_enabled():
                _phases = getattr(self._tracker.plan, "phases", [])
                # Schema validator normalises both singular and plural forms,
                # so coding_question_ids is the canonical source.
                if any(getattr(p, "coding_question_ids", None) for p in _phases):
                    self._tracer.event("coding_preload")
                    logger.info(
                        "[coding] emitted coding_preload (cadence has a coding phase)"
                    )
        except Exception as _pe:
            logger.warning("[coding] preload trigger failed: %s", _pe)

        try:
            while not self._stop.is_set():
                started = time.perf_counter()
                await self._tick()
                elapsed = time.perf_counter() - started
                sleep_for = max(0.0, self._tick_ms / 1000.0 - elapsed)
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=sleep_for)
                except asyncio.TimeoutError:
                    continue
                else:
                    return
        except asyncio.CancelledError:
            return

    async def on_mic_muted(self, muted: bool) -> None:
        """The candidate muted or unmuted their own microphone.

        Mute is the one way an utterance can end that the VAD cannot see.
        Muting stops the frames, and the endpoint the VAD would have fired is
        made of the silence those very frames would have carried — so without
        this the state machine sits in SPEAKING/PAUSED forever and
        `candidate_speaking` never goes False. Verified from a live session:
        56s of audio across a 101s interview, no `endpoint_detected` after the
        mute, and the AI silent for the rest of it.

        So a mute mid-utterance IS an endpoint, and is DELEGATED to the
        ordinary handler rather than reimplemented beside it — the noise
        rejection, the STT finalize, the barge-in cancel and the tracer event
        all have to behave exactly as they do for a real one.

        Called from the WS inbound dispatcher on a `mic_muted` message.
        """
        self._mic_muted = bool(muted)
        if not self._mic_muted:
            # Unmute needs nothing: frames resume, and the VAD starts a fresh
            # utterance from DONE on the next speech_start. Re-arm the notice so
            # a LATER mute is announced again — it is once per mute, not once
            # per interview.
            self._muted_prompt_fired = False
            logger.info("[MIC] candidate unmuted")
            return
        logger.info("[MIC] candidate muted")
        if not self._store.state.candidate_speaking:
            return                      # nothing in flight to close
        logger.info(
            "[MIC] muted mid-utterance — forcing the endpoint the VAD can no "
            "longer see, so the AI is not locked out."
        )
        # NOTHING is said about the mute on this turn. It is tempting, but
        # "candidate_speaking" is SPEAKING *or* PAUSED, and PAUSED is just the
        # VAD's 600ms tail after someone stops talking — so a candidate who
        # finishes an answer and then mutes (the natural order) is always still
        # "speaking" here. Observed live: a complete 159-char question, muted
        # 465ms after the last word and 135ms before the endpoint would have
        # fired by itself, got a "you're muted" instead of an answer. The notice
        # belongs on the silence prompt, where there is no reply to displace.
        await self.on_vad_event(
            "endpoint_detected",
            {"ts_ms": self._last_vad_ts_ms, "confidence": 1.0},
        )

    def on_coding_panel_closed(self) -> None:
        """Browser confirmed the coding editor unmounted. Releases the
        code-discussion opening turn that the apply-block handshake is holding
        (see the coding-exit hook in _tick). Called from the coding inbound
        dispatcher on a `coding_panel_closed` message."""
        self._coding_close_event.set()

    def on_scenario_media_ack(self, kind: str) -> None:
        """Candidate browser reported a Visual Scenario Analysis item's media
        finished playing / errored / was skipped by the candidate. Forwards
        straight into the current phase's `ScenarioCursor` — unlike the
        coding dismount handshake this needs no `asyncio.Event`: the
        dispatch-suppression check in `_tick` polls the cursor's own bounded
        wait every tick (see `scenario_needs_media_wait`), so there's nothing
        here to unblock synchronously. Called from the coding-style inbound
        WS dispatcher on a `scenario_media_ended` / `scenario_media_error` /
        `scenario_media_skipped` message. Safe to call when no scenario
        phase is active (no-op)."""
        cursor = self._tracker.scenario_cursor()
        if cursor is None:
            return
        _kind_map = {"scenario_media_ended": "ended", "scenario_media_error": "error",
                     "scenario_media_skipped": "skipped"}
        cursor.media_ack(_kind_map.get(kind, kind))  # tolerate either the WS msg name or the bare kind
        self._tracer.event(
            "scenario_media_ack", phase_id=self._tracker.current_phase_id,
            item_id=(cursor.current_item().id if cursor.current_item() else None),
            # NOT `kind=` — Tracer.event's own first positional parameter is
            # itself named `kind`, so a payload field of the same name raises
            # "got multiple values for argument 'kind'" (caught by
            # tests/test_scenario_director_glue.py).
            ack_kind=kind,
        )

    def _emit_scenario_item_dispatch(self, cursor) -> None:
        """Emit `scenario_item_dispatched` for `cursor`'s CURRENT item, if
        it's freshly awaiting its media (AWAIT_MEDIA_INTRO) — mirrors the
        pool branch's `question_dispatched`, fired once per fresh
        presentation. Idempotent by construction: `next_action()` only
        returns "show_media" while the cursor is still in
        AWAIT_MEDIA_INTRO, and this advances the stage right after, so a
        second call (e.g. a stray extra tick) is a harmless no-op."""
        action = cursor.next_action()
        if action.get("action") != "show_media":
            return
        item = action["item"]
        self._tracer.event(
            "scenario_item_dispatched",
            phase_id=cursor.phase_id,
            item_id=item.id,
            item_index=cursor.index,
            item_total=len(cursor.items),
            media={"kind": item.media.kind, "ref": item.media.ref,
                   "filename": item.media.filename, "mime_type": item.media.mime_type},
            question_text=item.question,
            coverage_tags=list(item.coverage_tags),
            max_followups=item.max_followups,
        )
        cursor.media_intro_dispatched(self._elapsed_ms() / 1000.0)

    async def _tick(self) -> None:
        state = self._store.state
        now_ms = self._elapsed_ms()

        # ── audio-starvation watchdog ────────────────────────────────
        # `candidate_speaking` can only be cleared by an endpoint, and an
        # endpoint can only be reached by the VAD hearing silence. Anything
        # that stops frames outright — a dropped socket, a revoked mic
        # permission, an OS-suspended tab, or a mute from a browser too old
        # to send the message below — strands the interview with the AI
        # forbidden from speaking. The explicit mute message handles the
        # common case; this catches the rest, so the class of bug is closed
        # rather than one instance of it.
        if (
            state.candidate_speaking
            and not self._audio_starved_fired
            and self._last_vad_event_ms > 0
            and (now_ms - self._last_vad_event_ms) >= self._audio_starved_timeout_ms
        ):
            self._audio_starved_fired = True
            logger.warning(
                "[MIC] no VAD signal for %dms while mid-utterance — forcing "
                "the endpoint so the AI is not locked out (muted=%s).",
                now_ms - self._last_vad_event_ms, self._mic_muted,
            )
            await self.on_vad_event(
                "endpoint_detected",
                {"ts_ms": self._last_vad_ts_ms, "confidence": 1.0},
            )
            state = self._store.state      # re-read: the endpoint mutated it

        # Re-arm phase_intro if the most recent phase-transition dispatch
        # got barged_in before reaching audio_done. The barged turn now
        # sits in state.turns with a <barged_in/> tag — without re-arming,
        # the next dispatch would default to `endpoint` trigger and the
        # slow LLM (anchored on the old-phase history) would revert to
        # the old phase's question. Re-arming forces ONE more attempt at
        # the phase-transition opening with the proper marker + tracker
        # block in front of it.
        if (
            self._phase_intro_turn_id is not None
            and not self._phase_intro_pending
        ):
            for t in reversed(state.turns):
                if t.turn_id != self._phase_intro_turn_id:
                    continue
                if t.speaker == Speaker.AI and (
                    "<barged_in" in (t.text or "")
                ):
                    self._phase_intro_pending = True
                    # The candidate didn't actually hear the question
                    # (barge fired before audio finished) — clear the
                    # "presented" flag so the retry re-shows the
                    # question text in full.
                    if self._tracker.current_phase().uses_question_pool:
                        self._tracker.unmark_current_question_presented()
                    self._tracer.event(
                        "phase_intro_rearmed",
                        reason="barged_in_before_completion",
                        turn_id=self._phase_intro_turn_id,
                        phase=state.phase,
                    )
                # Found it — consume the id so we only re-arm once per
                # phase-intro turn, regardless of outcome.
                self._phase_intro_turn_id = None
                break

        # NO top-of-tick eager phase-apply. Phase transitions queued
        # during silence used to apply here the moment AI went idle, then
        # force a YES dispatch — meaning the AI would speak a second
        # turn (the phase intro) right after its first turn, without
        # ever waiting for the candidate. That breaks natural turn-
        # taking: the candidate hears two AI utterances back-to-back.
        #
        # Instead, the pending phase is applied at the LAST moment —
        # inside the YES branch below, right before the dispatch. By
        # then policy has already decided to dispatch (because the
        # candidate spoke / silence_prompt fired / it's the greeting),
        # so the AI's NEXT turn is naturally triggered, not forced.
        # The applied phase change is invisible until that natural
        # dispatch needs the new context.

        # Tracker-driven phase decision. Concrete time-based logic.
        await self._maybe_advance_via_tracker(now_ms)

        # Auto-end on terminal phase. We only end after an EXPLICIT signal
        # that the wrap-up exchange is done:
        #   - the verifier returned `wrap_up_complete` (candidate signalled
        #     the close, e.g., "no questions, thanks"), OR
        #   - the phase-override agent fired `end_now` (explicit user
        #     request to stop the interview)
        # AND the AI has finished delivering its farewell turn AFTER the
        # signal landed (so the candidate hears the goodbye before the
        # session shuts down). Without these guards the auto-end fires
        # right after the FIRST wrap_up AI turn and never gives the
        # candidate a chance to reply — leaving them mid-conversation.
        if (
            not self._wrap_up_end_fired
            and self._tracker.is_terminal_phase()
            and self._end_request_ts_ms is not None
            and state.ai_activity == AIActivityState.AUDIO_DONE
            and state.last_audio_end_ts_ms > self._end_request_ts_ms
            and (now_ms - state.last_audio_end_ts_ms) >= self._wrap_up_end_grace_ms
            and self._on_session_end_requested is not None
        ):
            self._wrap_up_end_fired = True
            since_end_s = (now_ms - state.last_audio_end_ts_ms) / 1000
            logger.info(
                "[WRAP_UP] AI farewell complete (%.1fs after audio_end) — "
                "ending session.", since_end_s,
            )
            self._tracer.event(
                EventKind.SESSION_ENDED,
                reason="wrap_up_complete",
                phase=state.phase,
                ms_since_audio_end=int(now_ms - state.last_audio_end_ts_ms),
            )
            try:
                self._on_session_end_requested()
            except Exception as e:  # pragma: no cover
                logger.warning("on_session_end_requested raised: %s", e)
            return

        # Compose policy inputs.
        ms_since_endpoint: int | None = None
        if self._last_endpoint_ms is not None:
            ms_since_endpoint = max(0, now_ms - self._last_endpoint_ms)

        ms_since_speech = max(0, now_ms - state.last_any_speech_ms) \
            if state.last_any_speech_ms > 0 else 999_999_999

        # Have we got a candidate turn that the AI hasn't responded to yet?
        # This is the SIGNAL that STT delivered text. Without this guard, the
        # director can dispatch the LLM before STT's transcript arrives →
        # LLM answers a question it never heard.
        last_turn_is_candidate = bool(
            state.turns and state.turns[-1].speaker == Speaker.CANDIDATE
        )

        # Rule-1 gate: VAD endpoint must be for the current utterance
        # (= timestamp > last_speech_start_ts_ms). VAD endpoint is the
        # single trigger; STT final is not required here.
        vad_endpoint_after_speech_start = (
            state.last_endpoint_ts_ms > state.last_speech_start_ts_ms
        )

        policy_inputs = PolicyInputs(
            now_ms=now_ms,
            ai_activity=state.ai_activity,
            candidate_speaking=state.candidate_speaking,
            ms_since_last_endpoint=ms_since_endpoint,
            ms_since_any_speech=ms_since_speech if state.last_any_speech_ms > 0 else 0,
            in_protected_response=state.in_protected_response,
            mic_dropout=False,                   # wired later if MicAudioSource emits it
            mic_muted=self._mic_muted,
            muted_prompt_fired=self._muted_prompt_fired,
            is_first_turn=not self._has_greeted,
            last_turn_is_candidate=last_turn_is_candidate,
            candidate_spoke_since_last_ai=state.candidate_spoke_since_last_ai,
            vad_endpoint_after_speech_start=vad_endpoint_after_speech_start,
        )

        decision = decide(policy_inputs, self._cfg)

        # phase_intro_dispatch is computed AFTER policy YES, when we
        # apply the pending phase right before dispatch (see below).
        # We no longer force YES based on a pre-set _phase_intro_pending
        # flag — that path made the AI speak a second back-to-back turn
        # whenever a phase budget expired during silence. The natural
        # policy is: dispatch only when (a) candidate spoke, (b) silence
        # prompt fires, or (c) greeting/first turn. The pending phase
        # then rides on top of that natural dispatch.
        phase_intro_dispatch = False

        self._tracer.event(
            EventKind.DIRECTOR_TICK,
            now_ms=now_ms, decision=decision.value,
            ai_activity=state.ai_activity.value,
            candidate_speaking=state.candidate_speaking,
            ms_since_endpoint=ms_since_endpoint,
            ms_since_speech=ms_since_speech if state.last_any_speech_ms > 0 else None,
            last_turn_is_candidate=last_turn_is_candidate,
            phase=state.phase,
            phase_elapsed_s=self._tracker.elapsed_in_phase_s(),
            barge_in_strike_count=state.barge_in_strike_count,
            phase_intro=phase_intro_dispatch,
        )

        if decision is not Decision.YES:
            return

        # The verifier + phase-override agents fire from on_stt_final and
        # stash a Task on self._post_stt_agents_task. They MUST complete
        # before the slow LLM call so:
        #   1. The verifier instruction is in the slow LLM's context.
        #   2. Any phase override has queued pending_phase in time for the
        #      apply step (which already ran at top of this tick to catch
        #      pre-existing pending phases, but won't see a pending set
        #      mid-tick by a still-running override).
        # In the common case the fast agents have already finished by now
        # (sub-second). When they haven't, we wait — which is exactly the
        # ordering the design calls for: tracker + verifier inform the
        # slow LLM, not the other way around.
        if self._post_stt_agents_task is not None:
            try:
                await self._post_stt_agents_task
            except Exception:  # pragma: no cover — task has its own fallback
                logger.exception("[POST-STT] agents task raised")
            self._post_stt_agents_task = None

        # Apply any pending phase RIGHT NOW, immediately before dispatch.
        # This is the ONLY place pending phases apply — there's no
        # top-of-tick eager apply anymore. By the time we get here policy
        # has already decided YES (candidate spoke / silence_prompt /
        # greeting), so applying here just rides on top of the natural
        # dispatch instead of forcing an extra AI turn during silence.
        # Whether the pending was queued by a time_budget expiry, a
        # phase_override, or an LLM intent: same handler.
        state = self._store.state
        if (
            state.pending_phase is not None
            and state.ai_activity in (
                AIActivityState.IDLE, AIActivityState.AUDIO_DONE,
                # CODING is included so a coding phase can transition out
                # of itself when the candidate submits OR the time budget
                # expires. Without this, ai_activity=CODING would block the
                # phase advance and the interview would stall.
                AIActivityState.CODING,
            )
            and not state.candidate_speaking
        ):
            from_p = state.phase
            to_p = state.pending_phase
            await self._store.set_phase(to_p, when_ms=now_ms)
            self._tracker.jump_to(to_p, reason="apply_pending_pre_dispatch")
            self._tracer.event(
                EventKind.PHASE_CHANGED,
                from_phase=from_p, to_phase=to_p, reason="natural",
            )

            # ── Coding feature: emit phase_ended if LEAVING a coding phase ──
            # Browser unmounts the editor overlay so the candidate can see
            # the avatar speak in the next (non-coding) phase.
            _left_coding = False
            try:
                _from_phase = self._tracker.plan.get_phase(from_p)
                if getattr(_from_phase, "coding_question_ids", None):
                    _left_coding = True
                    # Clear BEFORE the emit so a coding_panel_closed ack that
                    # races in during the emit/mutate below isn't lost — the
                    # wait_for right after this hook consumes it.
                    self._coding_close_event.clear()
                    self._tracer.event(
                        "coding_phase_ended",
                        phase_id=from_p,
                        reason="natural",
                    )
                    # Reset ai_activity → IDLE. Submit-path WS dispatchers
                    # set AUDIO_DONE for us, but the time-budget exit path
                    # bypasses them entirely; without this, the next phase
                    # would enter with ai_activity=CODING and the dispatch
                    # gate below would suppress every tick.
                    async def _reset_ai_activity(s: SessionState) -> None:
                        s.ai_activity = AIActivityState.IDLE
                    await self._store.mutate(_reset_ai_activity)
                    logger.info(
                        "[coding-hook] emitted phase_ended for %s "
                        "(exiting coding phase) + ai_activity=IDLE", from_p,
                    )
            except Exception as _exit_e:
                logger.warning("[coding-hook] phase_ended emit failed: %s", _exit_e)

            # ── Scenario feature: emit phase_ended if LEAVING a scenario
            # phase ── mirrors the coding-exit hook: the browser unmounts its
            # media panel so the candidate sees the avatar in the next phase.
            try:
                _from_phase_sc = self._tracker.plan.get_phase(from_p)
                if getattr(_from_phase_sc, "is_scenario_analysis", False):
                    self._tracer.event(
                        "scenario_phase_ended", phase_id=from_p, reason="natural",
                    )
                    logger.info(
                        "[scenario-hook] emitted phase_ended for %s "
                        "(exiting scenario phase)", from_p,
                    )
            except Exception as _sc_exit_e:
                logger.warning(
                    "[scenario-hook] phase_ended emit failed: %s", _sc_exit_e,
                )

            # ── Coding feature: wait for the browser to confirm the editor
            # unmounted before the next phase's opening turn dispatches below, so
            # the AI never talks over a live editor. Covers EVERY coding-round
            # exit (time budget, override advance, candidate-asks-to-end,
            # all-submitted) — they all funnel through this apply block. Bounded
            # so a client that never acks (old build / error) can't stall.
            if _left_coding:
                try:
                    await asyncio.wait_for(
                        self._coding_close_event.wait(),
                        timeout=self._coding_close_timeout_s,
                    )
                    logger.info("[coding-hook] panel-close ack received")
                except asyncio.TimeoutError:
                    logger.warning(
                        "[coding-hook] panel-close ack not received in %.1fs — "
                        "proceeding with code-discussion",
                        self._coding_close_timeout_s,
                    )
                # Start the NEXT round's phase clock only now — after the panel is
                # gone — so the dismount wait isn't charged to its budget (mirrors
                # the resume-clock re-anchor).
                self._tracker._phase_started_at_ms = self._elapsed_ms()

            # ── Coding feature: emit phase_started if entering coding phase ──
            # Uses tracer.event() — the proven canonical publish path that
            # STT_FINAL / PHASE_CHANGED also use. The payload builder is shared
            # with the resume path so a resumed coding phase re-mounts identically.
            try:
                _entered = self._tracker.plan.get_phase(to_p)
            except Exception as _hook_e:
                logger.warning("[coding-hook] get_phase(%s) failed: %s", to_p, _hook_e)
                _entered = None
            _payload = (
                build_coding_phase_started_payload(_entered)
                if _entered is not None else None
            )
            if _payload is not None:
                try:
                    self._tracer.event("coding_phase_started", **_payload)
                    logger.info(
                        "[coding-hook] coding_phase_started emitted phase_id=%s "
                        "questions=%d total_budget=%ds",
                        to_p, _payload["question_count"],
                        _payload["total_time_budget_s"],
                    )
                    # Set ai_activity = CODING — gates director dispatch
                    async def _set_coding(s: SessionState) -> None:
                        s.ai_activity = AIActivityState.CODING
                    await self._store.mutate(_set_coding)
                    logger.info("[coding-hook] ai_activity=CODING set")
                except Exception as _e:
                    logger.warning(
                        "[coding-hook] failed to fire phase_started: %s",
                        _e, exc_info=True,
                    )

            # ── Scenario feature: emit the first item's media on phase entry ──
            # Mirrors the coding-enter hook immediately above: the media panel
            # should mount on the candidate's screen as soon as the phase
            # begins, before the AI's opening turn is even dispatched (which
            # happens moments later via phase_intro_dispatch=True below) —
            # same "mount now, speak shortly after" shape as
            # coding_phase_started/CodingPanel. No special ai_activity is set
            # (unlike CODING) — a scenario phase is a normal conversational
            # phase to the verifier/guardrail/phase_override triad; only
            # dispatch itself is gated while media plays (see the
            # dispatch-suppression check below).
            if _entered is not None and getattr(_entered, "is_scenario_analysis", False):
                _cursor = self._tracker.scenario_cursor(to_p)
                if _cursor is not None:
                    try:
                        self._emit_scenario_item_dispatch(_cursor)
                    except Exception as _sc_e:
                        logger.warning(
                            "[scenario-hook] failed to emit first item: %s",
                            _sc_e, exc_info=True,
                        )

            marker_text = self._tracker.render_transition_marker(
                from_p, to_p, reason="natural",
            )
            # ── Persistent phase-history truncation ──
            # On EVERY phase change, trim state.turns so only the most
            # recent turn before the marker survives. Going forward all
            # agents (slow LLM, verifier, override, filler, apology) read
            # ctx.recent_turns and naturally see only the current phase
            # plus that single anchor turn — no per-agent slicing logic
            # needed. The events.jsonl still has the full history for
            # the admin dashboard; only the runtime SessionState gets
            # trimmed. When the next phase change fires, we trim again
            # against the new turns accumulated within this phase.
            async def _truncate_for_phase_change(s: SessionState) -> None:
                if s.turns:
                    s.turns = s.turns[-1:]
            await self._store.mutate(_truncate_for_phase_change)
            await self._store.append_turn(Turn(
                turn_id=f"phase-marker-{now_ms}",
                speaker=Speaker.UNKNOWN,
                text=marker_text,
                start_ms=now_ms, end_ms=now_ms, confidence=1.0,
            ))

            # ── Durable checkpoint (phase boundary) ──
            # state.turns is now exactly [anchor, phase-marker] — the state this
            # phase STARTS with. Persist it + the new phase id so a fresh runner
            # (after a shard restart / crash / evict) can resume THIS phase from
            # the beginning instead of re-greeting. Best-effort: the callback
            # owns its own timeout + try/except, so Redis latency/failure can
            # never break the tick or the interview.
            if self._on_checkpoint is not None:
                try:
                    await self._on_checkpoint(to_p, list(self._store.state.turns))
                except Exception as _ck_e:  # pragma: no cover — never fatal
                    logger.warning("[checkpoint] write at phase %s failed: %s",
                                   to_p, _ck_e)

            phase_intro_dispatch = True
            # New phase → new pool question (or generic phase). Reset
            # the consecutive-partial counter so the cap restarts fresh
            # for the first question of the new phase.
            self._partial_count_current_q = 0
            self._latest_missing_tags = []
            # Drop the stashed verifier instruction — it was classifying
            # the candidate's last reply in the OLD phase and shouldn't
            # shape the intro to the NEW phase.
            self._latest_verifier_instruction = None
            state = self._store.state

        # Re-arm path: prior phase_intro turn was barged-in. Treat THIS
        # dispatch as a phase_transition too, so it retries the new-phase
        # opening with truncated history + PHASE BOUNDARY framing. We
        # check the flag AFTER the apply above so a normal apply still
        # takes precedence (sets phase_intro_dispatch = True).
        if self._phase_intro_pending and not phase_intro_dispatch:
            phase_intro_dispatch = True

        # Decide trigger BEFORE we mutate state — drives whether the
        # latency orchestrator fires fillers/apologies for this turn.
        # Greeting is special-cased; otherwise the trigger comes from
        # whether the LAST turn was the candidate (real response) or whether
        # we're prompting on silence.
        midphase_resume = False
        if phase_intro_dispatch:
            trigger = "phase_transition"
            self._phase_intro_pending = False
        elif self._resume_midphase_pending:
            # First turn after a mid-phase resume: answer the candidate's last
            # answer if it's the last turn, else re-ask (see the think below).
            midphase_resume = True
            self._resume_midphase_pending = False
            trigger = "endpoint" if last_turn_is_candidate else "silence_prompt"
        elif not self._has_greeted:
            trigger = "greeting"
        elif last_turn_is_candidate:
            trigger = "endpoint"
        else:
            trigger = "silence_prompt"

        # Greeting flag set on first YES.
        self._has_greeted = True

        # Consume the endpoint (one shot; don't fire the same endpoint twice).
        self._last_endpoint_ms = None

        # Cancel any STT-wait filler still running — we're dispatching now.
        await self._latency.cancel_stt_wait_filler()

        # Clear candidate_spoke_since_last_ai — we're consuming this
        # utterance by dispatching a turn.
        async def _clr(s: SessionState) -> None:
            s.candidate_spoke_since_last_ai = False
        await self._store.mutate(_clr)

        # Build the context with the cadence tracker + the latest verifier
        # instruction (from the parallel agent run after the last STT
        # delivery). Pass-and-consume — clear so a stale instruction
        # never bleeds into a turn it wasn't computed for.
        verifier_instr = self._latest_verifier_instruction
        self._latest_verifier_instruction = None
        # Silence re-engagement: on a silence_prompt dispatch (candidate didn't
        # respond), inject a <think> directive to re-ask the last question —
        # through the same per-turn <think> briefing channel as the verifier note.
        if trigger == "silence_prompt" and not verifier_instr:
            if self._mic_muted:
                # Silent because the mic is OFF, not because they are thinking.
                # Re-asking the question would be answering the wrong question;
                # say what is actually wrong instead. Once per mute.
                verifier_instr = _MUTED_THINK
                self._muted_prompt_fired = True
            else:
                _sil_ms = max(0, now_ms - self._store.state.last_any_speech_ms)
                verifier_instr = _SILENCE_REASK_THINK.format(s=_sil_ms // 1000)
        # Resume acknowledgment: the FIRST turn after a durable resume opens with a
        # brief "we're back, continuing on [topic]" folded into the <think>
        # briefing — spoken through the NORMAL turn path (reliable audio), not the
        # old special pre-director announce. The phase-open + question ride
        # alongside via is_phase_transition, so it's one natural utterance.
        if self._resume_ack_pending and phase_intro_dispatch:
            verifier_instr = _RESUME_ACK_THINK
            self._resume_ack_pending = False
        elif self._resume_ack_pending and midphase_resume:
            verifier_instr = _RESUME_MIDPHASE_THINK
            self._resume_ack_pending = False
        ctx = build_context(
            self._store.state, now_ms=now_ms,
            tracker=self._tracker,
            verifier_instruction=verifier_instr,
            is_phase_transition=phase_intro_dispatch,
        )

        # Emit policy_decision (only on YES — less noise per §9.2).
        self._tracer.event(
            EventKind.POLICY_DECISION, decision="yes", phase=state.phase,
            silence_ms=ctx.candidate_silence_ms, trigger=trigger,
        )

        # Protected-response check (§8B.4).
        if (
            state.barge_in_strike_count >= self._protected_threshold
            and not state.in_protected_response
        ):
            await self._enter_protected_mode()
            ctx = build_context(
                self._store.state, now_ms=now_ms,
                tracker=self._tracker,
                verifier_instruction=verifier_instr,
                is_phase_transition=phase_intro_dispatch,
            )
            trigger = "protected"

        logger.info(
            "[DIRECTOR] dispatch trigger=%s phase=%s silence_ms=%d strikes=%d",
            trigger, state.phase, ctx.candidate_silence_ms,
            state.barge_in_strike_count,
        )

        # ── Coding feature: gate dispatch in coding phases ─────────────
        # ALLOW the very first dispatch in a coding phase (the intro turn
        # saying "Here's a coding exercise") which is a phase_transition.
        # SUPPRESS everything after that — the candidate is typing and
        # silence_prompt / endpoint follow-ups would constantly interrupt.
        # The phase exits when the candidate submits (launcher mutates
        # pending_phase) or the time budget expires.
        try:
            _cur_phase_obj = self._tracker.plan.get_phase(state.phase)
            _is_coding_phase = bool(getattr(_cur_phase_obj, "coding_question_ids", None))
            _is_scenario_phase = bool(getattr(_cur_phase_obj, "is_scenario_analysis", False))
        except Exception:
            _is_coding_phase = False
            _is_scenario_phase = False
        if _is_coding_phase and trigger != "phase_transition":
            logger.info(
                "[DIRECTOR] dispatch suppressed — coding phase post-intro "
                "(trigger=%s phase=%s)", trigger, state.phase,
            )
            return

        # ── Scenario feature: suppress dispatch while an item's video/audio
        # media is still playing ─────────────────────────────────────────
        # The framing turn ("here's the video, I'll wait") was ALREADY
        # dispatched (that's what put the cursor in AWAIT_MEDIA_ACK) — this
        # gate only blocks the FOLLOWING turn (the question), so the AI never
        # talks over the media. Non-blocking: each tick just re-checks the
        # cursor's own bounded wait (see scenario_needs_media_wait) instead of
        # an asyncio.Event + wait_for like the coding dismount handshake —
        # "do not block indefinitely" falls out for free since a timeout is
        # simply a tick where the check returns False.
        if _is_scenario_phase:
            _now_s = now_ms / 1000.0
            _cursor = self._tracker.scenario_cursor()
            if _cursor is not None:
                if _cursor.needs_media_wait(_now_s):
                    logger.info(
                        "[DIRECTOR] dispatch suppressed — scenario item media "
                        "still playing (trigger=%s phase=%s)", trigger, state.phase,
                    )
                    return
                if _cursor.media_wait_timed_out(_now_s):
                    # Bounded wait expired with no ack — proceed rather than
                    # block indefinitely (per the runtime spec). Treat it as
                    # "ended" so the item can still be answered; the timeout
                    # itself is recorded for the admin trace.
                    logger.warning(
                        "[scenario] media wait timed out (phase=%s item=%s) — "
                        "proceeding without an ack", state.phase,
                        (_cursor.current_item().id if _cursor.current_item() else None),
                    )
                    self._tracer.event(
                        "scenario_media_wait_timeout", phase_id=state.phase,
                        item_id=(_cursor.current_item().id if _cursor.current_item() else None),
                    )
                    _cursor.media_ack("ended")

        # ── persist runtime tags into history (KV-cache stability) ────
        # The slow-LLM dispatch emits ephemeral runtime messages at the
        # prompt tail — `<silence_ms=N/>` (user), out-of-band state tags
        # (system), and the verifier+tracker `<think>` directive (user).
        # Today these are recomputed every dispatch and never written
        # back, so the previous turn's `<think>` block disappears from
        # the conversation between candidate_N and ai_N on the next
        # dispatch. That breaks prefix KV-cache and makes the candidate's
        # follow-up history look incoherent.
        #
        # Fix: append each runtime message as a Turn to state.turns
        # BEFORE start_turn fires. The slow LLM's _build_messages then
        # picks them up via turns_to_messages naturally, and future
        # dispatches see them at the same chronological position. The
        # Turn carries an explicit `message_role` override so the
        # synthesized turn gets the correct OpenAI role regardless of
        # speaker.
        await self._persist_runtime_tags(ctx, now_ms=now_ms)

        # ── Resume: start the phase clock at THIS LLM call ──
        # On the FIRST re-open dispatch after a durable resume, anchor the
        # phase budget to now — the exact moment the rebuilt message list is
        # sent to the slow LLM. This EXCLUDES bring-up + the resume announce
        # (which ran before the director started) from the phase budget, so a
        # resumed phase gets its full time from the LLM call, mirroring a normal
        # transition (where jump_to + dispatch happen in the same tick). One-shot.
        if self._resume_clock_pending and (phase_intro_dispatch or midphase_resume):
            # A mid-phase resume keeps the time the phase had already used; a
            # phase re-open starts it afresh.
            self._tracker._phase_started_at_ms = now_ms - (
                self._resume_phase_elapsed_ms if midphase_resume else 0)
            self._resume_clock_pending = False
            self._tracer.event(
                "resume_phase_clock_started", phase=state.phase, now_ms=now_ms,
            )
            logger.info(
                "[RESUME] phase clock started at LLM dispatch phase=%s now_ms=%d",
                state.phase, now_ms,
            )

        # Per-turn checkpoint (Phase 4): the candidate's answer is in the
        # state and the AI is about to respond — if the runner is lost from
        # here on, a resume restores exactly this and the AI responds again;
        # the candidate never repeats an answer. In the background: it must
        # add nothing to the turn's latency.
        if (trigger in ("endpoint", "silence_prompt", "protected")
                and self._on_checkpoint is not None
                and _turn_checkpointable(self._tracker.current_phase())):
            try:
                self._turn_ckpt_task = asyncio.create_task(self._on_checkpoint(
                    state.phase, list(self._store.state.turns), kind="turn",
                    tracker=self._tracker.to_snapshot(),
                    phase_elapsed_ms=max(0, now_ms - self._tracker._phase_started_at_ms),
                ))
            except Exception as e:  # never break a turn for a checkpoint
                logger.warning("[checkpoint] turn checkpoint failed: %s", e)

        turn_id = await self._latency.start_turn(ctx, trigger=trigger)
        # Don't await completion — keep ticking. Audio coordination is
        # entirely inside LatencyOrchestrator.

        # Remember the turn id of a phase_transition dispatch so the
        # next tick can detect if it was barged_in and re-arm.
        if trigger == "phase_transition":
            self._phase_intro_turn_id = turn_id

        # NOTE: we do NOT pop the pool question here. The verifier judges
        # the candidate's reply on the next turn and the pool is popped
        # only when it returns intent="answered". This means the same
        # pool question stays in front of the slow LLM across multiple
        # turns until it's actually answered — which is exactly what the
        # author of a `specific` phase wants.
        #
        # For specific-mode phases, mark the current question as
        # "presented" so the NEXT render suppresses the question text.
        # Subsequent turns just remind the LLM to follow the verifier's
        # push instruction; they don't re-print the question (re-printing
        # would beg a verbatim re-ask). When the verifier finally says
        # "answered", `pick_next_question()` pops and clears this flag,
        # so the next turn presents the NEW question in full.
        if self._tracker.current_phase().uses_question_pool:
            fresh = self._tracker.mark_current_question_presented()
            # ASK-TIME record: emit once per question (only on a fresh
            # presentation, not on follow-up re-pushes — `fresh` is True
            # exactly once per question id; a barge-in before audio resets
            # the flag so the re-ask fires it again, which the eval sectioner
            # dedupes).
            if fresh:
                q = self._tracker.peek_next_question()
                if q is not None:
                    # Generic per-question BOUNDARY marker for ALL specific
                    # phases (was previously emitted only for adaptive ones).
                    # Post-interview evaluation (features/eval/sectioner.py)
                    # splits the transcript into per-question segments on these
                    # markers and joins them to the cadence / question-pool by
                    # `question_id`. The payload carries the identifiers a
                    # scoring plugin needs (difficulty / coverage_tags) so it
                    # can grade a question without re-deriving them from prose.
                    self._tracer.event(
                        "question_dispatched",
                        phase_id=self._tracker.current_phase_id,
                        question_id=q.id,
                        question_text=q.text,
                        topic=q.topic,
                        difficulty=q.difficulty,
                        coverage_tags=list(q.coverage_tags),
                    )
                    # Adaptive phases ALSO emit the legacy difficulty-ladder
                    # record for one release (existing readers / benchmarking).
                    # The sectioner uses `adaptive_question_asked` only as a
                    # boundary ALIAS when `question_dispatched` is absent (old
                    # logs); once this dual-emit is removed it relies solely on
                    # `question_dispatched`.
                    if self._tracker.is_adaptive_phase():
                        ad = self._tracker.adaptive_state()
                        if ad is not None:
                            self._tracer.event(
                                "adaptive_question_asked",
                                phase=self._tracker.current_phase_id,
                                question_id=q.id,
                                topic=q.topic,
                                difficulty=q.difficulty,
                                level_transition=ad.last_transition,
                                trigger=ad.last_trigger,
                                recovered_streak=ad.recovered_streak,
                                questions_remaining_by_level=ad.remaining_counts(),
                            )
                            logger.info(
                                "[CADENCE/ADAPTIVE] asking '%s' difficulty=%s "
                                "transition=%s",
                                q.id, q.difficulty, ad.last_transition,
                            )

        # Scenario bookkeeping — mirrors the pool block immediately above,
        # advancing the cursor's stage now that the LLM has actually been
        # dispatched with this turn's instruction (show media / ask the
        # question / push a follow-up). Item 0 of a freshly-entered phase
        # was already dispatched by the apply-block's enter hook above (so
        # this is a no-op for it — `next_action()` no longer says
        # "show_media" once `media_intro_dispatched` has run); this call
        # matters for item 2+ within the SAME phase, whose "show_media"
        # bookkeeping has no apply-block hook to run it.
        elif self._tracker.current_phase().is_scenario_analysis:
            cursor = self._tracker.scenario_cursor()
            if cursor is not None:
                action = cursor.next_action()
                kind = action.get("action")
                if kind == "show_media":
                    self._emit_scenario_item_dispatch(cursor)
                elif kind == "ask_question":
                    item = action["item"]
                    # NOTE: this records the AUTHORED question text, not the
                    # LLM's actual rephrased words — `start_turn` above is
                    # fire-and-forget (Director doesn't await generation), so
                    # the exact spoken phrasing isn't known synchronously at
                    # dispatch time. Mirrors question_dispatched's own
                    # existing limitation for pool-mode's "verbatim" ask.
                    cursor.question_dispatched(item.question)
                    self._tracer.event(
                        "scenario_question_asked",
                        phase_id=self._tracker.current_phase_id,
                        item_id=item.id,
                        question_text=item.question,
                    )
                elif kind == "ask_followup":
                    missing = action.get("missing_tags") or []
                    cursor.followup_dispatched(f"(follow-up on: {', '.join(missing)})")
                    self._tracer.event(
                        "scenario_followup_asked",
                        phase_id=self._tracker.current_phase_id,
                        item_id=(action["item"].id if action.get("item") else None),
                        missing_tags=missing,
                    )

    # ── public hooks called by InterviewSession when STT/VAD events arrive ──

    async def on_stt_partial(
        self, text: str, words: list[dict], end_ms: int, start_ms: int = 0,
    ) -> None:
        # Bump silence timer on candidate speech.
        async def _do(s: SessionState) -> None:
            s.last_any_speech_ms = self._elapsed_ms()
        await self._store.mutate(_do)
        text = (text or "").strip()
        if not text:
            return
        # STT head lag: speech_start → FIRST partial with real text. VAD
        # already had the audio at speech_start, so this delay is purely STT —
        # the "delay before the first caption" signal. Fires once per utterance.
        # The first partial also anchors the per-partial lag below: `start_ms`
        # is the recognizer's audio-stream offset for this phrase, our zero for
        # "audio recognized so far within this utterance".
        if not self._first_partial_seen and self._current_utterance_start_ts_ms > 0:
            self._first_partial_seen = True
            self._utterance_stream_start_ms = start_ms
            head_lag = self._elapsed_ms() - self._current_utterance_start_ts_ms
            if head_lag >= 0:
                STT_FIRST_PARTIAL_MS.labels(self._stt_provider).observe(head_lag)
        # STT per-partial recognition lag: how far BEHIND real time the
        # streaming recognizer is AT this partial (fires on EVERY partial, so
        # the panel shows the lag distribution, not one sample per utterance).
        #   audio_recognized = end_ms - <stream offset at utterance start>
        #   wall_elapsed     = now  - <wall time at speech_start>
        #   lag              = wall_elapsed - audio_recognized
        # Flat small lag ⇒ STT keeps pace; growing lag ⇒ it's falling behind.
        # `lag >= 0` naturally drops providers that don't supply a per-phrase
        # audio offset (Groq keeps start_ms/end_ms at 0/cumulative → negative).
        if (
            self._utterance_stream_start_ms is not None
            and self._current_utterance_start_ts_ms > 0
        ):
            audio_recognized = end_ms - self._utterance_stream_start_ms
            wall_elapsed = self._elapsed_ms() - self._current_utterance_start_ts_ms
            lag = wall_elapsed - audio_recognized
            if lag >= 0:
                STT_PARTIAL_LAG_MS.labels(self._stt_provider).observe(lag)
        # Segment detection via Azure phrase offset. `start_ms` is the START
        # offset of the phrase Azure is recognizing. Within one segment it's
        # ~constant while the partial grows/self-corrects; when Azure starts
        # the NEXT segment after its segmentation silence, start_ms jumps
        # forward. On a jump, COMMIT the segment we were building and begin
        # a fresh one. (For backends that don't supply an offset — Groq /
        # Stream A, start_ms stays 0 — the jump never triggers, so the whole
        # utterance is one segment: identical to "keep the latest partial".)
        if (
            self._seg_offset_ms is not None
            and start_ms > self._seg_offset_ms + self._seg_offset_jump_ms
            and self._seg_text
        ):
            committed = self._commit_segment(self._seg_text)
            if committed:
                self._utterance_audio_ms += self._seg_audio_ms()
                self._tracer.event(
                    "stt_segment", text=self._seg_text,
                    offset_ms=self._seg_offset_ms, end_ms=self._seg_end_ms,
                    reason="offset_jump", new_offset_ms=start_ms,
                )
            self._seg_offset_ms = start_ms
            self._seg_text = text
            self._seg_end_ms = end_ms
        elif self._seg_offset_ms is None:
            self._seg_offset_ms = start_ms
            self._seg_text = text
            self._seg_end_ms = end_ms
        else:
            # Same segment — Azure refined/extended the partial.
            self._seg_text = text
            self._seg_end_ms = end_ms

    def _seg_audio_ms(self) -> int:
        """Audio duration (ms) of the segment the tracker currently holds.

        Azure's phrase `offset` (start_ms) and `end_ms` are both ABSOLUTE
        timestamps from the start of the recognition stream, so the segment
        length is simply end − offset. Backends that don't supply an offset
        (Groq / Stream A) keep offset at 0 and report a cumulative end_ms, so
        end − 0 still gives the right per-segment length. Returns 0 when the
        tracker has no open segment (e.g. a `recognized` with no prior
        partials), which keeps the rare path from contributing garbage."""
        if self._seg_offset_ms is None:
            return 0
        d = self._seg_end_ms - self._seg_offset_ms
        return d if d > 0 else 0

    def _commit_segment(self, text: str) -> bool:
        """Append one completed segment's text to the utterance buffer.
        Returns True if committed, False if empty/noise. The caller is
        responsible for adding `_seg_audio_ms()` to `_utterance_audio_ms`
        BEFORE mutating the segment tracker (offset/end)."""
        text = (text or "").strip()
        if not text or _is_noise_only(text):
            return False
        self._utterance_segments.append(text)
        return True

    async def on_stt_final(
        self, text: str, words: list[dict], end_ms: int,
        confidence: float, utterance_id: str,
    ) -> None:
        """Azure fired a REAL `recognized` for the current segment. Commit
        it to the buffer (the recognized text is Azure's corrected version)
        and reset the segment tracker so the next partial starts a fresh
        segment. Does NOT kick the verifier/tracker/slow LLM — that fires
        once at the VAD endpoint over the joined buffer.

        Azure does NOT reliably fire `recognized` for every segment; the
        offset-jump path in on_stt_partial covers the ones it misses. The
        two are mutually exclusive per segment (recognized resets the
        tracker, so the next offset jump can't double-commit the same
        segment).
        """
        now = self._elapsed_ms()
        endpoint_ts = getattr(self, "_last_stt_endpoint_ts_ms", None)
        stt_latency = (now - endpoint_ts) if endpoint_ts else None
        log_timing(
            logger, "STT", "final", stt_latency,
            text=repr(text[:60]), conf=f"{confidence:.2f}",
        )
        await self._latency.cancel_stt_wait_filler()

        if self._stt_wait_escalated:
            logger.info(
                "[STT] dropping late delivery — escalation already fired "
                "(text=%r)", text[:60]
            )
            return

        text = text.strip()
        if text and not _is_noise_only(text):
            is_low_conf = confidence < 0.5
            async def _do(s: SessionState) -> None:
                s.last_any_speech_ms = now
                s.last_stt_confidence = confidence
                if is_low_conf:
                    s.consecutive_low_conf_finals += 1
                else:
                    s.consecutive_low_conf_finals = 0
            await self._store.mutate(_do)
            if self._commit_segment(text):
                self._utterance_audio_ms += self._seg_audio_ms()
                self._utterance_min_conf = min(self._utterance_min_conf, confidence)
                self._tracer.event(
                    "stt_segment", text=text, confidence=confidence,
                    end_ms=end_ms, reason="recognized",
                )
                logger.info("[STT] recognized segment committed: %r", text[:60])
            # Reset the segment tracker — the next partial is a new segment.
            self._seg_offset_ms = None
            self._seg_text = ""
            self._seg_end_ms = 0

            # LATE-RECOGNIZED RECOVERY: if the VAD endpoint already fired
            # for this utterance and `_finalize_utterance_at_endpoint`
            # returned False (because Azure hadn't delivered the segment
            # yet), the recognized text would orphan in the accumulator
            # and get wiped by the NEXT utterance's speech_start. We'd
            # never produce an `stt_final` event → verifier never runs →
            # slow LLM never dispatches → interview hangs.
            #
            # Detect: vad_state == DONE AND we haven't already finalized
            # for the current speech_start. Re-run the finalizer, which
            # is the same path the endpoint would have taken if the
            # segment had been on time.
            st = self._store.state
            sst = st.last_speech_start_ts_ms
            if (
                st.vad_state == VadState.DONE
                and sst > 0
                and self._utterance_finalized_for_speech_start_ms != sst
            ):
                logger.info(
                    "[STT] late `recognized` arrived after endpoint — "
                    "finalizing utterance retroactively (sst=%dms)",
                    sst,
                )
                try:
                    appended = await self._finalize_utterance_at_endpoint()
                    if appended:
                        await self._maybe_kick_post_stt_pipeline()
                except Exception as _e:  # pragma: no cover
                    logger.exception(
                        "[STT] late-recognized recovery raised: %s", _e,
                    )
        else:
            self._tracer.event(EventKind.NOISE_ONLY_FINAL, text=text)

    def _reset_utterance_accumulator(self) -> None:
        """Clear per-utterance STT state. Called on the FIRST speech_start
        of a new utterance and after each endpoint."""
        self._seg_offset_ms = None
        self._seg_text = ""
        self._seg_end_ms = 0
        self._utterance_segments = []
        self._utterance_min_conf = 1.0
        self._utterance_audio_ms = 0

    async def _finalize_utterance_at_endpoint(self) -> bool:
        """Close out the utterance at the VAD endpoint: commit the active
        (still-open) segment, JOIN all committed segments into ONE candidate
        Turn, and append it. Returns True if a Turn was appended, False if
        nothing usable was said.

        Called once from `on_vad_event(endpoint_detected)`, AFTER the
        noise-rejection gate.
        """
        sst = self._store.state.last_speech_start_ts_ms
        if sst > 0 and self._utterance_finalized_for_speech_start_ms == sst:
            return False  # already finalized this utterance (dup endpoint)

        # Commit the active segment (the one Azure hadn't closed via a
        # `recognized` or an offset jump before the endpoint) and add its
        # audio duration to the utterance total.
        if self._seg_text:
            if self._commit_segment(self._seg_text):
                self._utterance_audio_ms += self._seg_audio_ms()

        full_text = " ".join(s for s in self._utterance_segments if s).strip()
        if not full_text or _is_noise_only(full_text):
            # Nothing usable. Clear candidate-spoke so the silence prompt
            # can fire normally.
            async def _clear(s: SessionState) -> None:
                s.candidate_spoke_since_last_ai = False
            await self._store.mutate(_clear)
            self._reset_utterance_accumulator()
            self._last_endpoint_ms = None
            return False

        if sst > 0:
            self._utterance_finalized_for_speech_start_ms = sst

        n_segments = len(self._utterance_segments)
        confidence = self._utterance_min_conf
        is_low_conf = confidence < 0.5
        rendered = full_text
        if is_low_conf:
            rendered = f"{tag_low_confidence(confidence)}{full_text}"
        seg_end_ms = self._seg_end_ms
        # Total audio (ms) processed for this utterance — the billable STT
        # duration, summed across committed segments (NOT seg_end_ms, which
        # is an absolute stream timestamp that grows all session long).
        utterance_audio_ms = self._utterance_audio_ms
        # Spoken-duration baseline for STT lag attribution (see prom.py): how
        # long the candidate actually spoke, plotted next to STT head-lag so a
        # 2s head-lag on a 2s utterance reads as severe, on a 15s one as minor.
        if utterance_audio_ms > 0:
            STT_SPOKEN_MS.labels(self._stt_provider).observe(utterance_audio_ms)

        async def _do(s: SessionState) -> None:
            s.last_any_speech_ms = self._elapsed_ms()
            s.last_stt_confidence = confidence
        await self._store.mutate(_do)
        # Tag the previous candidate turn <no_response_yet/> if the AI never
        # responded to it.
        await self._store.mutate(_maybe_tag_previous_no_response_yet())
        await self._store.append_turn(Turn(
            turn_id=f"cand-{self._elapsed_ms()}",
            speaker=Speaker.CANDIDATE,
            text=rendered,
            text_full=full_text,
            start_ms=0,
            end_ms=seg_end_ms,
            confidence=confidence,
        ))
        await self._store.push_audio_event(RecentAudioEvent(
            ts_offset_s=0.0, kind="candidate_finished", text=full_text,
            metadata={"stt_confidence": confidence},
        ))

        # Deterministic ending-phrase detection. The verifier's
        # `wrap_up_complete` only fires on terminal phase; phase_override's
        # `end_now` is LLM-judgement and can miss "thank you" / "goodbye".
        # Belt-and-suspenders: if the candidate clearly signals they're
        # done, jump to the terminal phase and arm the auto-end gate. The
        # slow LLM's first turn in the terminal phase is the farewell, and
        # the audio_end of that farewell unblocks the wrap-up gate.
        ending_match = self._matches_ending_phrase(full_text)
        if ending_match is not None and self._end_request_ts_ms is None:
            logger.info(
                "[end] candidate ending-phrase '%s' detected in %r — "
                "arming wrap-up", ending_match, full_text[:120],
            )
            self._tracer.event(
                "candidate_ending_phrase_detected",
                phrase=ending_match, text=full_text[:200],
            )
            try:
                terminal = self._tracker.plan.terminal_phase_id()
                if not self._tracker.is_terminal_phase():
                    async def _queue_terminal(s: SessionState) -> None:
                        s.pending_phase = terminal
                    await self._store.mutate(_queue_terminal)
                self.request_session_end(reason="candidate_ending_phrase")
            except Exception as _ee:
                logger.warning("[end] failed to arm wrap-up: %s", _ee)

        logger.info(
            "[STT] utterance finalized at endpoint — %d segment(s), %d chars: %r",
            n_segments, len(full_text), full_text[:100],
        )
        # Event-log trace: ONE stt_final per utterance with the merged text.
        # `audio_ms` is the real billable duration (summed segments); the
        # admin per-phase / per-model cost rebuild reads it in preference to
        # `end_ms` (which is an absolute, ever-growing stream timestamp).
        self._tracer.event(
            EventKind.STT_FINAL, text=full_text, confidence=confidence,
            end_ms=seg_end_ms, audio_ms=utterance_audio_ms, segments=n_segments,
        )
        # Langfuse `stt.final`: merged transcript. This is now the SINGLE
        # place STT cost is booked — it carries the whole utterance's
        # `audio_ms`. (Azure's per-segment `recognized` events, which used to
        # carry cost via the STT client, rarely fire in this deployment, so
        # the STT client no longer books cost — see azure_stt_client.)
        try:
            st = self._store.state
            sid = str(st.session_id)
            uid = getattr(getattr(st, "candidate_profile", None), "name", None)
            from engine.brain.observability.langfuse_client import observe_stt
            with observe_stt(
                session_id=sid,
                audio_ms=(utterance_audio_ms if utterance_audio_ms > 0 else None),
                user_id=uid, name="stt.final",
            ) as _lf:
                _lf.update(
                    output={"text": full_text, "segments": n_segments},
                    metadata={"char_count": len(full_text),
                              "audio_ms": utterance_audio_ms},
                )
        except Exception as e:  # pragma: no cover — observability never blocks
            logger.debug("[STT] langfuse stt.final emit failed: %s", e)
        self._reset_utterance_accumulator()
        return True

    async def _maybe_kick_post_stt_pipeline(self) -> None:
        """Coordinator: create _post_stt_agents_task IFF the current
        utterance has a VAD endpoint and we haven't already dispatched
        for this utterance.

        Called from `on_vad_event(kind="endpoint_detected")` only. VAD
        endpoint is the single trigger for the verifier+override pipeline;
        STT final no longer drives orchestration (it just appends the Turn
        with text). The dedupe flag prevents repeat firing on duplicate
        endpoints for the same utterance.
        """
        state = self._store.state
        sst = state.last_speech_start_ts_ms
        if sst <= 0:
            return  # no utterance yet
        if state.last_endpoint_ts_ms <= sst:
            return  # VAD endpoint hasn't fired for this utterance
        if self._post_stt_dispatched_for_speech_start_ms == sst:
            return  # already fired for this utterance
        self._post_stt_dispatched_for_speech_start_ms = sst

        # Drain a prior task (rare — different utterance, slow agents).
        if (
            self._post_stt_agents_task is not None
            and not self._post_stt_agents_task.done()
        ):
            try:
                await self._post_stt_agents_task
            except Exception:  # pragma: no cover
                logger.exception("[POST-STT] previous task raised")
        self._post_stt_agents_task = asyncio.create_task(
            self._run_post_stt_agents(),
            name="post-stt-agents",
        )
        logger.info(
            "[POST-STT] pipeline fired (speech_start=%d, vad_endpoint=%d)",
            sst, state.last_endpoint_ts_ms,
        )

    async def _run_post_stt_agents(self) -> None:
        """Verifier + guardrail + phase-override, all in parallel. See task #8.

        Three independent fast-LLM calls fired together (asyncio.gather); we
        wait for all, then merge by PRIORITY: override > guardrail > verifier.
          - override always applies (it changes phase, orthogonal to content).
          - a guardrail trip supersedes the verifier's content verdict for this
            turn (scrub the adversarial turn + neutral re-ask; verifier verdict
            discarded — no instruction stash, no pool pop).
          - otherwise the verifier verdict applies normally.
        Guardrail is its own agent (engine/brain/agents/guardrail_agent.py) so
        its free-string `category` never trips Groq structured decoding the way
        the verifier's old enum `reason` did.
        """
        if (
            self._verifier_agent is None
            and self._phase_override_agent is None
            and self._guardrail_agent is None
        ):
            return

        ctx = build_context(
            self._store.state, now_ms=self._elapsed_ms(),
            tracker=self._tracker,
            # Scope the verifier to the previously-missing tags when this is a
            # follow-up turn (see conversation_context rubric handling).
            prior_missing_tags=self._latest_missing_tags,
        )

        tasks: list = []
        if self._verifier_agent is not None:
            # Skip the verifier during CODING — it watches STT_FINAL events
            # to classify the candidate's answer, but speech during a coding
            # phase isn't an answer (might be "hmm let me think", a question
            # to the AI, etc.). phase_override still runs so the candidate
            # can say "I'm done" / "next" to advance verbally.
            if self._store.state.ai_activity != AIActivityState.CODING:
                tasks.append(("verifier", self._verifier_agent.verify(ctx)))
        if self._guardrail_agent is not None:
            # Guardrail runs under the SAME CODING gate as the verifier: during
            # a coding phase the candidate's speech isn't an answer to police
            # (thinking aloud, asking the AI, etc.). Same rationale as above.
            if self._store.state.ai_activity != AIActivityState.CODING:
                tasks.append(("guardrail", self._guardrail_agent.classify(ctx)))
        if self._phase_override_agent is not None:
            # Skip phase_override during CODING. The agent is LLM-based and
            # has no coding-phase awareness — if the candidate mumbles
            # something like "let me think… I'm done with this part" while
            # typing, the LLM can emit `end_now` at conf ≥ 0.7 and the
            # director will terminate the whole interview (the end_now path
            # bypasses the 25 s dwell guard). The candidate can still
            # advance via the editor's Submit button.
            if self._store.state.ai_activity != AIActivityState.CODING:
                tasks.append((
                    "override",
                    self._phase_override_agent.decide(
                        ctx,
                        current_phase_id=self._tracker.current_phase_id,
                        questions_remaining=self._tracker.questions_remaining(),
                        elapsed_in_phase_s=self._tracker.elapsed_in_phase_s(),
                        phase_budget_s=self._tracker.current_phase().duration_s,
                    ),
                ))

        # gather, never raise — each sub-agent has its own internal
        # fallback so the parent flow never aborts on a sub-agent error.
        results = await asyncio.gather(
            *(t[1] for t in tasks), return_exceptions=True,
        )

        by_label: dict[str, object] = {}
        for (label, _), result in zip(tasks, results):
            if isinstance(result, BaseException):
                logger.warning("[%s] task raised: %s", label, result)
                continue
            by_label[label] = result

        # ── Priority merge: override > guardrail > verifier ──────────────
        # 1) Phase override always applies — it changes the phase, which is
        #    orthogonal to the content verdict below.
        override = by_label.get("override")
        if override is not None:
            await self._apply_phase_override(override)

        # 2) Guardrail trip supersedes the verifier for this turn: treat the
        #    candidate's turn as if it never happened (for the LLMs only — the
        #    GUARDRAIL_TRIGGERED event + the stt_final stay in events.jsonl for
        #    audit), re-ask neutrally, and DISCARD the verifier verdict (no
        #    instruction stash, no pool pop) so the same question is re-asked.
        #    The guardrail agent already emits GUARDRAIL_TRIGGERED; the scrub
        #    keeps the adversarial turn out of the slow LLM + next verifier pass.
        guardrail = by_label.get("guardrail")
        if guardrail is not None and guardrail.triggered:
            await self._scrub_last_candidate_turn(reason=guardrail.category)
            self._latest_verifier_instruction = _GUARDRAIL_REASK_THINK
            self._latest_missing_tags = []
            return

        # 3) No guardrail trip → apply the verifier verdict normally.
        for (label, _), result in zip(tasks, results):
            if isinstance(result, BaseException):
                continue
            if label == "verifier":
                effective_intent = result.intent
                instruction = result.instruction
                is_specific = (
                    self._tracker.current_phase().uses_question_pool
                )
                is_scenario = self._tracker.current_phase().is_scenario_analysis

                # Scenario skip request: "I don't know" / "can we skip this"
                # is a META request, not a content judgment, so it's checked
                # deterministically (mirroring `_matches_ending_phrase`)
                # BEFORE the verifier's own verdict is applied — a skip ask
                # takes priority over whatever the verifier made of the same
                # reply. One gentle nudge, then granted (ScenarioCursor.
                # request_skip's own one-nudge rule).
                if is_scenario:
                    _last_cand_text = ""
                    for _t in reversed(self._store.state.turns):
                        if _t.speaker == Speaker.CANDIDATE:
                            _last_cand_text = _t.text or ""
                            break
                    if self._matches_skip_phrase(_last_cand_text):
                        cursor = self._tracker.scenario_cursor()
                        if cursor is not None:
                            item_before = cursor.current_item()
                            granted = cursor.request_skip()
                            self._tracer.event(
                                "scenario_skip_requested",
                                phase_id=self._tracker.current_phase_id,
                                item_id=(item_before.id if item_before else None),
                                granted=granted,
                            )
                            if granted:
                                if cursor.records:
                                    self._tracer.event(
                                        "scenario_item_completed",
                                        phase_id=self._tracker.current_phase_id,
                                        **cursor.records[-1 if cursor.is_phase_done()
                                                          else cursor.index - 1].to_dict(),
                                    )
                                if not cursor.is_phase_done():
                                    self._emit_scenario_item_dispatch(cursor)
                            else:
                                self._latest_verifier_instruction = (
                                    "The candidate asked to skip this item or said "
                                    "they don't know. Give ONE brief, gentle "
                                    "encouragement to give it a try anyway (even a "
                                    "partial guess is fine) — do not push hard, and "
                                    "if they still don't want to after this, you'll "
                                    "be told to move on."
                                )
                        self._partial_count_current_q = 0
                        self._latest_missing_tags = []
                        continue

                # Scenario items (no skip request above) reuse this SAME
                # counter/instruction machinery (they're conceptually
                # identical: "how many times has the verifier said partial
                # for the thing currently in front of the LLM") but each item
                # carries its OWN follow-up cap (0-5, default 2) rather than
                # the Director-wide `self._max_follow_ups` pool phases use —
                # see ScenarioItem.max_followups.

                # Counter-driven auto-promotion of `partial_answer` to
                # `partial_answer_skip` once we hit the max-follow-ups
                # cap. The verifier just judges content quality each
                # turn (partial vs answered); the Director enforces the
                # "no more than N consecutive follow-ups" rule in code,
                # so the cap is a strict guarantee independent of LLM
                # compliance.
                if effective_intent == "partial_answer" and (is_specific or is_scenario):
                    self._partial_count_current_q += 1
                    _cap = self._max_follow_ups
                    if is_scenario:
                        _scen_item = self._tracker.current_scenario_item()
                        _cap = _scen_item.max_followups if _scen_item is not None else self._max_follow_ups
                    if self._partial_count_current_q > _cap:
                        # Cap exceeded — promote this verdict to skip.
                        effective_intent = "partial_answer_skip"
                        instruction = (
                            "Candidate's reply is still partial after "
                            f"{_cap} prior push(es) for "
                            "depth on this question. Briefly acknowledge in "
                            "your own words (a short, natural move-on — e.g. "
                            "the sense of 'got it, let's move on', NOT those "
                            "exact words) and ask the next question the tracker "
                            "hands you. Do NOT push again on the same topic."
                        )
                        self._tracer.event(
                            "partial_answer_skip_auto_promoted",
                            from_intent="partial_answer",
                            partial_count=self._partial_count_current_q,
                            max_follow_ups=_cap,
                            phase=self._tracker.current_phase_id,
                        )
                    elif getattr(result, "missing_tags", None):
                        # Still probing (cap not hit). The verifier's canned
                        # instruction already names these missing concepts; we
                        # just remember them so the NEXT (follow-up) verification
                        # is scoped to ONLY these.
                        self._latest_missing_tags = list(result.missing_tags)

                # Stash the (possibly overridden) instruction for the
                # next build_context call.
                self._latest_verifier_instruction = instruction

                # Pool gating: pop when the candidate has either fully
                # answered the CURRENT pool question OR the Director
                # just auto-promoted a `partial_answer` to skip after
                # the follow-up cap was hit. The verifier never emits
                # `partial_answer_skip` itself — it's a Director-
                # internal effective intent.
                if effective_intent in (
                    "answered", "default_answered", "partial_answer_skip",
                ) and is_specific:
                    # For adaptive phases, classify how the candidate did on
                    # the question being consumed (first-try / recovered /
                    # failed / neutral) and hand it to the tracker, which uses
                    # it to pick the NEXT question's difficulty. Static pools
                    # ignore the outcome.
                    is_adaptive = self._tracker.is_adaptive_phase()
                    outcome = (
                        classify_outcome(
                            effective_intent,
                            self._partial_count_current_q,
                            self._adaptive_config,
                        )
                        if is_adaptive else None
                    )
                    popped = self._tracker.pick_next_question(outcome=outcome)
                    if popped is not None:
                        self._tracer.event(
                            "question_pool_consumed",
                            phase=self._tracker.current_phase_id,
                            question_id=popped.id,
                            questions_remaining=self._tracker.questions_remaining(),
                            verifier_intent=effective_intent,
                            raw_verifier_intent=result.intent,
                            # Adaptive extras (None on static phases) — the raw
                            # signal the future benchmarking step reads.
                            difficulty=popped.difficulty,
                            outcome=outcome.value if outcome else None,
                            partial_count=self._partial_count_current_q,
                        )
                        # Surface an explicit level-change marker when the
                        # adaptive level actually moved (cheap; handy for
                        # scanning the transcript / live admin viewer).
                        if is_adaptive:
                            ad = self._tracker.adaptive_state()
                            if ad is not None and ad.last_transition not in (
                                "stayed", "start",
                            ):
                                self._tracer.event(
                                    "adaptive_level_changed",
                                    phase=self._tracker.current_phase_id,
                                    to_level=ad.current_difficulty(),
                                    transition=ad.last_transition,
                                    trigger=ad.last_trigger,
                                    recovered_streak=ad.recovered_streak,
                                    questions_remaining_by_level=ad.remaining_counts(),
                                )
                    # Pool advanced — reset the consecutive-partial counter
                    # and the missing-tag scope for the next pool question.
                    self._partial_count_current_q = 0
                    self._latest_missing_tags = []

                # Scenario gating: the SAME three good-enough intents
                # advance the cursor's CURRENT item instead of popping a
                # pool question — a scenario phase has no pool
                # (question_mode stays "generic"; see
                # PhaseDef.is_scenario_analysis).
                elif effective_intent in (
                    "answered", "default_answered", "partial_answer_skip",
                ) and is_scenario:
                    cursor = self._tracker.scenario_cursor()
                    if cursor is not None:
                        last_cand_text = ""
                        for _t in reversed(self._store.state.turns):
                            if _t.speaker == Speaker.CANDIDATE:
                                last_cand_text = _t.text or ""
                                break
                        outcome = cursor.record_answer(
                            text=last_cand_text,
                            effective_intent=effective_intent,
                            missing_tags=list(getattr(result, "missing_tags", None) or []),
                        )
                        self._tracer.event(
                            "scenario_item_answered",
                            phase_id=self._tracker.current_phase_id,
                            item_id=(outcome["record"]["item_id"] if outcome["record"] else None),
                            verifier_intent=effective_intent,
                            raw_verifier_intent=result.intent,
                            item_done=outcome["item_done"],
                            record=outcome["record"],
                        )
                        if outcome["item_done"]:
                            self._tracer.event(
                                "scenario_item_completed",
                                phase_id=self._tracker.current_phase_id,
                                **(outcome["record"] or {}),
                            )
                            if not cursor.is_phase_done():
                                # Show the NEXT item's media immediately —
                                # mirrors popping a pool question straight
                                # into the next one; the following natural
                                # dispatch (this same turn already fired, so
                                # it's the NEXT tick) asks/frames it.
                                self._emit_scenario_item_dispatch(cursor)
                    # Item advanced (or a follow-up is due) — reset the
                    # consecutive-partial counter and missing-tag scope,
                    # mirroring the pool branch above.
                    self._partial_count_current_q = 0
                    self._latest_missing_tags = []

                # Wrap-up end: when we're on the terminal phase and the
                # candidate signalled the closing exchange is done,
                # request session end. The next AI turn will be a brief
                # farewell (per the verifier's instruction) and then the
                # auto-end-on-AUDIO_DONE path shuts things down.
                if (
                    effective_intent == "wrap_up_complete"
                    and self._tracker.is_terminal_phase()
                ):
                    self._tracer.event(
                        "wrap_up_complete_detected",
                        phase=self._tracker.current_phase_id,
                    )
                    if self._end_request_ts_ms is None:
                        self._end_request_ts_ms = self._elapsed_ms()

    async def _scrub_last_candidate_turn(self, *, reason: str | None = None) -> None:
        """Remove the most recent candidate-spoken Turn from the LLM-visible
        history. Called on a guardrail trip so the adversarial content never
        reaches the slow LLM or the next verifier pass.

        Only `state.turns` (and the matching `candidate_finished` audio
        event) are touched — the event log is deliberately left intact, so
        the GUARDRAIL_TRIGGERED event + the stt_final still record what was
        said for the admin audit trail."""
        async def _mut(s: SessionState) -> None:
            scrubbed_id = None
            for i in range(len(s.turns) - 1, -1, -1):
                if s.turns[i].speaker == Speaker.CANDIDATE:
                    scrubbed_id = s.turns.pop(i).turn_id
                    break
            # Drop the paired live-audio event so the "candidate_finished"
            # text doesn't linger in the runtime-signals block either.
            for j in range(len(s.recent_audio_events) - 1, -1, -1):
                if s.recent_audio_events[j].kind == "candidate_finished":
                    s.recent_audio_events.pop(j)
                    break
            logger.info(
                "[GUARDRAIL] scrubbed candidate turn %s from LLM history "
                "(reason=%s); audit trail retained in events.jsonl",
                scrubbed_id, reason,
            )
        await self._store.mutate(_mut)

    # Minimum time the tracker must have been in a phase before the
    # override agent is allowed to fire `advance_now`. Without this guard
    # the override fires within ~1s of a phase apply (because the
    # conversation history is full of "let's dive into…" content from
    # the just-applied transition's prior phase) and chains phases
    # together in seconds. end_now is NOT gated by dwell time — the
    # candidate explicitly asking to stop should always be honoured.
    _ADVANCE_OVERRIDE_MIN_DWELL_S: int = 25
    # Confidence threshold at which the dwell guard is bypassed. The
    # guard exists for LLM hallucinations (conf ~0.7–0.8) inferring a
    # phase change from ambient context. Explicit candidate requests
    # ("skip this phase", "let's move on") get conf 1.00 from the
    # override agent and should be honoured even within the dwell window
    # — otherwise the candidate's literal instruction gets silently
    # discarded.
    _ADVANCE_OVERRIDE_DWELL_BYPASS_CONF: float = 0.95

    async def _apply_phase_override(self, override_result) -> None:
        """Honour the phase-override agent's decision (advance_now / end_now).
        'stay' is the default and means do nothing — tracker keeps running.

        end_now is a HARD override: it always wins over any queued advance,
        because the candidate explicitly asking to end the interview should
        not be blocked by a stale transition that's still waiting to apply.
        advance_now defers to an already-queued transition (no point
        queueing twice) and is gated by a minimum phase dwell time."""
        if override_result.override == "stay":
            return
        if override_result.override == "advance_now":
            dwell_s = self._tracker.elapsed_in_phase_s()
            conf = float(getattr(override_result, "confidence", 0.0) or 0.0)
            # Bypass the dwell guard when the override is high-confidence:
            # those come from explicit candidate signals ("skip this phase",
            # "let's move on") at conf 1.00, which we should honour even
            # within the dwell window. The guard's real target is LLM
            # hallucinations inferring a phase change from ambient
            # conversation, which cluster at conf ~0.7-0.8.
            if (
                dwell_s < self._ADVANCE_OVERRIDE_MIN_DWELL_S
                and conf < self._ADVANCE_OVERRIDE_DWELL_BYPASS_CONF
            ):
                logger.info(
                    "[PHASE-OVERRIDE] advance_now suggested but phase has "
                    "only been active %ds (< %ds dwell) and conf=%.2f "
                    "(< %.2f bypass threshold) — ignoring",
                    dwell_s, self._ADVANCE_OVERRIDE_MIN_DWELL_S,
                    conf, self._ADVANCE_OVERRIDE_DWELL_BYPASS_CONF,
                )
                self._tracer.event(
                    "phase_override_rejected",
                    reason="below_min_dwell",
                    requested=override_result.override,
                    phase=self._tracker.current_phase_id,
                    dwell_s=dwell_s,
                    min_dwell_s=self._ADVANCE_OVERRIDE_MIN_DWELL_S,
                    confidence=conf,
                )
                return
            if dwell_s < self._ADVANCE_OVERRIDE_MIN_DWELL_S:
                logger.info(
                    "[PHASE-OVERRIDE] advance_now within dwell window "
                    "(%ds < %ds) but conf=%.2f >= %.2f — bypassing guard",
                    dwell_s, self._ADVANCE_OVERRIDE_MIN_DWELL_S,
                    conf, self._ADVANCE_OVERRIDE_DWELL_BYPASS_CONF,
                )
                self._tracer.event(
                    "phase_override_dwell_bypassed",
                    phase=self._tracker.current_phase_id,
                    dwell_s=dwell_s, confidence=conf,
                    reason=override_result.reason,
                )
            # Continue to the existing advance_now handler below.
            if self._store.state.pending_phase is not None:
                logger.info(
                    "[PHASE-OVERRIDE] advance_now suggested but a transition "
                    "is already queued (%s) — ignoring",
                    self._store.state.pending_phase,
                )
                return
            nxt = self._tracker.plan.next_phase_id(
                self._tracker.current_phase_id,
            )
            if nxt is None:
                return
            await self._store.mutate(_set_pending_phase(nxt))
            self._tracer.event(
                EventKind.PHASE_CHANGED,
                reason="llm_override_advance",
                from_phase=self._tracker.current_phase_id,
                to_phase=nxt,
                queued=True,
                override_reason=override_result.reason,
            )
        elif override_result.override == "end_now":
            terminal = self._tracker.plan.terminal_phase_id()
            # Arm the auto-end. Either we're already on terminal (just
            # mark the end request so the next AI turn's audio_end
            # triggers shutdown) OR we're queueing the terminal phase
            # (the phase_intro will deliver the farewell, then end).
            if self._end_request_ts_ms is None:
                self._end_request_ts_ms = self._elapsed_ms()
            if self._tracker.is_terminal_phase():
                return
            # Hard override: replace any queued transition with terminal.
            current_pending = self._store.state.pending_phase
            if current_pending == terminal:
                return
            await self._store.mutate(_set_pending_phase(terminal))
            self._tracer.event(
                EventKind.PHASE_CHANGED,
                reason="llm_override_end_now",
                from_phase=self._tracker.current_phase_id,
                to_phase=terminal,
                queued=True,
                replaced_pending=current_pending,
                override_reason=override_result.reason,
            )

    async def on_vad_event(self, kind: str, payload: dict) -> None:
        """The PRIMARY driver of turn-taking. Every VAD event = a state transition.

        Transitions:
          speech_start    : * → SPEAKING  (cancel any AI turn; clear endpoint)
          speech_end      : SPEAKING → PAUSED   (pause might resume; don't trigger anything)
          endpoint_detected : PAUSED|SPEAKING → DONE  (now policy may fire YES)
        """
        ts = int(payload.get("ts_ms", self._elapsed_ms()))
        now_ms = self._elapsed_ms()
        prev_state = self._store.state.vad_state
        # Proof of life for the audio-starvation watchdog in _tick, and the
        # VAD's own clock for any endpoint we have to synthesize later.
        self._last_vad_event_ms = now_ms
        self._last_vad_ts_ms = ts
        self._audio_starved_fired = False

        if kind == "speech_start":
            self._tracer.event(EventKind.VAD_SPEECH_START, ts_ms=ts,
                               from_state=prev_state.value)
            # Clear any "endpoint just fired" state — candidate resumed.
            self._last_endpoint_ms = None

            # Snapshot pre-utterance silence-timer state — but ONLY on
            # the FIRST speech_start of a new utterance (transition out
            # of IDLE/DONE). Mid-utterance breath/blip transitions
            # (PAUSED → SPEAKING) must NOT overwrite the snapshot; we
            # need the value from BEFORE the candidate started speaking,
            # so that if the eventual endpoint reveals the whole thing
            # was noise, the rewind restores the right state. The same
            # FIRST-speech_start timestamp doubles as the utterance-start
            # marker the endpoint handler uses to compute duration.
            if prev_state in (VadState.IDLE, VadState.DONE):
                self._current_utterance_start_ts_ms = now_ms
                # New utterance → arm the STT-lag metrics for its first partial.
                self._first_partial_seen = False
                self._utterance_stream_start_ms = None
                pre_state = self._store.state
                self._pre_utterance_any_speech_ms = pre_state.last_any_speech_ms
                self._pre_utterance_candidate_spoke = pre_state.candidate_spoke_since_last_ai
                # Brand-new utterance → clear the accumulator so segments
                # from the previous answer don't bleed in. Mid-utterance
                # breath/blip transitions (PAUSED → SPEAKING) keep
                # accumulating, so we ONLY reset on the first speech_start.
                self._reset_utterance_accumulator()

            async def _do(s: SessionState) -> None:
                s.vad_state = VadState.SPEAKING
                s.last_speech_start_ts_ms = now_ms
                s.last_any_speech_ms = now_ms
                # Mark "candidate has spoken since last AI" — Rule 4 will
                # suppress silence_prompt while this is True.
                s.candidate_spoke_since_last_ai = True
            await self._store.mutate(_do)
            # NOTE: We deliberately do NOT wipe the accumulator on
            # mid-utterance speech_starts. VAD fires multiple speech_start
            # / speech_end pairs inside one logical utterance (breath gaps,
            # glottal stops, micro-noise blips). Only `endpoint_detected`
            # means "candidate done"; only the FIRST speech_start (handled
            # just above) resets the accumulator.
            # New utterance starts → if we'd previously escalated due to STT
            # failure, accept STT for THIS new utterance.
            self._stt_wait_escalated = False

            # Cancel any STT-wait filler ladder still running. The candidate
            # is starting a new utterance — the prior endpoint is stale and
            # we'd otherwise fire "Give me a moment" over the candidate's
            # voice. (The barge-in callback below cancels active AI turns;
            # STT-wait filler isn't a turn so it needs an explicit cancel.)
            await self._latency.cancel_stt_wait_filler()

            logger.info(
                "[VAD] %s → SPEAKING (ts=%dms)", prev_state.value, ts,
            )
            logger.info(
                "[TIMER] silence-prompt clock RESET (candidate started speaking)"
            )

            # Barge-in: if AI is doing anything (LLM generating / TTS queued /
            # audio playing), cancel immediately. The barge-in evaluator in
            # InterviewSession will pick this up via its speech_start hook,
            # but we also tell it directly via the cancel callback.
            if self._on_speech_start_cancel is not None:
                try:
                    await self._on_speech_start_cancel()
                except Exception as e:  # pragma: no cover
                    logger.warning("on_speech_start_cancel raised: %s", e)

        elif kind == "speech_end":
            self._tracer.event(EventKind.VAD_SPEECH_END, ts_ms=ts,
                               from_state=prev_state.value)
            # Mid-utterance brief silence. Move SPEAKING → PAUSED. (If we're
            # already in PAUSED or DONE this is unusual but harmless.)
            async def _do(s: SessionState) -> None:
                if s.vad_state == VadState.SPEAKING:
                    s.vad_state = VadState.PAUSED
                s.last_speech_end_ts_ms = now_ms
                s.last_any_speech_ms = now_ms
            await self._store.mutate(_do)
            logger.info("[VAD] %s → PAUSED (ts=%dms)", prev_state.value, ts)

        elif kind == "endpoint_detected":
            confidence = float(payload.get("confidence", 1.0))
            self._last_endpoint_ms = now_ms
            self._last_stt_endpoint_ts_ms = now_ms      # for STT-latency timing
            self._tracer.event(EventKind.VAD_ENDPOINT, ts_ms=ts,
                               confidence=confidence,
                               from_state=prev_state.value)
            # ── Noise rejection ───────────────────────────────────────
            # Reject the endpoint as noise if the WHOLE utterance (from
            # the first speech_start out of IDLE/DONE to the endpoint)
            # was shorter than `noise_threshold_ms`. Using the
            # FIRST-speech_start anchor is critical: VAD fires multiple
            # speech_start/speech_end pairs inside one logical utterance
            # (breath gaps, mid-thought pauses) — using the last pair
            # would catastrophically reject a 30-second answer whose
            # final clause happened to be brief (trace 8cacc7a4).
            #
            # On rejection:
            #   - don't synthesize a Turn from the partial buffer
            #   - don't kick the verifier+phase_override pipeline
            #   - rewind the silence-timer state so the AI's silence
            #     prompt still fires at the right time
            # Same threshold as `BARGE_IN_WARMUP_MS`.
            state = self._store.state
            utt_start = self._current_utterance_start_ts_ms
            utterance_dur_ms = (now_ms - utt_start) if utt_start > 0 else 0
            if 0 < utterance_dur_ms < self._noise_threshold_ms:
                logger.info(
                    "[VAD] endpoint ts=%dms — utterance was %dms (< %dms "
                    "noise threshold). REJECTING as noise; restoring "
                    "pre-utterance silence-timer state.",
                    ts, utterance_dur_ms, self._noise_threshold_ms,
                )
                self._tracer.event(
                    EventKind.NOISE_ONLY_FINAL,
                    text="", speech_duration_ms=utterance_dur_ms,
                    threshold_ms=self._noise_threshold_ms,
                    reason="vad_endpoint_under_noise_threshold",
                )
                pre_any = self._pre_utterance_any_speech_ms
                pre_spoke = self._pre_utterance_candidate_spoke
                async def _do(s: SessionState) -> None:
                    s.vad_state = VadState.DONE
                    s.last_endpoint_ts_ms = now_ms
                    # Rewind silence-timer state — as if the noise blip
                    # never happened.
                    s.last_any_speech_ms = pre_any
                    s.candidate_spoke_since_last_ai = pre_spoke
                await self._store.mutate(_do)
                # Reset the utterance-start marker so the next
                # speech_start (out of DONE) starts a fresh utterance.
                self._current_utterance_start_ts_ms = 0
                # Clear the whole accumulator so a noise-burst's segments
                # / partials don't carry into the next real utterance.
                self._reset_utterance_accumulator()
                # Cancel any in-flight barge-in warm-up — the noise burst
                # didn't last long enough to count.
                if self._on_endpoint_cancel_pending_barge is not None:
                    try:
                        await self._on_endpoint_cancel_pending_barge()
                    except Exception as e:  # pragma: no cover
                        logger.warning(
                            "on_endpoint_cancel_pending_barge raised: %s", e,
                        )
                return

            # Real utterance — reset the marker now that we've consumed
            # it. Next speech_start (out of DONE) will set a fresh one.
            self._current_utterance_start_ts_ms = 0

            # Candidate is genuinely done. Move to DONE.
            async def _do(s: SessionState) -> None:
                s.vad_state = VadState.DONE
                s.last_endpoint_ts_ms = now_ms
                s.last_any_speech_ms = now_ms
            await self._store.mutate(_do)
            logger.info(
                "[VAD] %s → DONE (ts=%dms conf=%.2f) — policy can fire YES now",
                prev_state.value, ts, confidence,
            )
            # If a barge-in warm-up task is still pending, cancel it. Endpoint
            # firing before the warm-up expired means the utterance was a
            # brief noise burst — the AI should keep speaking.
            if self._on_endpoint_cancel_pending_barge is not None:
                try:
                    await self._on_endpoint_cancel_pending_barge()
                except Exception as e:  # pragma: no cover
                    logger.warning(
                        "on_endpoint_cancel_pending_barge raised: %s", e
                    )
            # Start the STT-wait filler ladder: while STT is processing the
            # candidate's audio, fire "Give me a moment" every 5s up to 3
            # times, then escalate to "Could you say that again?".
            #
            # Skip during CODING: the candidate's cough/hum/typing noise can
            # trip the VAD endpoint while they're focused on the editor. The
            # filler ladder would then talk over them ("Give me a moment…",
            # "Sorry, I didn't quite catch that").
            if self._store.state.ai_activity != AIActivityState.CODING:
                await self._latency.start_stt_wait_filler(
                    on_escalate=self._on_stt_wait_escalation,
                )
            # Assemble the FULL utterance from all accumulated `recognized`
            # segments (+ any trailing partial) and append ONE candidate
            # Turn. This is the single point a candidate Turn enters the
            # conversation — never per Azure segment. Covers both the
            # multi-segment case (Azure split on pauses) and the
            # never-fired-a-final case (only partials, captured as the
            # trailing fragment).
            appended = await self._finalize_utterance_at_endpoint()
            if not appended:
                logger.info(
                    "[STT] endpoint with no usable transcript — not kicking "
                    "post-STT pipeline (silence prompt will handle it)."
                )
                return
            # VAD endpoint is the single trigger: fire the verifier +
            # phase-override pipeline now, on the COMPLETE transcript. The
            # slow LLM dispatch in tick() awaits this task before calling
            # the LLM, so verifier+tracker output is in context first.
            await self._maybe_kick_post_stt_pipeline()

    # ── tracker-driven phase advancement ──────────────────────────────────

    async def _maybe_advance_via_tracker(self, now_ms: int) -> None:
        """Concrete time-based phase advancement, driven by CadenceTracker.

        Tracker is the authority for "what should happen with this phase
        right now". Three outcomes:
          - STAY: nothing to do.
          - ADVANCE: queue the next phase via state.pending_phase. The
                     atomic-apply block at the top of _tick picks it up
                     once AI is IDLE so transitions never split a turn.
          - END: queue the final-phase marker if not already terminal;
                 the wrap-up auto-end at the bottom of _tick handles
                 actually shutting down once AI's farewell finishes.
        """
        if self._store.state.pending_phase is not None:
            # Already queued; wait for the apply step.
            return
        decision = self._tracker.check_phase_budget()
        if decision is TickDecision.STAY:
            return
        if decision is TickDecision.ADVANCE:
            nxt = self._tracker.plan.next_phase_id(self._tracker.current_phase_id)
            if nxt is None:
                return  # tracker said advance but we're terminal — defer to END
            await self._store.mutate(_set_pending_phase(nxt))
            self._tracer.event(
                EventKind.PHASE_CHANGED,
                reason="time_budget",
                from_phase=self._tracker.current_phase_id,
                to_phase=nxt,
                queued=True,
            )
            return
        # decision is END — only the wrap-up auto-end below should fire.
        # Make sure we're on the terminal phase so the auto-end matches.
        if not self._tracker.is_terminal_phase():
            terminal = self._tracker.plan.terminal_phase_id()
            await self._store.mutate(_set_pending_phase(terminal))
            self._tracer.event(
                EventKind.PHASE_CHANGED,
                reason="tracker_jump_to_terminal",
                from_phase=self._tracker.current_phase_id,
                to_phase=terminal,
                queued=True,
            )

    # ── runtime-tag persistence (KV-cache stability) ─────────────────────────

    async def _persist_runtime_tags(
        self, ctx: "ConversationContext", *, now_ms: int,
    ) -> None:
        """Append the slow-LLM dispatch's runtime messages as Turns in
        state.turns so they survive into future dispatches at the same
        chronological position.

        Mirrors `question_agent._runtime_messages`: same conditions,
        same tag content. Difference is the result lands in state.turns
        (with `message_role` overrides so the OpenAI role still matches
        what the LLM expects) instead of being injected ephemerally at
        the tail of the message list.

        Side-effect: also extends `ctx.recent_turns` so the CURRENT
        dispatch's `_build_messages` (which reads from ctx, not from
        state) picks the new turns up. That keeps current-dispatch
        prompt behaviour byte-identical with the prior ephemeral path
        while making the same content persistent for future dispatches.
        """
        new_turns: list[Turn] = []

        # 1. Silence re-engagement is now injected as a <think> per-turn briefing
        # directive in _tick (via verifier_instruction → build_context), NOT as a
        # <silence_ms=N/> user turn here. Nothing to persist for silence.

        # 2. out-of-band state tags — system role. Same content as
        # question_agent._runtime_messages assembles.
        state_tags: list[str] = []
        if ctx.in_protected_response:
            state_tags.append("<protected_response_mode/>")
        elif ctx.barge_in_strike_count >= 2:
            state_tags.append(
                f"<barge_in_strikes count={ctx.barge_in_strike_count}/>"
            )
        if state_tags:
            new_turns.append(Turn(
                turn_id=f"rt-state-{now_ms}",
                speaker=Speaker.UNKNOWN,
                text=" ".join(state_tags),
                start_ms=now_ms, end_ms=now_ms, confidence=1.0,
                message_role="system",
            ))

        # 3. <think>{verifier+tracker}</think> — ASSISTANT role (the AI's
        # own per-turn scratchpad, NOT candidate speech). The
        # forward-looking directive for THIS dispatch. Persisting it as
        # a Turn means the NEXT dispatch's prompt shows the candidate
        # turn → <think> → AI response triple intact, so the prefix
        # KV-cache hits all the way up to the previous <think>. Must match
        # the role question_agent emits the live <think> as (assistant) so
        # the persisted history and the live prompt stay consistent.
        if ctx.think_content:
            new_turns.append(Turn(
                turn_id=f"rt-think-{now_ms}",
                speaker=Speaker.UNKNOWN,
                text=f"<think>\n{ctx.think_content}\n</think>",
                start_ms=now_ms, end_ms=now_ms, confidence=1.0,
                message_role="assistant",
            ))

        for t in new_turns:
            await self._store.append_turn(t)
        # Update ctx.recent_turns in place so the current dispatch sees
        # the new turns via _build_messages (which reads ctx, not state).
        if new_turns:
            ctx.recent_turns.extend(new_turns)

    # ── protected mode entry ──────────────────────────────────────────────────

    async def _enter_protected_mode(self) -> None:
        async def _do(s: SessionState) -> None:
            s.in_protected_response = True
        await self._store.mutate(_do)
        self._tracer.event(
            EventKind.PROTECTED_RESPONSE_MODE_ENTERED,
            strike_count=self._store.state.barge_in_strike_count,
        )

    async def exit_protected_mode(self) -> None:
        async def _do(s: SessionState) -> None:
            s.in_protected_response = False
            s.barge_in_strike_count = 0
        await self._store.mutate(_do)
        self._tracer.event(EventKind.PROTECTED_RESPONSE_MODE_EXITED)

    # ── STT-wait filler ladder escalation ────────────────────────────────

    async def _on_stt_wait_escalation(self) -> None:
        """Called by LatencyOrchestrator when the STT-wait filler ladder has
        fired the maximum number of times (3) and STT still hasn't delivered.

        We mark the current pending utterance as abandoned (any late STT
        final for it will be dropped), clear the candidate-spoke flag so
        policy can resume normally, and dispatch a canned 'could you say
        that again?' via the latency orchestrator.
        """
        self._stt_wait_escalated = True
        logger.warning(
            "[STT-WAIT] escalation fired — abandoning current utterance, "
            "asking candidate to repeat"
        )
        # Clear the candidate-spoke flag (we're giving up on the utterance).
        # Reset _last_endpoint_ms too (we're no longer in STT-wait state).
        self._last_endpoint_ms = None
        async def _do(s: SessionState) -> None:
            s.candidate_spoke_since_last_ai = False
        await self._store.mutate(_do)
        self._tracer.event(
            "stt_wait_escalation",
            text="Sorry, I didn't quite catch that — could you say that again?",
        )


# ── helpers ──────────────────────────────────────────────────

def _is_noise_only(text: str) -> bool:
    """Return True if `text` is just filler-words / disfluencies."""
    cleaned = text.lower().strip().replace(",", " ").replace(".", " ")
    tokens = [t for t in cleaned.split() if t]
    if not tokens:
        return True
    return all(t in {"um", "uh", "ah", "er", "hmm", "mm", "mhm"} for t in tokens)


def _set_pending_phase(target: str):
    def _do(s: SessionState) -> None:
        s.pending_phase = target
    return _do


def _maybe_tag_previous_no_response_yet():
    """If the most recent turn is a CANDIDATE turn (no AI response between),
    annotate it with <no_response_yet/>."""
    from engine.brain.contracts.tags import tag_no_response_yet  # local import to avoid cycle
    def _do(s: SessionState) -> None:
        if not s.turns:
            return
        last = s.turns[-1]
        speaker = last.speaker.value if hasattr(last.speaker, "value") else last.speaker
        if speaker == Speaker.CANDIDATE.value and tag_no_response_yet() not in last.text:
            last.text = last.text + tag_no_response_yet()
    return _do
