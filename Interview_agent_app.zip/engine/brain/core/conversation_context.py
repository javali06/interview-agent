"""ConversationContext builder — NEW_STREAM_B.md §10.4.

Every sub-agent that calls an LLM gets one of these. The system prompt
references these fields by name. We render the context as a YAML-style
block in the LLM message so the model sees a familiar structured-data
format.
"""
from __future__ import annotations

from dataclasses import dataclass

from typing import TYPE_CHECKING

from engine.brain.contracts.session_state import (
    AIActivityState,
    IntegrityFlag,
    RecentAudioEvent,
    SessionState,
    Turn,
)

if TYPE_CHECKING:
    from engine.brain.core.cadence_tracker import CadenceTracker


@dataclass
class ConversationContext:
    candidate_name: str
    role: str
    resume_summary: str
    phase: str
    phase_elapsed_s: int
    phase_budget_s: int
    phase_pace: str                          # "ahead" | "on_track" | "behind"
    pending_phase: str | None
    rolling_summary: str
    recent_turns: list[Turn]                  # tag-rendered text
    recent_audio_events: list[RecentAudioEvent]
    candidate_silence_ms: int
    ai_activity: AIActivityState
    last_filler_text: str | None
    last_apology_ts_ms: int
    barge_in_strike_count: int
    in_protected_response: bool
    consecutive_low_conf_finals: int
    last_stt_confidence: float
    active_integrity_flags: list[IntegrityFlag]
    # ── injected at dispatch time by Director (the verifier instruction
    #    from the fast classifier + the tracker's rendered phase block).
    #    Per user spec: verifier first, then tracker, in the slow LLM's
    #    system prompt.
    verifier_instruction: str | None = None
    tracker_phase_block: str | None = None
    # Composed per-turn directive for the <think> user-role message that
    # rides at the END of the messages list (right before generation).
    # Combines (a) the verifier's natural-language guidance about the
    # candidate's last reply and (b) the tracker's "ask this question"
    # or "push for depth" directive for this turn. Keeping these out of
    # the system prompt and into <think> means: (i) the system prompt
    # stays stable across turns (better attention anchoring on phase
    # semantics) and (ii) the volatile per-turn directive lives next to
    # the candidate's latest reply where the model expects to act on
    # the most recent context. None when there's nothing for the
    # runtime to say this turn.
    think_content: str | None = None
    # Set True for the one dispatch that immediately follows a phase apply.
    # QuestionAgent suppresses the `<silence_ms=N/>` framing on this turn so
    # the AI introduces the new phase seamlessly (candidate doesn't perceive
    # the underlying state change as a "take your time" prompt).
    is_phase_transition: bool = False
    # For specific-mode phases: the pool question currently being asked +
    # its follow-up probes (as a rubric for the VERIFIER, not the slow LLM).
    # Lets the verifier judge whether the candidate's reply actually
    # addressed the question against a concrete checklist. None for
    # generic phases or when the pool is exhausted.
    current_pool_question_rubric: str | None = None
    # Compact phase descriptor for the VERIFIER: id, intent, and (for
    # generic mode) the phase's expected topics. Lets the verifier judge
    # whether the candidate's reply is ON-PHASE or NOT_APPLICABLE
    # (carrying over a prior-phase thread).
    current_phase_descriptor: str | None = None
    # True when the current phase is the terminal phase (wrap_up).
    # Verifier uses this to enable the `wrap_up_complete` intent — the
    # signal that the closing exchange has happened and the director
    # should end the session.
    is_terminal_phase: bool = False
    # Rendered "candidate just submitted this code" block, populated only
    # when the current phase is the one IMMEDIATELY after a coding phase
    # (typically code_discussion). None otherwise so the slow LLM doesn't
    # carry stale code context through unrelated phases. See build_context.
    coding_submission_block: str | None = None
    # Non-empty when the question on the table is a WRITTEN-RESPONSE task
    # (comprehensive / transcription / translation / image description). Its
    # material never passes through the LLM, so the model has to be told it
    # exists and must not be invented — see cadence_tracker._written_response_brief.
    written_response_brief: str | None = None


def build_context(
    state: SessionState,
    *,
    now_ms: int,
    tracker: "CadenceTracker | None" = None,
    recent_turns_n: int | None = None,
    verifier_instruction: str | None = None,
    is_phase_transition: bool = False,
    prior_missing_tags: list[str] | None = None,
) -> ConversationContext:
    """Build the per-turn context shipped to LLMs.

    `recent_turns_n=None` (default) keeps the FULL conversation history.
    The slow LLM (QuestionAgent) needs all of it to ask non-redundant
    follow-ups. The fast LLM (FillerAgent) slices internally to keep its
    prompt small via `render_history_for_prompt(ctx, limit=N)`.

    `tracker` (optional) is the CadenceTracker — when present it's the
    source of truth for phase budget and elapsed. If None we fall back
    to a hardcoded 600s budget so the context still builds for tests
    or any caller that doesn't have a tracker handy.
    """
    elapsed_s = max(0, (now_ms - state.phase_started_at_ms) // 1000)
    if tracker is not None:
        budget = tracker.current_phase().duration_s
    else:
        budget = 600

    # Compose the per-turn <think> block content: verifier guidance +
    # tracker directive. Both are dynamic (change every turn) so they
    # live in a user-role message at the end of the conversation, not
    # in the system prompt.
    think_parts: list[str] = []
    if verifier_instruction:
        think_parts.append(f"verifier note: {verifier_instruction}")
    if tracker is not None:
        # Generic-mode topics live in the <think> block only on phase-
        # entry dispatches (when is_phase_transition is True). On
        # subsequent turns in the same generic phase, the tracker
        # directive is empty for generic mode — the slow LLM follows
        # the conversation history + phase intent. Specific-mode
        # always returns the current question text (load-bearing).
        directive = tracker.render_think_directive(
            is_phase_entry=is_phase_transition,
        )
        if directive:
            think_parts.append(directive)
    think_content: str | None = "\n\n".join(think_parts) if think_parts else None

    # Build a rubric block for specific-mode phases — the verifier uses
    # this to judge whether the candidate's reply met the bar. Not shown
    # to the slow LLM (it just asks the question; the verifier gates
    # depth).
    rubric: str | None = None
    phase_descriptor: str | None = None
    is_terminal = False
    if tracker is not None:
        phase = tracker.current_phase()
        is_terminal = tracker.is_terminal_phase()
        descriptor_lines = [
            f"current_phase: {phase.id}",
            f"phase_intent: {phase.intent}",
            f"question_mode: {phase.question_mode}",
        ]
        if phase.is_scenario_analysis:
            # Visual Scenario Analysis: the verifier needs the CURRENT
            # item's question + coverage_tags to judge "good enough", the
            # same shape a pool question gives it below — scenario items
            # just aren't pool-backed (question_mode stays "generic"; see
            # PhaseDef.is_scenario_analysis), so they need their own branch
            # here rather than falling into the pool one.
            item = tracker.current_scenario_item()
            if item is not None:
                parts = [f'question: "{item.question}"']
                followup_tags = [t for t in (prior_missing_tags or []) if t in item.coverage_tags]
                if followup_tags:
                    parts.append(
                        "FOLLOW-UP verification: the candidate already covered "
                        "the rest of this item's question on an earlier turn. "
                        "Verify the latest reply ONLY against these remaining "
                        "concept(s) — do NOT require anything else. If the "
                        "reply (or recent turns) now addresses them (in their "
                        "own words or closely related ideas), mark `answered`. "
                        "Otherwise `partial_answer` with the still-missing "
                        "one(s) in missing_tags:"
                    )
                    for t in followup_tags:
                        parts.append(f"  - {t}")
                elif item.coverage_tags:
                    parts.append(
                        "coverage_tags (concepts a COMPLETE answer should "
                        "address — mark `answered` if the reply covers them or "
                        "closely related ideas; only the genuinely-missing "
                        "ones go in missing_tags => partial_answer):"
                    )
                    for t in item.coverage_tags:
                        parts.append(f"  - {t}")
                rubric = "\n".join(parts)
            else:
                descriptor_lines.append("scenario_status: exhausted")
        elif phase.uses_question_pool:
            q = tracker.peek_next_question()
            if q is not None:
                parts = [f'question: "{q.text}"']
                if q.topic:
                    parts.append(f"topic: {q.topic}")
                points = q.coverage_points()
                # FOLLOW-UP scoping: if the previous verification flagged some
                # tags as missing and we re-asked ONLY those, the verifier must
                # now judge the reply against ONLY those remaining tags — the
                # rest of the question was already covered on the earlier turn.
                # This prevents re-failing a follow-up just because the (now
                # short, targeted) reply doesn't re-explain the whole question.
                followup_tags = [
                    t for t in (prior_missing_tags or []) if t in points
                ] if q.uses_tags else []
                if followup_tags:
                    parts.append(
                        "FOLLOW-UP verification: the candidate already covered "
                        "the rest of this question on an earlier turn. Verify "
                        "the latest reply ONLY against these remaining "
                        "concept(s) — do NOT require anything else. If the "
                        "reply (or recent turns) now addresses them (in their "
                        "own words or closely related ideas), mark `answered`. "
                        "Otherwise `partial_answer` with the still-missing "
                        "one(s) in missing_tags:"
                    )
                    for t in followup_tags:
                        parts.append(f"  - {t}")
                elif points and q.uses_tags:
                    # Concept tags a COMPLETE answer must address. The verifier
                    # judges the reply against each and returns the unaddressed
                    # ones in `missing_tags`.
                    parts.append(
                        "coverage_tags (concepts a COMPLETE answer should "
                        "address — mark `answered` if the reply covers them or "
                        "closely related ideas; only the genuinely-missing "
                        "ones go in missing_tags => partial_answer):"
                    )
                    for t in points:
                        parts.append(f"  - {t}")
                elif points:
                    # Legacy follow-up questions (pools/cadences not yet migrated
                    # to tags). Same checklist semantics.
                    parts.append(
                        "follow_up_checklist (legacy — each point is something a "
                        "COMPLETE answer must cover; missing point(s) => "
                        "partial_answer):"
                    )
                    for i, fu in enumerate(points, 1):
                        parts.append(f"  FU{i}: {fu}")
                rubric = "\n".join(parts)
            else:
                descriptor_lines.append("pool_status: exhausted")
        else:
            if phase.generic_prompts:
                descriptor_lines.append("expected_topics:")
                for p in phase.generic_prompts:
                    descriptor_lines.append(f"  - {p}")
        if is_terminal:
            descriptor_lines.append(
                "terminal_phase: true (wrap_up). `wrap_up_complete` is "
                "available as an intent when the closing exchange is done."
            )
        phase_descriptor = "\n".join(descriptor_lines)
    pace = (
        "ahead" if elapsed_s < budget * 0.5
        else "on_track" if elapsed_s < budget
        else "behind"
    )

    # Coding-submission block: surface only in the phase IMMEDIATELY after
    # the coding phase the submission belongs to. After that, drop it so
    # the LLM doesn't keep revisiting old code three phases later.
    coding_submission_block: str | None = None
    sub = state.last_coding_submission
    if sub and tracker is not None:
        sub_phase = sub.get("phase_id", "")
        try:
            next_after_coding = tracker.plan.next_phase_id(sub_phase)
        except Exception:
            next_after_coding = None
        if next_after_coding and next_after_coding == state.phase:
            coding_submission_block = _render_coding_submission_block(sub)

    return ConversationContext(
        candidate_name=state.candidate_profile.name,
        role=state.candidate_profile.role,
        resume_summary=state.candidate_profile.resume_summary,
        phase=state.phase,
        phase_elapsed_s=elapsed_s,
        phase_budget_s=budget,
        phase_pace=pace,
        pending_phase=state.pending_phase,
        rolling_summary=state.rolling_summary,
        recent_turns=(
            list(state.turns) if recent_turns_n is None
            else list(state.turns[-recent_turns_n:])
        ),
        recent_audio_events=list(state.recent_audio_events[-10:]),
        candidate_silence_ms=max(0, now_ms - state.last_any_speech_ms),
        ai_activity=state.ai_activity,
        last_filler_text=state.last_filler_text,
        last_apology_ts_ms=state.last_apology_ts_ms,
        barge_in_strike_count=state.barge_in_strike_count,
        in_protected_response=state.in_protected_response,
        consecutive_low_conf_finals=state.consecutive_low_conf_finals,
        last_stt_confidence=state.last_stt_confidence,
        active_integrity_flags=list(state.active_flags),
        verifier_instruction=verifier_instruction,
        tracker_phase_block=(
            tracker.render_phase_context() if tracker is not None else None
        ),
        think_content=think_content,
        is_phase_transition=is_phase_transition,
        current_pool_question_rubric=rubric,
        current_phase_descriptor=phase_descriptor,
        is_terminal_phase=is_terminal,
        coding_submission_block=coding_submission_block,
        written_response_brief=(
            (tracker.render_written_response_brief() or None)
            if tracker is not None else None
        ),
    )


def _render_coding_submission_block(sub: dict) -> str:
    # Renders the "candidate just submitted this code" block for the slow
    # LLM's system prompt. Keep it compact — the code itself can be long.
    code = (sub.get("code") or "").rstrip()
    fn_name = sub.get("function_name") or "(unknown)"
    qid = sub.get("question_id") or "(unknown)"
    q_prompt = (sub.get("question_prompt") or "").strip()
    results = sub.get("test_results") or []
    if isinstance(results, list) and results:
        passed = sum(1 for r in results if (r.get("pass") or r.get("passed")))
        total = len(results)
        failures = [
            r for r in results
            if not (r.get("pass") or r.get("passed"))
        ]
        result_lines = [f"  tests_passed: {passed}/{total}"]
        for r in failures[:3]:
            # Show at most 3 failures inline; the LLM doesn't need all of them.
            name = r.get("name") or "(unnamed)"
            err = r.get("error") or r.get("got") or "(no detail)"
            result_lines.append(f"  failure '{name}': {str(err)[:200]}")
        result_block = "\n".join(result_lines)
    else:
        result_block = "  (no test results recorded)"

    return (
        "candidate_coding_submission:\n"
        f"  question_id: {qid}\n"
        f"  function_name: {fn_name}\n"
        "  question_prompt: |\n"
        f"    {q_prompt or '(not provided)'}\n"
        "  submitted_code: |\n"
        f"    {_indent(code, '    ') or '(empty)'}\n"
        "  test_results:\n"
        f"{result_block}\n"
        "instructions_for_this_phase:\n"
        "  - Open by asking the candidate to walk through their approach.\n"
        "  - Probe for edge cases they handled or missed.\n"
        "  - Ask about time/space complexity in their own words.\n"
        "  - If a test failed, ask what they'd change — don't lecture.\n"
        "  - Do NOT correct the code or write code yourself.\n"
    )


def _indent(text: str, prefix: str) -> str:
    if not text:
        return ""
    return "\n".join(prefix + line for line in text.splitlines())


def turns_to_messages(
    turns: list[Turn], *, limit: int | None = None,
) -> list[dict[str, str]]:
    """Convert turns into proper OpenAI-format multi-turn messages.

    Mapping:
      Speaker.AI         → "assistant"
      Speaker.CANDIDATE  → "user"
      Speaker.UNKNOWN    → "system"  (phase markers, meta-turns whose text
                                       is just a tag like
                                       <phase_changed from=... to=.../>)
      Speaker.INTERVIEWER → "system" (human TA voice, rare in laptop mode)

    Tags inside turn.text (`<barged_in/>`, `<filler text=.../>`, etc.) ride
    along as part of the content; the system prompt teaches the LLM what
    they mean.

    `limit=None` returns all turns. `limit=N` keeps only the last N.
    """
    if limit is not None and len(turns) > limit:
        turns = turns[-limit:]
    msgs: list[dict[str, str]] = []
    for t in turns:
        text = (t.text or "").strip()
        if not text:
            continue
        # Explicit override wins. Used for synthesized meta-turns
        # (e.g. <think> blocks persisted by the director) whose role
        # doesn't match the Speaker enum's default mapping.
        override = getattr(t, "message_role", None)
        if override in ("user", "assistant", "system"):
            msgs.append({"role": override, "content": text})
            continue
        speaker = t.speaker.value if hasattr(t.speaker, "value") else str(t.speaker)
        if speaker == "ai":
            msgs.append({"role": "assistant", "content": text})
        elif speaker == "candidate":
            msgs.append({"role": "user", "content": text})
        elif speaker == "interviewer":
            # Phase 2: a human TA shadowing the interview held PTT and
            # asked the candidate a question. Wrap in
            # <interviewer_message> so the slow LLM clearly distinguishes
            # this from the candidate's own voice (the system prompt
            # documents the tag). Surface as "user" role so it lands in
            # the same conversational lane the candidate's turns use —
            # otherwise OpenAI-format providers can ignore it.
            msgs.append({
                "role": "user",
                "content": f"<interviewer_message>\n{text}\n</interviewer_message>",
            })
        else:
            # UNKNOWN — surface as system note for context.
            msgs.append({"role": "system", "content": text})
    return msgs


def render_history_for_prompt(
    ctx: ConversationContext, *, limit: int | None = None,
) -> str:
    """Render the recent_turns as `[speaker] text` lines.

    `limit=None` renders everything in `ctx.recent_turns` (default — used
    by the slow LLM which needs full history to avoid asking duplicate or
    trivial follow-ups). Pass `limit=N` to take only the last N turns
    (used by the fast LLM filler — keeps its prompt small)."""
    turns = ctx.recent_turns
    if limit is not None and len(turns) > limit:
        turns = turns[-limit:]
    lines: list[str] = []
    for t in turns:
        speaker_str = t.speaker.value if hasattr(t.speaker, "value") else str(t.speaker)
        lines.append(f"[{speaker_str}] {t.text}")
    return "\n".join(lines) if lines else "(no turns yet — opening of the interview)"


def render_signals_block(ctx: ConversationContext) -> str:
    """Render the runtime signals as a YAML block to embed in the prompt."""
    aev_lines = []
    for e in ctx.recent_audio_events:
        text_part = f' text="{(e.text or "")[:60]}"' if e.text else ""
        aev_lines.append(
            f"  - {e.kind} ts_offset_s={e.ts_offset_s:.1f}{text_part}"
        )
    aev = "\n".join(aev_lines) if aev_lines else "  (none)"

    pending = ctx.pending_phase if ctx.pending_phase else "none"
    last_filler = ctx.last_filler_text or "(none in last 10s)"

    return (
        "runtime_signals:\n"
        f"  candidate_silence_ms: {ctx.candidate_silence_ms}\n"
        f"  ai_activity: {ctx.ai_activity.value}\n"
        f"  phase: {ctx.phase}\n"
        f"  phase_elapsed_s: {ctx.phase_elapsed_s}\n"
        f"  phase_budget_s: {ctx.phase_budget_s}\n"
        f"  phase_pace: {ctx.phase_pace}\n"
        f"  pending_phase: {pending}\n"
        f"  last_filler_text: {last_filler!r}\n"
        f"  barge_in_strike_count: {ctx.barge_in_strike_count}\n"
        f"  in_protected_response: {ctx.in_protected_response}\n"
        f"  last_stt_confidence: {ctx.last_stt_confidence:.2f}\n"
        f"  consecutive_low_conf_finals: {ctx.consecutive_low_conf_finals}\n"
        "  recent_audio_events:\n"
        f"{aev}"
    )
