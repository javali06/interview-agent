"""Turn-taking policy — pure function, NEW_STREAM_B.md §6.4 / SSOT §6.4.

Returns YES / NO / WAIT every 500ms tick. First matching rule wins.
Refined-from-v1: explicit handling for protected mode, mic dropout, AI activity.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from engine.brain.contracts.session_state import AIActivityState


class Decision(str, Enum):
    YES = "yes"        # speak now
    NO = "no"          # don't speak; not even soon
    WAIT = "wait"      # come back next tick


@dataclass
class PolicyConfig:
    endpoint_tail_ms: int = 600
    silence_prompt_ms: int = 15000   # 15s — natural thinking pauses can run 8-12s
    overrun_pct: float = 0.20


@dataclass
class PolicyInputs:
    now_ms: int
    ai_activity: AIActivityState
    candidate_speaking: bool                  # VAD says candidate is currently mid-utterance
    ms_since_last_endpoint: int | None       # None if no endpoint yet this turn
    ms_since_any_speech: int                  # candidate-speech only
    in_protected_response: bool
    mic_dropout: bool
    is_first_turn: bool                       # forces YES for the greeting
    # True iff the last recorded turn in state.turns is a candidate turn.
    # Signal that STT delivered text and the AI hasn't responded yet.
    # Used by Rule 1 to gate dispatch (we need actual text to call the LLM).
    last_turn_is_candidate: bool
    # True from VAD speech_start until AI's audio_start (or dispatch /
    # noise_only_final). Used by Rule 4 to suppress silence_prompt — we
    # KNOW the candidate spoke (per VAD), even if STT hasn't delivered text.
    candidate_spoke_since_last_ai: bool
    # VAD endpoint must have landed AFTER the most recent speech_start for
    # the current utterance — that's the "candidate finished" signal that
    # gates Rule 1. STT final is NOT required for the gate; orchestration
    # is VAD-endpoint-driven and the verifier/tracker pipeline kicks from
    # the endpoint too. STT final still appends the Turn (text input).
    vad_endpoint_after_speech_start: bool = False
    # Candidate has muted their own mic. Only Rule 4 reads it: a muted
    # candidate is silent for a KNOWN reason, so re-asking the question is
    # pointless. It must NOT gate the other rules — the turn that answers what
    # they said before muting (and tells them they're muted) goes out on
    # Rule 1, and would be swallowed by a blanket mute check.
    mic_muted: bool = False
    # "You seem to be muted" has already been said for this mute. Keeps a
    # candidate who stepped away from being told every 15s.
    muted_prompt_fired: bool = False


def decide(inputs: PolicyInputs, cfg: PolicyConfig) -> Decision:
    # Rule -1 (highest precedence): candidate is mid-utterance — NEVER fire.
    # This is the rule that prevents "take your time" firing while you're
    # mid-sentence. It supersedes everything including is_first_turn —
    # if the candidate jumped in before the greeting, let them finish.
    if inputs.candidate_speaking:
        return Decision.NO

    # Rule 0: If we're already speaking (any AI activity), don't fire another turn.
    if inputs.ai_activity not in (AIActivityState.IDLE, AIActivityState.AUDIO_DONE):
        return Decision.NO

    # Rule 0a: Protected response in flight — director has suspended ticks
    # anyway, but defensively: NO.
    if inputs.in_protected_response:
        return Decision.NO

    # Rule 0b: Mic dropout — don't fire silence_prompt rule when we don't know
    # if the candidate is even there.
    if inputs.mic_dropout:
        return Decision.NO

    # Rule 0c: First turn — greeting, no candidate audio required.
    if inputs.is_first_turn:
        return Decision.YES

    # Rule 1: dispatch when:
    #   (a) last_turn_is_candidate          — STT delivered → Turn appended
    #   (b) vad_endpoint_after_speech_start — VAD says "candidate done"
    #
    # VAD endpoint is the authoritative "candidate finished" signal.
    # last_turn_is_candidate gates on text availability so the slow LLM
    # doesn't dispatch before STT has produced anything to respond to.
    if (
        inputs.last_turn_is_candidate
        and inputs.vad_endpoint_after_speech_start
    ):
        return Decision.YES

    # Rule 2: Endpoint fired but STT hasn't delivered the transcript yet.
    # Wait — we're a few hundred ms away from being able to respond
    # meaningfully.
    if (
        inputs.ms_since_last_endpoint is not None
        and inputs.ms_since_last_endpoint < cfg.endpoint_tail_ms + 3000
    ):
        return Decision.WAIT

    # Rule 4: Long silence — prompt the candidate.
    if inputs.ms_since_any_speech >= cfg.silence_prompt_ms:
        # Muted candidates DO get this dispatch — it is the one moment telling
        # them they're muted is useful, and it cannot displace a reply because
        # nothing is waiting to be replied to. The director turns it into "you
        # seem to be muted" rather than a re-ask. But only ONCE per mute: after
        # that, silence from a muted mic is fully explained, and repeating it
        # every 15s at someone who stepped away is noise.
        if inputs.mic_muted and inputs.muted_prompt_fired:
            return Decision.WAIT
        # GUARD: if VAD detected the candidate speak since the last AI turn,
        # we KNOW they spoke even if STT hasn't delivered text. Don't fire
        # silence_prompt; the STT-wait filler ladder is handling this case
        # (it'll either succeed when STT delivers, or escalate to
        # "could you say that again?").
        if inputs.candidate_spoke_since_last_ai:
            return Decision.WAIT
        return Decision.YES

    return Decision.NO
