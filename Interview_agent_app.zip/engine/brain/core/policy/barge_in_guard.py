"""Barge-in guard — pure function.

Decides whether a `vad_speech_start` (after warm-up) should cancel an
active TTS turn. The continuity check itself happens upstream: the
session's warm-up task sleeps `warmup_ms` and only invokes this guard
if VAD is still in SPEAKING/PAUSED at expiry. By the time we get here,
"speech was sustained" is already true — this function only handles
the remaining 4 questions:

  1. Is the AI even cancellable right now? (no if IDLE/AUDIO_DONE)
  2. Are we in protected-response mode? (preserve the AI)
  3. Are we within the audio-end grace window? (let it finish)
  4. Otherwise → CANCEL.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from engine.brain.contracts.session_state import AIActivityState


class BargeInDecision(str, Enum):
    CANCEL = "cancel"            # truly interrupting; stop TTS
    IGNORE = "ignore"             # AI isn't cancellable — speech_start is the next turn
    GRACE_END = "grace_end"       # within audio-end window; treat as next turn
    PROTECTED = "protected"       # protected-response mode; record but don't cancel


@dataclass
class BargeInInputs:
    ai_activity: AIActivityState
    ms_to_expected_audio_end: int | None    # None if no estimate
    in_protected_response: bool


@dataclass
class BargeInConfig:
    audio_end_grace_ms: int = 200
    # Warm-up window. On VAD speech_start we defer the cancel by this long;
    # if endpoint fires during the window, it was a short noise burst (cough,
    # door, paper) and the cancel is skipped. Tradeoff: real barge-ins are
    # delayed by ~warmup_ms before the AI stops.
    warmup_ms: int = 400
    # At warm-up expiry, if VAD is in PAUSED state we re-check how long the
    # most recent speech BURST was (real-time). If it's shorter than this,
    # the candidate didn't really utter anything — it was a brief noise
    # blip (AEC residual, cough, click) that fired speech_start + speech_end
    # in rapid succession but never produced a sustained utterance. Default
    # 150 ms: shorter than even the briefest interrupting word ("wait" ≈
    # 250 ms real-time), longer than typical noise bursts (≤ 100 ms).
    min_burst_ms: int = 150


def decide_barge_in(inputs: BargeInInputs, cfg: BargeInConfig) -> BargeInDecision:
    if inputs.in_protected_response:
        return BargeInDecision.PROTECTED

    if inputs.ai_activity in (AIActivityState.IDLE, AIActivityState.AUDIO_DONE):
        # Nothing to cancel — speech_start is the start of the next candidate
        # turn, not a barge-in.
        return BargeInDecision.IGNORE

    # AI is in LLM_GENERATING / TTS_QUEUED / AUDIO_PLAYING — all cancellable.
    # §8B.2 (cancel during LLM gen) and §8B.3 (cancel during audio) both
    # share this guard; orchestrator chooses the recording path based on
    # whether audio was audible.

    if (
        inputs.ai_activity == AIActivityState.AUDIO_PLAYING
        and inputs.ms_to_expected_audio_end is not None
        and inputs.ms_to_expected_audio_end <= cfg.audio_end_grace_ms
    ):
        return BargeInDecision.GRACE_END

    return BargeInDecision.CANCEL
