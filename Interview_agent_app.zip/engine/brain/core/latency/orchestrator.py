"""LatencyOrchestrator — fast/slow/apology arbiter + per-turn life-cycle.

NEW_STREAM_B.md §7 + §8B + §8F. Owns the entire "candidate finished →
AI speaking" journey.

Flow per turn:
  1. start_turn(turn_id, ctx) — kick off the slow LLM call (cancellable).
  2. fire two timers:
        filler_timer  (default 800ms) — if slow LLM has no first token yet
                                        → run FillerAgent in parallel
        apology_timer (default 2500ms) — if neither slow nor filler has
                                        produced first audio → speak a canned
                                        apology
  3. as slow LLM streams `utterance` chars, accumulate at sentence
     boundaries and ship to TTSClient.speak_chunk. If a filler/apology is
     currently audible, hold pending slow chunks until that audio_end fires;
     then drain in order. This is the clean hand-off (§7.3).
  4. if slow LLM produces first char before filler_timer fires → cancel
     timers, stream normally.
  5. cancel_turn(turn_id, reason): full cancellation path (barge-in).
     Cancels all LLM calls, broadcasts TTS cancels, finalises Turn record
     with `<barged_in/>` and truncated text (§8B.3).

Strike counting (§8B.4):
  - Each cancel-mid-LLM (§8B.2) increments strike counter.
  - Each cancel-mid-audio (§8B.3) increments strike counter.
  - Reaching 3 → enter PROTECTED_RESPONSE_MODE on the next start_turn.
"""
from __future__ import annotations

import asyncio
import logging
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Awaitable, Callable

from engine.brain.agents.apology_agent import ApologyAgent
from engine.brain.agents.filler_agent import FillerAgent
from engine.brain.agents.question_agent import QuestionAgent, QuestionAgentResult
from engine.brain.contracts.events import EventKind
from engine.brain.contracts.session_state import (
    AIActivityState,
    RecentAudioEvent,
    Speaker,
    SessionState,
    Turn,
    TurnInterruption,
)
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from engine.brain.core.cadence_tracker import CadenceTracker
from engine.brain.contracts.tags import (
    tag_apology,
    tag_barged_in,
    tag_barged_in_pre_audio,
    tag_filler,
    tag_protected_response,
    tag_silence_ms,
)
from engine.brain.core.conversation_context import ConversationContext
from engine.brain.core.session_store import SessionStore
from engine.brain.observability.tracer import Tracer
from engine.brain.streamA_bridge.tts_client import TTSClient

logger = logging.getLogger(__name__)


class LatencyState(str, Enum):
    IDLE = "idle"
    DISPATCHED_SLOW = "dispatched_slow"
    DISPATCHED_FILLER = "dispatched_filler"
    STREAMING_FILLER = "streaming_filler"
    STREAMING_APOLOGY = "streaming_apology"
    STREAMING_SLOW = "streaming_slow"
    SLOW_PENDING_HANDOFF = "slow_pending_handoff"
    CANCELLED = "cancelled"


@dataclass
class LatencyConfig:
    filler_threshold_ms: int = 5000       # fast-LLM "thinking" filler if slow has no first token
    apology_threshold_ms: int = 10000     # last-ditch canned phrase if slow LLM is truly dead
    sentence_boundary_chars: str = ".!?\n"
    strike_threshold: int = 3
    silence_reset_window_ms: int = 30_000
    protected_response_max_words: int = 60


_BOUNDARY_RE = re.compile(r"[.!?\n]+\s")


@dataclass
class _TurnFrame:
    turn_id: str                          # "turn-{n}" base
    slow_turn_id: str                     # TTS sub-id namespace for the substantive response
    filler_turn_id: str | None = None
    apology_turn_id: str | None = None
    cancel_event: asyncio.Event = field(default_factory=asyncio.Event)
    slow_task: asyncio.Task | None = None
    filler_task: asyncio.Task | None = None
    filler_timer_task: asyncio.Task | None = None
    apology_timer_task: asyncio.Task | None = None
    slow_first_token_seen: bool = False
    filler_audio_active: bool = False
    apology_audio_active: bool = False
    slow_audio_active: bool = False
    # Set True when the apology recovery fires (slow LLM stalled past
    # apology_threshold_ms). Once set: the slow LLM call is cancelled and
    # ANY late slow output is rejected, the apology becomes this turn's
    # substantive AI utterance, and the apology fast-LLM call must not
    # fire more than once. See _apology_timer + _run_slow guards.
    apology_fired: bool = False
    # Number of filler chunks sent to TTS that haven't yet seen audio_end.
    # While > 0 — i.e. tier-1 or tier-2 filler is in flight (sent or playing) —
    # slow chunks buffer in pending_slow_chunks instead of shipping. Closes
    # the gap between "speak_chunk sent" and "audio_start arrives" (~500ms
    # round-trip).
    filler_chunks_pending: int = 0
    # Local FIFO of slow-LLM sentence chunks waiting to be shipped to TTS.
    # Originally only used during filler/apology hand-off; now also used by
    # Fix-B rate-limiting: at most one slow sub may be in flight to Stream
    # A at a time. Why: Stream A's cancel API can't reliably abort queued
    # (not-yet-active) sub-requests because Kokoro doesn't check the abort
    # flag mid-synthesis. Capping the in-flight count at 1 keeps Stream A's
    # internal queue shallow, so barge-in cancellation has at most one
    # synthesis to wait out instead of N.
    pending_slow_chunks: list[str] = field(default_factory=list)
    # How many slow speak_chunks we've sent to Stream A whose audio_end
    # hasn't fired yet. Incremented in _send_slow_chunk_now, decremented
    # in _on_tts_audio_end. Used as a blocker in _ship_slow_chunk so the
    # value never exceeds 1 per turn (Fix B).
    slow_chunks_in_flight: int = 0
    # Set True once the LLM has finished streaming AND we've enqueued the
    # tail. Combined with `slow_chunks_in_flight == 0` and
    # `pending_slow_chunks == []`, signals that the turn is fully done
    # generating + transmitting — at which point the audio_end handler
    # spawns the sink-drain task to finalize the recorded Turn.
    slow_streaming_done: bool = False
    pending_seq_counter: int = 0
    last_sent_chunk_n: int = 0
    completed: asyncio.Event = field(default_factory=asyncio.Event)
    slow_buf: list[str] = field(default_factory=list)
    slow_word_count_streamed: int = 0
    slow_total_text: list[str] = field(default_factory=list)
    state: LatencyState = LatencyState.IDLE
    last_filler_text: str | None = None
    last_apology_text: str | None = None
    is_protected: bool = False
    silence_ms_at_dispatch: int = 0
    # Why this turn was dispatched — drives which agents/timers are scheduled.
    # See start_turn() for the dispatch matrix.
    trigger: str = "endpoint"   # ∈ {endpoint, greeting, silence_prompt, protected, phase_transition}


class LatencyOrchestrator:
    def __init__(
        self,
        *,
        question_agent: QuestionAgent,
        filler_agent: FillerAgent | None,
        apology_agent: ApologyAgent,
        tts: TTSClient,
        store: SessionStore,
        tracer: Tracer,
        tracker: "CadenceTracker",
        config: LatencyConfig | None = None,
        elapsed_ms_provider: Callable[[], int],
        sink_bytes_buffered_provider: Callable[[], int] | None = None,
    ) -> None:
        self._qa = question_agent
        self._fa = filler_agent
        self._tracker = tracker
        self._ap = apology_agent
        self._tts = tts
        self._store = store
        self._tracer = tracer
        self._cfg = config or LatencyConfig()
        self._elapsed_ms = elapsed_ms_provider
        # Probe the local audio sink's buffered byte count. Used to delay the
        # AUDIO_PLAYING → AUDIO_DONE transition until the speakers actually
        # go silent — Stream A's WS audio_end fires when PCM stops arriving,
        # not when playback finishes. Kokoro synthesizes faster than realtime
        # (~14% on our config), so the sink can hold 1-2s of audio after
        # audio_end. Without this delay, the state machine claims the AI is
        # done speaking while it's still audibly speaking → barge-ins during
        # the sink-tail are missed and no `<barged_in/>` tag is recorded.
        self._sink_bytes_buffered = sink_bytes_buffered_provider or (lambda: 0)
        self._frames: dict[str, _TurnFrame] = {}
        self._turn_seq = 0
        self._tts_audio_active_turn: str | None = None
        # STT-wait filler ladder (see start_stt_wait_filler / cancel_stt_wait_filler)
        self._stt_wait_task: asyncio.Task | None = None
        self._stt_wait_count: int = 0

        # TTS callbacks — wire these on construction.
        self._tts.set_callbacks(
            on_audio_start=self._on_tts_audio_start,
            on_audio_end=self._on_tts_audio_end,
            on_cancelled=self._on_tts_cancelled,
        )

    # ── public API ───────────────────────────────────────────────────────────

    async def start_turn(
        self, ctx: ConversationContext, *, trigger: str = "endpoint",
    ) -> str:
        """Kick off a turn. Returns a turn_id you can pass to `cancel_turn`.

        Dispatch matrix:
          ┌──────────────────┬──────────┬─────────┬──────────┐
          │ trigger          │ slow_LLM │ filler  │ apology  │
          │                  │          │  timer  │  timer   │
          ├──────────────────┼──────────┼─────────┼──────────┤
          │ endpoint         │   yes    │   yes   │   yes    │
          │ silence_prompt   │   yes    │   no    │   no     │
          │ greeting         │   yes    │   no    │   no     │
          │ protected        │   yes    │   no    │   no     │
          └──────────────────┴──────────┴─────────┴──────────┘

        Filler is a single tier: at `filler_threshold_ms` (~800ms), if slow
        LLM hasn't first-tokened, fast LLM produces a "thinking" filler
        ("Hmm, let me think about that for a moment"). Slow LLM keeps
        running and its substantive response plays after the filler audio.
        Apology fires only if slow LLM is genuinely dead at
        `apology_threshold_ms` (~6s).
        """
        self._turn_seq += 1
        base = f"turn-{self._turn_seq}"
        frame = _TurnFrame(
            turn_id=base,
            slow_turn_id=f"slow-{self._turn_seq}",
            silence_ms_at_dispatch=ctx.candidate_silence_ms,
            is_protected=ctx.in_protected_response,
            trigger=trigger,
        )
        self._frames[base] = frame
        await self._store.set_ai_activity(AIActivityState.LLM_GENERATING)

        self._tracer.event(
            EventKind.LATENCY_STATE_CHANGED,
            turn_id=base, from_state="idle",
            to_state=LatencyState.DISPATCHED_SLOW.value,
            trigger=trigger,
        )
        frame.state = LatencyState.DISPATCHED_SLOW
        logger.info(
            "[LATENCY] start_turn turn=%s trigger=%s phase=%s protected=%s",
            base, trigger, ctx.phase, frame.is_protected,
        )

        # Slow LLM dispatch (the only path that produces the substantive
        # response — for every trigger). For silence_prompt, the slow LLM's
        # ConversationContext tells it the candidate has been silent so it
        # will naturally produce a "take your time" prompt.
        frame.slow_task = asyncio.create_task(
            self._run_slow(frame, ctx), name=f"slow-{base}",
        )

        # Filler + apology only on candidate-driven turns.
        if trigger == "endpoint":
            if self._fa is not None and not frame.is_protected:
                frame.filler_timer_task = asyncio.create_task(
                    self._filler_timer(frame, ctx), name=f"filler-timer-{base}",
                )
                logger.info(
                    "[FILLER] timer scheduled for turn=%s (fires at +%dms if slow LLM has no token)",
                    base, self._cfg.filler_threshold_ms,
                )
            frame.apology_timer_task = asyncio.create_task(
                self._apology_timer(frame, ctx), name=f"apology-timer-{base}",
            )
        else:
            logger.info(
                "[LATENCY] no filler/apology timers — trigger=%s", trigger,
            )
        # Return the SLOW turn id (e.g., "slow-3") — that's the id used
        # when the AI's substantive turn is later appended to state.turns
        # via `_record_ai_turn`. The director uses this id to look the
        # turn back up later (e.g., to detect whether a phase_transition
        # dispatch got barged_in before completing). Returning `base`
        # ("turn-3") here is useless to the caller because nothing in
        # state.turns uses that id.
        return frame.slow_turn_id

    async def cancel_turn(
        self, turn_id: str, *, reason: str = "barge_in",
    ) -> None:
        """Full cancellation. Used by barge-in or director shutdown."""
        frame = self._frames.get(turn_id)
        if frame is None:
            return
        frame.state = LatencyState.CANCELLED
        frame.cancel_event.set()
        # Stop in-flight LLM calls + timers.
        for t in (
            frame.slow_task, frame.filler_task,
            frame.filler_timer_task,
            frame.apology_timer_task,
        ):
            if t is not None and not t.done():
                t.cancel()
        # Also cancel the drain task if a sink-drain is pending — the
        # barge-in path will take over recording.
        drain_task = getattr(frame, "_drain_task", None)
        if drain_task is not None and not drain_task.done():
            drain_task.cancel()
        # Broadcast TTS cancels.
        for tid in (frame.slow_turn_id, frame.filler_turn_id, frame.apology_turn_id):
            if tid is not None:
                await self._tts.cancel_turn(tid)

        # Finalise Turn record with truncation tags as appropriate.
        await self._finalize_cancelled_turn(frame, reason=reason)
        frame.completed.set()

    async def wait_completed(self, turn_id: str) -> None:
        frame = self._frames.get(turn_id)
        if frame is not None:
            await frame.completed.wait()

    def is_protected_response(self, turn_id: str) -> bool:
        f = self._frames.get(turn_id)
        return bool(f and f.is_protected)

    def active_turn_id(self) -> str | None:
        """Return the most recent non-completed turn_id, or None."""
        for tid, f in reversed(list(self._frames.items())):
            if not f.completed.is_set() and f.state != LatencyState.CANCELLED:
                return tid
        return None

    # ── STT-wait filler ladder ───────────────────────────────────────────────
    #
    # When the candidate finishes speaking (VAD endpoint fires) but STT is
    # slow to deliver a transcript, this ladder fires "Give me a moment to
    # process" up to 3 times every 5s. Cancelled when STT delivers (any
    # kind). After the 3rd fire, the on_escalate callback is invoked so
    # Director can mark the utterance abandoned and play the canned
    # "could you say that again?" message.

    _STT_WAIT_INTERVAL_S: float = 10.0
    _STT_WAIT_MAX_FIRES: int = 3
    _STT_WAIT_PHRASES: list[str] = [
        "Give me a moment to process that.",
        "Bear with me, I'm working through it.",
        "One sec, almost there.",
    ]
    _STT_WAIT_ESCALATION_PHRASE: str = (
        "Sorry, I didn't quite catch that — could you say that again?"
    )

    async def start_stt_wait_filler(
        self, *, on_escalate: Callable[[], asyncio.Future] | None,
    ) -> None:
        """Start the STT-wait filler loop. Cancels any prior loop."""
        await self.cancel_stt_wait_filler()
        self._stt_wait_count = 0
        self._stt_wait_task = asyncio.create_task(
            self._stt_wait_loop(on_escalate),
            name="stt-wait-filler",
        )
        logger.info("[STT-WAIT] ladder started — fires every %.0fs, max %d, then escalates",
                    self._STT_WAIT_INTERVAL_S, self._STT_WAIT_MAX_FIRES)

    async def cancel_stt_wait_filler(self) -> None:
        """Cancel the STT-wait filler loop (called when STT delivers, when
        a turn dispatches, or on session teardown)."""
        task = getattr(self, "_stt_wait_task", None)
        if task is not None and not task.done():
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass
        self._stt_wait_task = None
        # Cancel any in-flight stt-wait TTS too.
        for i in range(1, self._STT_WAIT_MAX_FIRES + 2):
            await self._tts.cancel_turn(f"stt-wait-{i}")
            await self._tts.cancel_turn(f"stt-wait-escalate")

    async def _stt_wait_loop(
        self, on_escalate: Callable[[], asyncio.Future] | None,
    ) -> None:
        """Fire STT-wait fillers periodically; escalate after max fires."""
        try:
            for fire_n in range(1, self._STT_WAIT_MAX_FIRES + 1):
                await asyncio.sleep(self._STT_WAIT_INTERVAL_S)
                self._stt_wait_count = fire_n
                phrase = self._STT_WAIT_PHRASES[
                    (fire_n - 1) % len(self._STT_WAIT_PHRASES)
                ]
                logger.info(
                    "[STT-WAIT] fire %d/%d — %r",
                    fire_n, self._STT_WAIT_MAX_FIRES, phrase,
                )
                self._tracer.event(
                    "stt_wait_filler_fired",
                    fire_n=fire_n, max_fires=self._STT_WAIT_MAX_FIRES,
                    text=phrase,
                )
                # Ship via TTS as a non-frame turn. _on_tts_audio_start finds
                # no frame, traces, and ignores — exactly what we want.
                await self._tts.speak_chunk(f"stt-wait-{fire_n}", 1, phrase)

            # All fillers fired, STT still hasn't delivered. Escalate.
            await asyncio.sleep(self._STT_WAIT_INTERVAL_S)
            logger.warning(
                "[STT-WAIT] escalating — STT didn't deliver after %d fillers",
                self._STT_WAIT_MAX_FIRES,
            )
            await self._tts.speak_chunk(
                "stt-wait-escalate", 1, self._STT_WAIT_ESCALATION_PHRASE,
            )
            if on_escalate is not None:
                try:
                    await on_escalate()
                except Exception as e:  # pragma: no cover
                    logger.warning("STT-wait on_escalate raised: %s", e)
        except asyncio.CancelledError:
            return

    # ── slow LLM run ─────────────────────────────────────────────────────────

    async def _run_slow(self, frame: _TurnFrame, ctx: ConversationContext) -> None:
        """Run the slow (substantive) LLM. Always produces the real answer.

        On endpoint-triggered turns, fillers (short ack + thinking filler) play
        in front while this is running. Slow's chunks buffer behind any active
        filler audio and play after audio_end (see _ship_slow_chunk +
        _release_next_slow_chunk).
        """
        try:
            def _on_first_token() -> None:
                # If the apology recovery already fired, this slow turn was
                # abandoned — reject its (late) output entirely.
                if frame.apology_fired:
                    return
                if frame.slow_first_token_seen:
                    return
                frame.slow_first_token_seen = True
                self._tracer.event(EventKind.LLM_CALL_FIRST_TOKEN,
                                   agent="question_agent", turn_id=frame.turn_id)
                # Slow LLM has produced — no need to fire the filler or
                # apology. (If filler audio was already playing, slow's
                # chunks queue behind it via _release_next_slow_chunk and
                # play cleanly after audio_end.)
                for t in (
                    frame.filler_timer_task,
                    frame.apology_timer_task,
                ):
                    if t is not None and not t.done():
                        t.cancel()
                if frame.state == LatencyState.DISPATCHED_SLOW:
                    frame.state = LatencyState.STREAMING_SLOW

            def _on_char(c: str) -> None:
                # Drop late slow output once the apology recovery has fired.
                if frame.apology_fired:
                    return
                frame.slow_buf.append(c)
                frame.slow_total_text.append(c)
                if c in self._cfg.sentence_boundary_chars:
                    self._maybe_flush_slow_boundary(frame)

            res: QuestionAgentResult = await self._qa.run(
                ctx,
                on_utterance_char=_on_char,
                on_first_token=_on_first_token,
                cancel_event=frame.cancel_event,
            )
            # Apology recovery took over this turn — discard the stale slow
            # response entirely (don't ship, don't finalise).
            if frame.apology_fired:
                return
            await self._record_llm_usage(res)
            tail = "".join(frame.slow_buf).strip()
            if tail and not frame.cancel_event.is_set():
                await self._ship_slow_chunk(frame, tail)
                frame.slow_buf.clear()
            # LLM stream + tail enqueue both done. The audio_end handler
            # uses this flag to know when "no more chunks coming, OK to
            # spawn the sink-drain finaliser."
            frame.slow_streaming_done = True

            if res.cancelled:
                return
            if not res.utterance:
                frame.completed.set()
                return

            frame.last_sent_chunk_n = frame.pending_seq_counter
            await self._maybe_finalize_slow(frame, res)
        except asyncio.CancelledError:
            return

    def _maybe_flush_slow_boundary(self, frame: _TurnFrame) -> None:
        # Flush whole-sentence chunk(s) from slow_buf.
        text = "".join(frame.slow_buf)
        # Match up to the last sentence boundary char.
        last_boundary = -1
        for i, c in enumerate(text):
            if c in self._cfg.sentence_boundary_chars:
                last_boundary = i
        if last_boundary < 0:
            return
        chunk = text[: last_boundary + 1].strip()
        rest = text[last_boundary + 1:]
        frame.slow_buf = list(rest)
        if chunk:
            asyncio.create_task(self._ship_slow_chunk(frame, chunk))

    async def _ship_slow_chunk(self, frame: _TurnFrame, chunk: str) -> None:
        """Enqueue a slow-LLM sentence for TTS.

        Sentence is sent to Stream A only if ALL of:
          - no filler audio currently playing (`filler_audio_active = False`)
          - no apology audio currently playing (`apology_audio_active = False`)
          - no filler chunk in flight (`filler_chunks_pending == 0`)
          - no prior slow chunk in flight (`slow_chunks_in_flight == 0`)
            ← Fix B: caps Stream A's per-session queue at 1 slow item per turn.

        Otherwise the chunk is buffered locally in `pending_slow_chunks` and
        released by `_release_next_slow_chunk` when the relevant audio_end
        fires.
        """
        if frame.cancel_event.is_set():
            return
        if (
            frame.filler_audio_active
            or frame.apology_audio_active
            or frame.filler_chunks_pending > 0
            or frame.slow_chunks_in_flight > 0
        ):
            frame.pending_slow_chunks.append(chunk)
            frame.state = LatencyState.SLOW_PENDING_HANDOFF
            logger.debug(
                "[BUFFER] slow chunk held (filler_audio=%s apology_audio=%s "
                "filler_chunks_pending=%d slow_in_flight=%d, %d queued)",
                frame.filler_audio_active, frame.apology_audio_active,
                frame.filler_chunks_pending, frame.slow_chunks_in_flight,
                len(frame.pending_slow_chunks),
            )
            return
        await self._send_slow_chunk_now(frame, chunk)

    async def _send_slow_chunk_now(self, frame: _TurnFrame, chunk: str) -> None:
        frame.pending_seq_counter += 1
        seq = frame.pending_seq_counter
        frame.slow_chunks_in_flight += 1
        await self._tts.speak_chunk(frame.slow_turn_id, seq, chunk)
        self._tracer.event(
            EventKind.TTS_SPEAK_CHUNK_SENT,
            turn_id=frame.slow_turn_id, sequence_id=seq, text=chunk, source="slow",
        )

    async def _release_next_slow_chunk(self, frame: _TurnFrame) -> None:
        """Release at most ONE slow chunk from the local queue to TTS.

        Used to be `_drain_pending_slow` which sent all pending chunks at
        once — that pre-filled Stream A's queue and caused the zombie
        cascade on barge-in. Under Fix B we release exactly one chunk per
        invocation, gated by the same blockers as `_ship_slow_chunk`
        (filler/apology not playing, no slow chunk in flight). The next
        release happens when the released chunk's audio_end fires.

        Called from: filler audio_end, apology audio_end, and slow
        audio_end paths in `_on_tts_audio_end`.
        """
        if frame.cancel_event.is_set():
            return
        if not frame.pending_slow_chunks:
            return
        if (
            frame.filler_audio_active
            or frame.apology_audio_active
            or frame.filler_chunks_pending > 0
            or frame.slow_chunks_in_flight > 0
        ):
            return
        chunk = frame.pending_slow_chunks.pop(0)
        await self._send_slow_chunk_now(frame, chunk)
        frame.state = LatencyState.STREAMING_SLOW

    async def _maybe_finalize_slow(
        self, frame: _TurnFrame, res: QuestionAgentResult,
    ) -> None:
        """Once slow LLM is done AND its audio ends, write Turn + emit ai_utterance."""
        full_text = "".join(frame.slow_total_text).strip()
        if not full_text:
            frame.completed.set()
            return

        # Wait for slow audio to finish playing.
        # The audio_end callback will set completed via finalisation.
        # Here we just stash the result text so the audio_end handler can use it.
        frame._slow_full_text = full_text  # type: ignore[attr-defined]

        # If somehow no chunk was ever sent, treat it as no audio expected.
        if frame.pending_seq_counter == 0 and not frame.pending_slow_chunks:
            await self._record_ai_turn(frame, full_text, was_barged_in=False)
            frame.completed.set()

    # ── filler timer + run ───────────────────────────────────────────────────

    async def _filler_timer(self, frame: _TurnFrame, ctx: ConversationContext) -> None:
        try:
            await asyncio.sleep(self._cfg.filler_threshold_ms / 1000.0)
        except asyncio.CancelledError:
            logger.info("[FILLER] timer cancelled for turn=%s (slow LLM was fast enough)",
                        frame.turn_id)
            return
        if frame.cancel_event.is_set():
            logger.info("[FILLER] timer fired but turn was already cancelled — skipping")
            return
        if frame.slow_first_token_seen:
            # Slow LLM already started producing — no filler needed. (This
            # check existed as `frame.winner is not None`, but `winner` was
            # never a real field on _TurnFrame, so it AttributeError'd
            # silently and the filler never fired. The cancel-on-first-
            # token path in _run_slow already prevents this race in most
            # cases; this guards the residual race where the timer fires
            # before the cancel propagates.)
            logger.info(
                "[FILLER] timer fired but slow LLM already producing — skipping"
            )
            return
        # Slow is taking too long; fire filler.
        frame.filler_turn_id = f"filler-{self._turn_seq}"
        frame.state = LatencyState.DISPATCHED_FILLER
        logger.info(
            "[FILLER] FIRING — slow LLM has no first token after %dms — dispatching fast LLM",
            self._cfg.filler_threshold_ms,
        )
        self._tracer.event(
            EventKind.LATENCY_STATE_CHANGED,
            turn_id=frame.turn_id,
            from_state="dispatched_slow", to_state="dispatched_filler",
        )
        self._tracer.event(
            EventKind.FILLER_DISPATCHED,
            turn_id=frame.turn_id, threshold_ms=self._cfg.filler_threshold_ms,
        )
        if self._fa is None:
            logger.warning("[FILLER] timer fired but filler agent is None — no filler will play")
            return
        frame.filler_task = asyncio.create_task(
            self._run_filler(frame, ctx), name=f"filler-{frame.turn_id}",
        )

    async def _run_filler(
        self, frame: _TurnFrame, ctx: ConversationContext,
    ) -> None:
        try:
            buf: list[str] = []

            def _on_first_token() -> None:
                # filler audio is about to start being shipped to TTS
                if frame.state == LatencyState.DISPATCHED_FILLER:
                    frame.state = LatencyState.STREAMING_FILLER

            def _on_char(c: str) -> None:
                buf.append(c)

            res = await self._fa.run(
                ctx,
                on_utterance_char=_on_char,
                on_first_token=_on_first_token,
                cancel_event=frame.cancel_event,
            )
            await self._record_llm_usage(res)
            text = res.utterance.strip() if res and res.utterance else ""
            if not text:
                logger.warning("[FILLER] fast LLM produced empty utterance — no audio")
                return
            if res.cancelled:
                logger.info("[FILLER] fast LLM call was cancelled")
                return
            frame.last_filler_text = text
            logger.info(
                "[FILLER] sending to TTS: %r (canned=%s, took %dms)",
                text, res.used_canned, res.latency_ms,
            )
            # Bump the in-flight counter BEFORE sending — slow chunks must
            # buffer from this moment, not from when audio_start arrives.
            frame.filler_chunks_pending += 1
            await self._tts.speak_chunk(frame.filler_turn_id or "filler-?", 1, text)
            self._tracer.event(
                EventKind.FILLER_SPOKEN, turn_id=frame.turn_id, text=text,
                used_canned=res.used_canned,
            )
            await self._store.mutate(_set_last_filler_text(text))
            await self._store.push_audio_event(RecentAudioEvent(
                ts_offset_s=0.0, kind="ai_filler_spoken", text=text,
            ))
        except asyncio.CancelledError:
            return

    # ── apology timer ─────────────────────────────────────────────────────────

    async def _apology_timer(
        self, frame: _TurnFrame, ctx: ConversationContext,
    ) -> None:
        """Recovery tier. Fires at apology_threshold_ms (≈ 2× the filler
        threshold). If the slow LLM STILL has no first token, we conclude it's
        wedged: cancel it, reject any late output, and use the fast LLM to
        speak a context-aware "sorry, I glitched — could you repeat that?"
        line built from the last 5 turns. That apology becomes this turn's
        substantive AI utterance, so the director treats the turn as done and
        waits for the candidate to re-answer. Fires at most once per turn; if
        even this breaks, the 30s watchdog is the final backstop."""
        try:
            await asyncio.sleep(self._cfg.apology_threshold_ms / 1000.0)
        except asyncio.CancelledError:
            return
        # Skip if: already fired, the frame is terminated (barge-in cancelled
        # it, or the slow LLM already completed — even with empty output), or
        # the slow LLM came alive in time. The empty-completion case is left
        # to the watchdog, since a terminated frame's apology audio would be
        # ignored anyway.
        if frame.apology_fired or self._frame_is_terminated(frame):
            return
        if frame.slow_first_token_seen:
            return

        # Commit. Setting apology_fired BEFORE any await makes the _run_slow
        # guards reject any slow output that lands during this path, and
        # prevents a second apology from firing (fast LLM fires once).
        frame.apology_fired = True
        frame.state = LatencyState.STREAMING_APOLOGY
        logger.warning(
            "[APOLOGY] FIRING recovery — slow LLM has no first token after "
            "%dms. Cancelling the stuck slow LLM and asking the candidate to "
            "repeat.", self._cfg.apology_threshold_ms,
        )
        self._tracer.event(
            EventKind.LATENCY_STATE_CHANGED, turn_id=frame.turn_id,
            from_state="dispatched_slow", to_state="streaming_apology",
        )

        # 1. Kill the stuck slow LLM + any pending filler; reject stale output.
        if frame.slow_task and not frame.slow_task.done():
            frame.slow_task.cancel()
        if frame.filler_task and not frame.filler_task.done():
            frame.filler_task.cancel()
        # Drop any slow chunk Stream A may have queued but not yet played.
        await self._tts.cancel_turn(frame.slow_turn_id)

        # 2. Generate the recovery apology via the fast LLM (last 5 turns).
        #    ApologyAgent falls back to a canned repeat-request internally if
        #    the fast LLM is unavailable / errors / returns empty.
        frame.apology_turn_id = f"apology-{self._turn_seq}"
        buf: list[str] = []

        def _on_char(c: str) -> None:
            buf.append(c)

        def _on_first_token() -> None:
            pass

        try:
            res = await self._ap.generate(
                ctx,
                on_utterance_char=_on_char,
                on_first_token=_on_first_token,
                cancel_event=frame.cancel_event,
            )
        except asyncio.CancelledError:
            return
        await self._record_llm_usage(res)
        text = (res.text or "".join(buf)).strip()
        if not text or res.cancelled:
            logger.warning(
                "[APOLOGY] recovery produced no text — leaving it to the watchdog"
            )
            return

        # 3. Speak it as one chunk; the audio_end handler records it as the
        #    turn's AI utterance and flips to AUDIO_DONE.
        frame._apology_full_text = text  # type: ignore[attr-defined]
        frame.last_apology_text = text
        await self._tts.speak_chunk(frame.apology_turn_id, 1, text)
        logger.info(
            "[APOLOGY] recovery spoken (canned=%s): %r", res.used_canned, text,
        )
        self._tracer.event(
            EventKind.APOLOGY_DISPATCHED, turn_id=frame.turn_id, text=text,
            apology_kind="repeat_request", used_canned=res.used_canned,
        )
        await self._store.push_audio_event(RecentAudioEvent(
            ts_offset_s=0.0, kind="apology_played", text=text,
        ))
        await self._store.mutate(_set_last_apology_ts(self._elapsed_ms()))

    async def _finalize_apology_turn(self, frame: _TurnFrame) -> None:
        """Record the recovery apology as this turn's AI utterance and flip to
        AUDIO_DONE. The apology stands in for the abandoned slow response, so
        the director sees a completed AI turn and waits for the candidate."""
        text = getattr(frame, "_apology_full_text", "") or frame.last_apology_text or ""
        if not text:
            await self._recompute_ai_activity()
            return
        parts: list[str] = []
        if frame.last_filler_text:
            parts.append(tag_filler(frame.last_filler_text))
        display = ("".join(parts) + text).strip()
        if frame.is_protected:
            display = tag_protected_response() + display
        turn = Turn(
            turn_id=frame.apology_turn_id or frame.slow_turn_id,
            speaker=Speaker.AI,
            text=display,
            text_full=text,
            start_ms=self._elapsed_ms(),
            end_ms=self._elapsed_ms(),
            confidence=1.0,
            audio_played_ms=0,
        )
        await self._store.append_turn(turn)
        self._tracer.event(
            EventKind.AI_UTTERANCE, text=display, text_full=text,
            turn_id=turn.turn_id, was_barged_in=False,
        )
        await self._store.mutate(_on_audio_done_mutator(self._elapsed_ms()))
        frame.completed.set()
        if not frame.is_protected:
            await self._store.mutate(_reset_strikes())

    # ── TTS callbacks ─────────────────────────────────────────────────────────

    # ── single source of truth: ai_activity reflects all live frames ────────

    def _frame_is_terminated(self, frame: "_TurnFrame") -> bool:
        """A frame is 'terminated' when no further state transitions on it
        should affect ai_activity. Late TTS events for a terminated frame
        (a cancel command races with an in-flight audio_start, etc.) get
        traced for audit but do NOT bring ai_activity back to AUDIO_PLAYING."""
        return (
            frame.state == LatencyState.CANCELLED
            or frame.completed.is_set()
        )

    async def _recompute_ai_activity(self) -> None:
        """Scan all live frames and set ai_activity to the correct value.

        Called by every handler that mutates per-frame audio flags. This is
        the only place ai_activity transitions OUT of an active state are
        decided — so cancellation/audio-end/cancelled events all converge
        on a consistent global state regardless of arrival order.
        """
        any_audio = False
        any_llm_gen = False
        for f in self._frames.values():
            if self._frame_is_terminated(f):
                continue
            if f.slow_audio_active or f.filler_audio_active or f.apology_audio_active:
                any_audio = True
                break
            if f.slow_task is not None and not f.slow_task.done():
                any_llm_gen = True
        if any_audio:
            new_state = AIActivityState.AUDIO_PLAYING
        elif any_llm_gen:
            new_state = AIActivityState.LLM_GENERATING
        else:
            new_state = AIActivityState.IDLE
        cur = self._store.state.ai_activity
        if cur != new_state:
            await self._store.set_ai_activity(new_state)
            logger.debug(
                "[ACTIVITY] %s → %s (recomputed from frames)",
                cur.value, new_state.value,
            )

    # ── TTS event handlers — all route through _recompute_ai_activity ───────

    async def _on_tts_audio_start(self, evt: dict) -> None:
        turn_id_subbed = evt.get("turn_id", "")
        frame = self._find_frame_by_tts_turn(turn_id_subbed)
        if frame is None:
            return
        # Bug A: late audio_start for a turn we already cancelled. Trace it
        # but DO NOT flip ai_activity back to AUDIO_PLAYING — the candidate
        # never heard this audio (Stream A's cancelled processing will follow).
        if self._frame_is_terminated(frame):
            logger.info(
                "[TTS] audio_start turn=%s sub=%s for TERMINATED frame — ignoring",
                frame.turn_id, turn_id_subbed,
            )
            self._tracer.event(
                EventKind.TTS_AUDIO_START,
                turn_id_subbed=turn_id_subbed,
                request_id=evt.get("request_id"),
                ignored="frame_terminated",
            )
            return

        if turn_id_subbed == frame.filler_turn_id:
            frame.filler_audio_active = True
        elif turn_id_subbed == frame.apology_turn_id:
            frame.apology_audio_active = True
            # The recovery apology stands in for the AI's turn — clear the
            # candidate-spoke flag (same as a real slow turn) so silence
            # detection resets and the director waits for a fresh answer.
            async def _clear_spoke_apology(s: SessionState) -> None:
                s.candidate_spoke_since_last_ai = False
            await self._store.mutate(_clear_spoke_apology)
        elif turn_id_subbed == frame.slow_turn_id:
            frame.slow_audio_active = True
            # When the agent successfully starts a substantive turn, reset
            # the barge-in counter. Repeated past failures shouldn't lock us
            # into protected mode forever.
            await self._store.mutate(_reset_strikes())
            # Per user spec: clear candidate_spoke_since_last_ai when AI
            # starts speaking via TTS. Restores Rule 4 to its normal
            # silence-detection behaviour for the next round.
            async def _clear_spoke(s: SessionState) -> None:
                s.candidate_spoke_since_last_ai = False
            await self._store.mutate(_clear_spoke)
        self._tts_audio_active_turn = turn_id_subbed
        logger.info(
            "[TTS] audio_start turn=%s sub=%s", frame.turn_id, turn_id_subbed,
        )
        self._tracer.event(
            EventKind.TTS_AUDIO_START,
            turn_id_subbed=turn_id_subbed,
            request_id=evt.get("request_id"),
        )
        await self._recompute_ai_activity()

    async def _on_tts_audio_end(self, evt: dict) -> None:
        turn_id_subbed = evt.get("turn_id", "")
        frame = self._find_frame_by_tts_turn(turn_id_subbed)
        self._tracer.event(
            EventKind.TTS_AUDIO_END,
            turn_id_subbed=turn_id_subbed,
            request_id=evt.get("request_id"),
            # How long the utterance plays. The page needs it on LiveKit, where
            # it hears a live track rather than counting the bytes itself (the
            # avatar's lip timing is spread over it).
            duration_ms=evt.get("duration_ms"),
        )
        if frame is None:
            return

        # Bug C: late audio_end for a terminated frame. Clear the flag for
        # bookkeeping but skip the "record turn / set AUDIO_DONE" path —
        # cancel_turn already finalised this frame.
        if self._frame_is_terminated(frame):
            if turn_id_subbed == frame.filler_turn_id:
                frame.filler_audio_active = False
                frame.filler_chunks_pending = max(0, frame.filler_chunks_pending - 1)
            elif turn_id_subbed == frame.apology_turn_id:
                frame.apology_audio_active = False
            elif turn_id_subbed == frame.slow_turn_id:
                frame.slow_audio_active = False
            await self._recompute_ai_activity()
            return

        if turn_id_subbed == frame.filler_turn_id:
            frame.filler_audio_active = False
            frame.filler_chunks_pending = max(0, frame.filler_chunks_pending - 1)
            # Release only if NO more filler chunks are pending — otherwise the
            # next filler audio is about to start and slow chunks should
            # keep buffering.
            if frame.filler_chunks_pending == 0:
                await self._release_next_slow_chunk(frame)
        elif turn_id_subbed == frame.apology_turn_id:
            frame.apology_audio_active = False
            if frame.apology_fired:
                # Recovery apology finished playing — it IS this turn's
                # utterance. Record it + flip to AUDIO_DONE, then stop (don't
                # fall through to the recompute, which would reset to IDLE).
                await self._finalize_apology_turn(frame)
                return
            await self._release_next_slow_chunk(frame)
        elif turn_id_subbed == frame.slow_turn_id:
            # One slow sub finished playing. Decrement in-flight count,
            # then either release the next pending chunk OR (if nothing
            # left + LLM done) trigger the sink-drain finalisation.
            frame.slow_chunks_in_flight = max(0, frame.slow_chunks_in_flight - 1)
            if frame.pending_slow_chunks:
                # More to play — release next, stay in AUDIO_PLAYING.
                await self._release_next_slow_chunk(frame)
                return
            ts = self._tts.turn_state(frame.slow_turn_id)
            still_active = bool(ts and ts.sub_ids_active)
            if (
                not still_active
                and frame.slow_chunks_in_flight == 0
                and frame.slow_streaming_done
            ):
                frame.slow_audio_active = False
                # NOTE: We do NOT mark AUDIO_DONE or record the turn here.
                # Stream A's audio_end means "PCM stopped arriving at the
                # WS", NOT "speakers are silent". Kokoro often synthesizes
                # faster than realtime so the sink can hold 1-2s of
                # buffered audio after audio_end. During that window the
                # candidate is still hearing AI and a barge-in must work.
                # The drain task handles finalization after the sink
                # actually empties — see _finalize_after_sink_drain.
                drain_task = asyncio.create_task(
                    self._finalize_after_sink_drain(frame),
                    name=f"drain-{frame.turn_id}",
                )
                # Track on the frame so cancel_turn() can cancel it.
                frame._drain_task = drain_task  # type: ignore[attr-defined]
                return

        await self._recompute_ai_activity()

    async def _finalize_after_sink_drain(self, frame: _TurnFrame) -> None:
        """Wait for the local audio sink to drain, then record the turn and
        flip the state to AUDIO_DONE. If the frame is cancelled in the
        meantime (barge-in during the sink-tail), exit early — cancel_turn
        handles recording with `<barged_in/>` tags."""
        # Safety timeout: even if the sink never reports empty (e.g., callback
        # provider returned a fixed 0 in tests), don't hang the state machine.
        deadline = self._elapsed_ms() + 5000
        try:
            while not frame.cancel_event.is_set():
                if self._sink_bytes_buffered() <= 0:
                    break
                if self._elapsed_ms() > deadline:
                    logger.warning(
                        "[DRAIN] timeout waiting for sink — finalising anyway"
                    )
                    break
                await asyncio.sleep(0.05)
        except asyncio.CancelledError:
            return
        if frame.cancel_event.is_set():
            # Barge-in fired during drain. cancel_turn → _finalize_cancelled_turn
            # owns the recording. Nothing more to do here.
            logger.info(
                "[DRAIN] turn=%s cancelled during sink-tail — barge-in path "
                "owns finalisation",
                frame.turn_id,
            )
            return

        # Sink truly empty. Record the turn cleanly and flip state.
        full_text = getattr(frame, "_slow_full_text", "")
        if full_text:
            await self._record_ai_turn(frame, full_text, was_barged_in=False)
        await self._store.mutate(
            _on_audio_done_mutator(self._elapsed_ms()),
        )
        # Phase progression is owned by the CadenceTracker + PhaseOverrideAgent.
        # The slow LLM does NOT vote on transitions.
        logger.info(
            "[TIMER] silence-prompt clock STARTED at %dms (sink drained). "
            "Will fire if candidate stays silent past silence_prompt_ms.",
            self._elapsed_ms(),
        )
        frame.completed.set()
        if not frame.is_protected:
            await self._store.mutate(_reset_strikes())

    async def _on_tts_cancelled(self, evt: dict) -> None:
        """Bug B: clear the per-frame flag AND recompute global activity.

        Previously this only cleared the flag, leaving ai_activity stuck at
        whatever the last audio_start had set it to.
        """
        turn_id_subbed = evt.get("turn_id", "")
        frame = self._find_frame_by_tts_turn(turn_id_subbed)
        self._tracer.event(
            EventKind.TTS_CANCELLED,
            turn_id_subbed=turn_id_subbed,
            request_id=evt.get("request_id"),
        )
        if frame is None:
            return
        if turn_id_subbed == frame.filler_turn_id:
            frame.filler_audio_active = False
            frame.filler_chunks_pending = max(0, frame.filler_chunks_pending - 1)
        elif turn_id_subbed == frame.apology_turn_id:
            frame.apology_audio_active = False
        elif turn_id_subbed == frame.slow_turn_id:
            frame.slow_audio_active = False
        await self._recompute_ai_activity()

    def _find_frame_by_tts_turn(self, turn_id_subbed: str) -> _TurnFrame | None:
        for f in self._frames.values():
            if turn_id_subbed in (f.slow_turn_id, f.filler_turn_id, f.apology_turn_id):
                return f
        return None

    # ── finalisation: write the AI Turn into SessionStore ────────────────────

    async def _record_ai_turn(
        self,
        frame: _TurnFrame,
        full_text: str,
        *,
        was_barged_in: bool,
        played_words: int | None = None,
        pre_audio: bool = False,
    ) -> None:
        """Build the recorded AI Turn for the conversation history.

        Three tag scenarios for `was_barged_in=True`:
          - pre_audio=True:  candidate heard NONE of full_text → wrap with
            <barged_in_pre_audio/> so the LLM knows the line of thinking
            was abandoned before audio.
          - played_words > 0: candidate heard the first N words → show
            those + <barged_in/>; the rest is what the LLM had queued.
          - else (filler-only cancel): empty body + <barged_in/> — rare.
        """
        # Build display text with leading tags (filler/apology/silence) and
        # trailing <barged_in/> variant if applicable.
        parts: list[str] = []
        if frame.last_filler_text:
            parts.append(tag_filler(frame.last_filler_text))
        elif frame.last_apology_text:
            parts.append(tag_apology(frame.last_apology_text))
        # (silence re-engagement is now an assistant-role <think> directive
        # injected by the Director, not a <silence_ms=N/> tag on the AI turn.)

        if was_barged_in and pre_audio:
            # §8B.2: full text was generated but never made it to audio.
            display = ("".join(parts) + full_text + tag_barged_in_pre_audio()).strip()
            display_full = full_text
        elif was_barged_in and played_words is not None and played_words > 0:
            # §8B.3: audio played for `played_words` words, rest cut off.
            words = full_text.split()
            shown = " ".join(words[:played_words])
            display = ("".join(parts) + shown + tag_barged_in()).strip()
            display_full = full_text
        elif was_barged_in:
            display = ("".join(parts) + tag_barged_in()).strip()
            display_full = full_text
        else:
            display = ("".join(parts) + full_text).strip()
            display_full = full_text

        if frame.is_protected:
            display = tag_protected_response() + display

        ts = self._tts.turn_state(frame.slow_turn_id)
        played_ms = ts.audio_played_ms if ts else 0
        turn = Turn(
            turn_id=frame.slow_turn_id,
            speaker=Speaker.AI,
            text=display,
            text_full=display_full,
            start_ms=self._elapsed_ms(),
            end_ms=self._elapsed_ms(),
            confidence=1.0,
            audio_played_ms=played_ms,
            interruption=(
                TurnInterruption(
                    interrupted_at_word=played_words or 0,
                    total_words=len(full_text.split()),
                    candidate_text_after=None,
                    ts_ms=self._elapsed_ms(),
                ) if was_barged_in else None
            ),
        )
        await self._store.append_turn(turn)
        self._tracer.event(
            EventKind.AI_UTTERANCE,
            text=display, text_full=display_full,
            turn_id=frame.slow_turn_id, was_barged_in=was_barged_in,
            audio_played_ms=played_ms,
        )

    async def _finalize_cancelled_turn(
        self, frame: _TurnFrame, *, reason: str,
    ) -> None:
        """Called from cancel_turn(). Decides §8B.2 vs §8B.3 path.

        Wrapped in try/finally so the IDLE transition is GUARANTEED even
        if anything inside throws — otherwise ai_activity could get stuck
        at LLM_GENERATING / AUDIO_PLAYING and the policy would never fire
        another turn.
        """
        try:
            await self._finalize_cancelled_turn_body(frame, reason=reason)
        finally:
            # GUARANTEED state reset.
            await self._store.set_ai_activity(AIActivityState.IDLE)

    async def _finalize_cancelled_turn_body(
        self, frame: _TurnFrame, *, reason: str,
    ) -> None:
        full = "".join(frame.slow_total_text).strip()
        # Was the SLOW response audible? (Filler/apology cancellations don't
        # count as strikes — those are benign cancellations of acknowledgments,
        # not interruptions of the actual answer.)
        ts = self._tts.turn_state(frame.slow_turn_id)
        slow_was_audible = bool(ts and ts.audio_played_ms > 0)
        # Did the candidate actually hear the AI's substantive content yet?
        # If only a filler had played, the slow response wasn't underway.
        slow_dispatched = bool(
            frame.slow_task is not None
            and (frame.slow_first_token_seen or full)
        )

        if reason == "barge_in" and slow_was_audible:
            # §8B.3: barge-in during TTS playback of the slow response.
            kokoro_cps = max(10.0, self._store.state.kokoro_chars_per_second)
            estimated_ms = (len(full) / kokoro_cps) * 1000 if full else 1
            played_ratio = min(1.0, ts.audio_played_ms / max(1.0, estimated_ms))
            played_words = max(0, int(played_ratio * len(full.split())))
            await self._record_ai_turn(
                frame, full, was_barged_in=True, played_words=played_words,
            )
            self._tracer.event(
                EventKind.AI_RESPONSE_BARGED_IN,
                turn_id=frame.slow_turn_id,
                played_words=played_words,
                total_words=len(full.split()),
                audio_played_ms=ts.audio_played_ms,
            )
            await self._store.push_audio_event(RecentAudioEvent(
                ts_offset_s=0.0, kind="ai_response_barged_in",
                text=" ".join(full.split()[:played_words]),
            ))
            # Real interruption of substantive content → STRIKE.
            if not frame.is_protected:
                await self._increment_strikes()
        elif reason == "barge_in" and slow_dispatched:
            # §8B.2: barge-in during slow LLM generation. The LLM produced
            # text but the candidate heard NONE of it (cancel reached TTS
            # before audio_start). Record the AI turn with the
            # <barged_in_pre_audio/> tag so the NEXT LLM call sees what
            # line of thinking was abandoned — without being misled into
            # thinking the candidate heard it. (User's request: "context
            # to the llm if it generated the response should be appended".)
            await self._record_ai_turn(
                frame, full, was_barged_in=True, played_words=0,
                pre_audio=True,                       # ← uses the new tag
            )
            self._tracer.event(
                EventKind.AI_RESPONSE_BARGED_IN,
                turn_id=frame.slow_turn_id, played_words=0,
                total_words=len(full.split()) if full else 0,
                phase="llm_generation",
            )
            await self._store.push_audio_event(RecentAudioEvent(
                ts_offset_s=0.0, kind="ai_response_barged_in",
                text=full,
                metadata={"phase": "pre_audio"},
            ))
            # Still a strike — repeated mid-LLM cancels starve the slow LLM
            # and waste cost.
            if not frame.is_protected:
                await self._increment_strikes()
        elif reason == "barge_in":
            # Cancel happened before slow LLM produced any text (only filler
            # may have played). NOT a strike — the candidate just kept
            # talking past a brief acknowledgment. NOT recorded — there is
            # no AI thinking to preserve. (User's rule: "if the response
            # did not come, we should ignore it.")
            self._tracer.event(
                EventKind.AI_RESPONSE_BARGED_IN,
                turn_id=frame.slow_turn_id, played_words=0,
                total_words=0, phase="filler_only", strike=False,
            )
        # Defensive cleanup of in-flight buffers/counters. The frame is now
        # CANCELLED so future events bail at _frame_is_terminated, but
        # explicit reset means no stale state can leak into anything.
        frame.slow_buf.clear()
        frame.pending_slow_chunks.clear()
        frame.filler_chunks_pending = 0
        frame.filler_audio_active = False
        frame.apology_audio_active = False
        frame.slow_audio_active = False
        # ai_activity → IDLE happens in the wrapping finally (see
        # _finalize_cancelled_turn).

    async def _increment_strikes(self) -> None:
        """Bump barge-in strike counter; tracer event."""
        async def _do(s: SessionState) -> int:
            s.barge_in_strike_count += 1
            return s.barge_in_strike_count
        new_count = await self._store.mutate(_do)
        self._tracer.event(
            EventKind.BARGE_IN_STRIKE_INCREMENT,
            new_count=new_count,
            threshold=self._cfg.strike_threshold,
        )

    async def _record_llm_usage(self, res) -> None:
        """Bump SessionState.llm_usage[model] from a QuestionAgentResult /
        FillerAgentResult. No-op if usage wasn't returned (some providers
        don't echo it on cancellation)."""
        model = getattr(res, "model", None)
        if not model:
            return
        tin = getattr(res, "tokens_in", None) or 0
        tout = getattr(res, "tokens_out", None) or 0
        tcached = getattr(res, "tokens_in_cached", None) or 0
        tcw = getattr(res, "tokens_in_cache_write", None) or 0
        treason = getattr(res, "tokens_out_reasoning", None) or 0
        latency = int(getattr(res, "latency_ms", 0) or 0)
        if tin == 0 and tout == 0 and latency == 0:
            return

        async def _do(s: SessionState) -> None:
            entry = s.llm_usage.setdefault(model, {
                "input_tokens": 0, "output_tokens": 0,
                "cached_tokens": 0, "cache_write_tokens": 0,
                "reasoning_tokens": 0,
                "calls": 0, "total_latency_ms": 0,
            })
            entry["input_tokens"] += tin
            entry["output_tokens"] += tout
            entry["cached_tokens"] = entry.get("cached_tokens", 0) + tcached
            entry["cache_write_tokens"] = entry.get("cache_write_tokens", 0) + tcw
            entry["reasoning_tokens"] = entry.get("reasoning_tokens", 0) + treason
            entry["calls"] += 1
            entry["total_latency_ms"] += latency
        await self._store.mutate(_do)


# ── small mutators kept at module scope for clarity ──────────────────

def _set_last_filler_text(text: str):
    def _do(s: SessionState) -> None:
        s.last_filler_text = text
    return _do


def _set_last_apology_ts(ts_ms: int):
    def _do(s: SessionState) -> None:
        s.last_apology_ts_ms = ts_ms
    return _do


def _on_audio_done_mutator(now_ms: int):
    def _do(s: SessionState) -> None:
        s.ai_activity = AIActivityState.AUDIO_DONE
        s.last_audio_end_ts_ms = now_ms
        # Reset the silence timer — see README §F2 / §"AI hallucinates
        # back-to-back turns": treat AI's own speech as a "speech happened"
        # event so Rule 4 doesn't fire 8s later when candidate is just listening.
        s.last_any_speech_ms = now_ms
    return _do


def _reset_strikes():
    def _do(s: SessionState) -> None:
        s.barge_in_strike_count = 0
    return _do


