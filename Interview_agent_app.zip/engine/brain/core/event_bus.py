"""In-process pub/sub for state-change events.

NEW_STREAM_B.md §3 architecture diagram. Used by:
  - Tracer.event(): publishes every emitted Event so live consumers
    (a future TA console websocket, a debug dumper, etc.) can subscribe.
  - The director: subscribes to Stream A events forwarded by the bridge layer.

Sync publish for Tracer (it's called from any thread/task and we don't want
back-pressure on writes). Async subscribers run on the event loop.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Awaitable, Callable

from engine.brain.contracts.events import Event

logger = logging.getLogger(__name__)


Subscriber = Callable[[Event], Awaitable[None]]


class EventBus:
    def __init__(self) -> None:
        self._subs: list[Subscriber] = []
        self._loop: asyncio.AbstractEventLoop | None = None

    def attach_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        """Bind the bus to the running asyncio loop. Required for publish_sync."""
        self._loop = loop

    def subscribe(self, sub: Subscriber) -> None:
        self._subs.append(sub)

    def publish_sync(self, evt: Event) -> None:
        """Fire-and-forget publish from any context. Drops if no loop attached
        (safe during early init / teardown)."""
        if self._loop is None or self._loop.is_closed():
            return
        for sub in self._subs:
            try:
                # Schedule on the bound loop without awaiting.
                self._loop.call_soon_threadsafe(self._spawn, sub, evt)
            except RuntimeError:
                # loop closed mid-call
                pass

    @staticmethod
    def _spawn(sub: Subscriber, evt: Event) -> None:
        try:
            asyncio.create_task(_run_sub(sub, evt))
        except RuntimeError:
            pass


async def _run_sub(sub: Subscriber, evt: Event) -> None:
    try:
        await sub(evt)
    except Exception as e:  # pragma: no cover
        logger.warning("bus subscriber raised: %s", e)
