"""Runtime owner of phase + time + question-pool state.

Reads a static `CadencePlan` and exposes a small imperative API for the
Director (per tick) and the QuestionAgent (per turn dispatch):

  Per-tick (Director._tick):
    .check_phase_budget(now_ms) → {STAY | ADVANCE | END}

  Per-turn (QuestionAgent._build_system_prompt):
    .render_phase_context() → str       # phase prompt block for the slow LLM
    .pick_next_question() → str | None  # for specific-mode phases only

  Manual overrides:
    .advance(now_ms, reason)            # move to the next phase
    .jump_to(phase_id, now_ms, reason)  # skip ahead (e.g., LLM asked to wrap up)
    .end(now_ms, reason)                # mark interview terminated

State semantics:
  - phase advancement is PRIMARILY time-based (concrete logic). The
    fast-LLM override agent (task #6) provides a soft signal that the
    tracker can act on, but the tracker is the authority.
  - in `specific` phases, the question pool is consumed by index. When
    the pool is exhausted, the phase advances even if budget remains
    (no point lingering on a topic with no questions left to ask).
  - in `generic` phases, the LLM improvises from the prompt list; the
    tracker tracks elapsed time and the phase intent only.
"""
from __future__ import annotations

import logging
import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from engine.brain.cadence.schema import CadencePlan, PhaseDef, QuestionPoolItem, ScenarioItem
from engine.brain.core.adaptive import (
    AdaptiveConfig,
    AdaptivePoolState,
    Outcome,
    build_adaptive_pool,
)
from engine.brain.core.scenario_cursor import ScenarioCursor, ScenarioStage

logger = logging.getLogger(__name__)


# Grace seconds added to coding-phase `duration_s` before the server's
# cadence_tracker advances. Lets the browser's autoSubmitAllRemaining
# land its `coding_code_submitted` events first (which trigger
# auto-advance via the natural path) without the server racing ahead and
# clobbering the panel mid-submit.
_CODING_TIME_BUDGET_GRACE_S = 10


class TickDecision(str, Enum):
    """What the Director should do after asking `check_phase_budget`."""

    STAY = "stay"          # remain in the current phase
    ADVANCE = "advance"    # move to the next phase
    END = "end"            # interview is over; request session end


@dataclass
class PoolState:
    """Per-phase consumption tracker for `specific` mode pools.
    `remaining` is the list of question indices not yet asked, in original
    order. We pop from the front each time so questions are asked in the
    order the cadence-author put them — predictable for testing."""

    phase_id: str
    remaining: list[int] = field(default_factory=list)
    asked_ids: list[str] = field(default_factory=list)

    # Uniform read API shared with AdaptivePoolState so the tracker's render /
    # budget paths don't need to branch on pool type.
    def head_index(self) -> int | None:
        """Pool index of the next question to ask (FIFO head), or None when the
        pool is exhausted."""
        return self.remaining[0] if self.remaining else None

    def count_remaining(self) -> int:
        return len(self.remaining)


def _written_response_brief(
    phase: PhaseDef, question: QuestionPoolItem | None,
) -> str:
    """The rules the interviewer LLM needs when it opens a WRITTEN-RESPONSE
    question (comprehensive / transcription / translation / image description),
    or "" for an ordinary spoken question.

    WHY this exists: the task's material — the audio clip, the source passage,
    the image — is rendered on the candidate's screen by the client, straight
    from the phase config, and deliberately never passes through the LLM (that's
    what guarantees a translation's passage reaches them exactly as authored).
    The model only ever sees the INSTRUCTION. Left to itself it fills the gap:
    it invents a plausible passage and reads it out, or it answers the task,
    which silently replaces the authored assessment. It also can't know the
    submission is one-shot, so it tries to probe for depth like a spoken answer.

    Per-type wording (what the material is, what "doing it yourself" means)
    lives in the ONE table — question_types.QUESTION_TYPES — so a fifth type
    needs no edit here.
    """
    phase_wr = getattr(phase, "written_response", None)
    if phase_wr is None:
        return ""
    wr = phase_wr.resolved_for(
        getattr(question, "written_response", None) if question is not None else None
    )
    from engine.brain.cadence import question_types as qt
    try:
        spec = qt.spec_for(wr.question_type)
    except Exception:          # unknown type → still emit the shared rules
        spec = None

    limit_unit = "word" if wr.limit_kind == "words" else "character"
    lines = [
        "WRITTEN RESPONSE TASK — the candidate answers this by TYPING into a "
        "text box on their screen, not by speaking.",
        "  - Say the instruction above VERBATIM. Do not paraphrase it, do not "
        "add examples, and do not restate the "
        f"{limit_unit} limit or the countdown — their screen already shows "
        "both.",
    ]
    material = getattr(spec, "material_label", "") if spec else ""
    if material:
        lines.append(
            f"  - The material for this task ({material}) is already displayed "
            "on their screen. You do NOT have it. Never quote it, invent it, "
            "summarise it, or read it aloud — say the instruction and stop."
        )
    ban = getattr(spec, "self_answer_ban", "") if spec else ""
    if ban:
        lines.append(f"  - You are the examiner, not the candidate: {ban}.")
    lines.append(
        # Deliberately does NOT say "acknowledge …" here: read as an action for
        # THIS turn, the model appended a second 'Got it, thank you.' after the
        # instruction. The one-clause acknowledgement is already specified by
        # HOW TO OPEN / PHASE BOUNDARY; this bullet only forbids probing.
        "  - ONE submission closes this task. Never ask a follow-up about it, "
        "never ask them to expand, and never comment on how well they did — "
        "the tracker hands you the next task and you simply state it."
    )
    return "\n".join(lines)


_MEDIA_KIND_LABEL = {"image": "image", "video": "video", "audio": "audio clip"}


def _scenario_item_brief(item: ScenarioItem) -> str:
    """The rules the interviewer LLM needs when it presents a Visual
    Scenario Analysis item, mirroring `_written_response_brief` — the
    item's media never passes through the LLM (it's rendered on the
    candidate's screen straight from the phase config), so the model must
    be told it exists, told never to invent/describe it, and told the
    rephrase/no-reveal/follow-up rules that keep the assessment intact."""
    kind_label = _MEDIA_KIND_LABEL.get(item.media.kind, "item")
    return "\n".join([
        "VISUAL SCENARIO ANALYSIS ITEM — the candidate is looking at (or "
        f"listening to) an {kind_label} shown on their screen. You do NOT "
        "have it and cannot see or hear it. Never describe, invent, or "
        "guess its contents.",
        "  - Ask the question below REPHRASED naturally in your own words — "
        "keep the exact scenario details and any numbers UNCHANGED (e.g. "
        "\"20 users to 2000\" must stay exactly as given). Do not add hints "
        "and do not mention or hint at the concepts you're listening for.",
        "  - If the candidate asks a clarifying question about the media "
        "itself (e.g. \"can you replay it?\", \"what does that mean?\"), "
        "answer BRIEFLY (they can replay it themselves with the on-screen "
        "controls) without giving away the answer, then return to the "
        "question.",
        "  - If they say they don't know or ask to skip, gently encourage "
        "one more try; if they still want to skip after that, let them move "
        "on — do not insist further.",
    ])


class CadenceTracker:
    """Stateful runtime overlay on top of an immutable `CadencePlan`."""

    def __init__(
        self,
        plan: CadencePlan,
        *,
        now_ms_provider,
        adaptive_config: AdaptiveConfig | None = None,
    ) -> None:
        self._plan = plan
        self._elapsed_ms = now_ms_provider
        self._adaptive_config = adaptive_config or AdaptiveConfig()
        self._current_phase_id: str = plan.first_phase_id()
        self._phase_started_at_ms: int = self._elapsed_ms()
        self._ended: bool = False
        # Per-phase pool state. A plain FIFO `PoolState` for static specific
        # phases; an `AdaptivePoolState` (difficulty-bucketed) for phases that
        # opted into adaptive_difficulty.
        self._pools: dict[str, PoolState | AdaptivePoolState] = {}
        for p in plan.phases:
            # Pool-backed, not literally "specific" — a written-response phase
            # (translation/comprehensive/…) names its own mode and MUST still
            # get a pool built here, or it would run with nothing to ask.
            if not p.uses_question_pool:
                continue
            if p.adaptive_difficulty:
                self._pools[p.id] = build_adaptive_pool(
                    phase_id=p.id,
                    difficulties=[q.difficulty for q in p.question_pool],
                    cfg=self._adaptive_config,
                )
            else:
                self._pools[p.id] = PoolState(
                    phase_id=p.id,
                    remaining=list(range(len(p.question_pool))),
                )
        # Per-phase Visual Scenario Analysis cursor — mirrors the pool dict
        # above, but keyed on `is_scenario_analysis` (scenario_items is
        # orthogonal to question_mode, so it needs its own construction
        # branch rather than living inside the pool loop). Built once; a
        # phase is never re-entered (matches pool phases, which also don't
        # support revisiting) and durable-resume restarts the phase from
        # scratch (matches the coding-phase precedent — see director.py's
        # resume bring-up).
        self._scenario_cursors: dict[str, ScenarioCursor] = {}
        for p in plan.phases:
            if p.is_scenario_analysis:
                self._scenario_cursors[p.id] = ScenarioCursor(
                    items=list(p.scenario_items), phase_id=p.id,
                )
        # ID of the specific-mode pool question that has already been
        # presented to the slow LLM via a previous render. While this is
        # set and matches the current pool head, `render_phase_context`
        # suppresses the "ASK THIS QUESTION NEXT" block — the LLM has
        # already heard the question. It now follows the verifier's push
        # instruction to dig for the missing depth on the same question.
        # Cleared when the question is popped (answered) or when the
        # phase changes.
        self._presented_question_id: str | None = None
        logger.info(
            "[CADENCE] tracker initialised: %d phases, %ds total, starting phase=%s",
            len(plan.phases), plan.total_duration_s, self._current_phase_id,
        )

    # ── read-only accessors ────────────────────────────────────────────

    @property
    def plan(self) -> CadencePlan:
        return self._plan

    @property
    def current_phase_id(self) -> str:
        return self._current_phase_id

    @property
    def phase_started_at_ms(self) -> int:
        return self._phase_started_at_ms

    @property
    def is_ended(self) -> bool:
        return self._ended

    def current_phase(self) -> PhaseDef:
        return self._plan.get_phase(self._current_phase_id)

    def is_terminal_phase(self) -> bool:
        """True iff we're in the last phase of the cadence — Director uses
        this to decide whether the wrap-up auto-end should fire."""
        return self._current_phase_id == self._plan.terminal_phase_id()

    def elapsed_in_phase_s(self) -> int:
        return max(0, (self._elapsed_ms() - self._phase_started_at_ms) // 1000)

    def remaining_in_phase_s(self) -> int:
        budget = self.current_phase().duration_s
        return max(0, budget - self.elapsed_in_phase_s())

    def questions_remaining(self) -> int:
        """For the CURRENT phase if it's specific-mode; 0 otherwise (or if
        the phase is generic)."""
        pool = self._pools.get(self._current_phase_id)
        return pool.count_remaining() if pool else 0

    def asked_ids_in_current_phase(self) -> list[str]:
        pool = self._pools.get(self._current_phase_id)
        return list(pool.asked_ids) if pool else []

    # ── serialization (stateless text tier: snapshot the runtime overlay) ──
    # The immutable CadencePlan is NOT stored — a restore rebuilds a fresh
    # tracker from the plan (recreating the right pool TYPE per phase) and
    # overlays only these mutable consumption deltas. Additive; the voice path
    # never calls these.
    def to_snapshot(self) -> dict:
        """JSON-safe snapshot of the mutable runtime overlay (phase cursor +
        per-phase pool consumption), covering FIFO and adaptive pools."""
        pools: dict = {}
        for pid, pool in self._pools.items():
            if isinstance(pool, AdaptivePoolState):
                pools[pid] = {
                    "type": "adaptive",
                    "remaining_by_level": {k: list(v) for k, v in pool.remaining_by_level.items()},
                    "current_level": pool.current_level,
                    "asked_ids": list(pool.asked_ids),
                    "recovered_streak": pool.recovered_streak,
                    "last_transition": pool.last_transition,
                    "last_trigger": pool.last_trigger,
                }
            else:  # PoolState (FIFO)
                pools[pid] = {
                    "type": "fifo",
                    "remaining": list(pool.remaining),
                    "asked_ids": list(pool.asked_ids),
                }
        return {
            "current_phase_id": self._current_phase_id,
            "presented_question_id": self._presented_question_id,
            "ended": self._ended,
            "phase_started_at_ms": self._phase_started_at_ms,
            "pools": pools,
        }

    def restore_snapshot(self, snap: dict) -> None:
        """Overlay a to_snapshot() dict onto a freshly-built tracker. Tolerant of
        missing keys so a partial/older blob degrades rather than crashes."""
        if not snap:
            return
        self._current_phase_id = snap.get("current_phase_id", self._current_phase_id)
        self._presented_question_id = snap.get("presented_question_id")
        self._ended = bool(snap.get("ended", False))
        self._phase_started_at_ms = int(
            snap.get("phase_started_at_ms", self._phase_started_at_ms) or 0
        )
        for pid, pd in (snap.get("pools") or {}).items():
            pool = self._pools.get(pid)
            if pool is None:
                continue
            if isinstance(pool, AdaptivePoolState) and pd.get("type") == "adaptive":
                pool.remaining_by_level = {
                    k: list(v) for k, v in (pd.get("remaining_by_level") or {}).items()
                }
                pool.current_level = pd.get("current_level", pool.current_level)
                pool.asked_ids = list(pd.get("asked_ids") or [])
                pool.recovered_streak = int(pd.get("recovered_streak", 0) or 0)
                pool.last_transition = pd.get("last_transition", "start")
                pool.last_trigger = pd.get("last_trigger", "start")
            elif isinstance(pool, PoolState) and pd.get("type") == "fifo":
                pool.remaining = list(pd.get("remaining") or [])
                pool.asked_ids = list(pd.get("asked_ids") or [])

    # ── tick decision (Director consults every 500ms) ─────────────────

    def check_phase_budget(self) -> TickDecision:
        """Decide what to do at the current tick.

        Logic (concrete, deterministic — no LLM):
          1. If `ended` flag is set → END.
          2. If the current phase is `specific` AND its pool is empty →
             ADVANCE (or END, if current was terminal).
          3. If `elapsed_in_phase_s` exceeds the phase's `duration_s` →
             ADVANCE (or END, if terminal).
          4. Otherwise → STAY.
        """
        if self._ended:
            return TickDecision.END

        # Pool exhaustion takes priority over time budget. `head_index() is
        # None` means "nothing drawable": for a static pool that's an empty
        # remaining list; for an adaptive pool it ALSO covers the case where the
        # highest reachable difficulty has drained (lower buckets may still have
        # questions, but the upward-only policy ends the phase rather than
        # dropping back down — see core/adaptive.py).
        pool = self._pools.get(self._current_phase_id)
        if pool is not None and pool.head_index() is None:
            return self._advance_or_end_decision("pool_exhausted")

        # Visual Scenario Analysis: same "nothing left to do" early-end as
        # pool exhaustion above — every item finished (good-enough,
        # follow-ups exhausted, or skipped) ends the phase immediately
        # rather than idling until the wall clock also catches up.
        cursor = self._scenario_cursors.get(self._current_phase_id)
        if cursor is not None and cursor.is_phase_done():
            return self._advance_or_end_decision("scenario_exhausted")

        # Untimed (text) interviews are purely question-driven: there is no
        # wall-clock budget, so a phase advances ONLY on pool exhaustion (above)
        # or an explicit signal (jump_to/end via the Director). Skip the
        # time-budget branch entirely. A specific-mode pool is what gives an
        # untimed phase its end; generic untimed phases never auto-advance here
        # and must be ended by signal.
        if not self._plan.timed:
            return TickDecision.STAY

        # Coding-phase grace: browser timer starts ~2s after server (WS
        # delivery + lazy import + Pyodide warm). At duration_s exact, the
        # browser's autoSubmitAllRemaining is still ~2s away from firing.
        # Without grace, the server advances first → panel unmounts →
        # autoSubmit interval cleared → zero submissions recorded. Adding
        # 10s lets the browser's submits land via the existing
        # coding_code_submitted auto-advance path. If browser is dead,
        # server takes over after the grace expires.
        phase_obj = self.current_phase()
        budget = phase_obj.duration_s
        if getattr(phase_obj, "coding_question_ids", None):
            budget += _CODING_TIME_BUDGET_GRACE_S

        if self.elapsed_in_phase_s() >= budget:
            # Close out the scenario cursor's records (current item wrapped,
            # every unreached item marked `not_reached`) at the exact moment
            # the phase actually ends via the wall clock — mirrors how pool
            # exhaustion above is itself the record of "nothing left".
            if cursor is not None:
                cursor.time_up(now_s=self.elapsed_in_phase_s())
            return self._advance_or_end_decision("time_budget")

        return TickDecision.STAY

    def _advance_or_end_decision(self, reason: str) -> TickDecision:
        nxt = self._plan.next_phase_id(self._current_phase_id)
        if nxt is None:
            logger.info(
                "[CADENCE] terminal phase '%s' done (reason=%s) → END",
                self._current_phase_id, reason,
            )
            return TickDecision.END
        logger.info(
            "[CADENCE] phase '%s' done (reason=%s) → ADVANCE to '%s'",
            self._current_phase_id, reason, nxt,
        )
        return TickDecision.ADVANCE

    # ── mutators (Director calls when it decides to act on a decision) ─

    def advance(self, reason: str = "natural") -> Optional[str]:
        """Move to the next phase. Returns the new phase id, or None if we
        were already on the terminal phase (in which case the caller should
        call `end()` instead)."""
        if self._ended:
            return None
        nxt = self._plan.next_phase_id(self._current_phase_id)
        if nxt is None:
            logger.info(
                "[CADENCE] advance() called on terminal phase '%s' — ignoring",
                self._current_phase_id,
            )
            return None
        from_p = self._current_phase_id
        self._current_phase_id = nxt
        self._phase_started_at_ms = self._elapsed_ms()
        self._presented_question_id = None
        logger.info(
            "[CADENCE] phase transition: %s → %s (reason=%s)",
            from_p, nxt, reason,
        )
        return nxt

    def jump_to(self, phase_id: str, reason: str = "manual") -> str:
        """Skip ahead (or back) to an arbitrary phase. Used by the
        fast-LLM phase-override agent for cases like 'candidate asked to
        wrap up early'."""
        if self._ended:
            return self._current_phase_id
        # Validate — raises KeyError if phase_id isn't in plan.
        self._plan.get_phase(phase_id)
        if phase_id == self._current_phase_id:
            return phase_id
        from_p = self._current_phase_id
        self._current_phase_id = phase_id
        self._phase_started_at_ms = self._elapsed_ms()
        self._presented_question_id = None
        logger.info(
            "[CADENCE] phase jump: %s → %s (reason=%s)",
            from_p, phase_id, reason,
        )
        return phase_id

    def end(self, reason: str = "natural") -> None:
        """Mark the interview terminated. Director sees `is_ended` and
        triggers session shutdown."""
        if self._ended:
            return
        self._ended = True
        logger.info(
            "[CADENCE] interview END at phase '%s' (reason=%s)",
            self._current_phase_id, reason,
        )

    # ── question picking (specific-mode only) ─────────────────────────

    def peek_next_question(self) -> QuestionPoolItem | None:
        """Return the next question to ask WITHOUT removing it from the pool.

        Used by `render_phase_context` to embed the question text into the
        slow LLM's system prompt so the LLM speaks the exact pool question.
        Returns None for generic phases or when the pool is exhausted.

        Works for both static and adaptive pools via `head_index()` — for
        adaptive pools the head is the front of the current (effective)
        difficulty bucket."""
        pool = self._pools.get(self._current_phase_id)
        if pool is None:
            return None
        idx = pool.head_index()
        if idx is None:
            return None
        return self.current_phase().question_pool[idx]

    def mark_current_question_presented(self) -> bool:
        """Record that the current pool question has been presented to the
        slow LLM. Subsequent `render_phase_context()` calls suppress the
        question text (the LLM already asked it) and instead direct the
        LLM to follow the verifier's push instruction. Cleared automatically
        when `pick_next_question()` pops the question (verifier said
        answered) or when the phase changes.

        Called by the director right after a dispatch in a specific-mode
        phase — by then the slow LLM has been handed the question.

        Returns True iff this was a FRESH presentation (a question the LLM
        hadn't been shown yet) — the Director uses that to emit the ask-time
        observability event exactly once per question, not on every follow-up
        re-push of the same question."""
        q = self.peek_next_question()
        if q is None:
            return False
        if self._presented_question_id == q.id:
            return False
        self._presented_question_id = q.id
        return True

    def unmark_current_question_presented(self) -> None:
        """Reverse `mark_current_question_presented` — used when the prior
        dispatch was barged-in before reaching audio, so the candidate
        never actually heard the question and the next render must
        present it in full."""
        self._presented_question_id = None

    def pick_next_question(
        self,
        *,
        outcome: Outcome | None = None,
        rng: random.Random | None = None,
    ) -> QuestionPoolItem | None:
        """For the current phase, return the question that was on the table AND
        remove it from the pool. Returns None for generic phases or when the
        pool is exhausted.

        Static pools: FIFO over `remaining` (the cadence author's order). The
        `outcome` arg is ignored.

        Adaptive pools: pops the current question and, using `outcome` (how the
        candidate did on it), resolves the difficulty of the NEXT question via
        the dynamic populated ladder (see core/adaptive.py). `outcome` defaults
        to NEUTRAL (no level change) if the caller doesn't pass one.

        `rng` is accepted but currently unused (placeholder for future
        randomisation of static pools)."""
        pool = self._pools.get(self._current_phase_id)
        if pool is None:
            return None
        phase = self.current_phase()

        if isinstance(pool, AdaptivePoolState):
            idx = pool.pop_and_advance(outcome or Outcome.NEUTRAL)
            if idx is None:
                return None
            q = phase.question_pool[idx]
            pool.asked_ids.append(q.id)
            self._presented_question_id = None
            logger.info(
                "[CADENCE/ADAPTIVE] picked '%s' (difficulty=%s, outcome=%s) "
                "from phase '%s' → next_level=%s transition=%s (%d remaining)",
                q.id, q.difficulty, (outcome or Outcome.NEUTRAL).value,
                self._current_phase_id, pool.current_difficulty(),
                pool.last_transition, pool.count_remaining(),
            )
            return q

        # ── static FIFO pool ────────────────────────────────────────────
        if not pool.remaining:
            return None
        idx = pool.remaining.pop(0)
        q = phase.question_pool[idx]
        pool.asked_ids.append(q.id)
        # The next question (if any) hasn't been presented yet — clear
        # the suppression flag so the upcoming render shows the new
        # question text in full.
        self._presented_question_id = None
        logger.info(
            "[CADENCE] picked question '%s' from phase '%s' "
            "(%d remaining)",
            q.id, self._current_phase_id, len(pool.remaining),
        )
        return q

    # ── Visual Scenario Analysis (mirrors the pool accessors above) ───────
    # All Director-facing: the pure state machine lives in scenario_cursor.py,
    # this is just the phase-keyed lookup + delegation, exactly like `_pools`.

    def scenario_cursor(self, phase_id: str | None = None) -> ScenarioCursor | None:
        return self._scenario_cursors.get(phase_id or self._current_phase_id)

    def current_scenario_item(self) -> ScenarioItem | None:
        cursor = self._scenario_cursors.get(self._current_phase_id)
        return cursor.current_item() if cursor else None

    def scenario_next_action(self) -> dict:
        """The current phase's next scenario action (`{"action": ...}`), or
        `{"action": "noop"}` when the current phase isn't a scenario phase."""
        cursor = self._scenario_cursors.get(self._current_phase_id)
        return cursor.next_action() if cursor else {"action": "noop"}

    def scenario_needs_media_wait(self, now_s: float) -> bool:
        cursor = self._scenario_cursors.get(self._current_phase_id)
        return bool(cursor and cursor.needs_media_wait(now_s))

    def render_scenario_item_brief(self) -> str:
        """The VISUAL SCENARIO ANALYSIS ITEM rules for the item currently on
        the table, or "" when this isn't a scenario phase or no item is
        current. Exposed so QuestionAgent can reinforce them in its final
        PHASE BOUNDARY imperative, mirroring `render_written_response_brief`."""
        item = self.current_scenario_item()
        return _scenario_item_brief(item) if item is not None else ""

    # ── adaptive-difficulty introspection (for the Director's events) ─────

    def is_adaptive_phase(self, phase_id: str | None = None) -> bool:
        pool = self._pools.get(phase_id or self._current_phase_id)
        return isinstance(pool, AdaptivePoolState)

    def adaptive_state(self) -> AdaptivePoolState | None:
        """The current phase's adaptive pool state, or None if not adaptive."""
        pool = self._pools.get(self._current_phase_id)
        return pool if isinstance(pool, AdaptivePoolState) else None

    # ── prompt rendering (for the slow LLM's system prompt) ───────────

    def render_phase_context(self) -> str:
        """STATIC phase block for the slow LLM's system prompt.

        Contains ONLY the slow-changing setup for the current phase:
        intent, elapsed/budget counters, question_mode, and the
        operating instructions for that mode. The per-turn "ask THIS
        question" / "current question still on the table" directive is
        NOT here — that's `render_think_directive()` and rides in a
        <think> user message right before generation. Splitting the
        two keeps the system prompt stable across turns (better cache
        utilisation, easier for the model to anchor on phase semantics)
        while the volatile per-turn directive lives where it belongs:
        next to the candidate's latest reply.
        """
        phase = self.current_phase()
        elapsed = self.elapsed_in_phase_s()
        budget = phase.duration_s
        lines: list[str] = [
            f"current_phase: {phase.id}",
            f"  intent (the phase's purpose, written by the cadence author): "
            f"{phase.intent}",
            f"  elapsed_s: {elapsed}",
            f"  budget_s: {budget}",
            f"  question_mode: {phase.question_mode}",
        ]
        if phase.is_scenario_analysis:
            cursor = self._scenario_cursors.get(phase.id)
            lines.append(
                "  operating_instructions (derived from scenario_items — "
                "question_mode stays 'generic', mirroring a coding phase): "
                "you present media items one at a time. Each item's rules "
                "arrive via the <think> block right before each turn — "
                "when to just say the framing line, when to ask the "
                "rephrased question, and when to push a focused follow-up. "
                "Never invent the media's contents; never reveal the "
                "concepts you're listening for. The tracker advances items "
                "and the phase; you do NOT decide when to move on."
            )
            if cursor is not None:
                lines.append(
                    f"  scenario_items_total: {len(cursor.items)}"
                )
                lines.append(
                    f"  scenario_item_index: {min(cursor.index + 1, len(cursor.items))}"
                )
        elif not phase.uses_question_pool:
            lines.append(
                "  operating_instructions (derived from question_mode="
                "generic): improvise organically — paraphrase the topic "
                "prompts surfaced in the <think> block, sequence them "
                "naturally, and follow up on what the candidate says. "
                "The tracker watches the time budget and will advance "
                "the phase when ready; you do NOT decide when to leave."
            )
        else:
            pool = self._pools[phase.id]
            lines.append(
                # Name the phase's ACTUAL mode — saying "specific" here on a
                # translation phase contradicts the question_mode line directly
                # above it and invites the model to reconcile the two.
                f"  operating_instructions (derived from question_mode="
                f"{phase.question_mode}): you are handed ONE question at a time via the "
                "<think> block right before each turn. Ask EXACTLY that "
                "question (verbatim, or minimal paraphrase for natural "
                "speech). Do NOT invent a different question. Do NOT skip "
                "ahead. When the <think> block says the current question "
                "still needs more depth, push on the specific gap it "
                "describes; otherwise you'll be handed the next question."
            )
            lines.append(f"  questions_remaining: {pool.count_remaining()}")
            if pool.asked_ids:
                lines.append(f"  already_asked: {pool.asked_ids}")
            if isinstance(pool, AdaptivePoolState):
                # The slow LLM doesn't choose difficulty — it just asks the
                # question handed to it — but surfacing the live level keeps
                # the system-prompt block (and the event log derived from it)
                # honest about what's happening.
                lines.append("  difficulty_mode: adaptive")
                lines.append(f"  current_difficulty: {pool.current_difficulty()}")
        return "\n".join(lines)

    def render_think_directive(self, *, is_phase_entry: bool = False) -> str:
        """Per-turn directive content, intended to go inside a <think>
        user-role message right before generation.

        For SPECIFIC mode:
          - First time this pool question is presented → the exact
            question text the slow LLM should speak.
          - Already presented (verifier said partial last turn) → a
            "same question still on the table; follow the verifier's
            push" hint, NOT the question text (we don't want the LLM
            to re-ask verbatim).
          - Pool exhausted → wrap-up nudge.

        For GENERIC mode:
          - At PHASE ENTRY (is_phase_entry=True) → list the phase's
            `generic_prompts` so the slow LLM knows what topics to open
            with. The same prompts also ride in the `<phase_changed>`
            marker turn, so this is belt-and-suspenders for the first
            turn of a generic phase.
          - On subsequent turns → return "" (no topic block in <think>).
            Re-listing starter prompts mid-conversation reads like "you
            went off-track, restart from these starting points", which
            is misleading when the LLM is correctly mid-deep-dive on a
            topic. The slow LLM has the conversation history + the
            phase's intent in its system prompt; that's enough to keep
            improvising in-phase.

        Returns "" when there's nothing the tracker wants to say this
        turn; the caller can decide whether to emit a <think> message
        at all.
        """
        phase = self.current_phase()
        if phase.is_scenario_analysis:
            return self._render_scenario_think_directive()
        if not phase.uses_question_pool:
            # Topics only at phase entry — see docstring for rationale.
            if not is_phase_entry or not phase.generic_prompts:
                return ""
            out = ["topics to improvise from (paraphrase, don't recite):"]
            for p in phase.generic_prompts:
                out.append(f"  - {p}")
            return "\n".join(out)
        # specific mode
        pool = self._pools[phase.id]
        next_q = self.peek_next_question()
        if next_q is None:
            return (
                "pool is exhausted — the tracker will advance to the next "
                "phase shortly. Briefly wrap up the current thread; do "
                "not invent a new technical question."
            )
        already_presented = (
            self._presented_question_id is not None
            and self._presented_question_id == next_q.id
        )
        if not already_presented:
            brief = _written_response_brief(phase, next_q)
            if brief:
                # A written-response phase holds N tasks; only the FIRST is
                # dispatched through a phase change, so questions 2..N would
                # otherwise get none of these rules.
                parts = [
                    "state this task EXACTLY as written:",
                    f'  task: "{next_q.text}"',
                    brief,
                ]
                return "\n".join(parts)
            parts = [
                "ask this question (verbatim, or minimal paraphrase for "
                "natural speech):",
                f'  question: "{next_q.text}"',
            ]
            if next_q.topic:
                parts.append(f"  topic: {next_q.topic}")
            return "\n".join(parts)
        # already presented — push for depth. We surface the question's
        # coverage-tag checklist DIRECTLY here (not only via the verifier note)
        # so the slow LLM always has the concrete concepts to probe even if the
        # fast verifier's free-text note is weak/garbled. The slow LLM compares
        # the checklist against what the candidate already said and asks only
        # the unaddressed concept(s).
        lines = [
            "current_question_status: ALREADY ASKED — the candidate's last "
            "reply did not fully cover this question. Do NOT re-ask the "
            "original question.",
        ]
        points = next_q.coverage_points()
        if points:
            label = (
                "A complete answer should cover these concepts:"
                if next_q.uses_tags else
                "A complete answer should cover these points:"
            )
            lines.append(label)
            for p in points:
                lines.append(f"  - {p}")
            lines.append(
                "Look at what the candidate has ALREADY said, then ask ONE "
                "single follow-up question that rolls up ALL the concept(s) "
                "above they have NOT covered yet — give them one chance to "
                "address everything still missing in a single response. Do "
                "NOT split into multiple probes and do NOT re-ask what they "
                "already answered. (The verifier note above also names the "
                "concepts still missing.)"
            )
        else:
            lines.append(
                "Push for the specific depth the verifier note above "
                "describes; ask one focused follow-up. Do not re-probe what "
                "they already covered."
            )
        return "\n".join(lines)

    def _render_scenario_think_directive(self) -> str:
        """Per-turn <think> content for a Visual Scenario Analysis phase —
        the scenario counterpart to the pool branch above. Reads the pure
        `ScenarioCursor`'s stage (see scenario_cursor.py) to decide whether
        this turn should be the media framing line, the rephrased question,
        or a focused follow-up; never surfaces raw coverage_tags to the
        candidate-facing text (only as concepts the SLOW LLM should probe
        for, exactly like the pool branch's coverage-tag checklist)."""
        cursor = self._scenario_cursors.get(self._current_phase_id)
        if cursor is None:
            return ""
        remaining = self.remaining_in_phase_s()
        time_hint = cursor.time_budget_hint(remaining)
        action = cursor.next_action()
        kind = action.get("action")
        item = action.get("item")

        if kind == "end_phase":
            return (
                "every scenario item is finished — the tracker will advance "
                "to the next phase shortly. Briefly wrap up; do not start a "
                "new topic."
            )
        if cursor.should_wrap_up_now(remaining):
            # So little phase time remains that the tracker will end the
            # phase imminently (check_phase_budget's time-budget branch) —
            # tell the LLM to wrap the CURRENT item in one short exchange
            # rather than start a fresh follow-up it won't get to finish.
            return (
                "time for this phase is almost up — briefly wrap up the "
                "current item in one short exchange (e.g. \"let's move "
                "on\") rather than asking anything further about it. Do "
                "not start a new topic."
            )
        if kind == "show_media":
            media_label = _MEDIA_KIND_LABEL.get(item.media.kind, "item")
            lines = []
            # If the PREVIOUS item's media failed to load, acknowledge it in
            # this same opening line rather than silently moving on — the
            # candidate saw a broken player and deserves one sentence of
            # explanation (see the runtime spec's "tell the candidate
            # briefly" media-error handling).
            prev_idx = cursor.index - 1
            if 0 <= prev_idx < len(cursor.records) and cursor.records[prev_idx].media_ack == "error":
                lines.append(
                    "The previous item's media failed to load — briefly and "
                    "warmly say so in one short clause (e.g. \"looks like "
                    "that one didn't load — let's move on\") as part of your "
                    "opening line below, then continue."
                )
            lines.extend([
                "Say ONLY this framing line (adapt naturally to the media "
                f"kind), then STOP — do not ask the question yet:",
                f'  "This is the {media_label} on your screen. '
                + ("Take a look." if item.media.kind == "image"
                   else "Please watch or listen — I will wait.") + '"',
            ])
            if item.media.kind != "image":
                lines.append(
                    "  The media will play automatically once you've said "
                    "this line — wait silently until it finishes; do not "
                    "speak again until the tracker hands you the question."
                )
            return "\n".join(lines)
        if kind == "await_media":
            # Director's dispatch-suppression gate should prevent reaching
            # here at all; defensive no-op if it's ever bypassed.
            return ""
        if kind == "ask_question":
            lines = [
                "The media has been shown. Ask the question below REPHRASED "
                "naturally in your own words — keep every scenario detail "
                "and number EXACTLY as given, do not add hints, and do not "
                "mention or imply the concepts you're listening for:",
                f'  question: "{item.question}"',
            ]
            if time_hint:
                lines.append(f"  pacing: {time_hint}")
            return "\n".join(lines)
        if kind == "ask_followup":
            missing = action.get("missing_tags") or []
            lines = [
                "current_item_status: ALREADY ASKED — the candidate's last "
                "reply did not fully cover this item's question. Do NOT "
                "re-ask the original question.",
            ]
            if missing:
                lines.append(
                    "A complete answer should have touched on these ideas "
                    "(probe for them naturally — do NOT recite this list or "
                    "quote these words verbatim, and do NOT reveal them as a "
                    "checklist):"
                )
                for t in missing:
                    lines.append(f"  - {t}")
                lines.append(
                    "Ask ONE focused follow-up that rolls up whatever is "
                    "still missing — give them one chance to address it in a "
                    "single reply."
                )
            else:
                lines.append(
                    "Ask one focused follow-up pushing for more depth on "
                    "this item. Do not re-probe what they already covered."
                )
            if time_hint:
                lines.append(f"  pacing: {time_hint}")
            return "\n".join(lines)
        # "await_answer" or unknown — nothing new to say this turn.
        return ""

    def render_written_response_brief(self) -> str:
        """The WRITTEN RESPONSE TASK rules for the question currently on the
        table, or "" when this isn't a written-response phase. Exposed so the
        QuestionAgent can reinforce them in its final PHASE BOUNDARY imperative
        (the last thing the model reads before generating)."""
        return _written_response_brief(self.current_phase(), self.peek_next_question())

    def render_transition_marker(
        self, from_phase: str, to_phase_id: str, reason: str = "natural",
    ) -> str:
        """Render the message-history marker the tracker inserts when a
        phase change applies. This is what the slow LLM sees in its next
        turn's conversation history — a tag plus the new phase's intent
        and (for generic phases) prompts. The slow LLM responds to this
        marker by opening the new phase; it does NOT choose to transition.

        For `specific` phases we just note that questions come from the
        pool — the director picks them via `pick_next_question()`.
        """
        phase = self._plan.get_phase(to_phase_id)
        lines = [
            f'<phase_changed from="{from_phase}" to="{to_phase_id}" reason="{reason}">',
            f"  intent: {phase.intent}",
            "  HOW TO OPEN: VERY briefly acknowledge the candidate's "
            "previous reply (one short clause, ≤6 words like 'Got it.' "
            "or 'Makes sense.'), then SMOOTHLY pivot into this new "
            "phase's first question/intent. Do NOT announce the phase "
            "change — the candidate must not know phases exist. Do NOT "
            "repeat or summarise the prior thread.",
        ]
        if phase.is_scenario_analysis:
            cursor = self._scenario_cursors.get(to_phase_id)
            lines.append(
                "  this is a VISUAL SCENARIO ANALYSIS phase — the first "
                "item's media is being shown on the candidate's screen now. "
                "The <think> block right after this marker tells you EXACTLY "
                "what to say this turn (the framing line only — do not ask "
                "the question yet)."
            )
            if cursor is not None:
                lines.append(f"  scenario_items_total: {len(cursor.items)}")
        elif not phase.uses_question_pool:
            lines.append("  open with one of these (paraphrase, don't recite):")
            for p in phase.generic_prompts:
                lines.append(f"    - {p}")
        else:
            pool = self._pools.get(to_phase_id)
            head_idx = pool.head_index() if pool else None
            if pool is not None and head_idx is not None:
                first_q = phase.question_pool[head_idx]
                lines.append(
                    f"  question_pool_size: {pool.count_remaining()}"
                )
                brief = _written_response_brief(phase, first_q)
                if brief:
                    # A written task's instruction must land VERBATIM — the
                    # "minimal paraphrase for natural speech" licence below is
                    # for spoken questions and would let the model reword an
                    # authored assessment task.
                    lines.append(
                        "  open this phase by stating this task EXACTLY as "
                        "written:"
                    )
                    lines.append(f'    "{first_q.text}"')
                    lines.extend(f"  {ln}" for ln in brief.splitlines())
                else:
                    lines.append(
                        "  open this phase with this exact question (or "
                        "minimal paraphrase for natural speech):"
                    )
                    lines.append(f'    "{first_q.text}"')
            else:
                lines.append(
                    "  question pool is empty — tracker will advance "
                    "again immediately."
                )
        lines.append("</phase_changed>")
        return "\n".join(lines)
