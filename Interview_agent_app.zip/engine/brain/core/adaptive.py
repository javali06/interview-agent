"""Adaptive (dynamic) difficulty for `specific` question phases.

A `specific` phase normally asks a fixed pool of questions in author order.
When a phase opts in with `adaptive_difficulty: true`, the pool is split into
difficulty buckets (easy / medium / hard) and the *next* question's difficulty
is chosen dynamically from how the candidate has been doing — read from the
verifier's per-question outcome.

This module is deliberately PURE and runtime-agnostic:
  - `classify_outcome()` maps a verifier verdict → a per-question `Outcome`.
  - `decide_level_delta()` maps an outcome (+ a running "recovered" streak) → a
    difficulty step (-1 / 0 / +1).
  - `AdaptivePoolState` holds the per-phase buckets and applies those steps over
    the DYNAMIC populated ladder (floor = lowest level that still has questions,
    ceiling = highest; both rise as buckets drain).

Nothing here touches the LLM, disk, or the network — every question is already
in memory, so selection is a synchronous list pop. The `CadenceTracker` owns one
of these per adaptive phase and the `Director` drives it from the verifier hook.

See reading/adaptive_difficulty_plan.md for the full design + rationale.
"""
from __future__ import annotations

import logging
from collections import deque
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)

# Canonical difficulty ordering, low → high. A phase's `levels` are this list
# filtered to whatever difficulties actually appear in its pool, so a pool with
# only easy + hard makes escalate jump easy→hard with no empty "medium" stop.
DIFFICULTY_ORDER: tuple[str, ...] = ("easy", "medium", "hard")


class Outcome(str, Enum):
    """How the candidate did on a single pool question, derived at the moment
    the question is consumed (the verifier said the question is finished)."""

    FIRST_TRY = "first_try"   # answered with zero follow-up pushes → escalate
    RECOVERED = "recovered"   # answered, but only after ≥1 follow-up push
    FAILED = "failed"         # follow-up cap hit without a full answer → de-escalate
    NEUTRAL = "neutral"       # no signal (verifier fallback) → no level change


# Human-readable trigger label for the observability events. Describes WHY the
# level is what it is for the next question.
_TRIGGER_NAME: dict[Outcome, str] = {
    Outcome.FIRST_TRY: "FIRST_TRY",
    Outcome.RECOVERED: "RECOVERED_STREAK",
    Outcome.FAILED: "FAILED",
    Outcome.NEUTRAL: "NEUTRAL",
}


@dataclass(frozen=True)
class AdaptiveConfig:
    """Tunable rubric thresholds. Defaults match the resolved design:
    first-try → escalate immediately; 2 consecutive recoveries → escalate;
    follow-up-cap miss → de-escalate; verifier fallback → no change."""

    start_difficulty: str = "easy"
    escalate_on_first_try: bool = True
    recovered_streak_to_escalate: int = 2
    deescalate_on_skip: bool = True
    # When True (default), `default_answered` (verifier timeout/error fallback)
    # is treated as NEUTRAL so a verifier outage never moves difficulty.
    neutral_on_default_answered: bool = True


# ── pure decision functions ─────────────────────────────────────────────────


def classify_outcome(
    effective_intent: str,
    partial_count: int,
    cfg: AdaptiveConfig,
) -> Outcome:
    """Map the Director's effective verifier intent (+ how many follow-up
    pushes the current question took) to a per-question `Outcome`.

    Called only for the intents that actually consume a pool question:
    `answered`, `default_answered`, `partial_answer_skip`.
    """
    if effective_intent == "partial_answer_skip":
        return Outcome.FAILED
    if effective_intent == "default_answered":
        if cfg.neutral_on_default_answered:
            return Outcome.NEUTRAL
        # Treated like a real answer if the operator opted out of neutral.
        return Outcome.FIRST_TRY if partial_count == 0 else Outcome.RECOVERED
    if effective_intent == "answered":
        return Outcome.FIRST_TRY if partial_count == 0 else Outcome.RECOVERED
    # Defensive: any other intent shouldn't consume a question, but if it does,
    # don't move difficulty.
    return Outcome.NEUTRAL


def decide_level_delta(
    latest: Outcome,
    recovered_streak: int,
    cfg: AdaptiveConfig,
) -> tuple[int, int]:
    """Pure rubric: given the latest outcome and the current consecutive-
    `RECOVERED` streak, return `(delta, new_recovered_streak)` where delta is
    -1 / 0 / +1. The streak resets to 0 on any actual escalation/de-escalation
    so we never double-jump off one good/bad answer.
    """
    if latest == Outcome.FIRST_TRY:
        return (1, 0) if cfg.escalate_on_first_try else (0, 0)
    if latest == Outcome.RECOVERED:
        streak = recovered_streak + 1
        if streak >= cfg.recovered_streak_to_escalate:
            return (1, 0)
        return (0, streak)
    if latest == Outcome.FAILED:
        return (-1, 0) if cfg.deescalate_on_skip else (0, 0)
    # NEUTRAL (or anything else): hold level, keep streak.
    return (0, recovered_streak)


# ── runtime pool state ───────────────────────────────────────────────────────


@dataclass
class AdaptivePoolState:
    """Per-phase consumption tracker for an adaptive `specific` pool.

    `remaining_by_level` maps each present difficulty → the list of pool
    indices not yet asked at that difficulty (FIFO, author order within a
    level). A question lives in exactly one bucket and is removed when drawn,
    so questions can never repeat. `current_level` is the difficulty we intend
    to draw the NEXT question from; it always resolves to a populated level via
    `_effective_level()` (snapping UP if its own bucket has drained).
    """

    phase_id: str
    levels: list[str]                      # present difficulties, low→high
    remaining_by_level: dict[str, list[int]]
    current_level: str
    cfg: AdaptiveConfig
    asked_ids: list[str] = field(default_factory=list)
    recovered_streak: int = 0
    window: deque = field(default_factory=lambda: deque(maxlen=16))
    # Observability about how we arrived at `current_level` for the next
    # question. `last_transition` ∈ {start, escalated, stayed, deescalated,
    # exhaustion_escalate, exhausted}.
    last_transition: str = "start"
    last_trigger: str = "start"

    # ── read-only helpers (safe to call from the render path) ────────────

    def count_remaining(self) -> int:
        """Total questions left across every bucket (informational)."""
        return sum(len(v) for v in self.remaining_by_level.values())

    def _effective_level(self) -> str | None:
        """The level we'd actually draw the next question from.

        If `current_level` still has questions → that level. If it has drained,
        snap UPWARD to the nearest populated higher level (exhaustion is
        upward-only). If nothing at-or-above is populated → None (the highest
        reachable level has drained; the phase should end — we do NOT drop down
        to refill from easier buckets).
        """
        if self.remaining_by_level.get(self.current_level):
            return self.current_level
        base_i = self.levels.index(self.current_level)
        for i in range(base_i + 1, len(self.levels)):
            if self.remaining_by_level[self.levels[i]]:
                return self.levels[i]
        return None

    def head_index(self) -> int | None:
        """Pool index of the next question to ask (the head of the effective
        level's bucket), or None when nothing is drawable → phase should end."""
        lvl = self._effective_level()
        if lvl is None:
            return None
        return self.remaining_by_level[lvl][0]

    def current_difficulty(self) -> str | None:
        """Difficulty of the next question to ask (resolved/effective level)."""
        return self._effective_level()

    def remaining_counts(self) -> dict[str, int]:
        """{level: remaining_count} for every present level — for the event log."""
        return {lvl: len(self.remaining_by_level[lvl]) for lvl in self.levels}

    # ── consume + advance (mutating; called from pick_next_question) ─────

    def pop_and_advance(self, outcome: Outcome) -> int | None:
        """Remove the question currently on the table (head of the effective
        level), record its `outcome`, and resolve `current_level` for the NEXT
        question. Returns the popped pool index, or None if already exhausted.
        """
        draw_level = self._effective_level()
        if draw_level is None:
            return None
        idx = self.remaining_by_level[draw_level].pop(0)
        self.window.append(outcome)
        delta, self.recovered_streak = decide_level_delta(
            outcome, self.recovered_streak, self.cfg
        )
        self._resolve_next_level(draw_level, delta, outcome)
        return idx

    def _resolve_next_level(
        self, base_level: str, delta: int, outcome: Outcome,
    ) -> None:
        """Set `current_level` (and the transition labels) for the next
        question, applying `delta` over the DYNAMIC populated ladder.

        Rules:
          - Clamp the move to the current [floor, ceiling] of populated levels
            (floor/ceiling rise as lower/higher buckets drain).
          - Snap to the nearest populated level ≥ the (clamped) target so gaps
            and just-drained buckets escalate upward, never downward.
          - If everything still populated is BELOW where we just drew (i.e. the
            highest reachable level drained) → mark exhausted; phase ends.
        """
        populated = [lvl for lvl in self.levels if self.remaining_by_level[lvl]]
        trig = _TRIGGER_NAME.get(outcome, "NEUTRAL")
        if not populated:
            self.last_transition = "exhausted"
            self.last_trigger = trig
            return

        base_i = self.levels.index(base_level)
        pop_is = [self.levels.index(lvl) for lvl in populated]  # ascending
        floor_i, ceil_i = pop_is[0], pop_is[-1]

        # Highest reachable level drained (only lower levels remain) → end the
        # phase rather than dropping back to easier questions.
        if base_i > ceil_i:
            self.last_transition = "exhausted"
            self.last_trigger = trig
            self.current_level = base_level  # _effective_level() will return None
            return

        target_i = max(min(base_i + delta, ceil_i), floor_i)
        # Snap to nearest populated level at or above the clamped target.
        at_or_above = [i for i in pop_is if i >= target_i]
        chosen_i = at_or_above[0] if at_or_above else pop_is[-1]
        self.current_level = self.levels[chosen_i]

        # Label the transition for observability.
        base_drained = base_level not in populated
        if chosen_i > base_i:
            self.last_transition = (
                "exhaustion_escalate" if base_drained else "escalated"
            )
            self.last_trigger = "exhaustion" if base_drained else trig
        elif chosen_i < base_i:
            self.last_transition = "deescalated"
            self.last_trigger = trig
        else:
            self.last_transition = "stayed"
            self.last_trigger = trig


def build_adaptive_pool(
    *,
    phase_id: str,
    difficulties: list[str | None],
    cfg: AdaptiveConfig,
) -> AdaptivePoolState:
    """Construct an `AdaptivePoolState` from the per-question difficulties of a
    phase's pool (index order == `difficulties` order).

    `difficulties[i]` is the difficulty of `phase.question_pool[i]`. Items with
    an unrecognised/missing difficulty are bucketed as `easy` defensively (the
    schema validator already requires a difficulty on adaptive phases).
    """
    remaining_by_level: dict[str, list[int]] = {}
    for idx, diff in enumerate(difficulties):
        key = diff if diff in DIFFICULTY_ORDER else "easy"
        remaining_by_level.setdefault(key, []).append(idx)
    # Present levels in canonical low→high order.
    levels = [d for d in DIFFICULTY_ORDER if d in remaining_by_level]
    # Resolve the start level: requested start if present, else the lowest
    # present level (defensive — the validator enforces presence).
    start = cfg.start_difficulty if cfg.start_difficulty in levels else levels[0]
    logger.info(
        "[CADENCE/ADAPTIVE] phase '%s' adaptive pool: levels=%s counts=%s start=%s",
        phase_id, levels,
        {lvl: len(remaining_by_level[lvl]) for lvl in levels}, start,
    )
    return AdaptivePoolState(
        phase_id=phase_id,
        levels=levels,
        remaining_by_level=remaining_by_level,
        current_level=start,
        cfg=cfg,
    )
