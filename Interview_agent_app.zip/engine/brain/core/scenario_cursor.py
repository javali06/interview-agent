"""Visual Scenario Analysis: the per-item state machine that walks a
scenario_analysis phase's `scenario_items` in order under the phase's single
time budget (`PhaseDef.duration_s`).

Pure and LLM/IO-free by design — `CadenceTracker` owns one `ScenarioCursor`
per scenario_analysis phase (mirrors how it owns a `PoolState`/
`AdaptivePoolState` per pool-backed phase). Director drives it and supplies
the verifier's judge results as plain data; this module never calls an LLM,
never touches asyncio, and never touches the WS — so it is fully unit
testable without mocking any of those.

Per-item flow (mirrors the spec in the runtime prompt):
    AWAIT_MEDIA_INTRO → [image: immediate] / [video|audio: AWAIT_MEDIA_ACK]
        → READY_TO_ASK → AWAIT_ANSWER → (judge) → ASK_FOLLOWUP → AWAIT_ANSWER
        → ... → DONE → next item's AWAIT_MEDIA_INTRO, or PHASE_DONE.

The "machine-readable action" Director consumes each tick is
`ScenarioCursor.next_action()` — one small dict, mirroring the
tool-call/decision shapes already used elsewhere in this codebase (e.g.
phase_override's `{override, reason}`).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Literal, Optional

from engine.brain.cadence.schema import ScenarioItem

# Outcomes that close an item — mirrors the verifier's "answered" /
# "default_answered" / "partial_answer_skip" (Director-internal) trio that
# already pops a pool question, so recognising them here needs no new
# vocabulary on the Director side.
GOOD_ENOUGH_INTENTS = frozenset({"answered", "default_answered", "partial_answer_skip"})


class ScenarioStage(str, Enum):
    AWAIT_MEDIA_INTRO = "await_media_intro"  # need to dispatch the framing turn (once)
    AWAIT_MEDIA_ACK = "await_media_ack"      # framing turn spoken; waiting on playback (video/audio only)
    READY_TO_ASK = "ready_to_ask"            # ready to dispatch the (rephrased) question
    AWAIT_ANSWER = "await_answer"            # question asked; waiting on the candidate + verifier
    ASK_FOLLOWUP = "ask_followup"            # not good enough; a follow-up is due next dispatch
    DONE = "done"                            # this item is finished
    PHASE_DONE = "phase_done"                # every item finished, or the budget ran out


MediaAckKind = Literal["ended", "error", "skipped"]
ItemOutcome = Literal[
    "good_enough", "followups_exhausted", "skipped_by_candidate",
    "skipped_media_error", "skipped_time_budget", "not_reached", "in_progress",
]


@dataclass
class Attempt:
    """One candidate answer (initial or a follow-up reply), as judged."""

    text: str
    good_enough: bool
    missing_tags: list[str] = field(default_factory=list)


@dataclass
class ItemRecord:
    """Coverage recording for ONE item (Step B — data only, no scores)."""

    item_id: str
    media_ref: str
    media_kind: str
    question_asked: str = ""            # the rephrased question, once spoken
    attempts: list[Attempt] = field(default_factory=list)
    followups_asked: list[str] = field(default_factory=list)
    tags_covered: list[str] = field(default_factory=list)
    tags_missing: list[str] = field(default_factory=list)
    outcome: ItemOutcome = "in_progress"
    media_ack: Optional[MediaAckKind] = None
    started_at_s: float = 0.0
    ended_at_s: Optional[float] = None

    def to_dict(self) -> dict:
        return {
            "item_id": self.item_id,
            "media_ref": self.media_ref,
            "media_kind": self.media_kind,
            "question_asked": self.question_asked,
            "attempts": [
                {"text": a.text, "good_enough": a.good_enough, "missing_tags": list(a.missing_tags)}
                for a in self.attempts
            ],
            "followups_asked": list(self.followups_asked),
            "tags_covered": list(self.tags_covered),
            "tags_missing": list(self.tags_missing),
            "outcome": self.outcome,
            "media_ack": self.media_ack,
            "started_at_s": self.started_at_s,
            "ended_at_s": self.ended_at_s,
        }


@dataclass
class ScenarioCursor:
    items: list[ScenarioItem]
    phase_id: str
    max_followups_default: int = 2   # fallback only; each item normally carries its own
    # Bounded wait for a video/audio item's playback ack before Director gives
    # up and proceeds anyway ("do not block indefinitely" per the runtime spec).
    media_wait_timeout_s: float = 90.0

    index: int = 0
    stage: ScenarioStage = ScenarioStage.AWAIT_MEDIA_INTRO
    followups_used: int = 0
    records: list[ItemRecord] = field(default_factory=list)
    _skip_nudged: bool = False
    _media_dispatched_at_s: Optional[float] = None
    _media_wait_timed_out: bool = False

    def __post_init__(self) -> None:
        if self.items and not self.records:
            self._open_record(0)

    # ── construction helpers ─────────────────────────────────────────────

    def _open_record(self, index: int, now_s: float = 0.0) -> None:
        item = self.items[index]
        self.records.append(ItemRecord(
            item_id=item.id, media_ref=item.media.ref, media_kind=item.media.kind,
            started_at_s=now_s,
        ))

    # ── read-only ──────────────────────────────────────────────────────

    def current_item(self) -> Optional[ScenarioItem]:
        if self.index >= len(self.items):
            return None
        return self.items[self.index]

    def current_record(self) -> Optional[ItemRecord]:
        if self.index >= len(self.records):
            return None
        return self.records[self.index]

    def is_phase_done(self) -> bool:
        return self.stage is ScenarioStage.PHASE_DONE or self.index >= len(self.items)

    def items_remaining(self) -> int:
        return max(0, len(self.items) - self.index)

    def needs_media_wait(self, now_s: float) -> bool:
        """True while Director must suppress dispatch — the framing turn has
        been spoken and we're waiting on a video/audio item's playback to
        end, error, or be skipped, and the bounded wait hasn't expired yet."""
        if self.stage is not ScenarioStage.AWAIT_MEDIA_ACK:
            return False
        if self._media_dispatched_at_s is None:
            return True
        elapsed = now_s - self._media_dispatched_at_s
        if elapsed >= self.media_wait_timeout_s:
            return False  # caller should call media_wait_timed_out() next
        return True

    def media_wait_timed_out(self, now_s: float) -> bool:
        """Whether the bounded media wait just expired (call ONLY when
        `needs_media_wait` returned False due to a real timeout, to move the
        stage forward and record the timeout — distinguishes a genuine
        timeout from 'never needed a wait in the first place')."""
        if self.stage is not ScenarioStage.AWAIT_MEDIA_ACK:
            return False
        if self._media_dispatched_at_s is None:
            return False
        return (now_s - self._media_dispatched_at_s) >= self.media_wait_timeout_s

    def time_budget_hint(self, remaining_phase_s: float) -> str:
        """A short pacing hint for the prompt: how much time is left and how
        many items remain, so the LLM doesn't spend the whole budget on
        item 1. Empty string when there's nothing useful to say (last item,
        or already past the budget)."""
        remaining_items = self.items_remaining()
        if remaining_items <= 1 or remaining_phase_s <= 0:
            return ""
        per_item = remaining_phase_s / remaining_items
        return (
            f"{remaining_items} scenario items remain with about "
            f"{int(remaining_phase_s)}s left in this phase — roughly "
            f"{int(per_item)}s each. Pace yourself; do not spend the whole "
            "budget on the current item."
        )

    def should_wrap_up_now(self, remaining_phase_s: float, floor_s: float = 20.0) -> bool:
        """True when so little phase time remains that the CURRENT item
        should be wrapped up immediately rather than followed up on."""
        return remaining_phase_s <= floor_s and not self.is_phase_done()

    # ── transitions: media ───────────────────────────────────────────────

    def media_intro_dispatched(self, now_s: float) -> None:
        """The framing turn ('here's the image/video/audio...') was just
        spoken. Images need no wait; video/audio move to AWAIT_MEDIA_ACK."""
        if self.stage is not ScenarioStage.AWAIT_MEDIA_INTRO:
            return
        item = self.current_item()
        if item is None:
            return
        if item.media.kind == "image":
            self.stage = ScenarioStage.READY_TO_ASK
        else:
            self.stage = ScenarioStage.AWAIT_MEDIA_ACK
            self._media_dispatched_at_s = now_s

    def media_ack(self, kind: MediaAckKind) -> None:
        """Client reported the media finished / errored / was skipped, OR
        the bounded wait expired (caller passes "ended" for a timeout too —
        we can't know whether the candidate actually watched it, but we must
        not block the interview any longer)."""
        rec = self.current_record()
        if rec is not None:
            rec.media_ack = kind
        if kind == "error":
            self._finish_item("skipped_media_error", [])
            return
        if self.stage is ScenarioStage.AWAIT_MEDIA_ACK:
            self.stage = ScenarioStage.READY_TO_ASK

    # ── transitions: question / answer ──────────────────────────────────

    def question_dispatched(self, rephrased_text: str) -> None:
        rec = self.current_record()
        if rec is not None and not rec.question_asked:
            rec.question_asked = rephrased_text
        if self.stage in (ScenarioStage.READY_TO_ASK, ScenarioStage.ASK_FOLLOWUP):
            self.stage = ScenarioStage.AWAIT_ANSWER

    def followup_dispatched(self, text: str) -> None:
        rec = self.current_record()
        if rec is not None:
            rec.followups_asked.append(text)
        self.stage = ScenarioStage.AWAIT_ANSWER

    def record_answer(self, text: str, effective_intent: str, missing_tags: list[str]) -> dict:
        """The verifier's (possibly Director-promoted) verdict for the
        candidate's latest reply. Returns {"item_done": bool, "record": dict}
        so the caller can emit the right events without reaching into
        private state."""
        item = self.current_item()
        rec = self.current_record()
        good_enough = effective_intent in GOOD_ENOUGH_INTENTS
        if rec is not None:
            rec.attempts.append(Attempt(text=text, good_enough=good_enough, missing_tags=list(missing_tags)))
        cap = item.max_followups if item is not None else self.max_followups_default
        if good_enough or self.followups_used >= cap:
            outcome = "good_enough" if good_enough else "followups_exhausted"
            self._finish_item(outcome, missing_tags if not good_enough else [])
            return {"item_done": True, "record": rec.to_dict() if rec else None}
        self.followups_used += 1
        self.stage = ScenarioStage.ASK_FOLLOWUP
        return {"item_done": False, "record": rec.to_dict() if rec else None}

    def request_skip(self) -> bool:
        """Candidate said "I don't know" / asked to skip. Returns True if the
        skip is GRANTED now; False on the first ask (one gentle nudge)."""
        if not self._skip_nudged:
            self._skip_nudged = True
            return False
        self._finish_item("skipped_by_candidate", [])
        return True

    def time_up(self, now_s: float = 0.0) -> None:
        """The phase's wall-clock budget is essentially exhausted. Wrap the
        CURRENT item (if any is still open) and mark every unreached item
        `not_reached`, then end the phase — mirrors how pool exhaustion ends
        a phase immediately rather than waiting for the clock to also expire."""
        if not self.is_phase_done():
            self._finish_item("skipped_time_budget", [], now_s=now_s)
        for i in range(self.index, len(self.items)):
            if i >= len(self.records):
                self._open_record(i, now_s)
            self.records[i].outcome = "not_reached"
            self.records[i].ended_at_s = now_s
        self.stage = ScenarioStage.PHASE_DONE

    def _finish_item(self, outcome: ItemOutcome, missing_tags: list[str], now_s: float = 0.0) -> None:
        item = self.current_item()
        rec = self.current_record()
        if rec is not None:
            rec.outcome = outcome
            rec.ended_at_s = now_s
            rec.tags_missing = list(missing_tags)
            all_tags = item.coverage_tags if item is not None else []
            rec.tags_covered = [t for t in all_tags if t not in missing_tags]
        self.index += 1
        self._skip_nudged = False
        self.followups_used = 0
        self._media_dispatched_at_s = None
        if self.index >= len(self.items):
            self.stage = ScenarioStage.PHASE_DONE
        else:
            self._open_record(self.index, now_s)
            self.stage = ScenarioStage.AWAIT_MEDIA_INTRO

    # ── the "machine-readable action" Director consumes each tick ────────

    def next_action(self) -> dict:
        if self.is_phase_done():
            return {"action": "end_phase"}
        item = self.current_item()
        if self.stage is ScenarioStage.AWAIT_MEDIA_INTRO:
            return {"action": "show_media", "item": item}
        if self.stage is ScenarioStage.AWAIT_MEDIA_ACK:
            return {"action": "await_media", "item": item}
        if self.stage in (ScenarioStage.READY_TO_ASK,):
            return {"action": "ask_question", "item": item}
        if self.stage is ScenarioStage.ASK_FOLLOWUP:
            missing = (self.current_record().attempts[-1].missing_tags
                       if self.current_record() and self.current_record().attempts else [])
            return {"action": "ask_followup", "item": item, "missing_tags": missing}
        if self.stage is ScenarioStage.AWAIT_ANSWER:
            return {"action": "await_answer", "item": item}
        return {"action": "noop"}

    # ── serialization (for a future durable-resume extension; unused by the
    #    voice runtime today — see the module docstring in cadence_tracker.py
    #    on how coding/scenario resume restarts the phase, matching precedent) ──

    def to_dict(self) -> dict:
        return {
            "phase_id": self.phase_id,
            "index": self.index,
            "stage": self.stage.value,
            "followups_used": self.followups_used,
            "records": [r.to_dict() for r in self.records],
        }
