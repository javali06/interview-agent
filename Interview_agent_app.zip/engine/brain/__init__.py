"""Stream B v2 — agentic interviewer.

The full design and rationale live in ../NEW_STREAM_B.md. The short version:

* `runtime.InterviewSession` is the only thing `orchestrator_new` imports.
* Inside, a `Director` ticks every 500ms, asks the `TurnTakingPolicy` what to
  do, and delegates to sub-agents via tool calls.
* The `LatencyOrchestrator` arbitrates fast-LLM filler / slow-LLM substance /
  canned apology so the candidate hears something within ~1s of finishing
  speaking.
* Conversation history sent to the LLM is **tag-rich** — `<barged_in/>`,
  `<filler text=.../>`, `<silence_ms=.../>` etc. — so the LLM has explicit
  signals about what just happened in the audio world.
"""
__version__ = "0.1.0"
