"""Stream A wire format helpers.

Inbound (mic → STT/VAD): 8-byte header + PCM16. Mirrors v1's
`orchestrator/audio_pump.py::encode_audio_frame`.

Outbound (TTS → us): 6-byte header + PCM16. Same constant as v1's
`orchestrator/stream_a_bridge._TTS_OUT_HEADER`.
"""
from __future__ import annotations

import struct

from engine.brain.contracts.audio import SAMPLE_RATE_HZ  # noqa: F401  (re-export)

PARTICIPANT_CANDIDATE = 1

# Inbound mic frame: <I (ts_ms u32 LE) H (participant_id u16) H (sample_count u16)>
_AUDIO_IN_HEADER = struct.Struct("<IHH")

# Outbound TTS frame: <I (ts_ms u32 LE) H (sample_count u16)>
_TTS_OUT_HEADER = struct.Struct("<IH")
TTS_OUT_HEADER_BYTES = _TTS_OUT_HEADER.size  # 6


def encode_audio_frame(ts_ms: int, pcm_bytes: bytes) -> bytes:
    """Frame a 20ms PCM16 chunk for sending to STT/VAD WS."""
    sample_count = len(pcm_bytes) // 2
    return _AUDIO_IN_HEADER.pack(ts_ms, PARTICIPANT_CANDIDATE, sample_count) + pcm_bytes


def strip_tts_header(raw: bytes) -> bytes:
    """Strip Stream A's 6-byte TTS header → raw PCM16 LE bytes."""
    if len(raw) <= TTS_OUT_HEADER_BYTES:
        return b""
    return raw[TTS_OUT_HEADER_BYTES:]
