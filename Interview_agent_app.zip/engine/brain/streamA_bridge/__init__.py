"""Thin WebSocket clients for Stream A's STT, VAD, and TTS services.

Each client owns its own connection AND a parallel reader task — the
upstream fix the v1 README §5a explicitly calls for. No more out-of-band
`_drain_tts` patch in the orchestrator.
"""
from engine.brain.streamA_bridge.aec_processor import AECProcessor
from engine.brain.streamA_bridge.groq_stt_client import GroqSTTClient
from engine.brain.streamA_bridge.stt_client import STTClient
from engine.brain.streamA_bridge.tts_client import TTSClient
from engine.brain.streamA_bridge.vad_client import VADClient

__all__ = ["STTClient", "GroqSTTClient", "VADClient", "TTSClient", "AECProcessor"]
