"""Stream A STT WebSocket client.

Owns its connection. Runs a parallel reader that pushes
partial / final messages to a callback.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Awaitable, Callable

import websockets

from engine.brain.streamA_bridge._wire import encode_audio_frame

logger = logging.getLogger(__name__)


PartialCb = Callable[[str, list[dict], int], Awaitable[None]]
FinalCb = Callable[[str, list[dict], int, float, str], Awaitable[None]]
"""(text, words, end_ms, confidence, utterance_id)"""


class STTClient:
    def __init__(
        self,
        url: str,
        *,
        on_partial: PartialCb | None = None,
        on_final: FinalCb | None = None,
    ) -> None:
        self._url = url
        self._on_partial = on_partial
        self._on_final = on_final
        self._ws: websockets.ClientConnection | None = None
        self._reader_task: asyncio.Task | None = None
        self._closed = asyncio.Event()

    async def connect(self) -> None:
        self._ws = await websockets.connect(
            self._url,
            ping_interval=60,            # bumped from 20s — Kokoro/Whisper warmup spikes
            ping_timeout=60,
            max_size=8 * 1024 * 1024,
        )
        self._reader_task = asyncio.create_task(self._read_loop(), name="stt-reader")
        logger.info("STT connected: %s", self._url)

    async def send_audio_frame(self, ts_ms: int, pcm: bytes) -> None:
        if self._ws is None:
            return
        try:
            await self._ws.send(encode_audio_frame(ts_ms, pcm))
        except websockets.ConnectionClosed:
            self._closed.set()

    async def send_control(self, payload: dict[str, Any]) -> None:
        """Forward a JSON control message (e.g. forwarded VAD events)."""
        if self._ws is None:
            return
        try:
            await self._ws.send(json.dumps(payload))
        except websockets.ConnectionClosed:
            self._closed.set()

    async def close(self) -> None:
        if self._reader_task is not None:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except (asyncio.CancelledError, Exception):
                pass
        if self._ws is not None:
            try:
                await self._ws.close()
            except Exception:  # pragma: no cover
                pass
        self._closed.set()

    async def _read_loop(self) -> None:
        assert self._ws is not None
        try:
            async for raw in self._ws:
                if not isinstance(raw, str):
                    continue
                try:
                    evt = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                kind = evt.get("type")
                if kind == "partial":
                    if self._on_partial is not None:
                        try:
                            words = evt.get("words") or []
                            end_ms = int(words[-1].get("end_ms", 0)) if words else 0
                            await self._on_partial(evt.get("text", ""), words, end_ms)
                        except Exception as e:  # pragma: no cover
                            logger.warning("on_partial cb raised: %s", e)
                elif kind == "final":
                    if self._on_final is not None:
                        try:
                            words = evt.get("words") or []
                            end_ms = int(words[-1].get("end_ms", 0)) if words else 0
                            conf = _avg_confidence(words)
                            uid = evt.get("utterance_id") or ""
                            await self._on_final(
                                evt.get("text", ""), words, end_ms, conf, uid
                            )
                        except Exception as e:  # pragma: no cover
                            logger.warning("on_final cb raised: %s", e)
        except websockets.ConnectionClosed:
            pass
        finally:
            self._closed.set()


def _avg_confidence(words: list[dict]) -> float:
    if not words:
        return 1.0
    confs = [float(w.get("conf", 1.0)) for w in words]
    return sum(confs) / len(confs)
