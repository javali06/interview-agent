"""Server-side acoustic echo cancellation (Exp #2).

WHAT THIS DOES (plain English)
------------------------------
The audio interview agent has two microphones in conflict:
  - The candidate's mic captures their voice.
  - The same mic also captures the AI's voice playing out of the speakers.

When the AI's voice leaks back into the mic, the VAD treats it as candidate
speech (the "no-headphones loop" documented in Exp #0). Exp #1 sidestepped
this by hard-muting the VAD while the AI talks — but the cost was real
barge-in (the candidate can't interrupt the AI mid-sentence).

This module restores barge-in by removing the AI's voice from the captured
mic signal BEFORE it reaches VAD or STT. The trick: we have a reference
copy of exactly what the AI sent to the speakers (the TTS output frames),
and we can subtract that from the mic input using an adaptive filter. After
1-2 seconds of warming up, the filter learns the room's impulse response
(how the speakers' sound morphs on its way to the mic) and outputs
"approximately just the candidate's voice".

We use `livekit.rtc.AudioProcessingModule` — a Python wrapper around
Chromium's WebRTC AEC3 (the same algorithm every modern browser ships).
20-40 dB of cancellation, ~4 ms per block, 1-2 s convergence. Apache-2.0,
no LiveKit cloud account needed.

WIRING (from interview_session.py)
----------------------------------
  TTSClient PCM out  →  AECProcessor.feed_reference()  (every TTS frame)
       (also)        →  audio_sink.play()              (unchanged, plays speakers)

  MicAudioSource PCM →  AECProcessor.process_mic()  →  VADClient + STTClient

  Background task    →  AECProcessor.feed_silence_reference()  every 20 ms
                        when TTS idle, so the AEC filter stays warm and
                        converged for the moment the AI does start talking.

KEY CONSTRAINT
--------------
The underlying WebRTC AEC3 algorithm only accepts EXACTLY 10 ms frames
(160 samples @ 16 kHz). Stream B's pipeline runs on 20 ms frames (320
samples). So every Stream B frame is split into two contiguous 10 ms
halves before being handed to APM. No buffering is needed — each half is
self-contained, and the time alignment between the mic half and the
reference half is preserved because we feed both in lockstep.
"""
from __future__ import annotations

import logging
from typing import Optional

from livekit.rtc import AudioFrame, AudioProcessingModule

logger = logging.getLogger(__name__)

# Audio contract — must match stream_b_new.contracts.audio
SAMPLE_RATE_HZ = 16_000
NUM_CHANNELS = 1
# 20 ms frames (the Stream B contract) → 320 samples / 640 bytes PCM16.
STREAM_FRAME_SAMPLES = 320
STREAM_FRAME_BYTES = STREAM_FRAME_SAMPLES * 2
# WebRTC APM block size: EXACTLY 10 ms (160 samples / 320 bytes PCM16).
APM_BLOCK_SAMPLES = 160
APM_BLOCK_BYTES = APM_BLOCK_SAMPLES * 2

# Pre-baked silence frame: 320 samples of zero PCM16 = 640 zero bytes.
# Used to keep the AEC filter warm while TTS is idle.
_SILENCE_20MS = bytes(STREAM_FRAME_BYTES)


class AECProcessor:
    """Wraps livekit.rtc.AudioProcessingModule for our 20 ms PCM16 pipeline.

    Public surface:
        AECProcessor(stream_delay_ms=50, noise_suppression=True,
                     high_pass_filter=True)
        processor.feed_reference(pcm_20ms_bytes)
        processor.feed_silence_reference()         # convenience for idle ticks
        processor.process_mic(pcm_20ms_bytes) -> pcm_20ms_bytes_cleaned

    Thread safety: the underlying APM is not documented as thread-safe.
    Construct + use it from a single asyncio task. The methods here are
    sync but cheap (~4 ms total per frame); call them from the audio
    callbacks that already run on the asyncio loop.
    """

    def __init__(
        self,
        *,
        stream_delay_ms: int = 50,
        noise_suppression: bool = True,
        high_pass_filter: bool = True,
        auto_gain_control: bool = False,
    ) -> None:
        """Create the underlying APM and configure the echo delay estimate.

        Args:
            stream_delay_ms: Approximate round-trip latency from the moment
                a TTS frame is enqueued for playback to the moment its
                acoustic echo arrives at the mic. 50 ms is a sane default
                for a single-machine MacBook with sounddevice. The AEC3
                filter is 100-300 ms long so ±50 ms misalignment is
                tolerated; only re-tune if measured ERLE is poor.
            noise_suppression: Run NS in addition to AEC. Cheap and helps
                Whisper transcribe noisy environments.
            high_pass_filter: Strip <80 Hz rumble. Cheap; helps everywhere.
            auto_gain_control: Off by default. Whisper handles level
                variation natively, and AGC adds gain pumping on the
                residual TTS that hurts perceived audio quality.
        """
        self._apm = AudioProcessingModule(
            echo_cancellation=True,
            noise_suppression=noise_suppression,
            high_pass_filter=high_pass_filter,
            auto_gain_control=auto_gain_control,
        )
        self._apm.set_stream_delay_ms(stream_delay_ms)
        self._stream_delay_ms = stream_delay_ms
        # Telemetry: number of frames processed since construction.
        self._mic_frames_processed: int = 0
        self._ref_frames_processed: int = 0
        self._silence_ref_frames: int = 0
        logger.info(
            "[AEC] processor ready: sample_rate=%dHz channels=%d "
            "stream_delay_ms=%d NS=%s HPF=%s AGC=%s",
            SAMPLE_RATE_HZ, NUM_CHANNELS, stream_delay_ms,
            noise_suppression, high_pass_filter, auto_gain_control,
        )

    def feed_reference(self, pcm_20ms: bytes) -> None:
        """Feed one 20 ms TTS reference frame into the AEC's reverse stream.

        Call this from the TTS PCM callback path — the SAME path that
        also feeds audio_sink.play(). The AEC needs to know what was sent
        to the speakers BEFORE the corresponding mic frame is processed.

        Splits the 20 ms frame into two 10 ms halves and feeds each to APM
        (which requires exactly 10 ms blocks).
        """
        if len(pcm_20ms) != STREAM_FRAME_BYTES:
            logger.warning(
                "[AEC] feed_reference got %d bytes, expected %d "
                "(20 ms PCM16). Dropping frame.",
                len(pcm_20ms), STREAM_FRAME_BYTES,
            )
            return
        for off in (0, APM_BLOCK_BYTES):
            block = pcm_20ms[off : off + APM_BLOCK_BYTES]
            frame = AudioFrame(
                data=block,
                sample_rate=SAMPLE_RATE_HZ,
                num_channels=NUM_CHANNELS,
                samples_per_channel=APM_BLOCK_SAMPLES,
            )
            self._apm.process_reverse_stream(frame)
        self._ref_frames_processed += 1

    def feed_silence_reference(self) -> None:
        """Feed a 20 ms silence frame to the reverse stream.

        Call this from a periodic background task whenever TTS is idle.
        Keeps the AEC's adaptive filter converged so it's ready the
        instant the AI does start talking. Without this, every new TTS
        turn would start with 1-2 s of unconverged filter and the first
        words leak through to the mic.
        """
        self.feed_reference(_SILENCE_20MS)
        self._silence_ref_frames += 1

    def process_mic(self, pcm_20ms: bytes) -> bytes:
        """Run the captured mic frame through AEC and return cleaned PCM.

        Splits into two 10 ms halves, processes each, and concatenates the
        cleaned output. APM mutates the frame data in place; we read it
        back out and rebuild a 20 ms blob.

        Returns the same 20 ms frame on shape mismatch (defensive — keeps
        the audio pipeline flowing even if a stray malformed frame hits
        us, at the cost of one unprocessed frame).
        """
        if len(pcm_20ms) != STREAM_FRAME_BYTES:
            logger.warning(
                "[AEC] process_mic got %d bytes, expected %d "
                "(20 ms PCM16). Passing through unprocessed.",
                len(pcm_20ms), STREAM_FRAME_BYTES,
            )
            return pcm_20ms
        out = bytearray()
        for off in (0, APM_BLOCK_BYTES):
            block = pcm_20ms[off : off + APM_BLOCK_BYTES]
            frame = AudioFrame(
                data=block,
                sample_rate=SAMPLE_RATE_HZ,
                num_channels=NUM_CHANNELS,
                samples_per_channel=APM_BLOCK_SAMPLES,
            )
            self._apm.process_stream(frame)  # mutates frame.data in-place
            out += bytes(frame.data)
        self._mic_frames_processed += 1
        return bytes(out)

    def stats(self) -> dict:
        """Return a snapshot for end-of-session debugging."""
        return {
            "stream_delay_ms": self._stream_delay_ms,
            "mic_frames_processed": self._mic_frames_processed,
            "ref_frames_processed": self._ref_frames_processed,
            "silence_ref_frames": self._silence_ref_frames,
        }
