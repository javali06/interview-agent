"""Azure Cognitive Services STT — drop-in replacement for STTClient / GroqSTTClient.

Same public surface as GroqSTTClient so callers in
`stream_b_new/runtime/interview_session.py` don't change:

  - connect() / close()
  - send_audio_frame(ts_ms, pcm)
  - send_control(payload)        # speech_start / speech_end / endpoint_detected
  - on_partial / on_final callbacks

Unlike Groq (REST, buffer-then-POST) and unlike v1's Stream A WS service,
Azure's SDK gives us **true streaming recognition**: we hand it a
`PushAudioInputStream` and it fires `recognizing` (partial) and
`recognized` (final) events as the candidate speaks. Endpointing is
Azure-side — Stream B's VAD `endpoint_detected` becomes a no-op (logged
only) because the SDK already segments utterances itself.

Architectural notes worth re-reading before changing this file:

  1. **Threading bridge.** The Azure Python SDK invokes our event
     handlers (`recognizing`, `recognized`, `canceled`, `session_*`) on
     **worker threads it owns**. Touching asyncio primitives from those
     threads will deadlock or corrupt the loop. We capture
     `self._loop = asyncio.get_running_loop()` once in connect(), then
     use `self._loop.call_soon_threadsafe(...)` to schedule the actual
     callback dispatch back onto the asyncio loop. The `on_partial` /
     `on_final` user callbacks are async, so we wrap them in
     `asyncio.create_task` after the threadsafe hop.

  2. **Continuous recognition auto-stop.** Azure's continuous-mode
     `SpeechRecognizer` is documented to terminate the session after
     ~10-30 min of activity. The candidate may go quiet for that long
     between LLM responses on a slow interview. We bind
     `session_stopped` and, if `self._connected` is still True (i.e. the
     user didn't call close()), we transparently restart the recognizer
     so the candidate doesn't end up mic-deaf.

  3. **Push stream vs pull stream.** We use `PushAudioInputStream`
     (rather than a pull stream + buffered queue) because Stream B's
     audio pipeline already pushes 20ms frames via `send_audio_frame`.
     Push semantics map 1:1: `push_stream.write(pcm)` is fire-and-forget
     and the SDK pulls bytes off internally on its own thread.

  4. **Word-level timings.** Set `request_word_level_timestamps()` so
     `recognized.result.json` contains an `NBest` array with `Words`,
     each with an `Offset` and `Duration` in 100-nanosecond ticks. We
     convert to ms and emit the same `[{"w", "start_ms", "end_ms",
     "conf"}, ...]` shape the rest of Stream B expects.

  5. **Confidence.** `NBest[0]["Confidence"]` is Azure's per-utterance
     confidence (0.0-1.0). If absent (e.g. detailed-output is off,
     defensive), fall back to 1.0 to keep downstream `confidence`-gated
     checks behaving the same as GroqSTTClient's "no per-segment data"
     path.

  6. **Auth.** Subscription key + region. No token refresh, no AAD.

Reference: https://learn.microsoft.com/en-us/azure/ai-services/speech-service/get-started-speech-to-text
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from typing import Any, Awaitable, Callable

import azure.cognitiveservices.speech as speechsdk

from engine.brain.observability.langfuse_client import observe_stt
from engine.brain.observability.timing import log_timing

logger = logging.getLogger(__name__)


PartialCb = Callable[[str, str], Awaitable[None]]
FinalCb = Callable[[str, list[dict], int, float, str], Awaitable[None]]


# Azure reports offsets in 100-nanosecond "ticks" (the .NET DateTime tick).
# 1 ms = 10,000 ticks. Conversion is integer division to keep ms an int.
_TICKS_PER_MS = 10_000


class AzureSTTClient:
    """Azure-backed STT with the same surface as GroqSTTClient.

    The signature mirrors GroqSTTClient exactly so the caller can swap
    by name. Two extras at the tail (`region`, `voice`) are
    Azure-specific. `voice` is irrelevant for STT and is silently
    ignored — it's accepted only so the same factory site that builds
    `AzureTTSClient(voice=...)` can pass through cleanly.
    """

    def __init__(
        self,
        *,
        api_key: str,
        model: str = "azure-default",
        language: str = "en-US",
        base_url: str = "",                  # accepted for API compat; ignored
        sample_rate: int = 16_000,
        on_partial: PartialCb | None = None,
        on_final: FinalCb | None = None,
        client: Any | None = None,           # accepted for API compat; ignored
        no_speech_threshold: float = 0.6,    # accepted for API compat; unused (director does noise rejection)
        min_utterance_ms: int = 0,           # accepted for API compat; unused
        preroll_ms: int = 50,                # audio (ms) prepended at speech_start so VAD-hysteresis head isn't clipped
        # Azure-specific extras —
        region: str = "eastus",
        voice: str | None = None,            # irrelevant for STT; ignored
        # Langfuse session_id — when set, each recognized utterance opens a
        # generation observation tagged with this session. None disables.
        langfuse_session_id: str | None = None,
        # Langfuse user_id — candidate name. Tags every trace so the
        # Langfuse "Users" tab can list past sessions for a candidate.
        langfuse_user_id: str | None = None,
    ) -> None:
        self._api_key = api_key
        # Non-secret id for THIS Azure Speech key — sha256(secret)[:8], the SAME
        # scheme speech_pool._key_id uses, so a throttle counted here lines up on
        # the same key_id as the admission counter + interview_speech_inflight
        # gauge on the dashboard. Never logs the secret.
        self._key_id = hashlib.sha256((api_key or "").encode()).hexdigest()[:8]
        self._region = region
        self._langfuse_session_id = langfuse_session_id
        self._langfuse_user_id = langfuse_user_id
        # Azure language codes use the BCP-47 form ("en-US"). If a caller
        # passes Groq's short form ("en") we normalise to a sensible
        # default so a single config flip doesn't require touching every
        # call-site.
        self._language = language if "-" in language else f"{language}-US"
        self._sample_rate = sample_rate
        self._on_partial = on_partial
        self._on_final = on_final
        # `voice` is accepted for symmetry with AzureTTSClient — not used.
        _ = voice

        # SDK objects — created in connect() so we can capture the
        # asyncio loop at the same time.
        self._speech_config: speechsdk.SpeechConfig | None = None
        self._push_stream: speechsdk.audio.PushAudioInputStream | None = None
        self._recognizer: speechsdk.SpeechRecognizer | None = None

        # Loop the SDK callbacks must marshal onto. Captured in connect().
        self._loop: asyncio.AbstractEventLoop | None = None

        # Utterance ID counter. Mirrors GroqSTTClient's `groq-stt-<n>`
        # pattern so downstream tooling that greps utterance IDs stays
        # readable.
        self._utterance_seq = 0

        # Lifecycle flags. `_connected` is True between connect() and
        # close(); used by the session_stopped handler to decide whether
        # to restart the recognizer (Azure's 10-30min auto-stop bug) or
        # leave it stopped because the user explicitly tore down.
        self._connected = False
        # `_restart_in_progress` prevents recursive restart attempts if
        # session_stopped fires repeatedly during teardown.
        self._restart_in_progress = False

        # ── VAD gating (mirror GroqSTTClient) ─────────────────────────────
        # Azure used to run open-mic: EVERY mic frame was written to the push
        # stream and Azure did its own endpointing. We now gate writes on
        # Stream B's VAD so Azure only ever sees speech-window audio — fewer
        # noise-driven partials, and no recognition churning during silence.
        # Unlike Groq (buffer-then-POST per utterance), we KEEP the continuous
        # recognizer running; we simply WITHHOLD bytes outside the speech
        # window so the recognizer sees a clean speech stream.
        #   - _buffer_active: True between speech_start and endpoint_detected.
        #   - _preroll: ring of the most recent `preroll_ms` of audio, flushed
        #     into the stream at speech_start so the head-of-utterance the VAD
        #     hysteresis clipped is recovered.
        self._buffer_active = False
        self._preroll_ms = preroll_ms
        # PCM16 = 2 bytes/sample. Byte cap for `preroll_ms` of audio.
        self._preroll_max_bytes = preroll_ms * sample_rate * 2 // 1000
        self._preroll = bytearray()

    # ── lifecycle ─────────────────────────────────────────────────────

    async def connect(self) -> None:
        """Build the SpeechConfig + PushAudioInputStream + SpeechRecognizer
        and kick off continuous recognition. Idempotent."""
        if self._connected:
            return
        self._loop = asyncio.get_running_loop()
        self._build_recognizer()
        # `start_continuous_recognition()` is non-blocking — the SDK
        # spawns its own worker thread to pump audio and dispatch
        # events. No need for run_in_executor.
        assert self._recognizer is not None
        self._recognizer.start_continuous_recognition()
        self._connected = True
        logger.info(
            "Azure STT ready (region=%s lang=%s sr=%d)",
            self._region, self._language, self._sample_rate,
        )

    def _build_recognizer(self) -> None:
        """Construct a fresh SpeechRecognizer. Called from connect() and
        from the session_stopped auto-restart path."""
        self._speech_config = speechsdk.SpeechConfig(
            subscription=self._api_key, region=self._region,
        )
        self._speech_config.speech_recognition_language = self._language
        # Detailed output gives us NBest + per-word timings + confidence.
        self._speech_config.output_format = speechsdk.OutputFormat.Detailed
        # Enable word-level offsets in the JSON result. Without this,
        # `NBest[0]["Words"]` is absent.
        self._speech_config.request_word_level_timestamps()

        # ── End-of-utterance silence timeouts ─────────────────────────
        # Without these, the SDK's internal defaults vary by region /
        # SDK version and have been observed (trace 50c47400 / 2026-06-01)
        # to never fire `recognized` for long monologues — the system
        # then stalls in Rule 2 (`wait for STT`) and runs the STT-wait
        # filler ladder forever. Setting both properties forces Azure to
        # finalize an utterance after EndSilence ms of trailing silence
        # and to split mid-utterance after Segmentation ms.
        #
        # Segmentation + end-silence both default to 1000ms. Azure resets
        # its partial after ~1000ms of silence (often without a usable
        # `recognized`); the Director recovers each segment by detecting
        # the partial-collapse and joins them at the VAD endpoint. Override
        # via App Settings without a rebuild: AZURE_STT_END_SILENCE_MS /
        # AZURE_STT_SEGMENTATION_SILENCE_MS.
        import os as _os
        end_silence_ms = _os.environ.get("AZURE_STT_END_SILENCE_MS", "1000")
        seg_silence_ms = _os.environ.get(
            "AZURE_STT_SEGMENTATION_SILENCE_MS", "1000",
        )
        try:
            self._speech_config.set_property(
                speechsdk.PropertyId.SpeechServiceConnection_EndSilenceTimeoutMs,
                str(end_silence_ms),
            )
            self._speech_config.set_property(
                speechsdk.PropertyId.Speech_SegmentationSilenceTimeoutMs,
                str(seg_silence_ms),
            )
            logger.info(
                "[STT] Azure silence tuning: end=%sms segmentation=%sms",
                end_silence_ms, seg_silence_ms,
            )
        except Exception as e:  # pragma: no cover
            # Older Speech SDKs may not expose these property ids — fall
            # back to defaults rather than crash. Log so it's diagnosable.
            logger.warning("[STT] silence-timeout properties not applied: %s", e)

        # Fresh recognizer → fresh gating state. A restart (Azure's 10-30min
        # auto-stop) must not leave us "mid-utterance" writing to the new push
        # stream; wait for the next speech_start to re-open the window.
        self._buffer_active = False
        self._preroll = bytearray()

        # Push stream — incoming PCM16 mono. The SDK pulls from this on
        # its own thread; we just write() into it from
        # `send_audio_frame`.
        audio_format = speechsdk.audio.AudioStreamFormat(
            samples_per_second=self._sample_rate,
            bits_per_sample=16,
            channels=1,
        )
        self._push_stream = speechsdk.audio.PushAudioInputStream(
            stream_format=audio_format,
        )
        audio_config = speechsdk.audio.AudioConfig(stream=self._push_stream)

        self._recognizer = speechsdk.SpeechRecognizer(
            speech_config=self._speech_config,
            audio_config=audio_config,
        )

        # Bind event handlers. All callbacks run on SDK worker threads —
        # never touch asyncio directly inside them, always marshal via
        # `self._loop.call_soon_threadsafe(...)`.
        self._recognizer.recognizing.connect(self._on_recognizing)
        self._recognizer.recognized.connect(self._on_recognized)
        self._recognizer.canceled.connect(self._on_canceled)
        self._recognizer.session_started.connect(self._on_session_started)
        self._recognizer.session_stopped.connect(self._on_session_stopped)

    async def close(self) -> None:
        """Stop continuous recognition + close the push stream. Idempotent."""
        self._connected = False
        if self._recognizer is not None:
            try:
                # `stop_continuous_recognition()` is blocking-ish (waits
                # for the worker to acknowledge); offload so we don't
                # stall the event loop.
                assert self._loop is not None
                await self._loop.run_in_executor(
                    None, self._recognizer.stop_continuous_recognition,
                )
            except Exception as e:
                logger.warning("[STT] stop_continuous_recognition failed: %s", e)
        if self._push_stream is not None:
            try:
                self._push_stream.close()
            except Exception as e:
                logger.warning("[STT] push_stream.close failed: %s", e)
        self._recognizer = None
        self._push_stream = None
        self._speech_config = None

    # ── data + control plane ──────────────────────────────────────────

    async def send_audio_frame(self, ts_ms: int, pcm: bytes) -> None:
        """Feed mic PCM into the pre-roll ring, and (only while the VAD speech
        window is open) into the SDK's push stream.

        VAD-gated: outside the speech window we withhold bytes from Azure so it
        never recognizes silence/noise — the pre-roll ring keeps the most recent
        `preroll_ms` so the head-of-utterance clipped by VAD hysteresis is
        recovered at speech_start. `ts_ms` is accepted for API compatibility but
        not used; Azure assigns its own offsets relative to fed-audio time.
        """
        if not pcm:
            return
        # Maintain the pre-roll ring. Guard preroll_max_bytes == 0 — the slice
        # `self._preroll[-0:]` is the WHOLE array, so it would grow unbounded
        # and seed each utterance with the entire session history.
        if self._preroll_max_bytes > 0:
            self._preroll.extend(pcm)
            if len(self._preroll) > self._preroll_max_bytes:
                self._preroll = self._preroll[-self._preroll_max_bytes:]
        if self._push_stream is None or not self._buffer_active:
            return
        try:
            self._push_stream.write(pcm)
        except Exception as e:
            # Defensive: if the SDK objects to a write (e.g. after a
            # session_stopped that hasn't yet been auto-restarted), don't
            # let it kill the audio-pump task in the caller.
            logger.warning("[STT] push_stream.write failed: %s", e)

    async def send_control(self, payload: dict[str, Any]) -> None:
        """Gate the push stream on Stream B's VAD (mirror GroqSTTClient):

          speech_start      → flush pre-roll into the stream, open the window
          speech_end        → keep the window open (mid-utterance pause)
          endpoint_detected → close the window (stop feeding Azure)

        The continuous recognizer stays running throughout — we only control
        WHICH audio it sees. Azure still does its own sub-utterance
        segmentation on the speech-window audio; the director joins the
        partials at the VAD endpoint (Azure's own `recognized` may lag the
        endpoint slightly since we stop feeding trailing silence — tolerated,
        the director commits the open segment at the endpoint).
        """
        kind = payload.get("type")
        if kind == "speech_start":
            if not self._buffer_active:
                # Seed the stream with the pre-roll so the head-of-utterance
                # that arrived BEFORE VAD registered speech (hysteresis + hop)
                # isn't clipped.
                seeded = 0
                if self._push_stream is not None and self._preroll:
                    try:
                        self._push_stream.write(bytes(self._preroll))
                        seeded = len(self._preroll) * 1000 // (self._sample_rate * 2)
                    except Exception as e:
                        logger.warning("[STT] pre-roll write failed: %s", e)
                self._buffer_active = True
                logger.info(
                    "[STT] VAD speech_start — opening Azure window "
                    "(seeded %dms pre-roll)", seeded,
                )
        elif kind == "speech_end":
            logger.debug("[STT] VAD speech_end (mid-utterance pause — window stays open)")
        elif kind == "endpoint_detected":
            if self._buffer_active:
                self._buffer_active = False
                logger.info("[STT] VAD endpoint_detected — closing Azure window")

    # ── SDK callbacks (worker threads — marshal to loop) ──────────────
    #
    # Every handler below runs on an Azure-owned worker thread. The only
    # thing we may do safely is call `self._loop.call_soon_threadsafe(...)`
    # to schedule a coroutine onto the asyncio loop. Anything else risks
    # hangs or undefined behaviour.

    def _on_recognizing(self, evt: Any) -> None:
        """Partial result (mid-utterance). Fires repeatedly as Azure
        revises its best guess."""
        text = (evt.result.text or "").strip()
        if not text or self._on_partial is None or self._loop is None:
            return
        # Use the current utterance counter; Azure doesn't expose a
        # stable per-utterance ID until `recognized` fires, so we issue
        # our own — same scheme as GroqSTTClient. (Not passed to the
        # downstream callback — InterviewSession's _on_stt_partial
        # signature is `(text, words, end_ms)` with no utterance_id.)
        # Azure ticks are 100ns; convert offset+duration to ms. `offset` is
        # the START of the CURRENT phrase Azure is recognizing — it stays
        # ~stable across the recognizing chain of one segment and JUMPS
        # forward (by the silence gap) when Azure starts the next segment.
        # The Director uses that offset jump to detect segment boundaries
        # (Azure doesn't reliably fire `recognized` for each one).
        try:
            start_ms = int(evt.result.offset) // 10_000
            end_ms = (int(evt.result.offset) + int(evt.result.duration)) // 10_000
        except Exception:
            start_ms = 0
            end_ms = 0
        # Partials carry no word-level timings (Azure only emits those on
        # `recognized`). Pass an empty list — the director treats partials
        # as text-only signals anyway.
        self._loop.call_soon_threadsafe(
            self._dispatch_partial, text, [], end_ms, start_ms,
        )

    def _on_recognized(self, evt: Any) -> None:
        """Final result (end of an utterance, Azure-side endpoint)."""
        if self._loop is None:
            return
        # Azure surfaces a `result.reason`; only `RecognizedSpeech` carries
        # text. `NoMatch` (silence/garbage) we still surface as empty text
        # so the director clears `candidate_spoke_since_last_ai`, matching
        # GroqSTTClient's "drop noise → empty on_final" contract.
        try:
            reason = evt.result.reason
            text = (evt.result.text or "").strip()
        except Exception as e:
            logger.warning("[STT] recognized handler: result read failed: %s", e)
            return

        # Increment the utterance counter on every recognized event,
        # whether or not text is present, so each utterance gets a unique
        # ID and the partials → final mapping stays consistent.
        self._utterance_seq += 1
        uid = f"azure-stt-{self._utterance_seq}"

        if reason == speechsdk.ResultReason.NoMatch:
            logger.info("[STT] no-match (silence/noise) — emitting empty final %s", uid)
            self._loop.call_soon_threadsafe(
                self._dispatch_final, "", [], 0, 1.0, uid,
            )
            return
        if reason != speechsdk.ResultReason.RecognizedSpeech:
            # Other reasons (TranslatedSpeech, etc.) shouldn't appear in
            # this single-language config; log and skip.
            logger.debug("[STT] recognized non-speech reason=%s — ignoring", reason)
            return

        words, end_ms, conf = self._parse_detailed_result(evt)
        # Extract the recognized utterance's DURATION (not its end
        # timestamp). Azure's `evt.result.duration` is in 100ns ticks;
        # convert to ms. This is what Azure bills against — using
        # `end_ms` (absolute session position) was a major bug that
        # multiplied STT cost by ~N per session, since each successive
        # final's end_ms is bigger than the last.
        try:
            duration_ms = int(evt.result.duration) // _TICKS_PER_MS
        except Exception:
            duration_ms = 0
        # Fallback when Azure doesn't populate `duration` (observed as 0 in
        # some Detailed-output responses → STT cost showed $0 in Langfuse /
        # the dashboard). Estimate from word-level timings if present
        # (last word end − first word start), else from a rough speech rate
        # (~3 words/sec). Keeps STT cost from collapsing to zero.
        if duration_ms <= 0:
            if words:
                try:
                    first_start = int(words[0].get("start_ms", 0))
                    last_end = int(words[-1].get("end_ms", 0))
                    duration_ms = max(0, last_end - first_start)
                except Exception:
                    duration_ms = 0
            if duration_ms <= 0 and text:
                # ~3 words/sec ≈ 333ms/word.
                duration_ms = max(1, len(text.split())) * 333
        log_timing(
            logger, "STT", "final", None,
            uid=uid,
            text=repr(text[:60]),
            conf=f"{conf:.2f}",
            words=len(words),
            duration_ms=duration_ms,
        )
        self._loop.call_soon_threadsafe(
            self._dispatch_final, text, words, end_ms, conf, uid, duration_ms,
        )

    def _on_canceled(self, evt: Any) -> None:
        """Recognition was cancelled. Could be a real error (network,
        auth) or just session_stopped on close()."""
        try:
            reason = evt.reason
            details = evt.error_details
        except Exception:
            reason = "unknown"
            details = ""
        logger.warning(
            "[STT] azure canceled: reason=%s details=%s",
            reason, details,
        )
        # Throttle attribution: a 429 (Azure CancellationErrorCode.TooManyRequests
        # or a quota message) surfaces here as a cancellation, NOT an exception.
        # Count it against this Speech key so the dashboard shows the STT ceiling.
        try:
            code = getattr(evt, "error_code", None)
            from engine.brain.observability import prom
            if prom.is_throttle_error(code) or prom.is_throttle_error(details):
                prom.note_throttle("stt", self._key_id)
        except Exception:
            pass

    def _on_session_started(self, evt: Any) -> None:
        logger.info("[STT] azure session_started session_id=%s", evt.session_id)

    def _on_session_stopped(self, evt: Any) -> None:
        """Azure auto-stops continuous recognition after ~10-30min. If
        the client is still meant to be connected, restart transparently.

        Runs on a worker thread — marshal the restart onto the asyncio
        loop so we can `await loop.run_in_executor(...)`.
        """
        logger.info("[STT] azure session_stopped session_id=%s", evt.session_id)
        if not self._connected or self._restart_in_progress or self._loop is None:
            return
        self._restart_in_progress = True
        self._loop.call_soon_threadsafe(
            lambda: asyncio.create_task(
                self._restart_recognizer(), name="azure-stt-restart",
            ),
        )

    async def _restart_recognizer(self) -> None:
        """Rebuild the recognizer after a session_stopped while still
        connected. Keeps the existing push stream's buffer; rebuilds the
        recognizer + push stream from scratch (Azure SDK doesn't expose
        a clean "resume" API)."""
        try:
            logger.info("[STT] restarting recognizer after session_stopped")
            # Don't reuse the old recognizer/push_stream; build fresh.
            if self._recognizer is not None:
                try:
                    assert self._loop is not None
                    await self._loop.run_in_executor(
                        None, self._recognizer.stop_continuous_recognition,
                    )
                except Exception:
                    pass
            if self._push_stream is not None:
                try:
                    self._push_stream.close()
                except Exception:
                    pass
            self._build_recognizer()
            assert self._recognizer is not None
            self._recognizer.start_continuous_recognition()
            logger.info("[STT] recognizer restarted")
        except Exception as e:
            logger.error("[STT] restart_recognizer failed: %s", e)
        finally:
            self._restart_in_progress = False

    # ── loop-side dispatch helpers (called via call_soon_threadsafe) ──

    def _dispatch_partial(
        self, text: str, words: list[dict], end_ms: int, start_ms: int = 0,
    ) -> None:
        """Schedule the async `on_partial` callback on the loop.

        `start_ms` is the phrase START offset (ms) — the Director uses an
        offset jump between partials to detect Azure segment boundaries.
        Passed as a 4th positional arg; InterviewSession._on_stt_partial
        accepts it (optional, defaults to 0 for STT backends that don't
        provide it, e.g. Groq / Stream A).
        """
        if self._on_partial is None:
            return
        try:
            asyncio.create_task(
                self._on_partial(text, words, end_ms, start_ms),
                name=f"azure-stt-partial-{end_ms}",
            )
        except Exception as e:
            logger.warning("[STT] failed to dispatch on_partial: %s", e)

    def _dispatch_final(
        self,
        text: str,
        words: list[dict],
        end_ms: int,
        conf: float,
        uid: str,
        duration_ms: int = 0,
    ) -> None:
        """Schedule the async `on_final` callback as a task on the loop.

        Also emit a Langfuse `stt.recognize` observation for this utterance
        (synchronous open+close; Azure already gave us all the data). Skips
        emission for empty-text NoMatch finals (they're noise/silence and
        would clutter the dashboard)."""
        # Langfuse — fire-and-forget. Done on the asyncio loop (we're
        # already there after call_soon_threadsafe), so OTel context vars
        # are valid. Errors must not break STT delivery.
        if (
            self._langfuse_session_id is not None
            and text  # skip silence/noise NoMatch events
        ):
            # COST IS NOT BOOKED HERE. Azure's `recognized` rarely fires in
            # this deployment, so this per-segment observation can't be the
            # source of truth for STT cost — it would leave STT at $0. The
            # Director now books the whole utterance's audio_ms on its single
            # `stt.final` observation at the VAD endpoint (see
            # director._finalize_utterance_at_endpoint). We still emit this
            # observation (audio_ms=None → no cost) so a `recognized` segment
            # remains visible in Langfuse as a transcript trace; booking cost
            # here too would double-count.
            audio_ms = None
            try:
                with observe_stt(
                    session_id=self._langfuse_session_id,
                    audio_ms=audio_ms,
                    user_id=self._langfuse_user_id,
                ) as lf_obs:
                    lf_obs.update(
                        output={"text": text,
                                "confidence": conf,
                                "words_count": len(words)},
                        metadata={"uid": uid,
                                  "language": self._language,
                                  "region": self._region},
                    )
            except Exception as e:  # pragma: no cover
                logger.debug("[STT] langfuse emit failed: %s", e)

        if self._on_final is None:
            return
        try:
            asyncio.create_task(
                self._on_final(text, words, end_ms, conf, uid),
                name=f"azure-stt-final-{uid}",
            )
        except Exception as e:
            logger.warning("[STT] failed to dispatch on_final: %s", e)

    # ── parse Azure detailed result ───────────────────────────────────

    def _parse_detailed_result(self, evt: Any) -> tuple[list[dict], int, float]:
        """Pull words + confidence + end_ms out of the recognizer event.

        Azure's detailed JSON (when `output_format=Detailed` +
        `request_word_level_timestamps()` are set) looks like:

            {
              "DisplayText": "Hello world.",
              "NBest": [{
                "Confidence": 0.94,
                "Lexical": "hello world",
                "ITN": "hello world",
                "MaskedITN": "hello world",
                "Display": "Hello world.",
                "Words": [
                  {"Word": "hello", "Offset": 1500000, "Duration": 3000000},
                  {"Word": "world", "Offset": 4600000, "Duration": 4000000}
                ]
              }]
            }

        Offsets and durations are in 100-nanosecond ticks
        (1 ms = 10_000 ticks). Returns (words, end_ms, conf).
        """
        try:
            raw_json = evt.result.json
        except Exception as e:
            logger.warning("[STT] result.json read failed: %s", e)
            return [], 0, 1.0

        try:
            data = json.loads(raw_json) if isinstance(raw_json, str) else raw_json
        except (json.JSONDecodeError, TypeError):
            logger.warning("[STT] could not parse result.json (raw=%r)", raw_json[:120] if raw_json else "")
            return [], 0, 1.0

        nbest = (data or {}).get("NBest") or []
        if not nbest:
            return [], 0, 1.0
        top = nbest[0] or {}
        conf = float(top.get("Confidence", 1.0))
        words_raw = top.get("Words") or []

        words: list[dict] = []
        end_ms = 0
        for w in words_raw:
            try:
                offset_ticks = int(w.get("Offset", 0))
                duration_ticks = int(w.get("Duration", 0))
            except (ValueError, TypeError):
                continue
            start_ms = offset_ticks // _TICKS_PER_MS
            word_end_ms = (offset_ticks + duration_ticks) // _TICKS_PER_MS
            end_ms = max(end_ms, word_end_ms)
            words.append({
                "w": str(w.get("Word", "")),
                "start_ms": start_ms,
                "end_ms": word_end_ms,
                # Azure surfaces per-utterance confidence, not per-word.
                # Use the utterance confidence as a per-word stand-in so
                # downstream code that expects a `conf` key on each word
                # doesn't KeyError.
                "conf": conf,
            })

        # Fallback: if no words were parsed (e.g. detailed output got
        # disabled upstream), derive end_ms from result.duration.
        if end_ms == 0:
            try:
                end_ms = int(evt.result.duration) // _TICKS_PER_MS
            except Exception:
                end_ms = 0

        return words, end_ms, conf
