"""Stream A VAD WebSocket client.

VAD events: speech_start, speech_end, endpoint_detected. We forward audio
frames in (so VAD can analyse them) and surface events out via callbacks.

By convention, callers also forward our VAD events to STT as control
messages so STT's buffer is VAD-gated (matches v1's pattern). The bridge
layer above us handles that wiring.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import Any, Awaitable, Callable

import websockets

from engine.brain.streamA_bridge._wire import encode_audio_frame

logger = logging.getLogger(__name__)


VadEventCb = Callable[[str, dict[str, Any]], Awaitable[None]]
"""(event_kind, payload) — kind ∈ {speech_start, speech_end, endpoint_detected}"""


class VADClient:
    def __init__(self, url: str, *, on_event: VadEventCb | None = None) -> None:
        self._url = url
        self._on_event = on_event
        self._ws: websockets.ClientConnection | None = None
        self._reader_task: asyncio.Task | None = None
        self._closed = asyncio.Event()

    async def connect(self) -> None:
        # Bounded connect: a wedged/slow VAD subprocess must FAIL FAST + LOUD, not
        # stall bring-up silently for minutes (the earlier "never started" hang and
        # the slow-2nd-interview symptom). open_timeout caps each attempt; a few
        # short retries ride out a transient. On total failure we raise so the
        # session errors out visibly instead of hanging.
        timeout_s = float(os.environ.get("VAD_CONNECT_TIMEOUT_S", "10"))
        attempts = int(os.environ.get("VAD_CONNECT_ATTEMPTS", "3"))
        last_err: Exception | None = None
        for attempt in range(1, attempts + 1):
            try:
                self._ws = await websockets.connect(
                    self._url,
                    ping_interval=60,
                    ping_timeout=60,
                    open_timeout=timeout_s,
                    close_timeout=5,
                    max_size=8 * 1024 * 1024,
                )
                self._reader_task = asyncio.create_task(self._read_loop(), name="vad-reader")
                logger.info("VAD connected: %s (attempt %d/%d)", self._url, attempt, attempts)
                return
            except Exception as e:  # incl. TimeoutError from open_timeout
                last_err = e
                logger.warning("VAD connect attempt %d/%d failed (%s): %s",
                               attempt, attempts, self._url, e)
                if attempt < attempts:
                    await asyncio.sleep(0.5 * attempt)
        try:  # surface the fail-fast on /metrics (never let metrics mask the error)
            from engine.brain.observability.prom import VAD_CONNECT_FAILURES
            VAD_CONNECT_FAILURES.inc()
        except Exception:
            pass
        raise RuntimeError(
            f"VAD connect failed after {attempts} attempts to {self._url}: {last_err}"
        ) from last_err

    async def send_audio_frame(self, ts_ms: int, pcm: bytes) -> None:
        if self._ws is None:
            return
        try:
            await self._ws.send(encode_audio_frame(ts_ms, pcm))
        except websockets.ConnectionClosed:
            self._closed.set()

    async def close(self) -> None:
        if self._reader_task is not None:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except (asyncio.CancelledError, Exception):
                pass
        if self._ws is not None:
            try:
                await self._ws.close()
            except Exception:  # pragma: no cover
                pass
        self._closed.set()

    async def _read_loop(self) -> None:
        assert self._ws is not None
        try:
            async for raw in self._ws:
                if not isinstance(raw, str):
                    continue
                try:
                    evt = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                kind = evt.get("type")
                if kind in ("speech_start", "speech_end", "endpoint_detected"):
                    if self._on_event is not None:
                        try:
                            await self._on_event(kind, evt)
                        except Exception as e:  # pragma: no cover
                            logger.warning("on_event cb raised: %s", e)
        except websockets.ConnectionClosed:
            pass
        finally:
            self._closed.set()
