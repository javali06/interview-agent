"""Azure Cognitive Services TTS — drop-in replacement for TTSClient.

Same public surface as the WebSocket-based TTSClient (Kokoro subprocess
on the other end of a WS), but driven by Azure's neural TTS via the
`azure-cognitiveservices-speech` SDK:

  - set_callbacks(*, on_pcm, on_audio_start, on_audio_end, on_cancelled)
  - connect() / close()
  - speak_chunk(turn_id, sequence_id, text)
  - cancel_turn(turn_id) / cancel_all()
  - pause() / resume() / is_paused()
  - turn_state(turn_id) / total_text_for(turn_id)

Architecture / why-this-shape:

  1. **One SpeechSynthesizer, reused.** The synthesizer object is
     expensive to construct (TLS handshake, per-voice model fetch). We
     build it once in connect() and reuse it for every speak_chunk.
     `Connection.from_speech_synthesizer(synth).open(True)` pre-warms
     the WS so the first synthesis doesn't pay the connect tax —
     critical for an interactive voice loop where the first AI sentence
     of the interview otherwise eats 800ms+ of latency.

  2. **Streaming via AudioDataStream.** `start_speaking_text_async()`
     kicks off a synthesis and returns a `SpeechSynthesisResult` whose
     `AudioDataStream` can be read in chunks **as audio is being
     generated server-side**. We pull fixed-size buffers in a thread
     (read_data blocks) and dispatch each chunk to `on_pcm` via the
     asyncio loop. Result: PCM starts flowing to the speakers within
     ~200-400ms of speak_chunk being called.

  3. **Threading bridge.** `read_data()` is blocking, so the per-chunk
     read loop runs inside `loop.run_in_executor(None, ...)`. Inside
     that thread we hand each PCM block back to the loop via
     `loop.call_soon_threadsafe(_handle_pcm, sub_id, pcm)` — the loop-
     side handler then drops cancelled subs and invokes `on_pcm`. PCM
     callbacks themselves are **sync** (`PcmCb = Callable[[bytes],
     None]`) to match TTSClient's contract, so no `create_task` wrapping
     is needed for them; the lifecycle callbacks (`on_audio_start` etc.)
     ARE async and DO get wrapped.

  4. **Cancellation race.** When the candidate barges in mid-utterance,
     the director calls `cancel_turn(turn_id)`. We:
       (a) add every active sub_id for that turn to `_cancelled_subs`
           BEFORE any await (so the PCM gate in the read loop is armed
           immediately).
       (b) call `synth.stop_speaking_async()` to abort server-side. The
           SDK still returns whatever audio it has already buffered on
           the client side; the gate at step (a) drops it before it
           reaches `on_pcm`.
     Identical contract to TTSClient.cancel_turn.

  5. **Pause/resume.** When paused, `speak_chunk` buffers (turn_id,
     seq, text) tuples instead of dispatching. On resume() the buffered
     chunks are flushed in order. Used by the latency orchestrator to
     hold AI speech while a filler clip plays.

  6. **_TurnState shape.** Mirrors the dataclass from `tts_client.py`
     1:1 so any code that introspects `turn_state(turn_id)` keeps
     working unchanged (`chars_sent`, `pcm_bytes_received`,
     `sub_ids_active`, etc.).

Output format is locked to Raw16Khz16BitMonoPcm so the downstream sink
(which expects exactly PCM16 mono 16kHz, no WAV header) gets bytes it
can write straight to the speakers.

Reference: https://learn.microsoft.com/en-us/azure/ai-services/speech-service/get-started-text-to-speech
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
from dataclasses import dataclass, field
from typing import Awaitable, Callable

import azure.cognitiveservices.speech as speechsdk

from engine.brain.observability.langfuse_client import observe_tts
from engine.brain.observability.timing import log_timing

logger = logging.getLogger(__name__)


PcmCb = Callable[[bytes], None]                          # raw PCM16 bytes → consumer
LifecycleCb = Callable[[dict], Awaitable[None]]          # JSON event → handler


# Read-buffer size for AudioDataStream.read_data(). 3200 bytes = 1600
# samples PCM16 mono = 100ms at 16kHz. Small enough to keep latency low
# (first PCM to speakers ~200ms after speak_chunk), large enough that we
# aren't spinning the executor thread on tiny reads.
_READ_BUFFER_BYTES = 3200


@dataclass
class _TurnState:
    """Per-turn bookkeeping. Mirrors the shape from tts_client.py so
    introspection code (e.g. the latency orchestrator's
    `audio_played_words` estimation) doesn't have to special-case Azure.
    """

    turn_id: str
    sub_ids_active: set[str] = field(default_factory=set)
    chars_sent: int = 0
    pcm_bytes_received: int = 0
    text_sent: list[str] = field(default_factory=list)
    audio_started: bool = False
    audio_played_ms: int = 0
    audio_started_at: float | None = None
    finished: bool = False
    sub_sent_at: dict[str, float] = field(default_factory=dict)
    sub_audio_started_at: dict[str, float] = field(default_factory=dict)
    # Per-sub running byte count — used to compute duration_ms on
    # audio_end. PCM16 mono @ 16kHz → bytes / 2 / 16 = ms.
    sub_bytes: dict[str, int] = field(default_factory=dict)


class AzureTTSClient:
    """Azure-backed TTS with the same surface as TTSClient.

    `__init__` signature differs from TTSClient: instead of a single WS
    `url`, we take `api_key + region + voice` so the caller can swap
    Kokoro for Azure with a config flip in `interview_session.py`.
    """

    def __init__(
        self,
        *,
        api_key: str,
        region: str,
        voice: str = "en-US-AvaNeural",
        sample_rate_hz: int = 16_000,
        # Langfuse session_id — when set, each speak_chunk fires a
        # `tts.synthesize` generation observation at audio_end / cancel.
        # None disables (local dev / Langfuse not configured).
        langfuse_session_id: str | None = None,
        # Langfuse user_id — candidate name. Propagated onto every trace
        # so Sessions view in Langfuse can group by candidate.
        langfuse_user_id: str | None = None,
    ) -> None:
        self._api_key = api_key
        # Non-secret id for THIS Azure Speech key (same sha256(secret)[:8] scheme
        # as the STT client + speech_pool), so a TTS throttle lines up on the same
        # key_id as its STT/admission counterparts on the dashboard.
        self._key_id = hashlib.sha256((api_key or "").encode()).hexdigest()[:8]
        self._region = region
        self._voice = voice
        self.sample_rate_hz = sample_rate_hz
        self._langfuse_session_id = langfuse_session_id
        self._langfuse_user_id = langfuse_user_id
        # Per-sub text captured at _send_chunk time so Langfuse spans on
        # audio_end can record the input string + char count without
        # re-deriving from _TurnState.text_sent (which is a flat list).
        self._sub_text: dict[str, str] = {}

        # SDK objects — built in connect().
        self._speech_config: speechsdk.SpeechConfig | None = None
        self._synthesizer: speechsdk.SpeechSynthesizer | None = None
        self._connection: speechsdk.Connection | None = None

        # Loop the SDK reader-thread callbacks marshal onto. Captured in
        # connect() because asyncio.get_running_loop() must be called
        # from a coroutine that's actually running.
        self._loop: asyncio.AbstractEventLoop | None = None

        # Hooks. Mirror TTSClient's defaults.
        self._on_audio_start: LifecycleCb | None = None
        self._on_audio_end: LifecycleCb | None = None
        self._on_cancelled: LifecycleCb | None = None
        self._on_pcm: PcmCb | None = None

        # Per-turn state + sub_id → turn_id index. Identical to TTSClient.
        self._turns: dict[str, _TurnState] = {}
        self._sub_to_turn: dict[str, str] = {}

        # Cancellation gate. Sub_ids added here are dropped at the
        # loop-side PCM dispatch (mirrors TTSClient._cancelled_subs).
        self._cancelled_subs: set[str] = set()

        # pause/resume — same semantics as TTSClient. Initially unpaused.
        self._paused = asyncio.Event()
        self._paused.set()
        self._buffered: list[tuple[str, int, str]] = []   # (turn_id, seq, text)

        # In-flight per-sub read tasks. Tracked so close() can cancel
        # them cleanly.
        self._inflight: set[asyncio.Task] = set()

    # ── construction-time wiring ──────────────────────────────────────

    def set_callbacks(
        self,
        *,
        on_pcm: PcmCb | None = None,
        on_audio_start: LifecycleCb | None = None,
        on_audio_end: LifecycleCb | None = None,
        on_cancelled: LifecycleCb | None = None,
    ) -> None:
        if on_pcm is not None: self._on_pcm = on_pcm
        if on_audio_start is not None: self._on_audio_start = on_audio_start
        if on_audio_end is not None: self._on_audio_end = on_audio_end
        if on_cancelled is not None: self._on_cancelled = on_cancelled

    # ── lifecycle ─────────────────────────────────────────────────────

    async def connect(self) -> None:
        """Build the SpeechConfig + SpeechSynthesizer + pre-warm the WS."""
        if self._synthesizer is not None:
            return
        self._loop = asyncio.get_running_loop()

        self._speech_config = speechsdk.SpeechConfig(
            subscription=self._api_key, region=self._region,
        )
        # Raw PCM16 mono 16kHz — no WAV header. Downstream sink writes
        # these bytes straight to the speaker queue.
        self._speech_config.set_speech_synthesis_output_format(
            speechsdk.SpeechSynthesisOutputFormat.Raw16Khz16BitMonoPcm,
        )
        self._speech_config.speech_synthesis_voice_name = self._voice

        # `audio_config=None` is the magic incantation that says "don't
        # play the audio yourself, hand it to me via AudioDataStream".
        # Without this, Azure plays through the default sound device.
        self._synthesizer = speechsdk.SpeechSynthesizer(
            speech_config=self._speech_config, audio_config=None,
        )

        # Pre-warm: keep the WS open across utterances so we don't pay
        # connect cost per speak_chunk.
        self._connection = speechsdk.Connection.from_speech_synthesizer(
            self._synthesizer,
        )
        try:
            self._connection.open(True)
            logger.info(
                "TTS connected (azure region=%s voice=%s sr=%d)",
                self._region, self._voice, self.sample_rate_hz,
            )
        except Exception as e:
            # Pre-warm failure isn't fatal — first speak_chunk will just
            # eat the connect tax. Log and keep going.
            logger.warning("[TTS] connection.open(True) failed: %s", e)

    async def close(self) -> None:
        """Cancel in-flight reads + tear down the synthesizer."""
        for t in list(self._inflight):
            t.cancel()
        for t in list(self._inflight):
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
        # Best-effort: stop any synthesis that's still in flight server-side.
        if self._synthesizer is not None:
            try:
                self._synthesizer.stop_speaking_async().get()
            except Exception:
                pass
        if self._connection is not None:
            try:
                self._connection.close()
            except Exception:
                pass
        self._connection = None
        self._synthesizer = None
        self._speech_config = None

    # ── speak / cancel ────────────────────────────────────────────────

    async def speak_chunk(self, turn_id: str, sequence_id: int, text: str) -> None:
        """Synthesize one chunk. Same contract as TTSClient.speak_chunk:
        sub_id = f"{turn_id}-{sequence_id}". When paused, buffer for
        resume()."""
        if not text.strip() or self._synthesizer is None:
            return
        if not self._paused.is_set():
            self._buffered.append((turn_id, sequence_id, text))
            return
        await self._send_chunk(turn_id, sequence_id, text)

    async def _send_chunk(self, turn_id: str, sequence_id: int, text: str) -> None:
        assert self._synthesizer is not None
        assert self._loop is not None
        sub_id = f"{turn_id}-{sequence_id}"
        ts = self._turns.setdefault(turn_id, _TurnState(turn_id=turn_id))
        ts.sub_ids_active.add(sub_id)
        ts.chars_sent += len(text)
        ts.text_sent.append(text)
        ts.sub_sent_at[sub_id] = self._loop.time()
        ts.sub_bytes[sub_id] = 0
        self._sub_to_turn[sub_id] = turn_id
        # Stash text for Langfuse observation emit at audio_end / cancel.
        # Bounded by the sub's lifetime — popped in _emit_langfuse_obs.
        self._sub_text[sub_id] = text

        # Kick off the synthesis + reader task. The actual
        # `start_speaking_text_async().get()` call is blocking, so the
        # whole reader pipeline runs as a task that off-loads its
        # blocking bits to the default executor.
        task = asyncio.create_task(
            self._synthesize_and_stream(sub_id, turn_id, text),
            name=f"azure-tts-{sub_id}",
        )
        self._inflight.add(task)
        task.add_done_callback(self._inflight.discard)

    async def _synthesize_and_stream(
        self, sub_id: str, turn_id: str, text: str,
    ) -> None:
        """Run one synthesis end-to-end: kick off, stream PCM, fire
        lifecycle callbacks, clean up state."""
        assert self._synthesizer is not None
        assert self._loop is not None
        ts = self._turns.get(turn_id)
        if ts is None:
            return

        try:
            # `start_speaking_text_async()` returns a future immediately
            # but the underlying `.get()` blocks until Azure has accepted
            # the request and prepared the AudioDataStream. Push to the
            # executor.
            def _start() -> speechsdk.SpeechSynthesisResult:
                assert self._synthesizer is not None
                return self._synthesizer.start_speaking_text_async(text).get()

            result = await self._loop.run_in_executor(None, _start)
            # A throttled synth (429 / quota) comes back as a CANCELED result, not
            # an exception — wrapping it in AudioDataStream would just read 0 bytes
            # and look like a silent, empty utterance. Attribute it to this key.
            self._note_throttle_if_canceled(result)
            stream = speechsdk.AudioDataStream(result)

            # Pull PCM in fixed-size blocks until the stream is drained.
            # `read_data` is blocking — runs in the executor too.
            audio_started_fired = False
            total_bytes = 0
            while True:
                # Each iteration kicks off a fresh executor read. If the
                # sub was cancelled while we were blocked in the previous
                # read, exit early to avoid streaming any more PCM.
                if sub_id in self._cancelled_subs:
                    break

                # IMPORTANT: AudioDataStream.read_data() in azure-
                # cognitiveservices-speech 1.40+ strictly type-checks its
                # `audio_buffer` arg as `bytes` (not `bytearray`). Passing
                # a bytearray raises
                #   TypeError: audio_buffer must be a bytes, is
                #   "bytearray(...)
                # immediately on the very first read. So we pass `bytes`
                # and take the chunk's actual length from read_data's
                # return value (read_data accepts immutable bytes because
                # internally it just reads up to len(buf) bytes; it
                # doesn't mutate the Python-side object — the SDK copies
                # into its own internal buffer and returns the slice).
                buf = bytes(_READ_BUFFER_BYTES)

                def _read() -> tuple[int, bytes]:
                    # Returns (n_bytes, buffer-with-the-n-bytes-at-head).
                    # 0 means end-of-stream (synthesis complete).
                    n = stream.read_data(buf)
                    return n, buf

                n, returned_buf = await self._loop.run_in_executor(None, _read)
                if n <= 0:
                    break

                chunk = returned_buf[:n]

                # Fire audio_start on the first byte. We do it here
                # (rather than on speak_chunk entry) so the first-byte
                # latency log reflects real time-to-first-audio.
                if not audio_started_fired:
                    audio_started_fired = True
                    self._mark_audio_start(sub_id, turn_id)

                # Dispatch the PCM through the cancellation gate.
                self._handle_pcm(sub_id, turn_id, chunk)
                total_bytes += n

            # read_data() also returns 0 when Azure CANCELS the synthesis
            # mid-stream; the candidate then hears the sentence cut off. Seen
            # live: 0.8 s of a 2.8 s question, intermittent, not tied to the
            # text. Say so loudly — otherwise it reads as a normal turn.
            try:
                if (stream.status == speechsdk.StreamStatus.Canceled
                        and sub_id not in self._cancelled_subs):
                    cd = stream.cancellation_details
                    details = getattr(cd, "error_details", "") or ""
                    code = getattr(cd, "error_code", None) or getattr(cd, "code", None)
                    logger.error(
                        "[TTS] synthesis cancelled part-way sub=%s after %d ms of audio: %s %s",
                        sub_id, (total_bytes // 2) * 1000 // self.sample_rate_hz,
                        code, details[:200],
                    )
                    from engine.brain.observability import prom
                    prom.TTS_TRUNCATED.labels(key_id=self._key_id).inc()
                    if prom.is_throttle_error(details) or prom.is_throttle_error(code):
                        prom.note_throttle("tts", self._key_id)
            except Exception:  # never break the turn over a diagnostic
                pass

            # End-of-stream. If we got here without being cancelled,
            # fire audio_end. If we *were* cancelled, fire on_cancelled
            # instead — matches TTSClient's reader-loop behaviour where
            # `cancelled` and `audio_end` are mutually exclusive per sub.
            if sub_id in self._cancelled_subs:
                self._mark_cancelled(sub_id, turn_id, total_bytes)
            else:
                self._mark_audio_end(sub_id, turn_id, total_bytes)

        except asyncio.CancelledError:
            # close() cancelled us; don't fire callbacks on the way out.
            return
        except Exception as e:
            logger.error(
                "[TTS] azure synth failed for sub=%s: %s", sub_id, e,
            )
            # A 429/throttle can also surface as a raised exception (e.g. the
            # start_speaking future erroring) — count it too.
            try:
                from engine.brain.observability import prom
                if prom.is_throttle_error(e):
                    prom.note_throttle("tts", self._key_id)
            except Exception:
                pass
            # Clean up ghost sub_id so the orchestrator doesn't wait
            # forever for an audio_end that's not coming.
            self._mark_cancelled(sub_id, turn_id, 0)

    async def cancel_turn(self, turn_id: str) -> None:
        """Cancel every active sub for `turn_id`.

        Mirrors TTSClient: mark all subs as cancelled BEFORE the
        server-side abort, so PCM already in flight (from the executor's
        in-progress read) is dropped at the gate. Then call
        `stop_speaking_async()` to tell Azure to stop synthesizing — any
        further reads return n=0 and the streamer exits naturally.
        """
        ts = self._turns.get(turn_id)
        if ts is None or self._synthesizer is None:
            return
        for sub_id in list(ts.sub_ids_active):
            self._cancelled_subs.add(sub_id)
        # Tell Azure to stop generating. Best-effort; the in-flight
        # executor read will simply see EOF on next call.
        try:
            assert self._loop is not None
            await self._loop.run_in_executor(
                None, lambda: self._synthesizer.stop_speaking_async().get(),
            )
        except Exception as e:
            logger.warning("[TTS] stop_speaking_async failed: %s", e)
        # Drop any still-buffered chunks for this turn.
        self._buffered = [t for t in self._buffered if t[0] != turn_id]

    async def cancel_all(self) -> None:
        for turn_id in list(self._turns.keys()):
            await self.cancel_turn(turn_id)

    # ── pause / resume — for filler hand-off ──────────────────────────

    def pause(self) -> None:
        self._paused.clear()

    async def resume(self) -> None:
        self._paused.set()
        buffered = list(self._buffered)
        self._buffered.clear()
        for turn_id, seq, text in buffered:
            await self._send_chunk(turn_id, seq, text)

    def is_paused(self) -> bool:
        return not self._paused.is_set()

    # ── inspect ───────────────────────────────────────────────────────

    def turn_state(self, turn_id: str) -> _TurnState | None:
        return self._turns.get(turn_id)

    def total_text_for(self, turn_id: str) -> str:
        ts = self._turns.get(turn_id)
        return "".join(ts.text_sent) if ts is not None else ""

    # ── Langfuse emit ─────────────────────────────────────────────────

    def _emit_langfuse_obs(
        self,
        sub_id: str,
        turn_id: str,
        total_bytes: int,
        duration_ms: int,
        *,
        cancelled: bool,
    ) -> None:
        """Open + immediately close a Langfuse `tts.synthesize` observation
        for one completed (or cancelled) sub. No-op when not configured.

        Latency anchors:
          - latency_ms     : send_chunk-dispatch → audio_end (total).
          - ttft_ms        : send_chunk-dispatch → first-PCM-byte. The
                             interactive-voice latency lever.
          - audio_ms_out   : duration of synthesised audio actually
                             delivered (excludes cancelled-tail bytes).
        """
        # Always pop the per-sub text — keeps the dict from leaking memory
        # even when Langfuse is disabled.
        text = self._sub_text.pop(sub_id, "")
        if self._langfuse_session_id is None or not text:
            return
        ts = self._turns.get(turn_id)
        sent_at = (ts.sub_sent_at.get(sub_id) if ts is not None else None)
        started_at = (
            ts.sub_audio_started_at.get(sub_id) if ts is not None else None
        )
        now = self._loop.time() if self._loop is not None else None
        latency_ms: int | None = None
        ttft_ms: int | None = None
        if sent_at is not None and now is not None:
            latency_ms = int((now - sent_at) * 1000)
        if sent_at is not None and started_at is not None:
            ttft_ms = int((started_at - sent_at) * 1000)
        try:
            with observe_tts(
                session_id=self._langfuse_session_id,
                text=text,
                voice=self._voice,
                user_id=self._langfuse_user_id,
            ) as lf_obs:
                lf_obs.update(
                    output={"audio_ms": duration_ms,
                            "pcm_bytes": total_bytes,
                            "cancelled": cancelled},
                    metadata={"sub_id": sub_id,
                              "turn_id": turn_id,
                              "latency_ms": latency_ms,
                              "ttft_ms": ttft_ms,
                              "region": self._region,
                              "sample_rate_hz": self.sample_rate_hz},
                )
        except Exception as e:  # pragma: no cover
            logger.debug("[TTS] langfuse emit failed: %s", e)

    # ── throttle attribution ──────────────────────────────────────────

    def _note_throttle_if_canceled(self, result: object) -> None:
        """If ``result`` is a CANCELED synthesis due to an upstream 429/throttle
        (Azure CancellationErrorCode.TooManyRequests or a quota message), count it
        against this Speech key (interview_rate_limited_total{service="tts"}).
        Guarded — never breaks synthesis."""
        try:
            if getattr(result, "reason", None) != speechsdk.ResultReason.Canceled:
                return
            cd = getattr(result, "cancellation_details", None)
            details = getattr(cd, "error_details", "") if cd is not None else ""
            code = getattr(cd, "error_code", None) if cd is not None else None
            from engine.brain.observability import prom
            if prom.is_throttle_error(code) or prom.is_throttle_error(details):
                prom.note_throttle("tts", self._key_id)
        except Exception:
            pass

    # ── PCM gate + lifecycle event helpers ────────────────────────────

    def _handle_pcm(self, sub_id: str, turn_id: str, pcm: bytes) -> None:
        """Loop-side PCM dispatch. Drops cancelled subs, accounts bytes,
        forwards to on_pcm.

        Called from `_synthesize_and_stream` (which runs on the loop).
        No threadsafe hop needed — we're already on the loop here.
        """
        if not pcm:
            return
        # Gate: cancelled subs are dropped silently.
        if sub_id in self._cancelled_subs:
            return
        ts = self._turns.get(turn_id)
        if ts is not None:
            ts.pcm_bytes_received += len(pcm)
            ts.sub_bytes[sub_id] = ts.sub_bytes.get(sub_id, 0) + len(pcm)
        # Audio accounting: how many ms of audio have actually been
        # delivered. PCM16 mono → samples = bytes / 2, ms = samples *
        # 1000 / sr.
        if ts is not None and ts.audio_started and not ts.finished:
            added_ms = (len(pcm) // 2) * 1000 // self.sample_rate_hz
            ts.audio_played_ms += added_ms
        if self._on_pcm is not None:
            try:
                self._on_pcm(pcm)
            except Exception as e:
                logger.warning("[TTS] on_pcm raised: %s", e)

    def _mark_audio_start(self, sub_id: str, turn_id: str) -> None:
        """Fire on_audio_start for `sub_id`. Called when the first PCM
        byte for that sub is read."""
        if self._loop is None:
            return
        ts = self._turns.get(turn_id)
        now = self._loop.time()
        if ts is not None:
            ts.audio_started = True
            if ts.audio_started_at is None:
                ts.audio_started_at = now
            ts.sub_audio_started_at[sub_id] = now
            sent_at = ts.sub_sent_at.get(sub_id)
            if sent_at is not None:
                first_byte_ms = int((now - sent_at) * 1000)
                log_timing(
                    logger, "TTS", "audio_start", first_byte_ms, sub=sub_id,
                )
        if self._on_audio_start is not None:
            evt = {"type": "audio_start", "request_id": sub_id, "turn_id": turn_id}
            try:
                asyncio.create_task(
                    self._on_audio_start(evt),
                    name=f"azure-tts-audio_start-{sub_id}",
                )
            except Exception as e:
                logger.warning("[TTS] on_audio_start dispatch raised: %s", e)

    def _mark_audio_end(self, sub_id: str, turn_id: str, total_bytes: int) -> None:
        """Fire on_audio_end for `sub_id`. Called when read_data returns
        0 (end-of-stream) and the sub wasn't cancelled."""
        if self._loop is None:
            return
        ts = self._turns.get(turn_id)
        duration_ms = (total_bytes // 2) * 1000 // self.sample_rate_hz
        if ts is not None:
            ts.sub_ids_active.discard(sub_id)
            if not ts.sub_ids_active:
                ts.finished = True
            started_at = ts.sub_audio_started_at.get(sub_id)
            if started_at is not None:
                synth_ms = int((self._loop.time() - started_at) * 1000)
                log_timing(
                    logger, "TTS", "audio_end", synth_ms,
                    sub=sub_id, dur=f"{duration_ms}ms",
                )
        # Langfuse: emit one `tts.synthesize` observation per completed sub.
        # We're on the asyncio loop here so OTel context vars are valid.
        self._emit_langfuse_obs(
            sub_id, turn_id, total_bytes, duration_ms, cancelled=False,
        )
        self._cancelled_subs.discard(sub_id)
        self._sub_to_turn.pop(sub_id, None)
        if self._on_audio_end is not None:
            evt = {
                "type": "audio_end", "request_id": sub_id, "turn_id": turn_id,
                "total_bytes": total_bytes, "duration_ms": duration_ms,
            }
            try:
                asyncio.create_task(
                    self._on_audio_end(evt),
                    name=f"azure-tts-audio_end-{sub_id}",
                )
            except Exception as e:
                logger.warning("[TTS] on_audio_end dispatch raised: %s", e)

    def _mark_cancelled(self, sub_id: str, turn_id: str, total_bytes: int) -> None:
        """Fire on_cancelled for `sub_id`. Called when the sub was
        cancelled mid-stream OR when synthesis failed (defensive
        cleanup)."""
        ts = self._turns.get(turn_id)
        if ts is not None:
            ts.sub_ids_active.discard(sub_id)
            ts.finished = True
        duration_ms = (total_bytes // 2) * 1000 // self.sample_rate_hz
        self._emit_langfuse_obs(
            sub_id, turn_id, total_bytes, duration_ms, cancelled=True,
        )
        self._cancelled_subs.discard(sub_id)
        self._sub_to_turn.pop(sub_id, None)
        if self._on_cancelled is not None:
            evt = {
                "type": "cancelled", "request_id": sub_id, "turn_id": turn_id,
                "total_bytes": total_bytes,
            }
            try:
                asyncio.create_task(
                    self._on_cancelled(evt),
                    name=f"azure-tts-cancelled-{sub_id}",
                )
            except Exception as e:
                logger.warning("[TTS] on_cancelled dispatch raised: %s", e)
