"""Groq Whisper STT — drop-in replacement for STTClient.

Stream A's STT is a WebSocket service: stream 20ms PCM frames in, get
partials/finals out. Groq's STT is REST: POST a complete audio file, get
the full transcription back. We adapt by:

  - Buffering raw PCM frames locally (this client) while the candidate is
    speaking — between VAD speech_start and VAD endpoint_detected.
  - On endpoint, wrapping the buffer in a WAV container and POSTing to
    Groq's `/audio/transcriptions` endpoint with `verbose_json` +
    word-level timestamps.
  - Surfacing the result via the same `on_final` callback shape as
    STTClient — `(text, words, end_ms, confidence, utterance_id)`.

No partials are emitted (Groq's REST API isn't streaming). The rest of
the system never knew about partials anyway (Stream A's STT didn't emit
them either), so this is a clean swap.

Endpoint reference: https://console.groq.com/docs/speech-to-text
  POST https://api.groq.com/openai/v1/audio/transcriptions
  multipart/form-data: file, model, response_format, timestamp_granularities,
                        language, temperature
  Models: whisper-large-v3 (10.3% WER, $0.111/hr)
          whisper-large-v3-turbo (12% WER, $0.04/hr — recommended default)
"""
from __future__ import annotations

import asyncio
import io
import logging
import math
import time
import wave
from typing import Any, Awaitable, Callable

from openai import AsyncOpenAI

from engine.brain.observability.timing import log_timing

logger = logging.getLogger(__name__)


PartialCb = Callable[[str, list[dict], int], Awaitable[None]]
FinalCb = Callable[[str, list[dict], int, float, str], Awaitable[None]]


def _pcm16_to_wav_bytes(pcm: bytes, sample_rate: int = 16_000) -> bytes:
    """Wrap raw PCM16 mono bytes in a WAV container so Groq accepts them.
    Groq downsamples to 16kHz mono internally regardless of input rate, but
    needs a real audio container — raw PCM bytes are rejected."""
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)             # PCM16 = 2 bytes/sample
        wf.setframerate(sample_rate)
        wf.writeframes(pcm)
    return buf.getvalue()


# Known Whisper hallucinations — short generic phrases the model emits
# on near-silent / noise-only audio when `no_speech_prob` happens to fall
# below threshold. Match is case-insensitive and ignores leading/trailing
# whitespace + final punctuation. Curated from typical Whisper output
# patterns; extend freely as new ones turn up in your logs.
_WHISPER_HALLUCINATIONS: frozenset[str] = frozenset({
    "thank you",
    "thanks",
    "thanks for watching",
    "thanks for watching!",
    "thanks for watching.",
    "thank you for watching",
    "thank you so much for watching",
    "please subscribe",
    "subscribe to the channel",
    "subscribe to my channel",
    "don't forget to subscribe",
    "like and subscribe",
    "see you in the next video",
    "see you next time",
    "bye",
    "bye bye",
    "goodbye",
    "okay",
    "ok",
    "yeah",
    "yes",
    "no",
    "mmm",
    "hmm",
    "uh",
    "um",
    "i'm sorry",
    "sorry",
    "it's just a little",
    "you",
    "the",
    ".",
    "...",
})


def _is_whisper_hallucination(text: str) -> bool:
    """True if `text` matches a known Whisper short-hallucination pattern.

    Normalisation: lowercased, stripped, trailing punctuation removed.
    Only short transcripts are checked — Whisper's known hallucinations
    are all short, and any long string is unlikely to match by accident.
    """
    if not text:
        return False
    # Strip leading/trailing whitespace + common trailing punctuation.
    norm = text.strip().lower().rstrip(".!?,;: ")
    if not norm:
        return True  # was just punctuation
    # Cap on length so a real long sentence that coincidentally starts
    # with "thank you" can't be mistaken for a pure hallucination.
    if len(norm.split()) > 6:
        return False
    return norm in _WHISPER_HALLUCINATIONS


class GroqSTTClient:
    """Drop-in replacement for STTClient that uses Groq's whisper API.

    Public API matches STTClient:
      - connect() / close()
      - send_audio_frame(ts_ms, pcm)
      - send_control(payload)   # speech_start / speech_end / endpoint_detected
      - on_partial / on_final callbacks
    """

    def __init__(
        self,
        *,
        api_key: str,
        model: str = "whisper-large-v3-turbo",
        language: str = "en",
        base_url: str = "https://api.groq.com/openai/v1",
        sample_rate: int = 16_000,
        on_partial: PartialCb | None = None,
        on_final: FinalCb | None = None,
        client: AsyncOpenAI | None = None,
        no_speech_threshold: float = 0.6,
        min_utterance_ms: int = 0,
        preroll_ms: int = 50,
    ) -> None:
        self._api_key = api_key
        self._model = model
        self._language = language
        self._sample_rate = sample_rate
        self._on_partial = on_partial      # accepted for API compat; never called
        self._on_final = on_final
        # If Whisper's per-segment `no_speech_prob` averages above this,
        # treat the transcript as noise (emit empty text). Catches the
        # "AI's voice / cough / door slam → hallucinated 'Thank you.'"
        # failure mode.
        self._no_speech_threshold = no_speech_threshold
        # Minimum buffered audio duration before we even POST to Groq. If
        # endpoint fires within this window, the utterance is treated as
        # noise — we skip the transcription entirely and emit empty text.
        # Tied to the barge-in warm-up window: if speech wasn't sustained
        # enough to interrupt the AI, it isn't sustained enough to
        # transcribe either.
        self._min_utterance_ms = min_utterance_ms
        # Use a dedicated client (Groq's STT lives at the same base URL as the
        # chat completions API, so this works on the same key).
        self._client = client or AsyncOpenAI(api_key=api_key, base_url=base_url)

        # Per-utterance PCM buffer, opened on VAD speech_start, closed on
        # VAD endpoint_detected.
        self._buffer = bytearray()
        self._buffer_active = False
        self._utterance_seq = 0
        # Pre-roll ring buffer. Continuously holds the last `preroll_ms` of
        # mic PCM, even when no utterance is being buffered. On speech_start
        # we prepend it to the new utterance buffer so the head-of-utterance
        # audio that arrived BEFORE VAD detected speech (VAD's ~120ms
        # hysteresis + WS roundtrip + handler latency = 200-500ms typical)
        # is recovered. Without this the first word or two of every
        # utterance gets clipped.
        self._preroll_ms = preroll_ms
        # PCM16 = 2 bytes/sample. Byte-cap for `preroll_ms` of audio.
        self._preroll_max_bytes = preroll_ms * sample_rate * 2 // 1000
        self._preroll = bytearray()
        # Snapshot of how many pre-roll bytes we seeded into `_buffer` on
        # this utterance's speech_start. Used to derive the true speech-only
        # duration at endpoint so `min_utterance_ms` still measures actual
        # speech length (not speech + pre-roll silence).
        self._preroll_bytes_in_buffer = 0
        # Track in-flight transcribe tasks so we can cancel on close().
        self._inflight: set[asyncio.Task] = set()

    async def connect(self) -> None:
        """No-op — Groq's STT is REST, not WebSocket."""
        logger.info(
            "Groq STT ready (model=%s lang=%s)", self._model, self._language,
        )

    async def send_audio_frame(self, ts_ms: int, pcm: bytes) -> None:
        """Feed mic PCM into both the pre-roll ring buffer and (if a
        speech_start has fired) the active utterance buffer."""
        # Only maintain the pre-roll ring when it's configured to a
        # non-zero size. `preroll_max_bytes == 0` would make the slice
        # `self._preroll[-0:]` evaluate to `self._preroll[0:]` — the
        # WHOLE array — so the buffer would grow unbounded and every
        # new utterance would be seeded with the entire session's audio
        # history (manifests as the candidate's PRIOR turn being
        # transcribed again instead of the latest one).
        if self._preroll_max_bytes > 0:
            self._preroll.extend(pcm)
            if len(self._preroll) > self._preroll_max_bytes:
                self._preroll = self._preroll[-self._preroll_max_bytes:]
        if self._buffer_active:
            self._buffer.extend(pcm)

    async def send_control(self, payload: dict[str, Any]) -> None:
        """Map VAD control messages to buffer lifecycle.

          speech_start      → open buffer if not already open
          speech_end        → keep buffering (mid-utterance pause)
          endpoint_detected → flush + dispatch transcription in background
        """
        kind = payload.get("type")
        if kind == "speech_start":
            if not self._buffer_active:
                self._utterance_seq += 1
                # Seed the new utterance buffer with the pre-roll. This
                # recovers ~preroll_ms of audio that arrived BEFORE VAD
                # registered speech_start — the head-of-utterance that
                # would otherwise be clipped (VAD hysteresis + WS hop).
                self._buffer = bytearray(self._preroll)
                self._preroll_bytes_in_buffer = len(self._buffer)
                preroll_ms = (
                    self._preroll_bytes_in_buffer * 1000
                    // (self._sample_rate * 2)
                )
                self._buffer_active = True
                logger.info(
                    "[STT] speech_start — opening buffer for utterance #%d "
                    "(seeded with %dms of pre-roll)",
                    self._utterance_seq, preroll_ms,
                )
        elif kind == "endpoint_detected":
            if not self._buffer_active or len(self._buffer) == 0:
                return
            audio = bytes(self._buffer)
            preroll_bytes = self._preroll_bytes_in_buffer
            self._buffer = bytearray()
            self._buffer_active = False
            self._preroll_bytes_in_buffer = 0
            uid = f"groq-stt-{self._utterance_seq}"
            duration_s = len(audio) / 2 / self._sample_rate
            duration_ms = int(duration_s * 1000)
            # `speech_duration_ms` excludes the pre-roll bytes we prepended.
            # min_utterance_ms is supposed to gate on actual speech length,
            # not "speech + pre-roll silence", otherwise pre-roll would
            # silently inflate every utterance past the threshold.
            speech_bytes = max(0, len(audio) - preroll_bytes)
            speech_duration_ms = speech_bytes * 1000 // (self._sample_rate * 2)
            # Too-short utterance: don't even bother POSTing. Treat as noise.
            # Still emit on_final("") so the director can cancel STT-wait
            # filler and clear `candidate_spoke_since_last_ai`.
            if speech_duration_ms < self._min_utterance_ms:
                logger.info(
                    "[STT] endpoint — speech %.2fs (%dms, excludes %dms "
                    "pre-roll) is below min_utterance_ms=%dms → dropping "
                    "without POST",
                    speech_duration_ms / 1000, speech_duration_ms,
                    preroll_bytes * 1000 // (self._sample_rate * 2),
                    self._min_utterance_ms,
                )
                if self._on_final is not None:
                    asyncio.create_task(
                        self._on_final("", [], duration_ms, 1.0, uid),
                        name=f"groq-stt-short-{uid}",
                    )
                return
            logger.info(
                "[STT] endpoint — buffer %d bytes (%.2fs audio) → POST to Groq (%s)",
                len(audio), duration_s, uid,
            )
            task = asyncio.create_task(
                self._transcribe(audio, uid, duration_s),
                name=f"groq-stt-{uid}",
            )
            self._inflight.add(task)
            task.add_done_callback(self._inflight.discard)
        # speech_end: ignore — endpoint will fire when candidate truly stops

    async def close(self) -> None:
        """Cancel any in-flight transcription tasks."""
        for t in list(self._inflight):
            t.cancel()
        for t in list(self._inflight):
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass

    # ── private ────────────────────────────────────────────────────────────

    async def _transcribe(
        self, pcm: bytes, utterance_id: str, duration_s: float,
    ) -> None:
        """POST the buffered PCM to Groq's transcription endpoint and emit
        the result via on_final."""
        if not self._on_final or not pcm:
            return
        # Skip silly-short utterances — Groq's documented minimum is 0.01s
        # but realistically <100ms is just a click or breath that VAD
        # spuriously latched onto.
        if duration_s < 0.1:
            logger.debug("[STT] skipping ultra-short utterance (%.3fs)", duration_s)
            return

        wav_bytes = _pcm16_to_wav_bytes(pcm, self._sample_rate)
        started = time.perf_counter()
        try:
            res = await self._client.audio.transcriptions.create(
                file=("speech.wav", wav_bytes, "audio/wav"),
                model=self._model,
                response_format="verbose_json",
                timestamp_granularities=["word"],
                language=self._language,
                temperature=0.0,
            )
            latency_ms = int((time.perf_counter() - started) * 1000)
            text = (getattr(res, "text", "") or "").strip()
            words = self._extract_words(res)
            end_ms = (
                int(words[-1].get("end_ms", 0)) if words
                else int(duration_s * 1000)
            )
            conf = self._extract_confidence(res)
            no_speech = self._extract_no_speech_prob(res)
            # If Whisper itself says this is mostly silence/noise, drop the
            # text. Director's `_is_noise_only` already handles empty text
            # → it clears `candidate_spoke_since_last_ai` and skips the LLM
            # dispatch. Without this filter, Whisper hallucinates strings
            # like "Thank you." / "Thanks for watching." on noise input.
            if no_speech is not None and no_speech > self._no_speech_threshold:
                log_timing(
                    logger, "STT", "groq_resp", latency_ms,
                    model=self._model,
                    audio_s=f"{duration_s:.1f}",
                    text=repr(text[:60]),
                    conf=f"{conf:.2f}",
                    no_speech=f"{no_speech:.2f}",
                    dropped="noise",
                )
                logger.info(
                    "[STT] dropping noise transcript: no_speech_prob=%.2f > "
                    "%.2f threshold (hallucinated text was %r)",
                    no_speech, self._no_speech_threshold, text[:60],
                )
                await self._on_final("", [], end_ms, conf, utterance_id)
                return

            # Whisper-hallucination list filter. Whisper emits a small set
            # of short generic phrases ("Thank you.", "It's just a little.",
            # "Thanks for watching." etc.) on near-silent / noise-only
            # audio EVEN WHEN `no_speech_prob` is below threshold — i.e.
            # the previous filter doesn't catch them because the model is
            # falsely "confident" the noise was speech. Match the
            # normalised transcript against a curated block-list and
            # treat as noise (empty text) downstream.
            if _is_whisper_hallucination(text):
                log_timing(
                    logger, "STT", "groq_resp", latency_ms,
                    model=self._model,
                    audio_s=f"{duration_s:.1f}",
                    text=repr(text[:60]),
                    conf=f"{conf:.2f}",
                    no_speech=f"{no_speech:.2f}" if no_speech is not None else "n/a",
                    dropped="hallucination",
                )
                logger.info(
                    "[STT] dropping known Whisper hallucination: %r "
                    "(no_speech_prob=%s)",
                    text[:60],
                    f"{no_speech:.2f}" if no_speech is not None else "n/a",
                )
                await self._on_final("", [], end_ms, conf, utterance_id)
                return
            log_timing(
                logger, "STT", "groq_resp", latency_ms,
                model=self._model,
                audio_s=f"{duration_s:.1f}",
                text=repr(text[:60]),
                conf=f"{conf:.2f}",
                no_speech=f"{no_speech:.2f}" if no_speech is not None else "n/a",
            )
            await self._on_final(text, words, end_ms, conf, utterance_id)
        except asyncio.CancelledError:
            return
        except Exception as e:
            logger.error("[STT] groq transcribe failed for %s: %s", utterance_id, e)

    def _extract_words(self, res: Any) -> list[dict]:
        """Convert Groq's word-level timestamps to our internal `words` format
        (used by Director to estimate end_ms etc.)."""
        words = getattr(res, "words", None) or []
        out: list[dict] = []
        for w in words:
            try:
                wd = w if isinstance(w, dict) else w.model_dump()
            except Exception:
                wd = {}
            out.append({
                "w": wd.get("word", ""),
                "start_ms": int(float(wd.get("start", 0.0)) * 1000),
                "end_ms": int(float(wd.get("end", 0.0)) * 1000),
                "conf": 1.0,             # Groq doesn't return per-word confidence
            })
        return out

    def _extract_confidence(self, res: Any) -> float:
        """Aggregate confidence from `verbose_json` segments. Groq returns
        `avg_logprob` per segment; we map to 0-1 via exp(logprob) then
        average across segments."""
        segments = getattr(res, "segments", None) or []
        if not segments:
            return 1.0
        confs: list[float] = []
        for seg in segments:
            try:
                sd = seg if isinstance(seg, dict) else seg.model_dump()
            except Exception:
                sd = {}
            lp = sd.get("avg_logprob")
            if lp is not None:
                try:
                    confs.append(math.exp(float(lp)))
                except (ValueError, OverflowError):
                    pass
        if not confs:
            return 1.0
        return sum(confs) / len(confs)

    def _extract_no_speech_prob(self, res: Any) -> float | None:
        """Mean of per-segment `no_speech_prob` from verbose_json. Whisper's
        built-in noise indicator: high values mean the segment is more
        likely silence/noise than speech. Returns None if no segments."""
        segments = getattr(res, "segments", None) or []
        if not segments:
            return None
        probs: list[float] = []
        for seg in segments:
            try:
                sd = seg if isinstance(seg, dict) else seg.model_dump()
            except Exception:
                sd = {}
            p = sd.get("no_speech_prob")
            if p is not None:
                try:
                    probs.append(float(p))
                except (ValueError, TypeError):
                    pass
        if not probs:
            return None
        return sum(probs) / len(probs)
