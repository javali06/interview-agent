"""Stream A TTS WebSocket client — the headline architectural fix.

What v1's `TTSSender` got wrong (README §5a):
  - It only ever called `ws.send()`. The server's `audio_start`/PCM/`audio_end`
    replies piled up in the recv buffer; `max_queue=32` filled within ~0.6s of
    synthesis; pongs got stuck behind unread frames; connection died with
    `1011 keepalive ping timeout` after ~30s.

What v2 does:
  - Owns a parallel reader task (`_reader_loop`). Drains binary PCM frames
    into an `audio_consumer` callback (the speakers); parses
    audio_start/audio_end/cancelled JSON into typed callbacks.
  - Each `speak_chunk(turn_id, sequence_id, text)` uses a unique sub-ID
    `f"{turn_id}-{sequence_id}"` so Stream A's `cancel_manager` doesn't
    reject duplicates (the v1 sub-ID hack made native).
  - `cancel_turn(turn_id)` broadcasts cancels to every active sub-ID. Stream
    A returns cancelled-but-no-error for already-finished sub-IDs.
  - `pause()` / `resume()` let the latency orchestrator hold buffered chunks
    while a filler plays.
"""
from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from typing import Awaitable, Callable

import websockets

from engine.brain.observability.timing import log_timing
from engine.brain.streamA_bridge._wire import strip_tts_header

logger = logging.getLogger(__name__)


PcmCb = Callable[[bytes], None]                          # raw PCM16 bytes → consumer
LifecycleCb = Callable[[dict], Awaitable[None]]          # JSON event → handler


@dataclass
class _TurnState:
    """Per-turn bookkeeping. Persisted on TTSClient.

    `expected_chars` is the running total of text submitted; `played_ms` is
    the running total of audio that's actually played. We use these to
    estimate `audio_played_words` on barge-in (NEW_STREAM_B.md §8B.3).
    """

    turn_id: str
    sub_ids_active: set[str] = field(default_factory=set)
    chars_sent: int = 0
    text_sent: list[str] = field(default_factory=list)
    audio_started: bool = False
    audio_played_ms: int = 0
    audio_started_at: float | None = None
    finished: bool = False
    # Per-sub-id timestamps for TTS first-byte / synthesis-duration timing.
    # Populated when speak_chunk is sent (sent_at) and when its audio_start
    # arrives (audio_started_at_per_sub).
    sub_sent_at: dict[str, float] = field(default_factory=dict)
    sub_audio_started_at: dict[str, float] = field(default_factory=dict)


class TTSClient:
    def __init__(
        self,
        url: str,
        *,
        sample_rate_hz: int = 16_000,
        ping_interval: int = 60,
        ping_timeout: int = 60,
        max_size: int = 8 * 1024 * 1024,
    ) -> None:
        self._url = url
        self._ping_interval = ping_interval
        self._ping_timeout = ping_timeout
        self._max_size = max_size
        self._ws: websockets.ClientConnection | None = None
        self._reader_task: asyncio.Task | None = None
        self.sample_rate_hz = sample_rate_hz

        # Hooks (latency orchestrator wires these).
        self._on_audio_start: LifecycleCb | None = None
        self._on_audio_end: LifecycleCb | None = None
        self._on_cancelled: LifecycleCb | None = None
        self._on_pcm: PcmCb | None = None

        # Turn-state map. Multiple turns can be in flight if pause/resume is in
        # use; we track each by turn_id.
        self._turns: dict[str, _TurnState] = {}
        self._sub_to_turn: dict[str, str] = {}

        # Per-sub PCM gating. Stream A's WS interleaves JSON lifecycle events
        # with binary PCM frames. PCM frames carry NO sub_id in their header,
        # so we track "which sub is currently streaming" via JSON audio_start
        # / audio_end / cancelled events:
        #   - audio_start(X)          → _current_sub = X
        #   - audio_end(X)            → _current_sub cleared if it was X
        #   - cancelled(X)            → _current_sub cleared if it was X
        # `_cancelled_subs` is populated *locally* at cancel_turn() call time
        # (before the WS round-trip) so any in-flight PCM that arrives
        # between sending the cancel and Stream A processing it is dropped.
        self._current_sub: str | None = None
        self._cancelled_subs: set[str] = set()

        # pause/resume — when paused, speak_chunk buffers and does NOT send.
        self._paused = asyncio.Event()
        self._paused.set()                      # initially unpaused
        self._buffered: list[tuple[str, int, str]] = []   # (turn_id, seq, text)

    # ── construction-time wiring ──────────────────────────────────────────────

    def set_callbacks(
        self,
        *,
        on_pcm: PcmCb | None = None,
        on_audio_start: LifecycleCb | None = None,
        on_audio_end: LifecycleCb | None = None,
        on_cancelled: LifecycleCb | None = None,
    ) -> None:
        if on_pcm is not None: self._on_pcm = on_pcm
        if on_audio_start is not None: self._on_audio_start = on_audio_start
        if on_audio_end is not None: self._on_audio_end = on_audio_end
        if on_cancelled is not None: self._on_cancelled = on_cancelled

    # ── lifecycle ──────────────────────────────────────────────────────────────

    async def connect(self) -> None:
        self._ws = await websockets.connect(
            self._url,
            ping_interval=self._ping_interval,
            ping_timeout=self._ping_timeout,
            max_size=self._max_size,
        )
        self._reader_task = asyncio.create_task(self._reader_loop(), name="tts-reader")
        logger.info("TTS connected: %s", self._url)

    async def close(self) -> None:
        if self._reader_task is not None:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except (asyncio.CancelledError, Exception):
                pass
        if self._ws is not None:
            try:
                await self._ws.close()
            except Exception:  # pragma: no cover
                pass

    # ── speak / cancel ─────────────────────────────────────────────────────────

    async def speak_chunk(self, turn_id: str, sequence_id: int, text: str) -> None:
        """Send one sentence/chunk for synthesis. Streams seamlessly with prior chunks
        of the same turn_id."""
        if not text.strip() or self._ws is None:
            return
        # If paused, buffer. The latency orchestrator will resume() and we'll flush.
        if not self._paused.is_set():
            self._buffered.append((turn_id, sequence_id, text))
            return
        await self._send_chunk(turn_id, sequence_id, text)

    async def _send_chunk(self, turn_id: str, sequence_id: int, text: str) -> None:
        assert self._ws is not None
        sub_id = f"{turn_id}-{sequence_id}"
        ts = self._turns.setdefault(turn_id, _TurnState(turn_id=turn_id))
        ts.sub_ids_active.add(sub_id)
        ts.chars_sent += len(text)
        ts.text_sent.append(text)
        ts.sub_sent_at[sub_id] = asyncio.get_running_loop().time()
        self._sub_to_turn[sub_id] = turn_id
        try:
            await self._ws.send(json.dumps({
                "type": "speak", "request_id": sub_id, "text": text,
            }))
        except websockets.ConnectionClosed:
            # CRITICAL: don't leave a ghost sub_id in the active set. If we
            # do, the latency orchestrator's audio_end handler will keep
            # waiting for an event that never arrives, and ai_activity will
            # stick at AUDIO_PLAYING forever.
            logger.warning(
                "[TTS] WS closed while sending chunk %s — dropping ghost sub_id",
                sub_id,
            )
            ts.sub_ids_active.discard(sub_id)
            self._sub_to_turn.pop(sub_id, None)
        except Exception as e:
            # Same defensive cleanup for any other send failure.
            logger.warning("[TTS] send failed for %s: %s — dropping ghost sub_id",
                           sub_id, e)
            ts.sub_ids_active.discard(sub_id)
            self._sub_to_turn.pop(sub_id, None)

    async def cancel_turn(self, turn_id: str) -> None:
        """Broadcast cancel to every active sub-ID for a turn.

        Critically, sub_ids are added to `_cancelled_subs` BEFORE the WS
        send. Any PCM that arrives between the send and Stream A's
        processing of the cancel (in-flight chunks already on the wire)
        will be dropped at the reader-loop gate, so the candidate doesn't
        hear the tail of a cancelled turn."""
        ts = self._turns.get(turn_id)
        if ts is None or self._ws is None:
            return
        # Mark BEFORE the WS send so the PCM gate is armed immediately.
        for sub_id in list(ts.sub_ids_active):
            self._cancelled_subs.add(sub_id)
        for sub_id in list(ts.sub_ids_active):
            try:
                await self._ws.send(json.dumps({"type": "cancel", "request_id": sub_id}))
            except websockets.ConnectionClosed:
                break
        # Drop any still-buffered chunks for this turn (they won't be flushed on resume).
        self._buffered = [t for t in self._buffered if t[0] != turn_id]

    async def cancel_all(self) -> None:
        for turn_id in list(self._turns.keys()):
            await self.cancel_turn(turn_id)

    # ── pause / resume — for filler hand-off ──────────────────────────────────

    def pause(self) -> None:
        self._paused.clear()

    async def resume(self) -> None:
        self._paused.set()
        # Flush anything that built up while paused.
        buffered = list(self._buffered)
        self._buffered.clear()
        for turn_id, seq, text in buffered:
            await self._send_chunk(turn_id, seq, text)

    def is_paused(self) -> bool:
        return not self._paused.is_set()

    # ── inspect ───────────────────────────────────────────────────────────────

    def turn_state(self, turn_id: str) -> _TurnState | None:
        return self._turns.get(turn_id)

    def total_text_for(self, turn_id: str) -> str:
        ts = self._turns.get(turn_id)
        return "".join(ts.text_sent) if ts is not None else ""

    # ── parallel reader ───────────────────────────────────────────────────────

    async def _reader_loop(self) -> None:
        assert self._ws is not None
        try:
            async for raw in self._ws:
                if isinstance(raw, (bytes, bytearray)):
                    pcm = strip_tts_header(bytes(raw))
                    # Gate: drop PCM that belongs to a cancelled sub. Stream
                    # A still streams chunks already on the wire after our
                    # cancel; without this gate they'd play after barge-in.
                    if (
                        pcm
                        and self._current_sub is not None
                        and self._current_sub in self._cancelled_subs
                    ):
                        # Silent drop — don't forward to on_pcm, don't account.
                        continue
                    if pcm and self._on_pcm is not None:
                        try:
                            self._on_pcm(pcm)
                        except Exception as e:  # pragma: no cover
                            logger.warning("on_pcm raised: %s", e)
                    self._account_pcm(pcm)
                    continue
                # text frame — JSON status
                try:
                    evt = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                msg_type = evt.get("type")
                req_id = evt.get("request_id")
                turn_id = self._sub_to_turn.get(req_id, "")
                ts = self._turns.get(turn_id)

                if msg_type == "audio_start":
                    # New sub is streaming; PCM frames belong to it until
                    # audio_end / cancelled.
                    self._current_sub = req_id
                    if ts is not None:
                        ts.audio_started = True
                        if ts.audio_started_at is None:
                            ts.audio_started_at = asyncio.get_running_loop().time()
                        ts.sub_audio_started_at[req_id] = asyncio.get_running_loop().time()
                        # Timing: speak_chunk → audio_start (TTS first byte).
                        sent_at = ts.sub_sent_at.get(req_id)
                        if sent_at is not None:
                            first_byte_ms = int((ts.sub_audio_started_at[req_id] - sent_at) * 1000)
                            log_timing(logger, "TTS", "audio_start", first_byte_ms,
                                       sub=req_id)
                    if self._on_audio_start is not None:
                        try:
                            await self._on_audio_start({**evt, "turn_id": turn_id})
                        except Exception as e:  # pragma: no cover
                            logger.warning("on_audio_start raised: %s", e)
                elif msg_type == "audio_end":
                    if self._current_sub == req_id:
                        self._current_sub = None
                    self._cancelled_subs.discard(req_id)  # tidy up
                    if ts is not None:
                        ts.sub_ids_active.discard(req_id)
                        if not ts.sub_ids_active:
                            ts.finished = True
                        # Timing: audio_start → audio_end (synthesis duration).
                        started_at = ts.sub_audio_started_at.get(req_id)
                        if started_at is not None:
                            synth_ms = int((asyncio.get_running_loop().time() - started_at) * 1000)
                            log_timing(logger, "TTS", "audio_end", synth_ms,
                                       sub=req_id, dur=f"{synth_ms}ms")
                    if self._on_audio_end is not None:
                        try:
                            await self._on_audio_end({**evt, "turn_id": turn_id})
                        except Exception as e:  # pragma: no cover
                            logger.warning("on_audio_end raised: %s", e)
                elif msg_type == "cancelled":
                    if self._current_sub == req_id:
                        self._current_sub = None
                    self._cancelled_subs.discard(req_id)
                    if ts is not None:
                        ts.sub_ids_active.discard(req_id)
                        ts.finished = True
                    if self._on_cancelled is not None:
                        try:
                            await self._on_cancelled({**evt, "turn_id": turn_id})
                        except Exception as e:  # pragma: no cover
                            logger.warning("on_cancelled raised: %s", e)
        except websockets.ConnectionClosed:
            return

    def _account_pcm(self, pcm: bytes) -> None:
        """Update audio_played_ms for whichever turn is currently audio-playing."""
        if not pcm:
            return
        # samples = bytes / 2 (PCM16); ms = samples * 1000 / sample_rate
        added_ms = (len(pcm) // 2) * 1000 // self.sample_rate_hz
        # Attribute the bytes to whichever turn most recently emitted audio_start
        # and is not yet finished. Multiple turns shouldn't be playing at once.
        for ts in self._turns.values():
            if ts.audio_started and not ts.finished:
                ts.audio_played_ms += added_ms
                return
