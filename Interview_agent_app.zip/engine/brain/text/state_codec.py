"""State (de)serialization + integrity signing for the stateless text tier.

The text interview's live state is held in the CANDIDATE'S BROWSER between turns
and posted back with each turn; Redis is written only on phase transitions /
explicit Save / end (to keep it cool). So the state blob crosses a trust
boundary — it is HMAC-signed with a server secret and verified on every turn, so
a candidate can't tamper with the transcript, the pool cursor, or the phase.

Two concerns, kept separate:
  - state_to_jsonable / state_from_jsonable — the SessionState fields that carry
    interview continuity (voice/audio/VAD fields are dropped: meaningless here).
  - sign_blob / verify_blob — HMAC wrapper around the whole {state, tracker,
    carry} blob.
The CadenceTracker overlay is serialized by CadenceTracker.to_snapshot/
restore_snapshot; the whole-engine blob is assembled by TextTurnEngine.snapshot.
"""
from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any, Optional

from engine.brain.contracts.session_state import (
    CandidateProfile,
    SessionState,
    turn_from_jsonable,
    turn_to_jsonable,
)

STATE_BLOB_VERSION = 1


# ── SessionState ⇆ dict (text-relevant fields only) ─────────────────────────
def state_to_jsonable(state: SessionState) -> dict:
    """The semantically load-bearing SessionState fields for text continuity.
    Drops the whole live-audio/VAD block and TTS calibration —
    all meaningless for a typed interview."""
    p = state.candidate_profile
    return {
        "turns": [turn_to_jsonable(t) for t in state.turns],
        "candidate_profile": {
            "name": p.name,
            "role": p.role,
            "resume_summary": p.resume_summary,
            "extra_notes": p.extra_notes,
        },
        "phase": state.phase,
        "phase_started_at_ms": state.phase_started_at_ms,
        "rolling_summary": state.rolling_summary,
        "cost_so_far_usd": state.cost_so_far_usd,
        "llm_usage": state.llm_usage,
    }


def state_from_jsonable(d: dict) -> SessionState:
    """Rebuild a SessionState from state_to_jsonable(). session_id is left to
    default (uuid4); the engine rebinds it to the Tracer's session id on
    restore so events + state describe the same interview."""
    cp = d.get("candidate_profile") or {}
    st = SessionState(
        candidate_profile=CandidateProfile(
            name=cp.get("name", "Candidate"),
            role=cp.get("role", "Engineer"),
            resume_summary=cp.get("resume_summary", ""),
            extra_notes=cp.get("extra_notes", ""),
        ),
        phase=d.get("phase", "warm_up"),
        phase_started_at_ms=int(d.get("phase_started_at_ms", 0) or 0),
        rolling_summary=d.get("rolling_summary", ""),
    )
    st.turns = [turn_from_jsonable(t) for t in (d.get("turns") or [])]
    st.cost_so_far_usd = float(d.get("cost_so_far_usd", 0.0) or 0.0)
    st.llm_usage = d.get("llm_usage") or {}
    return st


# ── HMAC integrity wrapper (browser-held blob crosses a trust boundary) ─────
def _canonical(payload: dict) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sign_blob(payload: dict, secret: str) -> dict:
    """Wrap a state payload with an HMAC-SHA256 signature. The signed body is
    carried as an OPAQUE STRING (`payload` is the canonical JSON text, not a
    nested object) and the signature is over those exact bytes.

    Why a string and not a nested object: the browser parses the blob and
    re-JSON.stringifies it to re-post each turn. JavaScript has no int/float
    distinction, so a whole-number float in the state (a Turn's confidence=1.0,
    cost_so_far_usd=0.0) collapses 1.0→1 / 0.0→0 on the round-trip — which would
    change the canonical form the server re-hashes and break every signature.
    Signing a STRING makes the signed bytes travel through the browser verbatim
    (JSON.stringify never touches the characters inside a string), so the HMAC is
    stable regardless of number reformatting."""
    body = _canonical(payload).decode("utf-8")
    sig = hmac.new(secret.encode("utf-8"), body.encode("utf-8"), hashlib.sha256).hexdigest()
    return {"v": STATE_BLOB_VERSION, "payload": body, "sig": sig}


def verify_blob(signed: Any, secret: str) -> Optional[dict]:
    """Return the parsed inner payload iff the signature validates, else None
    (caller treats a None as tampering / corruption and refuses the turn).
    Verifies over the exact transported string, then parses it. Constant-time
    compare."""
    if not isinstance(signed, dict):
        return None
    body = signed.get("payload")
    sig = signed.get("sig")
    if not isinstance(body, str) or not isinstance(sig, str):
        return None
    expect = hmac.new(secret.encode("utf-8"), body.encode("utf-8"), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(sig, expect):
        return None
    try:
        return json.loads(body)
    except (ValueError, TypeError):
        return None
