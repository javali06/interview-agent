"""TextTurnEngine — production audio-free discrete-turn interviewer.

Generalises the feasibility spike (scratchpad/spike_text_turn.py) into a
reusable engine and adds EVAL-COMPATIBLE event emission: it emits, via the
injected Tracer, the same events the post-interview sectioner
(features/eval/sectioner.py) keys on — with byte-identical payload keys copied
from the Director / LatencyOrchestrator emit sites — so a text interview parses
into the identical phase → segment tree a voice interview does.

It mirrors the AUDIO-FREE essence of the Director's post-STT flow
(director._run_post_stt_agents: verifier + guardrail in PARALLEL → priority
merge guardrail>verifier → follow-up-cap → pool-pop → advance) plus the
YES-branch dispatch (build_context → QuestionAgent.run), for ONE turn on demand.

Public surface:
  eng = TextTurnEngine(plan=…, candidate=…, tracer=…, slow_llm=…, fast_llm=…,
                       slow_model=…, fast_model=…, max_follow_ups=1)
  report = await eng.run_one_turn(candidate_text)   # -> dict
  eng.state    # the live SessionState  (the NEXT task serializes these)
  eng.tracker  # the live CadenceTracker

Does NOT touch the Director, orchestrator, or any Stream-A component.
"""
from __future__ import annotations

import asyncio
import os
import uuid
from time import monotonic
from typing import Any, Optional

from engine.brain.agents.guardrail_agent import GuardrailAgent
from engine.brain.agents.question_agent import QuestionAgent
from engine.brain.agents.verifier_agent import VerifierAgent
from engine.brain.cadence.schema import CadencePlan
from engine.brain.contracts.events import EventKind
from engine.brain.contracts.session_state import (
    CandidateProfile,
    SessionState,
    Speaker,
    Turn,
)
from engine.brain.core.cadence_tracker import CadenceTracker, TickDecision
from engine.brain.core.conversation_context import build_context
from engine.brain.llm import LLMClient
from engine.brain.observability import Tracer

# Verbatim copy of director._GUARDRAIL_REASK_THINK (director.py:61-70). Routed
# into the per-turn <think> briefing (via verifier_instruction) on a guardrail
# trip so the AI acknowledges-and-re-asks through the NORMAL dispatch path —
# exactly what the Director does after a scrub.
_GUARDRAIL_REASK_THINK = (
    "The candidate just said something that can't be addressed, so it has "
    "been intentionally left out of the transcript — that is why there is no "
    "candidate message right before this note (you are not speaking twice in "
    "a row by mistake). In your reply, briefly and warmly acknowledge that "
    "you can't address what they just said and won't be engaging with it, "
    "then re-ask the current interview question as if asking it fresh and "
    "continue normally. Do NOT repeat, quote, paraphrase, or guess what they "
    "said."
)

# Verifier intents that mean "this turn did NOT get us an answer to the current
# pool question, and the AI is about to re-ask it". They share ONE budget
# (policy.max_follow_ups_per_question): the cap is "how many times do we re-ask
# THIS question before giving up", regardless of WHY the reply fell short —
# otherwise a candidate alternating between shallow and off-topic replies stalls
# for twice as long as the cap allows.
#
# Deliberately NOT here: asked_to_repeat / asked_for_time / clarifying_question
# (legitimate candidate needs — skipping their question for asking it would be
# hostile) and no_speech (silence has its own timer; counting it would burn
# questions during a mic/network outage).
_UNPRODUCTIVE_INTENTS = ("partial_answer", "off_topic", "not_applicable")

# Slow-LLM instruction used when an unproductive intent exhausts the budget.
# Keyed by the intent that hit the cap so the move-on line fits what the
# candidate actually did; all three mean "stop re-asking, take the next one".
_CAP_HIT_INSTRUCTION: dict[str, str] = {
    "partial_answer": (
        "Candidate's reply is still partial after the push for depth. "
        "Briefly acknowledge and ask the next question."
    ),
    "off_topic": (
        "The candidate has not engaged with this question after being steered "
        "back to it. Briefly and neutrally acknowledge what they said, then "
        "move on to the next question. Do NOT re-ask this question, do NOT "
        "comment on their not answering it, and do NOT reveal or hint at its "
        "answer."
    ),
    "not_applicable": (
        "The candidate is still on a previous topic after being steered back "
        "to this question. Briefly and neutrally acknowledge, then move on to "
        "the next question. Do NOT re-ask this question, do NOT comment on "
        "their not answering it, and do NOT reveal or hint at its answer."
    ),
}


class TextTurnEngine:
    def __init__(
        self,
        *,
        plan: CadencePlan,
        candidate: CandidateProfile,
        tracer: Tracer,
        slow_llm: LLMClient,
        fast_llm: Optional[LLMClient],
        slow_model: str,
        fast_model: str,
        max_follow_ups: int = 1,
        restore: Optional[dict] = None,
    ) -> None:
        self._plan = plan
        self._tracer = tracer
        self._slow_model = slow_model
        self._fast_model = fast_model
        self._max_follow_ups = max_follow_ups

        # Monotonic ms clock (no wall-clock — this engine is untimed by default;
        # the timestamps are only used to order Turns / stamp event payloads).
        self._t0 = monotonic()

        self.tracker = CadenceTracker(plan, now_ms_provider=self._now_ms)
        # Keep the SessionState's id == the Tracer's session id so the emitted
        # events and the in-memory state describe the SAME interview (the next
        # task serializes self.state / self.tracker).
        self.state = SessionState(
            session_id=tracer.session_id,
            candidate_profile=candidate,
            phase=self.tracker.current_phase_id,
            phase_started_at_ms=self._now_ms(),
        )

        # Slow LLM drives the substantive turn; fast LLM (optional) runs the
        # verifier + guardrail. Both agents are fail-open — a None fast_llm
        # simply means no verification (every turn dispatches fresh).
        self._question_agent = QuestionAgent(
            llm=slow_llm, model=slow_model, tracer=tracer,
            max_tokens=int(os.environ.get("SLOW_LLM_MAX_TOKENS", "2000")),
        )
        self._verifier_agent = (
            VerifierAgent(llm=fast_llm, model=fast_model, tracer=tracer)
            if fast_llm is not None else None
        )
        self._guardrail_agent = (
            GuardrailAgent(llm=fast_llm, model=fast_model, tracer=tracer)
            if fast_llm is not None else None
        )

        # Director-mirrored per-turn carry state. The counter spends the shared
        # follow-up budget across every _UNPRODUCTIVE_INTENTS verdict, not just
        # partial answers (the snapshot key stays `partial_count_current_q` for
        # blob compatibility — see snapshot()).
        self._unproductive_count_current_q = 0
        self._latest_verifier_instruction: Optional[str] = None
        self._latest_missing_tags: list[str] = []
        self._ended = False
        self._session_ended_emitted = False

        # DISPLAY transcript — a separate, append-only, NEVER-trimmed log of the
        # human-facing turns ({speaker, text, phase}). Distinct from state.turns
        # (the LLM working set, which IS trimmed at phase boundaries) and from
        # events.jsonl (the eval/audit record). This is what the candidate sees
        # and what a resume reloads, so it must carry the WHOLE conversation.
        self.transcript: list[dict[str, Any]] = []

        if restore:
            # Resume: overlay saved state/tracker/carry onto the fresh build and
            # do NOT re-emit SESSION_STARTED (the interview's events.jsonl already
            # opened; the restored turns continue the same record).
            self._apply_restore(restore)
        else:
            # ── EVENT: SESSION_STARTED — the sectioner opens the interview's
            # first phase on this (reads payload.initial_phase). Shape copied
            # from interview_session.py:758.
            self._tracer.event(
                EventKind.SESSION_STARTED,
                session_id=str(self.state.session_id),
                candidate_name=candidate.name,
                role=candidate.role,
                initial_phase=self.tracker.current_phase_id,
                slow_model=slow_model,
                fast_model=fast_model,
            )

    # ── state (de)serialization — the stateless-tier snapshot/resume ──────
    def snapshot(self) -> dict:
        """The full resumable engine state: SessionState + CadenceTracker overlay
        + the Director-mirrored per-turn carry. Held in the browser between
        turns; written to Redis on phase transition / Save / end. Sign it with
        state_codec.sign_blob before it leaves the server."""
        from engine.brain.text.state_codec import state_to_jsonable
        return {
            "state": state_to_jsonable(self.state),
            "tracker": self.tracker.to_snapshot(),
            "transcript": list(self.transcript),
            "carry": {
                # Key name kept for compatibility with signed blobs already held
                # by in-flight browsers; the value now counts every unproductive
                # verdict, not only partial answers.
                "partial_count_current_q": self._unproductive_count_current_q,
                "latest_verifier_instruction": self._latest_verifier_instruction,
                "latest_missing_tags": list(self._latest_missing_tags),
                "ended": self._ended,
                "session_ended_emitted": self._session_ended_emitted,
            },
        }

    def _apply_restore(self, restore: dict) -> None:
        from engine.brain.text.state_codec import state_from_jsonable
        self.state = state_from_jsonable(restore.get("state") or {})
        # Rebind the state's id to the Tracer's session id so events + state
        # keep describing the SAME interview across a resume.
        self.state.session_id = self._tracer.session_id
        self.tracker.restore_snapshot(restore.get("tracker") or {})
        self.transcript = list(restore.get("transcript") or [])
        carry = restore.get("carry") or {}
        self._unproductive_count_current_q = int(
            carry.get("partial_count_current_q", 0) or 0
        )
        self._latest_verifier_instruction = carry.get("latest_verifier_instruction")
        self._latest_missing_tags = list(carry.get("latest_missing_tags") or [])
        self._ended = bool(carry.get("ended", False))
        self._session_ended_emitted = bool(carry.get("session_ended_emitted", False))

    # ── clock / small helpers ────────────────────────────────────────────
    def _now_ms(self) -> int:
        return int((monotonic() - self._t0) * 1000)

    @property
    def phase(self) -> str:
        return self.tracker.current_phase_id

    def _append_turn(self, speaker: Speaker, text: str) -> str:
        turn_id = str(uuid.uuid4())
        self.state.turns.append(
            Turn(turn_id=turn_id, speaker=speaker, text=text,
                 start_ms=self._now_ms(), end_ms=self._now_ms())
        )
        return turn_id

    def _has_prior_ai_turn(self) -> bool:
        return any(t.speaker == Speaker.AI for t in self.state.turns)

    def _scrub_last_candidate_turn(self) -> None:
        """Drop the most recent candidate Turn from LLM-visible history — the
        audio-free equivalent of director._scrub_last_candidate_turn. The
        events.jsonl audit trail (stt_final + guardrail_triggered) is left
        intact; only self.state.turns is edited."""
        for i in range(len(self.state.turns) - 1, -1, -1):
            if self.state.turns[i].speaker == Speaker.CANDIDATE:
                self.state.turns.pop(i)
                break

    # ── the one public coroutine ─────────────────────────────────────────
    async def run_one_turn(
        self, candidate_text: str, on_delta: Any = None,
    ) -> dict[str, Any]:
        """Append the candidate reply, run verifier+guardrail → merge → pool
        gating → advance, dispatch ONE AI turn, emit the eval events. Returns a
        dict describing the turn."""
        report: dict[str, Any] = {"candidate": candidate_text}

        # First-turn gate: only run the verifier if a prior AI question exists.
        run_agents = self._has_prior_ai_turn()
        self._append_turn(Speaker.CANDIDATE, candidate_text)
        # Full display transcript (never trimmed) — the candidate's line lands in
        # the phase they answered IN (before any advance below).
        self.transcript.append({
            "speaker": "candidate", "text": candidate_text,
            "phase": self.tracker.current_phase_id,
        })

        # ── EVENT: STT_FINAL — the sectioner's candidate-turn source
        # (_to_turn maps stt_final → a "candidate" Turn on payload.text). Add
        # source="text" so the record is unambiguously the typed answer.
        self._tracer.event(
            EventKind.STT_FINAL,
            text=candidate_text, source="text", confidence=1.0,
            audio_ms=0, segments=1,
        )

        is_specific = self.tracker.current_phase().uses_question_pool
        is_phase_transition = False

        # ── timed written-response (essay) phase: ONE-SHOT. The submission ends
        # the phase — no verifier/guardrail follow-up loop (a single long answer,
        # not a probed conversation). The essay is still a candidate turn in
        # events.jsonl, scored post-interview by the phase's rubric plugin.
        if run_agents and is_specific and self._is_written_response_phase():
            popped = self.tracker.pick_next_question()
            if popped is not None:
                report["popped_question"] = popped.id
            self._unproductive_count_current_q = 0
            self._latest_missing_tags = []
            self._latest_verifier_instruction = None
            report["written_response_submitted"] = True
            is_phase_transition = self._advance_or_end(report)
        # ── verifier + guardrail in PARALLEL, priority merge guardrail>verifier
        elif run_agents and (
            self._verifier_agent is not None or self._guardrail_agent is not None
        ):
            vctx = build_context(
                self.state, now_ms=self._now_ms(), tracker=self.tracker,
                prior_missing_tags=self._latest_missing_tags,
            )
            tasks: list[tuple[str, Any]] = []
            if self._verifier_agent is not None:
                tasks.append(("verifier", self._verifier_agent.verify(vctx)))
            if self._guardrail_agent is not None:
                tasks.append(("guardrail", self._guardrail_agent.classify(vctx)))

            # gather, never raise — each sub-agent has its own internal
            # fallback so the turn flow never aborts on a sub-agent error.
            results = await asyncio.gather(
                *(t[1] for t in tasks), return_exceptions=True,
            )
            by_label: dict[str, Any] = {}
            for (label, _), result in zip(tasks, results):
                if isinstance(result, BaseException):
                    continue
                by_label[label] = result

            guardrail = by_label.get("guardrail")
            if guardrail is not None and guardrail.triggered:
                # Guardrail supersedes the verifier for this turn: scrub the
                # adversarial turn from LLM-visible history, neutral re-ask, and
                # DISCARD the verifier verdict (no pool pop). The guardrail
                # agent already emitted GUARDRAIL_TRIGGERED.
                self._scrub_last_candidate_turn()
                self._latest_verifier_instruction = _GUARDRAIL_REASK_THINK
                self._latest_missing_tags = []
                report["guardrail_tripped"] = True
                report["guardrail_category"] = guardrail.category
            else:
                verifier = by_label.get("verifier")
                if verifier is not None:
                    is_phase_transition = self._apply_verifier(
                        verifier, is_specific, report,
                    )

        # ── dispatch: build_context + QuestionAgent.run (YES-branch essence) ──
        res = await self._dispatch_ai_turn(
            report, is_phase_transition=is_phase_transition, on_delta=on_delta,
        )
        ai_text = res.utterance

        # ── EVENT: SESSION_ENDED — once, after the terminal-phase farewell.
        if self._ended and not self._session_ended_emitted:
            self._session_ended_emitted = True
            self._tracer.event(
                EventKind.SESSION_ENDED,
                reason="pool_exhausted",
                phase=self.tracker.current_phase_id,
            )

        report["ai_text"] = ai_text
        report["phase"] = self.tracker.current_phase_id
        report["pool_remaining"] = self.tracker.questions_remaining()
        report["ended"] = self._ended
        report["ttft_ms"] = res.ttft_ms
        report["latency_ms"] = res.latency_ms
        return report

    # ── the opener (dispatch-only, no candidate/verifier turn) ────────────
    async def open_turn(self, on_delta: Any = None) -> dict[str, Any]:
        """Produce the AI's OPENER — the first question — with NO candidate input:
        the dispatch half of run_one_turn WITHOUT the verifier/candidate turn.
        Emits question_dispatched + ai_utterance (SESSION_STARTED was already
        emitted by the ctor). Used by the text service's /start endpoint."""
        report: dict[str, Any] = {}
        res = await self._dispatch_ai_turn(report, is_phase_transition=False, on_delta=on_delta)
        report["ai_text"] = res.utterance
        report["phase"] = self.tracker.current_phase_id
        report["pool_remaining"] = self.tracker.questions_remaining()
        report["ended"] = self._ended
        report["ttft_ms"] = res.ttft_ms
        report["latency_ms"] = res.latency_ms
        return report

    # ── shared YES-branch dispatch (run_one_turn + open_turn) ─────────────
    async def _dispatch_ai_turn(
        self, report: dict[str, Any], *, is_phase_transition: bool, on_delta: Any = None,
    ) -> Any:
        """build_context → persist the <think> directive → QuestionAgent.run →
        emit question_dispatched + ai_utterance. Returns the QuestionAgent result
        (its `.utterance` is the AI text; `.ttft_ms`/`.latency_ms` feed the report).
        Factored out verbatim from run_one_turn so the opener reuses it without a
        candidate/verifier turn."""
        self.state.phase = self.tracker.current_phase_id
        qctx = build_context(
            self.state, now_ms=self._now_ms(), tracker=self.tracker,
            verifier_instruction=self._latest_verifier_instruction,
            is_phase_transition=is_phase_transition,
            prior_missing_tags=self._latest_missing_tags,
        )
        # LOAD-BEARING: persist the tracker's <think> directive as an assistant
        # Turn (message_role="assistant") — the Director does this via
        # _persist_runtime_tags (director.py:2385) and the QuestionAgent reads
        # it back out of conversation history. Without it the "ask THIS pool
        # question next" directive never reaches the slow LLM.
        if qctx.think_content:
            think_turn = Turn(
                turn_id=f"rt-think-{self._now_ms()}",
                speaker=Speaker.UNKNOWN,
                text=f"<think>\n{qctx.think_content}\n</think>",
                message_role="assistant",
            )
            self.state.turns.append(think_turn)
            qctx.recent_turns.append(think_turn)  # this dispatch sees it too

        # Stream the (tag-stripped) tokens to on_delta as they arrive; a None
        # on_delta means non-streaming (the caller reads res.utterance at the end).
        on_char = on_delta if on_delta is not None else (lambda _c: None)
        res = await self._question_agent.run(
            qctx,
            on_utterance_char=on_char,
            on_first_token=lambda: None,
            cancel_event=asyncio.Event(),
        )
        ai_text = res.utterance

        # ── EVENT: QUESTION_DISPATCHED — emit once, when a FRESH specific-pool
        # question is first presented (mirrors director.py:1104-1130). The
        # sectioner opens a new question segment on this marker, so it MUST
        # precede the AI utterance below. mark_..._presented() returns True
        # exactly once per question id (follow-up re-pushes return False).
        if self.tracker.current_phase().uses_question_pool:
            fresh = self.tracker.mark_current_question_presented()
            if fresh:
                q = self.tracker.peek_next_question()
                if q is not None:
                    self._tracer.event(
                        "question_dispatched",
                        phase_id=self.tracker.current_phase_id,
                        question_id=q.id,
                        question_text=q.text,
                        topic=q.topic,
                        difficulty=q.difficulty,
                        coverage_tags=list(q.coverage_tags),
                    )
                    report["dispatched_question"] = q.id

        # ── EVENT: AI_UTTERANCE — the sectioner's AI-turn source (attaches to
        # the current segment). Shape copied from orchestrator.py:909.
        ai_turn_id = str(uuid.uuid4())
        self.state.turns.append(
            Turn(turn_id=ai_turn_id, speaker=Speaker.AI, text=ai_text,
                 start_ms=self._now_ms(), end_ms=self._now_ms(), confidence=1.0)
        )
        self._tracer.event(
            EventKind.AI_UTTERANCE,
            text=ai_text, text_full=ai_text,
            turn_id=ai_turn_id, was_barged_in=False,
        )
        # Full display transcript (never trimmed) — the AI's line in the phase it
        # was dispatched for (post-advance).
        self.transcript.append({
            "speaker": "ai", "text": ai_text, "phase": self.tracker.current_phase_id,
        })
        return res

    # ── verifier verdict → pool gating → advance (director essence) ───────
    def _apply_verifier(
        self, verifier: Any, is_specific: bool, report: dict[str, Any],
    ) -> bool:
        """Apply the verifier verdict: follow-up cap → pool pop → advance/end.
        Returns True iff a phase transition was applied this turn."""
        effective_intent = verifier.intent
        instruction = verifier.instruction
        report["verifier_intent"] = verifier.intent
        report["verifier_missing_tags"] = list(verifier.missing_tags)

        # Unproductive reply (shallow, off-topic, or still on a prior topic) —
        # all three re-ask the SAME question, so all three spend from the one
        # follow-up budget. Without this an off_topic/not_applicable candidate
        # loops on a question forever: neither intent pops the pool, and an
        # untimed text plan has no wall clock to break the tie.
        if effective_intent in _UNPRODUCTIVE_INTENTS and is_specific:
            self._unproductive_count_current_q += 1
            if self._unproductive_count_current_q > self._max_follow_ups:
                report["effective_intent"] = (
                    f"partial_answer_skip (cap hit, from {effective_intent})"
                )
                # Emit BEFORE the promotion so the trace records which intent
                # actually exhausted the budget, not the synthetic skip.
                self._tracer.event(
                    "partial_answer_skip_auto_promoted",
                    from_intent=effective_intent,
                    partial_count=self._unproductive_count_current_q,
                    max_follow_ups=self._max_follow_ups,
                    phase=self.tracker.current_phase_id,
                )
                instruction = _CAP_HIT_INSTRUCTION[effective_intent]
                effective_intent = "partial_answer_skip"
            elif effective_intent == "partial_answer" and verifier.missing_tags:
                # Only a partial answer carries coverage gaps worth re-probing;
                # an off-topic reply addressed none of them, so scoping the next
                # verification to "what's still missing" would be meaningless.
                self._latest_missing_tags = list(verifier.missing_tags)

        self._latest_verifier_instruction = instruction

        # Candidate finished the closing exchange ("no questions, thanks"). The
        # Director ends the interview after the farewell; we do the same — end
        # now so this turn still dispatches a warm sign-off, then SESSION_ENDED
        # fires. Without this, a specific-pool wrap-up phase whose question the
        # verifier scores wrap_up_complete (not "answered") never pops → the
        # tracker STAYs → the closing question re-asks in a loop.
        if effective_intent == "wrap_up_complete":
            self.tracker.end(reason="wrap_up_complete")
            self._ended = True
            report["ended"] = True
            report["effective_intent"] = "wrap_up_complete (end)"
            return False

        if effective_intent in (
            "answered", "default_answered", "partial_answer_skip",
        ) and is_specific:
            popped = self.tracker.pick_next_question()
            if popped is not None:
                report["popped_question"] = popped.id
            self._unproductive_count_current_q = 0
            self._latest_missing_tags = []

        # ── advance the phase when the pool is exhausted (untimed plan) ──
        return self._advance_or_end(report)

    def _is_written_response_phase(self) -> bool:
        """True when the current phase is a timed written-response (essay) phase —
        a one-shot submission that ends the phase with no verifier follow-up."""
        return getattr(self.tracker.current_phase(), "written_response", None) is not None

    def _advance_or_end(self, report: dict[str, Any]) -> bool:
        """Advance the phase (or end the interview) when the current pool is
        exhausted — the untimed-plan transition apply block, shared by the
        verifier path and the written-response one-shot path. Returns True iff a
        phase transition was applied this turn."""
        decision = self.tracker.check_phase_budget()
        if decision == TickDecision.ADVANCE:
            frm = self.tracker.current_phase_id
            nxt = self._plan.next_phase_id(frm)
            marker = self.tracker.render_transition_marker(frm, nxt)
            # ── Persistent phase-history truncation (mirror director.py:860-872) ──
            # On EVERY phase change, trim state.turns so only the most recent turn
            # before the marker survives. Going forward the slow LLM + verifier read
            # ctx.recent_turns and naturally see ONLY the current phase plus that one
            # anchor turn — no prior-phase transcript, exactly like the voice Director
            # — with no per-turn slicing logic. events.jsonl keeps the FULL history
            # (emitted per turn via the tracer), so eval and the admin trace are
            # unaffected; only the runtime SessionState is trimmed.
            if self.state.turns:
                self.state.turns = self.state.turns[-1:]
            self.state.turns.append(
                Turn(turn_id=str(uuid.uuid4()), speaker=Speaker.UNKNOWN,
                     text=marker, message_role="system")
            )
            self.tracker.advance(reason="pool_exhausted")
            self.state.phase = self.tracker.current_phase_id
            self.state.phase_started_at_ms = self._now_ms()
            report["advanced_to"] = self.tracker.current_phase_id
            # ── EVENT: PHASE_CHANGED — the APPLIED marker (NO queued flag —
            # the sectioner skips queued pre-announcements). Shape copied from
            # director.py:763.
            self._tracer.event(
                EventKind.PHASE_CHANGED,
                from_phase=frm, to_phase=self.tracker.current_phase_id,
                reason="natural",
            )
            return True
        if decision == TickDecision.END:
            self.tracker.end(reason="pool_exhausted")
            self._ended = True
            report["ended"] = True
        return False
