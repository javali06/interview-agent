"""Text-only interview brain — an audio-free, discrete-turn engine.

`TextTurnEngine` runs ONE interviewer turn per candidate reply without the
Director tick-loop, LatencyOrchestrator, or any STT/VAD/TTS. It reuses the
proven brain internals (QuestionAgent + VerifierAgent + GuardrailAgent +
CadenceTracker + build_context + SessionState) and emits the SAME structured
events the post-interview eval sectioner (features/eval/sectioner.py) consumes,
so a text interview scores through the existing evaluation pipeline unchanged.
"""
from __future__ import annotations

from engine.brain.text.turn_engine import TextTurnEngine

__all__ = ["TextTurnEngine"]
