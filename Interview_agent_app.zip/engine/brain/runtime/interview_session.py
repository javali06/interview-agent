"""InterviewSession — the top-level façade.

The only thing `orchestrator_new.live_main` imports. Wires:
  - SessionStore + EventBus + Tracer + JsonlEventLog
  - STT/VAD/TTS clients
  - Sub-agents (Question, Filler, Apology)
  - LatencyOrchestrator
  - Director
  - Mic-pump + speaker-sink (we receive these as protocols)

Lifecycle: __aenter__ connects everything, runs Kokoro pre-warm. run_until_signal()
ticks until cancelled. __aexit__ tears down in the order from §8E.4.
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, AsyncIterator
from uuid import UUID, uuid4

from engine.brain.agents import (
    ApologyAgent,
    FillerAgent,
    GuardrailAgent,
    PhaseOverrideAgent,
    QuestionAgent,
    VerifierAgent,
)
from engine.brain.contracts.audio import (
    FRAME_BYTES,
    FRAME_MS,
    SAMPLE_RATE_HZ,
    AudioSink,
    AudioSource,
)
from engine.brain.contracts.events import EventKind
from engine.brain.cadence import CadencePlan, default_cadence
from engine.brain.core.adaptive import AdaptiveConfig
from engine.brain.contracts.session_state import (
    AIActivityState,
    CandidateProfile,
    SessionState,
    Turn,
    VadState,
    turn_from_jsonable,
    turn_to_jsonable,
)
from engine.brain.core.cadence_tracker import CadenceTracker
from engine.brain.core.conversation_context import build_context
from engine.brain.core.director import Director, build_coding_phase_started_payload
from engine.brain.core.event_bus import EventBus
from engine.brain.core.latency import LatencyConfig, LatencyOrchestrator
from engine.brain.core.policy import PolicyConfig
from engine.brain.core.policy.barge_in_guard import (
    BargeInConfig,
    BargeInDecision,
    BargeInInputs,
    decide_barge_in,
)
from engine.brain.core.session_store import SessionStore
from engine.brain.llm import LLMClient
from engine.brain.observability import JsonlEventLog, Tracer
from engine.brain.observability.timing import log_timing
from engine.brain.observability.langfuse_client import (
    flush as langfuse_flush,
    get_langfuse,
)
from engine.brain.streamA_bridge import (
    AECProcessor,
    GroqSTTClient,
    STTClient,
    TTSClient,
    VADClient,
)

logger = logging.getLogger(__name__)


@dataclass
class SessionConfig:
    candidate_profile: CandidateProfile
    # Cadence plan — defines phases, durations, question pools. If None,
    # the session uses the built-in 10-second testing cadence (see
    # stream_b_new.cadence.default_cadence). live_main resolves this from
    # CLI flags (--cadence-path / --cadence-description) before
    # constructing SessionConfig.
    cadence: CadencePlan | None = None

    # Rubric thresholds for adaptive-difficulty `specific` phases. Only consulted
    # when a phase sets `adaptive_difficulty: true`; harmless otherwise. Built
    # from the `adaptive:` block of system_config.yaml.
    adaptive: AdaptiveConfig = field(default_factory=AdaptiveConfig)

    # Stream A endpoints (VAD + TTS — and STT iff stt_provider == "streamA")
    stt_url: str = "ws://localhost:8010/stt"
    vad_url: str = "ws://localhost:8011/vad"
    tts_url: str = "ws://localhost:8012/tts"
    tts_sample_rate_hz: int = 16_000

    # STT provider:
    #   "groq"   — Groq's whisper REST API (~100ms response, fast TTFT)
    #   "azure"  — Azure Speech continuous recognition (streaming partials,
    #              built-in VAD, ~$1/audio-hour)
    #   "streamA" — bundled Stream A faster-whisper WebSocket
    stt_provider: str = "groq"
    stt_model: str = "whisper-large-v3"   # 12% WER, $0.04/hr, fast
    stt_language: str = "en"

    # TTS provider:
    #   "kokoro" — Stream A's local Kokoro subprocess (default; offline,
    #              free, ~1.5x realtime CPU synthesis)
    #   "azure"  — Azure Neural TTS direct (no subprocess; sub-realtime,
    #              ~$16/1M chars, hundreds of voices)
    tts_provider: str = "kokoro"

    # Azure Speech credentials (used iff stt_provider == "azure" or
    # tts_provider == "azure"). Region is the short code, e.g. "eastus".
    azure_speech_key: str | None = None
    azure_speech_region: str = "eastus"
    azure_speech_voice: str = "en-US-AvaNeural"
    stt_no_speech_threshold: float = 0.6  # drop transcripts whose mean
                                           # per-segment no_speech_prob exceeds
                                           # this (Whisper hallucination guard)
    # Pre-roll ring buffer length in ms. Continuously holds the last N
    # ms of mic PCM so that when VAD finally fires speech_start (after
    # its ~120ms hysteresis + WS hop + handler latency) we can recover
    # the head-of-utterance audio that arrived BEFORE the speech_start
    # event. Without it the first word or two of every utterance gets
    # clipped. Lowered from 300 to 50 ms now that AEC is in place —
    # with the AEC cancelling the AI's voice in the mic input, the pre-
    # roll ring no longer needs to swallow speaker echo, and the
    # smaller window avoids the spurious-noise bugs the bigger buffer
    # was causing.
    stt_preroll_ms: int = 50

    # Models (NEW_STREAM_B.md §14 Q1)
    # Models on Groq (default). Both slow and fast share one Groq endpoint;
    # they differ only in model id + token budget. Override via CLI or
    # SessionConfig if you want to use OpenRouter / Anthropic / etc.
    slow_model: str = "openai/gpt-oss-120b"        # substantive reasoning
    # Token budget for the slow LLM. Reasoning models (gpt-oss-120b) burn
    # most of it inside <think>…</think>, which is stripped before TTS —
    # too low (≤~1500) risks zero spoken output. Sourced from
    # system_config.yaml llm.slow.max_tokens (env SLOW_LLM_MAX_TOKENS on cloud).
    slow_llm_max_tokens: int = 2000
    fast_model: str = "meta-llama/llama-3.1-8b-instruct"
    # ↑ OpenRouter model id. The fast LLM now routes via OpenRouter so we
    # can pin provider=Groq behind OpenRouter's rate-limit and fallback
    # machinery instead of hitting Groq's direct API and eating its raw
    # 429s. Groq's native model id (`llama-3.1-8b-instant`) is only valid
    # against api.groq.com — `meta-llama/llama-3.1-8b-instruct` is the
    # equivalent name OpenRouter exposes for the same Groq endpoint.
    use_filler: bool = True
    use_canned_filler: bool = False
    # Prewarm is OFF by default — it's audible (a brief "Hi") and the Kokoro
    # cold-start is hidden behind the first slow LLM call anyway. Pass
    # --prewarm to enable.
    prewarm_kokoro: bool = False

    # Tick
    tick_interval_ms: int = 500

    # Latency
    # Filler ladder — see LatencyOrchestrator.start_turn dispatch matrix.
    filler_threshold_ms: int = 5000          # fast-LLM "thinking" filler if slow stalls
    apology_threshold_ms: int = 10000        # canned apology if slow LLM is dead
    strike_threshold: int = 3

    # Policy
    endpoint_tail_ms: int = 600
    silence_prompt_ms: int = 15000   # 15s — natural thinking pauses can run 8-12s

    # Follow-up cap on specific-mode pool questions. After this many
    # consecutive "push for depth" turns on the same pool question, the
    # verifier emits `partial_answer_skip` instead of another
    # `partial_answer`, the tracker pops the question, and the slow LLM
    # moves on. Default 1 → one push, then skip. Use 0 to disable
    # follow-ups entirely (any partial = immediate skip); higher values
    # let the AI push multiple times before giving up.
    max_follow_ups_per_question: int = 1

    # Barge-in + STT-side noise rejection (one shared threshold).
    # Used in TWO places:
    #   - BargeInConfig.warmup_ms — defer barge-in cancel by this long
    #     after speech_start; if endpoint fires inside the window it
    #     was noise and the AI keeps speaking.
    #   - Director.noise_threshold_ms — at VAD endpoint, utterances
    #     whose duration was below this get rejected as cough / click,
    #     no Turn appended, no LLM kicked, silence-timer rewound.
    # Set via BARGE_IN_WARMUP_MS env var.
    audio_end_grace_ms: int = 200
    barge_in_warmup_ms: int = 1500

    # Acoustic Echo Cancellation (Exp #2) — speaker-tolerant mode with
    # mid-sentence barge-in re-enabled.
    # When `aec_enabled=True`, every mic frame is run through Chromium's
    # WebRTC AEC3 (via livekit.rtc.AudioProcessingModule) before reaching
    # VAD/STT, using the AI's TTS PCM as the reference signal. Result: the
    # AI's voice gets digitally subtracted from the mic input, so VAD only
    # fires on real candidate speech — meaning barge-in works without
    # headphones.
    aec_enabled: bool = False
    # Round-trip mic→speaker delay in ms. AEC needs this to align the
    # captured echo with the reference signal. 50 ms is a sane default for
    # a MacBook with sounddevice. Re-tune per device only if measured ERLE
    # is poor — AEC3's filter is 100-300 ms so ±50 ms is tolerated.
    aec_stream_delay_ms: int = 50
    # NS / HPF inside the AEC stack. Cheap, helpful, on by default.
    # AGC is OFF by default — Whisper handles level variation and AGC
    # adds gain pumping on residual TTS that hurts quality.
    aec_noise_suppression: bool = True
    aec_high_pass_filter: bool = True
    aec_auto_gain_control: bool = False

    # Observability
    event_log_path: Path = field(default_factory=lambda: Path("/tmp/integration/events.jsonl"))

    # Provider config (OpenAI-compatible base URL; works for Groq / OpenRouter
    # / OpenAI proper / any compat-shim provider).
    llm_api_key: str = ""
    llm_base_url: str = "https://api.groq.com/openai/v1"

    # Optional: route the SLOW LLM through a different provider than the fast
    # one. Useful when Groq's TPM cap on `gpt-oss-120b` rate-limits the slow
    # path but we still want Groq's TTFT for fillers/verifier/override. Leave
    # both None to keep slow + fast on the same client (the default).
    slow_llm_api_key: str | None = None
    slow_llm_base_url: str | None = None
    # OpenRouter provider routing for the SLOW LLM (analogous to fast).
    # e.g. ["Groq"] forces gpt-oss-120b to the Groq-served route. Only
    # honoured when the slow base URL points at openrouter.ai.
    slow_llm_provider_order: list[str] | None = None

    # Optional: route the FAST LLM (verifier, phase-override, filler)
    # through a dedicated endpoint. The standard setup is OpenRouter
    # with provider=Groq forced via `fast_llm_provider_order` — this
    # gives us Groq's TTFT while sidestepping Groq's direct-API TPM
    # caps (which were causing cascading 429s on every candidate turn).
    # Leave all three None to share the main `llm_*` client.
    fast_llm_api_key: str | None = None
    fast_llm_base_url: str | None = None
    # OpenRouter provider routing: ordered list of providers OpenRouter
    # should prefer when serving the fast model. e.g. ["Groq"] forces
    # all fast-LLM traffic to Groq via OpenRouter; ["Groq", "Cerebras"]
    # falls back to Cerebras if Groq 5xx's. Only honoured when the fast
    # base URL points at openrouter.ai.
    fast_llm_provider_order: list[str] | None = None


@dataclass
class SessionResult:
    session_id: UUID
    n_turns: int
    n_fillers: int
    n_strikes_total: int


class InterviewSession:
    def __init__(
        self,
        *,
        config: SessionConfig,
        audio_source: AudioSource,
        audio_sink: AudioSink,
        session_id: UUID | None = None,
        # ── durable checkpoint / resume (feature B) ──
        # checkpoint_writer: async callable (phase_id, jsonable_turns) that
        # persists a phase-boundary snapshot to Redis. None disables writes
        # (local / ad-hoc runs). resume_checkpoint: a loaded checkpoint dict
        # (see app/coordination/interview_checkpoint) when this is a RESUME of
        # an interview whose runner was lost; None for a fresh run.
        checkpoint_writer=None,
        resume_checkpoint: dict | None = None,
    ) -> None:
        self._cfg = config
        self._source = audio_source
        self._sink = audio_sink
        self._checkpoint_writer = checkpoint_writer
        self._resume_checkpoint = resume_checkpoint

        # ── start-time bookkeeping ─────────────────────
        # Initialized to None here so `_elapsed_ms` returns 0 until the
        # event loop actually starts (via run_until_signal). Set BEFORE
        # tracker construction because the tracker calls _elapsed_ms()
        # in its __init__ to record phase_started_at_ms.
        self._loop_started: float | None = None
        # Cumulative-time offset (ms) added to every _elapsed_ms() reading.
        # 0 for a fresh interview. On a durable RESUME it's the total interview
        # time that had elapsed when the interrupted phase STARTED (persisted in
        # the checkpoint as `elapsed_ms_at_phase_entry`), so the recorded total
        # continues cumulatively across the crash instead of restarting at 0.
        # The per-phase clock still re-anchors to "now" on resume (fresh phase
        # budget) — this offset only lifts the absolute timeline. Pre-crash
        # partial-phase time is intentionally dropped (we replace the phase).
        self._resume_elapsed_offset_ms: int = int(
            (resume_checkpoint or {}).get("elapsed_ms_at_phase_entry", 0) or 0
        )

        # ── cadence + tracker ─────────────────────────
        self._cadence: CadencePlan = config.cadence or default_cadence()
        # Tracker uses _elapsed_ms which returns 0 until the loop starts.
        # The tracker re-anchors phase_started_at_ms to the real "now"
        # at run_until_signal time so the first phase starts counting
        # from when the interview actually begins, not __init__ time.
        self._tracker = CadenceTracker(
            self._cadence,
            now_ms_provider=lambda: self._elapsed_ms(),
            adaptive_config=config.adaptive,
        )

        # ── state ─────────────────────────────────────
        # Caller-supplied session_id is preferred so it can match the
        # admin's candidate token (and thus the Langfuse session deep-link).
        # When None, generate a random uuid and log it so devs running
        # the CLI without --scheduled-token can still find their traces in
        # Langfuse's Sessions tab.
        resolved_session_id = session_id or uuid4()
        if session_id is None:
            logger.info(
                "[session] no session_id provided — using random uuid %s "
                "(search this in Langfuse Sessions to find traces)",
                resolved_session_id,
            )
        self._state = SessionState(
            session_id=resolved_session_id,
            candidate_profile=config.candidate_profile,
            phase=self._tracker.current_phase_id,
        )
        self._store = SessionStore(self._state)
        self._bus = EventBus()
        self._event_log = JsonlEventLog(config.event_log_path)
        self._tracer = Tracer(
            session_id=self._state.session_id,
            event_log=self._event_log,
            bus=self._bus,
        )

        # ── llm clients ───────────────────────────────
        # Slow LLM can optionally use a different provider than the fast
        # client (e.g., OpenAI for the slow path while Groq drives fillers
        # and verifier). When `slow_llm_base_url` / `slow_llm_api_key` are
        # both None we share one client across slow + fast.
        slow_base_url = config.slow_llm_base_url or config.llm_base_url
        slow_api_key = config.slow_llm_api_key or config.llm_api_key
        slow_extra: dict[str, Any] = {}
        if config.slow_llm_provider_order and "openrouter" in slow_base_url:
            # allow_fallbacks=False makes the order list AUTHORITATIVE: OpenRouter
            # tries only these providers (Groq → Baseten) and errors if none can
            # serve — instead of silently routing to a random slow provider
            # (DeepInfra etc.) that also handles gpt-oss reasoning inconsistently.
            slow_extra = {
                "provider": {
                    "order": list(config.slow_llm_provider_order),
                    "allow_fallbacks": False,
                }
            }
            logger.info(
                "[LLM] slow LLM routed via OpenRouter, provider order=%s (no fallbacks)",
                config.slow_llm_provider_order,
            )
        self._slow_llm = LLMClient(
            api_key=slow_api_key,
            base_url=slow_base_url,
            default_extra_body=slow_extra or None,
            tier="slow",
        )
        # Fast LLM: dedicated endpoint when `fast_llm_*` is configured
        # (typical setup: OpenRouter with provider=Groq forced via
        # `fast_llm_provider_order`). Falls back to the shared main client
        # otherwise. Provider routing is attached as `default_extra_body`
        # on the OpenAI client so every Verifier / PhaseOverride / Filler
        # call inherits it without per-agent changes.
        fast_base_url = config.fast_llm_base_url or config.llm_base_url
        fast_api_key = config.fast_llm_api_key or config.llm_api_key
        fast_extra: dict[str, Any] = {}
        if config.fast_llm_provider_order and "openrouter" in fast_base_url:
            # See slow LLM note: lock routing to the listed providers
            # (Groq → DeepInfra) so the verifier/phase-override tool-calls
            # don't land on a provider that honors forced tool_choice poorly.
            fast_extra = {
                "provider": {
                    "order": list(config.fast_llm_provider_order),
                    "allow_fallbacks": False,
                }
            }
            logger.info(
                "[LLM] fast LLM routed via OpenRouter, provider order=%s (no fallbacks)",
                config.fast_llm_provider_order,
            )
        fast_distinct = (
            fast_base_url != slow_base_url
            or fast_api_key != slow_api_key
            or bool(fast_extra)
        )
        if fast_distinct:
            self._fast_llm = LLMClient(
                api_key=fast_api_key,
                base_url=fast_base_url,
                default_extra_body=fast_extra or None,
                tier="fast",
            )
        else:
            self._fast_llm = self._slow_llm

        # ── STT client (Azure / Groq REST / Stream A WebSocket) ────
        if config.stt_provider == "azure":
            if not config.azure_speech_key:
                raise ValueError(
                    "stt_provider='azure' but no azure_speech_key set. "
                    "Set AZURE_SPEECH_KEY in App Settings."
                )
            from engine.brain.streamA_bridge.azure_stt_client import AzureSTTClient
            self._stt: STTClient | GroqSTTClient | "AzureSTTClient" = AzureSTTClient(
                api_key=config.azure_speech_key,
                region=config.azure_speech_region,
                language=config.stt_language,
                on_partial=self._on_stt_partial,
                on_final=self._on_stt_final,
                # Azure is now VAD-gated too (mirrors Groq): only speech-window
                # audio reaches the recognizer, with `preroll_ms` prepended at
                # speech_start so the VAD-hysteresis head isn't clipped.
                preroll_ms=config.stt_preroll_ms,
                no_speech_threshold=config.stt_no_speech_threshold,
                langfuse_session_id=str(self._state.session_id),
                langfuse_user_id=self._state.candidate_profile.name,
            )
            logger.info(
                "[STT] using Azure Speech (region=%s lang=%s) — Groq + "
                "Stream A STT are unused.",
                config.azure_speech_region, config.stt_language,
            )
        elif config.stt_provider == "groq":
            if not config.llm_api_key:
                raise ValueError(
                    "stt_provider='groq' but no llm_api_key set — "
                    "Groq STT shares the LLM key. Set GROQ_API_KEY in .env."
                )
            self._stt = GroqSTTClient(
                api_key=config.llm_api_key,
                model=config.stt_model,
                language=config.stt_language,
                base_url=config.llm_base_url,
                on_partial=self._on_stt_partial,
                on_final=self._on_stt_final,
                no_speech_threshold=config.stt_no_speech_threshold,
                # Mirror barge-in warm-up: if speech wasn't sustained
                # enough to interrupt the AI, we don't trust it enough
                # to transcribe either.
                min_utterance_ms=config.barge_in_warmup_ms,
                preroll_ms=config.stt_preroll_ms,
            )
            logger.info(
                "[STT] using Groq STT (model=%s, lang=%s) — Stream A's STT "
                "service on :8010 is unused.",
                config.stt_model, config.stt_language,
            )
        else:
            self._stt = STTClient(
                url=f"{config.stt_url}/{self._state.session_id}",
                on_partial=self._on_stt_partial,
                on_final=self._on_stt_final,
            )
            logger.info("[STT] using Stream A WebSocket STT (faster-whisper)")
        self._vad = VADClient(
            url=f"{config.vad_url}/{self._state.session_id}",
            on_event=self._on_vad_event,
        )
        # ── TTS client (Azure / Kokoro via Stream A) ───────────
        if config.tts_provider == "azure":
            if not config.azure_speech_key:
                raise ValueError(
                    "tts_provider='azure' but no azure_speech_key set. "
                    "Set AZURE_SPEECH_KEY in App Settings."
                )
            from engine.brain.streamA_bridge.azure_tts_client import AzureTTSClient
            self._tts = AzureTTSClient(
                api_key=config.azure_speech_key,
                region=config.azure_speech_region,
                voice=config.azure_speech_voice,
                sample_rate_hz=config.tts_sample_rate_hz,
                langfuse_session_id=str(self._state.session_id),
                langfuse_user_id=self._state.candidate_profile.name,
            )
            logger.info(
                "[TTS] using Azure Speech Neural TTS (voice=%s region=%s) "
                "— Stream A's TTS subprocess on :8012 is unused.",
                config.azure_speech_voice, config.azure_speech_region,
            )
        else:
            self._tts = TTSClient(
                url=f"{config.tts_url}/{self._state.session_id}",
                sample_rate_hz=config.tts_sample_rate_hz,
            )
            logger.info("[TTS] using Stream A WebSocket TTS (Kokoro local)")
        # Speaker pipe: TTSClient strips header → AudioSink plays.
        self._tts.set_callbacks(on_pcm=self._on_pcm)

        # ── sub-agents ────────────────────────────────
        self._question_agent = QuestionAgent(
            llm=self._slow_llm, model=config.slow_model, tracer=self._tracer,
            max_tokens=config.slow_llm_max_tokens,
        )
        if config.use_filler and not config.use_canned_filler:
            self._filler_agent: FillerAgent | None = FillerAgent(
                llm=self._fast_llm, model=config.fast_model, tracer=self._tracer,
            )
        elif config.use_filler and config.use_canned_filler:
            self._filler_agent = FillerAgent(
                llm=None, model="canned", tracer=self._tracer,
            )
        else:
            self._filler_agent = None
        # Apology recovery uses the fast LLM to write a context-aware
        # "sorry, could you repeat that?" line when the slow LLM stalls past
        # the apology threshold. Falls back to canned phrases if the fast LLM
        # is unavailable.
        self._apology_agent = ApologyAgent(
            tracer=self._tracer,
            llm=self._fast_llm,
            model=config.fast_model,
        )
        # Two fast-LLM auxiliaries — both default to benign behaviour on
        # failure so they never block the main loop.
        self._verifier_agent = VerifierAgent(
            llm=self._fast_llm, model=config.fast_model, tracer=self._tracer,
        )
        # Guardrail runs as its OWN fast-LLM agent (parallel to verifier +
        # override). Split out of the verifier because its old enum `reason`
        # broke Groq structured decoding on every verifier call; its tool now
        # uses a free-string category. Defaults to not-triggered on any error.
        # Model is pinned to a safety-tuned model INDEPENDENT of config.fast_model
        # (the verifier/apology/phase-override/filler agents below still use
        # config.fast_model, unaffected) — same fast-tier client/credentials
        # (OpenRouter, provider forced to Groq, which hosts this model), just a
        # different model string per call.
        self._guardrail_agent = GuardrailAgent(
            llm=self._fast_llm, model="openai/gpt-oss-safeguard-20b", tracer=self._tracer,
        )
        self._phase_override_agent = PhaseOverrideAgent(
            llm=self._fast_llm, model=config.fast_model, tracer=self._tracer,
        )

        # ── latency ───────────────────────────────────
        self._latency = LatencyOrchestrator(
            question_agent=self._question_agent,
            filler_agent=self._filler_agent,
            apology_agent=self._apology_agent,
            tts=self._tts,
            store=self._store,
            tracer=self._tracer,
            tracker=self._tracker,
            config=LatencyConfig(
                filler_threshold_ms=config.filler_threshold_ms,
                apology_threshold_ms=config.apology_threshold_ms,
                strike_threshold=config.strike_threshold,
            ),
            elapsed_ms_provider=self._elapsed_ms,
            # Lets the orchestrator wait for the sink to actually drain
            # before flipping AUDIO_PLAYING → AUDIO_DONE. Otherwise barge-ins
            # during the sink-tail (≈1-2s after Stream A audio_end) get
            # ignored because the state machine prematurely says "done".
            sink_bytes_buffered_provider=getattr(
                audio_sink, "bytes_buffered", lambda: 0,
            ),
        )

        # `_stop` is the session-end signal. Director's wrap-up auto-end
        # callback sets this; `run_until_signal()` awaits it. Initialized
        # BEFORE Director construction because we pass `self._on_wrapup_end`
        # into the Director's `on_session_end_requested` kwarg.
        self._stop = asyncio.Event()
        # True only when the session ended because the AI finished its WRAP_UP
        # farewell (the director's auto-end gate) — as opposed to a browser
        # "end", an orphan evict, or a crash. Teardown holds for the farewell to
        # play out ONLY on this natural end (see __aexit__).
        self._end_via_wrapup = False

        # ── director ──────────────────────────────────
        self._director = Director(
            store=self._store,
            tracer=self._tracer,
            latency=self._latency,
            tracker=self._tracker,
            verifier_agent=self._verifier_agent,
            phase_override_agent=self._phase_override_agent,
            guardrail_agent=self._guardrail_agent,
            elapsed_ms_provider=self._elapsed_ms,
            # Purely for the STT latency histograms' `provider` label.
            stt_provider=config.stt_provider,
            tick_interval_ms=config.tick_interval_ms,
            policy_config=PolicyConfig(
                endpoint_tail_ms=config.endpoint_tail_ms,
                silence_prompt_ms=config.silence_prompt_ms,
            ),
            protected_strike_threshold=config.strike_threshold,
            max_follow_ups_per_question=config.max_follow_ups_per_question,
            adaptive_config=config.adaptive,
            # Director invokes this synchronously on every VAD speech_start.
            # The handler schedules a deferred cancel — the actual TTS stop
            # happens `warmup_ms` later, so noise bursts (cough, door, click)
            # whose endpoint fires inside the window never reach the cancel.
            # Durable checkpoint at each phase boundary (feature B). Serializes
            # state.turns + phase id to Redis so a fresh runner can resume the
            # phase instead of re-greeting. No-op when checkpoint_writer is None.
            on_checkpoint=self._checkpoint,
            on_speech_start_cancel=self._schedule_barge_in_check,
            # Endpoint within the warm-up window means it was noise —
            # cancel the pending barge-in task so the AI keeps speaking.
            on_endpoint_cancel_pending_barge=self._cancel_pending_barge_task,
            # Director fires this once the AI's farewell turn in WRAP_UP
            # has played out (sink drained). We set our stop event so
            # `run_until_signal()` returns cleanly and __aexit__ tears
            # everything down in the right order.
            on_session_end_requested=self._on_wrapup_end,
            # Reuse barge_in_warmup_ms for STT-side noise rejection. Same
            # spirit: a burst shorter than this is cough / paper / door
            # click — no Turn appended, no LLM kick, silence-timer
            # rewound to pre-utterance.
            noise_threshold_ms=config.barge_in_warmup_ms,
        )

        # ── barge-in tracking ─────────────────────────
        self._barge_cfg = BargeInConfig(
            audio_end_grace_ms=config.audio_end_grace_ms,
            warmup_ms=config.barge_in_warmup_ms,
        )
        # Pending barge-in warm-up task. Set on speech_start, cleared when
        # the timer fires OR when endpoint pre-empts it. At most one task
        # is live at a time — back-to-back speech_starts replace the prior.
        self._pending_barge_task: asyncio.Task | None = None

        # ── Acoustic Echo Cancellation (Exp #2 — sink-callback timing) ───
        # Construct the AEC processor up-front when enabled. Putting the
        # APM together is cheap; the expensive part is the filter
        # convergence, which happens in the first 1-2 s of feeding.
        self._aec: AECProcessor | None = None
        if config.aec_enabled:
            self._aec = AECProcessor(
                stream_delay_ms=config.aec_stream_delay_ms,
                noise_suppression=config.aec_noise_suppression,
                high_pass_filter=config.aec_high_pass_filter,
                auto_gain_control=config.aec_auto_gain_control,
            )
        # Background task that drains the cross-thread reference queue
        # (fed by audio_sink's sounddevice-thread callback) and pushes the
        # frames into AECProcessor.feed_reference on the asyncio loop.
        # Started in run_until_signal() when AEC is enabled.
        self._aec_ref_task: asyncio.Task | None = None
        # Thread-safe queue between audio_sink._callback (sounddevice
        # thread) and the asyncio-side AEC drain task. Bounded to avoid
        # unbounded memory if the drain task lags. Each item is PCM16
        # bytes representing one sink-callback's worth of audio (~64 ms
        # at 16 kHz / BLOCK_SIZE=1024).
        import queue as _queue  # local — avoid cluttering top of file
        self._aec_ref_q: _queue.Queue[bytes] | None = (
            _queue.Queue(maxsize=256) if config.aec_enabled else None
        )
        # Idle-silence pump task — keeps AEC filter primed between AI
        # turns by feeding zero PCM to the reverse stream. Started when
        # AEC is enabled.
        self._aec_silence_task: asyncio.Task | None = None

        # ── tasks ─────────────────────────────────────
        self._mic_task: asyncio.Task | None = None
        self._director_task: asyncio.Task | None = None
        self._watchdog_task: asyncio.Task | None = None
        # ── watchdog state ────────────────────────────
        # 30s in non-IDLE → unwedge. Combined with the progress check
        # below — recent TTS audio_end events reset the timer — even a
        # long multi-chunk reply should not trip this, because chunks
        # produce audio_end events every few seconds.
        self._activity_stuck_threshold_ms: int = 30_000
        self._last_activity_change_ms: int = 0
        self._last_seen_activity: AIActivityState = AIActivityState.IDLE
        # ── mic-silence detector (dead/muted/blocked mic OR a saturated uplink
        # zero-filling frames — the dead-air incident). Fires ONCE per interview:
        # frames have been arriving for >= grace but we've seen no voiced energy
        # for >= warn. Observability + a durable `mic_silent` degraded-flag; does
        # NOT alter interview flow. Env-tunable; 0 disables.
        self._mic_silence_grace_s: float = float(os.getenv("MIC_SILENCE_GRACE_S", "20"))
        self._mic_silence_warn_s: float = float(os.getenv("MIC_SILENCE_WARN_S", "25"))
        self._mic_silent_fired: bool = False

    # ── timing ──────────────────────────────────────────────────────────────

    def _elapsed_ms(self) -> int:
        if self._loop_started is None:
            return self._resume_elapsed_offset_ms
        return self._resume_elapsed_offset_ms + int(
            (asyncio.get_running_loop().time() - self._loop_started) * 1000
        )

    # ── async context ───────────────────────────────────────────────────────

    async def __aenter__(self) -> "InterviewSession":
        self._loop_started = asyncio.get_running_loop().time()
        # Re-anchor the tracker's phase_started_at_ms now that the clock
        # is actually ticking. The tracker was constructed in __init__
        # with a now-of-0; without this fix the first phase would appear
        # to have started ages ago and immediately tick over to advance.
        self._tracker._phase_started_at_ms = self._elapsed_ms()
        self._bus.attach_loop(asyncio.get_running_loop())

        # Connect Stream A — each step timed so a slow bring-up is attributable on
        # /metrics as interview_stage_latency_ms{service="startup", action=...}
        # (e.g. vad_connect spiking = a wedged/slow VAD, the slow-2nd-start cause).
        _t0 = time.monotonic()
        await self._stt.connect()
        log_timing(logger, "startup", "stt_connect", (time.monotonic() - _t0) * 1000.0)
        _t0 = time.monotonic()
        await self._vad.connect()
        log_timing(logger, "startup", "vad_connect", (time.monotonic() - _t0) * 1000.0)
        _t0 = time.monotonic()
        await self._tts.connect()
        log_timing(logger, "startup", "tts_connect", (time.monotonic() - _t0) * 1000.0)
        _t0 = time.monotonic()
        await self._sink_start_safely()
        log_timing(logger, "startup", "sink_start", (time.monotonic() - _t0) * 1000.0)
        _t0 = time.monotonic()
        await self._source.start()
        log_timing(logger, "startup", "source_start", (time.monotonic() - _t0) * 1000.0)

        # AEC sink-callback wiring: register the pcm-consumed callback so
        # every block of audio the sink writes to the speaker hardware is
        # also pushed into self._aec_ref_q for the drain task to pick up
        # and feed to AEC.feed_reference. set_pcm_consumed_callback only
        # exists on SpeakerAudioSink — NullSink doesn't expose it, in
        # which case AEC has no reference signal and we warn.
        if self._aec is not None:
            set_cb = getattr(self._sink, "set_pcm_consumed_callback", None)
            if set_cb is not None and self._aec_ref_q is not None:
                ref_q = self._aec_ref_q

                def _on_pcm_consumed_from_sink(pcm: bytes) -> None:
                    # Sounddevice thread. Cheap put; drop silently on
                    # overflow to keep the audio thread non-blocking.
                    try:
                        ref_q.put_nowait(pcm)
                    except Exception:  # queue.Full or anything else
                        pass

                set_cb(_on_pcm_consumed_from_sink)
                logger.info(
                    "[AEC] sink-callback reference path active "
                    "(reference fed when bytes hit speakers, not when "
                    "they arrive from TTS — keeps AEC reference timing "
                    "aligned with actual playback)",
                )
            else:
                logger.warning(
                    "[AEC] sink does not support set_pcm_consumed_callback; "
                    "reference signal will NOT be fed. AEC will be ineffective.",
                )

        # Pre-warm Kokoro (NEW_STREAM_B.md §8C.5)
        if self._cfg.prewarm_kokoro:
            await self._prewarm_kokoro()

        # On a durable RESUME, record the phase we're actually resuming into
        # (not the cadence's first phase) so this SESSION_STARTED never reads as
        # "interview started from the greeting". The SESSION_RESUMED marker
        # emitted in _resume_bringup is the authoritative interruption boundary
        # the trace/eval readers collapse on (app/resume_collapse.py).
        _rck = self._resume_checkpoint or {}
        _is_resume = bool(self._resume_checkpoint)
        self._tracer.event(
            EventKind.SESSION_STARTED,
            session_id=str(self._state.session_id),
            candidate_name=self._state.candidate_profile.name,
            role=self._state.candidate_profile.role,
            initial_phase=(_rck.get("phase_id") or self._state.phase),
            resumed=_is_resume,
            resume_count=int(_rck.get("resume_count", 0) or 0),
            slow_model=self._cfg.slow_model,
            fast_model=self._cfg.fast_model,
            use_filler=self._cfg.use_filler,
            tick_ms=self._cfg.tick_interval_ms,
        )

        # Langfuse session: emit one anchor observation per session so the
        # Sessions tab shows interview metadata (candidate, role, models)
        # even when no LLM turn has happened yet. `propagate_attributes`
        # is the v4 API for setting trace-level session_id / user_id /
        # tags — there is no `update_current_trace` method on the client.
        _lf = get_langfuse()
        if _lf is not None:
            try:
                from langfuse import propagate_attributes
                with propagate_attributes(
                    session_id=str(self._state.session_id),
                    user_id=self._state.candidate_profile.name,
                    tags=[
                        self._state.candidate_profile.role,
                        f"stt:{self._cfg.stt_provider}",
                        f"tts:{self._cfg.tts_provider}",
                    ],
                    trace_name=(
                        f"Interview — "
                        f"{self._state.candidate_profile.name} "
                        f"({self._state.candidate_profile.role})"
                    ),
                ):
                    with _lf.start_as_current_observation(
                        name="interview.session_started",
                        as_type="span",
                        metadata={
                            "session_id": str(self._state.session_id),
                            "candidate_name": self._state.candidate_profile.name,
                            "role": self._state.candidate_profile.role,
                            "slow_model": self._cfg.slow_model,
                            "fast_model": self._cfg.fast_model,
                            "stt_provider": self._cfg.stt_provider,
                            "tts_provider": self._cfg.tts_provider,
                        },
                    ):
                        pass
            except Exception as e:
                logger.warning("[langfuse] session anchor failed: %s", e)

        return self

    async def __aexit__(self, *exc) -> None:
        # Teardown order — NEW_STREAM_B.md §8E.4.
        self._stop.set()

        # 1. cancel any in-flight slow LLM
        active_tid = self._latency.active_turn_id()
        if active_tid is not None:
            try:
                await self._latency.cancel_turn(active_tid, reason="session_end")
            except Exception as e:  # pragma: no cover
                logger.debug("cancel_turn during teardown raised: %s", e)

        # Cancel any pending barge-in warm-up task so it doesn't leak.
        if self._pending_barge_task is not None and not self._pending_barge_task.done():
            self._pending_barge_task.cancel()

        # 2. stop director ticks
        if self._director_task is not None:
            self._director_task.cancel()
            try:
                await self._director_task
            except (asyncio.CancelledError, Exception):
                pass

        # 2b. On a NATURAL wrap-up end, hold teardown until the farewell has
        # actually played out in the browser. Azure TTS generates PCM far faster
        # than real time, so the last chunk is "generated" seconds before it's
        # "heard"; tearing down now (cancel_all → broadcaster.stop → WS close →
        # session_ended) cut the AI off mid-sentence. The sink models the
        # remaining playout; we wait it out (+ a small margin for the browser's
        # own jitter buffer), bounded so teardown can never hang. Skipped for a
        # browser-"end" / orphan-evict / crash (exc set, or not a wrap-up end).
        if self._end_via_wrapup and exc[0] is None:
            margin_s = float(os.environ.get("WRAPUP_PLAYOUT_MARGIN_S", "0.6"))
            cap_s = float(os.environ.get("WRAPUP_PLAYOUT_MAX_WAIT_S", "15"))
            _ev = getattr(self._sink, "playout_done_event", None)
            _rem = getattr(self._sink, "remaining_playout_s", None)
            remaining = 0.0
            if callable(_rem):
                try:
                    remaining = float(_rem())
                except Exception:
                    remaining = 0.0
            if _ev is not None and not _ev.is_set():
                # Prefer the REAL browser "farewell finished playing" ack — hold
                # until it arrives (bounded by cap_s), then a small margin for the
                # browser's jitter buffer. This is the accurate fix for the wrap-up
                # cut-off (the old path used only the server-side estimate).
                logger.info(
                    "[teardown] natural end — waiting up to %.0fs for browser "
                    "playback-finished ack (est. remaining≈%.1fs)", cap_s, remaining,
                )
                try:
                    await asyncio.wait_for(_ev.wait(), timeout=cap_s)
                    await asyncio.sleep(margin_s)
                except asyncio.TimeoutError:
                    logger.warning(
                        "[teardown] no playback-finished ack within %.0fs — "
                        "proceeding (est. remaining≈%.1fs)", cap_s, remaining,
                    )
                except asyncio.CancelledError:
                    pass  # forced teardown during the hold — just proceed
            elif remaining > 0.0:
                # No ack event (older sink / no ack client) — fall back to the
                # server-side playout estimate.
                wait_s = min(remaining + margin_s, cap_s)
                logger.info(
                    "[teardown] natural end — holding %.1fs for farewell playout "
                    "(server estimate; remaining≈%.1fs, cap=%.0fs)", wait_s, remaining, cap_s,
                )
                try:
                    await asyncio.sleep(wait_s)
                except asyncio.CancelledError:
                    pass

        # 3. cancel pending TTS turns; wait for audio_end (with timeout)
        await self._tts.cancel_all()

        # 4. write session_ended
        self._tracer.event(
            EventKind.SESSION_ENDED,
            n_turns=len(self._state.turns),
            barge_in_strike_count=self._state.barge_in_strike_count,
        )

        # 5. close WS clients
        for client in (self._stt, self._vad, self._tts):
            try:
                await client.close()
            except Exception:  # pragma: no cover
                pass

        # 6. close audio
        # Durable mic-delivery diagnostics → events.jsonl BEFORE stop (console
        # logs aren't retained on ACA). arrival_rate_per_s >> ~50 or
        # dominant_packet_bytes != 640 confirms the audio-rate drift that
        # degrades VAD + STT (see the audio-timeline investigation).
        try:
            _mic_stats = getattr(self._source, "stats", None)
            if callable(_mic_stats):
                self._tracer.event("mic_delivery_stats", **_mic_stats())
        except Exception as e:  # pragma: no cover — never break teardown
            logger.debug("[mic-stats] emit failed: %s", e)
        try:
            await self._source.stop()
        except Exception:  # pragma: no cover
            pass
        try:
            await self._sink.stop()
        except Exception:  # pragma: no cover
            pass

        # 7. flush event log
        try:
            self._event_log.close()
        except Exception:  # pragma: no cover
            pass

        # 7b. flush Langfuse — last LLM/STT/TTS spans of the session must
        # land before the container winds down. Safe to call when disabled
        # (no-op).
        try:
            langfuse_flush()
        except Exception as e:  # pragma: no cover
            logger.debug("[langfuse] flush during teardown raised: %s", e)

        # 8. mic task + watchdog + AEC tasks (silence pump + ref drain).
        # Unregister the sink callback first so we don't keep pushing into
        # a queue that nobody drains.
        if self._aec is not None:
            set_cb = getattr(self._sink, "set_pcm_consumed_callback", None)
            if set_cb is not None:
                try:
                    set_cb(None)
                except Exception:
                    pass
        for t in (
            self._mic_task, self._watchdog_task,
            self._aec_silence_task, self._aec_ref_task,
        ):
            if t is not None:
                t.cancel()
                try:
                    await t
                except (asyncio.CancelledError, Exception):
                    pass

        # Log final AEC stats for debugging (no-op when AEC was off).
        if self._aec is not None:
            logger.info("[AEC] session stats: %s", self._aec.stats())

    async def _sink_start_safely(self) -> None:
        # AudioSink may or may not need explicit start — protocol doesn't mandate.
        start = getattr(self._sink, "start", None)
        if start is not None:
            res = start()
            if asyncio.iscoroutine(res):
                await res

    # ── pre-warm ────────────────────────────────────────────────────────────

    async def _prewarm_kokoro(self) -> None:
        """Send a tiny silent speak so first real turn doesn't pay cold-start.
        Audio is muted at the sink during this turn."""
        try:
            self._sink_muted = True  # type: ignore[attr-defined]
            await self._tts.speak_chunk("prewarm-1", 1, "Hi.")
            await asyncio.sleep(2.0)  # let it synthesise + play silently
        except Exception as e:
            logger.warning("prewarm failed: %s", e)
        finally:
            self._sink_muted = False  # type: ignore[attr-defined]

    # ── durable checkpoint / resume (feature B) ──────────────────────────────

    async def _checkpoint(self, phase_id: str, turns: list[Turn], *, kind: str = "phase",
                          tracker: dict | None = None, phase_elapsed_ms: int = 0) -> None:
        """Director callback: at each phase boundary (kind="phase": the
        phase-entry turns) and, in most phases, before each AI turn (kind="turn":
        the phase's turns so far + the question cursor + the phase time used, so
        a resume continues mid-phase — Phase 4). Hands it to the injected writer
        (Redis). Best-effort — a hiccup here never affects the live interview."""
        if self._checkpoint_writer is None:
            return
        jsonable = [turn_to_jsonable(t) for t in turns]
        # Persist the TOTAL interview time at this point so a resume can
        # continue the cumulative clock (see _resume_elapsed_offset_ms). This
        # already includes any prior resume offset, so it stays cumulative across
        # multiple resumes.
        elapsed = self._elapsed_ms()
        # Names this checkpoint in events.jsonl, so the trace/eval view can tell
        # which turns a later resume continued from (app/resume_collapse.py).
        seq = uuid4().hex[:12]
        ok = await self._checkpoint_writer(
            phase_id, jsonable, elapsed_ms=elapsed, kind=kind, tracker=tracker,
            phase_elapsed_ms=phase_elapsed_ms, seq=seq)
        # Observability: land a marker in events.jsonl (shared sessions volume) so
        # a resume test can confirm the checkpoint was persisted for THIS phase —
        # and, with checkpoint_cleared/kept from the WS teardown, show exactly why
        # a later resume did or didn't fire. `ok=false` means the Redis write
        # itself failed (a separate failure mode from a checkpoint being cleared).
        try:
            self._tracer.event(
                EventKind.CHECKPOINT_WRITTEN,
                phase_id=phase_id, ok=bool(ok), n_turns=len(jsonable),
                # Not `kind=`: that's tracer.event's own first parameter.
                elapsed_ms=elapsed, checkpoint_kind=kind, seq=seq,
            )
        except Exception:  # pragma: no cover — never break the tick
            pass

    async def _await_playout(self, cap_s: float, *, margin_s: float = 0.6) -> None:
        """Block until the current utterance has actually FINISHED playing in the
        candidate's browser (the audio_playback_finished ack), bounded by cap_s.
        Falls back to the server-side playout estimate when no ack client is
        connected. Mirrors the wrap-up teardown hold in __aexit__ — used to pace
        the resume announce so each line finishes before the next begins."""
        ev = getattr(self._sink, "playout_done_event", None)
        rem_fn = getattr(self._sink, "remaining_playout_s", None)
        if ev is not None and not ev.is_set():
            try:
                await asyncio.wait_for(ev.wait(), timeout=cap_s)
                await asyncio.sleep(margin_s)
            except asyncio.TimeoutError:
                logger.warning("[resume] playout ack not received within %.0fs — "
                               "proceeding", cap_s)
            except asyncio.CancelledError:
                pass
            return
        # No ack event / already set — fall back to the server-side estimate.
        remaining = 0.0
        if callable(rem_fn):
            try:
                remaining = float(rem_fn())
            except Exception:
                remaining = 0.0
        if remaining > 0.0:
            try:
                await asyncio.sleep(min(remaining + margin_s, cap_s))
            except asyncio.CancelledError:
                pass

    async def _say_resume_line(self, sub_base: str, text: str,
                               *, cap_s: float = 6.0) -> None:
        """Speak ONE resume-announce line (outside the turn loop, like the
        STT-wait filler) and wait for it to finish playing. Non-frame turn id →
        the latency state machine ignores it, so it doesn't create/disturb a
        turn. Swallows errors — a failed announce must not abort the resume."""
        # Log the apology text server-side (events.jsonl) even though the UI is
        # told to render nothing for resume-* lines (audio-only; the audio_start
        # text is suppressed in deploy/azure_app.py). Keeps it fully auditable.
        try:
            self._tracer.event("resume_announce", line=sub_base, text=text)
        except Exception:  # pragma: no cover
            pass
        try:
            # Arm the ack wait BEFORE the async audio_start arrives, then wait for
            # the browser's real playback-finished ack — the wiring the session
            # already has for "candidate finished hearing this on the speaker". This
            # gates each line on the candidate actually HEARING it before the next
            # line (and before the interview + timer start). This only works if the
            # client resumes its AudioContext on reconnect so the audio plays and
            # the ack comes back (candidateEngine.ts); without that the ack never
            # arrived and each line stalled cap_s — the 20s gaps in 81a315fe.
            expect = getattr(self._sink, "expect_playout", None)
            if expect is not None:
                expect(f"{sub_base}-1")   # speak_chunk sub_id = f"{turn_id}-{seq}"
            await self._tts.speak_chunk(sub_base, 1, text)
            await self._await_playout(cap_s)
        except Exception as e:  # pragma: no cover — never fatal
            logger.warning("[resume] announce line %r failed: %s", sub_base, e)

    async def _compose_resume_intro(self, phase_intent: str) -> str:
        """Compose the candidate-facing 'we hit a hiccup, let's restart this
        part' line from the phase intent via the FAST LLM. Canned fallback on
        any failure/timeout. The phase NAME is never revealed — only the intent
        shapes what section we're restarting."""
        canned = ("Sorry about that — we hit a brief technical issue on my end. "
                  "Let's pick this part back up.")
        if self._fast_llm is None or not phase_intent:
            return canned
        sys_prompt = (
            "You are a warm technical interviewer. A brief technical glitch "
            "interrupted the interview and you must restart the CURRENT section "
            "from the beginning. In ONE short spoken sentence (max ~25 words), "
            "reassure the candidate and say you'll pick this part back up, "
            "hinting at the topic. Do NOT mention phases, checkpoints, servers, "
            "or that anything was lost. Output only the words to speak."
        )
        chunks: list[str] = []

        def _collect(ch: str) -> None:  # on_utterance_char is synchronous
            chunks.append(ch)

        try:
            from engine.brain.llm.client import LLMRequest
            from engine.brain.observability.langfuse_client import (
                apply_llm_result, observe_llm)
            req = LLMRequest(
                system_prompt=sys_prompt,
                user_messages=[{"role": "user",
                                "content": f"Section intent: {phase_intent}"}],
                tools=[], tool_choice=None, parser=None,
                model=self._cfg.fast_model,
            )
            # Trace this apology as its own LLM generation — it's an EXTRA call
            # caused by the interruption, so its COST must be visible in
            # events.jsonl AND Langfuse (grouped under this session, alongside the
            # interview.resumed WARNING span that marks the error itself).
            lf_trace = None
            with observe_llm(
                agent="resume_announce_agent", model=self._cfg.fast_model,
                session_id=str(self._tracer.session_id),
                input_data=[{"role": "user",
                             "content": f"Section intent: {phase_intent}"}],
                metadata={"reason": "interruption_recovery"},
            ) as _obs:
                res = await asyncio.wait_for(
                    self._fast_llm.complete_text_streaming(
                        req, on_utterance_char=_collect,
                    ),
                    timeout=float(os.environ.get("RESUME_INTRO_TIMEOUT_S", "8")),
                )
                text = "".join(chunks).strip()
                try:
                    apply_llm_result(_obs, res, output={"text": text})
                except Exception:  # pragma: no cover
                    pass
                lf_trace = getattr(_obs, "trace_id", None)
            try:
                self._tracer.event(
                    EventKind.LLM_CALL_COMPLETED,
                    agent="resume_announce_agent", model=self._cfg.fast_model,
                    response_text=text,
                    latency_ms=getattr(res, "latency_ms", None),
                    ttft_ms=getattr(res, "ttft_ms", None),
                    tokens_in=getattr(res, "tokens_in", None),
                    tokens_out=getattr(res, "tokens_out", None),
                    cost_usd=getattr(res, "cost_usd", None),
                    generation_id=getattr(res, "generation_id", None),
                    langfuse_trace_id=lf_trace,
                )
            except Exception:  # pragma: no cover
                pass
            return text or canned
        except Exception as e:
            logger.warning("[resume] intro compose failed (%s) — canned", e)
            return canned

    async def _resume_bringup(self) -> bool:
        """Announce + rehydrate before the director/mic-pump start. Returns True
        if the caller should PROCEED to run the interview, False if we've given
        up (spoke an apology + set stop) and the caller should just tear down.

        The mic-pump is not running yet (run_until_signal starts it AFTER this),
        so candidate voice is naturally held off STT/VAD throughout the announce;
        we drain the mic queue at the end before the pump starts."""
        ckpt = self._resume_checkpoint or {}
        phase_id = ckpt.get("phase_id") or self._tracker.current_phase_id
        give_up = bool(ckpt.get("give_up"))

        # ── give-up path (repeated-crash cap reached) ──
        if give_up:
            logger.warning("[resume] give-up: too many resume attempts at phase %s",
                           phase_id)
            await self._say_resume_line(
                "resume-giveup",
                "I'm sorry, but we've hit repeated technical problems and I have "
                "to end the interview here. Thank you for your time, and someone "
                "will follow up with you.",
            )
            self._end_via_wrapup = False
            self._stop.set()
            return False

        # Resolve the checkpoint phase BEFORE announcing. If it's no longer in
        # the cadence plan (cadence changed since the checkpoint was written),
        # the checkpoint is unresumable — fall back to a clean fresh start
        # (normal greeting) rather than announcing then crashing on jump_to.
        try:
            phase_def = self._tracker.plan.get_phase(phase_id)
        except Exception:
            phase_def = None
        if phase_def is None:
            logger.warning("[resume] checkpoint phase %r not in current cadence — "
                           "falling back to a fresh start", phase_id)
            return True  # proceed as a normal (un-hydrated) fresh interview
        phase_intent = getattr(phase_def, "intent", "") or ""
        resume_count = int(ckpt.get("resume_count", 0) or 0)
        # Phase 4: a TURN checkpoint resumes mid-phase — the conversation goes
        # on from the candidate's last answer, with the question cursor and the
        # phase's remaining time. (Coding/scenario phases only ever write phase
        # checkpoints, so they reopen the phase as before.)
        midphase = ckpt.get("kind") == "turn" and bool(ckpt.get("tracker"))

        logger.info("[resume] resuming interview at phase=%s (%d turns in ckpt)",
                    phase_id, len(ckpt.get("turns") or []))

        # 0. Interruption boundary marker. This is what the trace/eval readers
        #    (app/resume_collapse.py) collapse on: everything from the pre-crash
        #    entry into `phase_id` up to this marker is the ABANDONED partial
        #    attempt and is replaced by the resumed run below. Also record the
        #    interruption in Langfuse (WARNING) so the trace shows the error.
        self._tracer.event(
            EventKind.SESSION_RESUMED,
            phase_id=phase_id,
            resume_count=resume_count,
            elapsed_ms_at_phase_entry=self._resume_elapsed_offset_ms,
            mode="turn" if midphase else "phase",
            checkpoint_seq=ckpt.get("seq", ""),
        )
        try:
            _lf = get_langfuse()
            if _lf is not None:
                with _lf.start_as_current_observation(
                    name="interview.resumed", as_type="span",
                    metadata={"phase_id": phase_id, "resume_count": resume_count,
                              "reason": "runner_lost_mid_interview"},
                ) as _sp:
                    _sp.update(level="WARNING",
                              status_message=f"resumed at {phase_id} "
                                             f"(attempt {resume_count})")
        except Exception as e:  # pragma: no cover — audit never blocks resume
            logger.debug("[resume] langfuse interruption marker failed: %s", e)

        # NOTE: the "we're back, picking up where we left off" line is NO LONGER
        # spoken here via a special pre-director announce — that path produced no
        # audio + 20s stalls in EVERY attempt (v27/v28/v29). Instead we set
        # `_resume_ack_pending` below; the director folds the acknowledgment into
        # the FIRST normal turn's <think> briefing, so it's spoken through the same
        # reliable path as every other turn (see director._RESUME_ACK_THINK). The
        # phase-open (with the topic + question) rides alongside, so the AI opens
        # with one natural "we're back — let's continue with [question]" utterance.

        # Rehydrate: restore turns + tracker phase, prime the director for a
        #    phase re-open (NOT a greeting), re-mount the coding editor if needed.
        restored = [turn_from_jsonable(d) for d in (ckpt.get("turns") or [])]

        async def _restore(s: SessionState) -> None:
            s.turns = list(restored)
            s.phase = phase_id
            s.pending_phase = None
            s.ai_activity = AIActivityState.IDLE
        await self._store.mutate(_restore)

        self._tracker.jump_to(phase_id, reason="durable_resume")
        # The first tick must dispatch (not wait for the candidate), so it runs
        # as the "first turn" — but not as a greeting:
        self._director._has_greeted = False
        if midphase:
            # ...as a continuation of the restored conversation, with the
            # question cursor where it was.
            self._tracker.restore_snapshot(ckpt.get("tracker") or {})
            self._director._resume_midphase_pending = True
            self._director._resume_phase_elapsed_ms = int(ckpt.get("phase_elapsed_ms", 0) or 0)
        else:
            # ...as a phase_transition re-open.
            self._director._phase_intro_pending = True
        # Fold the "we're back" acknowledgment into that first turn (spoken
        # through the normal, reliable turn path).
        self._director._resume_ack_pending = True

        # Coding phase → re-emit coding_phase_started so the browser re-mounts
        # the editor (the normal apply block that does this is skipped on resume).
        if phase_def is not None:
            payload = build_coding_phase_started_payload(phase_def)
            if payload is not None:
                try:
                    self._tracer.event("coding_phase_started", **payload)
                    logger.info("[resume] re-emitted coding_phase_started phase=%s",
                                phase_id)
                except Exception as e:  # pragma: no cover
                    logger.warning("[resume] coding re-mount failed: %s", e)

        # Drain anything the mic captured during bring-up before the pump starts
        # (whatever the candidate said mid-reconnect is not an answer to resume).
        try:
            dropped = await self._source.drain()
            logger.info("[resume] drained %s pre-resume mic frames", dropped)
        except Exception:
            pass

        # Safety anchor only — keep elapsed_in_phase ≈ 0 so the director's
        #    first-tick advance check can't fast-forward the phase. The TRUE
        #    phase-clock start happens at the LLM dispatch (director re-anchors
        #    on _resume_clock_pending), so bring-up + announce are excluded.
        self._tracker._phase_started_at_ms = self._elapsed_ms()
        self._director._resume_clock_pending = True

        # Observability: count the resume.
        try:
            from engine.brain.observability import prom as _prom
            _prom.INTERVIEW_RESUMES.labels(phase=phase_id).inc()
            _prom.INTERVIEW_RESUMES_BY_MODE.labels(mode="turn" if midphase else "phase").inc()
        except Exception:
            pass
        return True

    # ── main loop ───────────────────────────────────────────────────────────

    async def run_until_signal(self) -> None:
        """Spin up mic-pump + director + watchdog; block until stop()."""
        # Durable resume (feature B): if this runner was spawned for an interview
        # whose prior runner was lost, announce + rehydrate BEFORE starting the
        # mic-pump/director (so candidate voice is held off during the announce).
        if self._resume_checkpoint is not None:
            proceed = await self._resume_bringup()
            if not proceed:
                # give-up path already set _stop + spoke the apology.
                await self._stop.wait()
                return
        self._mic_task = asyncio.create_task(self._mic_pump_loop(), name="mic-pump")
        self._director_task = asyncio.create_task(self._director.run(), name="director")
        self._watchdog_task = asyncio.create_task(self._watchdog_loop(), name="watchdog")
        # AEC silence pump + sink-callback reference drain. Both only run
        # when aec_enabled=True (config check happened at construction).
        if self._aec is not None:
            self._aec_silence_task = asyncio.create_task(
                self._aec_silence_pump_loop(), name="aec-silence-pump",
            )
            self._aec_ref_task = asyncio.create_task(
                self._aec_ref_drain_loop(), name="aec-ref-drain",
            )
        await self._stop.wait()

    def _check_mic_silence(self) -> None:
        """Detect a dead/muted/blocked candidate mic (or a saturated uplink
        zero-filling frames): mic frames ARE arriving, but no voiced energy for a
        sustained window. Fires the `mic_silent` event ONCE. Observability only —
        does not alter interview flow (a candidate-facing warning is a follow-up).

        Grounded in the dead-air incident: 24,438 frames arrived at ~43/s yet
        zero speech was ever transcribed. `mic_health()` from the browser mic
        source separates that (frames + no energy) from normal think-time silence
        (frames + a real noise floor) and from "no frames at all" (packets_in=0)."""
        health_fn = getattr(self._source, "mic_health", None)
        if not callable(health_fn):
            return  # local mic source (non-web) — no energy signal
        try:
            health = health_fn()
        except Exception:  # pragma: no cover — never break the watchdog
            return
        first_wall = health.get("first_packet_wall_s")
        if not health.get("packets_in") or first_wall is None:
            return  # no frames arriving → a different failure (not "silent mic")
        flowing_for = time.monotonic() - first_wall
        if flowing_for < self._mic_silence_grace_s:
            return  # still within startup grace (AI greeting / first question)
        since_voiced = health.get("seconds_since_voiced")
        # Never voiced since frames began, OR voiced-then-went-dead past `warn`.
        if since_voiced is not None and since_voiced < self._mic_silence_warn_s:
            return
        self._mic_silent_fired = True
        self._tracer.event(
            "mic_silent",
            reason="frames_arriving_no_energy",
            flowing_for_s=round(flowing_for, 1),
            seconds_since_voiced=(round(since_voiced, 1) if since_voiced is not None else None),
            voiced_frames=health.get("voiced_frames", 0),
            silent_frames=health.get("silent_frames", 0),
            voiced_ratio=round(health.get("voiced_ratio", 0.0), 3),
            packets_in=health.get("packets_in", 0),
        )
        logger.warning(
            "[MIC-SILENT] candidate mic frames arriving (%d pkts) but no voiced "
            "energy for %.0fs — likely dead/muted/blocked mic or a saturated "
            "uplink dropping audio. Interview flagged degraded (mic_silent).",
            health.get("packets_in", 0), flowing_for,
        )

    async def _watchdog_loop(self) -> None:
        """Background safety net: if ai_activity stays non-IDLE for too long,
        forcibly unstick the state machine.

        v0 had a bug where ghost TTS sub_ids could pin ai_activity at
        AUDIO_PLAYING forever; this loop catches any future variant of
        the same class of bug. Runs every 1s.
        """
        try:
            while not self._stop.is_set():
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=1.0)
                    return
                except asyncio.TimeoutError:
                    pass
                # Mic-silence detector (independent of the ai_activity check
                # below): frames arriving but no voiced energy = we can't hear
                # the candidate. Fires once; observability only.
                if not self._mic_silent_fired and self._mic_silence_warn_s > 0:
                    self._check_mic_silence()
                state = self._store.state
                now_ms = self._elapsed_ms()
                # Track when activity last changed.
                if state.ai_activity != self._last_seen_activity:
                    self._last_seen_activity = state.ai_activity
                    self._last_activity_change_ms = now_ms
                    continue
                # Idle / done are fine to stay in.
                if state.ai_activity in (
                    AIActivityState.IDLE, AIActivityState.AUDIO_DONE,
                ):
                    continue
                # Progress signal: the audio sink is the ground truth for
                # "candidate is currently hearing audio". As long as it has
                # PCM bytes buffered, the system is producing audible
                # output and shouldn't be considered stuck — regardless of
                # how long ai_activity has sat at AUDIO_PLAYING.
                #
                # Why sink (not Stream A's audio_end events): Stream A
                # ships PCM to us faster than realtime when Kokoro is on
                # fast hardware. audio_end fires when PCM stops arriving at
                # our process, which can be several seconds before the
                # speakers actually go silent. Sink covers both the
                # fill phase (PCM still arriving) and the drain phase
                # (PCM arrived, slowly playing out).
                try:
                    bytes_buffered = self._sink.bytes_buffered()
                except Exception:
                    bytes_buffered = 0
                if bytes_buffered > 0:
                    self._last_activity_change_ms = now_ms
                    continue
                # Non-idle for too long → unstick.
                stuck_for = now_ms - self._last_activity_change_ms
                if stuck_for > self._activity_stuck_threshold_ms:
                    logger.warning(
                        "[WATCHDOG] ai_activity=%s stuck for %dms — "
                        "forcibly unsticking. Cancelling active turn(s).",
                        state.ai_activity.value, stuck_for,
                    )
                    # Cancel any active turn (dumps whatever was in flight).
                    active_tid = self._latency.active_turn_id()
                    if active_tid is not None:
                        try:
                            await self._latency.cancel_turn(
                                active_tid, reason="watchdog_unwedge",
                            )
                            await self._sink.flush()
                        except Exception as e:  # pragma: no cover
                            logger.warning("watchdog cancel raised: %s", e)
                    # Forcibly reset state regardless of whether cancel worked.
                    async def _reset(s: SessionState) -> None:
                        s.ai_activity = AIActivityState.IDLE
                        s.barge_in_strike_count = 0
                        s.in_protected_response = False
                    await self._store.mutate(_reset)
                    self._tracer.event(
                        "watchdog_unwedge",
                        was_stuck_ms=stuck_for,
                        was_state=state.ai_activity.value,
                    )
                    self._last_seen_activity = AIActivityState.IDLE
                    self._last_activity_change_ms = now_ms
        except asyncio.CancelledError:
            return

    def _on_wrapup_end(self) -> None:
        """Director's WRAP_UP auto-end gate fired — the AI has said its farewell.
        Mark this a natural end so teardown waits for the farewell to play out,
        then signal run_until_signal() to return."""
        self._end_via_wrapup = True
        self._stop.set()

    def request_stop(self) -> None:
        self._stop.set()
        self._director.request_stop()

    # ── mic pump ─────────────────────────────────────────────────────────────

    async def _mic_pump_loop(self) -> None:
        # Discard any audio that piled up between WS-open and now. Browser
        # mic frames start queueing the moment the WebSocket upgrades
        # (broadcaster.handle_client_via_adapter runs in parallel with
        # _session_runner). During InterviewSession.__aenter__ we're
        # connecting Azure STT/TTS over WS, which on cold start can take
        # 5-20s. Without this drain, the pump consumes the backlog at
        # unbounded rate, ts_ms (= seq*FRAME_MS) races ahead of wall
        # clock, and VAD/STT silence timers fire on what looks like
        # short utterances inside the burst — observed as the 22s
        # ts_ms offset in trace a348e47d. The pre-session audio is just
        # the candidate watching "Connecting…", so dropping it is fine.
        drain = getattr(self._source, "drain", None)
        if drain is not None:
            try:
                n_dropped = await drain()
                if n_dropped:
                    logger.info(
                        "[mic-pump] drained %d backlog frames (~%.1fs of "
                        "pre-session audio) — ts_ms starts at 0 from real "
                        "wall-clock now",
                        n_dropped, n_dropped * FRAME_MS / 1000.0,
                    )
            except Exception as e:  # pragma: no cover — defensive
                logger.warning("[mic-pump] source.drain() raised: %s", e)
        seq = 0
        try:
            async for frame in self._source.frames():
                if self._stop.is_set():
                    break
                if not frame:
                    continue
                ts_ms = seq * FRAME_MS
                seq += 1
                # AEC pre-processing. Run the mic frame through echo
                # cancellation BEFORE handing it to VAD/STT. If AEC is
                # off, the frame passes through unmodified.
                if self._aec is not None:
                    try:
                        frame = self._aec.process_mic(frame)
                    except Exception as e:  # pragma: no cover — defensive
                        logger.warning(
                            "[AEC] process_mic raised: %s — passing frame through", e,
                        )
                # Send to STT and VAD in parallel (cheap; same WS lib).
                await asyncio.gather(
                    self._stt.send_audio_frame(ts_ms, frame),
                    self._vad.send_audio_frame(ts_ms, frame),
                    return_exceptions=True,
                )
        except asyncio.CancelledError:
            return

    async def _aec_ref_drain_loop(self) -> None:
        """Pull PCM blocks from the cross-thread reference queue and feed
        them into AEC.feed_reference on the asyncio loop.

        The sink callback (sounddevice thread) pushes one block per
        callback (~64 ms of audio at 16 kHz / BLOCK_SIZE=1024 = 2048
        bytes PCM16). We slice into the AEC's 20 ms boundary (640 bytes)
        — anything left over from the previous block is held until the
        next iteration.

        Why this exists: AEC needs the reference fed in lockstep with
        actual playback so the cancellation filter can correlate "what
        the speakers just emitted" with "what the mic just captured
        ~50 ms later". Feeding from `_on_pcm` (TTS arrival) was
        catastrophically misaligned because of the audio_sink's
        buffering depth.
        """
        import queue as _queue
        from engine.brain.streamA_bridge.aec_processor import STREAM_FRAME_BYTES
        if self._aec is None or self._aec_ref_q is None:
            return
        leftover = b""
        try:
            while not self._stop.is_set():
                # Non-blocking get + asyncio.sleep, because a blocking
                # queue.Queue.get from an asyncio task starves the loop.
                try:
                    block = self._aec_ref_q.get_nowait()
                except _queue.Empty:
                    await asyncio.sleep(0.020)  # 20 ms — one audio frame
                    continue
                buf = leftover + block
                # Feed AEC in 20 ms frames (640 bytes PCM16).
                n_full = len(buf) // STREAM_FRAME_BYTES
                for i in range(n_full):
                    try:
                        self._aec.feed_reference(
                            buf[i * STREAM_FRAME_BYTES : (i + 1) * STREAM_FRAME_BYTES],
                        )
                    except Exception as e:  # pragma: no cover
                        logger.warning("[AEC] feed_reference raised: %s", e)
                leftover = buf[n_full * STREAM_FRAME_BYTES :]
        except asyncio.CancelledError:
            return

    async def _aec_silence_pump_loop(self) -> None:
        """Keep the AEC filter primed by feeding 20 ms of silence to the
        reverse stream whenever the AI is idle.

        Without this, the AEC's adaptive filter goes stale between AI
        turns and the first 1-2 s of the next AI utterance leaks
        through to the mic. With this, the filter stays converged so
        barge-in works instantly even mid-greeting.

        When the AI is talking, the sink-callback path is feeding real
        TTS frames to the reverse stream; in that case we just yield
        and let the sink callback own the reverse stream.
        """
        interval_s = FRAME_MS / 1000.0
        try:
            while not self._stop.is_set():
                if self._aec is None:
                    return
                state = self._store.state
                ai_idle = state.ai_activity in (
                    AIActivityState.IDLE,
                    AIActivityState.AUDIO_DONE,
                )
                if ai_idle:
                    try:
                        self._aec.feed_silence_reference()
                    except Exception as e:  # pragma: no cover
                        logger.warning(
                            "[AEC] feed_silence_reference raised: %s", e,
                        )
                # else: the sink callback is feeding real TTS frames to
                # the reverse stream. Sleep one frame and re-check.
                await asyncio.sleep(interval_s)
        except asyncio.CancelledError:
            return

    # ── Stream A event handlers ──────────────────────────────────────────────

    async def _on_stt_partial(
        self, text: str, words: list[dict], end_ms: int, start_ms: int = 0,
    ) -> None:
        self._tracer.event(EventKind.STT_PARTIAL, text=text, end_ms=end_ms)
        await self._director.on_stt_partial(text, words, end_ms, start_ms)

    async def _on_stt_final(
        self, text: str, words: list[dict], end_ms: int,
        confidence: float, utterance_id: str,
    ) -> None:
        await self._director.on_stt_final(
            text, words, end_ms, confidence, utterance_id,
        )

    async def _on_vad_event(self, kind: str, payload: dict) -> None:
        # The Director is the primary consumer — it owns the VAD state
        # machine and invokes our barge-in callback synchronously on
        # speech_start. We just forward.
        await self._director.on_vad_event(kind, payload)

        # Forward to STT as control msg so STT's buffer is VAD-gated
        # (matches Stream A's expected protocol).
        await self._stt.send_control({**payload, "type": kind})

    async def _schedule_barge_in_check(self) -> None:
        """Called by Director on every VAD speech_start.

        Schedules a deferred barge-in check rather than cancelling
        immediately. After `warmup_ms` of continuous speech we re-check VAD
        state and run the actual cancel decision. If endpoint fires during
        the window (= short noise burst), the pending task is cancelled by
        `_cancel_pending_barge_task` and the AI keeps speaking.

        Back-to-back speech_starts replace the prior pending task — only
        the most recent warm-up window matters.
        """
        # Cancel any prior pending task (back-to-back speech_starts).
        if self._pending_barge_task is not None and not self._pending_barge_task.done():
            self._pending_barge_task.cancel()
        self._pending_barge_task = asyncio.create_task(
            self._delayed_barge_check(),
            name="barge-warmup",
        )
        logger.info(
            "[BARGE] warm-up STARTED — deferring cancel by %dms (will fire only if "
            "speech is still sustained at expiry)",
            self._barge_cfg.warmup_ms,
        )

    async def _cancel_pending_barge_task(self) -> None:
        """Called by Director on VAD endpoint_detected. If a warm-up task
        is still pending, cancel it — the utterance ended within the warm-up
        window, so it was noise, not a real barge-in."""
        task = self._pending_barge_task
        if task is None or task.done():
            return
        task.cancel()
        self._pending_barge_task = None
        logger.info(
            "[BARGE] warm-up CANCELLED — endpoint fired inside warm-up window "
            "(noise burst, not a real barge-in). AI keeps speaking."
        )

    async def _delayed_barge_check(self) -> None:
        """Runs after `warmup_ms` of continuous speech. Re-checks VAD state
        and either fires the cancel decision or skips."""
        try:
            await asyncio.sleep(self._barge_cfg.warmup_ms / 1000.0)
        except asyncio.CancelledError:
            return

        # Did the candidate actually sustain speech through the window?
        state = self._store.state
        if state.vad_state not in (VadState.SPEAKING, VadState.PAUSED):
            logger.info(
                "[BARGE] warm-up expired but VAD=%s — treating as noise",
                state.vad_state.value,
            )
            return

        # PAUSED can mean two things:
        #   (a) Mid-utterance pause — speech is real and is just resting
        #       for a beat before resuming. We SHOULD barge.
        #   (b) A brief noise burst — speech_start fired on AEC residual
        #       (or cough / click), speech_end followed milliseconds later,
        #       VAD never reached the endpoint threshold, and the state is
        #       stuck at PAUSED for the rest of the window. We should NOT
        #       barge — there was no real utterance.
        #
        # Discriminate with the duration of the most recent speech burst:
        # case (a) burst is at least a syllable (~150 ms+); case (b) burst
        # is just tens of ms. Burst duration is measured in real time
        # (elapsed_ms diff between speech_start and speech_end) — close
        # enough to audio duration for this filter to work, and avoids
        # tracking VAD's audio ts_ms separately.
        if state.vad_state == VadState.PAUSED:
            burst_ms = state.last_speech_end_ts_ms - state.last_speech_start_ts_ms
            if 0 < burst_ms < self._barge_cfg.min_burst_ms:
                logger.info(
                    "[BARGE] warm-up expired but most recent speech burst "
                    "was only %dms (< %dms min) — treating as noise, AI "
                    "keeps speaking.",
                    burst_ms, self._barge_cfg.min_burst_ms,
                )
                return

        await self._fire_barge_in_decision()

    async def _fire_barge_in_decision(self) -> None:
        """Run the existing cancel-decision logic. Called from the warm-up
        task once continuity is confirmed. Strike-counting + transcript-
        tagging happens inside the latency orchestrator's
        `_finalize_cancelled_turn`."""
        state = self._store.state
        active_tid = self._latency.active_turn_id()
        if active_tid is None or state.ai_activity in (
            AIActivityState.IDLE, AIActivityState.AUDIO_DONE,
        ):
            logger.info(
                "[BARGE] warm-up expired with no active AI turn — nothing to cancel"
            )
            return

        # ms_to_expected_audio_end for the audio-end grace check.
        # Only compute the estimate when Stream A has finished sending PCM
        # for all subs of this turn (sub_ids_active empty). While subs are
        # still streaming, "ms remaining" is fundamentally unknowable from
        # cps math — and any barge-in during real audio should CANCEL, not
        # grace_end. Leaving `ms_to_end = None` makes `decide_barge_in`
        # skip the grace branch entirely.
        ms_to_end: int | None = None
        f = self._latency._frames.get(active_tid)
        if f is not None and getattr(f, "_slow_full_text", None):
            ts_state = self._tts.turn_state(f.slow_turn_id)
            still_streaming = bool(ts_state and ts_state.sub_ids_active)
            if not still_streaming:
                full = f._slow_full_text
                cps = max(10.0, state.kokoro_chars_per_second)
                expected_ms = int(len(full) / cps * 1000)
                played = ts_state.audio_played_ms if ts_state else 0
                ms_to_end = max(0, expected_ms - played)

        # By the time we reach this decision, the warm-up task has already
        # verified that speech was sustained for `warmup_ms` (otherwise the
        # endpoint cancel path would have pre-empted us). So no separate
        # `speech_continuous_ms` check is needed in the guard.
        decision = decide_barge_in(BargeInInputs(
            ai_activity=state.ai_activity,
            ms_to_expected_audio_end=ms_to_end,
            in_protected_response=state.in_protected_response,
        ), self._barge_cfg)

        logger.info(
            "[BARGE] decision=%s ai_activity=%s active_tid=%s ms_to_end=%s",
            decision.value, state.ai_activity.value, active_tid, ms_to_end,
        )

        if decision is BargeInDecision.CANCEL:
            logger.info("[BARGE]   ⇒ cancelling turn %s IMMEDIATELY", active_tid)
            await self._latency.cancel_turn(active_tid, reason="barge_in")
            # Drain locally-queued PCM so speakers go silent NOW. Anything
            # still en-route from Stream A for this turn's sub_ids is
            # dropped inside TTSClient's reader gate (no time window
            # needed — strictly per-sub).
            await self._sink.flush()
            logger.info("[BARGE]   ⇒ audio sink flushed (cancelled sub gate active in TTSClient)")
        elif decision is BargeInDecision.GRACE_END:
            self._tracer.event(
                EventKind.AUDIO_END_GRACE_BLOCKED_BARGE_IN,
                ms_to_expected_end=ms_to_end,
            )

    def _on_pcm(self, pcm: bytes) -> None:
        """Called from TTSClient's reader for each PCM chunk.

        Per-sub PCM gating already happened inside TTSClient — PCM for
        cancelled sub_ids is dropped at the WS reader before reaching us.
        The only mute here is `_sink_muted`, used by prewarm to silently
        consume Kokoro cold-start audio.

        Bug #4 fix: call `play_sync` (not `create_task(self._sink.play)`).
        `play` has no awaits — wrapping each frame in a coroutine just
        adds scheduler latency and lets dozens of pending tasks pile up
        in the event loop. The sink-drain check then reads ~5 s of
        "buffered" audio when only ~1.5 s has truly arrived. Falling
        back to `create_task(play)` for sinks without `play_sync` (e.g.,
        NullSink in --no-playback) keeps protocol compliance.

        Note: AEC reference feeding does NOT happen here. It happens
        inside SpeakerAudioSink._callback via the
        `set_pcm_consumed_callback` hook — that's the moment bytes
        actually hit the speakers, ~50 ms before the mic captures the
        echo. Feeding from this callback (TTS arrival) would be
        catastrophically misaligned because the audio_sink buffers
        seconds of audio between arrival and playback.
        """
        if getattr(self, "_sink_muted", False):
            return
        play_sync = getattr(self._sink, "play_sync", None)
        if play_sync is not None:
            play_sync(pcm)
        else:
            asyncio.create_task(self._sink.play(pcm))

    # ── public introspection ─────────────────────────────────────────────────

    @property
    def state(self) -> SessionState:
        return self._state

    def summary(self) -> str:
        s = self._state
        usage_lines = _render_usage_table(s.llm_usage)

        lines = [
            "=" * 70,
            "  SESSION SUMMARY",
            "=" * 70,
            f"  session_id : {s.session_id}",
            f"  turns      : {len(s.turns)}",
            f"  strikes    : {s.barge_in_strike_count}",
            "",
            "=== llm usage ===",
            *usage_lines,
            "",
            f"=== transcript ({len(s.turns)} turns) ===",
        ]
        if not s.turns:
            lines.append("  (no turns recorded)")
        else:
            for t in s.turns:
                speaker = t.speaker.value if hasattr(t.speaker, "value") else t.speaker
                lines.append(f"  [{speaker:<11}] {t.text[:200]}")
        lines.append("")
        lines.append(f"event log: {self._event_log.path}")
        return "\n".join(lines)


# Per-model pricing now lives in `config/llm_models.yaml`, including the
# cache-read / cache-write discounts each provider applies. `compute_cost`
# resolves aliases, subtracts cached tokens before billing at the input
# rate, and bills cached/cache-write tokens at their own rates. Callers
# pass cached counts when available (the LLM client captures them from
# OpenRouter's `prompt_tokens_details`).
from engine.brain.llm.pricing import estimate_total_usd as _estimate_total_usd


def _estimate_cost_usd(
    model: str, tin: int, tout: int,
    cached: int = 0, cache_write: int = 0,
) -> float | None:
    return _estimate_total_usd(
        model,
        tokens_in=tin, tokens_out=tout,
        tokens_cached=cached, tokens_cache_write=cache_write,
    )


def _render_usage_table(usage: dict[str, dict[str, int]]) -> list[str]:
    if not usage:
        return ["  (no LLM calls)"]
    # Extra `cached` column makes the cache-hit savings visible at the
    # end of a run. Width stretched to fit; the table is for ops eyes
    # only, not parsed by anything.
    header_fmt = (
        "  {:<28} {:>5} {:>9} {:>9} {:>8} {:>8} {:>9}"
    )
    out = [
        header_fmt.format(
            "model", "calls", "in_tok", "out_tok",
            "cached", "avg_ms", "cost_usd",
        ),
        "  " + "─" * 84,
    ]
    total_in = total_out = total_cached = total_cw = total_calls = 0
    total_cost = 0.0
    cost_unknown = False
    for model, e in sorted(usage.items()):
        calls = e.get("calls", 0)
        tin = e.get("input_tokens", 0)
        tout = e.get("output_tokens", 0)
        tcached = e.get("cached_tokens", 0)
        tcw = e.get("cache_write_tokens", 0)
        avg_ms = (e.get("total_latency_ms", 0) // calls) if calls else 0
        cost = _estimate_cost_usd(model, tin, tout, tcached, tcw)
        cost_str = f"${cost:.4f}" if cost is not None else "?"
        if cost is None:
            cost_unknown = True
        out.append(
            header_fmt.format(
                model[:28], calls, tin, tout, tcached,
                f"{avg_ms}ms", cost_str,
            )
        )
        total_in += tin
        total_out += tout
        total_cached += tcached
        total_cw += tcw
        total_calls += calls
        total_cost += cost or 0.0
    out.append("  " + "─" * 84)
    total_cost_str = (
        f"${total_cost:.4f}{'+ unknown' if cost_unknown else ''}"
    )
    out.append(
        header_fmt.format(
            "TOTAL", total_calls, total_in, total_out, total_cached,
            "", total_cost_str,
        )
    )
    if total_cached:
        out.append(
            "  (cache-read tokens billed at provider's discounted rate; "
            f"cache-write tokens this run: {total_cw})"
        )
    return out
