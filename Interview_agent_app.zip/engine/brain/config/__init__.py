"""System config loader — reads config/system_config.yaml (tuning knobs).

Single source of truth for all non-secret, non-per-session tuning. Both the
local entry point (orchestrator_new.live_main) and the cloud entry point
(deploy.azure_app) load this and build a SessionConfig from it.

Three public helpers:
  - load_system_config(path=None)  → the raw nested dict
  - tuning_kwargs(cfg)             → flat SessionConfig kwargs (no secrets,
                                     no provider keys, no per-session fields)
  - resolve_providers(cfg, getenv=, slow_provider_override=)
                                   → llm_*/slow_llm_*/fast_llm_* kwargs with
                                     keys sourced from env. Centralises the
                                     provider/base-url/key resolution that used
                                     to be duplicated (and drift) across the
                                     two entry points.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Callable

import yaml

_PKG_DIR = Path(__file__).resolve().parent  # engine/brain/config

_PROVIDER_DEFAULTS = {
    "groq":       ("https://api.groq.com/openai/v1", "GROQ_API_KEY"),
    "openrouter": ("https://openrouter.ai/api/v1",   "OPENROUTER_API_KEY"),
    "openai":     ("https://api.openai.com/v1",      "OPENAI_API_KEY"),
}


def config_path() -> Path:
    """Resolve the system_config.yaml path. SYSTEM_CONFIG_PATH env overrides;
    otherwise <repo-root>/config/system_config.yaml."""
    override = os.environ.get("SYSTEM_CONFIG_PATH", "").strip()
    if override:
        return Path(override)
    return _PKG_DIR.parents[2] / "config" / "system_config.yaml"


def load_system_config(path: str | Path | None = None) -> dict[str, Any]:
    p = Path(path) if path else config_path()
    if not p.exists():
        raise FileNotFoundError(f"system config not found: {p}")
    return yaml.safe_load(p.read_text(encoding="utf-8")) or {}


def tuning_kwargs(cfg: dict[str, Any]) -> dict[str, Any]:
    """Map the yaml dict to SessionConfig tuning kwargs (everything except
    secrets, provider keys, and per-session fields)."""
    stt = cfg.get("stt", {}) or {}
    tts = cfg.get("tts", {}) or {}
    vad = cfg.get("vad", {}) or {}
    az = cfg.get("azure_speech", {}) or {}
    llm = cfg.get("llm", {}) or {}
    slow = llm.get("slow", {}) or {}
    fast = llm.get("fast", {}) or {}
    lat = cfg.get("latency", {}) or {}
    pol = cfg.get("policy", {}) or {}
    aec = cfg.get("aec", {}) or {}
    rt = cfg.get("runtime", {}) or {}
    adapt = cfg.get("adaptive_difficulty", {}) or {}

    from engine.brain.core.adaptive import AdaptiveConfig

    return dict(
        # STT
        stt_provider=stt.get("provider", "groq"),
        stt_model=stt.get("model", "whisper-large-v3"),
        stt_language=stt.get("language", "en"),
        stt_url=stt.get("url", "ws://localhost:8010/stt"),
        stt_no_speech_threshold=float(stt.get("no_speech_threshold", 0.6)),
        stt_preroll_ms=int(stt.get("preroll_ms", 50)),
        # TTS
        tts_provider=tts.get("provider", "kokoro"),
        tts_url=tts.get("url", "ws://localhost:8012/tts"),
        tts_sample_rate_hz=int(tts.get("sample_rate_hz", 16000)),
        # VAD
        vad_url=vad.get("url", "ws://localhost:8011/vad"),
        # Azure speech (non-secret)
        azure_speech_region=az.get("region", "eastus"),
        azure_speech_voice=az.get("voice", "en-US-AvaNeural"),
        # LLM models (keys/base-urls resolved separately)
        slow_model=slow.get("model", "openai/gpt-oss-120b"),
        slow_llm_max_tokens=int(slow.get("max_tokens", 2000)),
        fast_model=fast.get("model", "meta-llama/llama-3.1-8b-instruct"),
        # Latency
        use_filler=bool(lat.get("use_filler", True)),
        use_canned_filler=bool(lat.get("use_canned_filler", False)),
        filler_threshold_ms=int(lat.get("filler_threshold_ms", 5000)),
        apology_threshold_ms=int(lat.get("apology_threshold_ms", 10000)),
        strike_threshold=(
            999_999 if bool(lat.get("disable_strikes", False))
            else int(lat.get("strike_threshold", 3))
        ),
        # Policy
        endpoint_tail_ms=int(pol.get("endpoint_tail_ms", 600)),
        silence_prompt_ms=int(pol.get("silence_prompt_ms", 15000)),
        barge_in_warmup_ms=int(pol.get("barge_in_warmup_ms", 1500)),
        audio_end_grace_ms=int(pol.get("audio_end_grace_ms", 200)),
        max_follow_ups_per_question=int(pol.get("max_follow_ups_per_question", 1)),
        # AEC
        aec_enabled=bool(aec.get("enabled", False)),
        aec_stream_delay_ms=int(aec.get("stream_delay_ms", 50)),
        aec_noise_suppression=bool(aec.get("noise_suppression", True)),
        aec_high_pass_filter=bool(aec.get("high_pass_filter", True)),
        aec_auto_gain_control=bool(aec.get("auto_gain_control", False)),
        # Runtime
        tick_interval_ms=int(rt.get("tick_interval_ms", 500)),
        prewarm_kokoro=bool(rt.get("prewarm_kokoro", False)),
        # Adaptive (dynamic) difficulty rubric — only used by phases that set
        # adaptive_difficulty: true in the cadence.
        adaptive=AdaptiveConfig(
            start_difficulty=str(adapt.get("start_difficulty", "easy")),
            escalate_on_first_try=bool(adapt.get("escalate_on_first_try", True)),
            recovered_streak_to_escalate=int(
                adapt.get("recovered_streak_to_escalate", 2)
            ),
            deescalate_on_skip=bool(adapt.get("deescalate_on_skip", True)),
            neutral_on_default_answered=bool(
                adapt.get("neutral_on_default_answered", True)
            ),
        ),
    )


def resolve_providers(
    cfg: dict[str, Any],
    *,
    getenv: Callable[[str], str],
    slow_provider_override: str | None = None,
    fast_base_url_override: str | None = None,
) -> dict[str, Any]:
    """Resolve the LLM provider endpoints + keys into SessionConfig kwargs.

    `getenv(name)` returns the env value for `name` ('' if unset). Each entry
    point passes its own lookup (live_main's .env-aware finder, or
    os.environ.get on the cloud).

    Keys are read from env by NAME; this function never holds a literal key
    beyond what `getenv` returns. Mirrors the prior live_main / azure_app
    resolution so behaviour is unchanged — just centralised.
    """
    llm = cfg.get("llm", {}) or {}
    slow = llm.get("slow", {}) or {}
    fast = llm.get("fast", {}) or {}

    groq = getenv("GROQ_API_KEY")
    openrouter = getenv("OPENROUTER_API_KEY")

    # Primary fallback endpoint: Groq preferred, else OpenRouter, else config.
    if groq:
        primary_key, primary_base = groq, "https://api.groq.com/openai/v1"
    elif openrouter:
        primary_key, primary_base = openrouter, "https://openrouter.ai/api/v1"
    else:
        primary_key = ""
        primary_base = llm.get("default_base_url", "https://api.groq.com/openai/v1")

    # ── Slow LLM ──────────────────────────────────────────────────────────
    slow_provider = (slow_provider_override or slow.get("provider", "") or "").lower()
    slow_base_url: str | None = slow.get("base_url") or None
    slow_api_key: str | None = None
    env_var: str | None = slow.get("api_key_env") or None
    if slow_provider in _PROVIDER_DEFAULTS:
        default_url, default_env = _PROVIDER_DEFAULTS[slow_provider]
        slow_base_url = slow_base_url or default_url
        env_var = env_var or default_env
    elif slow_base_url and env_var is None:
        if "openrouter" in slow_base_url:
            env_var = "OPENROUTER_API_KEY"
        elif "openai.com" in slow_base_url:
            env_var = "OPENAI_API_KEY"
        elif "groq" in slow_base_url:
            env_var = "GROQ_API_KEY"
    if slow_base_url and env_var:
        slow_api_key = getenv(env_var) or None
    # OpenRouter provider routing for the slow LLM (analogous to the fast
    # path). Only applied when the slow LLM is hitting OpenRouter — direct
    # Groq / OpenAI ignore the `provider` extra_body.
    slow_provider_order: list[str] | None = None
    if slow_base_url and "openrouter" in slow_base_url:
        configured = slow.get("provider_order")
        if configured:
            slow_provider_order = list(configured)

    # ── Fast LLM (verifier / phase-override / filler / apology) ────────────
    # Default: route via OpenRouter (provider=Groq) when an OpenRouter key is
    # available, to sidestep Groq direct-API 429 storms.
    fast_base_url: str | None = (
        fast_base_url_override or fast.get("base_url") or None
    )
    fast_api_key: str | None = None
    if fast_base_url is None and openrouter:
        fast_base_url = "https://openrouter.ai/api/v1"
    if fast_base_url and "openrouter" in fast_base_url:
        fast_api_key = openrouter
    elif fast_base_url and "groq" in fast_base_url:
        fast_api_key = groq
    elif fast_base_url:
        fast_api_key = primary_key
    fast_provider_order: list[str] | None = None
    if fast_base_url and "openrouter" in fast_base_url:
        fast_provider_order = list(fast.get("provider_order") or ["Groq"])

    return dict(
        llm_api_key=primary_key,
        llm_base_url=primary_base or "https://api.groq.com/openai/v1",
        slow_llm_api_key=slow_api_key,
        slow_llm_base_url=slow_base_url,
        slow_llm_provider_order=slow_provider_order,
        fast_llm_api_key=fast_api_key,
        fast_llm_base_url=fast_base_url,
        fast_llm_provider_order=fast_provider_order,
        # Azure Speech key — sourced from env (secret). Stream B requires
        # this when stt_provider or tts_provider == "azure". Without this
        # line, live_main built a SessionConfig with azure_speech_key=None
        # even when AZURE_SPEECH_KEY was set in .env — only deploy/azure_app
        # was reading it explicitly.
        azure_speech_key=getenv("AZURE_SPEECH_KEY") or None,
    )
