"""Cadence-plan data model.

This is the canonical structure of an interview timeline. The tracker
keys off these fields directly, and the loader (whether parsing a YAML
file directly or a free-form description through an LLM) MUST emit a
plan that round-trips through `CadencePlan.model_validate`.

Why pydantic: gives us schema validation, clear error messages on
malformed input, and easy JSON/YAML round-tripping. The loader uses
`model_validate` to enforce the contract — if the slow LLM produces
malformed YAML when converting from prose, we catch it deterministically
before any of the interview machinery sees it.
"""
from __future__ import annotations

from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, model_validator

from engine.brain.cadence import question_types as qt


def _is_blank(value: object) -> bool:
    """True for None, an empty/whitespace-only string, or an empty/all-blank
    list — the one "is this field actually set" check shared by every
    written-response validator so a string_list field (e.g. ground_truth) is
    treated the same as a plain string field everywhere blankness matters."""
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    if isinstance(value, list):
        return not any(isinstance(v, str) and v.strip() for v in value)
    return False


class WrittenQuestion(BaseModel):
    """PER-QUESTION config inside a written-response phase (see WrittenResponse).

    Holds what varies question to question: the limits, the countdown, the
    material the candidate works from (a clip, a passage, an image), and the
    LANGUAGE PAIR. Only the question TYPE is phase-level — one phase is one kind
    of task, but it may mix language pairs across its questions. Any field left
    unset falls back to the phase-level block, so a legacy single-question essay
    phase (everything at phase level, no per-question block) — and any phase
    authored while the pair was phase-level — keeps working untouched."""

    char_limit: int | None = Field(default=None, gt=0)
    word_limit: int | None = Field(default=None, gt=0)  # legacy essays only
    time_limit_s: int | None = Field(default=None, gt=0)
    source_text: str | None = None
    audio_asset: str | None = None
    image_asset: str | None = None
    # Validated on the RESOLVED config (WrittenResponse.resolved_for rebuilds a
    # WrittenResponse, which checks both codes against the catalog), so an
    # off-list code on a question is rejected at plan load like any other.
    source_language: str | None = None
    target_language: str | None = None
    # transcription: exact reference transcript (str). translation /
    # image_description: one or more accepted reference answers (list[str]).
    # Server-side only — never sent to the candidate. Optional at the schema
    # level (see question_types.FieldSpec.ui_required) so existing questions
    # authored before this field existed keep validating unchanged.
    ground_truth: str | list[str] | None = None

    @model_validator(mode="after")
    def _one_limit_at_most(self) -> "WrittenQuestion":
        if self.char_limit is not None and self.word_limit is not None:
            raise ValueError(
                "a written question sets at most one of char_limit / word_limit"
            )
        return self


class QuestionPoolItem(BaseModel):
    """One concrete question. Used only when a phase has
    `question_mode == "specific"`.

    The tracker picks items by index from the pool and removes the picked
    item so each is asked at most once per interview. When the pool is
    exhausted the phase auto-advances (regardless of remaining time).
    """

    id: str = Field(min_length=1, description="Stable identifier, e.g. 'attn_basic'")
    text: str = Field(min_length=1, description="The question text to ask")
    topic: str = ""
    # Optional difficulty. Carried through to runtime so an adaptive phase can
    # bucket its pool by level and escalate/de-escalate. Static (non-adaptive)
    # phases ignore it — left None on the legacy customizer path.
    difficulty: Literal["easy", "medium", "hard"] | None = None
    # Coverage tags: short concept keywords a COMPLETE answer must address.
    # The verifier checks the candidate's reply against each tag and reports
    # which are missing; the interviewer then probes only the missing concepts.
    # This is the current model. `follow_ups` (full follow-up questions) is the
    # legacy field kept for backward compatibility — when `coverage_tags` is
    # empty we fall back to it. Prefer tags for new pools/cadences.
    coverage_tags: list[str] = Field(default_factory=list)
    follow_ups: list[str] = Field(default_factory=list)

    # ── Written-response material for THIS question (optional) ───────────────
    # Only meaningful inside a written-response phase (see WrittenResponse):
    # each question carries its own limits + material, so one phase can hold N
    # clips / passages / images. Absent → the phase-level block's values apply
    # (which is what a legacy single-question essay phase relies on).
    written_response: WrittenQuestion | None = Field(default=None)

    def coverage_points(self) -> list[str]:
        """The checklist a complete answer must cover — coverage_tags when
        present, else the legacy follow_ups. Used by the verifier rubric and
        the interviewer's probe directive."""
        return self.coverage_tags or self.follow_ups

    @property
    def uses_tags(self) -> bool:
        """True when this item carries concept tags (vs legacy follow-up
        questions) — lets renderers label the checklist correctly."""
        return bool(self.coverage_tags)


class WrittenResponse(BaseModel):
    """Config for a one-shot WRITTEN-RESPONSE phase — the text counterpart to the
    voice coding phase's submit lifecycle.

    When a PhaseDef carries this, each of the phase's question_pool items is a
    one-shot written question: the candidate is shown that question's prompt plus
    whatever material the question type supplies (an audio clip, a source passage,
    an image), an optional CLIENT-side countdown starts on display, and submit (or
    expiry) closes THAT question with no verifier follow-up loop. The tracker then
    presents the next question in the pool and the phase ends when the pool is
    exhausted — so a phase holds N questions of ONE type. The character/word limit
    + countdown are client-enforced so the text tier stays stateless; each
    submission is a normal candidate turn, scored by the usual eval plugins (e.g.
    conversational_rubric / rubric_marks). Timed per-QUESTION even inside an
    otherwise-untimed (text) interview.

    THIS block holds what the whole phase shares: the `question_type` and the
    language pair. Limits + material may also be set here, in which case they are
    DEFAULTS for every question that doesn't carry its own (see WrittenQuestion) —
    which is exactly how a legacy single-question essay phase is shaped.

    `question_type` selects which material/config applies — the definitions live
    in ONE place (`question_types.QUESTION_TYPES`) and the validators drive
    entirely off that table. BACKWARD COMPATIBILITY: a legacy essay block
    (`{word_limit, time_limit_s}`, no question_type) reads as "comprehensive"
    with a WORD limit, which is exactly what it was."""

    question_type: str = Field(
        default=qt.DEFAULT_QUESTION_TYPE,
        description="One of question_types.QUESTION_TYPE_IDS",
    )

    # ── limits: exactly ONE of these ─────────────────────────────────────────
    # char_limit is canonical for anything authored after the Add-Phase work;
    # word_limit is the LEGACY essay field, still honored (and still counted in
    # words by the candidate UI) so approved interviews are untouched.
    char_limit: int | None = Field(
        default=None, gt=0, description="Max characters the candidate may submit",
    )
    word_limit: int | None = Field(
        default=None, gt=0,
        description="LEGACY: max words. Prefer char_limit for new phases.",
    )
    # None → UNTIMED: a limited written answer the candidate submits when ready
    # (no countdown). A positive value → the client shows a countdown and
    # auto-submits on expiry. Either way it's a one-shot phase (submission ends it).
    time_limit_s: int | None = Field(
        default=None, gt=0,
        description="Countdown seconds; None = untimed (submit when ready)",
    )

    # ── type-specific material (each required by exactly one question type) ──
    # Names/requirements are NOT duplicated here — see question_types.py.
    source_text: str | None = Field(
        default=None, description="translation: the passage shown verbatim",
    )
    source_language: str | None = Field(
        default=None, description="transcription/translation: language code",
    )
    target_language: str | None = Field(
        default=None, description="transcription/translation: language code",
    )
    audio_asset: str | None = Field(
        default=None, description="transcription: uploaded asset name",
    )
    image_asset: str | None = Field(
        default=None, description="image_description: uploaded asset name",
    )
    ground_truth: str | list[str] | None = Field(
        default=None,
        description="transcription: exact transcript (str). translation / "
                    "image_description: accepted answers (list[str]). Server-only.",
    )

    @model_validator(mode="after")
    def _check_question_type(self) -> "WrittenResponse":
        spec = qt.spec_for(self.question_type)  # raises on an unknown type

        # At most one limit here — "exactly one" is checked on the RESOLVED
        # per-question config (a phase may legitimately leave limits to its
        # questions), see PhaseDef._check_mode_data.
        if self.char_limit is not None and self.word_limit is not None:
            raise ValueError(
                "written_response sets at most one of char_limit / word_limit "
                f"(got char_limit={self.char_limit!r}, word_limit={self.word_limit!r})"
            )

        own = {f.name for f in spec.fields}
        for field in spec.fields:
            value = getattr(self, field.name, None)
            if _is_blank(value):
                # Phase-scoped fields (the language pair) are required HERE;
                # question-scoped material is required on the resolved config,
                # so it may be absent from this block.
                if field.required and field.scope == "phase":
                    raise ValueError(
                        f"question_type '{self.question_type}' requires "
                        f"'{field.name}' ({field.label})"
                    )
                continue
            if field.kind == "language" and not qt.is_language(str(value)):
                raise ValueError(
                    f"'{field.name}' must be a language code from the catalog, "
                    f"got {value!r}"
                )
            if field.kind == "string_list" and not isinstance(value, list):
                raise ValueError(
                    f"'{field.name}' must be a list of strings, got {type(value).__name__}"
                )

        # A field belonging to a DIFFERENT type is a config error, not something
        # to silently carry (e.g. source_text on a transcription phase).
        for name in qt.ALL_TYPE_FIELDS:
            if name in own:
                continue
            value = getattr(self, name, None)
            if not _is_blank(value):
                raise ValueError(
                    f"'{name}' does not apply to question_type "
                    f"'{self.question_type}'"
                )
        return self

    # ── phase defaults + per-question overrides → ONE resolved config ────────
    def resolved_for(self, question: WrittenQuestion | None) -> "WrittenResponse":
        """This block with the question's own values layered on top — the config
        the candidate actually gets for that question. Re-validated by
        construction (so a question can't smuggle in material foreign to the
        phase's type). A limit set on the question REPLACES the phase's, whichever
        unit it uses, so a char-limited question inside a legacy word-limited
        phase doesn't end up with both."""
        if question is None:
            return self
        data = self.model_dump()
        if question.char_limit is not None or question.word_limit is not None:
            data["char_limit"] = question.char_limit
            data["word_limit"] = question.word_limit
        for name in ("time_limit_s", *qt.ALL_TYPE_FIELDS):
            value = getattr(question, name, None)
            if not _is_blank(value):
                data[name] = value
        return WrittenResponse.model_validate(data)

    def missing_requirements(self) -> list[str]:
        """What this (resolved) config still needs before a candidate could
        answer it: the type's required material and exactly one limit. Shared by
        PhaseDef validation and the authoring builder so both refuse the same
        things with the same words. Only checks SCHEMA-required fields
        (`FieldSpec.required`) — a `ui_required`-only field (e.g. ground_truth)
        is enforced by the authoring form, not here, so a question saved before
        that field existed keeps validating."""
        problems: list[str] = []
        if (self.char_limit is None) == (self.word_limit is None):
            problems.append("exactly one of char_limit / word_limit")
        for field in qt.spec_for(self.question_type).fields:
            if not field.required:
                continue
            value = getattr(self, field.name, None)
            if _is_blank(value):
                problems.append(f"{field.name} ({field.label})")
        return problems

    # ── ergonomic accessors (used by the text service + renderers) ───────────
    @property
    def limit_kind(self) -> str:
        """"chars" for anything authored with char_limit, "words" for a legacy
        essay — the candidate's counter counts whichever this says."""
        return "words" if self.word_limit is not None else "chars"

    @property
    def limit_value(self) -> int:
        return int(self.word_limit if self.word_limit is not None else self.char_limit or 0)

    @property
    def asset_name(self) -> str | None:
        """The uploaded asset this phase needs, if any (audio or image)."""
        return self.audio_asset or self.image_asset


class InlineCodingQuestion(BaseModel):
    """A coding question stored IN the cadence rather than referenced by id.

    Same field names as `features/coding/questions/library.yaml`, so
    `features.coding.get_question` can hand the runtime an identical `Question`
    whichever source it came from — the browser payload, the test runner and the
    evaluator all stay untouched.

    WHY embedded: a pool is a TEMPLATE, not a live dependency. Copying the
    definition in at apply time is what lets an admin edit or delete a pool
    without silently changing an interview already sent to a candidate — the
    same rule `question_pool_routes.questions_for_phase` already applies to
    uploaded audio/image material.
    """

    model_config = ConfigDict(extra="forbid")

    title: str = ""
    prompt: str = ""
    starter_code: str = ""
    function_name: str = ""
    # [{name, input, expected}] — python source strings, the shape the Pyodide
    # runner already evals.
    test_cases: list[dict[str, str]] = Field(default_factory=list)
    solution: str = ""
    hints: list[str] = Field(default_factory=list)
    difficulty: str = "easy"
    topic: list[str] = Field(default_factory=list)
    role_fit: list[str] = Field(default_factory=list)
    estimated_time_s: int = 0
    language: str = "python"


class ScenarioMedia(BaseModel):
    """One uploaded media asset for a Visual Scenario Analysis item — an image,
    video, or audio clip the candidate is shown before answering. Reuses the
    SAME phase-asset upload/storage/serving mechanism as image_description
    questions (`question_types.ASSET_RULES` + the `/api/cadence/{token}/
    phase-asset` upload + `/api/sessions/{token}/phase-asset/{name}` serving
    route): `ref` is the stored filename, never bytes — cadence.yaml never
    carries media data, only the reference."""

    model_config = ConfigDict(extra="forbid")

    kind: Literal["image", "video", "audio"]
    ref: str = Field(
        min_length=1,
        description="Stored asset filename, from the phase-asset upload response",
    )
    filename: str = Field(min_length=1, description="Original filename, for display")
    mime_type: str = Field(min_length=1)

    @model_validator(mode="after")
    def _check_mime_matches_kind(self) -> "ScenarioMedia":
        prefix = self.mime_type.split("/", 1)[0].lower()
        if prefix != self.kind:
            raise ValueError(
                f"media kind '{self.kind}' does not match mime_type "
                f"'{self.mime_type}' (expected a '{self.kind}/...' type)"
            )
        return self


class ScenarioItem(BaseModel):
    """One prompt in a Visual Scenario Analysis phase: a media asset, an
    admin-written question about it, and the concepts a complete answer should
    cover. Ordered within the phase — `items[i].id` is stable, like
    `QuestionPoolItem.id`. The runtime (not implemented at this layer) shows
    the media, asks a rephrased version of `question`, and may follow up up to
    `max_followups` times against `coverage_tags` — the same verifier-driven
    follow-up loop `QuestionPoolItem.coverage_tags` already drives. Scoring
    reuses the existing LLM-as-judge rubric approach; not implemented here."""

    model_config = ConfigDict(extra="forbid")

    id: str = Field(min_length=1, description="Stable identifier within the phase, e.g. 'diagram_1'")
    media: ScenarioMedia
    question: str = Field(min_length=1, description="Admin-written question about the media")
    coverage_tags: list[str] = Field(
        default_factory=list,
        description="Concepts a complete answer should address — not all are required",
    )
    max_followups: int = Field(default=2, ge=0, le=5)

    @model_validator(mode="after")
    def _clean_coverage_tags(self) -> "ScenarioItem":
        cleaned: list[str] = []
        for tag in self.coverage_tags:
            t = tag.strip()
            if t and t not in cleaned:
                cleaned.append(t)
        if not cleaned:
            raise ValueError(
                f"scenario item '{self.id}': coverage_tags must have at least "
                "one non-empty tag"
            )
        object.__setattr__(self, "coverage_tags", cleaned)
        return self


class PhaseDef(BaseModel):
    """One phase of the interview.

    `question_mode` says what KIND of phase this is, and with it where the AI's
    questions come from:
      - "generic":  the slow LLM improvises from `generic_prompts` and
                    the candidate's resume / role. Best for warm-up and
                    project-deep-dive style phases.
      - "specific": the tracker hands the slow LLM exactly one question
                    per turn from `question_pool`, and removes it after
                    use. Best for screening rounds where coverage matters
                    more than flow.
      - a WRITTEN-RESPONSE type ("comprehensive", "translation",
                    "transcription", "image_description", …): mechanically the
                    same pool-driven flow as "specific", but the phase is a
                    typed one-shot task rather than a spoken exchange.

    WHY the written types are named here instead of all reporting "specific":
    the mode is the one field every layer reads to know what a phase IS —
    the tracker, the director, the verifier's phase descriptor, the eval
    sectioner and the admin UI. Collapsing four distinct tasks into "specific"
    forced each layer to re-derive the real kind from a side-channel (this is
    what coding phases still do via `coding_question_ids`, and it means the
    same inference is written five times over). Stating it once here keeps every
    consumer honest — and, notably, tells the VERIFIER it is grading a
    translation rather than a spoken answer.

    The allowed values are NOT hardcoded: they are "generic", "specific", plus
    whatever `question_types.QUESTION_TYPE_IDS` declares, so a new written type
    is one entry in that table and needs no edit here.

    Anything that is not "generic" is pool-backed — use `uses_question_pool`
    rather than comparing against "specific", so a new kind can never be missed
    by a call site (see the accessor's note).

    Exactly one of (`generic_prompts`, `question_pool`) is required,
    matching `question_mode`.
    """

    id: str = Field(min_length=1, pattern=r"^[a-z][a-z0-9_]*$",
                    description="snake_case identifier, e.g. 'warm_up'")
    duration_s: int = Field(gt=0, description="Phase budget in seconds")
    intent: str = Field(min_length=1,
                        description="One-line summary of the phase's goal — "
                                    "embedded into the slow LLM's system prompt")
    # A plain str validated in _check_question_mode against the registry, NOT a
    # Literal: a new written type must not require a schema edit.
    question_mode: str
    generic_prompts: list[str] = Field(default_factory=list)
    question_pool: list[QuestionPoolItem] = Field(default_factory=list)

    # ── Adaptive (dynamic) difficulty (optional, off by default) ─────────────
    # When True, this `specific` phase loads its whole pool (all difficulties)
    # and the runtime escalates/de-escalates the next question's difficulty
    # based on the verifier's per-question outcomes. Requires every pool item
    # to carry a `difficulty`. See stream_b_new/core/adaptive.py + the
    # reading/adaptive_difficulty_plan.md design note. Backward compatible:
    # default False makes a specific phase behave exactly as before (static
    # FIFO over the author's pool order).
    adaptive_difficulty: bool = Field(default=False)
    adaptive_start_difficulty: Literal["easy", "medium", "hard"] | None = Field(
        default=None,
        description="Difficulty the adaptive phase opens at. Defaults to 'easy' "
                    "(or the lowest present level) when unset.",
    )

    # ── Coding phase (optional, off by default) ─────────────────────────────
    # See coding/README.md for the full feature. When `coding_question_id`
    # is set, this phase is a coding exercise instead of a conversation.
    # The question_mode + generic_prompts/question_pool fields are still
    # required (used for AI banter around the coding phase, e.g., introducing
    # the question and following up after submission).
    #
    # Validators below ALLOW question_pool/generic_prompts to be empty when
    # coding_question_id is set — the AI uses a built-in intro/wrap script.
    coding_question_id: str | None = Field(
        default=None,
        description="LEGACY single-question form. Use `coding_question_ids` "
                    "for new cadences. Kept for backwards compat; the "
                    "validator auto-converts to a single-element list.",
    )
    coding_question_ids: list[str] = Field(
        default_factory=list,
        description="List of question ids from coding/questions/library.yaml "
                    "for this coding phase. Candidate sees them as tabs and "
                    "submits each independently. Requires CODING_ENABLED.",
    )
    coding_questions_inline: dict[str, "InlineCodingQuestion"] = Field(
        default_factory=dict,
        description="Full question definitions embedded in THIS cadence, keyed "
                    "by the same id that appears in `coding_question_ids`. "
                    "Written when a question is pulled from an admin-authored "
                    "question pool: the definition is COPIED here so editing or "
                    "deleting that pool later cannot change — or break — an "
                    "interview that was already approved. A qid with no entry "
                    "here is resolved from the built-in library as before.",
    )
    coding_question_time_overrides: dict[str, int] | None = Field(
        default=None,
        description="Per-question time override in seconds: "
                    "{question_id: seconds}. When unset, each question uses "
                    "its library `estimated_time_s` (default by difficulty: "
                    "easy=600 / medium=1200 / hard=1800).",
    )
    # `coding_time_budget_s` was previously a separate editor-only countdown
    # but ended up confusing in practice (it was display-only; phase actually
    # ended at `duration_s`). Single source of truth: `duration_s`. Pydantic
    # silently ignores legacy YAMLs that still set the old field.

    # ── Timed written-response / essay phase (optional, off by default) ──────
    # When set, this phase is a timed comprehension/essay submission (see
    # WrittenResponse). Its single question_pool item is the prompt; the client
    # shows a word-limited composer + countdown and submit/expiry ends the phase.
    written_response: WrittenResponse | None = Field(default=None)

    # ── Visual Scenario Analysis phase (optional, off by default) ────────────
    # Presence of `scenario_items` is what makes this phase kind — mirroring
    # `coding_question_ids`, question_mode stays "generic" either way (used only
    # for the AI's own banter introducing/wrapping the phase, exactly like a
    # coding phase). Each item pairs one uploaded media asset with an
    # admin-written question and coverage tags. VOICE/VIDEO interviews only —
    # never valid when the plan is untimed (a text interview); see
    # CadencePlan._check_video_only_phases.
    scenario_items: list["ScenarioItem"] = Field(
        default_factory=list,
        description="Ordered Visual Scenario Analysis items (media + question "
                    "+ coverage tags) for this phase. Non-empty marks the "
                    "phase as scenario_analysis.",
    )

    # ── question_mode helpers — the ONE place that knows what a mode implies ──
    @property
    def uses_question_pool(self) -> bool:
        """True when the tracker sources this phase's questions from
        `question_pool` (i.e. anything that is not "generic").

        Every runtime call site MUST branch on this rather than
        `question_mode == "specific"`. A literal comparison silently excludes
        each new written type — and the most dangerous instance is the tracker's
        pool INITIALISATION, where being missed means the phase is built with no
        questions at all and the interview quietly has nothing to ask."""
        return self.question_mode != "generic"

    @property
    def written_question_type(self) -> str | None:
        """The written-response task type this phase runs, or None for a spoken
        phase. Reads the mode first (the canonical statement) and falls back to
        the block for cadences authored while the mode still said "specific"."""
        if self.written_response is None:
            return None
        if self.question_mode in qt.QUESTION_TYPE_IDS:
            return self.question_mode
        return self.written_response.question_type

    @property
    def is_scenario_analysis(self) -> bool:
        """True when this phase presents Visual Scenario Analysis items (media
        + question + coverage tags) rather than a spoken/pool-backed
        conversation. Orthogonal to question_mode, mirroring how
        `coding_question_ids` marks a coding phase — question_mode stays
        "generic" either way."""
        return bool(self.scenario_items)

    @model_validator(mode="after")
    def _check_question_mode(self) -> "PhaseDef":
        """`question_mode` must name a known kind. Allowed values come from the
        question-type registry, so adding a type never edits this file."""
        allowed = {"generic", "specific", *qt.QUESTION_TYPE_IDS}
        if self.question_mode not in allowed:
            raise ValueError(
                f"phase '{self.id}': unknown question_mode "
                f"{self.question_mode!r} (expected one of: "
                f"{', '.join(sorted(allowed))})"
            )
        # A mode naming a written type must agree with the block it describes,
        # otherwise two fields claim different tasks and every consumer has to
        # guess which wins.
        if self.question_mode in qt.QUESTION_TYPE_IDS:
            if self.written_response is None:
                raise ValueError(
                    f"phase '{self.id}': question_mode='{self.question_mode}' "
                    "is a written-response task but the phase has no "
                    "written_response block"
                )
            declared = self.written_response.question_type
            if declared != self.question_mode:
                raise ValueError(
                    f"phase '{self.id}': question_mode='{self.question_mode}' "
                    f"disagrees with written_response.question_type="
                    f"'{declared}' — they name the same task"
                )
        return self

    @model_validator(mode="after")
    def _check_mode_data(self) -> "PhaseDef":
        # Normalize the legacy single-question form into the canonical list
        # form, then DROP the legacy field so the model is IDEMPOTENT across
        # YAML round-trips (dump -> load). The validator previously lifted the
        # id into the list but left `coding_question_id` set, so the phase
        # serialized BOTH fields and re-parsing tripped this guard on every
        # customize / revise / validate / approve round-trip. We now:
        #   - error only on a genuine CONFLICT (legacy id ≠ the list),
        #   - accept the consistent round-tripped case (id present + ids==[id]),
        #   - always clear the legacy field after lifting.
        if self.coding_question_id is not None:
            if self.coding_question_ids and self.coding_question_ids != [self.coding_question_id]:
                raise ValueError(
                    f"phase '{self.id}': conflicting `coding_question_id` "
                    f"({self.coding_question_id!r}) and `coding_question_ids` "
                    f"({self.coding_question_ids!r}). Use `coding_question_ids` only."
                )
            object.__setattr__(
                self, "coding_question_ids",
                self.coding_question_ids or [self.coding_question_id],
            )
            object.__setattr__(self, "coding_question_id", None)

        is_coding = bool(self.coding_question_ids)
        is_scenario = bool(self.scenario_items)

        # ── Scenario-analysis conflicts ──────────────────────────────────────
        # Checked up front (before the coding/written-response blocks run their
        # own logic) so a phase can never be silently BOTH kinds — whichever
        # field is not the phase's real kind must be empty.
        if is_scenario:
            if is_coding:
                raise ValueError(
                    f"phase '{self.id}': scenario_items and coding are "
                    "mutually exclusive"
                )
            if self.written_response is not None:
                raise ValueError(
                    f"phase '{self.id}': scenario_items and written_response "
                    "are mutually exclusive"
                )
            if self.adaptive_difficulty:
                raise ValueError(
                    f"phase '{self.id}': scenario_items phases cannot be "
                    "adaptive (adaptive_difficulty requires a pool-backed "
                    "question_mode)"
                )

        # ── Written-response preconditions ──────────────────────────────────
        # One or more one-shot written questions of ONE type: every pool question
        # is a prompt the candidate answers in writing, each closed by its own
        # submission. Mutually exclusive with coding and adaptive difficulty.
        if self.written_response is not None:
            if is_coding:
                raise ValueError(
                    f"phase '{self.id}': written_response and coding are "
                    "mutually exclusive"
                )
            if self.adaptive_difficulty:
                raise ValueError(
                    f"phase '{self.id}': written_response phases cannot be adaptive"
                )
            if not self.uses_question_pool or not self.question_pool:
                raise ValueError(
                    f"phase '{self.id}': written_response requires a "
                    "pool-backed question_mode (its own type, or 'specific') "
                    "with at least one pool question "
                    "(each pool question is one written prompt)"
                )
            # Each question must be COMPLETE once the phase defaults are applied.
            for item in self.question_pool:
                resolved = self.written_response.resolved_for(item.written_response)
                problems = resolved.missing_requirements()
                if problems:
                    raise ValueError(
                        f"phase '{self.id}' question '{item.id}': "
                        f"{self.written_response.question_type} needs "
                        f"{', '.join(problems)}"
                    )
        elif any(q.written_response is not None for q in self.question_pool):
            # Per-question written config with no phase block would be silently
            # ignored at runtime (the phase isn't a written-response phase).
            raise ValueError(
                f"phase '{self.id}': a question carries a written_response block "
                "but the phase has none — add the phase-level written_response "
                "(it holds the question type)"
            )

        # ── Adaptive-difficulty preconditions ──────────────────────────────
        # Adaptive only makes sense for a conversational `specific` pool.
        if self.adaptive_difficulty:
            if is_coding:
                raise ValueError(
                    f"phase '{self.id}': adaptive_difficulty is not supported "
                    "on coding phases"
                )
            if not self.uses_question_pool:
                raise ValueError(
                    f"phase '{self.id}': adaptive_difficulty requires a "
                    "pool-backed question_mode (e.g. 'specific')"
                )
        # When coding phase, relax the generic/specific data requirement —
        # the coding library supplies the question. AI still uses a small
        # canned intro ("Let's do a short coding exercise.") and wrap-up.
        if is_coding:
            # Sanity: ensure mode-data fields are not also populated, to avoid
            # ambiguity at runtime (which does the AI use, the pool or the question?).
            if self.generic_prompts and self.question_pool:
                raise ValueError(
                    f"phase '{self.id}': coding phase cannot also have BOTH "
                    "generic_prompts and question_pool"
                )
            # Time-override map keys must reference questions in the list.
            if self.coding_question_time_overrides:
                for qid, secs in self.coding_question_time_overrides.items():
                    if qid not in self.coding_question_ids:
                        raise ValueError(
                            f"phase '{self.id}': coding_question_time_overrides "
                            f"has unknown question id '{qid}' (not in "
                            f"coding_question_ids)"
                        )
                    if not isinstance(secs, int) or secs < 30:
                        raise ValueError(
                            f"phase '{self.id}': time override for '{qid}' "
                            f"must be an int ≥ 30, got {secs!r}"
                        )
            # If admin omitted generic_prompts on a coding phase, inject a
            # safe default opener so the slow LLM doesn't improvise.
            # Cadence-converter LLM and hand-edits often forget this field
            # because the schema relaxes the requirement above.
            if not self.generic_prompts and not self.question_pool:
                multi = len(self.coding_question_ids) > 1
                opener = (
                    "Briefly tell the candidate we're going to do a short "
                    "coding round with several questions. Each question "
                    "has its own timer; they can work on them in any order. "
                    "Tell them to begin whenever they're ready."
                    if multi else
                    "Briefly tell the candidate we're going to do a short "
                    "coding exercise. The question is on the screen — "
                    "they can ask if anything is unclear; otherwise let "
                    "them begin."
                )
                object.__setattr__(self, "generic_prompts", [opener])
            return self

        # If scenario_items is set, this is a Visual Scenario Analysis phase —
        # same relaxation as coding: the AI only needs banter to introduce and
        # wrap the phase, and item ids must be unique within it.
        if is_scenario:
            if self.generic_prompts and self.question_pool:
                raise ValueError(
                    f"phase '{self.id}': a scenario_items phase cannot also "
                    "have BOTH generic_prompts and question_pool"
                )
            seen_items: set[str] = set()
            for item in self.scenario_items:
                if item.id in seen_items:
                    raise ValueError(
                        f"phase '{self.id}': duplicate scenario item id "
                        f"'{item.id}'"
                    )
                seen_items.add(item.id)
            if not self.generic_prompts and not self.question_pool:
                object.__setattr__(self, "generic_prompts", [
                    "Briefly tell the candidate you'll show them a short "
                    "scenario — an image, clip, or recording — and ask them "
                    "to walk through what they see. Let them take their time "
                    "before answering."
                ])
            return self

        if not self.uses_question_pool:
            if not self.generic_prompts:
                raise ValueError(
                    f"phase '{self.id}': question_mode='generic' but "
                    "generic_prompts is empty"
                )
            if self.question_pool:
                raise ValueError(
                    f"phase '{self.id}': question_mode='generic' but "
                    "question_pool is non-empty (use 'specific' or remove pool)"
                )
        else:  # any pool-backed mode: "specific" or a written-response type
            if not self.question_pool:
                raise ValueError(
                    f"phase '{self.id}': question_mode='{self.question_mode}' "
                    "but question_pool is empty"
                )
            if self.generic_prompts:
                raise ValueError(
                    f"phase '{self.id}': question_mode='{self.question_mode}' "
                    "but generic_prompts is non-empty "
                    "(use 'generic' or remove prompts)"
                )
            # Pool IDs must be unique within a phase.
            seen: set[str] = set()
            for q in self.question_pool:
                if q.id in seen:
                    raise ValueError(
                        f"phase '{self.id}': duplicate question id '{q.id}'"
                    )
                seen.add(q.id)
            # Adaptive phases need a difficulty on every pooled question (so the
            # runtime can bucket them) and ≥1 question at the requested start
            # level when one is pinned.
            if self.adaptive_difficulty:
                missing = [q.id for q in self.question_pool if q.difficulty is None]
                if missing:
                    raise ValueError(
                        f"phase '{self.id}': adaptive_difficulty=True but these "
                        f"pool questions have no difficulty: {missing}"
                    )
                if self.adaptive_start_difficulty is not None:
                    present = {q.difficulty for q in self.question_pool}
                    if self.adaptive_start_difficulty not in present:
                        raise ValueError(
                            f"phase '{self.id}': adaptive_start_difficulty="
                            f"'{self.adaptive_start_difficulty}' but no pool "
                            f"question has that difficulty (present: "
                            f"{sorted(d for d in present if d)})"
                        )
        return self


class CadencePlan(BaseModel):
    """Top-level container. A loaded cadence is plugged into SessionConfig
    and consumed by the CadenceTracker at runtime."""

    total_duration_s: int = Field(gt=0)
    phases: list[PhaseDef] = Field(min_length=1)
    # Admin-set at schedule time, immutable, mirrored here (deterministically
    # stamped by app.cadence_service.apply_recording_flag — never LLM-authored)
    # so the candidate lobby reads it like everything else it consumes from
    # cadence.yaml. Missing on older files → True, matching today's mandatory
    # camera+screen behavior, so pre-existing interviews are unaffected.
    recording_enabled: bool = Field(default=True)
    # Whether this interview is paced by a wall-clock (voice) or purely
    # question-driven (text). When False, the CadenceTracker's time-budget
    # advancement is disabled and phases advance only on question-pool
    # exhaustion / explicit signal — see cadence_tracker.check_phase_budget.
    # Defaults True so every existing voice plan is unchanged; untimed (text)
    # plans still carry positive dummy per-phase durations (PhaseDef.duration_s
    # stays gt=0), so only the plan-level sum check below is relaxed.
    timed: bool = Field(default=True)

    @model_validator(mode="after")
    def _check_totals(self) -> "CadencePlan":
        ids = [p.id for p in self.phases]
        if len(ids) != len(set(ids)):
            raise ValueError(f"phase ids must be unique, got {ids}")
        # Untimed plans don't budget by seconds, so the durations are dummies
        # and need not sum to the (also dummy) total. The unique-id check above
        # still runs for every plan.
        if not self.timed:
            return self
        summed = sum(p.duration_s for p in self.phases)
        if summed != self.total_duration_s:
            raise ValueError(
                f"total_duration_s={self.total_duration_s} does not match the "
                f"sum of phase durations ({summed})"
            )
        return self

    @model_validator(mode="after")
    def _check_video_only_phases(self) -> "CadencePlan":
        """Visual Scenario Analysis shows the candidate media and needs a live
        voice/video exchange to talk it through — it never runs in a TEXT
        interview. `timed=False` is the existing modality signal
        (`app.cadence_service.apply_modality_flag` stamps it from the admin's
        modality choice), so this is the same shape as the one existing
        modality gate (`text_service.start`'s `timed` check), just caught at
        the plan level with a phase-specific message instead of a generic one."""
        if not self.timed:
            offenders = [p.id for p in self.phases if p.scenario_items]
            if offenders:
                raise ValueError(
                    "Visual Scenario Analysis requires a voice/video "
                    f"interview — phase(s) {offenders} carry scenario_items "
                    "but this cadence is untimed (a text interview). Remove "
                    "the phase, or schedule this role as a voice interview."
                )
        return self

    # ── ergonomic accessors ────────────────────────────────────────────

    def phase_ids(self) -> list[str]:
        return [p.id for p in self.phases]

    def first_phase_id(self) -> str:
        return self.phases[0].id

    def terminal_phase_id(self) -> str:
        """The last phase in order — when it expires, the interview ends."""
        return self.phases[-1].id

    def get_phase(self, phase_id: str) -> PhaseDef:
        for p in self.phases:
            if p.id == phase_id:
                return p
        raise KeyError(f"phase '{phase_id}' not in this cadence")

    def next_phase_id(self, phase_id: str) -> str | None:
        """Return the id of the phase that follows `phase_id`, or None
        if `phase_id` is the terminal phase."""
        ids = self.phase_ids()
        try:
            idx = ids.index(phase_id)
        except ValueError as e:
            raise KeyError(f"phase '{phase_id}' not in this cadence") from e
        return ids[idx + 1] if idx + 1 < len(ids) else None


# ── factory / loader helpers ───────────────────────────────────────────


_DEFAULT_YAML_PATH = Path(__file__).resolve().parent / "default.yaml"
# Untimed, pool-backed default for TEXT interviews (see default_text.yaml).
# The no-JD schedule path uses this instead of default.yaml when modality="text"
# so a text interview always has an advanceable (pool-backed) starting cadence.
_DEFAULT_TEXT_YAML_PATH = Path(__file__).resolve().parent / "default_text.yaml"


def default_yaml_path_for(modality: str) -> Path:
    """The built-in default cadence file for a modality: pool-backed & untimed
    for text, the wall-clock voice default otherwise.

    ONE default per modality, shared by every flow that needs a starting plan —
    a one-off scheduled interview and a role's cadence template alike. A second
    "template" default would mean the two paths drift apart silently."""
    return _DEFAULT_TEXT_YAML_PATH if modality == "text" else _DEFAULT_YAML_PATH


def load_cadence_yaml(path: Path | str) -> CadencePlan:
    """Read a cadence YAML from disk and validate it.

    Raises whatever pydantic / yaml raises on bad input — caller is
    expected to surface a friendly message to the operator.
    """
    text = Path(path).read_text(encoding="utf-8")
    data = yaml.safe_load(text)
    return CadencePlan.model_validate(data)


def default_cadence() -> CadencePlan:
    """Return the built-in fast-testing cadence (10 seconds total).

    Used when the operator doesn't pass --cadence-path or
    --cadence-description. The default is deliberately short (in
    seconds, not minutes) so a full interview cycle plus end-of-
    interview termination can be exercised in roughly one coffee sip
    of real time.
    """
    return load_cadence_yaml(_DEFAULT_YAML_PATH)
