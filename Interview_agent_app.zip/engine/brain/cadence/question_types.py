"""Central definition of the WRITTEN-RESPONSE question types.

ONE source of truth for "what kinds of one-shot written phase can an admin
author, and what does each one need". Everything else derives from this module:

  - `schema.WrittenResponse` validates a phase's config against it,
  - `app.cadence_service.append_written_phase` builds the YAML from it,
  - `GET /api/cadence/question-types` serves `api_catalog()` to the SPA, so the
    authoring form's fields and the candidate renderer are driven by the SAME
    table (no duplicated TS list to drift),
  - the asset-upload endpoint validates uploads with `check_asset`.

Adding a question type = one entry in `QUESTION_TYPES` (+ a renderer in the UI
for any genuinely new widget kind). No new model, endpoint, or table.

Field kinds (`FieldSpec.kind`) are the UI's renderer key AND the backend's value
check: "text"/"long_text" → non-empty string, "language" → a code from
`LANGUAGES`, "asset_audio"/"asset_image" → an uploaded asset name, "string_list"
→ a non-empty list of non-empty strings (rendered as an add/remove row list).
"""
from __future__ import annotations

from dataclasses import dataclass

# ── language catalog (both language fields pick from this) ────────────────────
# BCP-47-ish codes; the label is what the admin/candidate sees. Deliberately a
# curated list rather than free text so a typo can't silently ship.
LANGUAGES: tuple[tuple[str, str], ...] = (
    ("en", "English"),
    ("es", "Spanish"),
    ("fr", "French"),
    ("de", "German"),
    ("it", "Italian"),
    ("pt", "Portuguese"),
    ("pt-BR", "Portuguese (Brazil)"),
    ("nl", "Dutch"),
    ("sv", "Swedish"),
    ("no", "Norwegian"),
    ("da", "Danish"),
    ("fi", "Finnish"),
    ("pl", "Polish"),
    ("cs", "Czech"),
    ("ro", "Romanian"),
    ("el", "Greek"),
    ("ru", "Russian"),
    ("uk", "Ukrainian"),
    ("tr", "Turkish"),
    ("ar", "Arabic"),
    ("he", "Hebrew"),
    ("fa", "Persian"),
    ("hi", "Hindi"),
    ("bn", "Bengali"),
    ("ta", "Tamil"),
    ("te", "Telugu"),
    ("mr", "Marathi"),
    ("gu", "Gujarati"),
    ("pa", "Punjabi"),
    ("ur", "Urdu"),
    ("id", "Indonesian"),
    ("ms", "Malay"),
    ("th", "Thai"),
    ("vi", "Vietnamese"),
    ("tl", "Filipino"),
    ("zh-Hans", "Chinese (Simplified)"),
    ("zh-Hant", "Chinese (Traditional)"),
    ("ja", "Japanese"),
    ("ko", "Korean"),
    ("sw", "Swahili"),
)

_LANG_BY_CODE: dict[str, str] = {code: label for code, label in LANGUAGES}


def is_language(code: str) -> bool:
    return code in _LANG_BY_CODE


def language_label(code: str) -> str:
    """Human label for a code, falling back to the code itself (so a legacy or
    off-list value still renders as something rather than blank)."""
    return _LANG_BY_CODE.get(code, code)


# ── uploaded assets (audio for transcription, image for image description) ────
@dataclass(frozen=True)
class AssetRule:
    kind: str                      # "audio" | "image" | "video"
    extensions: tuple[str, ...]    # lowercase, with the dot
    max_bytes: int


ASSET_RULES: dict[str, AssetRule] = {
    "audio": AssetRule(
        kind="audio",
        extensions=(".mp3", ".wav", ".m4a", ".ogg", ".oga", ".webm", ".flac"),
        max_bytes=25 * 1024 * 1024,
    ),
    "image": AssetRule(
        kind="image",
        extensions=(".png", ".jpg", ".jpeg", ".webp", ".gif"),
        max_bytes=10 * 1024 * 1024,
    ),
    # Added for Visual Scenario Analysis items (engine/brain/cadence/schema.py
    # ScenarioMedia) — a short clip (seconds to ~a minute), so 100 MB is
    # generous headroom without inviting a multi-hour upload. Deliberately
    # excludes .webm even though it's a valid video container: the extension
    # alone doesn't say audio-only vs video (the audio rule above already
    # claims .webm for its own clips, and the served media type is looked up
    # by extension alone — see app.main._ASSET_MEDIA_TYPES), so a genuine
    # .webm video should be re-muxed to .mp4 before upload.
    "video": AssetRule(
        kind="video",
        extensions=(".mp4", ".mov", ".m4v"),
        max_bytes=100 * 1024 * 1024,
    ),
}


def check_asset(kind: str, filename: str, size_bytes: int) -> str | None:
    """Validate an upload against its kind's rule. Returns an admin-facing error
    message, or None when the file is acceptable. Used by the upload endpoint —
    the same rules the SPA pre-checks with (served via api_catalog)."""
    rule = ASSET_RULES.get(kind)
    if rule is None:
        return f"unknown asset kind '{kind}'"
    name = (filename or "").strip().lower()
    if not name:
        return "the file has no name"
    if not any(name.endswith(ext) for ext in rule.extensions):
        return f"{kind} must be one of: {', '.join(rule.extensions)}"
    if size_bytes <= 0:
        return "the file is empty"
    if size_bytes > rule.max_bytes:
        return f"{kind} must be at most {rule.max_bytes // (1024 * 1024)} MB"
    return None


# ── the question-type table ──────────────────────────────────────────────────
@dataclass(frozen=True)
class FieldSpec:
    """One type-specific config field. `kind` is both the UI renderer key and
    the backend's value check (see the module docstring).

    `scope` says WHERE the field is authored and stored:
      - "phase":    once for the whole phase (the language pair) — lives on
                    PhaseDef.written_response.
      - "question": per question (the material) — lives on that pool item's own
                    `written_response` block, so one phase can hold N clips /
                    passages / images.
    A phase-level value still acts as the DEFAULT for every question that
    doesn't set its own — that's what keeps a legacy single-question essay
    phase (all config at phase level) valid and unchanged.
    """

    name: str
    kind: str
    label: str
    required: bool = True
    help: str = ""
    scope: str = "question"
    # UI-only requiredness: the authoring form treats the field as required
    # (blocks Save) WITHOUT the backend schema hard-enforcing it. Use this for a
    # field introduced after questions already existed of this type — `required`
    # would retroactively invalidate every one of them on the next cadence
    # revalidation (revise/approve/eval-plan-validate all reload + re-validate).
    # Effective UI requiredness is `required or ui_required`.
    ui_required: bool = False


@dataclass(frozen=True)
class QuestionTypeSpec:
    id: str
    label: str
    description: str
    # What the free-text prompt (the phase's single pool question) is called for
    # this type, and whether the admin MUST write it. When it's optional and left
    # blank we synthesize one from the config (`default_prompt`) — the schema
    # always needs exactly one pool question, and a transcription/translation
    # task's instruction is fully implied by its languages.
    prompt_label: str
    prompt_required: bool
    prompt_placeholder: str
    # The phase's default snake_case id (uniquified by the caller) and `intent`
    # (the one-line goal embedded in the interviewer's system prompt).
    slug: str
    intent: str
    # True → the admin never writes this type's instruction at all: it is always
    # synthesised from the question's own config (see default_prompt), so the
    # authoring form hides the field. Used where the instruction is fully implied
    # by the task — a translation's is exactly "translate this, X into Y", and
    # letting it be hand-written only invites it to drift from the language pair
    # the candidate is actually graded against.
    prompt_hidden: bool = False
    # ── what the INTERVIEWER LLM is told when it opens a question of this type ──
    # The material the candidate works from is rendered on their screen by the
    # client, straight from the phase config — it deliberately never passes
    # through the LLM (so a translation's source passage reaches them exactly as
    # authored). The model therefore has to be told the material exists, that it
    # does NOT have it, and that it must not do the task itself. Without that it
    # invents a plausible passage and reads it out, which silently replaces the
    # authored task.
    #   material_label: what the candidate sees separately ("" = nothing extra;
    #                   the instruction alone IS the task).
    #   self_answer_ban: the type-specific "don't do the candidate's work".
    material_label: str = ""
    self_answer_ban: str = "do not write any part of the answer for them"
    fields: tuple[FieldSpec, ...] = ()


# Authored PER QUESTION, not once for the phase: a translation/transcription
# phase routinely mixes pairs (en→es for one passage, en→fr for the next), and
# a single phase-level pair forced the admin to create a separate phase per
# pair. A phase-level value still validates and acts as the DEFAULT for any
# question that doesn't carry its own, so cadences authored before this keep
# working untouched.
_LANG_SOURCE = FieldSpec(
    name="source_language", kind="language", label="Source language",
    help="The language of the material the candidate works from.",
    scope="question",
)
_LANG_TARGET = FieldSpec(
    name="target_language", kind="language", label="Target language",
    help="The language the candidate must write in.",
    scope="question",
)

QUESTION_TYPES: tuple[QuestionTypeSpec, ...] = (
    QuestionTypeSpec(
        id="comprehensive",
        label="Comprehensive",
        description="A written answer to a question or set of instructions.",
        prompt_label="Question / instructions",
        prompt_required=True,
        prompt_placeholder="Describe what the candidate should write about…",
        slug="written_response",
        intent="Written response — assess written communication, structure, and depth.",
    ),
    QuestionTypeSpec(
        id="transcription",
        label="Transcription",
        description="The candidate listens to an audio clip and transcribes it.",
        prompt_label="Instructions (optional)",
        prompt_required=False,
        prompt_placeholder="",
        prompt_hidden=True,
        slug="transcription",
        intent="Transcription — assess listening accuracy, spelling, and fidelity to the audio.",
        material_label="an audio clip they can play and replay",
        self_answer_ban="do not transcribe, translate or summarise the audio yourself",
        fields=(
            FieldSpec(
                name="audio_asset", kind="asset_audio", label="Audio file",
                help="The clip the candidate transcribes.",
            ),
            _LANG_SOURCE,
            _LANG_TARGET,
            FieldSpec(
                name="ground_truth", kind="long_text",
                label="Ground Truth (exact transcript)",
                help="The exact reference transcript, for future automated scoring. "
                     "Never shown to the candidate.",
                required=False, ui_required=True,
            ),
        ),
    ),
    QuestionTypeSpec(
        id="translation",
        label="Translation",
        description="The candidate translates a supplied passage.",
        prompt_label="Instructions (optional)",
        prompt_required=False,
        prompt_placeholder="",
        prompt_hidden=True,
        slug="translation",
        intent="Translation — assess accuracy, fluency, and register in the target language.",
        material_label="the source passage, shown to them verbatim",
        self_answer_ban="do not translate the passage yourself, not even a word of it",
        fields=(
            FieldSpec(
                name="source_text", kind="long_text", label="Source text",
                help="Shown to the candidate verbatim — this is what they translate.",
            ),
            _LANG_SOURCE,
            _LANG_TARGET,
            FieldSpec(
                name="ground_truth", kind="string_list",
                label="Accepted Translations",
                help="One or more accepted reference translations, for future "
                     "automated scoring. Never shown to the candidate.",
                required=False, ui_required=True,
            ),
        ),
    ),
    QuestionTypeSpec(
        id="image_description",
        label="Image Description",
        description="The candidate writes a description of a supplied image.",
        prompt_label="Instructions (optional)",
        prompt_required=False,
        prompt_placeholder="",
        prompt_hidden=True,
        slug="image_description",
        intent="Image description — assess observation, clarity, and descriptive detail.",
        material_label="the image",
        self_answer_ban="do not describe the image yourself or name anything in it",
        fields=(
            FieldSpec(
                name="image_asset", kind="asset_image", label="Image file",
                help="The image the candidate describes.",
            ),
            FieldSpec(
                name="ground_truth", kind="string_list",
                label="Key Elements / Facts",
                help="One or more key elements/facts a complete description should "
                     "cover, for future automated scoring. Never shown to the candidate.",
                required=False, ui_required=True,
            ),
        ),
    ),
)

_BY_ID: dict[str, QuestionTypeSpec] = {t.id: t for t in QUESTION_TYPES}

QUESTION_TYPE_IDS: tuple[str, ...] = tuple(t.id for t in QUESTION_TYPES)

# The DEFAULT type. Legacy essay phases (a written_response block with no
# question_type) read as this, which is exactly what they are.
DEFAULT_QUESTION_TYPE = "comprehensive"

# Every type-specific field name across all types — the schema uses this to
# reject a field that doesn't belong to the phase's own type (so a translation's
# source_text can't be silently carried on a transcription phase).
ALL_TYPE_FIELDS: tuple[str, ...] = tuple(
    dict.fromkeys(f.name for t in QUESTION_TYPES for f in t.fields)
)

# field kind → the asset kind it uploads (used by the schema + the UI).
ASSET_FIELD_KINDS: dict[str, str] = {"asset_audio": "audio", "asset_image": "image"}


def phase_fields(question_type: str) -> tuple[FieldSpec, ...]:
    """The type's fields authored ONCE for the phase (the language pair)."""
    return tuple(f for f in spec_for(question_type).fields if f.scope == "phase")


def question_fields(question_type: str) -> tuple[FieldSpec, ...]:
    """The type's fields authored PER QUESTION (the material)."""
    return tuple(f for f in spec_for(question_type).fields if f.scope == "question")


def spec_for(question_type: str) -> QuestionTypeSpec:
    spec = _BY_ID.get(question_type)
    if spec is None:
        raise ValueError(
            f"unknown question_type '{question_type}' "
            f"(expected one of: {', '.join(QUESTION_TYPE_IDS)})"
        )
    return spec


def default_prompt(question_type: str, source_language: str = "", target_language: str = "") -> str:
    """The instruction to use when the admin left an optional prompt blank. Built
    from the config, never from an LLM, so the candidate always sees a concrete
    task."""
    src = language_label(source_language) if source_language else "the source language"
    tgt = language_label(target_language) if target_language else "the target language"
    if question_type == "transcription":
        return (
            f"Listen to the audio clip and transcribe it. The audio is in {src}; "
            f"write your transcription in {tgt}."
        )
    if question_type == "translation":
        return f"Translate the text below from {src} into {tgt}."
    if question_type == "image_description":
        return "Describe this image in as much detail as possible."
    return ""


def api_catalog() -> dict:
    """The whole table as plain JSON for the SPA: question types (with their
    fields, in render order), the language catalog, and the asset rules. The
    authoring form renders from this, so a new type needs no TS list edit."""
    return {
        "default_question_type": DEFAULT_QUESTION_TYPE,
        "question_types": [
            {
                "id": t.id,
                "label": t.label,
                "description": t.description,
                "prompt_label": t.prompt_label,
                "prompt_required": t.prompt_required,
                "prompt_placeholder": t.prompt_placeholder,
                # True → the form renders no instruction box; the backend
                # synthesises it from the question's language pair.
                "prompt_hidden": t.prompt_hidden,
                # The default phase id this type gets when the admin's typed
                # name doesn't produce a usable one (blank / starts with a
                # digit) — exposed so the Add-Phase form can preview, BEFORE
                # saving, whether it's about to land on a phase that already
                # exists (see cadence_service._phase_slug, the same rule).
                "slug": t.slug,
                "fields": [
                    {
                        "name": f.name,
                        "kind": f.kind,
                        "label": f.label,
                        "required": f.required,
                        "ui_required": f.ui_required,
                        "help": f.help,
                        # "phase" → authored once (shared by every question);
                        # "question" → authored per question.
                        "scope": f.scope,
                        # Present only for upload fields, so the form knows which
                        # asset kind (and therefore which rule) to enforce.
                        **({"asset_kind": ASSET_FIELD_KINDS[f.kind]}
                           if f.kind in ASSET_FIELD_KINDS else {}),
                    }
                    for f in t.fields
                ],
            }
            for t in QUESTION_TYPES
        ],
        "languages": [{"code": c, "label": lbl} for c, lbl in LANGUAGES],
        "asset_rules": {
            k: {"extensions": list(r.extensions), "max_bytes": r.max_bytes}
            for k, r in ASSET_RULES.items()
        },
    }
