"""Operator-confirmation step.

Runs after the loader has produced a validated `CadencePlan`, before the
interview machinery starts. Prints the plan in a readable summary,
prompts y/n on stdin, exits cleanly if the operator rejects.

Why a separate step (rather than just trusting the loader): when the
plan comes from a free-form description through an LLM, the schema
validation guarantees STRUCTURAL correctness but not SEMANTIC fidelity.
The operator might want to catch "the LLM split 30 minutes into 6/8/14/2
when I wanted 5/10/12/3" or "the technical pool has only beginner
questions". A 3-second sanity-check by a human prevents 30 minutes of
wrong interview.

For the YAML-direct mode and the default-cadence mode, the operator
still gets to confirm — same protection against typos / wrong file.
"""
from __future__ import annotations

import sys
from textwrap import indent

from engine.brain.cadence.schema import CadencePlan


def _fmt_duration(s: int) -> str:
    """Human-friendly duration. 75 → "1m15s"; 300 → "5m"; 7 → "7s"."""
    if s < 60:
        return f"{s}s"
    m, sec = divmod(s, 60)
    return f"{m}m" if sec == 0 else f"{m}m{sec}s"


def render_summary(plan: CadencePlan) -> str:
    """Pretty-print the cadence as a human-readable block. Returned as a
    single string so callers can log it as well as print it."""
    lines: list[str] = []
    total = _fmt_duration(plan.total_duration_s)
    lines.append(f"Interview cadence: {total} total, {len(plan.phases)} phases")
    lines.append("─" * 60)
    for i, p in enumerate(plan.phases, 1):
        dur = _fmt_duration(p.duration_s)
        lines.append(f"  {i}. {p.id}  ({dur})  [{p.question_mode}]")
        lines.append(indent(f"intent: {p.intent}", "       "))
        if not p.uses_question_pool:
            for prompt in p.generic_prompts:
                lines.append(indent(f"• {prompt}", "       "))
        else:
            for q in p.question_pool:
                topic_part = f" [{q.topic}]" if q.topic else ""
                lines.append(indent(f"• {q.text}{topic_part}", "       "))
                if q.coverage_tags:
                    lines.append(indent(
                        f"↳ must cover: {', '.join(q.coverage_tags)}",
                        "         "))
                else:
                    for fu in q.follow_ups:
                        lines.append(indent(f"↳ {fu}", "         "))
        lines.append("")
    return "\n".join(lines).rstrip()


def confirm_cadence(
    plan: CadencePlan,
    *,
    interactive: bool = True,
    out=None,
    in_=None,
) -> bool:
    """Display the plan and ask the operator to confirm.

    `interactive=False` skips the prompt and returns True — useful for
    CI / scripted tests. In interactive mode (default), reads y/N from
    stdin; anything other than 'y' / 'yes' / '' rejects.

    `out` / `in_` are injectable for tests; default to sys.stderr / sys.stdin.
    """
    out = out or sys.stderr
    in_ = in_ or sys.stdin

    print("", file=out)
    print(render_summary(plan), file=out)
    print("", file=out)

    if not interactive:
        print("[cadence] interactive=False → accepting without prompt.", file=out)
        return True

    print("Start the interview with this cadence? [Y/n] ", end="", file=out, flush=True)
    try:
        answer = (in_.readline() or "").strip().lower()
    except (KeyboardInterrupt, EOFError):
        print("\n[cadence] aborted by user.", file=out)
        return False

    # Default = yes (empty input means "press enter to accept" — the common path).
    if answer in ("", "y", "yes"):
        print("[cadence] ✓ confirmed; starting interview.", file=out)
        return True
    print("[cadence] ✗ rejected; exiting.", file=out)
    return False
