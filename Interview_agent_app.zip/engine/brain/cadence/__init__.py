"""Cadence subsystem.

A "cadence plan" defines the timeline of an interview — what phases there
are, how long each runs, and (per phase) either the open-ended prompts
the AI should follow OR a concrete pool of questions to draw from.

Public surface:
  CadencePlan, PhaseDef, QuestionPoolItem  — the canonical data shape
  load_cadence_yaml(path) → CadencePlan    — parse + validate from YAML
  default_cadence() → CadencePlan          — built-in 10s testing cadence

Used by:
  CadenceTracker  — runtime owner of phase + time + question state
  CadenceLoader   — converts user-provided text/PDF into the canonical YAML
  CadenceConfirmer — prints the plan + asks operator to confirm
"""
from engine.brain.cadence.confirmer import confirm_cadence, render_summary
from engine.brain.cadence.loader import load_cadence
from engine.brain.cadence.schema import (
    CadencePlan,
    PhaseDef,
    QuestionPoolItem,
    default_cadence,
    load_cadence_yaml,
)

__all__ = [
    "CadencePlan",
    "PhaseDef",
    "QuestionPoolItem",
    "default_cadence",
    "load_cadence_yaml",
    "load_cadence",
    "confirm_cadence",
    "render_summary",
]
