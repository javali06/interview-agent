"""Three-mode cadence loader.

Modes (mutually exclusive):
  1. No CLI flag                       → use the built-in default cadence.
  2. --cadence-path foo.yaml           → direct YAML load + schema validate.
  3. --cadence-description foo.{txt,pdf,md,docx,…}
                                       → extract plain text via `attachments`,
                                          feed to the slow LLM with a strict
                                          prompt, parse the YAML output,
                                          schema-validate, retry once on
                                          validation failure with the error
                                          fed back to the LLM.

The format check is pydantic validation in `CadencePlan.model_validate`.
The schema itself (`schema.py`) enforces:
  - phase IDs unique, snake_case
  - duration sum == total
  - question_mode matches data (generic ↔ prompts, specific ↔ pool)
  - question pool IDs unique within a phase

If a description doesn't survive two LLM attempts, we raise a clear error
so the operator can fix the source text rather than guessing at LLM-emitted
malformed YAML.
"""
from __future__ import annotations

import logging
import os
import re
from pathlib import Path

import yaml
from openai import AsyncOpenAI
from pydantic import ValidationError

from engine.brain.cadence.schema import (
    CadencePlan,
    default_cadence,
    load_cadence_yaml,
)

from engine.brain.prompts import load as load_prompt

logger = logging.getLogger(__name__)


# ── public entrypoint ──────────────────────────────────────────────────


async def load_cadence(
    *,
    cadence_path: Path | None = None,
    cadence_description_path: Path | None = None,
    role: str = "AI Engineer",
    candidate_name: str = "",
    api_key: str = "",
    base_url: str = "https://api.groq.com/openai/v1",
    model: str = "openai/gpt-oss-120b",
    token: str | None = None,
) -> CadencePlan:
    """Resolve and validate a cadence plan.

    Exactly one of `cadence_path`, `cadence_description_path`, or neither may
    be provided. Returns a fully-validated `CadencePlan`. Raises `ValueError`
    on contradictory inputs or on description-mode LLM conversion failure.

    `token` (the schedule token) is optional — passed through to the LLM
    conversion path ONLY so its cost/Langfuse trace can be attributed to the
    right interview's "cost for setting up interview" table. It has no
    bearing on cadence resolution itself.
    """
    if cadence_path is not None and cadence_description_path is not None:
        raise ValueError(
            "Pass at most one of cadence_path / cadence_description_path"
        )
    if cadence_path is not None:
        cadence_path = Path(cadence_path)
        logger.info("[cadence] loading YAML from %s", cadence_path)
        return load_cadence_yaml(cadence_path)
    if cadence_description_path is not None:
        cadence_description_path = Path(cadence_description_path)
        if not api_key:
            raise ValueError(
                "cadence_description_path requires an LLM API key — pass "
                "api_key= (typically your Groq key)"
            )
        logger.info(
            "[cadence] converting description %s to YAML via LLM",
            cadence_description_path,
        )
        return await _load_from_description(
            cadence_description_path,
            role=role, candidate_name=candidate_name,
            api_key=api_key, base_url=base_url, model=model, token=token,
        )
    logger.info("[cadence] using built-in default (10s testing cadence)")
    return default_cadence()


# ── description-mode internals ─────────────────────────────────────────


_FENCE_RE = re.compile(r"```(?:ya?ml)?\s*(.*?)```", re.DOTALL)


def _strip_markdown_fences(text: str) -> str:
    """LLMs love wrapping output in ```yaml ... ```. Strip the wrapper if
    present so `yaml.safe_load` doesn't choke. If no fence is present,
    return the text untouched."""
    m = _FENCE_RE.search(text)
    return m.group(1).strip() if m else text.strip()


def _extract_text_from_file(path: Path) -> str:
    """Pull plain text out of a description file using the `attachments`
    library (same one used for resumes). Handles txt/md/pdf/docx/etc."""
    if not path.exists():
        raise ValueError(f"cadence-description file not found: {path}")
    if not path.is_file():
        raise ValueError(f"cadence-description path is not a file: {path}")
    try:
        import attachments  # noqa: F401
    except ImportError as e:
        raise RuntimeError(
            "The `attachments` package is required to parse cadence "
            "descriptions from PDF/DOCX. Install with: pip install attachments"
        ) from e

    # FD-level silencing — `attachments` writes verbose progress to stdout.
    from attachments import Attachments  # noqa: WPS433
    devnull_fd = os.open(os.devnull, os.O_WRONLY)
    saved_out, saved_err = os.dup(1), os.dup(2)
    try:
        os.dup2(devnull_fd, 1)
        os.dup2(devnull_fd, 2)
        ctx = Attachments(str(path))
        rendered = str(ctx)
    finally:
        os.dup2(saved_out, 1)
        os.dup2(saved_err, 2)
        os.close(saved_out)
        os.close(saved_err)
        os.close(devnull_fd)

    # Same fence-strip as the LLM output path — `attachments` wraps
    # content in markdown source-label fences.
    body = _strip_markdown_fences(rendered)
    if not body:
        raise ValueError(f"description {path} parsed to empty text")
    return body




def _user_prompt(text: str, role: str, candidate_name: str, retry_error: str | None) -> str:
    parts = [
        f"Role being interviewed for: {role!r}",
    ]
    if candidate_name:
        parts.append(f"Candidate: {candidate_name!r}")
    parts.append("\nDescription to convert:\n")
    parts.append(text)
    if retry_error:
        parts.append(
            "\n\nYour previous attempt failed schema validation with:\n"
            f"  {retry_error}\n"
            "Fix that issue and emit corrected YAML. Output ONLY the YAML."
        )
    else:
        parts.append("\n\nOutput the YAML now.")
    return "\n".join(parts)


async def _load_from_description(
    path: Path,
    *,
    role: str,
    candidate_name: str,
    api_key: str,
    base_url: str,
    model: str,
    token: str | None = None,
) -> CadencePlan:
    """Two-attempt LLM conversion: emit YAML, validate, retry once with the
    validation error fed back as feedback. Raises ValueError if the second
    attempt also fails."""
    from app.setup_cost_tracker import trace_call

    description_text = _extract_text_from_file(path)
    logger.info(
        "[cadence] description extracted from %s (%d chars) — calling %s",
        path, len(description_text), model,
    )

    client = AsyncOpenAI(api_key=api_key, base_url=base_url)
    last_error: str | None = None
    last_raw_yaml: str = ""

    # OpenRouter tuning for this one-shot batch call: cap reasoning effort
    # (gpt-oss-style models burn latency on hidden chain-of-thought; this
    # is structured extraction) and route by THROUGHPUT — default routing
    # has landed on slow providers for gpt-oss-120b, while Groq/Cerebras
    # serve it at very high tok/s. Both ignored off-OpenRouter.
    extra_body = (
        {"reasoning": {"effort": "low"}, "provider": {"sort": "throughput"}}
        if "openrouter" in (base_url or "") else {}
    )

    for attempt in (1, 2):
        messages = [
            {"role": "system", "content": load_prompt("cadence_converter")},
            {"role": "user", "content": _user_prompt(
                description_text, role, candidate_name, last_error,
            )},
        ]
        try:
            with trace_call(
                token=token, purpose="generate_cadence", model=model, input_data=messages,
            ) as finish:
                resp = await client.chat.completions.create(
                    model=model, messages=messages, temperature=0.1, extra_body=extra_body,
                )
                finish(resp)
        except Exception as e:
            raise RuntimeError(
                f"LLM call failed while converting cadence description: {e}"
            ) from e

        raw = (resp.choices[0].message.content or "").strip()
        last_raw_yaml = raw
        yaml_text = _strip_markdown_fences(raw)
        try:
            data = yaml.safe_load(yaml_text)
        except yaml.YAMLError as e:
            last_error = f"YAML parse error: {e}"
            logger.warning("[cadence] attempt %d: YAML parse failed: %s", attempt, e)
            continue
        try:
            plan = CadencePlan.model_validate(data)
        except ValidationError as e:
            last_error = str(e)
            logger.warning(
                "[cadence] attempt %d: schema validation failed:\n%s",
                attempt, e,
            )
            continue

        logger.info(
            "[cadence] LLM-converted plan validated on attempt %d "
            "(%ds total, %d phases)",
            attempt, plan.total_duration_s, len(plan.phases),
        )
        return plan

    raise ValueError(
        f"Failed to convert cadence description after 2 attempts. "
        f"Last error:\n{last_error}\n\n"
        f"Last LLM output:\n{last_raw_yaml[:500]}{'...' if len(last_raw_yaml) > 500 else ''}"
    )
