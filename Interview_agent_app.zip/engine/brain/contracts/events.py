"""EventKind enum + Event Pydantic model.

Every state-changing thing emits an Event. Append-only. Source of truth for
post-hoc analysis. Tag rendering (NEW_STREAM_B.md §10.3) happens at write time
so tags appear inline in `Turn.text` rather than in event payloads.
"""
from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field


class EventKind(str, Enum):
    # ── lifecycle ─────────────────────────────────────────
    SESSION_STARTED = "session_started"
    SESSION_ENDED = "session_ended"
    # Emitted by a FRESH runner that is resuming a crashed interview from a
    # durable checkpoint (feature B). Marks the interruption boundary so the
    # trace/eval readers can REPLACE the interrupted phase's pre-crash partial
    # with the resumed run (see app/resume_collapse.py). Carries phase_id +
    # resume_count. Distinct from SESSION_STARTED so a resume never looks like
    # a fresh interview starting from the greeting phase.
    SESSION_RESUMED = "session_resumed"

    # Durable-checkpoint observability (feature B). CHECKPOINT_WRITTEN is emitted
    # by the live runner at each phase boundary (carries phase_id + ok). The WS
    # teardown emits exactly ONE of CHECKPOINT_CLEARED (clean end → checkpoint
    # dropped) or CHECKPOINT_KEPT (crash/cancel → checkpoint preserved for
    # resume). Together they make "did resume fire, and why/why not" readable
    # straight from events.jsonl (which is on the shared sessions volume, so all
    # three land in the same per-token log across a shard restart).
    CHECKPOINT_WRITTEN = "checkpoint_written"
    CHECKPOINT_CLEARED = "checkpoint_cleared"
    CHECKPOINT_KEPT = "checkpoint_kept"

    # ── audio in (from Stream A clients) ──────────────────
    STT_PARTIAL = "stt_partial"
    STT_FINAL = "stt_final"
    VAD_SPEECH_START = "vad_speech_start"
    VAD_SPEECH_END = "vad_speech_end"
    VAD_ENDPOINT = "vad_endpoint"

    # ── audio out (TTS lifecycle — first-class, NOT out-of-band like v1) ──
    TTS_SPEAK_CHUNK_SENT = "tts_speak_chunk_sent"
    TTS_AUDIO_START = "tts_audio_start"
    TTS_AUDIO_END = "tts_audio_end"
    TTS_CANCELLED = "tts_cancelled"

    # ── director / policy ────────────────────────────────
    DIRECTOR_TICK = "director_tick"
    POLICY_DECISION = "policy_decision"
    PHASE_CHANGED = "phase_changed"

    # ── latency orchestrator ─────────────────────────────
    LATENCY_STATE_CHANGED = "latency_state_changed"
    FILLER_DISPATCHED = "filler_dispatched"
    FILLER_SPOKEN = "filler_spoken"
    APOLOGY_DISPATCHED = "apology_dispatched"

    # ── LLM observability ────────────────────────────────
    LLM_CALL_STARTED = "llm_call_started"
    LLM_CALL_FIRST_TOKEN = "llm_call_first_token"
    LLM_CALL_COMPLETED = "llm_call_completed"
    LLM_CALL_FAILED = "llm_call_failed"
    LLM_PROVIDER_FAILOVER = "llm_provider_failover"

    # ── tools / sub-agents ───────────────────────────────
    TOOL_CALL_VALIDATED = "tool_call_validated"
    TOOL_CALL_EXECUTED = "tool_call_executed"
    TOOL_CALL_VALIDATION_RETRY = "tool_call_validation_retry"
    SUB_AGENT_INVOKED = "sub_agent_invoked"
    SUB_AGENT_COMPLETED = "sub_agent_completed"

    # ── turn outcome ─────────────────────────────────────
    AI_UTTERANCE = "ai_utterance"
    AI_RESPONSE_BARGED_IN = "ai_response_barged_in"
    SCORE_UPDATED = "score_updated"
    INTEGRITY_FLAGGED = "integrity_flagged"
    SUMMARY_COMPRESSED = "summary_compressed"
    # Verifier flagged the candidate's last reply as an integrity/security
    # guardrail trip (jailbreak / rubric_probe / answer_extraction). Distinct
    # from `verifier_classified` so the admin trace can highlight + count it.
    GUARDRAIL_TRIGGERED = "guardrail_triggered"

    # ── §8 engineering plumbing edge-case events ─────────
    FALSE_ENDPOINT_DROPPED = "false_endpoint_dropped"            # §8B.1
    BARGE_IN_STRIKE_INCREMENT = "barge_in_strike_increment"      # §8B.4
    PROTECTED_RESPONSE_MODE_ENTERED = "protected_response_mode_entered"
    PROTECTED_RESPONSE_MODE_EXITED = "protected_response_mode_exited"
    COST_CEILING_SOFT_CROSSED = "cost_ceiling_soft_crossed"      # §8B.5
    COST_CEILING_HARD_CROSSED = "cost_ceiling_hard_crossed"
    TTS_RECONNECT_ATTEMPTED = "tts_reconnect_attempted"          # §8C.2
    TTS_RECONNECT_SUCCEEDED = "tts_reconnect_succeeded"
    TTS_RECONNECT_FAILED = "tts_reconnect_failed"
    TTS_BUFFER_OVERFLOW = "tts_buffer_overflow"                   # §8C.3
    AUDIO_END_GRACE_BLOCKED_BARGE_IN = "audio_end_grace_blocked_barge_in"
    CATASTROPHIC_OUTPUT_DROPPED = "catastrophic_output_dropped"   # §8D.2
    MIC_SILENCE_DETECTED = "mic_silence_detected"                 # §8C.4
    MIC_SILENCE_RECOVERED = "mic_silence_recovered"
    MONOLOGUE_SOFT_ENDPOINT_FIRED = "monologue_soft_endpoint_fired"
    BACKCHANNEL_PLAYED = "backchannel_played"
    NOISE_ONLY_FINAL = "noise_only_final"                         # §8D.5
    SERVICE_RECONNECT = "service_reconnect"


class Event(BaseModel):
    session_id: UUID
    ts: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    kind: EventKind | str
    payload: dict[str, Any] = Field(default_factory=dict)

    def to_jsonable(self) -> dict[str, Any]:
        return {
            "session_id": str(self.session_id),
            "ts": self.ts.isoformat(),
            "kind": self.kind.value if isinstance(self.kind, EventKind) else str(self.kind),
            "payload": self.payload,
        }
