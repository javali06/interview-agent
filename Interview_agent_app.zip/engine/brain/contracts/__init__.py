"""Shared contracts: types, enums, schemas, wire formats."""
