"""SessionState — the in-memory source of truth for an active interview.

NEW_STREAM_B.md §10.2. This consolidates everything v1 hacked around with
private attributes (`_ai_active`, `_last_any_speech_ms`, etc.) into public,
typed fields.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Literal
from uuid import UUID, uuid4


# ── enums ────────────────────────────────────────────────────
#
# Phases are NO LONGER an enum — they're plain strings sourced from the
# user's cadence plan (see stream_b_new.cadence). The cadence defines the
# phase IDs (e.g. "warm_up", "technical_questions") and the CadenceTracker
# owns transition logic. SessionState.phase mirrors the tracker's current
# phase as a string for consumers (event log, conversation context) that
# don't need the tracker's full API.


class Speaker(str, Enum):
    CANDIDATE = "candidate"
    AI = "ai"
    # A human TA's push-to-talk turn. The observer feature is retired — no new
    # interview produces one — but past interviews' turns and events carry it,
    # so it must stay parseable.
    INTERVIEWER = "interviewer"
    UNKNOWN = "unknown"


class AIActivityState(str, Enum):
    """Lifecycle of an AI turn — used by BargeInGuard and Director."""

    IDLE = "idle"
    LLM_GENERATING = "llm_generating"   # slow LLM streaming, no audio yet
    TTS_QUEUED = "tts_queued"           # text sent to TTS, audio_start pending
    AUDIO_PLAYING = "audio_playing"     # audio is on speakers RIGHT NOW
    AUDIO_DONE = "audio_done"           # within 2s grace after final audio_end
    # AI is in a coding phase — waiting for the candidate to write + submit
    # code in the editor. Silence-prompt / filler / apology agents must be
    # gated when in this state; the candidate is typing, not silent.
    # See coding/ module for the feature.
    CODING = "coding"


class VadState(str, Enum):
    """Candidate's VAD-driven state — the PRIMARY signal for turn-taking.

    State machine:
        IDLE → (speech_start) → SPEAKING
        SPEAKING → (speech_end) → PAUSED       [brief silence inside utterance]
        PAUSED → (speech_start) → SPEAKING     [resumed mid-utterance]
        PAUSED → (endpoint_detected) → DONE    [tail_ms of silence — really done]
        SPEAKING → (endpoint_detected) → DONE  [endpoint fires without explicit speech_end]
        DONE → (speech_start) → SPEAKING       [next utterance]

    Semantics for the rest of the system:
        SPEAKING / PAUSED  → candidate_speaking == True; policy returns NO;
                              barge-in cancels any AI turn on entry to SPEAKING.
        DONE                → endpoint just fired; policy may dispatch YES.
        IDLE                → no speech ever; only the greeting can fire.
    """

    IDLE = "idle"
    SPEAKING = "speaking"
    PAUSED = "paused"        # brief mid-utterance silence (between speech_end and endpoint/resume)
    DONE = "done"             # endpoint fired — candidate finished an utterance


class Dimension(str, Enum):
    TECHNICAL_DEPTH = "technical_depth"
    PROBLEM_SOLVING = "problem_solving"
    COMMUNICATION = "communication"
    SYSTEM_THINKING = "system_thinking"
    CODE_QUALITY = "code_quality"


# ── value types ──────────────────────────────────────────────

@dataclass
class TurnInterruption:
    interrupted_at_word: int
    total_words: int
    candidate_text_after: str | None
    ts_ms: int


@dataclass
class Turn:
    turn_id: str
    speaker: Speaker
    text: str                          # tag-rendered, ready for prompt input
    text_full: str | None = None       # un-truncated, un-tagged original (audit)
    start_ms: int = 0
    end_ms: int = 0
    confidence: float = 1.0
    audio_played_ms: int = 0
    interruption: TurnInterruption | None = None
    # Optional explicit override for the OpenAI message role this Turn
    # should produce in `turns_to_messages`. Set this when a Turn is a
    # synthesized "meta" turn (e.g., a <think> block persisted by the
    # director so future dispatches can see it) whose role does not
    # match the Speaker-based default. None = use the Speaker mapping
    # (Speaker.AI → assistant, CANDIDATE → user, UNKNOWN/INTERVIEWER →
    # system).
    message_role: str | None = None


# ── Turn (de)serialization for the durable interview checkpoint ──────────────
# The checkpoint store (app/coordination/interview_checkpoint) keeps a tiny
# per-phase snapshot of state.turns in Redis so a fresh runner can resume the
# current phase instead of re-greeting. It deals in plain dicts; these helpers
# are the ONE place that knows Turn's shape. Only the fields that matter for
# rebuilding the LLM message list are carried — `interruption` (audit-only) is
# dropped and re-defaults to None on rehydrate.

def turn_to_jsonable(turn: "Turn") -> dict:
    """Serialize a Turn to a JSON-safe dict for the checkpoint blob."""
    return {
        "turn_id": turn.turn_id,
        "speaker": turn.speaker.value,
        "text": turn.text,
        "text_full": turn.text_full,
        "start_ms": turn.start_ms,
        "end_ms": turn.end_ms,
        "confidence": turn.confidence,
        "message_role": turn.message_role,
    }


def turn_from_jsonable(d: dict) -> "Turn":
    """Rebuild a Turn from a checkpoint dict. Tolerant of missing keys so an
    older/partial blob degrades gracefully rather than crashing bring-up."""
    return Turn(
        turn_id=d.get("turn_id", ""),
        speaker=Speaker(d.get("speaker", Speaker.UNKNOWN.value)),
        text=d.get("text", ""),
        text_full=d.get("text_full"),
        start_ms=int(d.get("start_ms", 0) or 0),
        end_ms=int(d.get("end_ms", 0) or 0),
        confidence=float(d.get("confidence", 1.0) or 1.0),
        message_role=d.get("message_role"),
    )


@dataclass
class RunningScore:
    dimension: Dimension
    score: float                        # 0-5
    confidence: float                   # 0-1
    evidence_ids: list[str] = field(default_factory=list)


@dataclass
class IntegrityFlag:
    flag_id: str
    raised_at: datetime
    kind: str
    severity: Literal["low", "medium", "high"]
    evidence: dict


@dataclass
class RecentAudioEvent:
    """One entry of `ConversationContext.recent_audio_events` (last 10s)."""

    ts_offset_s: float                  # negative; -2.1 means "2.1s ago"
    kind: Literal[
        "candidate_finished",
        "candidate_silence_started",
        "ai_filler_spoken",
        "ai_response_completed",
        "ai_response_barged_in",
        "apology_played",
        "mic_dropout",
        "mic_recovered",
    ]
    text: str | None = None
    metadata: dict = field(default_factory=dict)


# ── the session state ────────────────────────────────────────

@dataclass
class CandidateProfile:
    name: str
    role: str
    resume_summary: str = ""
    extra_notes: str = ""


@dataclass
class SessionState:
    # ── identity ────
    session_id: UUID = field(default_factory=uuid4)
    candidate_id: UUID = field(default_factory=uuid4)
    ta_id: UUID = field(default_factory=uuid4)
    candidate_profile: CandidateProfile = field(
        default_factory=lambda: CandidateProfile(name="Candidate", role="Engineer")
    )
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    # ── phase ───────
    # Phase ID as a string (no longer a Phase enum) — sourced from the
    # cadence plan and mirrored from CadenceTracker. Tracker is the
    # authority; this field is the cached value for downstream consumers.
    phase: str = "warm_up"
    phase_started_at_ms: int = 0
    pending_phase: str | None = None   # §8E.2 — atomic phase transitions

    # ── turn history ────
    turns: list[Turn] = field(default_factory=list)
    rolling_summary: str = ""

    # ── live audio state ────
    ai_activity: AIActivityState = AIActivityState.IDLE
    vad_state: VadState = VadState.IDLE  # PRIMARY signal — every VAD event mutates this
    last_speech_start_ts_ms: int = 0     # most recent VAD speech_start
    last_speech_end_ts_ms: int = 0       # most recent VAD speech_end (mid-utterance pause)
    last_endpoint_ts_ms: int = 0         # most recent VAD endpoint_detected
    last_audio_end_ts_ms: int = 0
    last_any_speech_ms: int = 0          # bumped on EVERY VAD candidate signal
    candidate_continuous_speech_ms: int = 0
    last_backchannel_ts_ms: int = 0
    last_filler_text: str | None = None
    last_apology_ts_ms: int = 0
    last_stt_confidence: float = 1.0
    consecutive_low_conf_finals: int = 0

    @property
    def candidate_speaking(self) -> bool:
        """True iff candidate is in the middle of an utterance (SPEAKING or PAUSED)."""
        return self.vad_state in (VadState.SPEAKING, VadState.PAUSED)

    # ── §8B.4 protected-response strike counter ────
    barge_in_strike_count: int = 0
    barge_in_strike_phase: str | None = None  # which phase the strikes belong to
    in_protected_response: bool = False

    # True from VAD speech_start until the AI's slow-LLM audio_start fires
    # (or dispatch / noise_only_final clears it). Used by Rule 4 to suppress
    # silence_prompt while we KNOW the candidate spoke (regardless of whether
    # STT has delivered text yet).
    candidate_spoke_since_last_ai: bool = False

    # ── §8B.5 cost meter ────
    cost_so_far_usd: float = 0.0
    cost_ceiling_soft_crossed: bool = False
    cost_ceiling_hard_crossed: bool = False

    # ── per-model LLM usage counter (for end-of-session token report) ────
    # Schema: {model_id: {"input_tokens": N, "output_tokens": N,
    #                     "calls": N, "total_latency_ms": N}}
    llm_usage: dict[str, dict[str, int]] = field(default_factory=dict)

    # ── §8C.5 calibration ────
    # Initial estimate, updated from observed turns. Measured empirically on
    # our bm_george / BrE / speed=1.0 config: 14.4-14.8 chars/sec across
    # multi-turn sessions. Kokoro publishes no cps spec — this default only
    # matters until the first non-barged turn completes, after which the
    # session state is updated to the actual observed rate. If you change
    # voice / lang_code / speed in stream_a's kokoro_client.py the default
    # may be off, but the calibration loop will correct it within one turn.
    kokoro_chars_per_second: float = 14.5

    # ── scoring + integrity ────
    rubric_scores: dict[Dimension, RunningScore] = field(default_factory=dict)
    active_flags: list[IntegrityFlag] = field(default_factory=list)
    risk_score: float = 0.0

    # ── recent audio events for ConversationContext ────
    recent_audio_events: list[RecentAudioEvent] = field(default_factory=list)

    # ── coding feature: last submission ────
    # Set by the WS submit handler when the candidate clicks Submit on a
    # coding phase. Consumed by build_context() in the immediately-following
    # phase (typically code_discussion) so the slow LLM can ground its
    # questions in the actual code the candidate wrote. Cleared / overwritten
    # on the next coding submission. None until first submit.
    # Schema: {"phase_id": str, "code": str, "function_name": str,
    #          "test_results": list[dict], "submitted_at_ms": int,
    #          "question_id": str, "question_prompt": str}
    last_coding_submission: dict | None = None
