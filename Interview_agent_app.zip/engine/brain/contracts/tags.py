"""Conversation tag vocabulary — NEW_STREAM_B.md §8A.1.

These tags are written *into* `Turn.text` at state-mutation time (not at
prompt-build time). The system prompt teaches the LLM what each tag means
so it can react naturally — e.g. "if the previous AI turn ends with
`<barged_in/>`, the candidate cut you off; read what they said and continue
from there, don't re-ask the question that got cut off".

Each tag has:
  - `format(...)`: how to render it as a string
  - `DOC`: human-readable docstring embedded into the system prompt verbatim
"""
from __future__ import annotations


# ── tag rendering helpers ─────────────────────────────────────

def tag_barged_in() -> str:
    return "<barged_in/>"


def tag_barged_in_pre_audio() -> str:
    """Like <barged_in/> but the candidate heard NONE of this turn's audio.
    The LLM generated text, the cancel reached TTS before any audio_start."""
    return "<barged_in_pre_audio/>"


def tag_filler(text: str) -> str:
    return f'<filler text="{_escape(text)}"/>'


def tag_apology(text: str) -> str:
    return f'<apology text="{_escape(text)}"/>'


def tag_silence_ms(ms: int) -> str:
    return f"<silence_ms={int(ms)}/>"


def tag_low_confidence(stt: float) -> str:
    return f"<low_confidence stt={stt:.2f}/>"


def tag_no_response_yet() -> str:
    return "<no_response_yet/>"


def tag_protected_response() -> str:
    return "<protected_response/>"


def tag_phase_changed(from_phase: str, to_phase: str, reason: str = "natural") -> str:
    return f'<phase_changed from="{from_phase}" to="{to_phase}" reason="{reason}"/>'


def _escape(s: str) -> str:
    """Minimal XML-attribute escaping. Prompt-targeted, not security-grade."""
    return (
        s.replace("&", "&amp;")
        .replace('"', "&quot;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


# ── docstrings embedded into the system prompt ───────────────

TAG_DOCS: dict[str, str] = {
    "<barged_in/>": (
        "Appears at the END of an AI turn. TTS playback was cancelled before "
        "this turn finished. Everything BEFORE the tag is what the candidate "
        "actually heard; everything after, only you thought of. The candidate "
        "may have answered the cut-off question — read what they said. Do "
        "NOT re-ask the question that got cut off as if nothing happened."
    ),
    "<barged_in_pre_audio/>": (
        "Appears at the END of an AI turn. You started generating this text "
        "but the candidate heard NONE of it — they spoke before the audio "
        "could start. The text shows what you were ABOUT to say. Don't "
        "deliver this verbatim now; consider whether the candidate's new "
        "utterance changes whether your line of thinking is still relevant."
    ),
    '<filler text="..."/>': (
        "Appears at the START of an AI turn. A short fast-LLM filler was "
        "played before this turn's substance — the candidate already heard "
        "the quoted text. Do NOT re-acknowledge it (don't open with 'Got "
        "it' / 'Sure' / 'Right' if those words appear in the filler). Start "
        "with substance."
    ),
    '<apology text="..."/>': (
        "Appears at the START of an AI turn. A canned apology was played "
        "(e.g. 'give me a second to think'). The candidate is expecting a "
        "thoughtful response — be substantive."
    ),
    "<silence_ms=N/>": (
        "Appears at the START of an AI turn. The candidate has been silent "
        "for N milliseconds. This turn is a PROMPT, not a response to "
        "anything specific. Re-engage gently — 'take your time', 'did you "
        "hear me?', or restate the last question."
    ),
    "<low_confidence stt=X/>": (
        "Wraps a candidate turn. STT confidence was low (X). The text may "
        "be partly wrong. If the meaning is unclear, ask for clarification "
        "rather than guessing."
    ),
    "<no_response_yet/>": (
        "Appears at the END of a candidate turn. The candidate self-"
        "corrected or said another thing before you could respond. Two "
        "consecutive candidate turns where the first ends with this tag "
        "means treat them as a single coherent message."
    ),
    "<protected_response/>": (
        "Wraps an AI turn. This turn was generated in protected-response "
        "mode after multiple consecutive interruptions. Acknowledge the "
        "candidate's pattern gracefully ('let me address those one at a "
        "time'), give a coherent response covering all their utterances, "
        "then explicitly cede the turn ('does that cover what you were "
        "asking?'). Keep to 2-3 sentences."
    ),
    '<phase_changed from="X" to="Y" reason="Z"/>': (
        "A phase transition just fired. Adjust your style to the new "
        "phase's prompt. If reason='budget', wrap up the previous thread "
        "tersely and pivot."
    ),
}


def render_tag_glossary() -> str:
    """Render the tag docs as a single block to embed in the system prompt."""
    lines = [
        "You will see special tags in the conversation history. They tell you",
        "what happened in the audio world that text alone cannot convey:",
        "",
    ]
    for tag, doc in TAG_DOCS.items():
        lines.append(f"  {tag}")
        for line in _wrap(doc, width=72, indent="    "):
            lines.append(line)
        lines.append("")
    return "\n".join(lines).rstrip()


def _wrap(text: str, *, width: int, indent: str) -> list[str]:
    words = text.split()
    out: list[str] = []
    cur = indent
    for w in words:
        if len(cur) + 1 + len(w) > width and cur != indent:
            out.append(cur)
            cur = indent + w
        else:
            cur = (cur + " " + w) if cur != indent else cur + w
    if cur.strip():
        out.append(cur)
    return out
