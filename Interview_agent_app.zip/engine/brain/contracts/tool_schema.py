"""LLM tool schemas — the LLM's only way to act on session state.

NEW_STREAM_B.md §6.3. We split SSOT's single `respond` tool into 5 tools so
each side-effect is independently testable and traceable. The `respond` tool
is the hot-path 90% of the time; the others are background actions.

Each tool has:
  - JSON schema (the OpenAI / OpenRouter `tools` parameter)
  - Pydantic model (validates the LLM's tool_call.function.arguments)
"""
from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

from engine.brain.contracts.session_state import Dimension


# ═══════════════════════════════════════════════════════════════
# 1. respond — the primary tool: speak the next AI turn
# ═══════════════════════════════════════════════════════════════

class RespondInput(BaseModel):
    """Speak the next AI turn. The text is streamed to TTS char-by-char.

    Streaming: the LLM should produce `utterance` first in the JSON ordering
    so chars start flowing to TTS within ~80ms of the first token (the
    UtteranceExtractor pulls characters out as they arrive, before the rest
    of the JSON is even produced).

    Phase transitions are NOT controlled by the slow LLM. The CadenceTracker
    owns phase progression (time-based budgets) and the PhaseOverrideAgent
    owns any overrides. The slow LLM just speaks the current phase — the
    `tracker_phase_block` in its system prompt tells it which phase it's in
    and what to do.
    """

    utterance: str = Field(
        ...,
        description=(
            "The exact text to speak. 1-3 sentences in normal mode, max 2 in "
            "protected-response mode. No emojis, no markdown, no stage "
            "directions. Spoken verbatim — write it the way you'd say it."
        ),
    )
    confidence: float = Field(
        default=0.8,
        ge=0.0, le=1.0,
        description="How sure you are this is the right next thing to say.",
    )
    concern: str | None = Field(
        default=None,
        description=(
            "Optional. If you noticed something off about the candidate's "
            "answer (vague, contradicting earlier, evasive), describe it "
            "briefly for the integrity log. Does not affect what you say."
        ),
    )


RESPOND_TOOL: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "respond",
        "description": (
            "Speak the next AI interviewer turn. Use this for every turn. "
            "The `utterance` field is streamed to TTS as it's produced — "
            "produce it FIRST in your tool-call JSON for low latency."
        ),
        "parameters": {
            "type": "object",
            "additionalProperties": False,
            "required": ["utterance"],
            "properties": {
                "utterance": {"type": "string", "minLength": 1, "maxLength": 1200},
                "confidence": {"type": "number", "minimum": 0, "maximum": 1},
                "concern": {"type": ["string", "null"]},
            },
        },
    },
}


# ═══════════════════════════════════════════════════════════════
# 2. update_score — mutate rubric_scores (ScorerAgent)
# ═══════════════════════════════════════════════════════════════

class ScoreDelta(BaseModel):
    dimension: Dimension
    new_score: float = Field(..., ge=0.0, le=5.0)
    confidence: float = Field(..., ge=0.0, le=1.0)
    evidence_quote: str
    evidence_turn_id: str


UPDATE_SCORE_TOOL: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "update_score",
        "description": "Update the running rubric score for one dimension.",
        "parameters": {
            "type": "object",
            "additionalProperties": False,
            "required": ["dimension", "new_score", "confidence",
                         "evidence_quote", "evidence_turn_id"],
            "properties": {
                "dimension": {"type": "string", "enum": [d.value for d in Dimension]},
                "new_score": {"type": "number", "minimum": 0, "maximum": 5},
                "confidence": {"type": "number", "minimum": 0, "maximum": 1},
                "evidence_quote": {"type": "string", "minLength": 1},
                "evidence_turn_id": {"type": "string", "minLength": 1},
            },
        },
    },
}


# ═══════════════════════════════════════════════════════════════
# 3. transition_phase — explicit phase change
# ═══════════════════════════════════════════════════════════════

class TransitionPhaseInput(BaseModel):
    # Phase id as a plain string (sourced from the active CadencePlan).
    # The runtime validates this against the cadence's known phase ids
    # when the tool is invoked.
    target: str
    reason: str


TRANSITION_PHASE_TOOL: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "transition_phase",
        "description": "Move the interview to the next phase. Validated against transitions.py.",
        "parameters": {
            "type": "object",
            "additionalProperties": False,
            "required": ["target", "reason"],
            "properties": {
                # Phase ids are not fixed — they're whatever the active
                # CadencePlan defines. The runtime validates the target
                # against the cadence's phase set at tool-call time.
                "target": {"type": "string"},
                "reason": {"type": "string", "minLength": 1},
            },
        },
    },
}


# ═══════════════════════════════════════════════════════════════
# 4. flag_integrity — append to active_flags
# ═══════════════════════════════════════════════════════════════

class FlagIntegrityInput(BaseModel):
    kind: str
    severity: Literal["low", "medium", "high"]
    evidence_quote: str
    evidence_turn_id: str
    note: str


FLAG_INTEGRITY_TOOL: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "flag_integrity",
        "description": "Flag a candidate utterance as suspicious / inconsistent.",
        "parameters": {
            "type": "object",
            "additionalProperties": False,
            "required": ["kind", "severity", "evidence_quote", "evidence_turn_id", "note"],
            "properties": {
                "kind": {"type": "string"},
                "severity": {"type": "string", "enum": ["low", "medium", "high"]},
                "evidence_quote": {"type": "string"},
                "evidence_turn_id": {"type": "string"},
                "note": {"type": "string"},
            },
        },
    },
}


# ═══════════════════════════════════════════════════════════════
# 5. request_clarification — speak a templated "I didn't catch that"
# ═══════════════════════════════════════════════════════════════

class RequestClarificationInput(BaseModel):
    prompt_text: str = Field(default="Sorry — could you say that again? I didn't catch it cleanly.")


REQUEST_CLARIFICATION_TOOL: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "request_clarification",
        "description": (
            "Ask the candidate to repeat themselves. Use when STT confidence "
            "is low or the answer doesn't seem to match the question."
        ),
        "parameters": {
            "type": "object",
            "additionalProperties": False,
            "required": [],
            "properties": {
                "prompt_text": {"type": "string"},
            },
        },
    },
}


ALL_TOOLS = [
    RESPOND_TOOL,
    UPDATE_SCORE_TOOL,
    TRANSITION_PHASE_TOOL,
    FLAG_INTEGRITY_TOOL,
    REQUEST_CLARIFICATION_TOOL,
]

# QuestionAgent does NOT use tools — the slow LLM streams plain text. The
# `respond` tool schema is kept here only because FillerAgent still uses it
# to enforce its ≤8-token short utterance via structured output.
FILLER_AGENT_TOOLS = [RESPOND_TOOL]
