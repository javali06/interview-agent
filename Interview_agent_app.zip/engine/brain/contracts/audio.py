"""Audio I/O protocols — narrow interface between orchestrator and stream_b_new.

NEW_STREAM_B.md §4.1. The orchestrator exposes a `MicAudioSource` /
`SpeakerAudioSink`; Stream B sees only the protocols below. A future Teams
bot or WAV-file source slots in identically.
"""
from __future__ import annotations

from typing import AsyncIterator, Protocol, runtime_checkable

# Stream A's mic-side wire format (mirrors stream_a/contracts/wire_formats.py).
SAMPLE_RATE_HZ = 16_000
FRAME_MS = 20
FRAME_SAMPLES = SAMPLE_RATE_HZ * FRAME_MS // 1000  # 320
FRAME_BYTES = FRAME_SAMPLES * 2                     # PCM16 mono = 640 bytes


@runtime_checkable
class AudioSource(Protocol):
    """Yields 20ms PCM16 mono frames at 16 kHz (raw bytes, no header)."""

    async def frames(self) -> AsyncIterator[bytes]: ...
    async def start(self) -> None: ...
    async def stop(self) -> None: ...


@runtime_checkable
class AudioSink(Protocol):
    """Plays PCM16 mono samples (raw bytes, no header) at the configured rate."""

    sample_rate_hz: int

    async def play(self, pcm: bytes) -> None: ...
    async def flush(self) -> None: ...
    async def stop(self) -> None: ...
    def bytes_buffered(self) -> int: ...
