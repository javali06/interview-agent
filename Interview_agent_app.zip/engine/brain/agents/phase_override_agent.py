"""Phase-override agent — fast LLM that can preempt the time-based phase
change when the conversation says it should.

The cadence tracker advances phases on a strict time/pool budget. That's
the right primary signal — predictable, deterministic, easy to debug.
But sometimes the candidate explicitly asks to end early ("let's wrap
this up"), or finishes the technical pool in 30 seconds when the budget
was 12 minutes, or otherwise signals a need to move on.

This agent reads the last ~5 conversation turns + the current phase
state and decides whether to:
  - STAY: tracker's default behaviour holds.
  - ADVANCE_NOW: jump to the next phase immediately, regardless of time.
  - END_NOW: jump to the terminal phase (wrap-up) and end after.

The Director invokes this on each candidate STT delivery (in parallel
with the verifier and tracker). Its result is advisory — the tracker is
the authority and the Director chooses whether to honour it.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any, Literal

from pydantic import BaseModel, Field

from engine.brain.contracts.session_state import Speaker
from engine.brain.core.conversation_context import ConversationContext
from engine.brain.llm.client import LLMClient, LLMRequest
from engine.brain.observability.langfuse_client import apply_llm_result, observe_llm
from engine.brain.observability.tracer import Tracer

from engine.brain.prompts import load as load_prompt

logger = logging.getLogger(__name__)


Override = Literal[
    "stay",          # let the tracker do its thing
    "advance_now",   # move to the next phase now
    "end_now",       # jump to terminal phase + end
]


class _PhaseOverrideToolInput(BaseModel):
    override: Override
    reason: str = Field(min_length=1, max_length=200)
    confidence: float = Field(ge=0.0, le=1.0, default=0.7)


_OVERRIDE_TOOL: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "decide_phase_override",
        "description": (
            "Decide whether the interview should override the tracker's "
            "time-based phase plan based on the last few turns of "
            "conversation."
        ),
        "parameters": {
            "type": "object",
            "required": ["override", "reason"],
            "properties": {
                "override": {
                    "type": "string",
                    "enum": list(Override.__args__),
                },
                "reason": {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 200,
                },
                "confidence": {
                    "type": "number",
                    "minimum": 0.0,
                    "maximum": 1.0,
                },
            },
        },
    },
}


@dataclass
class PhaseOverrideResult:
    override: Override
    reason: str
    confidence: float
    latency_ms: int
    error: str | None = None


def _default_stay() -> PhaseOverrideResult:
    return PhaseOverrideResult(
        override="stay",
        reason="default_fallback (LLM error or no signal)",
        confidence=0.0,
        latency_ms=0,
        error=None,
    )




class PhaseOverrideAgent:
    name = "phase_override_agent"

    def __init__(
        self,
        *,
        llm: LLMClient,
        model: str = "llama-3.1-8b-instant",
        tracer: Tracer,
        history_turns: int = 5,
        timeout_s: float = 5.0,
        min_confidence_to_act: float = 0.7,
    ) -> None:
        self._llm = llm
        self._model = model
        self._tracer = tracer
        self._history_turns = history_turns
        self._timeout_s = timeout_s
        self._min_confidence_to_act = min_confidence_to_act

    async def decide(
        self,
        ctx: ConversationContext,
        *,
        current_phase_id: str,
        questions_remaining: int,
        elapsed_in_phase_s: int,
        phase_budget_s: int,
    ) -> PhaseOverrideResult:
        """Call the fast LLM with the last few turns + phase state.
        Returns the override decision (or 'stay' on error)."""
        history_snippet = _render_recent_turns(ctx, self._history_turns)
        if not history_snippet:
            return _default_stay()

        user_msg = (
            f"Current phase: {current_phase_id} "
            f"(elapsed {elapsed_in_phase_s}s / budget {phase_budget_s}s, "
            f"{questions_remaining} questions remaining in pool)\n\n"
            f"Last {self._history_turns} turns:\n{history_snippet}\n\n"
            "Decide. Call `decide_phase_override`."
        )

        req = LLMRequest(
            system_prompt=load_prompt("phase_override"),
            user_messages=[{"role": "user", "content": user_msg}],
            tools=[_OVERRIDE_TOOL],
            tool_choice={"type": "function",
                         "function": {"name": "decide_phase_override"}},
            model=self._model,
            temperature=0.1,
            max_tokens=120,
            parser=_PhaseOverrideToolInput,
        )

        # Emit llm_call_started BEFORE the API call so the admin trace
        # viewer's prompt drawer can show the exact system prompt + user
        # messages we sent. Mirrors verifier_agent / question_agent.
        system_prompt_text = load_prompt("phase_override")
        user_messages_payload = [{"role": "user", "content": user_msg}]
        with observe_llm(
            agent=self.name, model=self._model,
            session_id=str(self._tracer.session_id),
            user_id=ctx.candidate_name, phase=current_phase_id,
            # Mirror question_agent / verifier: Langfuse `input` is the EXACT
            # system prompt + user message sent (the user message already
            # embeds the history snippet + phase state). Convenience fields
            # stay in metadata.
            input_data={"system": system_prompt_text,
                        "messages": user_messages_payload},
            metadata={"role": ctx.role,
                      "current_phase": current_phase_id,
                      "elapsed_s": elapsed_in_phase_s,
                      "budget_s": phase_budget_s,
                      "questions_remaining": questions_remaining},
            model_parameters={"temperature": 0.1, "max_tokens": 120,
                              "streaming": True, "timeout_s": self._timeout_s,
                              "min_confidence_to_act":
                                  self._min_confidence_to_act,
                              "tool_choice": "decide_phase_override"},
        ) as lf_obs:
            self._tracer.event(
                "llm_call_started",
                agent=self.name, model=self._model,
                system_prompt=system_prompt_text,
                user_messages=user_messages_payload,
            )
            try:
                res = await asyncio.wait_for(
                    self._llm.complete_streaming(req, cancel_event=asyncio.Event()),
                    timeout=self._timeout_s,
                )
            except asyncio.TimeoutError:
                logger.warning(
                    "[PHASE-OVERRIDE] timeout — defaulting to 'stay'",
                )
                try:
                    lf_obs.update(
                        output={"override": "stay", "fallback": "timeout"},
                        metadata={"timeout_s": self._timeout_s},
                        level="WARNING",
                        status_message=f"timeout after {self._timeout_s}s",
                    )
                except Exception:  # pragma: no cover
                    pass
                self._tracer.event(
                    "llm_call_failed",
                    agent=self.name, model=self._model,
                    reason="timeout",
                    error=f"timeout after {self._timeout_s}s",
                )
                return _default_stay()
            except Exception as e:
                logger.warning(
                    "[PHASE-OVERRIDE] error: %s — defaulting to 'stay'", e,
                )
                try:
                    lf_obs.update(
                        output={"override": "stay", "fallback": "error"},
                        metadata={"error": str(e)},
                        level="ERROR",
                        status_message=str(e)[:200],
                    )
                except Exception:  # pragma: no cover
                    pass
                self._tracer.event(
                    "llm_call_failed",
                    agent=self.name, model=self._model,
                    reason="transport_error",
                    error=str(e)[:200],
                )
                return _default_stay()

            if res.error or res.parsed is None:
                logger.warning(
                    "[PHASE-OVERRIDE] validation failed: %s — defaulting to 'stay'",
                    res.error,
                )
                # Model responded + cost incurred; record it (apply_llm_result),
                # then explicitly flag the generation as degraded when there's
                # no res.error so a pure output-validation failure is still
                # visible as a failed attempt in Langfuse.
                apply_llm_result(
                    lf_obs, res,
                    output={"override": "stay", "fallback": "validation"},
                    extra_metadata={"fallback_reason": "validation"},
                    session_id=str(self._tracer.session_id),
                )
                if not res.error:
                    try:
                        lf_obs.update(
                            level="WARNING",
                            status_message="output validation failed — used "
                                           "'stay' fallback",
                        )
                    except Exception:  # pragma: no cover
                        pass
                self._tracer.event(
                    "llm_call_failed",
                    agent=self.name, model=self._model,
                    reason="validation_or_error",
                    error=str(res.error)[:200] if res.error else "parsed=None",
                    latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
                    tokens_in=res.tokens_in, tokens_out=res.tokens_out,
                    tokens_in_cached=res.tokens_in_cached,
                    tokens_in_cache_write=res.tokens_in_cache_write,
                    cost_usd=res.cost_usd, generation_id=res.generation_id,
                )
                return _default_stay()

            parsed: _PhaseOverrideToolInput = res.parsed  # type: ignore[assignment]
            apply_llm_result(
                lf_obs, res,
                output={"override": parsed.override,
                        "reason": parsed.reason,
                        "confidence": parsed.confidence},
                extra_metadata={"phase": current_phase_id},
                session_id=str(self._tracer.session_id),
            )
            try:
                lf_obs.score(  # type: ignore[attr-defined]
                    name="phase_override_confidence",
                    value=float(parsed.confidence),
                    data_type="NUMERIC",
                )
                lf_obs.score(  # type: ignore[attr-defined]
                    name="phase_override_decision",
                    value=parsed.override,
                    data_type="CATEGORICAL",
                )
            except Exception:  # pragma: no cover
                pass
            langfuse_trace_id = getattr(lf_obs, "trace_id", None)
        # Apply the confidence gate. Low-confidence non-stay decisions get
        # downgraded so the tracker remains authoritative.
        actual = parsed.override
        if actual != "stay" and parsed.confidence < self._min_confidence_to_act:
            logger.info(
                "[PHASE-OVERRIDE] '%s' suggested but conf %.2f < %.2f — "
                "downgrading to 'stay'",
                actual, parsed.confidence, self._min_confidence_to_act,
            )
            actual = "stay"

        # Stringify the tool-call response for the admin's prompt drawer.
        import json as _json
        response_text_serialized = _json.dumps(
            {
                "override": parsed.override,
                "reason": parsed.reason,
                "confidence": parsed.confidence,
            },
            indent=2,
        )
        self._tracer.event(
            "llm_call_completed",
            agent=self.name, model=self._model,
            response_text=response_text_serialized,
            latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
            tokens_in=res.tokens_in, tokens_out=res.tokens_out,
            tokens_in_cached=res.tokens_in_cached,
            tokens_in_cache_write=res.tokens_in_cache_write,
            cost_usd=res.cost_usd, generation_id=res.generation_id,
            langfuse_trace_id=langfuse_trace_id,
        )
        self._tracer.event(
            "phase_override_decided",
            agent=self.name,
            override=actual,
            raw_override=parsed.override,
            confidence=parsed.confidence,
            reason=parsed.reason,
            latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
            tokens_in=res.tokens_in, tokens_out=res.tokens_out,
            tokens_in_cached=res.tokens_in_cached,
            tokens_in_cache_write=res.tokens_in_cache_write,
            cost_usd=res.cost_usd, generation_id=res.generation_id,
            model=self._model,
            langfuse_trace_id=langfuse_trace_id,
        )
        logger.info(
            "[PHASE-OVERRIDE] override=%s conf=%.2f reason=%r",
            actual, parsed.confidence, parsed.reason,
        )
        return PhaseOverrideResult(
            override=actual,
            reason=parsed.reason,
            confidence=parsed.confidence,
            latency_ms=res.latency_ms,
        )


def _render_recent_turns(ctx: ConversationContext, n: int) -> str:
    """Render the last N turns as 'role: text' lines for the LLM."""
    turns = ctx.recent_turns[-n:] if len(ctx.recent_turns) > n else ctx.recent_turns
    lines: list[str] = []
    for t in turns:
        sp = t.speaker.value if hasattr(t.speaker, "value") else t.speaker
        if sp == Speaker.AI.value:
            label = "interviewer"
        elif sp == Speaker.CANDIDATE.value:
            label = "candidate"
        else:
            continue  # skip phase markers / unknown
        text = (t.text or "").strip()
        if not text:
            continue
        # Truncate very long turns to keep the prompt tight.
        if len(text) > 220:
            text = text[:217] + "..."
        lines.append(f"  {label}: {text}")
    return "\n".join(lines)
