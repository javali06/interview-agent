"""FillerAgent — fast LLM acknowledgment.

NEW_STREAM_B.md §6.5 / §F1. Triggered by the latency orchestrator when slow
LLM hasn't produced first audio within ~800ms of dispatch. Uses a fast model
with a tight system prompt that forbids commitment language. Falls back to
canned phrases on LLM error.
"""
from __future__ import annotations

import asyncio
import logging
import random
from dataclasses import dataclass
from typing import Callable

from engine.brain.contracts.tool_schema import FILLER_AGENT_TOOLS, RespondInput
from engine.brain.core.conversation_context import (
    ConversationContext,
    turns_to_messages,
)
from engine.brain.llm.client import LLMClient, LLMRequest
from engine.brain.observability.langfuse_client import apply_llm_result, observe_llm
from engine.brain.observability.timing import log_timing
from engine.brain.observability.tracer import Tracer
from engine.brain.prompts import load as load_prompt

logger = logging.getLogger(__name__)


_CANNED_FILLERS_FALLBACK = [
    "Hmm, let me think about that for a moment.",
    "Give me a second to work through this carefully.",
    "That's a good one — let me think.",
    "Hmm, OK — let me pull this together.",
    "Right, give me a moment to phrase this properly.",
]


@dataclass
class FillerAgentResult:
    utterance: str
    cancelled: bool
    used_canned: bool
    error: str | None
    latency_ms: int
    ttft_ms: int | None
    model: str | None = None
    tokens_in: int | None = None
    tokens_out: int | None = None


class FillerAgent:
    name = "filler_agent"

    def __init__(
        self,
        *,
        llm: LLMClient | None,
        model: str,
        tracer: Tracer,
        max_tokens: int = 64,
        temperature: float = 0.7,
    ) -> None:
        self._llm = llm                  # None → always canned
        self._model = model
        self._tracer = tracer
        self._max_tokens = max_tokens
        self._temperature = temperature

    async def run(
        self,
        ctx: ConversationContext,
        *,
        on_utterance_char: Callable[[str], None],
        on_first_token: Callable[[], None],
        cancel_event: asyncio.Event,
    ) -> FillerAgentResult:
        """Generate a 'thinking' filler ("Hmm, let me think about that for
        a moment.") via the fast LLM. Used as a single tier — fires when
        slow LLM hasn't first-tokened by `filler_threshold_ms`."""
        canned_bank = _CANNED_FILLERS_FALLBACK
        max_tokens = self._max_tokens

        if self._llm is None:
            text = random.choice(canned_bank)
            on_first_token()
            for c in text:
                on_utterance_char(c)
            self._tracer.event(
                "llm_call_completed",
                agent=self.name, model="canned", response_text=text,
                latency_ms=0, ttft_ms=0,
            )
            return FillerAgentResult(
                utterance=text, cancelled=False, used_canned=True,
                error=None, latency_ms=0, ttft_ms=0,
                model="canned", tokens_in=0, tokens_out=0,
            )

        system = load_prompt("filler_prompt")
        # Fast LLM gets only the last 10 turns (cheap prompt — fillers don't
        # need long history). The 6-12-word "thinking" instruction lives in
        # the system prompt; tool_choice forces the `respond` call. No
        # trailing instruction message is needed.
        messages = turns_to_messages(ctx.recent_turns, limit=10)

        req = LLMRequest(
            system_prompt=system,
            user_messages=messages,
            tools=FILLER_AGENT_TOOLS,
            tool_choice={"type": "function", "function": {"name": "respond"}},
            model=self._model,
            temperature=self._temperature,
            max_tokens=max_tokens,
            parser=RespondInput,
        )

        self._tracer.event(
            "llm_call_started", agent=self.name, model=self._model,
            system_prompt=system, user_messages=messages,
        )
        log_timing(logger, "LLM-fast", "dispatched", None, model=self._model)
        with observe_llm(
            agent=self.name, model=self._model,
            session_id=str(self._tracer.session_id),
            user_id=ctx.candidate_name, phase=ctx.phase,
            input_data={"messages": messages[-3:] if messages else []},
            metadata={"role": ctx.role},
            model_parameters={"temperature": self._temperature,
                              "max_tokens": self._max_tokens,
                              "streaming": True,
                              "tool_choice": "respond"},
        ) as lf_obs:
            res = await self._llm.complete_streaming(
                req,
                on_utterance_char=on_utterance_char,
                on_first_token=on_first_token,
                cancel_event=cancel_event,
            )
            apply_llm_result(
                lf_obs, res,
                output={"text": res.text_streamed},
                extra_metadata={"phase": ctx.phase},
                session_id=str(self._tracer.session_id),
            )
            langfuse_trace_id = getattr(lf_obs, "trace_id", None)
        if res.ttft_ms is not None:
            log_timing(logger, "LLM-fast", "first_token", res.ttft_ms,
                       model=self._model)
        log_timing(logger, "LLM-fast", "completed", res.latency_ms,
                   model=self._model,
                   cancelled=res.cancelled,
                   tokens_in=res.tokens_in or 0,
                   tokens_out=res.tokens_out or 0)

        if res.cancelled:
            self._tracer.event(
                "llm_call_failed", agent=self.name, reason="cancelled",
                latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
                tokens_in=res.tokens_in, tokens_out=res.tokens_out,
                langfuse_trace_id=langfuse_trace_id,
            )
            return FillerAgentResult(
                utterance=res.text_streamed, cancelled=True,
                used_canned=False, error=None,
                latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
                model=self._model,
                tokens_in=res.tokens_in, tokens_out=res.tokens_out,
            )

        if res.error or res.parsed is None:
            self._tracer.event(
                "llm_call_failed", agent=self.name,
                reason="validation_or_error", error=res.error,
                latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
                tokens_in=res.tokens_in, tokens_out=res.tokens_out,
                langfuse_trace_id=langfuse_trace_id,
            )
            text = random.choice(canned_bank)
            for c in text:
                on_utterance_char(c)
            return FillerAgentResult(
                utterance=text, cancelled=False, used_canned=True,
                error=res.error, latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
                model=self._model,
                tokens_in=res.tokens_in, tokens_out=res.tokens_out,
            )

        parsed: RespondInput = res.parsed  # type: ignore[assignment]
        text = parsed.utterance.strip()
        # Hard cap if the LLM ignored the 12-word ask.
        if len(text.split()) > 14:
            text = " ".join(text.split()[:12])
        self._tracer.event(
            "llm_call_completed", agent=self.name, model=self._model,
            response_text=text, tool_arguments=res.tool_arguments_raw,
            latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
            tokens_in=res.tokens_in, tokens_out=res.tokens_out,
            tokens_in_cached=res.tokens_in_cached,
            tokens_in_cache_write=res.tokens_in_cache_write,
            cost_usd=res.cost_usd, generation_id=res.generation_id,
            langfuse_trace_id=langfuse_trace_id,
        )
        return FillerAgentResult(
            utterance=text, cancelled=False, used_canned=False,
            error=None, latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
            model=self._model,
            tokens_in=res.tokens_in, tokens_out=res.tokens_out,
        )
