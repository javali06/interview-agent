"""QuestionAgent — the slow LLM that drives the interview's utterances.

Plain-text streaming. The slow LLM does not call tools — it just emits the
exact words the AI should say. The character stream is piped directly to
TTS for low TTFT. Phase transitions and per-turn classifications are owned
by the CadenceTracker and the fast LLM agents respectively; this agent
only speaks.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Callable

from engine.brain.core.conversation_context import (
    ConversationContext,
    turns_to_messages,
)
from engine.brain.llm.client import LLMClient, LLMRequest
from engine.brain.observability.langfuse_client import apply_llm_result, observe_llm
from engine.brain.observability.timing import log_timing
from engine.brain.observability.tracer import Tracer
from engine.brain.prompts import load as load_prompt

logger = logging.getLogger(__name__)


def _runtime_messages(ctx: ConversationContext) -> list[dict[str, str]]:
    """Build runtime-state messages to append to the conversation.

    Returns a list of OpenAI-format role-tagged messages. Each is a
    tag-only string — the meaning of each tag is defined ONCE in
    system_prompt.md so the LLM doesn't need re-explanation per turn.

    Two roles, two semantic meanings:
      - `user`  : candidate-side events (e.g. silence happened). Reads
                  naturally as "the candidate's turn was: this event."
      - `system`: out-of-band annotations about live state (phase
                  pressure, strikes, protected mode). Not part of the
                  conversation flow, just info the LLM needs.

    Why tags, not prose: consistent with the rest of the tag vocabulary
    (`<barged_in/>`, `<filler/>`, `<low_confidence/>`, etc.). One
    mechanism, defined once in the system prompt.
    """
    out: list[dict[str, str]] = []

    # Silence re-engagement is now injected by the Director as an ASSISTANT-role
    # <think> directive (director._persist_runtime_tags), not a <silence_ms=N/>
    # user tag — so nothing to emit here.

    # Out-of-band state signals — concatenated into one system message.
    # NOTE: `<phase_pace>` is intentionally NOT emitted here. The slow LLM
    # has zero agency over phase transitions (the tracker owns them), so
    # telling it "you're 93% through the budget" is pure noise that adds
    # conflicting signal — the LLM tries to "wrap up tersely" and abandons
    # productive deep-dive threads. The tracker handles phase progression
    # automatically; the LLM just keeps answering until the marker says
    # otherwise.
    state_tags: list[str] = []
    if ctx.in_protected_response:
        state_tags.append("<protected_response_mode/>")
    elif ctx.barge_in_strike_count >= 2:
        state_tags.append(
            f"<barge_in_strikes count={ctx.barge_in_strike_count}/>"
        )

    if state_tags:
        out.append({"role": "system", "content": " ".join(state_tags)})

    # Per-turn directive (verifier note + tracker "ask this question" /
    # "push for depth" / "topics to improvise from"). Composed once by
    # ConversationContext.build_context and stored on ctx.think_content.
    # Emitted as the LAST message before generation, as an ASSISTANT-role
    # message — it's the AI's own per-turn scratchpad / directive, not
    # something the candidate said. (Was previously user-role, which made
    # it read like candidate speech in the transcript.) It still sits
    # closest to the model's generation point. Without this append the
    # directive is built but never delivered, silently breaking the
    # Director's partial_answer_skip override and the tracker's
    # pool-question handoff.
    if ctx.think_content:
        out.append({
            "role": "assistant",
            "content": f"<think>\n{ctx.think_content}\n</think>",
        })

    return out


def _build_phase_transition_messages(
    ctx: ConversationContext,
) -> list[dict[str, str]]:
    """Truncated message history for a phase-transition dispatch.

    Two messages from history get through (in chronological order):
      1. The candidate's MOST RECENT turn anywhere in history. This is
         what the slow LLM briefly acknowledges before pivoting. It may
         be from before OR after the phase_changed marker — whichever
         is the latest candidate utterance we have.
      2. The most recent `<phase_changed>` marker (UNKNOWN-speaker turn)
         with its embedded intent + first pool question.

    We deliberately DROP any AI turn that sits between them — including
    an AI question that the candidate hasn't yet replied to. Leaving an
    unanswered assistant turn at the tail of the prompt is the most
    reliable way to make the model hallucinate the candidate's reply
    in candidate-voice ("I led the design of..."). Removing the
    dangling assistant turn forces the model to start a fresh AI turn
    against the new phase's tracker block.

    A final PHASE BOUNDARY system-role message goes after both, so the
    LAST thing the model reads before generating is the imperative to
    switch.
    """
    from engine.brain.contracts.session_state import Speaker

    turns = ctx.recent_turns

    marker_idx: int | None = None
    latest_cand_idx: int | None = None
    for i in range(len(turns) - 1, -1, -1):
        t = turns[i]
        sp = t.speaker.value if hasattr(t.speaker, "value") else str(t.speaker)
        if marker_idx is None and sp == Speaker.UNKNOWN.value and "<phase_changed" in (t.text or ""):
            marker_idx = i
        if latest_cand_idx is None and sp == Speaker.CANDIDATE.value:
            latest_cand_idx = i
        if marker_idx is not None and latest_cand_idx is not None:
            break

    keep_indices = sorted({
        i for i in (latest_cand_idx, marker_idx) if i is not None
    })
    kept = [turns[i] for i in keep_indices]

    messages = turns_to_messages(kept)

    # Per-turn directive (verifier note + tracker's "ask this question").
    # On phase-entry dispatches the tracker hands us the first question
    # of the new phase (or, for generic phases, the opening topics) via
    # ctx.think_content. Emit it as an ASSISTANT-role message (the AI's
    # own per-turn directive, not candidate speech) BEFORE the PHASE
    # BOUNDARY system message — PHASE BOUNDARY stays the strongest last
    # imperative, with the concrete question text right next to it.
    if ctx.think_content:
        messages.append({
            "role": "assistant",
            "content": f"<think>\n{ctx.think_content}\n</think>",
        })

    # Final imperative — the LAST thing the model sees. Tweaked so the
    # "acknowledge candidate" instruction is conditional: if the
    # candidate did reply (we included a user turn above), acknowledge
    # it briefly; if they didn't (no recent candidate turn), open the
    # phase directly without thanking them for nothing.
    has_recent_cand = latest_cand_idx is not None
    ack_clause = (
        "briefly acknowledge the candidate's last reply with ≤6 words "
        "('Got it.', 'Makes sense.'), and "
    ) if has_recent_cand else ""
    # A WRITTEN-RESPONSE phase opens a typed task, not a spoken question. The
    # full rules ride in the <think> directive and the marker; this is the
    # last-position reinforcement of the two that actually corrupt the
    # assessment when broken — inventing the material, or doing the task.
    written_clause = (
        " This phase is a WRITTEN task: state its instruction VERBATIM, never "
        "quote or invent the material the candidate is working from (it is "
        "already on their screen and you do not have it), never do the task "
        "yourself, and ask NO follow-up — one submission closes it."
    ) if ctx.written_response_brief else ""
    messages.append({
        "role": "system",
        "content": (
            "PHASE BOUNDARY — READ THIS LAST. A NEW phase has just "
            "started (see the <phase_changed/> marker). Your next "
            f"utterance MUST: {ack_clause}immediately ask the question "
            "/ open the topic defined by the tracker block in your "
            "system prompt for the NEW phase. Do NOT ask any follow-up "
            "about the prior topic. Do NOT continue any AI question "
            "that came before the marker — that thread is closed. Do "
            "NOT speak in the candidate's voice or fabricate an answer "
            "for them. Do NOT announce 'let's switch phases' — the "
            f"candidate must not perceive a phase boundary.{written_clause}"
        ),
    })
    return messages


class _TagStripper:
    """Filter `<…>` tags out of a character stream before it reaches TTS.

    Why we need this: the AI turn-history shown to the slow LLM contains
    annotations like `<filler text="Got it."/>`, `<barged_in/>`,
    `<silence_ms=N/>`, `<phase_changed .../>`, and `<think>...</think>`.
    Those tags inform the LLM about audio-side events / per-turn
    directives. In plain-text mode some models occasionally mimic the
    format and emit a tag in their own utterance. The system prompt
    forbids this, but a streaming filter is a strict safety net: even
    if the LLM slips, the candidate never hears it.

    Two stripping behaviours, depending on tag shape:

      1. **Self-closing or unknown tag** — `<…/>` or `<…>` followed by
         non-tag text. Buffer chars from `<` until the next `>` and
         discard the buffer. Anything after the tag flows through as
         normal speech.

      2. **Paired block tag** — `<think>…</think>`. The most dangerous
         case for `<think>` specifically: a naive single-tag stripper
         would discard the opening tag, LEAK the inner content as
         spoken text, then discard the closing tag. To prevent that,
         when we recognise an opening of a known block tag (the
         `_BLOCK_TAGS` allowlist) we switch to "block mode" and
         discard EVERYTHING until we see the matching `</tagname>`
         closer. Inner content never reaches the sink.

    If a tag buffer grows past 256 chars without closing, we flush it
    as literal text — the LLM produced an unclosed `<` (rare; "less
    than X"). Normal spoken English contains no `<` so this is a pure
    no-op on the common path.
    """

    _MAX_BUF = 256
    _MAX_BLOCK_BUF = 8192          # generous; abandons block at this size
    _BLOCK_TAGS = ("think",)       # tag names whose CONTENT must also be stripped

    def __init__(self, sink: Callable[[str], None]) -> None:
        self._sink = sink
        self._in_tag = False
        self._buf: list[str] = []
        # Set when we're inside a block tag's content (e.g., after seeing
        # `<think>`). Holds the literal closing tag we're hunting for, in
        # lowercase, e.g. `</think>`. None when not in block mode.
        self._block_close_match: str | None = None
        self._block_buf: list[str] = []

    def feed(self, piece: str) -> None:
        for c in piece:
            self._feed_char(c)

    def _feed_char(self, c: str) -> None:
        # Block-mode: discard every char until we see the closing tag.
        if self._block_close_match is not None:
            self._block_buf.append(c)
            buf_str = "".join(self._block_buf).lower()
            if buf_str.endswith(self._block_close_match):
                # Found close — drop the whole block (open + content + close).
                self._block_close_match = None
                self._block_buf = []
            elif len(self._block_buf) > self._MAX_BLOCK_BUF:
                # Pathological: never closed. Bail out and resume normal
                # mode — the model probably got stuck in `<think>` and
                # we shouldn't eat the rest of the stream.
                self._block_close_match = None
                self._block_buf = []
            return

        if not self._in_tag:
            if c == "<":
                self._in_tag = True
                self._buf = ["<"]
            else:
                self._sink(c)
            return

        # Inside a potential tag.
        self._buf.append(c)
        if c == ">":
            tag_text = "".join(self._buf)
            tag_lower = tag_text.lower()
            # If the LLM produced `<think>` (or `<think ...>` with
            # attributes) — NOT `</think>` and NOT self-closing — switch
            # to block-strip mode so we also drop the inner content.
            for block_tag in self._BLOCK_TAGS:
                open_form = f"<{block_tag}"
                close_form = f"</{block_tag}"
                if (
                    tag_lower.startswith(open_form)
                    and not tag_lower.startswith(close_form)
                    and not tag_lower.endswith("/>")
                    # Char immediately after `<{tag}` must be `>` or
                    # whitespace — otherwise it's a different tag whose
                    # name happens to start with `think` (`<thinker>`).
                    and (
                        len(tag_lower) == len(open_form) + 1
                        or tag_lower[len(open_form)] in (">", " ", "\t", "\n")
                    )
                ):
                    self._block_close_match = f"</{block_tag}>"
                    self._block_buf = []
                    self._in_tag = False
                    self._buf = []
                    return
            # Regular tag (self-closing or unknown). Discard.
            self._in_tag = False
            self._buf = []
            return
        if len(self._buf) > self._MAX_BUF:
            # Doesn't look like a tag — flush as literal text.
            for ch in self._buf:
                self._sink(ch)
            self._in_tag = False
            self._buf = []

    def flush(self) -> None:
        # End of stream: if we're mid-tag, emit literal (might be normal
        # text after an unclosed `<`). If we're mid-block, drop silently
        # — the model was streaming inside a `<think>` block that never
        # closed; speaking the partial thought content would be worse
        # than dropping it.
        if self._buf and self._block_close_match is None:
            for ch in self._buf:
                self._sink(ch)
            self._buf = []
            self._in_tag = False
        if self._block_close_match is not None:
            self._block_close_match = None
            self._block_buf = []


@dataclass
class QuestionAgentResult:
    utterance: str
    cancelled: bool
    error: str | None
    ttft_ms: int | None
    latency_ms: int
    model: str | None = None
    tokens_in: int | None = None
    tokens_out: int | None = None


class QuestionAgent:
    name = "question_agent"

    def __init__(
        self,
        *,
        llm: LLMClient,
        model: str,
        tracer: Tracer,
        temperature: float = 0.4,
        max_tokens: int | None = None,
    ) -> None:
        self._llm = llm
        self._model = model
        self._tracer = tracer
        self._temperature = temperature
        # max_tokens precedence:
        #   1. explicit arg (kept for tests + ad-hoc usage)
        #   2. SLOW_LLM_MAX_TOKENS env var — deploy can cap verbose
        #      AI utterances without recompiling.
        #   3. Hard default 2000 — reasoning models (gpt-oss-120b) burn
        #      most of the budget inside <think>...</think>, which is then
        #      stripped by _TagStripper before TTS. 200 was too tight: the
        #      model hit the cap mid-think and produced ZERO spoken text.
        import os as _os
        if max_tokens is None:
            max_tokens = int(_os.environ.get("SLOW_LLM_MAX_TOKENS", "2000"))
        self._max_tokens = max_tokens

    async def run(
        self,
        ctx: ConversationContext,
        *,
        on_utterance_char: Callable[[str], None],
        on_first_token: Callable[[], None],
        cancel_event: asyncio.Event,
    ) -> QuestionAgentResult:
        system = self._build_system_prompt(ctx)
        messages = self._build_messages(ctx)
        req = LLMRequest(
            system_prompt=system,
            user_messages=messages,
            tools=[],
            tool_choice=None,
            model=self._model,
            temperature=self._temperature,
            max_tokens=self._max_tokens,
            parser=None,
        )
        user_chars = sum(len(m.get("content", "")) for m in messages)

        # Wrap the TTS sink so any `<...>` tags the LLM emits are stripped
        # before reaching audio. The transcript history still keeps tags
        # for the LLM's context on the next turn; only the *spoken* stream
        # is filtered.
        stripper = _TagStripper(on_utterance_char)

        def _piped_char(c: str) -> None:
            stripper.feed(c)

        with self._tracer.span(
            "llm_call", "llm_call_started",
            agent=self.name, model=self._model, phase=ctx.phase,
            system_prompt_chars=len(system), user_prompt_chars=user_chars,
        ) as span, observe_llm(
            agent=self.name, model=self._model,
            session_id=str(self._tracer.session_id),
            user_id=ctx.candidate_name, phase=ctx.phase,
            input_data={"system": system, "messages": messages},
            metadata={"system_prompt_chars": len(system),
                      "user_prompt_chars": user_chars,
                      "role": ctx.role},
            model_parameters={"temperature": self._temperature,
                              "max_tokens": self._max_tokens,
                              "streaming": True},
        ) as lf_obs:
            self._tracer.event(
                "llm_call_started",
                agent=self.name, model=self._model,
                system_prompt=system, user_messages=messages,
            )
            log_timing(logger, "LLM-slow", "dispatched", None,
                       model=self._model, phase=ctx.phase)
            res = await self._llm.complete_text_streaming(
                req,
                on_utterance_char=_piped_char,
                on_first_token=on_first_token,
                cancel_event=cancel_event,
            )
            stripper.flush()
            if res.ttft_ms is not None:
                log_timing(logger, "LLM-slow", "first_token", res.ttft_ms,
                           model=self._model)
            log_timing(logger, "LLM-slow", "completed", res.latency_ms,
                       model=self._model,
                       cancelled=res.cancelled,
                       tokens_in=res.tokens_in or 0,
                       tokens_out=res.tokens_out or 0)
            span.set(
                ttft_ms=res.ttft_ms, latency_ms=res.latency_ms,
                cancelled=res.cancelled, error=res.error,
                output_text_chars=len(res.text_streamed),
            )
            apply_llm_result(
                lf_obs, res,
                output={"text": res.text_streamed},
                extra_metadata={"output_text_chars": len(res.text_streamed),
                                "phase": ctx.phase},
                session_id=str(self._tracer.session_id),
            )
            # Capture trace_id INSIDE the with-block — used by the admin
            # phase-flow UI to deep-link this exact LLM call to its trace
            # in Langfuse. None when Langfuse is disabled (no-op shim).
            langfuse_trace_id = getattr(lf_obs, "trace_id", None)

        if res.cancelled:
            self._tracer.event(
                "llm_call_failed",
                agent=self.name, reason="cancelled", model=self._model,
                latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
                tokens_in=res.tokens_in, tokens_out=res.tokens_out,
                tokens_in_cached=res.tokens_in_cached,
                cost_usd=res.cost_usd, generation_id=res.generation_id,
                langfuse_trace_id=langfuse_trace_id,
            )
            return QuestionAgentResult(
                utterance="",
                cancelled=True,
                error=None, ttft_ms=res.ttft_ms, latency_ms=res.latency_ms,
                model=self._model,
                tokens_in=res.tokens_in, tokens_out=res.tokens_out,
            )
        if res.error:
            self._tracer.event(
                "llm_call_failed",
                agent=self.name, reason="transport_error", model=self._model,
                error=res.error,
                latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
                tokens_in=res.tokens_in, tokens_out=res.tokens_out,
                tokens_in_cached=res.tokens_in_cached,
                cost_usd=res.cost_usd, generation_id=res.generation_id,
                langfuse_trace_id=langfuse_trace_id,
            )
            return QuestionAgentResult(
                utterance=res.text_streamed,
                cancelled=False,
                error=res.error, ttft_ms=res.ttft_ms, latency_ms=res.latency_ms,
                model=self._model,
                tokens_in=res.tokens_in, tokens_out=res.tokens_out,
            )

        utterance = res.text_streamed.strip()
        self._tracer.event(
            "llm_call_completed",
            agent=self.name, model=self._model,
            latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
            tokens_in=res.tokens_in, tokens_out=res.tokens_out,
            tokens_in_cached=res.tokens_in_cached,
            tokens_in_cache_write=res.tokens_in_cache_write,
            tokens_out_reasoning=res.tokens_out_reasoning,
            cost_usd=res.cost_usd,
            generation_id=res.generation_id,
            response_text=utterance,
            langfuse_trace_id=langfuse_trace_id,
        )
        return QuestionAgentResult(
            utterance=utterance,
            cancelled=False,
            error=None,
            ttft_ms=res.ttft_ms,
            latency_ms=res.latency_ms,
            model=self._model,
            tokens_in=res.tokens_in, tokens_out=res.tokens_out,
        )

    def _build_system_prompt(self, ctx: ConversationContext) -> str:
        """Compose the slow LLM's system prompt.

        Section order:
          1. Base system prompt (system_prompt.md)
          2. Candidate profile (name, role, resume)
          3. Tracker phase context (STATIC phase setup — intent,
             operating_instructions, status counters)

        The per-turn DYNAMIC directive (verifier note + "ask this
        question") is NOT in the system prompt anymore. It rides in a
        <think> user-role message at the end of `_build_messages` so
        the system prompt stays stable across turns (cache-friendly)
        and the model sees the latest directive right next to the
        candidate's latest reply.

        The CadenceTracker is the single source of truth for what each
        phase means. It owns the cadence YAML and renders the phase
        block on demand. The slow LLM only sees what the tracker hands
        it — there is no static per-phase prompt file to fall back to.
        """
        if not ctx.tracker_phase_block:
            raise RuntimeError(
                "QuestionAgent requires ctx.tracker_phase_block. The "
                "CadenceTracker must supply phase context — there is no "
                "file-based fallback.",
            )
        base = load_prompt("system_prompt")
        candidate_block = (
            "candidate_profile:\n"
            f"  name: {ctx.candidate_name}\n"
            f"  role: {ctx.role}\n"
            f"  resume_summary: {ctx.resume_summary or '(not provided)'}\n"
        )
        parts = [base, "---", candidate_block]
        parts.extend(["---", ctx.tracker_phase_block])

        # Coding-submission block: only present in the phase immediately
        # after a coding phase. Gives the slow LLM the actual code +
        # test results so the discussion can ground in what they wrote,
        # not generic "tell me about your approach" pantomime.
        if ctx.coding_submission_block:
            parts.extend(["---", ctx.coding_submission_block])

        # Final, post-tracker directive. Models routinely over-weight the
        # most recent conversation turns and ignore the system prompt's
        # phase rules — putting the strongest reminder LAST keeps it
        # closest to the user message and hardest to forget.
        parts.append(
            "---\n"
            "TOP-PRIORITY RULE (overrides anything below if there's a "
            "conflict): your next utterance MUST stay inside the current "
            "phase defined above. If the conversation history above is "
            "from a prior phase, IGNORE that thread — that work is done. "
            "Speak only what the tracker tells you to speak for this "
            "phase. Do NOT carry a prior phase's question forward."
        )
        return "\n\n".join(parts)

    def _build_messages(self, ctx: ConversationContext) -> list[dict[str, str]]:
        """Build proper OpenAI multi-turn messages for the slow LLM.

        Normal (non-phase-transition) dispatches send the full conversation
        history so the LLM can ask non-redundant follow-ups. Tag-only
        runtime signals (`<silence_ms=N/>`, `<phase_pace/>`, etc.) are
        appended afterwards. Each tag's meaning is defined once in
        system_prompt.md — same mechanism as `<barged_in/>`, `<filler/>`.

        PHASE-TRANSITION DISPATCHES are different: we deliberately
        TRUNCATE the history. Models routinely treat the latest few
        candidate turns as the "active thread" and continue follow-up
        questions on whatever the candidate was just discussing —
        completely ignoring the system prompt's tracker block when it
        says to switch topics. With several turns of prior-phase content
        in front of the model, even strong directives lose. So on a
        phase transition we show only:
          1. The most recent <phase_changed/> marker (with the new
             phase's intent + opening question).
          2. The most recent candidate turn before that marker — so the
             LLM has ONE short clause to acknowledge before pivoting.
          3. A final PHASE BOUNDARY system message to force the switch.
        The prior phase's resume / follow-up history is omitted on this
        single turn. Once the new phase has at least one in-phase
        exchange, regular full-history dispatches resume."""
        if ctx.is_phase_transition:
            messages = _build_phase_transition_messages(ctx)
        else:
            # Phase truncation is enforced at the moment the phase_changed
            # marker is appended (see director._tick) — state.turns is
            # trimmed to [last_turn_before_marker, marker] right then. So
            # ctx.recent_turns here naturally contains only current-phase
            # history + the anchor turn. No per-agent slice needed.
            #
            # NB: the per-dispatch runtime messages (`<silence_ms>`,
            # state tags, `<think>verifier+tracker</think>`) are NO
            # LONGER appended here. The director persists them as Turns
            # in state.turns just before invoking start_turn (see
            # `director._persist_runtime_tags`), which means they ride
            # along inside ctx.recent_turns as part of conversation
            # history and survive into future dispatches at the same
            # chronological position. That's what keeps prefix KV-cache
            # stable as the conversation grows.
            messages = turns_to_messages(ctx.recent_turns)
        # FIRST-TURN GREETING: if there's no conversation history at all
        # (candidate just clicked Start, no turns yet, not a phase
        # transition), inject a single user-role <session_start/> message.
        # Without this, the slow LLM is called with an empty user-message
        # list and either errors out or produces a generic response that
        # skips the greeting entirely. The tag is documented in
        # system_prompt.md so the LLM knows to open with a warm greeting.
        if not messages:
            messages = [{
                "role": "user",
                "content": (
                    "<session_start/> The candidate just joined and clicked "
                    "Start. They are waiting silently to hear from you first."
                ),
            }]
        return messages
