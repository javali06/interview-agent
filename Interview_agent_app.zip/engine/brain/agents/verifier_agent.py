"""Answer verifier — fast LLM that classifies a candidate's STT into one of
six intents and emits a natural-language instruction for the slow LLM.

Why a fast classifier:
  - The slow LLM is good at generating the next interviewer turn but
    SLOW at picking up subtle conversational signals like "wait, can you
    repeat that?" Putting this work behind a 200-500ms fast call lets us
    route those cases (repeat, give-me-time, no-speech, off-topic) without
    putting the entire decision in the slow LLM's hands.
  - The instruction is appended to the slow LLM's system prompt BEFORE
    the tracker context, per the agreed prompt-composition order.

Public surface:
  VerifierAgent.verify(ctx) → VerifierResult
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Literal

from pydantic import BaseModel, Field

from engine.brain.contracts.session_state import Speaker
from engine.brain.core.conversation_context import ConversationContext
from engine.brain.llm.client import LLMClient, LLMRequest
from engine.brain.observability.langfuse_client import apply_llm_result, observe_llm
from engine.brain.observability.tracer import Tracer

from engine.brain.prompts import load as load_prompt

logger = logging.getLogger(__name__)


Intent = Literal[
    "answered",            # candidate fully addressed the CURRENT phase's question
    "default_answered",    # NOT emitted by the LLM — the Director/agent sets this
                           # when the verifier LLM errored/timed out. Treated
                           # IDENTICALLY to `answered` (acknowledge, proceed,
                           # pop the pool question) but tagged distinctly so a
                           # trace reviewer can see it was a fallback, not a
                           # real classification.
    "partial_answer",      # touched on the topic but shallow / vague / missing depth
    "not_applicable",      # reply is from / about a prior phase — slow LLM should
                           # redirect to the CURRENT phase's question
    "asked_to_repeat",     # "can you say that again"
    "asked_for_time",      # "give me a moment"
    "no_speech",           # silence / noise / non-speech transcript
    "off_topic",           # responded but on something unrelated (no phase fits)
    "clarifying_question", # asked back: "what do you mean by X?"
    "wrap_up_complete",    # ONLY meaningful in the terminal/wrap_up phase: the
                           # candidate has finished the closing exchange and the
                           # interview can end. Director uses this to shut down.
]
# NOTE: guardrail classification is NO LONGER a verifier intent. It moved to a
# dedicated fast agent (engine/brain/agents/guardrail_agent.py) run in parallel
# with the verifier. The verifier's tool used to carry a `reason` ENUM for the
# old `guardrail_triggered` intent, and Groq's structured decoding emitted that
# enum shape on EVERY call → pydantic validation failed → the verifier silently
# fell back to default_answered. Removing the enum here is the fix.
#
# NOTE: `partial_answer_skip` is NOT a verifier intent. The Director
# auto-promotes a `partial_answer` to "skip" semantics in code once the
# follow-up count exceeds the configured cap. The verifier has zero
# visibility into the cap and just emits `partial_answer` whenever the
# latest reply is materially short of the rubric.


class _VerifierToolInput(BaseModel):
    # The verifier LLM's ONLY job is to pick the flag (+ the structured
    # missing_tags). It does NOT write any free-text instruction —
    # the instruction the slow LLM receives is a CANNED per-intent template
    # (see _INSTRUCTION_TEMPLATES). Generating prose was the main source of
    # hallucination (it once echoed the tool description back as the
    # "instruction"), so we removed it.
    intent: Intent
    # For partial_answer on a SPECIFIC question: the EXACT coverage_tags the
    # reply did not address (verbatim copies). Empty otherwise.
    missing_tags: list[str] = Field(default_factory=list)
    confidence: float = Field(ge=0.0, le=1.0, default=0.8)


_VERIFIER_TOOL: dict[str, Any] = {
    "type": "function",
    "function": {
        "name": "classify_response",
        "description": (
            "Output the single intent flag that classifies the candidate's "
            "reply. For partial_answer on a question with coverage_tags, also "
            "list the unaddressed tags in `missing_tags`. Do NOT write any "
            "other free-text."
        ),
        "parameters": {
            "type": "object",
            "required": ["intent"],
            "properties": {
                "intent": {
                    "type": "string",
                    "enum": list(Intent.__args__),
                },
                "missing_tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": (
                        "For partial_answer ONLY: the EXACT coverage_tags from "
                        "the rubric the candidate's reply did NOT address (copy "
                        "the tag strings verbatim). Empty for every other "
                        "intent and when the answer covers all tags."
                    ),
                },
                "confidence": {
                    "type": "number",
                    "minimum": 0.0,
                    "maximum": 1.0,
                },
            },
        },
    },
}


# ── canned per-intent instructions (NOT LLM-generated) ────────────────────────
# The slow LLM's <think> "verifier note" is one of these fixed strings, chosen
# by the verifier's intent flag. partial_answer is built dynamically so the
# missing coverage tags can be embedded (specific phases) or a generic depth-
# probe used (generic phases). guardrail_triggered is handled entirely by the
# Director (scrub + canned re-ask), so it isn't here.
_INSTRUCTION_TEMPLATES: dict[str, str] = {
    "answered": (
        "Acknowledge the candidate's answer briefly and neutrally in your own "
        "words — do not comment on correctness, do not volunteer the answer. "
        "The tracker will hand you the next question."
    ),
    "default_answered": (
        "Acknowledge the candidate's reply briefly and move on to the next "
        "question for this phase."
    ),
    "not_applicable": (
        "The candidate is still on a prior phase's topic. Briefly acknowledge "
        "(a few words), then steer into the CURRENT phase's question."
    ),
    "asked_to_repeat": (
        "Restate your previous question clearly, in your own words. Do NOT "
        "move on to a new topic."
    ),
    "asked_for_time": (
        "Acknowledge gently that they can take a moment. Do NOT ask another "
        "question yet."
    ),
    "no_speech": (
        "The candidate didn't reply meaningfully. Gently acknowledge and offer "
        "to rephrase or move on. Do NOT volunteer or hint at the answer."
    ),
    "off_topic": (
        "Briefly acknowledge what they said, then steer back to the current "
        "phase's question."
    ),
    "clarifying_question": (
        "Restate the current question in plainer language. Do NOT give "
        "examples, hints, or any part of the answer."
    ),
    "wrap_up_complete": (
        "Deliver a short, warm final farewell line (≤10 words)."
    ),
}


def _instruction_for(intent: str, missing_tags: list[str]) -> str:
    """Map an intent flag (+ missing tags) to the canned slow-LLM instruction."""
    if intent == "partial_answer":
        if missing_tags:
            tags = ", ".join(missing_tags)
            return (
                f"The candidate's answer is incomplete — these concepts are "
                f"still missing: {tags}. Ask ONE single follow-up question "
                "that covers ALL of them together so they can address "
                "everything in one response. Do NOT re-ask what they already "
                "covered, stay neutral, and do not reveal or hint at the answer."
            )
        return (
            "The candidate's answer is shallow or vague. Ask ONE focused "
            "follow-up that pushes for the specific depth that's missing. "
            "Stay neutral; do not reveal or hint at the answer."
        )
    return _INSTRUCTION_TEMPLATES.get(
        intent, "Acknowledge the candidate's reply briefly and continue."
    )


@dataclass
class VerifierResult:
    intent: Intent
    instruction: str
    confidence: float
    latency_ms: int
    error: str | None = None
    # coverage_tags the candidate's reply didn't address (partial_answer only).
    missing_tags: list[str] = field(default_factory=list)


# ── default fall-back result, used on verifier-LLM failure ────────────


def _default_answered() -> VerifierResult:
    """On verifier failure (LLM error / timeout / bad output), fall back to
    `default_answered` — behaves exactly like `answered` (acknowledge,
    proceed, pop the pool question) so the conversation never stalls, but
    the distinct intent tag makes the fallback visible in traces."""
    return VerifierResult(
        intent="default_answered",
        instruction=_instruction_for("default_answered", []),
        confidence=0.0,
        latency_ms=0,
        error="default_fallback",
    )




class VerifierAgent:
    """Fast LLM classifier. One call per candidate STT delivery."""

    name = "verifier_agent"

    def __init__(
        self,
        *,
        llm: LLMClient,
        model: str = "llama-3.1-8b-instant",
        tracer: Tracer,
        timeout_s: float = 5.0,
    ) -> None:
        """The verifier ONLY judges the latest candidate reply's content
        quality vs the current phase / rubric — it does NOT enforce any
        follow-up cap. The Director counts consecutive `partial_answer`
        verdicts in code and auto-promotes the next one to
        `partial_answer_skip` once the cap is hit, so a strict
        guarantee is independent of LLM compliance.
        """
        self._llm = llm
        self._model = model
        self._tracer = tracer
        self._timeout_s = timeout_s

    async def verify(self, ctx: ConversationContext) -> VerifierResult:
        """Classify the most recent candidate turn and return an
        instruction string. On LLM failure / timeout / no candidate turn
        found, return the default 'answered' fallback."""
        last_cand = _find_last_candidate_text(ctx)
        if not last_cand:
            return VerifierResult(
                intent="no_speech",
                instruction=_instruction_for("no_speech", []),
                confidence=1.0, latency_ms=0,
            )

        # The verifier judges EXACTLY one exchange: the interviewer's most
        # recent question and the candidate's reply to it. We deliberately do
        # NOT feed the last-5-turns block — extra history was a source of
        # mis-classification (the model conflating earlier turns with the
        # current one). For specific phases the rubric below carries the
        # coverage_tags (or, on a follow-up, just the still-missing tags), which
        # is all the "what's left to cover" state the verifier needs.
        last_ai = _find_last_assistant_text(ctx)

        phase_section = ""
        if ctx.current_phase_descriptor:
            phase_section = (
                f"\n\nCurrent phase state (use this to judge phase-fit):\n"
                f"{ctx.current_phase_descriptor}\n"
            )
        rubric_section = ""
        if ctx.current_pool_question_rubric:
            rubric_section = (
                f"\n{ctx.current_pool_question_rubric}\n"
            )
        user_msg = (
            f"The interviewer asked:\n  {last_ai or '(question not recorded)'}\n\n"
            f"The candidate replied (classify THIS):\n  {last_cand}"
            f"{phase_section}"
            f"{rubric_section}\n"
            f"Output the intent flag via `classify_response`."
        )

        req = LLMRequest(
            system_prompt=load_prompt("verifier"),
            user_messages=[{"role": "user", "content": user_msg}],
            tools=[_VERIFIER_TOOL],
            tool_choice={"type": "function",
                         "function": {"name": "classify_response"}},
            model=self._model,
            temperature=0.1,
            max_tokens=200,
            parser=_VerifierToolInput,
        )

        phase = (
            ctx.current_phase_descriptor.split("\n", 1)[0]
            if ctx.current_phase_descriptor else None
        )
        # Emit llm_call_started BEFORE the API call so the admin trace
        # viewer's prompt drawer can show the exact system prompt + user
        # messages we sent. Mirrors the question_agent / filler_agent
        # pattern; event_viewer correlates the matching _completed /
        # _failed by agent name to wire prompts → response.
        system_prompt_text = load_prompt("verifier")
        user_messages_payload = [{"role": "user", "content": user_msg}]
        with observe_llm(
            agent=self.name, model=self._model,
            session_id=str(self._tracer.session_id),
            user_id=ctx.candidate_name, phase=phase,
            # Mirror question_agent: the Langfuse `input` is the EXACT system
            # prompt + user message we send (the user message already contains
            # the last-5-turns block, phase state, and rubric), so the trace
            # shows precisely what the verifier saw. The convenience fields
            # (candidate_reply / phase_descriptor) move to metadata so nothing
            # is lost but they don't shadow the real prompt.
            input_data={"system": system_prompt_text,
                        "messages": user_messages_payload},
            metadata={"rubric_present":
                      bool(ctx.current_pool_question_rubric),
                      "role": ctx.role,
                      "candidate_reply": last_cand,
                      "phase_descriptor": ctx.current_phase_descriptor},
            model_parameters={"temperature": 0.1, "max_tokens": 200,
                              "streaming": True, "timeout_s": self._timeout_s,
                              "tool_choice": "classify_response"},
        ) as lf_obs:
            self._tracer.event(
                "llm_call_started",
                agent=self.name, model=self._model,
                system_prompt=system_prompt_text,
                user_messages=user_messages_payload,
            )
            try:
                res = await asyncio.wait_for(
                    self._llm.complete_streaming(req, cancel_event=asyncio.Event()),
                    timeout=self._timeout_s,
                )
            except asyncio.TimeoutError:
                logger.warning(
                    "[VERIFIER] timeout after %.1fs — falling back to 'answered'",
                    self._timeout_s,
                )
                try:
                    lf_obs.update(
                        output={"intent": "answered", "fallback": "timeout"},
                        metadata={"timeout_s": self._timeout_s,
                                  "fallback_reason": "timeout"},
                        level="WARNING",
                        status_message=f"timeout after {self._timeout_s}s",
                    )
                except Exception:  # pragma: no cover
                    pass
                self._tracer.event(
                    "llm_call_failed",
                    agent=self.name, model=self._model,
                    reason="timeout",
                    error=f"timeout after {self._timeout_s}s",
                )
                return _default_answered()
            except Exception as e:
                logger.warning(
                    "[VERIFIER] error: %s — falling back to 'answered'", e,
                )
                try:
                    lf_obs.update(
                        output={"intent": "answered", "fallback": "error"},
                        metadata={"error": str(e)},
                        level="ERROR",
                        status_message=str(e)[:200],
                    )
                except Exception:  # pragma: no cover
                    pass
                self._tracer.event(
                    "llm_call_failed",
                    agent=self.name, model=self._model,
                    reason="transport_error",
                    error=str(e)[:200],
                )
                return _default_answered()

            # Salvage: llama-3.1-8b sometimes ignores the forced tool_choice and
            # emits the classification as JSON in the message body instead of a
            # `classify_response` tool call, leaving res.parsed None with no
            # error. Recover it from the content so the turn is still classified
            # rather than silently falling back to default_answered.
            parsed_obj: _VerifierToolInput | None = res.parsed  # type: ignore[assignment]
            if parsed_obj is None and not res.error:
                parsed_obj = _salvage_verifier_json(
                    getattr(res, "content_text", "") or "")
                if parsed_obj is not None:
                    logger.info(
                        "[VERIFIER] salvaged intent=%s from message body "
                        "(model skipped the tool call)", parsed_obj.intent,
                    )

            if res.error or parsed_obj is None:
                logger.warning(
                    "[VERIFIER] validation failed: %s — falling back to 'answered'",
                    res.error,
                )
                # The model DID respond and DID cost tokens — apply_llm_result
                # records that cost/usage to Langfuse + the local rollup. But
                # it only auto-marks level=ERROR when `res.error` is set; a pure
                # pydantic/tool-shape mismatch leaves res.error None, so the
                # generation would look successful. Mark it explicitly as a
                # degraded/failed attempt so it's filterable in Langfuse while
                # still carrying its cost.
                apply_llm_result(
                    lf_obs, res,
                    output={"intent": "answered", "fallback": "validation"},
                    extra_metadata={"fallback_reason": "validation",
                                    "phase": phase},
                    session_id=str(self._tracer.session_id),
                )
                if not res.error:
                    try:
                        lf_obs.update(
                            level="WARNING",
                            status_message="output validation failed — used "
                                           "'answered' fallback",
                        )
                    except Exception:  # pragma: no cover
                        pass
                self._tracer.event(
                    "llm_call_failed",
                    agent=self.name, model=self._model,
                    reason="validation_or_error",
                    error=str(res.error)[:200] if res.error else "parsed=None",
                    latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
                    tokens_in=res.tokens_in, tokens_out=res.tokens_out,
                    tokens_in_cached=res.tokens_in_cached,
                    tokens_in_cache_write=res.tokens_in_cache_write,
                    cost_usd=res.cost_usd, generation_id=res.generation_id,
                )
                return _default_answered()

            parsed: _VerifierToolInput = parsed_obj  # type: ignore[assignment]
            # The slow-LLM instruction is CANNED, chosen by the flag (+ missing
            # tags) — the verifier LLM never wrote prose, so it can't hallucinate
            # it.
            parsed_missing = list(parsed.missing_tags or [])
            instruction = _instruction_for(parsed.intent, parsed_missing)
            apply_llm_result(
                lf_obs, res,
                output={
                    "intent": parsed.intent,
                    "missing_tags": parsed_missing,
                    "confidence": parsed.confidence,
                },
                extra_metadata={"phase": phase},
                session_id=str(self._tracer.session_id),
            )
            # Trace-level score so the per-session aggregate in Langfuse
            # shows verifier confidence over time.
            try:
                lf_obs.score(  # type: ignore[attr-defined]
                    name="verifier_confidence",
                    value=float(parsed.confidence),
                    data_type="NUMERIC",
                )
                lf_obs.score(  # type: ignore[attr-defined]
                    name="verifier_intent",
                    value=parsed.intent,
                    data_type="CATEGORICAL",
                )
            except Exception:  # pragma: no cover
                pass
            langfuse_trace_id = getattr(lf_obs, "trace_id", None)
        # Stringify the tool-call response so the admin's prompt drawer
        # has a meaningful "response" pane. The verifier doesn't emit
        # free text — its "output" is the structured classification.
        import json as _json
        response_text_serialized = _json.dumps(
            {
                "intent": parsed.intent,
                "missing_tags": parsed_missing,
                "confidence": parsed.confidence,
                "canned_instruction": instruction,
            },
            indent=2,
        )
        self._tracer.event(
            "llm_call_completed",
            agent=self.name, model=self._model,
            response_text=response_text_serialized,
            latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
            tokens_in=res.tokens_in, tokens_out=res.tokens_out,
            tokens_in_cached=res.tokens_in_cached,
            tokens_in_cache_write=res.tokens_in_cache_write,
            tokens_out_reasoning=res.tokens_out_reasoning,
            cost_usd=res.cost_usd, generation_id=res.generation_id,
            langfuse_trace_id=langfuse_trace_id,
        )
        self._tracer.event(
            "verifier_classified",
            agent=self.name,
            intent=parsed.intent,
            confidence=parsed.confidence,
            instruction=instruction,
            missing_tags=parsed_missing,
            latency_ms=res.latency_ms, ttft_ms=res.ttft_ms,
            tokens_in=res.tokens_in, tokens_out=res.tokens_out,
            tokens_in_cached=res.tokens_in_cached,
            tokens_in_cache_write=res.tokens_in_cache_write,
            tokens_out_reasoning=res.tokens_out_reasoning,
            cost_usd=res.cost_usd, generation_id=res.generation_id,
            candidate_text_preview=last_cand[:80],
            model=self._model,
            langfuse_trace_id=langfuse_trace_id,
        )
        # Guardrail trips are now classified + emitted by the dedicated
        # GuardrailAgent (engine/brain/agents/guardrail_agent.py), which the
        # Director runs in parallel with this verifier. The verifier no longer
        # has any guardrail intent or GUARDRAIL_TRIGGERED emission.
        logger.info(
            "[VERIFIER] intent=%s conf=%.2f latency=%dms",
            parsed.intent, parsed.confidence, res.latency_ms,
        )
        return VerifierResult(
            intent=parsed.intent,
            instruction=instruction,
            confidence=parsed.confidence,
            latency_ms=res.latency_ms,
            missing_tags=parsed_missing,
        )


# ── helpers ───────────────────────────────────────────────────────────


def _salvage_verifier_json(text: str) -> _VerifierToolInput | None:
    """Recover a classify_response payload from the model's message body.

    Small models occasionally answer in prose/JSON instead of calling the
    forced tool. We scan the content for the first JSON object that has an
    `intent` field and validate it against the tool schema. Returns None if
    nothing usable is found (caller then uses the default_answered fallback).
    """
    if not text:
        return None
    import json
    import re
    # First {...} block (the schema has no nested objects — arrays are fine).
    for candidate in re.findall(r"\{[^{}]*\}", text, re.DOTALL):
        try:
            obj = json.loads(candidate)
        except Exception:
            continue
        if isinstance(obj, dict) and obj.get("intent"):
            try:
                return _VerifierToolInput.model_validate(obj)
            except Exception:
                continue
    return None


def _find_last_assistant_text(ctx: ConversationContext) -> str:
    """The interviewer's most recent spoken turn — the question the candidate
    is replying to. Skips phase-marker (UNKNOWN-speaker) turns; returns the
    raw AI text (it's what the candidate heard)."""
    for t in reversed(ctx.recent_turns):
        sp = t.speaker.value if hasattr(t.speaker, "value") else t.speaker
        if sp == Speaker.AI.value:
            return (t.text or "").strip()
    return ""


def _find_last_candidate_text(ctx: ConversationContext) -> str:
    for t in reversed(ctx.recent_turns):
        sp = t.speaker.value if hasattr(t.speaker, "value") else t.speaker
        if sp == Speaker.CANDIDATE.value:
            return (t.text or "").strip()
    return ""


