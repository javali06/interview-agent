"""ApologyAgent — recovery line when the slow LLM stalls.

Two modes:
  - `generate()` (preferred): the fast LLM writes a context-aware recovery
    line from the last few turns — apologises for OUR delay and asks the
    candidate to repeat their answer (restating the question if it's clear
    from history). This is the escalation tier the LatencyOrchestrator fires
    at `apology_threshold_ms` after cancelling the stuck slow LLM.
  - `pick()` (fallback / no-LLM): a canned phrase from apology_phrases.yaml.

The fast LLM call is plain-text streaming (no tool calls) — the slow LLM
proved plain text is far more reliable than forcing weak models through a
tool-call schema. On ANY failure we fall back to a canned repeat-request
phrase so the recovery never silently no-ops.
"""
from __future__ import annotations

import asyncio
import logging
import random
from dataclasses import dataclass
from typing import Callable

from engine.brain.core.conversation_context import (
    ConversationContext,
    turns_to_messages,
)
from engine.brain.llm.client import LLMClient, LLMRequest
from engine.brain.observability.langfuse_client import (
    apply_llm_result,
    observe_llm,
)
from engine.brain.observability.timing import log_timing
from engine.brain.observability.tracer import Tracer
from engine.brain.prompts import get_phrases, load as load_prompt

logger = logging.getLogger(__name__)

# Last-ditch fallback if the phrase bank can't be read.
_REPEAT_FALLBACK = "Sorry, I think I glitched for a second there — could you say that again?"


def _load_bank() -> dict[str, list[str]]:
    try:
        return get_phrases("apology_phrases")
    except Exception as e:  # pragma: no cover
        logger.warning("apology phrase load failed: %s", e)
        return {}


@dataclass
class ApologyResult:
    text: str
    used_canned: bool
    cancelled: bool = False
    latency_ms: int = 0
    tokens_in: int | None = None
    tokens_out: int | None = None
    model: str | None = None


class ApologyAgent:
    name = "apology_agent"

    def __init__(
        self,
        *,
        tracer: Tracer,
        llm: LLMClient | None = None,
        model: str = "",
        max_tokens: int = 80,
        temperature: float = 0.6,
    ) -> None:
        self._tracer = tracer
        self._bank = _load_bank()
        self._llm = llm
        self._model = model
        self._max_tokens = max_tokens
        self._temperature = temperature

    def pick(
        self,
        *,
        kind: str = "generic",
        last_candidate_turn_words: int = 0,
        topic_hint: str = "",
    ) -> str:
        """Return a canned phrase. `kind` ∈ {generic,
        after_long_candidate_answer, after_technical_answer,
        protected_response_open, monologue_backchannel, repeat_request}."""
        if kind == "generic" and last_candidate_turn_words >= 35:
            kind = "after_long_candidate_answer"
        if kind == "generic" and any(
            w in topic_hint.lower() for w in ("kafka", "redis", "k8s", "queue", "system")
        ):
            kind = "after_technical_answer"

        bank = self._bank.get(kind) or self._bank.get("generic") or [_REPEAT_FALLBACK]
        return random.choice(bank)

    def _canned_repeat(self) -> str:
        bank = self._bank.get("repeat_request") or [_REPEAT_FALLBACK]
        return random.choice(bank)

    async def generate(
        self,
        ctx: ConversationContext,
        *,
        on_utterance_char: Callable[[str], None],
        on_first_token: Callable[[], None],
        cancel_event: asyncio.Event,
    ) -> ApologyResult:
        """Generate a context-aware recovery apology via the fast LLM, using
        the last 5 turns as history. Streams chars to `on_utterance_char` for
        TTS. Falls back to a canned repeat-request phrase if the LLM is
        unavailable, errors, is cancelled, or returns empty."""
        # No LLM configured (e.g. canned-filler mode) → canned recovery.
        if self._llm is None:
            text = self._canned_repeat()
            on_first_token()
            for c in text:
                on_utterance_char(c)
            self._tracer.event(
                "apology_dispatched", agent=self.name, model="canned",
                response_text=text, used_canned=True,
            )
            return ApologyResult(text=text, used_canned=True, model="canned")

        system = load_prompt("apology_prompt")
        messages = turns_to_messages(ctx.recent_turns, limit=5)
        req = LLMRequest(
            system_prompt=system,
            user_messages=messages,
            tools=[],
            tool_choice=None,
            model=self._model,
            temperature=self._temperature,
            max_tokens=self._max_tokens,
            parser=None,
        )

        self._tracer.event(
            "llm_call_started", agent=self.name, model=self._model,
            system_prompt=system, user_messages=messages,
        )
        log_timing(logger, "LLM-fast", "apology dispatched", None, model=self._model)

        buf: list[str] = []

        def _on_char(c: str) -> None:
            buf.append(c)
            on_utterance_char(c)

        try:
            with observe_llm(
                agent=self.name,
                model=self._model,
                session_id=str(self._tracer.session_id),
                user_id=ctx.candidate_name,
                phase=ctx.phase,
                input_data={"system": system, "messages": messages},
                metadata={"user_prompt_chars": sum(len(m.get("content", "")) for m in messages),
                          "role": ctx.role},
                model_parameters={"temperature": self._temperature,
                                  "max_tokens": self._max_tokens,
                                  "streaming": True},
            ) as lf_obs:
                res = await self._llm.complete_text_streaming(
                    req,
                    on_utterance_char=_on_char,
                    on_first_token=on_first_token,
                    cancel_event=cancel_event,
                )
                if res is not None:
                    apply_llm_result(
                        lf_obs, res,
                        output={"text": res.text_streamed or "".join(buf)},
                        session_id=str(self._tracer.session_id),
                    )
        except asyncio.CancelledError:
            raise
        except Exception as e:
            logger.warning("[APOLOGY] fast LLM call raised (%s) — using canned", e)
            res = None

        text = ((res.text_streamed if res else "") or "".join(buf)).strip()

        if res is not None and res.cancelled:
            self._tracer.event(
                "apology_dispatched", agent=self.name, model=self._model,
                response_text=text, cancelled=True,
            )
            return ApologyResult(
                text=text, used_canned=False, cancelled=True,
                latency_ms=res.latency_ms, model=self._model,
                tokens_in=res.tokens_in, tokens_out=res.tokens_out,
            )

        if res is None or res.error or not text:
            # The fast LLM failed or returned nothing AND streamed nothing.
            # If chars already reached TTS we keep them; otherwise emit a
            # canned line so the candidate hears a recovery.
            if not buf:
                text = self._canned_repeat()
                on_first_token()
                for c in text:
                    on_utterance_char(c)
            self._tracer.event(
                "apology_dispatched", agent=self.name,
                model=self._model or "canned", response_text=text,
                used_canned=True, error=(res.error if res else "exception"),
            )
            return ApologyResult(
                text=text, used_canned=True,
                latency_ms=(res.latency_ms if res else 0), model=self._model,
            )

        log_timing(logger, "LLM-fast", "apology completed", res.latency_ms,
                   model=self._model, tokens_out=res.tokens_out or 0)
        self._tracer.event(
            "apology_dispatched", agent=self.name, model=self._model,
            response_text=text, used_canned=False,
            latency_ms=res.latency_ms, tokens_in=res.tokens_in,
            tokens_out=res.tokens_out,
        )
        return ApologyResult(
            text=text, used_canned=False, latency_ms=res.latency_ms,
            model=self._model, tokens_in=res.tokens_in, tokens_out=res.tokens_out,
        )
