"""Model registry + cost calculator.

Reads config/llm_models.yaml once per process and exposes:

  - `compute_cost(model, *, tokens_in, tokens_out, tokens_cached=0,
                  tokens_cache_write=0)`
      Returns a `CostBreakdown(input, output, cache_read, cache_write,
      total)` in USD, or None if the model is unknown. Uses the YAML's
      provider-specific cache multipliers so cached tokens are billed at
      the discounted rate, not the full input rate.
  - `model_metadata(model)`  → context_window / max_output_tokens / provider
  - `known_models()`         → sorted list of registered model ids
  - `resolve_alias(model)`   → canonical model id (follows alias_of chain)

DESIGN NOTES

1. *Source of truth*. OpenRouter's `usage-include` opt-in returns the
   provider's own USD cost in the streaming response; that ALWAYS wins.
   `compute_cost()` is only the fallback for upstreams that don't return
   cost (Groq direct, plain-OpenAI direct, anything BYOK without
   OpenRouter relay).

2. *Cache billing*. Providers have very different cache pricing:
     - OpenAI   : cache_write free, cache_read 0.50x input
     - Anthropic: cache_write 1.25x input, cache_read 0.10x input
     - DeepSeek : cache_write 1.0x  input, cache_read 0.10x input
     - Llama on Groq: no discount documented yet (1.0x both)
   The YAML stores the per-model `cache_read` / `cache_write` rates
   directly in USD/M so the math is provider-neutral here.

3. *Tokens accounting (avoid double-counting)*. OpenRouter's usage block
   reports `prompt_tokens` as the TOTAL prompt size INCLUDING cached
   tokens. So:
       fresh_input = tokens_in - tokens_cached - tokens_cache_write
       cost.input        = fresh_input    × rate.input
       cost.cache_read   = tokens_cached  × rate.cache_read
       cost.cache_write  = tokens_cache_write × rate.cache_write
   The breakdown sums to the same total as the naive "tokens_in × input"
   only when both cached counts are 0.

4. *Unknown model fallback*. Calling `compute_cost()` on a model not in
   the YAML logs a one-time warning per model id and returns None.
   Callers handle None as "cost not estimable" without crashing.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# ── module-level cache ────────────────────────────────────────────────
_registry: dict[str, Any] | None = None
_unknown_models_warned: set[str] = set()


def _default_yaml_path() -> Path:
    """Resolve config/llm_models.yaml relative to the repo root.

    The repo layout puts `config/` at the same level as `stream_b_new/`,
    so we walk up from this file (`stream_b_new/llm/pricing.py`) two
    levels. An explicit LLM_MODELS_YAML env var overrides for tests."""
    env = os.environ.get("LLM_MODELS_YAML")
    if env:
        return Path(env)
    return Path(__file__).resolve().parents[3] / "config" / "llm_models.yaml"


def _load_registry() -> dict[str, Any]:
    """Read llm_models.yaml once and cache. PyYAML is already a project
    dep (used elsewhere for cadence YAML). On parse failure we log and
    return an empty registry rather than crashing the interview."""
    global _registry
    if _registry is not None:
        return _registry
    path = _default_yaml_path()
    try:
        import yaml
    except ImportError:  # pragma: no cover — pyyaml is in pyproject
        logger.warning("PyYAML not installed; LLM pricing disabled")
        _registry = {"models": {}, "defaults": {}, "speech": {}}
        return _registry
    if not path.exists():
        logger.warning("llm_models.yaml not found at %s — pricing disabled", path)
        _registry = {"models": {}, "defaults": {}, "speech": {}}
        return _registry
    try:
        with path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
    except Exception as e:
        logger.warning("failed to parse %s (%s) — pricing disabled", path, e)
        _registry = {"models": {}, "defaults": {}, "speech": {}}
        return _registry
    _registry = data
    return _registry


def reload_registry() -> None:
    """Forget the cached YAML so the next call re-reads the file.
    Useful in tests and when an operator edits llm_models.yaml at
    runtime via the admin UI."""
    global _registry, _unknown_models_warned
    _registry = None
    _unknown_models_warned = set()


# ── public API ────────────────────────────────────────────────────────


def resolve_alias(model: str) -> str:
    """Follow the `alias_of` chain to the canonical model id. Returns
    the input string unchanged if no alias is registered. Aliases more
    than one hop deep are honoured (capped at 4 hops as a cycle guard)."""
    reg = _load_registry()
    models = reg.get("models") or {}
    seen: set[str] = set()
    current = model
    for _ in range(4):
        if current in seen:
            return current  # cycle — break out with whatever we have
        seen.add(current)
        entry = models.get(current)
        if not entry:
            return current
        alias = entry.get("alias_of")
        if not alias:
            return current
        current = alias
    return current


def known_models() -> list[str]:
    reg = _load_registry()
    models = (reg.get("models") or {}).keys()
    return sorted(models)


def model_metadata(model: str) -> dict[str, Any] | None:
    """Return the merged entry for `model` (defaults + per-model
    overrides + resolved alias). None for unknown models."""
    reg = _load_registry()
    canonical = resolve_alias(model)
    entry = (reg.get("models") or {}).get(canonical)
    if entry is None:
        return None
    defaults = reg.get("defaults") or {}
    merged: dict[str, Any] = {
        "context_window": entry.get(
            "context_window", defaults.get("context_window")
        ),
        "max_output_tokens": entry.get(
            "max_output_tokens", defaults.get("max_output_tokens")
        ),
        "provider": entry.get("provider", "unknown"),
        "notes": entry.get("notes"),
        "canonical_model": canonical,
    }
    pricing = dict(defaults.get("pricing_usd_per_million") or {})
    pricing.update(entry.get("pricing_usd_per_million") or {})
    merged["pricing_usd_per_million"] = pricing
    return merged


@dataclass
class CostBreakdown:
    """USD cost split by usage class. `total` is the sum of the other
    four — kept explicit so callers don't have to recompute it and so
    Langfuse `cost_details` can pass either the breakdown or the total
    without divergence."""
    input: float
    output: float
    cache_read: float
    cache_write: float
    total: float

    def as_langfuse_cost_details(self) -> dict[str, float]:
        """Map to Langfuse's `cost_details` shape. We expose four keys
        plus `total` so the UI's cost breakdown shows the cache split
        explicitly (otherwise cache savings are invisible)."""
        return {
            "input": round(self.input, 8),
            "output": round(self.output, 8),
            "cache_read": round(self.cache_read, 8),
            "cache_write": round(self.cache_write, 8),
            "total": round(self.total, 8),
        }


def compute_cost(
    model: str,
    *,
    tokens_in: int | None,
    tokens_out: int | None,
    tokens_cached: int | None = 0,
    tokens_cache_write: int | None = 0,
) -> CostBreakdown | None:
    """Return per-component USD cost for one LLM call. None if the
    model isn't in the YAML.

    `tokens_in` is OpenAI/OpenRouter's `prompt_tokens` — the FULL prompt
    size including cached + cache-write tokens. We subtract those out
    to get the "fresh" portion that gets billed at the input rate.
    """
    md = model_metadata(model)
    if md is None:
        if model not in _unknown_models_warned:
            _unknown_models_warned.add(model)
            logger.info(
                "[pricing] unknown model %r — cost will be reported as None. "
                "Add it to config/llm_models.yaml.", model,
            )
        return None

    rates: dict[str, float | None] = md["pricing_usd_per_million"]
    rate_in = float(rates.get("input") or 0.0)
    rate_out = float(rates.get("output") or 0.0)
    # `cache_read` / `cache_write` may be None → fall back to input rate
    # ("no discount" semantics).
    rate_cr = rates.get("cache_read")
    rate_cw = rates.get("cache_write")
    rate_cr = float(rate_cr) if rate_cr is not None else rate_in
    rate_cw = float(rate_cw) if rate_cw is not None else rate_in

    tin = int(tokens_in or 0)
    tout = int(tokens_out or 0)
    tcr = int(tokens_cached or 0)
    tcw = int(tokens_cache_write or 0)

    fresh = max(tin - tcr - tcw, 0)
    input_cost = fresh * rate_in / 1_000_000
    output_cost = tout * rate_out / 1_000_000
    cache_read_cost = tcr * rate_cr / 1_000_000
    cache_write_cost = tcw * rate_cw / 1_000_000
    total = input_cost + output_cost + cache_read_cost + cache_write_cost
    return CostBreakdown(
        input=input_cost,
        output=output_cost,
        cache_read=cache_read_cost,
        cache_write=cache_write_cost,
        total=total,
    )


def estimate_total_usd(
    model: str,
    *,
    tokens_in: int | None,
    tokens_out: int | None,
    tokens_cached: int | None = 0,
    tokens_cache_write: int | None = 0,
) -> float | None:
    """Convenience wrapper — returns just the total USD or None."""
    bd = compute_cost(
        model,
        tokens_in=tokens_in,
        tokens_out=tokens_out,
        tokens_cached=tokens_cached,
        tokens_cache_write=tokens_cache_write,
    )
    return None if bd is None else bd.total


# ── Speech (STT / TTS) unit pricing ───────────────────────────────────


_DEFAULT_SPEECH_RATES: dict[str, dict[str, float]] = {
    # Authoritative defaults if the `speech:` block is missing from the
    # YAML. Match the published Azure rates we've been using.
    "azure-speech-stt": {"rate_usd_per_audio_hour": 1.0},
    "azure-speech-tts-neural": {"rate_usd_per_million_chars": 16.0},
}


def get_speech_rate(unit_id: str) -> dict[str, float]:
    """Return the rate block for a speech unit (STT/TTS) from the YAML's
    `speech:` section, falling back to a sane built-in if the YAML is
    missing the entry. Callers read whichever rate key applies:
        get_speech_rate("azure-speech-stt")["rate_usd_per_audio_hour"]
        get_speech_rate("azure-speech-tts-neural")["rate_usd_per_million_chars"]
    """
    reg = _load_registry()
    speech = reg.get("speech") or {}
    entry = speech.get(unit_id)
    if entry is None:
        return dict(_DEFAULT_SPEECH_RATES.get(unit_id, {}))
    rates = {k: float(v) for k, v in entry.items()
             if k.startswith("rate_") and isinstance(v, (int, float))}
    # Backfill from defaults so callers always get the expected key.
    for k, v in _DEFAULT_SPEECH_RATES.get(unit_id, {}).items():
        rates.setdefault(k, v)
    return rates


def stt_usd_per_audio_ms(unit_id: str = "azure-speech-stt") -> float:
    """Per-millisecond STT cost (yaml `rate_usd_per_audio_hour` ÷ 3.6M)."""
    return get_speech_rate(unit_id).get("rate_usd_per_audio_hour", 1.0) / 3_600_000


def tts_usd_per_char(unit_id: str = "azure-speech-tts-neural") -> float:
    """Per-character TTS cost (yaml `rate_usd_per_million_chars` ÷ 1M)."""
    return get_speech_rate(unit_id).get("rate_usd_per_million_chars", 16.0) / 1_000_000
