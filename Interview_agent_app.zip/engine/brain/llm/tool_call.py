"""Streaming tool-call parser.

The LLM responds via a `respond` (or other) tool call. The arguments are
streamed JSON. We need the `utterance` field's value characters out as soon
as they arrive — every additional character is +6.5ms of TTS latency at
Kokoro's ~150 chars/s.

`UtteranceExtractor` is a tiny state machine over JSON chars — borrowed
from v1 (`stream_b/services/agent/llm_client.py::UtteranceExtractor`). It
handles escapes and \\uXXXX sequences. Every char of the utterance value is
piped to `on_char` exactly once, in order.
"""
from __future__ import annotations

from typing import Callable

_MARK = '"utterance"'
_ESCAPES = {
    '"': '"', "\\": "\\", "/": "/",
    "n": "\n", "t": "\t", "r": "\r", "b": "\b", "f": "\f",
}


class UtteranceExtractor:
    """Stream the value of the JSON string field `utterance`."""

    def __init__(self, on_char: Callable[[str], None]):
        self._on_char = on_char
        self._buf = ""
        self._mode = "SEARCH"            # SEARCH | AFTER_KEY | IN_VALUE | DONE
        self._escape = False
        self._unicode_hex = ""

    @property
    def done(self) -> bool:
        return self._mode == "DONE"

    def feed(self, chunk: str) -> None:
        for ch in chunk:
            self._step(ch)

    def _step(self, ch: str) -> None:
        if self._mode == "DONE":
            return
        if self._mode == "SEARCH":
            self._buf += ch
            idx = self._buf.find(_MARK)
            if idx < 0:
                return
            tail = self._buf[idx + len(_MARK):]
            self._buf = ""
            self._mode = "AFTER_KEY"
            for t in tail:
                self._step(t)
            return
        if self._mode == "AFTER_KEY":
            if ch in " \t\n\r" or ch == ":":
                return
            if ch == '"':
                self._mode = "IN_VALUE"
                return
            self._mode = "DONE"
            return
        # IN_VALUE
        if self._unicode_hex != "" or (self._escape and ch == "u"):
            if self._escape and ch == "u":
                self._escape = False
                self._unicode_hex = " "
                return
            self._unicode_hex += ch
            if len(self._unicode_hex) == 5:
                hex_str = self._unicode_hex[1:]
                self._unicode_hex = ""
                try:
                    self._on_char(chr(int(hex_str, 16)))
                except ValueError:
                    pass
            return
        if self._escape:
            self._on_char(_ESCAPES.get(ch, ch))
            self._escape = False
            return
        if ch == "\\":
            self._escape = True
            return
        if ch == '"':
            self._mode = "DONE"
            return
        self._on_char(ch)
