"""Provider-aware streaming LLM client.

NEW_STREAM_B.md §6.2 / §8D.3. Wraps OpenRouter (OpenAI-compat schema). One
client instance can be configured for "slow" (DeepSeek-V3.2) or "fast"
(`gpt-4o-mini`) work. Streaming: the `utterance` field's chars are piped to
`on_utterance_char` as they arrive — that's the latency lever.

Tool calls only. We force `tool_choice="required"` and validate the produced
arguments against the caller-provided Pydantic model. On validation failure,
caller may retry with an instruction-correction message (NEW_STREAM_B.md §8D.1).
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Type, TypeVar

from openai import AsyncOpenAI
from pydantic import BaseModel, ValidationError

from engine.brain.llm.tool_call import UtteranceExtractor

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)


def _llm_key_id(api_key: str, base_url: str) -> str:
    """Stable, NON-SECRET id for an LLM API key, safe as a Prometheus label.

    Multiple shards share the same key, so per-key concurrency must merge across
    shards (Prometheus `sum by (key_id)`). We identify the key by provider (from
    the base_url) + a short hash of the key — enough to tell distinct keys apart
    for the dashboard WITHOUT ever exposing the secret."""
    bl = (base_url or "").lower()
    if "openrouter" in bl:
        prov = "openrouter"
    elif "groq" in bl:
        prov = "groq"
    elif "openai" in bl:
        prov = "openai"
    else:
        prov = "llm"
    h = hashlib.sha256((api_key or "").encode()).hexdigest()[:6]
    return f"{prov}-{h}"


# OpenRouter usage-accounting opt-in. Adding `{"usage": {"include": true}}`
# to the request body makes the LAST streaming chunk carry a full
# `ResponseUsage` object: prompt/completion/total tokens, cost in USD,
# `prompt_tokens_details.cached_tokens` and
# `completion_tokens_details.reasoning_tokens`. Without this opt-in the
# stream still carries token counts but `cost` is omitted, forcing a
# second round-trip to `/api/v1/generation` per call. See
# https://openrouter.ai/docs/cookbook/administration/usage-accounting.
_OPENROUTER_USAGE_INCLUDE = {"usage": {"include": True}}


@dataclass
class LLMRequest:
    system_prompt: str
    user_messages: list[dict[str, str]]      # [{role, content}, ...]
    tools: list[dict[str, Any]]
    tool_choice: str | dict | None = "required"
    model: str = "deepseek/deepseek-v3.2"
    temperature: float = 0.4
    max_tokens: int = 800
    parser: Type[BaseModel] | None = None     # Pydantic model for validating args
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class LLMCallResult:
    tool_name: str
    tool_arguments_raw: str                   # full JSON string
    parsed: BaseModel | None                  # validated against `parser`
    text_streamed: str                        # the `utterance` chars we piped out
    model: str
    tokens_in: int | None
    tokens_out: int | None
    latency_ms: int
    ttft_ms: int | None
    cancelled: bool = False
    error: str | None = None
    # ── full OpenRouter usage accounting (populated when the provider
    # returns a `usage` block in the final SSE chunk) ─────────────────
    tokens_total: int | None = None
    tokens_in_cached: int | None = None        # prompt_tokens_details.cached_tokens
    tokens_in_cache_write: int | None = None   # prompt_tokens_details.cache_write_tokens
    tokens_out_reasoning: int | None = None    # completion_tokens_details.reasoning_tokens
    cost_usd: float | None = None              # total cost from OpenRouter
    cost_prompt_usd: float | None = None       # cost_details.upstream_inference_prompt_cost
    cost_completion_usd: float | None = None   # cost_details.upstream_inference_completions_cost
    generation_id: str | None = None           # OpenRouter generation id (for /api/v1/generation lookups)
    completion_start_time: datetime | None = None  # UTC time of the first response token
    content_text: str = ""                      # message-body content (non-tool-call); used to
                                                # salvage a classification when a small model
                                                # ignores forced tool_choice and answers in prose


def _coerce_float(v: Any) -> float | None:
    """Defensive cast — OpenRouter usage fields arrive as numbers but the
    OpenAI SDK occasionally surfaces them as model objects with `.value`
    attributes depending on schema drift. Cheap belt-and-braces."""
    if v is None:
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _coerce_int(v: Any) -> int | None:
    if v is None:
        return None
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _extract_openrouter_usage(usage: Any) -> dict[str, Any]:
    """Flatten an OpenRouter `usage` object (or dict) into the LLMCallResult
    field names we expose.

    Mirrors the schema documented at
    https://openrouter.ai/docs/api/reference/overview ("ResponseUsage").
    Returns only fields the upstream actually populated — keeps None
    values out so the caller can use `dict.update(...)` cleanly.

    Accepts either the OpenAI-SDK object form (`usage.cost`,
    `usage.prompt_tokens_details.cached_tokens`) or a plain dict; the
    OpenAI Python SDK returns Pydantic models but additional fields the
    SDK doesn't model land in `model_extra` / `__pydantic_extra__`.
    Helper getter `_get` handles both."""
    if usage is None:
        return {}

    def _get(obj: Any, key: str) -> Any:
        if obj is None:
            return None
        if isinstance(obj, dict):
            return obj.get(key)
        # OpenAI SDK BaseModel: try attribute, then model_extra.
        v = getattr(obj, key, None)
        if v is not None:
            return v
        extra = getattr(obj, "model_extra", None) or getattr(
            obj, "__pydantic_extra__", None
        )
        if isinstance(extra, dict):
            return extra.get(key)
        return None

    prompt_details = _get(usage, "prompt_tokens_details")
    completion_details = _get(usage, "completion_tokens_details")
    cost_details = _get(usage, "cost_details")

    out: dict[str, Any] = {}
    tokens_in = _coerce_int(_get(usage, "prompt_tokens"))
    tokens_out = _coerce_int(_get(usage, "completion_tokens"))
    tokens_total = _coerce_int(_get(usage, "total_tokens"))
    cost_usd = _coerce_float(_get(usage, "cost"))
    tokens_in_cached = _coerce_int(_get(prompt_details, "cached_tokens"))
    tokens_in_cache_write = _coerce_int(_get(prompt_details, "cache_write_tokens"))
    tokens_out_reasoning = _coerce_int(_get(completion_details, "reasoning_tokens"))
    cost_prompt = _coerce_float(
        _get(cost_details, "upstream_inference_prompt_cost")
    )
    cost_completion = _coerce_float(
        _get(cost_details, "upstream_inference_completions_cost")
    )

    if tokens_in is not None:
        out["tokens_in"] = tokens_in
    if tokens_out is not None:
        out["tokens_out"] = tokens_out
    if tokens_total is not None:
        out["tokens_total"] = tokens_total
    if tokens_in_cached is not None:
        out["tokens_in_cached"] = tokens_in_cached
    if tokens_in_cache_write is not None:
        out["tokens_in_cache_write"] = tokens_in_cache_write
    if tokens_out_reasoning is not None:
        out["tokens_out_reasoning"] = tokens_out_reasoning
    if cost_usd is not None:
        out["cost_usd"] = cost_usd
    if cost_prompt is not None:
        out["cost_prompt_usd"] = cost_prompt
    if cost_completion is not None:
        out["cost_completion_usd"] = cost_completion
    return out


class LLMClient:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "https://openrouter.ai/api/v1",
        client: AsyncOpenAI | None = None,
        default_extra_body: dict[str, Any] | None = None,
        tier: str = "",
    ) -> None:
        self._client = client or AsyncOpenAI(api_key=api_key, base_url=base_url)
        # Model tier this client serves ("fast" / "slow") — the only label on the
        # chokepoint LLM latency metrics, so latency is attributed per-model
        # without any per-agent wiring.
        self._tier = tier
        # Non-secret id of the API key this client uses, for the per-key
        # in-flight gauge (shards sharing a key merge in Prometheus).
        self._key_id = _llm_key_id(api_key, base_url)
        # Merged into every request's `extra_body`. Used to attach
        # OpenRouter provider-routing hints (e.g. {"provider": {"order":
        # ["Groq"]}}) once at construction so callers don't repeat it on
        # every LLMRequest. Per-request `extra["extra_body"]` keys win
        # over these defaults.
        self._default_extra_body: dict[str, Any] = default_extra_body or {}

    def _observe_call(self, ttft_ms: int | None, latency_ms: int | None,
                      model: str = "") -> None:
        """Record request→first-token and request→completion latency for THIS
        call at the client chokepoint — so EVERY LLM call (any agent) is timed,
        labeled by tier (fast/slow) + the actual model name. Guarded: metrics
        never break a call."""
        try:
            from engine.brain.observability.prom import LLM_LATENCY_MS, LLM_TTFT_MS
            tier = self._tier or "unknown"
            mdl = model or "unknown"
            if ttft_ms is not None:
                LLM_TTFT_MS.labels(tier=tier, model=mdl).observe(float(ttft_ms))
            if latency_ms is not None:
                LLM_LATENCY_MS.labels(tier=tier, model=mdl).observe(float(latency_ms))
        except Exception:
            pass

    def _note_error(self, e: object) -> None:
        """If a call failed with an upstream 429/throttle, count it against THIS
        client's key (interview_rate_limited_total{service="llm"}). The dashboard
        reads that step-from-zero against concurrent interviews to find the LLM
        rate-limit ceiling. Guarded — metrics never break a call."""
        try:
            from engine.brain.observability import prom
            if prom.is_throttle_error(e):
                prom.note_throttle("llm", self._key_id)
        except Exception:
            pass

    def _enter_call(self, model: str) -> None:
        """Mark one LLM call as in-flight — bumps the call counter, the live
        in-flight gauge, and the per-key peak-concurrency tracker (all keyed by
        tier+model+key_id). Paired with _exit_call in a try/finally so it can't leak."""
        try:
            from engine.brain.observability import prom
            prom.llm_enter(self._tier or "unknown", model or "unknown", self._key_id)
        except Exception:
            pass

    def _exit_call(self, model: str) -> None:
        """Mark one in-flight LLM call as finished (drops the live gauge + tracker)."""
        try:
            from engine.brain.observability import prom
            prom.llm_exit(self._tier or "unknown", model or "unknown", self._key_id)
        except Exception:
            pass

    def _merge_extra(self, req_extra: dict[str, Any]) -> dict[str, Any]:
        """Return a copy of `req_extra` with `default_extra_body` merged
        into its `extra_body` key. Per-request keys take precedence.

        Also unconditionally turns on OpenRouter usage accounting
        (`extra_body.usage.include = true`) so the final SSE chunk
        includes provider-side cost + cached/reasoning token counts.
        Caller-supplied `usage` keys (e.g. disabling for non-OpenRouter
        upstreams) still win."""
        out = dict(req_extra)
        # Layer 1: default extra body (provider routing hints set at
        # construction). Layer 2: OpenRouter usage-include. Layer 3:
        # per-request extra_body wins over both.
        merged_body: dict[str, Any] = dict(self._default_extra_body or {})
        merged_body.setdefault("usage", _OPENROUTER_USAGE_INCLUDE["usage"])
        merged_body.update(out.get("extra_body", {}) or {})
        out["extra_body"] = merged_body
        return out

    async def complete_streaming(
        self,
        req: LLMRequest,
        *,
        on_utterance_char: Callable[[str], None] | None = None,
        on_first_token: Callable[[], None] | None = None,
        cancel_event: asyncio.Event | None = None,
    ) -> LLMCallResult:
        """Public entry: count this call as in-flight (interview_llm_active) for
        its whole duration, then delegate. try/finally so the gauge never leaks
        on error / timeout / barge-in cancellation."""
        self._enter_call(req.model)
        try:
            return await self._complete_streaming_impl(
                req,
                on_utterance_char=on_utterance_char,
                on_first_token=on_first_token,
                cancel_event=cancel_event,
            )
        finally:
            self._exit_call(req.model)

    async def _complete_streaming_impl(
        self,
        req: LLMRequest,
        *,
        on_utterance_char: Callable[[str], None] | None = None,
        on_first_token: Callable[[], None] | None = None,
        cancel_event: asyncio.Event | None = None,
    ) -> LLMCallResult:
        """Stream a tool-call response.

        - `on_utterance_char(c)` fires for each character of the `utterance`
          field as it arrives. The latency orchestrator pipes these straight
          to TTS.
        - `on_first_token()` fires once, when the first character of the
          arguments JSON arrives. Used to flip `latency_state → STREAMING_SLOW`.
        - If `cancel_event` is set mid-stream, we close the stream and return
          early with `cancelled=True`. No partial output is recorded as a turn.
        """
        started = time.perf_counter()
        ttft: int | None = None
        completion_start: datetime | None = None
        first_token_seen = False
        chars_piped: list[str] = []

        def _utterance_sink(c: str) -> None:
            nonlocal first_token_seen
            if not first_token_seen:
                first_token_seen = True
                if on_first_token is not None:
                    on_first_token()
            chars_piped.append(c)
            if on_utterance_char is not None:
                on_utterance_char(c)

        extractor = UtteranceExtractor(_utterance_sink)
        args_buf: list[str] = []
        content_buf: list[str] = []
        tool_name: str = ""
        cancelled = False
        usage_fields: dict[str, Any] = {}
        generation_id: str | None = None

        messages = [{"role": "system", "content": req.system_prompt}]
        messages.extend(req.user_messages)

        try:
            stream = await self._client.chat.completions.create(
                model=req.model,
                messages=messages,
                tools=req.tools,
                tool_choice=req.tool_choice,
                temperature=req.temperature,
                max_tokens=req.max_tokens,
                stream=True,
                stream_options={"include_usage": True},
                **self._merge_extra(req.extra),
            )
            async for chunk in stream:
                # First chunk usually carries the upstream `id` — keep it
                # so observability can deep-link to OpenRouter's
                # /api/v1/generation endpoint and the Langfuse trace.
                if generation_id is None:
                    cid = getattr(chunk, "id", None)
                    if cid:
                        generation_id = cid
                if cancel_event is not None and cancel_event.is_set():
                    cancelled = True
                    try:
                        await stream.close()
                    except Exception:  # pragma: no cover
                        pass
                    break
                # The final chunk (when stream_options.include_usage=True) has
                # `usage` populated and `choices` empty. With OpenRouter's
                # usage-include opt-in, that block also carries `cost`,
                # `prompt_tokens_details.cached_tokens`, and
                # `completion_tokens_details.reasoning_tokens`. Capture
                # every field we model.
                usage = getattr(chunk, "usage", None)
                if usage is not None:
                    usage_fields.update(_extract_openrouter_usage(usage))
                try:
                    choice = chunk.choices[0]
                    delta = choice.delta
                    tool_calls = getattr(delta, "tool_calls", None) or []
                    # Capture any message-body content too. A small model
                    # (llama-3.1-8b) sometimes ignores forced tool_choice and
                    # emits the answer here instead of as a tool call; the
                    # caller can then salvage it rather than failing outright.
                    content_piece = getattr(delta, "content", None)
                    if content_piece:
                        content_buf.append(content_piece)
                except (AttributeError, IndexError):
                    continue
                for tc in tool_calls:
                    fn = getattr(tc, "function", None)
                    if fn is None:
                        continue
                    name = getattr(fn, "name", None)
                    if name and not tool_name:
                        tool_name = name
                    piece = getattr(fn, "arguments", None)
                    if not piece:
                        continue
                    if ttft is None:
                        ttft = int((time.perf_counter() - started) * 1000)
                        completion_start = datetime.now(timezone.utc)
                    args_buf.append(piece)
                    if not extractor.done:
                        extractor.feed(piece)
        except asyncio.CancelledError:
            cancelled = True
            raise
        except Exception as e:
            self._note_error(e)
            return LLMCallResult(
                tool_name=tool_name or "",
                tool_arguments_raw="".join(args_buf),
                parsed=None,
                text_streamed="".join(chars_piped),
                content_text="".join(content_buf),
                model=req.model,
                tokens_in=usage_fields.get("tokens_in"),
                tokens_out=usage_fields.get("tokens_out"),
                latency_ms=int((time.perf_counter() - started) * 1000),
                ttft_ms=ttft,
                cancelled=False,
                error=str(e),
                tokens_total=usage_fields.get("tokens_total"),
                tokens_in_cached=usage_fields.get("tokens_in_cached"),
                tokens_in_cache_write=usage_fields.get("tokens_in_cache_write"),
                tokens_out_reasoning=usage_fields.get("tokens_out_reasoning"),
                cost_usd=usage_fields.get("cost_usd"),
                cost_prompt_usd=usage_fields.get("cost_prompt_usd"),
                cost_completion_usd=usage_fields.get("cost_completion_usd"),
                generation_id=generation_id,
                completion_start_time=completion_start,
            )

        latency_ms = int((time.perf_counter() - started) * 1000)
        self._observe_call(ttft, latency_ms, req.model)
        raw = "".join(args_buf)
        parsed: BaseModel | None = None
        err: str | None = None
        if not cancelled and req.parser is not None and raw:
            try:
                parsed = req.parser.model_validate_json(raw)
            except ValidationError as ve:
                err = f"validation_error: {ve}"
                logger.warning("LLM tool-call validation failed: %s", ve)

        return LLMCallResult(
            tool_name=tool_name or "",
            tool_arguments_raw=raw,
            parsed=parsed,
            text_streamed="".join(chars_piped),
            content_text="".join(content_buf),
            model=req.model,
            tokens_in=usage_fields.get("tokens_in"),
            tokens_out=usage_fields.get("tokens_out"),
            latency_ms=latency_ms,
            ttft_ms=ttft,
            cancelled=cancelled,
            error=err,
            tokens_total=usage_fields.get("tokens_total"),
            tokens_in_cached=usage_fields.get("tokens_in_cached"),
            tokens_in_cache_write=usage_fields.get("tokens_in_cache_write"),
            tokens_out_reasoning=usage_fields.get("tokens_out_reasoning"),
            cost_usd=usage_fields.get("cost_usd"),
            cost_prompt_usd=usage_fields.get("cost_prompt_usd"),
            cost_completion_usd=usage_fields.get("cost_completion_usd"),
            generation_id=generation_id,
            completion_start_time=completion_start,
        )

    async def complete_text_streaming(
        self,
        req: LLMRequest,
        *,
        on_utterance_char: Callable[[str], None] | None = None,
        on_first_token: Callable[[], None] | None = None,
        cancel_event: asyncio.Event | None = None,
    ) -> LLMCallResult:
        """Public entry: count this call as in-flight (interview_llm_active) for
        its whole duration, then delegate. try/finally so the gauge never leaks
        on error / timeout / barge-in cancellation."""
        self._enter_call(req.model)
        try:
            return await self._complete_text_streaming_impl(
                req,
                on_utterance_char=on_utterance_char,
                on_first_token=on_first_token,
                cancel_event=cancel_event,
            )
        finally:
            self._exit_call(req.model)

    async def _complete_text_streaming_impl(
        self,
        req: LLMRequest,
        *,
        on_utterance_char: Callable[[str], None] | None = None,
        on_first_token: Callable[[], None] | None = None,
        cancel_event: asyncio.Event | None = None,
    ) -> LLMCallResult:
        """Stream a plain-text chat completion (no tools, no JSON).

        Use this for any agent that just needs to produce a string of text
        for TTS — there is no value in wrapping that text in a tool-call
        schema. Weaker models often fail to emit valid JSON for tool
        arguments; text is the lowest common denominator that every model
        complies with reliably.

        `on_utterance_char(c)` fires for each character of the response as
        it arrives — pipe straight to TTS. `on_first_token()` fires once.
        `req.tools` and `req.tool_choice` are ignored; `req.parser` is
        ignored (no parsing to do).
        """
        started = time.perf_counter()
        ttft: int | None = None
        completion_start: datetime | None = None
        first_token_seen = False
        chars_piped: list[str] = []
        cancelled = False
        usage_fields: dict[str, Any] = {}
        generation_id: str | None = None

        messages = [{"role": "system", "content": req.system_prompt}]
        messages.extend(req.user_messages)

        try:
            stream = await self._client.chat.completions.create(
                model=req.model,
                messages=messages,
                temperature=req.temperature,
                max_tokens=req.max_tokens,
                stream=True,
                stream_options={"include_usage": True},
                **self._merge_extra(req.extra),
            )
            async for chunk in stream:
                if generation_id is None:
                    cid = getattr(chunk, "id", None)
                    if cid:
                        generation_id = cid
                if cancel_event is not None and cancel_event.is_set():
                    cancelled = True
                    try:
                        await stream.close()
                    except Exception:  # pragma: no cover
                        pass
                    break
                usage = getattr(chunk, "usage", None)
                if usage is not None:
                    usage_fields.update(_extract_openrouter_usage(usage))
                try:
                    choice = chunk.choices[0]
                    delta = choice.delta
                    piece = getattr(delta, "content", None)
                except (AttributeError, IndexError):
                    continue
                if not piece:
                    continue
                if ttft is None:
                    ttft = int((time.perf_counter() - started) * 1000)
                    completion_start = datetime.now(timezone.utc)
                if not first_token_seen and on_first_token is not None:
                    first_token_seen = True
                    try:
                        on_first_token()
                    except Exception:  # pragma: no cover
                        logger.exception("on_first_token callback raised")
                chars_piped.append(piece)
                if on_utterance_char is not None:
                    for c in piece:
                        try:
                            on_utterance_char(c)
                        except Exception:  # pragma: no cover
                            logger.exception("on_utterance_char raised")
        except asyncio.CancelledError:
            cancelled = True
            raise
        except Exception as e:
            self._note_error(e)
            return LLMCallResult(
                tool_name="",
                tool_arguments_raw="",
                parsed=None,
                text_streamed="".join(chars_piped),
                model=req.model,
                tokens_in=usage_fields.get("tokens_in"),
                tokens_out=usage_fields.get("tokens_out"),
                latency_ms=int((time.perf_counter() - started) * 1000),
                ttft_ms=ttft,
                cancelled=False,
                error=str(e),
                tokens_total=usage_fields.get("tokens_total"),
                tokens_in_cached=usage_fields.get("tokens_in_cached"),
                tokens_in_cache_write=usage_fields.get("tokens_in_cache_write"),
                tokens_out_reasoning=usage_fields.get("tokens_out_reasoning"),
                cost_usd=usage_fields.get("cost_usd"),
                cost_prompt_usd=usage_fields.get("cost_prompt_usd"),
                cost_completion_usd=usage_fields.get("cost_completion_usd"),
                generation_id=generation_id,
                completion_start_time=completion_start,
            )

        latency_ms = int((time.perf_counter() - started) * 1000)
        self._observe_call(ttft, latency_ms, req.model)
        return LLMCallResult(
            tool_name="",
            tool_arguments_raw="",
            parsed=None,
            text_streamed="".join(chars_piped),
            model=req.model,
            tokens_in=usage_fields.get("tokens_in"),
            tokens_out=usage_fields.get("tokens_out"),
            latency_ms=latency_ms,
            ttft_ms=ttft,
            cancelled=cancelled,
            error=None,
            tokens_total=usage_fields.get("tokens_total"),
            tokens_in_cached=usage_fields.get("tokens_in_cached"),
            tokens_in_cache_write=usage_fields.get("tokens_in_cache_write"),
            tokens_out_reasoning=usage_fields.get("tokens_out_reasoning"),
            cost_usd=usage_fields.get("cost_usd"),
            cost_prompt_usd=usage_fields.get("cost_prompt_usd"),
            cost_completion_usd=usage_fields.get("cost_completion_usd"),
            generation_id=generation_id,
            completion_start_time=completion_start,
        )
