"""Append-only JSONL event log.

NEW_STREAM_B.md §9. Every event written here is the source of truth for
post-hoc analysis. One JSON object per line. Buffered writes; flushed on
`close()` and at session_end (the runtime calls flush manually then).
"""
from __future__ import annotations

import json
import logging
import queue
import threading
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_SENTINEL = object()


class JsonlEventLog:
    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        # 1 = line-buffered; the writer THREAD (not the event loop) pays the flush.
        self._fp = self._path.open("a", buffering=1, encoding="utf-8")
        # write() only enqueues; a single daemon thread does the actual disk I/O.
        # In cloud this path is on an Azure Files (SMB) mount, where a synchronous
        # write can stall the asyncio loop for milliseconds — delaying EVERY
        # concurrent interview's turn. Keeping the write off-loop is what lets one
        # replica host many sessions without the loop hitching on the network fs.
        self._q: queue.Queue = queue.Queue()
        self._writer = threading.Thread(
            target=self._drain, name="eventlog-writer", daemon=True,
        )
        self._writer.start()

    def _drain(self) -> None:
        while True:
            item = self._q.get()
            try:
                if item is _SENTINEL:
                    return
                self._fp.write(item)
            except Exception as e:  # pragma: no cover
                logger.warning("event log write failed: %s", e)
            finally:
                self._q.task_done()

    def write(self, record: dict[str, Any]) -> None:
        # Non-blocking hand-off — never touch the file from the caller's thread.
        try:
            self._q.put_nowait(json.dumps(record, default=_json_fallback) + "\n")
        except Exception as e:  # pragma: no cover
            logger.warning("event log enqueue failed: %s", e)

    def flush(self) -> None:
        # Block until every queued line is written, then flush. Called at
        # session_end (interview already over), so blocking here is fine and
        # guarantees the eval reads a complete events.jsonl.
        try:
            self._q.join()
            self._fp.flush()
        except Exception:  # pragma: no cover
            pass

    def close(self) -> None:
        try:
            self._q.put_nowait(_SENTINEL)
            self._writer.join(timeout=5)
            self._fp.flush()
            self._fp.close()
        except Exception:  # pragma: no cover
            pass

    @property
    def path(self) -> Path:
        return self._path


def append_event_oneshot(path: str | Path, session_id: str, kind: str,
                         payload: dict[str, Any]) -> None:
    """Append ONE event line to a token's events.jsonl, matching the Tracer's row
    shape ({session_id, ts, kind, payload}).

    For emitters that live OUTSIDE an InterviewSession — e.g. the WS teardown that
    clears/keeps a durable checkpoint after the session object is already gone —
    so they have no Tracer/JsonlEventLog handle. Opens, writes one line, closes;
    no background thread (unlike JsonlEventLog). Best-effort: never raises."""
    from datetime import datetime, timezone
    try:
        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        row = {
            "session_id": session_id,
            "ts": datetime.now(timezone.utc).isoformat(),
            "kind": kind,
            "payload": payload,
        }
        with p.open("a", buffering=1, encoding="utf-8") as fp:
            fp.write(json.dumps(row, default=_json_fallback) + "\n")
    except Exception as e:  # pragma: no cover — observability must never break teardown
        logger.warning("append_event_oneshot(%s) failed: %s", kind, e)


def _json_fallback(obj: Any) -> Any:
    # datetime, UUID, dataclasses, pydantic — anything we hand it.
    if hasattr(obj, "isoformat"):
        return obj.isoformat()
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    if hasattr(obj, "__dict__"):
        return obj.__dict__
    return str(obj)
