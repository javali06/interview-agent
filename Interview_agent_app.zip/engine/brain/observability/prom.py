"""Shared Prometheus registry for the session process.

Exposed at ``/metrics`` by ``deploy/azure_app.py``. Lives in
``engine/brain/observability`` (not ``deploy/``) so brain code — chiefly
``timing.py`` — can record metrics without importing the deploy layer.

The one histogram here is the workhorse: ``log_timing()`` funnels EVERY timed
pipeline stage (STT final, LLM first-token, TTS audio_start, director ticks,
session startup, …) into it, labeled by ``(service, action)``. That means any
lag on a shard is attributable to a specific stage from a single metric —
`histogram_quantile(0.95, sum by (le, service, action) (rate(interview_stage_latency_ms_bucket[1m])))`.
"""
from __future__ import annotations

from prometheus_client import CollectorRegistry, Counter, Gauge, Histogram

# One registry for everything the session process exports. deploy/azure_app.py
# registers its gauges here too and serves `generate_latest(REGISTRY)`.
REGISTRY = CollectorRegistry()

# Buckets in milliseconds: fine at the ~turn-budget scale (tens–hundreds of ms)
# and wide enough to catch multi-second startup / stalls.
_BUCKETS_MS = (5, 10, 25, 50, 100, 200, 400, 800, 1600, 3200, 6400, 12800, 25600)

STAGE_LATENCY_MS = Histogram(
    "interview_stage_latency_ms",
    "Per-stage latency in ms, labeled by pipeline service + action (fed by log_timing).",
    ["service", "action"],
    buckets=_BUCKETS_MS,
    registry=REGISTRY,
)

# LLM latency measured at the client CHOKEPOINT (LLMClient), so EVERY call is
# timed no matter which agent made it — labeled ONLY by tier (fast/slow), the two
# models in use, not by agent. ttft = request→first token (the responsiveness
# signal the user watches); latency = request→completion. Fed by
# LLMClient._observe_call on each successful call.
LLM_TTFT_MS = Histogram(
    "interview_llm_ttft_ms",
    "LLM time-to-first-token (ms) by tier (fast/slow) + model name. Chokepoint metric — every call.",
    ["tier", "model"],
    buckets=_BUCKETS_MS,
    registry=REGISTRY,
)
LLM_LATENCY_MS = Histogram(
    "interview_llm_latency_ms",
    "LLM request→completion latency (ms) by tier (fast/slow) + model name. Chokepoint metric — every call.",
    ["tier", "model"],
    buckets=_BUCKETS_MS,
    registry=REGISTRY,
)

# STT lag attribution. Two signals that ALWAYS fire (no dependence on a per-utterance
# STT `final`, which Azure doesn't reliably emit — the Turn is assembled from partials
# at the VAD endpoint):
#   - STT_FIRST_PARTIAL_MS: speech_start → first partial. VAD already had the audio at
#     speech_start, so this delay is PURELY STT — the "STT is slow while I talk" signal.
#   - STT_SPOKEN_MS: how long the candidate actually spoke (audio_ms) — the baseline that
#     contextualizes the lag (a 2s head-lag on a 2s utterance is severe; on a 15s one, minor).
# Plotted together (and next to interview_llm_ttft_ms{tier="slow"}) so a slow turn is
# attributable to STT vs LLM. NOTE: STT does NOT add to the AI's post-endpoint response
# delay — the director finalizes at the VAD endpoint without waiting for STT.
STT_FIRST_PARTIAL_MS = Histogram(
    "interview_stt_first_partial_ms",
    "STT head lag (ms): candidate speech_start → first partial transcript. Purely STT.",
    ["provider"],
    buckets=_BUCKETS_MS,
    registry=REGISTRY,
)
STT_SPOKEN_MS = Histogram(
    "interview_stt_spoken_ms",
    "Candidate spoken-audio duration per utterance (ms) — baseline to compare STT lag against.",
    ["provider"],
    buckets=_BUCKETS_MS,
    registry=REGISTRY,
)
# Per-PARTIAL recognition lag: how far behind real-time the streaming recognizer
# is AT each partial. Azure is a streaming push recognizer (no per-partial
# request/response) — each `recognizing` event reports, via its audio offset,
# the stream position it has produced a hypothesis for. Anchored to the
# utterance's stream start and compared to wall-clock:
#   lag = (now - speech_start) - (partial.end_ms - stream_offset_at_utterance_start)
# A small, flat lag ⇒ STT keeps pace; a GROWING lag ⇒ it's falling behind (the
# "captions lag while I talk" feeling). Fires on EVERY partial, so the panel
# shows the lag DISTRIBUTION (p50/p95), not one sample per utterance. This is
# the richer companion to STT_FIRST_PARTIAL_MS (which is only the first caption).
STT_PARTIAL_LAG_MS = Histogram(
    "interview_stt_partial_lag_ms",
    "Streaming-STT recognition lag at each partial (ms): wall-clock beyond the audio recognized so far.",
    ["provider"],
    buckets=_BUCKETS_MS,
    registry=REGISTRY,
)

# Concurrent LLM calls in flight RIGHT NOW, by tier (fast/slow) + model + the
# API key used. inc on call start / dec on finish at the client chokepoint
# (try/finally, so it can't leak on error / timeout / barge-in). Per-process, so
# it's this shard's live load — but because multiple shards share one API key,
# the DASHBOARD sums across shards per key: `sum by (key_id, model) (interview_llm_active)`
# shows, per key, how many slow vs fast calls the whole fleet is making (what the
# provider's rate limit actually sees). key_id is a non-secret provider+hash id.
LLM_ACTIVE = Gauge(
    "interview_llm_active",
    "LLM calls currently in flight, by tier (fast/slow) + model + API key (key_id). Sum across shards per key.",
    ["tier", "model", "key_id"],
    registry=REGISTRY,
)

# The instantaneous LLM_ACTIVE gauge above is invisible at a 5s scrape: LLM calls
# are sub-second-to-a-few-seconds and finish between scrapes, so a scrape almost
# always catches 0. So we ALSO keep, per (tier, model, key_id):
#   - LLM_CALLS: a counter → rate() = calls/sec per key (what a provider's req/min
#     rate limit actually sees), immune to sampling.
#   - LLM_ACTIVE_PEAK: MAX concurrent calls since the last scrape (peak-since-
#     scrape, same pattern as interview_loop_lag_ms) → concurrency spikes never
#     get missed. snapshot_llm_peaks() publishes + resets it on each scrape.
LLM_CALLS = Counter(
    "interview_llm_calls_total",
    "LLM calls started, by tier (fast/slow) + model + API key (key_id). rate() = calls/sec per key.",
    ["tier", "model", "key_id"],
    registry=REGISTRY,
)
LLM_ACTIVE_PEAK = Gauge(
    "interview_llm_active_peak",
    "Max concurrent LLM calls since last scrape, by tier + model + key_id (peak-since-scrape).",
    ["tier", "model", "key_id"],
    registry=REGISTRY,
)
# Live + peak concurrency bookkeeping keyed by (tier, model, key_id). Single event
# loop → no locking needed. Updated in llm_enter/llm_exit; peak published + reset
# by snapshot_llm_peaks() at scrape time.
_LLM_CUR: dict[tuple[str, str, str], int] = {}
_LLM_PEAK: dict[tuple[str, str, str], int] = {}


def llm_enter(tier: str, model: str, key_id: str) -> None:
    """One LLM call started: bump the call counter, the live in-flight gauge, and
    the per-key peak-concurrency tracker. Called at the LLM client chokepoint."""
    k = (tier, model, key_id)
    LLM_CALLS.labels(*k).inc()
    LLM_ACTIVE.labels(*k).inc()
    cur = _LLM_CUR.get(k, 0) + 1
    _LLM_CUR[k] = cur
    if cur > _LLM_PEAK.get(k, 0):
        _LLM_PEAK[k] = cur


def llm_exit(tier: str, model: str, key_id: str) -> None:
    """One LLM call finished: drop the live gauge + concurrency tracker."""
    k = (tier, model, key_id)
    LLM_ACTIVE.labels(*k).dec()
    _LLM_CUR[k] = max(0, _LLM_CUR.get(k, 0) - 1)


def snapshot_llm_peaks() -> None:
    """Publish peak-since-last-scrape concurrency into LLM_ACTIVE_PEAK, then reset
    each peak to the current live count (so a still-running call keeps showing).
    Call once per /metrics scrape, before generate_latest()."""
    for k, peak in _LLM_PEAK.items():
        LLM_ACTIVE_PEAK.labels(*k).set(peak)
        _LLM_PEAK[k] = _LLM_CUR.get(k, 0)


# VAD WebSocket connect failures (after retries) — a wedged/slow VAD subprocess.
# A nonzero rate means bring-up is failing fast (by design) instead of hanging
# silently. Incremented in engine/brain/streamA_bridge/vad_client.py::connect().
VAD_CONNECT_FAILURES = Counter(
    "interview_vad_connect_failures_total",
    "VAD WebSocket connect attempts that failed after retries (fail-fast, not a silent hang).",
    registry=REGISTRY,
)

# Candidate mic PCM frames dropped on inbound-queue overflow. The browser sends
# audio at real time; when a saturated event loop can't pump it to STT fast
# enough, the bounded mic queue overflows and we drop the oldest frame. A
# climbing rate here — read together with queue depth + loop lag — is THE
# "STT/audio pipeline can't keep up at scale" signal. Process-global (all
# sessions on the shard share it); Prometheus's `instance` label separates
# shards, so no explicit shard label is needed. Incremented in the broadcaster.
MIC_FRAMES_DROPPED = Counter(
    "interview_mic_frames_dropped_total",
    "Candidate mic PCM frames dropped on inbound-queue overflow (audio backpressure).",
    registry=REGISTRY,
)

# Durable-resume events (feature B): a fresh runner found a Redis checkpoint for
# an interview whose prior runner was lost (shard restart / crash / evict) and
# resumed the phase instead of re-greeting. A nonzero rate means runners are
# being lost mid-interview — read alongside container restart counts. Labelled by
# the phase resumed into. Incremented in InterviewSession._resume_bringup.
INTERVIEW_RESUMES = Counter(
    "interview_resumes_total",
    "Interviews resumed from a durable checkpoint after the prior runner was lost.",
    ["phase"],
    registry=REGISTRY,
)

# ── LiveKit media + session-tier scaling (Phases 1-4) ───────────────────────
# Read together on the "LiveKit media & scaling" dashboard row.

# How long each step of putting an interview in a LiveKit room took:
# agent_connect (the AI joins), candidate_ready (the page joined and can hear),
# egress_active (the server recorder is capturing — the greeting waits for it).
LIVEKIT_JOIN_MS = Histogram(
    "interview_livekit_join_ms",
    "Time per step of starting an interview in a LiveKit room, ms.",
    ["stage"],
    buckets=_BUCKETS_MS,
    registry=REGISTRY,
)

# The "finished playing" signal's delay: from when the AI's utterance should
# have finished playing (audio_end + the audio the sink still had queued) to the
# page confirming the candidate heard it out — the page's quiet window, jitter
# buffer and network, not the utterance's own length. The silence timer and the
# goodbye hold run off this ack, so a growing lag means they fire late; per
# transport, so LiveKit can be compared with the WebSocket path.
PLAYBACK_ACK_LAG_MS = Histogram(
    "interview_playback_ack_lag_ms",
    "Expected end of playback → audio_playback_finished, ms, per media transport.",
    ["transport"],
    buckets=_BUCKETS_MS,
    registry=REGISTRY,
)

# Acks that arrived BEFORE the server expected the utterance to end — kept out
# of the lag histogram (they'd read as a perfect 0). On LiveKit the page judges
# "heard" by the track going quiet, so a pause before the next sentence's audio
# arrives can confirm that sentence before it plays.
PLAYBACK_ACK_EARLY = Counter(
    "interview_playback_ack_early_total",
    "Playback acks received before the server expected the audio to end, per transport.",
    ["transport"],
    registry=REGISTRY,
)

# An interview stopped on this replica to continue elsewhere: no_room (LiveKit
# unusable at start), page_fallback (the page asked for the WebSocket),
# drain_ws / drain_deadline (replica shutting down), lease_lost (another
# replica took it). Incremented in deploy/azure_app.py.
INTERVIEW_HANDOFFS = Counter(
    "interview_handoffs_total",
    "Interviews handed off from this replica, by reason.",
    ["reason"],
    registry=REGISTRY,
)

# Resumes by how far back they went: "turn" (mid-phase, Phase 4) or "phase"
# (reopened the phase: coding/scenario phases, or a pre-Phase-4 checkpoint).
INTERVIEW_RESUMES_BY_MODE = Counter(
    "interview_resumes_by_mode_total",
    "Interviews resumed from a checkpoint, by resume mode.",
    ["mode"],
    registry=REGISTRY,
)

# Server-side recording lifecycle: started / start_failed / stopped /
# stop_failed (session tier), complete / failed (the recording_finalize job).
LIVEKIT_EGRESS = Counter(
    "interview_livekit_egress_total",
    "Server-side (LiveKit egress) recording outcomes.",
    ["outcome"],
    registry=REGISTRY,
)

# The LiveKit audio source restarted a reader stuck on a dead stream (no
# candidate audio for LIVEKIT_MIC_STALL_S while the track was unmuted).
JOBS = Counter(
    "interview_jobs_total",
    "Worker jobs finished, by job type and outcome (succeeded / retry / dead).",
    ["type", "outcome"],
    registry=REGISTRY,
)
LIVEKIT_MIC_STALL_HEALS = Counter(
    "interview_livekit_mic_stall_heals_total",
    "Candidate-audio readers restarted after a stall (LiveKit).",
    registry=REGISTRY,
)


# Upstream THROTTLING (HTTP 429 / "too many requests" / quota). The single
# clearest scale-CEILING signal: an interview needs an LLM call per turn, an
# Azure Speech STT stream, and Azure TTS — every one of those is a shared quota,
# and when a provider starts REJECTING calls THIS fires. Labelled by:
#   - service : "llm" | "stt" | "tts"  (which dependency ran out of headroom)
#   - key_id  : the SPECIFIC key that throttled — the LLM key (provider+hash,
#               e.g. "groq-ab12cd") or the Azure Speech key (sha256(secret)[:8],
#               the SAME id the admission counter + interview_speech_inflight
#               gauge use), so a 429 lines up on the same key as its in-flight
#               concurrency.
# It's a Counter → rate() = throttles/sec; the interesting moment is the STEP
# from zero. Read on the dashboard AGAINST interview_active_sessions (concurrent
# interviews) it answers "at how many concurrent interviews did <this key> start
# throttling?". Incremented at the client chokepoints (LLM client, Azure STT
# cancel handler, Azure TTS synth) via note_throttle().
# Azure can cancel a streaming synthesis part-way (an error, not a 429): the
# candidate then hears the sentence cut off. Nothing else surfaces it — the
# turn completes normally with whatever audio arrived.
TTS_TRUNCATED = Counter(
    "interview_tts_truncated_total",
    "Utterances whose synthesis was cancelled by the provider part-way through, per Speech key.",
    ["key_id"],
    registry=REGISTRY,
)

RATE_LIMITED = Counter(
    "interview_rate_limited_total",
    "Upstream 429 / throttle responses, by service (llm/stt/tts) + the specific key (key_id).",
    ["service", "key_id"],
    registry=REGISTRY,
)

# Throttle-shaped-error markers. Deliberately BROAD + string-based so one check
# works across the OpenAI SDK (openai.RateLimitError), the Azure Speech SDK's
# cancellation details, and raw provider messages — without depending on any
# provider-specific exception type or SDK enum value.
_THROTTLE_MARKERS = (
    "429", "too many requests", "throttl", "rate limit", "rate_limit",
    "rate-limit", "quota", "toomanyrequests",
)


def is_throttle_error(err: object) -> bool:
    """True if ``err`` (an exception, an SDK cancellation code, or a message
    string) looks like an upstream throttle / 429. Checks an HTTP status code
    when present (OpenAI/httpx-style ``.status_code``), then falls back to the
    string markers. Never raises."""
    try:
        code = getattr(err, "status_code", None)
        if code is None:
            code = getattr(err, "code", None)
        if code is not None:
            try:
                if int(code) == 429:
                    return True
            except (TypeError, ValueError):
                pass
        return any(m in str(err).lower() for m in _THROTTLE_MARKERS)
    except Exception:
        return False


def note_throttle(service: str, key_id: str) -> None:
    """Record ONE upstream throttle/429 for ``service`` on key ``key_id``.
    Guarded — observability must never break a call."""
    try:
        RATE_LIMITED.labels(service=service, key_id=(key_id or "unknown")).inc()
    except Exception:
        pass
