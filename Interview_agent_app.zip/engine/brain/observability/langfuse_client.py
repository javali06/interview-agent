"""Langfuse SDK wiring for stream_b_new.

Self-contained module the rest of stream_b_new imports. Three things on offer:

  - `get_langfuse()`               singleton client. Lazy init from env. Returns
                                   None if creds missing or init failed — every
                                   helper below is a no-op in that case so local
                                   dev / unconfigured runs never crash.
  - `observe_llm` / `observe_stt`  context managers that wrap an LLM / STT call
    / `observe_tts`                in a Langfuse "generation" observation. Yields
                                   an object whose `.update_observation(...)`
                                   the caller invokes once it knows tokens /
                                   output / latency. All metadata (session_id,
                                   phase, agent, etc.) is set automatically.
  - `flush()`                      manual flush, called from InterviewSession's
                                   teardown so the last few traces of a session
                                   land in Langfuse before the process exits.

DESIGN NOTES

1. **Session grouping.** Every observation we open calls
   `update_current_trace(session_id=<candidate token>)`. Langfuse's "Sessions"
   tab then groups every trace from one interview into one timeline. This is
   the primary navigation for the admin "View in Langfuse" deep-link.

2. **No turn-spans.** Earlier drafts wrapped each turn in an outer "turn" span
   with LLM/STT/TTS as children. We dropped that because TTS streams audio
   asynchronously and may complete AFTER the turn-span context exits — losing
   it as a child. Instead every component (LLM agent, STT recognize, TTS
   speak) opens its own observation; they cluster correctly via `session_id`
   in the Sessions view, without lifecycle coupling.

3. **No-op fallback.** When `LANGFUSE_PUBLIC_KEY` + `LANGFUSE_SECRET_KEY` are
   missing, `get_langfuse()` returns None ONCE, sets a sticky disabled flag,
   and every helper yields a `_NoopObservation` so callers don't need to
   guard each call site. This keeps local dev (no Langfuse creds) identical
   in code to cloud (creds set) — only behaviour differs.

4. **Threading.** Langfuse 4.x uses OpenTelemetry context vars under the
   hood, which are async-task-local. Each `start_as_current_observation`
   call must originate on the asyncio loop (NOT on an SDK worker thread)
   for nested children to attach correctly. STT/TTS callback bridges
   (azure_stt_client.py, azure_tts_client.py) already hop back to the
   loop via `loop.call_soon_threadsafe` before they do anything else —
   we instrument inside the loop-side handler.
"""
from __future__ import annotations

import logging
import os
import subprocess
from contextlib import contextmanager
from datetime import datetime
from typing import Any, Iterator, TYPE_CHECKING

if TYPE_CHECKING:
    from engine.brain.llm.client import LLMCallResult

logger = logging.getLogger(__name__)


# Single-init state.
_client: Any = None
_disabled: bool = False
_release: str | None = None     # cached git-SHA release tag


def _detect_release() -> str | None:
    """Best-effort release identifier for trace-level grouping in Langfuse.

    Precedence: LANGFUSE_RELEASE → git short SHA → None. The Langfuse SDK
    will pick it up via constructor; we cache so the subprocess call only
    runs once per process. None means "let the SDK decide / unset"."""
    global _release
    if _release is not None:
        return _release
    env_release = os.environ.get("LANGFUSE_RELEASE")
    if env_release:
        _release = env_release
        return _release
    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            stderr=subprocess.DEVNULL, timeout=2,
        )
        _release = out.decode().strip() or None
    except Exception:
        _release = None
    return _release


# Azure Cognitive Services pricing — used to fill `cost_details` on STT/TTS
# observations. Langfuse auto-computes LLM costs from model + token usage
# (pricing table is maintained server-side), but Azure Speech is not an LLM
# so we emit USD ourselves. Rates come from config/llm_models.yaml `speech:`
# (single source) via stream_b_new.llm.pricing.
def _azure_stt_usd_per_ms() -> float:
    from engine.brain.llm.pricing import stt_usd_per_audio_ms
    return stt_usd_per_audio_ms("azure-speech-stt")


def _azure_tts_neural_usd_per_char() -> float:
    from engine.brain.llm.pricing import tts_usd_per_char
    return tts_usd_per_char("azure-speech-tts-neural")

# Default voice + model strings used in observation `model=...` so Langfuse
# clusters Azure Speech calls under recognisable names in the UI. These are
# labels, not model IDs the SDK resolves — Langfuse stores them as-is.
_AZURE_STT_MODEL_LABEL = "azure-speech-stt"


def get_langfuse() -> Any:
    """Return the Langfuse client singleton, or None if disabled.

    Disabled means either:
      - LANGFUSE_PUBLIC_KEY / LANGFUSE_SECRET_KEY not set (expected in local
        dev without an account)
      - Client init raised (auth failure, host unreachable). We log once and
        stay disabled for the process lifetime — no retry storm.
    """
    global _client, _disabled
    if _disabled:
        return None
    if _client is not None:
        return _client
    pk = os.environ.get("LANGFUSE_PUBLIC_KEY")
    sk = os.environ.get("LANGFUSE_SECRET_KEY")
    host = (
        os.environ.get("LANGFUSE_HOST")
        or os.environ.get("LANGFUSE_BASE_URL")
        or "https://us.cloud.langfuse.com"
    )
    if not (pk and sk):
        logger.info(
            "[langfuse] keys not set (LANGFUSE_PUBLIC_KEY/SECRET_KEY) — "
            "tracing disabled for this process"
        )
        _disabled = True
        return None
    try:
        from langfuse import Langfuse  # imported lazily so the package is
                                       # only required when keys are present
        # Environment tag for trace-level grouping (cloud filters by it).
        # SDK already reads LANGFUSE_TRACING_ENVIRONMENT, but we pass it
        # explicitly so an operator can override with the friendlier
        # LANGFUSE_ENVIRONMENT name we document in .env.example.
        environment = (
            os.environ.get("LANGFUSE_TRACING_ENVIRONMENT")
            or os.environ.get("LANGFUSE_ENVIRONMENT")
            or os.environ.get("APP_ENV")
            or None
        )
        release = _detect_release()
        kwargs: dict[str, Any] = {
            "public_key": pk, "secret_key": sk, "host": host,
        }
        if environment:
            kwargs["environment"] = environment
        if release:
            kwargs["release"] = release
        _client = Langfuse(**kwargs)
        logger.info(
            "[langfuse] initialised host=%s environment=%s release=%s",
            host, environment or "(default)", release or "(unset)",
        )
        return _client
    except Exception as e:
        logger.warning(
            "[langfuse] init failed (%s) — tracing disabled for this process",
            e,
        )
        _disabled = True
        return None


def project_base_url() -> str | None:
    """Base URL for building admin deep-links to the Langfuse UI.

    Returns None when LANGFUSE_PROJECT_ID is unset (admin button hides
    gracefully in that case)."""
    host = (
        os.environ.get("LANGFUSE_HOST")
        or os.environ.get("LANGFUSE_BASE_URL")
        or "https://us.cloud.langfuse.com"
    )
    project_id = os.environ.get("LANGFUSE_PROJECT_ID")
    if not project_id:
        return None
    return f"{host.rstrip('/')}/project/{project_id}"


def session_url(session_token: str) -> str | None:
    """Deep-link to the Langfuse Sessions view for one candidate token."""
    base = project_base_url()
    if base is None:
        return None
    return f"{base}/sessions/{session_token}"


def trace_url(trace_id: str | None) -> str | None:
    """Deep-link to a specific trace by id (one LLM/STT/TTS observation)."""
    if not trace_id:
        return None
    base = project_base_url()
    if base is None:
        return None
    return f"{base}/traces/{trace_id}"


def flush() -> None:
    """Block until the SDK's background sender has shipped pending events.

    Called from InterviewSession.__aexit__ so the last traces of an
    interview land before the process winds down."""
    lf = get_langfuse()
    if lf is None:
        return
    try:
        lf.flush()
    except Exception as e:
        logger.warning("[langfuse] flush failed: %s", e)


# ── observation helpers ───────────────────────────────────────────────────


class _NoopObservation:
    """Object yielded when Langfuse is disabled. All updates silently drop.

    Mirrors the small slice of LangfuseGeneration's API that call sites
    actually use, so the same code reads `lf_obs.trace_id` in both modes
    without conditionals."""

    trace_id: str | None = None
    id: str | None = None

    def update(self, **kwargs: Any) -> None:
        return

    def update_observation(self, **kwargs: Any) -> None:  # legacy alias
        return


def _trace_scope(
    *,
    session_id: str,
    user_id: str | None = None,
    tags: list[str] | None = None,
    trace_name: str | None = None,
):
    """Context manager that tags every observation opened inside it with
    trace-level attributes (session_id, user_id, tags, trace name).

    Langfuse 4.x mechanism is `propagate_attributes` — a module-level
    context manager that pushes the attrs onto the OTel context. ALL
    observations opened while this context is active inherit them on
    their auto-created trace. This is the official API for tagging a
    Langfuse Session — there is no `update_current_trace` method.

    Returns a no-op context manager when Langfuse is disabled, so call
    sites can always `with _trace_scope(...): ...` without guarding."""
    if get_langfuse() is None:
        return _noop_cm()
    try:
        from langfuse import propagate_attributes
        kwargs: dict[str, Any] = {"session_id": str(session_id)}
        if user_id:
            kwargs["user_id"] = user_id
        if tags:
            kwargs["tags"] = tags
        if trace_name:
            kwargs["trace_name"] = trace_name
        return propagate_attributes(**kwargs)
    except Exception as e:  # pragma: no cover
        logger.debug("[langfuse] propagate_attributes failed: %s", e)
        return _noop_cm()


@contextmanager
def _noop_cm() -> Iterator[None]:
    yield None


@contextmanager
def observe_llm(
    *,
    agent: str,
    model: str,
    session_id: str,
    phase: str | None = None,
    input_data: Any = None,
    metadata: dict[str, Any] | None = None,
    user_id: str | None = None,
    model_parameters: dict[str, Any] | None = None,
) -> Iterator[Any]:
    """Wrap an LLM call in a Langfuse `generation` observation.

    Usage in an agent (paired with `apply_llm_result` for the post-call
    update so all 4 agents emit identical observations):

        with observe_llm(agent="question_agent", model=self._model,
                         session_id=session_id, phase=ctx.phase,
                         input_data=messages,
                         model_parameters={"temperature": 0.4,
                                           "max_tokens": 2000}) as obs:
            res = await self._llm.complete_text_streaming(req, ...)
            apply_llm_result(obs, res,
                             output={"text": res.text_streamed})

    `apply_llm_result` populates `usage_details` (including cached +
    reasoning), `cost_details` (USD from OpenRouter usage-include),
    `completion_start_time` (TTFT timestamp), `level=ERROR` on failure,
    and the OpenRouter generation_id in metadata.

    `model_parameters` (temperature, max_tokens, top_p, etc.) are passed
    at observation creation since they're known up-front. Langfuse will
    also auto-compute cost from `model` + `usage_details` if the model
    is in their pricing table — but we always send `cost_details` when
    OpenRouter gave us a real number, which wins over the estimate.
    """
    lf = get_langfuse()
    if lf is None:
        yield _NoopObservation()
        return
    meta: dict[str, Any] = {"agent": agent}
    if phase:
        meta["phase"] = phase
    if metadata:
        meta.update(metadata)
    trace_tags = [t for t in (phase, agent, "llm") if t]
    with _trace_scope(
        session_id=session_id, user_id=user_id, tags=trace_tags,
        trace_name=f"llm.{agent}",
    ):
        try:
            kwargs: dict[str, Any] = {
                "name": f"agent.{agent}",
                "as_type": "generation",
                "input": input_data,
                "model": model,
                "metadata": meta,
            }
            if model_parameters:
                kwargs["model_parameters"] = model_parameters
            obs_ctx = lf.start_as_current_observation(**kwargs)
        except Exception as e:
            logger.warning("[langfuse] start observation failed (%s) — skipping", e)
            yield _NoopObservation()
            return
        with obs_ctx as obs:
            # Stash session_id on the observation so apply_llm_result can
            # record to the local cost_tracker even when the caller didn't
            # pass session_id explicitly (none of the 4 agents do). Without
            # this the per-model cost rollup / sidecar / admin dashboard
            # stay empty even though Langfuse shows cost (it reads the
            # trace-level session_id set in _trace_scope above).
            try:
                obs._bx_session_id = session_id  # type: ignore[attr-defined]
            except Exception:
                pass
            yield obs


@contextmanager
def observe_stt(
    *,
    session_id: str,
    audio_ms: int | None = None,
    phase: str | None = None,
    model: str = _AZURE_STT_MODEL_LABEL,
    user_id: str | None = None,
    name: str = "stt.partial",
) -> Iterator[Any]:
    """Wrap one STT observation in a generation.

    `name` distinguishes the two STT observation kinds:
      - "stt.partial" (default): ONE Azure `recognized` segment of the
        candidate's utterance. Carries `audio_ms` → cost.
      - "stt.final": the merged full utterance emitted by the Director at
        VAD endpoint (audio_ms=None → no cost; cost already counted on the
        per-segment stt.partial observations).
    `audio_ms` is the duration of audio that produced this segment. Cost
    in `cost_details` is filled automatically from the rate constant. The
    caller `.update(output={"text": ...}, metadata={...})` afterwards."""
    lf = get_langfuse()
    if lf is None:
        yield _NoopObservation()
        return
    meta: dict[str, Any] = {}
    if phase:
        meta["phase"] = phase
    if audio_ms is not None:
        meta["audio_ms"] = audio_ms
    trace_tags = [t for t in (phase, "stt", "azure-speech") if t]
    with _trace_scope(
        session_id=session_id, user_id=user_id, tags=trace_tags,
        trace_name=name,
    ):
        try:
            obs_ctx = lf.start_as_current_observation(
                name=name,
                as_type="generation",
                model=model,
                input={"audio_ms": audio_ms} if audio_ms is not None else None,
                metadata=meta,
            )
        except Exception as e:
            logger.warning("[langfuse] start stt observation failed (%s) — skipping", e)
            yield _NoopObservation()
            return
        with obs_ctx as obs:
            # Pre-fill cost so the caller only needs to update output.
            # Langfuse expects standard keys: input / output / cache_read /
            # cache_write / total. The previous {"usd": X} key was ignored
            # by Langfuse's cost-rollup, making the dashboard show $0 for
            # every STT call. Use input + total so Langfuse can split
            # input/output if it cares to (STT is input-side audio).
            _stt_cost: float | None = None
            if audio_ms is not None:
                try:
                    _stt_cost = audio_ms * _azure_stt_usd_per_ms()
                    obs.update(cost_details={
                        "input": _stt_cost,
                        "total": _stt_cost,
                    })
                except Exception:  # pragma: no cover
                    pass
            # Record locally for the per-model dashboard rollup — the
            # same number we just wrote to Langfuse's cost_details.
            try:
                from engine.brain.observability.cost_tracker import record_stt
                record_stt(
                    session_id=str(session_id) if session_id else None,
                    audio_ms=audio_ms,
                    cost_usd=_stt_cost,
                )
            except Exception:  # pragma: no cover
                pass
            yield obs


@contextmanager
def observe_tts(
    *,
    session_id: str,
    text: str,
    voice: str,
    phase: str | None = None,
    user_id: str | None = None,
) -> Iterator[Any]:
    """Wrap one TTS synthesis (one speak_chunk call) in a generation observation.

    Caller `.update(output={"audio_ms": ..., "pcm_bytes": ...},
    metadata={"latency_ms": ..., "ttft_ms": ...})` once `on_audio_end` fires.
    `cost_details` is filled automatically from char count × Azure rate."""
    lf = get_langfuse()
    if lf is None:
        yield _NoopObservation()
        return
    meta: dict[str, Any] = {"voice": voice, "chars_in": len(text)}
    if phase:
        meta["phase"] = phase
    trace_tags = [t for t in (phase, "tts", "azure-speech") if t]
    with _trace_scope(
        session_id=session_id, user_id=user_id, tags=trace_tags,
        trace_name="tts.synthesize",
    ):
        try:
            obs_ctx = lf.start_as_current_observation(
                name="tts.synthesize",
                as_type="generation",
                model=f"azure-speech-tts/{voice}",
                input={"text": text},
                metadata=meta,
            )
        except Exception as e:
            logger.warning("[langfuse] start tts observation failed (%s) — skipping", e)
            yield _NoopObservation()
            return
        with obs_ctx as obs:
            # Standard Langfuse cost keys (output/total). Previously we
            # wrote {"usd": X} which Langfuse silently ignored, making
            # every TTS call show $0 on the dashboard. TTS is output-side
            # audio synthesis so the cost lives in "output".
            _tts_cost: float | None = None
            try:
                _tts_cost = len(text) * _azure_tts_neural_usd_per_char()
                obs.update(cost_details={
                    "output": _tts_cost,
                    "total": _tts_cost,
                })
            except Exception:  # pragma: no cover
                pass
            # Record locally for the per-model dashboard rollup. Azure
            # bills by characters of input text, so chars = len(text)
            # (NOT derived from audio duration).
            try:
                from engine.brain.observability.cost_tracker import record_tts
                record_tts(
                    session_id=str(session_id) if session_id else None,
                    voice=voice,
                    chars=len(text),
                    cost_usd=_tts_cost,
                )
            except Exception:  # pragma: no cover
                pass
            yield obs


# ── post-call helpers ─────────────────────────────────────────────────────


def apply_llm_result(
    obs: Any,
    res: "LLMCallResult",
    *,
    output: Any = None,
    extra_metadata: dict[str, Any] | None = None,
    session_id: str | None = None,
) -> None:
    """Single source of truth for emitting an LLMCallResult into Langfuse.

    NOTE: `session_id` falls back to the value stashed on `obs` by
    `observe_llm` when the caller doesn't pass it (the agents don't), so
    the local cost_tracker rollup is always populated.

    Every agent (question, verifier, filler, phase_override) calls this
    once with the result of an LLMClient call. Mapping:

      - `usage_details`  ← tokens_in / tokens_out / tokens_total +
                           cached + cache_write + reasoning_output
                           (each field omitted when upstream didn't
                           report it). Langfuse aggregates these for the
                           per-project token-spend dashboard.
      - `cost_details`   ← OpenRouter's authoritative USD numbers from the
                           usage-include opt-in WHEN PRESENT. When the
                           upstream (Groq direct, plain OpenAI direct)
                           does not return cost, fall back to the
                           per-model rates in config/llm_models.yaml and
                           emit an explicit FOUR-component breakdown
                           (input / output / cache_read / cache_write +
                           total). The cache split is what gives the
                           Langfuse cost dashboard a visible "savings
                           from caching" signal — without it cached and
                           fresh tokens look identical in the spend pane.
      - `completion_start_time` ← UTC ts of the first token (TTFT anchor).
                           Langfuse uses (start_time, completion_start_time,
                           end_time) to chart TTFT vs total latency.
      - `level` / `status_message` ← ERROR if the call errored, otherwise
                           default. Status carries the error string so
                           the "Errors" filter in Langfuse surfaces it.
      - `metadata`       ← latency_ms, ttft_ms, cancelled, generation_id
                           (for OpenRouter /api/v1/generation deep-link),
                           cost_source ("openrouter" vs "yaml_estimate")
                           so it's auditable which number is which.

    `output` is whatever the caller wants logged as the model's reply —
    typically `{"text": res.text_streamed}` for plain-text agents or a
    parsed-tool-call dict for tool agents.

    No-ops cleanly when `obs` is a `_NoopObservation` (Langfuse disabled).
    """
    if obs is None or isinstance(obs, _NoopObservation):
        return

    # Build usage_details with only the fields the upstream populated.
    # Langfuse standard keys are `input` / `output` / `total`. We add
    # `input_cached`, `input_cache_write`, and `output_reasoning` so the
    # dashboard separates fresh prompts from cache hits, cache writes,
    # and reasoning spend (very different cost profiles).
    usage_details: dict[str, int] = {}
    if res.tokens_in is not None:
        usage_details["input"] = int(res.tokens_in)
    if res.tokens_out is not None:
        usage_details["output"] = int(res.tokens_out)
    if res.tokens_total is not None:
        usage_details["total"] = int(res.tokens_total)
    if res.tokens_in_cached is not None:
        usage_details["input_cached"] = int(res.tokens_in_cached)
    if getattr(res, "tokens_in_cache_write", None) is not None:
        usage_details["input_cache_write"] = int(res.tokens_in_cache_write)
    if res.tokens_out_reasoning is not None:
        usage_details["output_reasoning"] = int(res.tokens_out_reasoning)

    cost_details: dict[str, float] = {}
    cost_source: str | None = None
    if res.cost_usd is not None:
        # OpenRouter's authoritative number — use it. We still emit the
        # prompt / completion split when the SDK provided it; the
        # cache-line stays empty since OpenRouter folds cache savings
        # into the prompt cost already.
        if res.cost_prompt_usd is not None:
            cost_details["input"] = float(res.cost_prompt_usd)
        if res.cost_completion_usd is not None:
            cost_details["output"] = float(res.cost_completion_usd)
        cost_details["total"] = float(res.cost_usd)
        cost_source = "openrouter"
    else:
        # Upstream didn't return cost (Groq direct, OpenAI direct, etc.).
        # Estimate from the YAML — same numbers the end-of-run usage
        # table uses. compute_cost handles the cache-read / cache-write
        # discounts so the cost reflects real billing.
        try:
            from engine.brain.llm.pricing import compute_cost
            bd = compute_cost(
                res.model,
                tokens_in=res.tokens_in,
                tokens_out=res.tokens_out,
                tokens_cached=res.tokens_in_cached or 0,
                tokens_cache_write=getattr(res, "tokens_in_cache_write", 0) or 0,
            )
        except Exception as e:  # pragma: no cover
            logger.debug("[langfuse] compute_cost failed: %s", e)
            bd = None
        if bd is not None:
            cost_details = bd.as_langfuse_cost_details()
            cost_source = "yaml_estimate"

    meta: dict[str, Any] = {
        "latency_ms": res.latency_ms,
        "ttft_ms": res.ttft_ms,
        "cancelled": res.cancelled,
    }
    if cost_source:
        meta["cost_source"] = cost_source
    # Cache savings — exposed as a top-level metadata field so it's
    # easy to filter / chart in Langfuse. None when no cache hit happened.
    if res.tokens_in_cached and res.tokens_in:
        meta["cache_hit_ratio"] = round(
            float(res.tokens_in_cached) / float(res.tokens_in), 4,
        )
    if res.error:
        meta["error"] = res.error
    if res.generation_id:
        # Surfaces in the Langfuse metadata pane; ops can paste it into
        # https://openrouter.ai/api/v1/generation?id=… to confirm cost.
        meta["openrouter_generation_id"] = res.generation_id
    if extra_metadata:
        meta.update(extra_metadata)

    update_kwargs: dict[str, Any] = {"metadata": meta}
    if output is not None:
        update_kwargs["output"] = output
    if usage_details:
        update_kwargs["usage_details"] = usage_details
    if cost_details:
        update_kwargs["cost_details"] = cost_details
    if res.completion_start_time is not None:
        update_kwargs["completion_start_time"] = res.completion_start_time
    if res.error and not res.cancelled:
        update_kwargs["level"] = "ERROR"
        update_kwargs["status_message"] = str(res.error)[:200]

    try:
        obs.update(**update_kwargs)
    except Exception as e:  # pragma: no cover — observability never blocks
        logger.debug("[langfuse] apply_llm_result update failed: %s", e)

    # Record locally for the per-model dashboard rollup. This is a LOCAL
    # in-memory map — it must NOT be coupled to whether Langfuse is live.
    # (Previously gated on `not isinstance(obs, _NoopObservation)`, so when
    # Langfuse wasn't configured on a deployment the entire cost rollup
    # stayed empty and the dashboard showed $0.) Record whenever we have a
    # session_id, regardless of Langfuse state.
    # Fall back to the session_id observe_llm stashed on `obs` — the agents
    # don't pass session_id to this function, so without this the rollup
    # would never populate.
    if session_id is None:
        session_id = getattr(obs, "_bx_session_id", None)
    if session_id:
        try:
            from engine.brain.observability.cost_tracker import record_llm_call
            total_cost = float(cost_details.get("total")) if cost_details else None
            # If the provider didn't echo a cost and cost_details is empty,
            # fall back to local pricing so the rollup is never zero for a
            # real call.
            if total_cost is None:
                try:
                    from engine.brain.llm.pricing import compute_cost
                    _bd = compute_cost(
                        res.model,
                        tokens_in=res.tokens_in or 0,
                        tokens_out=res.tokens_out or 0,
                        tokens_cached=res.tokens_in_cached or 0,
                        tokens_cache_write=getattr(res, "tokens_in_cache_write", 0) or 0,
                    )
                    total_cost = _bd.total if _bd is not None else None
                except Exception:
                    total_cost = None
            record_llm_call(
                session_id=str(session_id),
                model=res.model,
                tokens_in=res.tokens_in,
                tokens_out=res.tokens_out,
                tokens_cached=res.tokens_in_cached or 0,
                tokens_cache_write=getattr(res, "tokens_in_cache_write", 0) or 0,
                cost_usd=total_cost,
            )
        except Exception as e:  # pragma: no cover
            logger.debug("[langfuse] cost_tracker.record_llm_call failed: %s", e)


def score_current_trace(
    name: str,
    value: float | bool | str,
    *,
    data_type: str = "NUMERIC",
    comment: str | None = None,
) -> None:
    """Attach a trace-level score from inside an active observation
    context. Use for end-of-interview signals (e.g. completion=1.0,
    error_rate, candidate_satisfaction). Silently no-ops when Langfuse
    is disabled."""
    lf = get_langfuse()
    if lf is None:
        return
    try:
        kwargs: dict[str, Any] = {
            "name": name, "value": value, "data_type": data_type,
        }
        if comment:
            kwargs["comment"] = comment
        # `score_current_trace` attaches to the trace of whichever
        # observation is currently active in the OTel context.
        score_fn = getattr(lf, "score_current_trace", None)
        if score_fn is not None:
            score_fn(**kwargs)
    except Exception as e:  # pragma: no cover
        logger.debug("[langfuse] score_current_trace failed: %s", e)


def score_session(
    *,
    session_id: str,
    name: str,
    value: float | bool | str,
    data_type: str = "NUMERIC",
    comment: str | None = None,
) -> None:
    """Post-hoc score for a completed session. Used by InterviewSession
    teardown to record completion / error counts after the last
    observation context has closed. Routes through the REST API since
    there's no live observation to attach to."""
    lf = get_langfuse()
    if lf is None:
        return
    try:
        # The Sessions tab aggregates scores across all traces with the
        # same session_id; we attach one score to one synthetic
        # trace_id-less score row by passing session_id directly.
        lf.create_score(  # type: ignore[attr-defined]
            name=name, value=value, data_type=data_type,
            session_id=session_id, comment=comment,
        )
    except Exception as e:  # pragma: no cover
        logger.debug("[langfuse] score_session failed: %s", e)
