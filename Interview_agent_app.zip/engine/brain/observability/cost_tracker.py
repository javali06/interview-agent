"""Per-session, per-model cost accumulator.

WHY
===
Every cost number we compute is also pushed to Langfuse via `cost_details`
(see `apply_llm_result` for LLMs, `observe_stt` / `observe_tts` for speech).
For the admin dashboard we want the same totals locally so we can render a
"cost by model" table without round-tripping through Langfuse or walking
events.jsonl. This module keeps that running map in process memory:

    _SESSIONS: {
      "<session_id>": {
        "openai/gpt-oss-120b":     {calls, tokens_in, tokens_out,
                                    tokens_cached, tokens_cache_write,
                                    cost_usd, ...},
        "meta-llama/llama-3.1-8b": {...},
        "azure-speech-stt":        {calls, audio_ms, cost_usd, ...},
        "azure-speech-tts/<voice>": {calls, chars, cost_usd, ...},
      },
      ...
    }

The map is updated synchronously from `apply_llm_result` / `observe_stt` /
`observe_tts` — i.e. the EXACT same code path that writes the cost to
Langfuse. So Langfuse and this dashboard agree by construction.

USAGE
=====
- Recorders (called from the observability wrappers):
    cost_tracker.record_llm_call(session_id=..., model=..., tokens_in=...,
        tokens_out=..., tokens_cached=..., tokens_cache_write=...,
        cost_usd=...)
    cost_tracker.record_stt(session_id=..., audio_ms=..., cost_usd=...)
    cost_tracker.record_tts(session_id=..., voice=..., chars=..., cost_usd=...)

- Readers:
    cost_tracker.snapshot(session_id) -> {"rows": [...], "total_cost_usd": ...}
    cost_tracker.persist(session_id, path) -> writes sidecar JSON
    cost_tracker.load_sidecar(path)      -> reads sidecar JSON

- Lifecycle:
    cost_tracker.clear(session_id) — drop the in-memory map for a session
    (called after the sidecar has been persisted at SESSION_ENDED).

THREAD SAFETY
=============
A single `threading.Lock` guards the map. Recorders run on the asyncio
event loop in normal flow but can also be invoked from SDK callback
threads (Azure Speech SDK in particular runs callbacks on its own pool).
The lock is held only across the dict mutation; cost-computing math
happens outside the lock.

LIFETIME
========
Module-level state lives for the lifetime of the Python process. Gunicorn
runs with `--workers 1` on the cloud deploy so all sessions share one
process — there's no cross-worker visibility problem. If the process
restarts, in-memory state is lost — that's what the sidecar write at
SESSION_ENDED is for. Admin reads the sidecar in preference to the live
map for completed sessions.
"""
from __future__ import annotations

import json
import logging
import threading
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_LOCK = threading.Lock()


def _empty_row() -> dict[str, Any]:
    return {
        "model": "",
        "kind": "llm",          # one of: llm | stt | tts
        "calls": 0,
        "tokens_in": 0,         # LLMs only (zero for stt/tts)
        "tokens_out": 0,
        "tokens_cached": 0,
        "tokens_cache_write": 0,
        "audio_ms": 0,          # STT only
        "chars": 0,             # TTS only
        "cost_usd": 0.0,
    }


_SESSIONS: dict[str, dict[str, dict[str, Any]]] = defaultdict(
    lambda: defaultdict(_empty_row)
)


# ── recorders ─────────────────────────────────────────────────────────────


def record_llm_call(
    *,
    session_id: str | None,
    model: str | None,
    tokens_in: int | None,
    tokens_out: int | None,
    tokens_cached: int | None = 0,
    tokens_cache_write: int | None = 0,
    cost_usd: float | None,
) -> None:
    """Record one LLM call's contribution to the per-model rollup.

    Called from `apply_llm_result` right after the Langfuse update — the
    `cost_usd` here is the same number we just wrote to
    `cost_details.total` on the Langfuse observation.
    """
    if not session_id or not model:
        return
    with _LOCK:
        row = _SESSIONS[session_id][model]
        row["model"] = model
        row["kind"] = "llm"
        row["calls"] += 1
        row["tokens_in"] += int(tokens_in or 0)
        row["tokens_out"] += int(tokens_out or 0)
        row["tokens_cached"] += int(tokens_cached or 0)
        row["tokens_cache_write"] += int(tokens_cache_write or 0)
        row["cost_usd"] += float(cost_usd or 0.0)


def record_stt(
    *,
    session_id: str | None,
    audio_ms: int | None,
    cost_usd: float | None,
    model: str = "azure-speech-stt",
) -> None:
    """Record one STT recognition. Cost is the same number `observe_stt`
    just wrote to `cost_details.total` on the Langfuse observation."""
    if not session_id:
        return
    with _LOCK:
        row = _SESSIONS[session_id][model]
        row["model"] = model
        row["kind"] = "stt"
        row["calls"] += 1
        row["audio_ms"] += int(audio_ms or 0)
        row["cost_usd"] += float(cost_usd or 0.0)


def record_tts(
    *,
    session_id: str | None,
    voice: str,
    chars: int | None,
    cost_usd: float | None,
) -> None:
    """Record one TTS synthesis (one speak_chunk). Cost = len(text) ×
    per-char rate (Azure bills by characters of input text) — same number
    we just wrote to `cost_details.total` on the Langfuse observation."""
    if not session_id:
        return
    model = f"azure-speech-tts/{voice}" if voice else "azure-speech-tts"
    with _LOCK:
        row = _SESSIONS[session_id][model]
        row["model"] = model
        row["kind"] = "tts"
        row["calls"] += 1
        row["chars"] += int(chars or 0)
        row["cost_usd"] += float(cost_usd or 0.0)


# ── readers ───────────────────────────────────────────────────────────────


def snapshot(session_id: str) -> dict[str, Any]:
    """Return the per-model rollup for a session.

    Result shape:
      {
        "session_id": "...",
        "rows": [ {model, kind, calls, tokens_in, tokens_out,
                   tokens_cached, tokens_cache_write, audio_ms, chars,
                   cost_usd}, ... ],
        "total_cost_usd": float,
        "totals": {"tokens_in": int, "tokens_out": int,
                   "tokens_cached": int, "tokens_cache_write": int}
      }

    Rows are sorted by cost descending. Always returns a dict; an empty
    `rows` list means we haven't recorded anything yet for this session.
    """
    with _LOCK:
        models = _SESSIONS.get(session_id) or {}
        # Copy out under the lock so we don't iterate while a callback
        # thread mutates the dict.
        rows = [dict(r) for r in models.values()]

    rows.sort(key=lambda r: -r["cost_usd"])

    total_cost = sum(r["cost_usd"] for r in rows)
    totals = {
        "tokens_in": sum(r["tokens_in"] for r in rows if r["kind"] == "llm"),
        "tokens_out": sum(r["tokens_out"] for r in rows if r["kind"] == "llm"),
        "tokens_cached": sum(r["tokens_cached"] for r in rows if r["kind"] == "llm"),
        "tokens_cache_write": sum(
            r["tokens_cache_write"] for r in rows if r["kind"] == "llm"
        ),
    }
    return {
        "session_id": session_id,
        "rows": rows,
        "total_cost_usd": total_cost,
        "totals": totals,
    }


# ── persistence ───────────────────────────────────────────────────────────


def persist(session_id: str, out_path: Path) -> dict[str, Any] | None:
    """Snapshot the rollup for a session and write it to `out_path` as JSON.

    Called from the SESSION_ENDED hook so the dashboard can read a fresh
    sidecar even after the worker process restarts. Returns the dict
    written (or None on failure)."""
    try:
        snap = snapshot(session_id)
        snap["written_at"] = datetime.now(timezone.utc).isoformat()
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(
            json.dumps(snap, indent=2, default=str), encoding="utf-8"
        )
        logger.info(
            "[cost_tracker] %s persisted (%d models, $%.6f total)",
            session_id[:8] if session_id else "?",
            len(snap.get("rows") or []),
            snap.get("total_cost_usd") or 0.0,
        )
        return snap
    except Exception as e:
        logger.exception("[cost_tracker] persist failed for %s: %s", session_id, e)
        return None


def load_sidecar(path: Path) -> dict[str, Any] | None:
    """Read a previously-persisted rollup. Returns None when the file is
    missing or unparsable."""
    try:
        if not path.exists():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or "rows" not in data:
            return None
        return data
    except Exception:
        return None


def clear(session_id: str) -> None:
    """Drop the in-memory rollup for a session. Call after `persist` at
    SESSION_ENDED so long-running processes don't accumulate stale dicts."""
    with _LOCK:
        _SESSIONS.pop(session_id, None)
