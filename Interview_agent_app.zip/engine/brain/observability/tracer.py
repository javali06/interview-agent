"""Tracer — the structured-event emitter.

NEW_STREAM_B.md §9.1. `tracer.event(...)` writes one EventKind row.
`tracer.span("name")` is a context manager that times a block and emits
start + end events. Both go to the JSONL log AND publish to the in-process
event bus so live consumers can subscribe.
"""
from __future__ import annotations

import logging
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Iterator
from uuid import UUID, uuid4

from engine.brain.contracts.events import Event, EventKind
from engine.brain.core.event_bus import EventBus
from engine.brain.observability.event_log import JsonlEventLog

logger = logging.getLogger(__name__)


class Span:
    """A timing+context object. Mutate `.fields` to enrich the end event."""

    def __init__(self, tracer: "Tracer", name: str, started_at: float, kind: EventKind | str):
        self._tracer = tracer
        self.name = name
        self.kind = kind
        self.started_at = started_at
        self.span_id = str(uuid4())
        self.fields: dict[str, Any] = {"span_name": name, "span_id": self.span_id}

    def set(self, **fields: Any) -> None:
        self.fields.update(fields)


class Tracer:
    def __init__(self, *, session_id: UUID, event_log: JsonlEventLog, bus: EventBus) -> None:
        self._session_id = session_id
        self._log = event_log
        self._bus = bus

    @property
    def session_id(self) -> UUID:
        """Read-only session id. Used by Langfuse helpers to tag observations."""
        return self._session_id

    def event(self, kind: EventKind | str, **payload: Any) -> None:
        evt = Event(
            session_id=self._session_id,
            ts=datetime.now(timezone.utc),
            kind=kind,
            payload=payload,
        )
        self._log.write(evt.to_jsonable())
        # Best-effort publish; bus subscribers never block writers.
        try:
            self._bus.publish_sync(evt)
        except Exception as e:  # pragma: no cover
            logger.debug("bus publish failed: %s", e)

    @contextmanager
    def span(self, name: str, kind: EventKind | str = "span", **fields: Any) -> Iterator[Span]:
        sp = Span(self, name, time.perf_counter(), kind)
        sp.set(**fields)
        self.event(f"{kind}.start" if isinstance(kind, str) else kind, **sp.fields)
        try:
            yield sp
        finally:
            sp.set(duration_ms=int((time.perf_counter() - sp.started_at) * 1000))
            self.event(
                f"{kind}.end" if isinstance(kind, str) else kind, **sp.fields,
            )
