"""Colored per-service timing logs.

Drop a `log_timing(...)` call wherever a service crosses an interesting
boundary (STT final received, LLM first token, TTS audio_start, etc.) and
the user gets a colored line like:

    [TIMING][LLM-slow ] first_token  +382ms   model=openai/gpt-oss-120b
    [TIMING][TTS      ] audio_start  +240ms   sub=slow-3-1
    [TIMING][TTS      ] audio_end    +1820ms  sub=slow-3-1 dur=1820ms
    [TIMING][STT      ] final        +734ms   text='Hi, my name...'

Colors are ANSI codes — render correctly in tty stdout. When piped to a
file, the codes appear as raw bytes (jq filters work either way since
event-log entries are separate).
"""
from __future__ import annotations

import logging
import os
import sys

# ── ANSI palette ──────────────────────────────────────────────────────

_STT_COLOR = "\033[96m"        # bright cyan
_VAD_COLOR = "\033[94m"         # bright blue
_LLM_SLOW_COLOR = "\033[95m"    # bright magenta
_LLM_FAST_COLOR = "\033[92m"    # bright green
_TTS_COLOR = "\033[93m"         # bright yellow
_DEFAULT_COLOR = "\033[97m"     # bright white
_RESET = "\033[0m"
_DIM = "\033[2m"

_COLORS = {
    "STT":      _STT_COLOR,
    "VAD":      _VAD_COLOR,
    "LLM-slow": _LLM_SLOW_COLOR,
    "LLM-fast": _LLM_FAST_COLOR,
    "TTS":      _TTS_COLOR,
}

# Disable colors when output isn't a TTY (e.g. piped to `tee` for a log file).
# Override with FORCE_COLOR=1 to keep them anyway.
_USE_COLOR = (
    sys.stdout.isatty() if hasattr(sys.stdout, "isatty") else False
) or os.environ.get("FORCE_COLOR") == "1"


def _wrap(text: str, color: str) -> str:
    if not _USE_COLOR:
        return text
    return f"{color}{text}{_RESET}"


def log_timing(
    logger: logging.Logger,
    service: str,
    action: str,
    duration_ms: int | float | None,
    **fields,
) -> None:
    """Emit a single colored timing line.

    Args:
        logger:       any logging.Logger
        service:      one of "STT" / "VAD" / "LLM-slow" / "LLM-fast" / "TTS"
        action:       short verb like "first_token" / "audio_start" / "final"
        duration_ms:  elapsed time for the action (ms). May be None if the
                      action is just a marker without a duration.
        **fields:     extra context appended as `key=value` pairs.
    """
    color = _COLORS.get(service, _DEFAULT_COLOR)
    dur = f"+{int(duration_ms):>5}ms" if duration_ms is not None else "       "
    extras = "  ".join(f"{k}={v}" for k, v in fields.items())
    line = f"[TIMING][{service:<8}] {action:<14} {dur}  {extras}".rstrip()
    logger.info(_wrap(line, color))

    # Also record to Prometheus so every timed stage is attributable on the
    # /metrics dashboard (STT vs LLM vs TTS vs startup …). Labels stay to
    # (service, action) only — never per-session — to keep cardinality low.
    # Never let metrics break logging.
    if duration_ms is not None:
        try:
            from engine.brain.observability.prom import STAGE_LATENCY_MS
            STAGE_LATENCY_MS.labels(service=service, action=action).observe(
                float(duration_ms)
            )
        except Exception:
            pass
