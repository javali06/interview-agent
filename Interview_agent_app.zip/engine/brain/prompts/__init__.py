"""Prompt loading — reads from config/prompts.yaml (single source of truth).

`load(name)` returns the prompt registered under `name`. Legacy callers that
pass '<name>.md' still work (the suffix is stripped), so call sites don't all
need touching. `get_phrases(key)` returns a nested phrase-bank dict (e.g. the
apology fallback banks).
"""
from __future__ import annotations

import functools
import os
from pathlib import Path
from typing import Any

import yaml

_DIR = Path(__file__).resolve().parent  # engine/brain/prompts


def _prompts_path() -> Path:
    """PROMPTS_CONFIG_PATH env overrides; else <repo-root>/config/prompts.yaml."""
    override = os.environ.get("PROMPTS_CONFIG_PATH", "").strip()
    if override:
        return Path(override)
    return _DIR.parents[2] / "config" / "prompts.yaml"


@functools.lru_cache(maxsize=1)
def _load_all() -> dict[str, Any]:
    p = _prompts_path()
    if not p.exists():
        raise FileNotFoundError(f"prompts config not found: {p}")
    return yaml.safe_load(p.read_text(encoding="utf-8")) or {}


def load(name: str) -> str:
    """Return the prompt string registered under `name` (e.g. 'system_prompt',
    'verifier'). Accepts legacy '<name>.md' forms."""
    key = name[:-3] if name.endswith(".md") else name
    prompts = _load_all()
    val = prompts.get(key)
    if val is None:
        raise KeyError(f"prompt {key!r} not found in {_prompts_path()}")
    if not isinstance(val, str):
        raise TypeError(f"prompt {key!r} is not a string scalar")
    return val.rstrip()


def get_phrases(key: str = "apology_phrases") -> dict[str, Any]:
    """Return a nested phrase-bank dict (e.g. apology_phrases) from the config."""
    val = _load_all().get(key, {})
    return val if isinstance(val, dict) else {}
