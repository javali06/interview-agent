"""Prosody side-channel schema (A-05 done criterion)."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class ProsodyFeatures(BaseModel):
    """Per-utterance acoustic features derived from STT word timestamps + PCM."""

    words_per_minute: float = Field(ge=0.0)
    inter_word_pause_ms_mean: float = Field(ge=0.0)
    inter_word_pause_ms_std: float = Field(ge=0.0)
    pitch_hz_mean: float = Field(ge=0.0)
    pitch_hz_std: float = Field(ge=0.0)
    utterance_duration_ms: int = Field(ge=0)
    word_count: int = Field(ge=0)


class ProsodyEvent(BaseModel):
    type: Literal["prosody"] = "prosody"
    session_id: str
    utterance_id: str
    speaker: str                     # Matches Speaker enum values in session_state.py
    features: ProsodyFeatures
    schema_version: str = "v1"
