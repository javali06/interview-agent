"""TTS JSON message schemas per §4.2.

Client → server:
  speak:  {"type": "speak",  "text": str, "voice_id": str, "request_id": str}
  cancel: {"type": "cancel", "request_id": str}

Server → client:
  audio_start / audio_end / cancelled  (plus inline PCM frames per §4.1 direction 2)
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class SpeakRequest(BaseModel):
    type: Literal["speak"] = "speak"
    text: str
    # Optional: empty string falls back to the service's default_voice_id from
    # config. Lets clients (e.g. Stream B's TTSSender) omit voice selection.
    voice_id: str = ""
    request_id: str


class CancelRequest(BaseModel):
    type: Literal["cancel"] = "cancel"
    request_id: str


class AudioStart(BaseModel):
    type: Literal["audio_start"] = "audio_start"
    request_id: str


class AudioEnd(BaseModel):
    type: Literal["audio_end"] = "audio_end"
    request_id: str


class CancelledMessage(BaseModel):
    type: Literal["cancelled"] = "cancelled"
    request_id: str
