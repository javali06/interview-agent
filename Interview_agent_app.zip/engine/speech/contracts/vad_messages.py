"""VAD JSON message schemas per §4.2."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class SpeechStart(BaseModel):
    type: Literal["speech_start"] = "speech_start"
    ts_ms: int = Field(ge=0)


class SpeechEnd(BaseModel):
    type: Literal["speech_end"] = "speech_end"
    ts_ms: int = Field(ge=0)


class EndpointDetected(BaseModel):
    type: Literal["endpoint_detected"] = "endpoint_detected"
    ts_ms: int = Field(ge=0)
    confidence: float = Field(ge=0.0, le=1.0)
