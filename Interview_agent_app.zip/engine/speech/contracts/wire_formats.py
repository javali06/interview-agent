"""Binary audio framing and control messages per §4.1.

Frame layout (.NET → Python, inbound):

    [4 bytes] frame_timestamp_ms  (uint32, little-endian)
    [2 bytes] participant_id      (uint16, enum: 1=candidate, 2=ta, 3=other)
    [2 bytes] sample_count        (uint16 = 320 for 20ms at 16kHz)
    [N bytes] PCM16 mono samples  (little-endian, N = sample_count * 2)

Direction 2 (Python → .NET, TTS) omits participant_id:

    [4 bytes] frame_timestamp_ms  (uint32, little-endian)
    [2 bytes] sample_count        (uint16)
    [N bytes] PCM16 mono samples
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from enum import IntEnum

SAMPLE_RATE_HZ: int = 16_000
FRAME_MS: int = 20
FRAME_SAMPLES_20MS_16KHZ: int = SAMPLE_RATE_HZ * FRAME_MS // 1000  # 320
BYTES_PER_SAMPLE: int = 2
AUDIO_FRAME_HEADER_BYTES: int = 4 + 2 + 2  # ts + pid + sample_count
AUDIO_FRAME_OUT_HEADER_BYTES: int = 4 + 2  # ts + sample_count

_IN_HEADER = struct.Struct("<IHH")
_OUT_HEADER = struct.Struct("<IH")


class ParticipantID(IntEnum):
    """§4.1 enum. Matches the 2-byte participant_id field."""

    CANDIDATE = 1
    TA = 2
    OTHER = 3


@dataclass(frozen=True, slots=True)
class AudioFrame:
    """Decoded inbound audio frame from .NET."""

    frame_timestamp_ms: int
    participant_id: ParticipantID
    sample_count: int
    pcm: bytes  # little-endian PCM16

    @property
    def duration_ms(self) -> int:
        return self.sample_count * 1000 // SAMPLE_RATE_HZ


def encode_audio_frame(
    frame_timestamp_ms: int,
    participant_id: ParticipantID | int,
    pcm: bytes,
) -> bytes:
    """Encode an inbound frame (.NET → Python).

    sample_count is derived from len(pcm) // 2.
    """
    if len(pcm) % BYTES_PER_SAMPLE != 0:
        raise ValueError(f"PCM byte length {len(pcm)} is not a multiple of {BYTES_PER_SAMPLE}")
    sample_count = len(pcm) // BYTES_PER_SAMPLE
    if sample_count > 0xFFFF:
        raise ValueError(f"sample_count {sample_count} exceeds uint16 max")
    if frame_timestamp_ms < 0 or frame_timestamp_ms > 0xFFFFFFFF:
        raise ValueError("frame_timestamp_ms out of uint32 range")
    pid_int = int(participant_id)
    return _IN_HEADER.pack(frame_timestamp_ms, pid_int, sample_count) + pcm


def decode_audio_frame(data: bytes) -> AudioFrame:
    """Decode an inbound frame (.NET → Python)."""
    if len(data) < AUDIO_FRAME_HEADER_BYTES:
        raise ValueError(f"frame too short: {len(data)} bytes")
    ts, pid, sample_count = _IN_HEADER.unpack_from(data, 0)
    pcm = data[AUDIO_FRAME_HEADER_BYTES:]
    expected = sample_count * BYTES_PER_SAMPLE
    if len(pcm) != expected:
        raise ValueError(
            f"pcm length {len(pcm)} != declared sample_count * 2 = {expected}"
        )
    try:
        participant = ParticipantID(pid)
    except ValueError as e:
        raise ValueError(f"unknown participant_id {pid}") from e
    return AudioFrame(
        frame_timestamp_ms=ts,
        participant_id=participant,
        sample_count=sample_count,
        pcm=pcm,
    )


def encode_tts_frame(frame_timestamp_ms: int, pcm: bytes) -> bytes:
    """Encode an outbound TTS frame (Python → .NET)."""
    if len(pcm) % BYTES_PER_SAMPLE != 0:
        raise ValueError(f"PCM byte length {len(pcm)} is not a multiple of {BYTES_PER_SAMPLE}")
    sample_count = len(pcm) // BYTES_PER_SAMPLE
    if sample_count > 0xFFFF:
        raise ValueError(f"sample_count {sample_count} exceeds uint16 max")
    return _OUT_HEADER.pack(frame_timestamp_ms, sample_count) + pcm


@dataclass(frozen=True, slots=True)
class OutAudioFrame:
    frame_timestamp_ms: int
    sample_count: int
    pcm: bytes


def decode_tts_frame(data: bytes) -> OutAudioFrame:
    if len(data) < AUDIO_FRAME_OUT_HEADER_BYTES:
        raise ValueError(f"frame too short: {len(data)} bytes")
    ts, sample_count = _OUT_HEADER.unpack_from(data, 0)
    pcm = data[AUDIO_FRAME_OUT_HEADER_BYTES:]
    expected = sample_count * BYTES_PER_SAMPLE
    if len(pcm) != expected:
        raise ValueError(
            f"pcm length {len(pcm)} != declared sample_count * 2 = {expected}"
        )
    return OutAudioFrame(frame_timestamp_ms=ts, sample_count=sample_count, pcm=pcm)
