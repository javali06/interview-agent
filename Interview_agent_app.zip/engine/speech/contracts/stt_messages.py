"""STT JSON message schemas per §4.2.

Client sends PCM frames (§4.1 direction 1). Server emits either a partial or a final.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class Word(BaseModel):
    """Word timestamp produced by STT alignment."""

    w: str
    start_ms: int = Field(ge=0)
    end_ms: int = Field(ge=0)
    conf: float = Field(ge=0.0, le=1.0)


class PartialMessage(BaseModel):
    type: Literal["partial"] = "partial"
    text: str
    words: list[Word] = Field(default_factory=list)


class FinalMessage(BaseModel):
    type: Literal["final"] = "final"
    text: str
    words: list[Word] = Field(default_factory=list)
    utterance_id: str
    # Convenience fields Stream B uses; not in §4.2 but additive-only.
    start_ms: int = Field(ge=0, default=0)
    end_ms: int = Field(ge=0, default=0)
    confidence: float = Field(ge=0.0, le=1.0, default=1.0)


class ControlMessage(BaseModel):
    """Pause / resume toggles from the client. Additive to §4.2."""

    type: Literal["pause", "resume"]


class TranscribeStart(BaseModel):
    """Emitted by STT immediately before a request goes to the engine.

    Two fields explain "why this call":
      - kind:    the kind of result we expect back (partial | final)
      - trigger: what caused the call to fire:
                   "partial_timer" — the streaming partial interval elapsed
                   "endpoint"      — VAD endpoint_detected fired

    Today kind and trigger are 1:1 (timer→partial, endpoint→final). They're
    separate because future flows (e.g. forced commit on buffer overflow)
    might decouple them.
    """

    type: Literal["transcribe_start"] = "transcribe_start"
    kind: Literal["partial", "final"]
    trigger: Literal["partial_timer", "endpoint"]
    audio_ms: int = Field(ge=0)
    utterance_id: str
