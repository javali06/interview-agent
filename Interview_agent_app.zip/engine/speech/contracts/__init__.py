"""Shared contracts per §4 of the SSOT. Imported by every service.

Anything added here is a cross-service commitment — changes require an ADR
once M1 has passed (see §4 preamble in the plan doc).
"""

from contracts.prosody_messages import ProsodyEvent
from contracts.session_state import (
    Dimension,
    EvidenceRef,
    IntegrityFlag,
    PartialUtterance,
    Phase,
    RunningScore,
    SessionState,
    Speaker,
    TAOverride,
    Turn,
)
from contracts.stt_messages import FinalMessage, PartialMessage, TranscribeStart, Word
from contracts.tts_messages import (
    AudioEnd,
    AudioStart,
    CancelledMessage,
    CancelRequest,
    SpeakRequest,
)
from contracts.vad_messages import EndpointDetected, SpeechEnd, SpeechStart
from contracts.wire_formats import (
    AUDIO_FRAME_HEADER_BYTES,
    FRAME_SAMPLES_20MS_16KHZ,
    SAMPLE_RATE_HZ,
    AudioFrame,
    ParticipantID,
    decode_audio_frame,
    encode_audio_frame,
)

__all__ = [
    "AUDIO_FRAME_HEADER_BYTES",
    "AudioEnd",
    "AudioFrame",
    "AudioStart",
    "CancelRequest",
    "CancelledMessage",
    "Dimension",
    "EndpointDetected",
    "EvidenceRef",
    "FRAME_SAMPLES_20MS_16KHZ",
    "FinalMessage",
    "IntegrityFlag",
    "ParticipantID",
    "PartialMessage",
    "PartialUtterance",
    "Phase",
    "ProsodyEvent",
    "RunningScore",
    "SAMPLE_RATE_HZ",
    "SessionState",
    "SpeakRequest",
    "Speaker",
    "SpeechEnd",
    "SpeechStart",
    "TAOverride",
    "TranscribeStart",
    "Turn",
    "Word",
    "decode_audio_frame",
    "encode_audio_frame",
]
