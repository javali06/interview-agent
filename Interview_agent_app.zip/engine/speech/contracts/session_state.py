"""Session state schema per §4.3.

Stream A authors this initially; Stream C takes ownership at C-01 without breaking
imports — the surface below matches the SSOT verbatim.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from uuid import UUID

from pydantic import BaseModel, Field


class Phase(str, Enum):
    JOIN_CHECK = "join_check"
    WARM_UP = "warm_up"
    PROJECT_DEEP_DIVE = "project_deep_dive"
    PROGRAMMING = "programming"
    SYSTEM_DESIGN = "system_design"
    CANDIDATE_QA = "candidate_qa"
    WRAP_UP = "wrap_up"


class Speaker(str, Enum):
    CANDIDATE = "candidate"
    INTERVIEWER = "interviewer"
    AI = "ai"
    UNKNOWN = "unknown"


class Turn(BaseModel):
    turn_id: str
    speaker: Speaker
    text: str
    start_ms: int
    end_ms: int
    confidence: float = Field(ge=0.0, le=1.0)
    audio_ref: str | None = None


class PartialUtterance(BaseModel):
    speaker: Speaker
    text: str
    started_ms: int
    words: list[dict] = Field(default_factory=list)


class Dimension(str, Enum):
    TECHNICAL_DEPTH = "technical_depth"
    PROBLEM_SOLVING = "problem_solving"
    COMMUNICATION = "communication"
    SYSTEM_THINKING = "system_thinking"
    CODE_QUALITY = "code_quality"


class RunningScore(BaseModel):
    dimension: Dimension
    score: float = Field(ge=0.0, le=5.0)
    confidence: float = Field(ge=0.0, le=1.0)
    evidence_ids: list[str] = Field(default_factory=list)


class EvidenceRef(BaseModel):
    evidence_id: str
    turn_id: str
    quote: str
    dimension: Dimension
    note: str


class IntegrityFlag(BaseModel):
    flag_id: str
    raised_at: datetime
    kind: str
    severity: str
    evidence: dict


class TAOverride(BaseModel):
    override_id: str
    kind: str
    reason: str
    actioned_at: datetime


class SessionState(BaseModel):
    schema_version: str = "v1"
    session_id: UUID
    candidate_id: UUID
    ta_id: UUID
    phase: Phase
    phase_started_at: datetime
    phase_budget_seconds: int
    turns: list[Turn] = Field(default_factory=list)
    current_utterance: PartialUtterance | None = None
    rolling_summary: str = ""
    rubric_scores: dict[Dimension, RunningScore] = Field(default_factory=dict)
    evidence_refs: list[EvidenceRef] = Field(default_factory=list)
    active_flags: list[IntegrityFlag] = Field(default_factory=list)
    risk_score: float = 0.0
    ta_overrides: list[TAOverride] = Field(default_factory=list)
    last_updated_at: datetime
    last_checkpoint_at: datetime
