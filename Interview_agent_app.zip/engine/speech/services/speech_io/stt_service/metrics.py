"""Prometheus metrics for STT service. Names match §17.1."""

from __future__ import annotations

from prometheus_client import Counter, Histogram

from services.speech_io.common.metrics import REGISTRY

stt_partial_latency_ms = Histogram(
    "stt_partial_latency_ms",
    "Wall-clock ms between frame arrival and partial emission.",
    buckets=(50, 100, 200, 300, 400, 500, 600, 800, 1000, 1500, 2000),
    registry=REGISTRY,
)

stt_final_latency_ms = Histogram(
    "stt_final_latency_ms",
    "Wall-clock ms between endpoint_detected and final emission.",
    buckets=(50, 100, 200, 300, 500, 800, 1200, 2000, 4000),
    registry=REGISTRY,
)

stt_finals_total = Counter(
    "stt_finals_total",
    "Finals emitted per session.",
    ["session_id"],
    registry=REGISTRY,
)

stt_partials_total = Counter(
    "stt_partials_total",
    "Partials emitted per session.",
    ["session_id"],
    registry=REGISTRY,
)

stt_model_load_duration_seconds = Histogram(
    "stt_model_load_duration_seconds",
    "Time to load the STT model at service start.",
    buckets=(0.5, 1, 2, 5, 10, 30, 60),
    registry=REGISTRY,
)

stt_frames_dropped_total = Counter(
    "stt_frames_dropped_total",
    "Frames dropped under backpressure.",
    registry=REGISTRY,
)
