"""VAD-gated chunker that turns a PCM stream into partials + finals.

Design:
- Caller feeds PCM frames (via `feed`) and three classes of VAD events:
    `on_speech_start()` — opens the gate; subsequent `feed()` calls buffer audio
    `on_speech_end()`   — closes the gate; further frames are dropped, but the
                          buffer is preserved until endpoint fires
    `on_endpoint()`     — silence-tail reached; emit final and reset
- A background loop fires every `partial_interval_ms`, runs the STT engine on the
  active buffer, and emits a PartialMessage. Partials only fire while in_speech
  is True — we never ask the engine to transcribe silence.

Why this matters:
- Audio LLMs like Gemini hallucinate plausible speech when given silence (e.g.
  "I'm a software engineer..." returned for 30s of quiet). Gating eliminates
  the silence input entirely and prevents the hallucination.
- Without gating, the ring buffer accumulates everything from the last reset
  onwards, including all the silence between utterances. That's wasted tokens
  on every Gemini call.

Endpoint preemption:
- The tick loop awaits the endpoint event with a timeout. If endpoint fires at any
  time during the interval, we drop the pending partial timer and emit a final
  immediately. This means a 1s utterance followed by VAD silence-tail emits its
  final right after the silence tail — we do NOT wait for the next scheduled
  partial tick (important when partial_interval_ms is large, e.g. 5000ms for Gemini).
- If an `_emit_partial_now` is already in flight when endpoint fires, we let it
  finish (worst case: one extra in-flight STT call) and then emit the final.

Pause/resume: `pause()` stops partial emission but continues buffering so the final
after `resume()` includes the full utterance.
"""

from __future__ import annotations

import asyncio
import time
import uuid
from collections.abc import Awaitable, Callable
from dataclasses import dataclass

import numpy as np

from contracts.stt_messages import FinalMessage, PartialMessage, TranscribeStart, Word
from services.speech_io.common.audio import PCMRingBuffer, samples_to_ms
from services.speech_io.common.logging import get_logger
from services.speech_io.stt_service.engine import STTEngine
from services.speech_io.stt_service.metrics import (
    stt_final_latency_ms,
    stt_finals_total,
    stt_partial_latency_ms,
    stt_partials_total,
)

log = get_logger(__name__)

PartialEmitter = Callable[[PartialMessage], Awaitable[None]]
FinalEmitter = Callable[[FinalMessage], Awaitable[None]]
TranscribeStartEmitter = Callable[[TranscribeStart], Awaitable[None]]


@dataclass(slots=True)
class StreamingConfig:
    partial_interval_ms: int = 300
    min_partial_samples_ms: int = 500
    max_partial_context_ms: int = 8000
    min_final_confidence: float = 0.45
    # When False, no partial transcriptions are run. Only `endpoint_detected`
    # triggers a Gemini/Whisper call (a final). Saves engine calls and money
    # at the cost of "live caption" latency on the TA console.
    partials_enabled: bool = True


class StreamingSTT:
    def __init__(
        self,
        session_id: str,
        engine: STTEngine,
        emit_partial: PartialEmitter,
        emit_final: FinalEmitter,
        cfg: StreamingConfig,
        sample_rate: int = 16_000,
        emit_transcribe_start: TranscribeStartEmitter | None = None,
    ) -> None:
        self._session_id = session_id
        self._engine = engine
        self._emit_partial = emit_partial
        self._emit_final = emit_final
        self._emit_transcribe_start = emit_transcribe_start
        self._cfg = cfg
        self._sample_rate = sample_rate
        capacity = sample_rate * cfg.max_partial_context_ms // 1000
        self._buf = PCMRingBuffer(capacity)
        self._utterance_start_ms: int | None = None
        self._utterance_id: str | None = None
        self._endpoint_event = asyncio.Event()
        # ts_ms (in audio coordinates) when VAD says the candidate stopped
        # speaking. Used to trim trailing silence_tail audio from the buffer
        # before submitting to the engine — otherwise Whisper sees ~1.5s of
        # exact zero-padding at the end and emits an empty transcript.
        self._pending_endpoint_ts_ms: int | None = None
        self._paused = False
        self._stop = asyncio.Event()
        self._tick_task: asyncio.Task | None = None
        # Serialises transcribe calls so partials and finals don't race on the engine.
        self._engine_lock = asyncio.Lock()
        # VAD gate. Frames fed while in_speech=False are dropped; partials are
        # only emitted while in_speech=True. Endpoint always processes regardless.
        self._in_speech: bool = False

    async def start(self) -> None:
        self._tick_task = asyncio.create_task(self._tick_loop())

    async def stop(self) -> None:
        self._stop.set()
        if self._tick_task:
            await self._tick_task

    def feed(self, samples: np.ndarray, frame_ts_ms: int) -> None:
        # VAD gate: drop frames received outside the speech window. Without this
        # we'd be sending silence to the STT engine, which (for audio LLMs like
        # Gemini) leads to hallucinated transcripts.
        if not self._in_speech:
            return
        if self._utterance_start_ms is None:
            self._utterance_start_ms = frame_ts_ms
            self._utterance_id = str(uuid.uuid4())
        self._buf.write(samples)

    def on_speech_start(self, ts_ms: int | None = None) -> None:
        """VAD detected speech starting. Open the gate."""
        self._in_speech = True
        log.debug("stt.gate.open", ts_ms=ts_ms)

    def on_speech_end(self, ts_ms: int | None = None) -> None:
        """VAD detected speech ending — but DON'T close the gate. We keep
        buffering the silence between speech_end and either (a) the next
        speech_start (mid-utterance pause) or (b) endpoint_detected. This
        preserves acoustic continuity within an utterance, which Whisper-style
        ASR needs to transcribe accurately. Cross-utterance silence is still
        dropped because the gate only goes True on speech_start, and only
        becomes False inside _emit_final_now after endpoint commits."""
        log.debug("stt.gate.speech_end", ts_ms=ts_ms)

    def on_endpoint(self, ts_ms: int | None = None) -> None:
        # ts_ms here is the moment SPEECH STOPPED (per VAD). The endpoint event
        # itself fires silence_tail_ms later, so we use ts_ms to trim the
        # silence-tail audio off the buffer before submission.
        self._pending_endpoint_ts_ms = ts_ms
        self._endpoint_event.set()

    def pause(self) -> None:
        self._paused = True

    def resume(self) -> None:
        self._paused = False

    @property
    def in_speech(self) -> bool:
        return self._in_speech

    async def _tick_loop(self) -> None:
        # Partials disabled? Just wait on the endpoint event indefinitely.
        if not self._cfg.partials_enabled:
            while not self._stop.is_set():
                await asyncio.wait(
                    {asyncio.create_task(self._endpoint_event.wait()),
                     asyncio.create_task(self._stop.wait())},
                    return_when=asyncio.FIRST_COMPLETED,
                )
                if self._stop.is_set():
                    return
                self._endpoint_event.clear()
                await self._emit_final_now()
            return

        interval = self._cfg.partial_interval_ms / 1000
        min_samples = self._sample_rate * self._cfg.min_partial_samples_ms // 1000
        while not self._stop.is_set():
            try:
                await asyncio.wait_for(self._endpoint_event.wait(), timeout=interval)
                self._endpoint_event.clear()
                await self._emit_final_now()
            except asyncio.TimeoutError:
                if self._paused or self._buf.size < min_samples:
                    continue
                if self._endpoint_event.is_set():
                    continue
                if not self._in_speech:
                    # No active speech — don't burn engine calls on silence.
                    continue
                await self._emit_partial_now()

    async def _emit_partial_now(self) -> None:
        if self._utterance_start_ms is None:
            return
        audio = self._buf.peek(self._buf.size)
        if self._emit_transcribe_start and self._utterance_id:
            await self._emit_transcribe_start(TranscribeStart(
                kind="partial",
                trigger="partial_timer",
                audio_ms=audio.size * 1000 // self._sample_rate,
                utterance_id=self._utterance_id,
            ))
        async with self._engine_lock:
            if self._endpoint_event.is_set():
                # Endpoint beat us to the lock — let _emit_final_now handle it.
                return
            t0 = time.perf_counter()
            try:
                tr = await self._engine.transcribe(audio, self._utterance_start_ms)
            except Exception as e:
                log.warning("stt.partial.error", error=str(e))
                return
            stt_partial_latency_ms.observe((time.perf_counter() - t0) * 1000)
        stt_partials_total.labels(session_id=self._session_id).inc()
        await self._emit_partial(PartialMessage(text=tr.text, words=tr.words))

    async def _emit_final_now(self) -> None:
        if self._utterance_start_ms is None or self._utterance_id is None:
            return
        audio = self._buf.peek(self._buf.size)
        # If VAD told us when speech actually stopped, trim the trailing
        # silence_tail audio off the buffer. Without this, faster-whisper
        # sees ~1.5s of exact zero-padding at the end of every utterance and
        # often returns an empty transcript (no_speech_prob spikes).
        if (
            self._pending_endpoint_ts_ms is not None
            and self._utterance_start_ms is not None
        ):
            speech_ms = self._pending_endpoint_ts_ms - self._utterance_start_ms
            if 0 < speech_ms:
                keep_samples = speech_ms * self._sample_rate // 1000
                if 0 < keep_samples < audio.size:
                    audio = audio[:keep_samples]
        if audio.size == 0:
            self._reset_utterance()
            return
        if self._emit_transcribe_start:
            await self._emit_transcribe_start(TranscribeStart(
                kind="final",
                trigger="endpoint",
                audio_ms=audio.size * 1000 // self._sample_rate,
                utterance_id=self._utterance_id,
            ))
        async with self._engine_lock:
            t0 = time.perf_counter()
            try:
                tr = await self._engine.transcribe(audio, self._utterance_start_ms)
            except Exception as e:
                log.warning("stt.final.error", error=str(e))
                self._reset_utterance()
                return
            stt_final_latency_ms.observe((time.perf_counter() - t0) * 1000)
        stt_finals_total.labels(session_id=self._session_id).inc()
        duration_ms = samples_to_ms(len(audio), self._sample_rate)
        final = FinalMessage(
            text=tr.text,
            words=tr.words,
            utterance_id=self._utterance_id,
            start_ms=self._utterance_start_ms,
            end_ms=self._utterance_start_ms + duration_ms,
            confidence=tr.confidence,
        )
        await self._emit_final(final)
        self._reset_utterance()

    def _reset_utterance(self) -> None:
        self._buf.clear()
        self._utterance_start_ms = None
        self._utterance_id = None
        self._pending_endpoint_ts_ms = None
        # Close the gate; will reopen on the next speech_start.
        self._in_speech = False


# Re-export Word for callers building test fixtures.
__all__ = ["StreamingConfig", "StreamingSTT", "Word"]
