"""A-01 STT WebSocket service on :8010.

Contract: §4.2 STT block.
  Client → server: binary PCM frames (§4.1 direction 1) + pause/resume JSON.
  Server → client: PartialMessage / FinalMessage JSON.

Endpointing is the responsibility of the VAD service (A-02); the STT client
is expected to forward an {"type":"endpoint_detected"} message whenever its
paired VAD emits one. This keeps STT free of VAD coupling inside the service.
"""

from __future__ import annotations

import os
from pathlib import Path

from fastapi import WebSocket, WebSocketDisconnect
from pydantic import ValidationError

from contracts.stt_messages import FinalMessage, PartialMessage, TranscribeStart
from contracts.wire_formats import decode_audio_frame
from services.speech_io.common.audio import pcm16_to_float32
from services.speech_io.common.config import load_yaml
from services.speech_io.common.logging import configure_logging, get_logger
from services.speech_io.common.state_stub import get_state
from services.speech_io.common.ws_server import make_app
from services.speech_io.stt_service.engine import build_engine_from_config
from services.speech_io.stt_service.metrics import stt_frames_dropped_total
from services.speech_io.stt_service.streaming import StreamingConfig, StreamingSTT

configure_logging("stt_service")
log = get_logger(__name__)

_CFG_PATH = Path(__file__).parent / "config.yaml"
_CFG = load_yaml(_CFG_PATH)

# Env overrides so you can flip backends without editing the yaml. Useful for
# interview_sim.py and CI runs.
if (backend := os.environ.get("STT_BACKEND")):
    _CFG.setdefault("engine", {})["backend"] = backend
if (interval := os.environ.get("STT_PARTIAL_INTERVAL_MS")):
    _CFG.setdefault("streaming", {})["partial_interval_ms"] = int(interval)
if (min_samples := os.environ.get("STT_MIN_PARTIAL_SAMPLES_MS")):
    _CFG.setdefault("streaming", {})["min_partial_samples_ms"] = int(min_samples)
if (max_ctx := os.environ.get("STT_MAX_PARTIAL_CONTEXT_MS")):
    _CFG.setdefault("streaming", {})["max_partial_context_ms"] = int(max_ctx)
if (raw := os.environ.get("STT_PARTIALS_ENABLED")) is not None:
    _CFG.setdefault("streaming", {})["partials_enabled"] = (
        raw.strip().lower() in {"1", "true", "yes", "on"}
    )

_ENGINE = build_engine_from_config(_CFG)
_STREAM_CFG = StreamingConfig(
    partial_interval_ms=int(_CFG["streaming"]["partial_interval_ms"]),
    min_partial_samples_ms=int(_CFG["streaming"]["min_partial_samples_ms"]),
    max_partial_context_ms=int(_CFG["streaming"]["max_partial_context_ms"]),
    min_final_confidence=float(_CFG["confidence"]["min_final_confidence"]),
    partials_enabled=bool(_CFG["streaming"].get("partials_enabled", True)),
)

# Single structured event capturing the EFFECTIVE configuration this service
# is running under. Scraped by run_interview_sim.sh after healthchecks pass.
log.info(
    "stt.config",
    backend=_CFG["engine"]["backend"],
    partials_enabled=_STREAM_CFG.partials_enabled,
    partial_interval_ms=_STREAM_CFG.partial_interval_ms,
    min_partial_samples_ms=_STREAM_CFG.min_partial_samples_ms,
    max_partial_context_ms=_STREAM_CFG.max_partial_context_ms,
    min_final_confidence=_STREAM_CFG.min_final_confidence,
    whisper_model_path=os.environ.get("WHISPER_MODEL_PATH") or None,
    whisper_device=os.environ.get("WHISPER_DEVICE") or None,
    whisper_compute_type=os.environ.get("WHISPER_COMPUTE_TYPE") or None,
    whisper_hf_model=os.environ.get("WHISPER_HF_MODEL") or None,
    openrouter_stt_model=os.environ.get("OPENROUTER_STT_MODEL") or None,
)


async def _handle(ws: WebSocket, session_id: str) -> None:
    state = get_state()
    log.info("stt.ws.open", session_id=session_id)

    async def emit_partial(msg: PartialMessage) -> None:
        await ws.send_text(msg.model_dump_json())

    async def emit_final(msg: FinalMessage) -> None:
        await ws.send_text(msg.model_dump_json())
        await state.append_turn(
            session_id,
            {
                "turn_id": msg.utterance_id,
                "speaker": "candidate",  # diarization (A-06) may overwrite later
                "text": msg.text,
                "start_ms": msg.start_ms,
                "end_ms": msg.end_ms,
                "confidence": msg.confidence,
            },
        )

    async def emit_transcribe_start(msg: TranscribeStart) -> None:
        await ws.send_text(msg.model_dump_json())

    streaming = StreamingSTT(
        session_id=session_id,
        engine=_ENGINE,
        emit_partial=emit_partial,
        emit_final=emit_final,
        emit_transcribe_start=emit_transcribe_start,
        cfg=_STREAM_CFG,
    )
    await streaming.start()
    try:
        while True:
            msg = await ws.receive()
            if msg.get("type") == "websocket.disconnect":
                break
            if (text := msg.get("text")) is not None:
                await _handle_control(text, streaming)
                continue
            if (data := msg.get("bytes")) is not None:
                try:
                    frame = decode_audio_frame(data)
                except ValueError as e:
                    stt_frames_dropped_total.inc()
                    log.warning("stt.frame.decode_error", error=str(e))
                    continue
                samples = pcm16_to_float32(frame.pcm)
                streaming.feed(samples, frame.frame_timestamp_ms)
    except WebSocketDisconnect:
        pass
    finally:
        await streaming.stop()
        log.info("stt.ws.close", session_id=session_id)


async def _handle_control(raw: str, streaming: StreamingSTT) -> None:
    import json

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        log.warning("stt.control.invalid_json", raw=raw[:100])
        return
    kind = payload.get("type")
    if kind == "pause":
        streaming.pause()
    elif kind == "resume":
        streaming.resume()
    elif kind == "speech_start":
        streaming.on_speech_start(payload.get("ts_ms"))
    elif kind == "speech_end":
        streaming.on_speech_end(payload.get("ts_ms"))
    elif kind == "endpoint_detected":
        streaming.on_endpoint(payload.get("ts_ms"))
    else:
        log.warning("stt.control.unknown", kind=kind)


app = make_app(
    service_name="stt_service",
    ws_path="/stt/{session_id}",
    handler=_handle,
)


def _main() -> None:
    import uvicorn

    uvicorn.run(
        "services.speech_io.stt_service.main:app",
        host=os.environ.get("STT_HOST", "0.0.0.0"),
        port=int(os.environ.get("STT_PORT", "8010")),
        log_level=os.environ.get("LOG_LEVEL", "info").lower(),
    )


if __name__ == "__main__":
    _main()
