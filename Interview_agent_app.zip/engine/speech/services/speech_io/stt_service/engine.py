"""STT engines behind a uniform async STTEngine protocol.

Backends shipped:

- FakeEngine: deterministic placeholder for CI. No network, no weights.
- FasterWhisperEngine: local Whisper via faster-whisper (CTranslate2). Requires
  WHISPER_MODEL_PATH + onnxruntime/ctranslate2 wheels for the running Python.
- WhisperHFEngine: local Whisper via the HuggingFace transformers pipeline.
  Default model openai/whisper-tiny — 39M params, ~75 MB, runs in real time on CPU.
  Has reliable word-level timestamps (Gemini doesn't).
- GeminiOpenRouterEngine: transcribes via OpenRouter's /chat/completions audio input.
  Utterance-level only — one blob per request, no streaming. Hallucinates on silence.

Switch via config.yaml `engine.backend` or the `STREAM_A_FAKE_BACKENDS` env var.
"""

from __future__ import annotations

import asyncio
import base64
import io
import json
import os
import re
import time
import wave
from dataclasses import dataclass
from typing import Protocol

import httpx
import numpy as np

from contracts.stt_messages import Word
from services.speech_io.common.audio import float32_to_pcm16
from services.speech_io.common.config import fake_backends_enabled
from services.speech_io.common.logging import get_logger
from services.speech_io.stt_service.metrics import stt_model_load_duration_seconds

log = get_logger(__name__)


@dataclass(frozen=True, slots=True)
class Transcription:
    text: str
    words: list[Word]
    confidence: float


class STTEngine(Protocol):
    async def transcribe(self, audio: np.ndarray, start_offset_ms: int) -> Transcription: ...


class FakeEngine:
    """Deterministic placeholder. 1 fake word per 400ms of audio."""

    async def transcribe(self, audio: np.ndarray, start_offset_ms: int) -> Transcription:
        duration_ms = int(len(audio) * 1000 / 16_000)
        n_words = max(1, duration_ms // 400)
        words: list[Word] = []
        per = max(1, duration_ms // n_words)
        for i in range(n_words):
            s = start_offset_ms + i * per
            words.append(Word(w=f"word{i}", start_ms=s, end_ms=s + per, conf=0.95))
        return Transcription(
            text=" ".join(w.w for w in words),
            words=words,
            confidence=0.95,
        )


def _detect_faster_whisper_device(requested_compute_type: str) -> tuple[str, str]:
    """Pick a (device, compute_type) pair that the installed CTranslate2 supports.

    Priority: CUDA → CPU. Macs use CPU because CTranslate2 wheels for macOS
    aren't compiled with CUDA. Compute type defaults are int8 on CPU and
    float16 on CUDA — both are good speed/quality trade-offs.
    """
    try:
        import ctranslate2  # noqa: local import

        if ctranslate2.get_cuda_device_count() > 0:
            return "cuda", (
                requested_compute_type if requested_compute_type != "auto" else "float16"
            )
    except Exception:
        pass
    return "cpu", (
        requested_compute_type if requested_compute_type != "auto" else "int8"
    )


class FasterWhisperEngine:
    """Real faster-whisper backend. Imported lazily so fake-mode CI doesn't pull torch."""

    def __init__(self, model_path: str, device: str, compute_type: str, beam_size: int) -> None:
        from faster_whisper import WhisperModel  # noqa: local import

        if device == "auto":
            device, compute_type = _detect_faster_whisper_device(compute_type)
        t0 = time.perf_counter()
        self._model = WhisperModel(model_path, device=device, compute_type=compute_type)
        stt_model_load_duration_seconds.observe(time.perf_counter() - t0)
        self._beam_size = beam_size
        log.info(
            "stt.model_loaded",
            model_path=model_path, device=device, compute_type=compute_type,
        )

    async def transcribe(self, audio: np.ndarray, start_offset_ms: int) -> Transcription:
        # faster-whisper is sync + CPU/GPU bound — offload to a thread.
        return await asyncio.to_thread(self._transcribe_sync, audio, start_offset_ms)

    def _dump_audio(self, audio: np.ndarray, start_offset_ms: int, dump_dir: str) -> None:
        import os as _os
        import wave as _wave

        _os.makedirs(dump_dir, exist_ok=True)
        path = _os.path.join(dump_dir, f"submit_{start_offset_ms:07d}ms_{int(audio.size)}samples.wav")
        pcm = (np.clip(audio, -1.0, 1.0) * 32767).astype("<i2").tobytes()
        with _wave.open(path, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(16_000)
            w.writeframes(pcm)
        log.info("stt.whisper.dumped", path=path, samples=int(audio.size))

    def _transcribe_sync(self, audio: np.ndarray, start_offset_ms: int) -> Transcription:
        # Optional: dump the exact audio that faster-whisper sees, for debugging
        # empty-result issues. Enable with WHISPER_DUMP_AUDIO_DIR=/tmp/stt_audio.
        if (dump_dir := os.environ.get("WHISPER_DUMP_AUDIO_DIR")):
            self._dump_audio(audio, start_offset_ms, dump_dir)

        # Plain faster-whisper transcribe. No vad_filter, no threshold tuning —
        # those experiments didn't help and risked introducing hallucinations
        # ("CHAPTER XII." on a misheard intro). Use a bigger model for accuracy
        # rather than tweaking decoder thresholds.
        segments, info = self._model.transcribe(
            audio,
            beam_size=self._beam_size,
            word_timestamps=True,
            vad_filter=False,
        )
        seg_list = list(segments)
        if not seg_list:
            log.warning(
                "stt.whisper.empty_segments",
                duration_s=round(audio.size / 16_000, 2),
                language=getattr(info, "language", None),
                language_prob=getattr(info, "language_probability", None),
            )
        words: list[Word] = []
        text_parts: list[str] = []
        for seg in seg_list:
            text_parts.append(seg.text)
            if not seg.words:
                continue
            for w in seg.words:
                words.append(
                    Word(
                        w=w.word.strip(),
                        start_ms=start_offset_ms + int((w.start or 0.0) * 1000),
                        end_ms=start_offset_ms + int((w.end or 0.0) * 1000),
                        conf=float(w.probability or 1.0),
                    )
                )
        confidence = float(np.mean([w.conf for w in words])) if words else 1.0
        return Transcription(
            text="".join(text_parts).strip(),
            words=words,
            confidence=confidence,
        )


class WhisperHFEngine:
    """OpenAI Whisper via HuggingFace transformers.

    Defaults to openai/whisper-tiny (39M params, ~75 MB) which transcribes faster
    than realtime on CPU. Bigger sizes (base, small, medium, large-v3) give
    higher accuracy at the cost of latency.

    Imported lazily so that fake-mode CI doesn't pull torch/transformers.
    """

    def __init__(
        self,
        model_id: str = "openai/whisper-tiny",
        device: str = "auto",
        language: str = "en",
        chunk_length_s: float = 30.0,
    ) -> None:
        import torch  # noqa: local import
        from transformers import (  # noqa: local import
            AutoModelForSpeechSeq2Seq,
            AutoProcessor,
            pipeline,
        )

        if device == "auto":
            device = "cuda:0" if torch.cuda.is_available() else "cpu"
        torch_dtype = torch.float16 if device.startswith("cuda") else torch.float32

        t0 = time.perf_counter()
        model = AutoModelForSpeechSeq2Seq.from_pretrained(
            model_id, torch_dtype=torch_dtype, low_cpu_mem_usage=True
        )
        model.to(device)
        processor = AutoProcessor.from_pretrained(model_id)
        self._pipe = pipeline(
            "automatic-speech-recognition",
            model=model,
            tokenizer=processor.tokenizer,
            feature_extractor=processor.feature_extractor,
            torch_dtype=torch_dtype,
            device=device,
        )
        stt_model_load_duration_seconds.observe(time.perf_counter() - t0)
        self._language = language
        self._chunk_length_s = chunk_length_s
        log.info(
            "stt.whisper.loaded",
            model=model_id,
            device=device,
            load_seconds=round(time.perf_counter() - t0, 2),
        )

    async def transcribe(
        self, audio: np.ndarray, start_offset_ms: int
    ) -> Transcription:
        # transformers' pipeline is synchronous; offload to a worker thread.
        return await asyncio.to_thread(self._transcribe_sync, audio, start_offset_ms)

    def _transcribe_sync(
        self, audio: np.ndarray, start_offset_ms: int
    ) -> Transcription:
        result = self._pipe(
            audio.astype(np.float32),
            return_timestamps="word",
            chunk_length_s=self._chunk_length_s,
            generate_kwargs={"language": self._language, "task": "transcribe"},
        )
        text = (result.get("text") or "").strip()
        words: list[Word] = []
        for chunk in result.get("chunks", []) or []:
            ts = chunk.get("timestamp") or (None, None)
            ws, we = ts[0], ts[1]
            if ws is None:
                continue
            we = we if we is not None else ws  # word at clip end has open-ended ts
            words.append(
                Word(
                    w=(chunk.get("text") or "").strip(),
                    start_ms=start_offset_ms + int(ws * 1000),
                    end_ms=start_offset_ms + int(we * 1000),
                    conf=1.0,
                )
            )
        return Transcription(text=text, words=words, confidence=1.0)


_GEMINI_PROMPT = (
    "Transcribe the following audio verbatim. The speaker is an interview candidate "
    "speaking English, possibly with an Indian accent. Return STRICT JSON only — no "
    "prose before or after — with this exact shape:\n"
    '{"text": "<full transcript>"}\n'
    "Do not include timestamps. Do not wrap in code fences."
)


class GeminiOpenRouterEngine:
    """Transcribe via OpenRouter's Gemini audio-input API.

    Utterance-level: each transcribe() call sends the whole buffer as one WAV blob.
    Per the user's latency policy, callers schedule this every 5s as a "snapshot"
    partial, and the StreamingSTT endpoint event preempts the timer so finals fire
    immediately on VAD endpoint even if it's 1s into a 5s interval.

    Word timestamps are synthesised from utterance duration — Gemini does not
    return reliable word-level timing, and the prompt explicitly asks for text only.
    """

    def __init__(
        self,
        api_key: str,
        model: str = "google/gemini-2.5-flash",
        base_url: str = "https://openrouter.ai/api/v1",
        timeout_s: float = 30.0,
    ) -> None:
        if not api_key:
            raise ValueError("OpenRouter API key is empty")
        self._client = httpx.AsyncClient(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "HTTP-Referer": "https://interview-assist.local",
                "X-Title": "interview-assist Stream A STT",
            },
            timeout=timeout_s,
        )
        self._model = model
        log.info("stt.gemini.configured", model=model, base_url=base_url)

    async def transcribe(self, audio: np.ndarray, start_offset_ms: int) -> Transcription:
        wav_bytes = _float32_to_wav(audio, sample_rate=16_000)
        b64 = base64.b64encode(wav_bytes).decode("ascii")
        payload = {
            "model": self._model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": _GEMINI_PROMPT},
                        {
                            "type": "input_audio",
                            "input_audio": {"data": b64, "format": "wav"},
                        },
                    ],
                }
            ],
            "response_format": {"type": "json_object"},
            "temperature": 0.0,
        }
        t0 = time.perf_counter()
        resp = await self._client.post("/chat/completions", json=payload)
        elapsed_ms = (time.perf_counter() - t0) * 1000
        if resp.status_code != 200:
            log.warning(
                "stt.gemini.http_error",
                status=resp.status_code,
                body=resp.text[:500],
                elapsed_ms=elapsed_ms,
            )
            resp.raise_for_status()
        data = resp.json()
        raw = data["choices"][0]["message"]["content"]
        text = _parse_gemini_text(raw)
        duration_ms = int(len(audio) * 1000 / 16_000)
        words = _synthesize_words(text, start_offset_ms, duration_ms)
        log.debug(
            "stt.gemini.transcribed",
            chars=len(text),
            words=len(words),
            duration_ms=duration_ms,
            elapsed_ms=elapsed_ms,
        )
        # Confidence deliberately pinned to 1.0 until we revisit (user ticket).
        return Transcription(text=text, words=words, confidence=1.0)

    async def close(self) -> None:
        await self._client.aclose()


def _float32_to_wav(audio: np.ndarray, sample_rate: int) -> bytes:
    pcm = float32_to_pcm16(audio)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(pcm)
    return buf.getvalue()


_CODE_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```$", re.MULTILINE)


def _parse_gemini_text(raw: str) -> str:
    """Gemini occasionally wraps JSON in code fences or prose. Recover gracefully."""
    stripped = _CODE_FENCE_RE.sub("", raw).strip()
    try:
        obj = json.loads(stripped)
    except json.JSONDecodeError:
        return raw.strip()
    if isinstance(obj, dict) and isinstance(obj.get("text"), str):
        return obj["text"].strip()
    return stripped


def _synthesize_words(text: str, start_offset_ms: int, duration_ms: int) -> list[Word]:
    """Distribute tokens evenly across the utterance when the engine gives no timing."""
    tokens = text.split()
    if not tokens or duration_ms <= 0:
        return []
    per = max(1, duration_ms // len(tokens))
    return [
        Word(
            w=tok,
            start_ms=start_offset_ms + i * per,
            end_ms=start_offset_ms + (i + 1) * per,
            conf=1.0,
        )
        for i, tok in enumerate(tokens)
    ]


def build_engine_from_config(cfg: dict) -> STTEngine:
    backend = cfg.get("engine", {}).get("backend", "faster_whisper")
    if fake_backends_enabled() or backend == "fake":
        log.info("stt.engine", backend="fake")
        return FakeEngine()
    if backend == "faster_whisper":
        engine_cfg = cfg["engine"]
        return FasterWhisperEngine(
            model_path=os.environ[engine_cfg["model_path_env"]],
            device=os.environ.get(
                engine_cfg["device_env"],
                engine_cfg.get("default_device", "auto"),
            ),
            compute_type=os.environ.get(
                engine_cfg["compute_type_env"],
                engine_cfg.get("default_compute_type", "auto"),
            ),
            beam_size=int(engine_cfg.get("beam_size", 1)),
        )
    if backend == "whisper_hf":
        engine_cfg = cfg["engine"]
        model_id = os.environ.get(
            engine_cfg.get("hf_model_env", "WHISPER_HF_MODEL"),
            engine_cfg.get("default_hf_model", "openai/whisper-tiny"),
        )
        device = os.environ.get(
            engine_cfg.get("hf_device_env", "WHISPER_HF_DEVICE"),
            engine_cfg.get("default_hf_device", "auto"),
        )
        language = os.environ.get(
            engine_cfg.get("hf_language_env", "WHISPER_HF_LANGUAGE"),
            engine_cfg.get("default_hf_language", "en"),
        )
        return WhisperHFEngine(model_id=model_id, device=device, language=language)
    if backend == "gemini_openrouter":
        engine_cfg = cfg["engine"]
        api_key = os.environ.get(engine_cfg.get("api_key_env", "OPENROUTER_API_KEY"), "")
        model = os.environ.get(
            engine_cfg.get("model_env", "OPENROUTER_STT_MODEL"),
            engine_cfg.get("default_model", "google/gemini-2.5-flash"),
        )
        base_url = engine_cfg.get("base_url", "https://openrouter.ai/api/v1")
        timeout_s = float(engine_cfg.get("timeout_s", 30.0))
        return GeminiOpenRouterEngine(
            api_key=api_key, model=model, base_url=base_url, timeout_s=timeout_s
        )
    raise ValueError(f"unknown STT backend: {backend}")
