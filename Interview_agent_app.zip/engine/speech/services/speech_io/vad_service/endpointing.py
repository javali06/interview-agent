"""Endpointing state machine.

Combines silence tail with a pitch-drop heuristic. Inputs come from the VADDetector
(speech probability per frame) and a simple pitch tracker (autocorrelation-based).

State transitions, per frame:
  IDLE
    → speech_prob ≥ threshold for ≥ speech_start_hysteresis_ms  → SPEAKING (emit speech_start)
  SPEAKING
    → speech_prob < threshold                                   → COOLDOWN (tentative speech_end)
  COOLDOWN
    → speech_prob ≥ threshold                                   → SPEAKING (revoke pending endpoint)
    → sustained silence ≥ silence_tail_ms                        → IDLE (emit speech_end + endpoint_detected)

The pitch-drop signal boosts endpoint confidence but cannot trigger an endpoint on its own.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

import numpy as np


class State(str, Enum):
    IDLE = "idle"
    SPEAKING = "speaking"
    COOLDOWN = "cooldown"


@dataclass(frozen=True, slots=True)
class EndpointingConfig:
    silence_tail_ms: int = 600
    pitch_drop_threshold: float = 0.3
    min_utterance_ms: int = 200
    speech_start_hysteresis_ms: int = 120
    speech_threshold: float = 0.5


@dataclass(frozen=True, slots=True)
class EndpointDecision:
    speech_start_ms: int | None = None
    speech_end_ms: int | None = None
    endpoint_ms: int | None = None
    endpoint_confidence: float = 0.0
    false_endpoint: bool = False


class EndpointingFSM:
    def __init__(self, cfg: EndpointingConfig) -> None:
        self._cfg = cfg
        self._state = State.IDLE
        self._speech_run_ms = 0
        self._silence_run_ms = 0
        self._utterance_start_ms: int | None = None
        self._pending_endpoint_ms: int | None = None
        self._last_pitch_hz: float | None = None
        self._utterance_pitch_peak: float = 0.0

    @property
    def state(self) -> State:
        return self._state

    def tick(
        self,
        frame_ts_ms: int,
        frame_ms: int,
        speech_prob: float,
        pitch_hz: float | None,
    ) -> EndpointDecision:
        is_speech = speech_prob >= self._cfg.speech_threshold
        if is_speech:
            self._speech_run_ms += frame_ms
            self._silence_run_ms = 0
            if pitch_hz is not None and pitch_hz > self._utterance_pitch_peak:
                self._utterance_pitch_peak = pitch_hz
            self._last_pitch_hz = pitch_hz
        else:
            self._silence_run_ms += frame_ms
            self._speech_run_ms = 0

        if self._state is State.IDLE:
            if is_speech and self._speech_run_ms >= self._cfg.speech_start_hysteresis_ms:
                self._state = State.SPEAKING
                self._utterance_start_ms = max(0, frame_ts_ms - self._speech_run_ms)
                self._utterance_pitch_peak = pitch_hz or 0.0
                return EndpointDecision(speech_start_ms=self._utterance_start_ms)
            return EndpointDecision()

        if self._state is State.SPEAKING:
            if not is_speech:
                # Speech just paused. Emit speech_end immediately so STT can
                # close its buffer gate; the endpoint may or may not follow
                # depending on whether speech resumes within silence_tail_ms.
                self._state = State.COOLDOWN
                self._pending_endpoint_ms = frame_ts_ms
                return EndpointDecision(speech_end_ms=frame_ts_ms)
            return EndpointDecision()

        # COOLDOWN
        if is_speech:
            # Resumption inside the silence-tail window. Revoke the pending
            # endpoint and re-emit speech_start so consumers re-open their gates.
            revoked = self._pending_endpoint_ms is not None
            self._state = State.SPEAKING
            self._pending_endpoint_ms = None
            return EndpointDecision(speech_start_ms=frame_ts_ms, false_endpoint=revoked)

        if self._silence_run_ms >= self._cfg.silence_tail_ms:
            endpoint_ms = (
                self._pending_endpoint_ms
                if self._pending_endpoint_ms is not None
                else frame_ts_ms
            )
            start_ms = (
                self._utterance_start_ms
                if self._utterance_start_ms is not None
                else endpoint_ms
            )
            duration_ms = endpoint_ms - start_ms
            # Drop utterances shorter than min_utterance_ms.
            if duration_ms < self._cfg.min_utterance_ms:
                self._reset_idle()
                return EndpointDecision()
            conf = self._endpoint_confidence(pitch_hz)
            # Note: speech_end was already emitted at SPEAKING→COOLDOWN. Here we
            # only commit the endpoint.
            decision = EndpointDecision(
                endpoint_ms=endpoint_ms,
                endpoint_confidence=conf,
            )
            self._reset_idle()
            return decision
        return EndpointDecision()

    def _reset_idle(self) -> None:
        self._state = State.IDLE
        self._speech_run_ms = 0
        self._silence_run_ms = 0
        self._utterance_start_ms = None
        self._pending_endpoint_ms = None
        self._utterance_pitch_peak = 0.0
        self._last_pitch_hz = None

    def _endpoint_confidence(self, trailing_pitch_hz: float | None) -> float:
        """Base confidence 0.7; bump to 1.0 if pitch dropped ≥ threshold from peak."""
        base = 0.7
        if trailing_pitch_hz is None or self._utterance_pitch_peak <= 0:
            return base
        drop = 1.0 - (trailing_pitch_hz / self._utterance_pitch_peak)
        if drop >= self._cfg.pitch_drop_threshold:
            return min(1.0, base + 0.3)
        return base


def estimate_pitch_hz(frame: np.ndarray, sample_rate: int = 16_000) -> float | None:
    """Cheap autocorrelation pitch estimate, 80-400 Hz range. None if frame unvoiced."""
    if frame.size < 256:
        return None
    frame = frame - np.mean(frame)
    if np.max(np.abs(frame)) < 1e-3:
        return None
    min_lag = sample_rate // 400
    max_lag = sample_rate // 80
    max_lag = min(max_lag, len(frame) - 1)
    if max_lag <= min_lag:
        return None
    corr = np.correlate(frame, frame, mode="full")
    corr = corr[len(corr) // 2 :]
    window = corr[min_lag : max_lag + 1]
    if window.size == 0:
        return None
    best = int(np.argmax(window)) + min_lag
    if window[best - min_lag] < 0.2 * corr[0]:
        return None
    return sample_rate / best
