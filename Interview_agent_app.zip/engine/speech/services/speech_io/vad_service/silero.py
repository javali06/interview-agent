"""Silero ONNX wrapper.

FakeDetector returns a deterministic is-speech decision based on RMS energy — good
enough to drive the full pipeline in CI without a model.
"""

from __future__ import annotations

import os
from typing import Protocol

import numpy as np

from services.speech_io.common.config import fake_backends_enabled
from services.speech_io.common.logging import get_logger

log = get_logger(__name__)


class VADDetector(Protocol):
    def speech_probability(self, frame: np.ndarray) -> float: ...


class FakeDetector:
    """Energy-based stand-in. Speech iff RMS > threshold."""

    def __init__(self, rms_threshold: float = 0.01) -> None:
        self._t = rms_threshold

    def speech_probability(self, frame: np.ndarray) -> float:
        if frame.size == 0:
            return 0.0
        rms = float(np.sqrt(np.mean(frame**2)))
        return 1.0 if rms > self._t else 0.0


class SileroDetector:
    """Silero VAD via ONNX runtime. 16kHz, 512-sample chunks (~32ms).

    Supports both the legacy v3 schema (input, h, c, sr) and the current v4/v5
    schema (input, state, sr). The schema is detected from the model's declared
    inputs at load time. We feed 20ms frames; the detector buffers them into
    32ms chunks before each inference call.

    For v4/v5 the model expects the previous 64 samples of audio prepended to
    each 512-sample chunk as context. We maintain that context internally —
    callers just feed raw frames. (See silero_vad.utils_vad.OnnxWrapper for the
    reference implementation we mirror.)
    """

    _CHUNK_SAMPLES = 512
    _CONTEXT_SAMPLES = 64  # only for v4/v5

    # ONE onnxruntime session per model_path, SHARED across every per-connection
    # detector instance. The session is stateless — the LSTM state is passed in
    # and out of run() per call and held per-instance below — so sharing it is
    # safe (calls are serialized on the single event loop) and keeps building a
    # PER-CONNECTION detector cheap + memory flat as concurrency grows.
    _SESSIONS: dict = {}

    def __init__(self, model_path: str) -> None:
        import onnxruntime as ort

        # Reuse (or lazily create) the shared session for this model_path.
        # intra/inter_op = 1: onnxruntime otherwise sizes its thread pools to the
        # HOST core count (ignoring the container's cgroup quota) and thrashes on
        # a CPU-limited box — many threads fighting one allowed core make each
        # inference SLOWER. The model is tiny; one thread runs in ~1ms.
        sess = SileroDetector._SESSIONS.get(model_path)
        if sess is None:
            _so = ort.SessionOptions()
            _so.intra_op_num_threads = 1
            _so.inter_op_num_threads = 1
            sess = ort.InferenceSession(
                model_path, sess_options=_so, providers=["CPUExecutionProvider"],
            )
            SileroDetector._SESSIONS[model_path] = sess
        self._sess = sess
        input_names = {i.name for i in self._sess.get_inputs()}
        if "state" in input_names:
            # v4/v5: combined state tensor + 64-sample context window.
            self._schema = "v4"
            self._state = np.zeros((2, 1, 128), dtype=np.float32)
            self._context = np.zeros(self._CONTEXT_SAMPLES, dtype=np.float32)
        else:
            # v3 legacy: separate h and c LSTM tensors, no audio context.
            self._schema = "v3"
            self._h = np.zeros((2, 1, 64), dtype=np.float32)
            self._c = np.zeros((2, 1, 64), dtype=np.float32)
        self._sr = np.array(16_000, dtype=np.int64)
        self._carry = np.empty(0, dtype=np.float32)
        # Last inferred probability — returned for frames that arrive between
        # 512-sample inference windows (since callers feed 320-sample frames).
        # Returning the held value keeps the FSM's speech_run_ms counter
        # accumulating continuously instead of resetting every other frame.
        self._last_prob: float = 0.0
        log.info("vad.silero.loaded", model_path=model_path, schema=self._schema)

    def speech_probability(self, frame: np.ndarray) -> float:
        self._carry = np.concatenate([self._carry, frame])
        if len(self._carry) < self._CHUNK_SAMPLES:
            return self._last_prob
        chunk = self._carry[: self._CHUNK_SAMPLES]
        self._carry = self._carry[self._CHUNK_SAMPLES :]

        if self._schema == "v4":
            x = np.concatenate([self._context, chunk]).reshape(1, -1).astype(np.float32)
            prob, self._state = self._sess.run(
                None, {"input": x, "state": self._state, "sr": self._sr}
            )
            # Save the tail of THIS chunk as context for the next call.
            self._context = chunk[-self._CONTEXT_SAMPLES :].copy()
        else:
            x = chunk.reshape(1, -1).astype(np.float32)
            prob, self._h, self._c = self._sess.run(
                None,
                {"input": x, "h": self._h, "c": self._c, "sr": self._sr},
            )
        self._last_prob = float(prob[0][0])
        return self._last_prob


def build_detector_from_config(cfg: dict) -> VADDetector:
    backend = cfg.get("engine", {}).get("backend", "silero")
    if fake_backends_enabled() or backend == "fake":
        log.info("vad.detector", backend="fake")
        return FakeDetector()
    if backend == "silero":
        model_path = os.environ.get(cfg["engine"]["model_path_env"])
        if not model_path:
            raise RuntimeError(
                f"Silero backend selected but {cfg['engine']['model_path_env']} is unset"
            )
        return SileroDetector(model_path)
    raise ValueError(f"unknown VAD backend: {backend}")
