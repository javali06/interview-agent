"""A-02 VAD WebSocket service on :8011.

Contract: §4.2 VAD block.
  Client → server: binary PCM frames (§4.1 direction 1).
  Server → client: SpeechStart | SpeechEnd | EndpointDetected JSON.

State mirrored into stub storage (§7.4 `session:{id}:vad`) so barge-in coordinator
can read without an extra WS hop.
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path

from fastapi import WebSocket, WebSocketDisconnect

from contracts.vad_messages import EndpointDetected, SpeechEnd, SpeechStart
from contracts.wire_formats import decode_audio_frame
from services.speech_io.common.audio import pcm16_to_float32
from services.speech_io.common.config import load_yaml
from services.speech_io.common.logging import configure_logging, get_logger
from services.speech_io.common.state_stub import get_state
from services.speech_io.common.ws_server import make_app
from services.speech_io.vad_service.endpointing import (
    EndpointingConfig,
    EndpointingFSM,
    estimate_pitch_hz,
)
from services.speech_io.vad_service.metrics import (
    vad_endpoint_detected_latency_ms,
    vad_events_total,
    vad_false_endpoints_total,
    vad_speech_start_latency_ms,
)
from services.speech_io.vad_service.silero import build_detector_from_config

configure_logging("vad_service")
log = get_logger(__name__)

_CFG_PATH = Path(__file__).parent / "config.yaml"
_CFG = load_yaml(_CFG_PATH)
# Warm the shared ONNX session at import so the first interview doesn't pay the
# model-load on its hot path. Detectors themselves are built PER CONNECTION in
# _handle() — each interview needs its OWN VAD state (carry buffer + LSTM hidden
# state); a single shared detector interleaves audio from every concurrent
# session and corrupts their endpointing. Per-connection detectors reuse this
# warmed session (see silero.py), so constructing one is cheap.
build_detector_from_config(_CFG)
_ENDPOINT_CFG = EndpointingConfig(
    silence_tail_ms=int(_CFG["endpointing"]["silence_tail_ms"]),
    pitch_drop_threshold=float(_CFG["endpointing"]["pitch_drop_threshold"]),
    min_utterance_ms=int(_CFG["endpointing"]["min_utterance_ms"]),
    speech_start_hysteresis_ms=int(_CFG["cadence"]["speech_start_hysteresis_ms"]),
    speech_threshold=float(_CFG["engine"]["speech_threshold"]),
)
_FRAME_MS = int(_CFG["cadence"]["frame_ms"])

log.info(
    "vad.config",
    backend=_CFG["engine"]["backend"],
    silero_model_path=os.environ.get("SILERO_MODEL_PATH") or None,
    silence_tail_ms=_ENDPOINT_CFG.silence_tail_ms,
    speech_start_hysteresis_ms=_ENDPOINT_CFG.speech_start_hysteresis_ms,
    min_utterance_ms=_ENDPOINT_CFG.min_utterance_ms,
    speech_threshold=_ENDPOINT_CFG.speech_threshold,
    pitch_drop_threshold=_ENDPOINT_CFG.pitch_drop_threshold,
    frame_ms=_FRAME_MS,
)


def _analyze_frame(detector, samples):
    """Silero ONNX inference + pitch estimate — the synchronous CPU work per
    frame. Pulled into a helper so it can run via asyncio.to_thread and never
    block the VAD service's single event loop (which must stay free to accept new
    connections and pump other sessions). onnxruntime releases the GIL during Run,
    so concurrent frames parallelize across cores."""
    return detector.speech_probability(samples), estimate_pitch_hz(samples)


async def _handle(ws: WebSocket, session_id: str) -> None:
    state = get_state()
    fsm = EndpointingFSM(_ENDPOINT_CFG)
    # Per-connection detector: isolated VAD state (carry buffer + LSTM hidden
    # state) so concurrent interviews never corrupt each other's endpointing.
    # Cheap — reuses the process-wide shared ONNX session (see silero.py).
    detector = build_detector_from_config(_CFG)
    log.info("vad.ws.open", session_id=session_id)
    try:
        while True:
            msg = await ws.receive()
            if msg.get("type") == "websocket.disconnect":
                break
            if (data := msg.get("bytes")) is None:
                continue
            try:
                frame = decode_audio_frame(data)
            except ValueError as e:
                log.warning("vad.frame.decode_error", error=str(e))
                continue
            samples = pcm16_to_float32(frame.pcm)
            # Run the synchronous Silero + pitch work OFF the event loop so one
            # busy interview can't head-of-line-block the loop from accepting new
            # connections or pumping other sessions' frames (the concurrency
            # ceiling behind slow 2nd-interview starts). Per-connection detector +
            # sequential awaits mean no concurrent use of one detector's state.
            prob, pitch = await asyncio.to_thread(_analyze_frame, detector, samples)
            decision = fsm.tick(frame.frame_timestamp_ms, _FRAME_MS, prob, pitch)

            if decision.speech_start_ms is not None:
                evt = SpeechStart(ts_ms=decision.speech_start_ms)
                await ws.send_text(evt.model_dump_json())
                vad_events_total.labels(kind="speech_start").inc()
                vad_speech_start_latency_ms.observe(
                    frame.frame_timestamp_ms - decision.speech_start_ms
                )
                await state.set_vad(session_id, speech_start=decision.speech_start_ms)

            if decision.speech_end_ms is not None:
                await ws.send_text(SpeechEnd(ts_ms=decision.speech_end_ms).model_dump_json())
                vad_events_total.labels(kind="speech_end").inc()
                await state.set_vad(session_id, speech_end=decision.speech_end_ms)

            if decision.endpoint_ms is not None:
                evt = EndpointDetected(
                    ts_ms=decision.endpoint_ms,
                    confidence=decision.endpoint_confidence,
                )
                await ws.send_text(evt.model_dump_json())
                vad_events_total.labels(kind="endpoint_detected").inc()
                vad_endpoint_detected_latency_ms.observe(
                    frame.frame_timestamp_ms - decision.endpoint_ms
                )
                await state.set_vad(session_id, last_endpoint_ms=decision.endpoint_ms)

            if decision.false_endpoint:
                vad_false_endpoints_total.inc()
                log.debug("vad.false_endpoint", session_id=session_id)
    except WebSocketDisconnect:
        pass
    finally:
        log.info("vad.ws.close", session_id=session_id)


app = make_app(service_name="vad_service", ws_path="/vad/{session_id}", handler=_handle)


def _main() -> None:
    import uvicorn

    uvicorn.run(
        "services.speech_io.vad_service.main:app",
        host=os.environ.get("VAD_HOST", "0.0.0.0"),
        port=int(os.environ.get("VAD_PORT", "8011")),
        log_level=os.environ.get("LOG_LEVEL", "info").lower(),
    )


if __name__ == "__main__":
    _main()
