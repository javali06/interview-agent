"""Prometheus metrics for the VAD service. Names match §17.1."""

from __future__ import annotations

from prometheus_client import Counter, Histogram

from services.speech_io.common.metrics import REGISTRY

vad_speech_start_latency_ms = Histogram(
    "vad_speech_start_latency_ms",
    "Ms between actual speech onset and speech_start emission.",
    buckets=(20, 50, 80, 100, 120, 150, 200, 300, 500),
    registry=REGISTRY,
)

vad_endpoint_detected_latency_ms = Histogram(
    "vad_endpoint_detected_latency_ms",
    "Ms between utterance end and endpoint_detected emission.",
    buckets=(100, 200, 400, 600, 800, 1000, 1500, 2000),
    registry=REGISTRY,
)

vad_false_endpoints_total = Counter(
    "vad_false_endpoints_total",
    "Endpoints later revoked because speech resumed within silence_tail_ms.",
    registry=REGISTRY,
)

vad_events_total = Counter(
    "vad_events_total",
    "VAD events by kind.",
    ["kind"],
    registry=REGISTRY,
)
