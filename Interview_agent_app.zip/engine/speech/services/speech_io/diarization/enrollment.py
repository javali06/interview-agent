"""Voiceprint enrollment.

During JOIN_CHECK the TA stays muted; we accumulate candidate-alone PCM until we
have `candidate_alone_duration_ms`, then compute an embedding that becomes the
canonical candidate voiceprint for the rest of the session.

FakeEnroller uses the mean RMS of the buffer as a trivial "embedding" — same
interface as the real one, good enough for wiring tests.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import numpy as np


@dataclass(slots=True)
class Voiceprint:
    """Opaque vector plus the frames used to build it."""

    vector: np.ndarray
    enrolled_ms: int


class Embedder(Protocol):
    def embed(self, audio: np.ndarray) -> np.ndarray: ...


class FakeEmbedder:
    """Trivial 1-D embedding from RMS; distinct voices won't collide because the
    test harness injects different signals."""

    def embed(self, audio: np.ndarray) -> np.ndarray:
        if audio.size == 0:
            return np.zeros(1, dtype=np.float32)
        rms = float(np.sqrt(np.mean(audio**2)))
        return np.array([rms], dtype=np.float32)


class Enroller:
    def __init__(self, embedder: Embedder, target_duration_ms: int, sample_rate: int = 16_000) -> None:
        self._embedder = embedder
        self._target_samples = sample_rate * target_duration_ms // 1000
        self._samples: list[np.ndarray] = []
        self._sample_rate = sample_rate
        self._done = False
        self._voiceprint: Voiceprint | None = None

    @property
    def ready(self) -> bool:
        return self._done

    @property
    def voiceprint(self) -> Voiceprint | None:
        return self._voiceprint

    def feed(self, audio: np.ndarray) -> bool:
        """Return True if enrollment just completed on this call."""
        if self._done:
            return False
        self._samples.append(audio)
        total = sum(s.size for s in self._samples)
        if total >= self._target_samples:
            concat = np.concatenate(self._samples)[: self._target_samples]
            vec = self._embedder.embed(concat)
            enrolled_ms = self._target_samples * 1000 // self._sample_rate
            self._voiceprint = Voiceprint(vector=vec, enrolled_ms=enrolled_ms)
            self._done = True
            self._samples.clear()
            return True
        return False


def cosine(a: np.ndarray, b: np.ndarray) -> float:
    na = float(np.linalg.norm(a))
    nb = float(np.linalg.norm(b))
    if na == 0 or nb == 0:
        return 0.0
    return float(np.dot(a, b) / (na * nb))
