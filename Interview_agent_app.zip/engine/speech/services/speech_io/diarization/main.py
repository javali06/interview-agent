"""A-06 realtime diarization service.

Contract (additive — §4.2 doesn't nail this one down):
  Client → server: binary PCM frames + JSON control:
                   {"type":"enroll_candidate"} — start/continue enrollment
                   {"type":"end_enroll"}       — stop enrollment, begin classification
  Server → client: {"type":"enrolled", "enrolled_ms": int}
                   {"type":"utterance_speaker",
                    "utterance_id": str, "speaker": "candidate|interviewer|unknown",
                    "confidence": float}

Real pyannote runs only when backend = "pyannote" and the `diarization` extra is
installed; otherwise FakeEmbedder runs so the rest of Stream A can exercise the
wiring.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
from fastapi import WebSocket, WebSocketDisconnect

from contracts.wire_formats import decode_audio_frame
from services.speech_io.common.audio import pcm16_to_float32
from services.speech_io.common.config import fake_backends_enabled, load_yaml
from services.speech_io.common.logging import configure_logging, get_logger
from services.speech_io.common.state_stub import get_state
from services.speech_io.common.ws_server import make_app
from services.speech_io.diarization.enrollment import (
    Embedder,
    Enroller,
    FakeEmbedder,
    cosine,
)

configure_logging("diarization")
log = get_logger(__name__)

_CFG_PATH = Path(__file__).parent / "config.yaml"
_CFG = load_yaml(_CFG_PATH)


def _build_embedder() -> Embedder:
    backend = _CFG["engine"]["backend"]
    if fake_backends_enabled() or backend == "fake":
        log.info("diarization.embedder", backend="fake")
        return FakeEmbedder()
    if backend == "pyannote":
        # Real pyannote is an optional extra — lazy import so fake mode stays light.
        try:
            from pyannote.audio import Model  # noqa: F401
        except ImportError as e:
            raise RuntimeError(
                "pyannote backend requires `pip install -e '.[diarization]'`"
            ) from e
        raise NotImplementedError(
            "Pyannote streaming embedder wiring is left as a TODO — fixtures required"
        )
    raise ValueError(f"unknown diarization backend: {backend}")


_EMBEDDER = _build_embedder()


async def _handle(ws: WebSocket, session_id: str) -> None:
    state = get_state()
    enroller = Enroller(
        embedder=_EMBEDDER,
        target_duration_ms=int(_CFG["enrollment"]["candidate_alone_duration_ms"]),
    )
    threshold = float(_CFG["classification"]["cosine_threshold"])
    current_utterance: list[np.ndarray] = []
    current_utterance_id: str | None = None
    enrolling = False
    log.info("diarization.ws.open", session_id=session_id)
    try:
        while True:
            msg = await ws.receive()
            if msg.get("type") == "websocket.disconnect":
                break
            if (text := msg.get("text")) is not None:
                try:
                    payload = json.loads(text)
                except json.JSONDecodeError:
                    continue
                kind = payload.get("type")
                if kind == "enroll_candidate":
                    enrolling = True
                elif kind == "end_enroll":
                    enrolling = False
                elif kind == "utterance_start":
                    current_utterance = []
                    current_utterance_id = payload.get("utterance_id")
                elif kind == "utterance_end":
                    await _classify_and_emit(
                        ws, state, session_id, current_utterance,
                        current_utterance_id, enroller, threshold,
                    )
                    current_utterance = []
                    current_utterance_id = None
                continue
            if (data := msg.get("bytes")) is None:
                continue
            try:
                frame = decode_audio_frame(data)
            except ValueError:
                continue
            samples = pcm16_to_float32(frame.pcm)
            if enrolling and not enroller.ready:
                if enroller.feed(samples):
                    await ws.send_text(json.dumps({
                        "type": "enrolled",
                        "enrolled_ms": enroller.voiceprint.enrolled_ms,
                    }))
            else:
                current_utterance.append(samples)
    except WebSocketDisconnect:
        pass
    finally:
        log.info("diarization.ws.close", session_id=session_id)


async def _classify_and_emit(
    ws: WebSocket,
    state,
    session_id: str,
    utterance_pcm: list[np.ndarray],
    utterance_id: str | None,
    enroller: Enroller,
    threshold: float,
) -> None:
    if not utterance_pcm or utterance_id is None:
        return
    audio = np.concatenate(utterance_pcm)
    if not enroller.ready or enroller.voiceprint is None:
        speaker = "unknown"
        confidence = 0.0
    else:
        emb = _EMBEDDER.embed(audio)
        similarity = cosine(emb, enroller.voiceprint.vector)
        if similarity >= threshold:
            speaker = "candidate"
            confidence = similarity
        else:
            speaker = "interviewer"
            confidence = 1.0 - similarity
    await ws.send_text(json.dumps({
        "type": "utterance_speaker",
        "utterance_id": utterance_id,
        "speaker": speaker,
        "confidence": confidence,
    }))
    await state.append_flag(
        session_id,
        {
            "kind": "speaker_label",
            "severity": "info",
            "evidence": {
                "utterance_id": utterance_id,
                "speaker": speaker,
                "confidence": confidence,
            },
        },
    )


app = make_app(
    service_name="diarization",
    ws_path="/diarization/{session_id}",
    handler=_handle,
)


def _main() -> None:
    import uvicorn

    uvicorn.run(
        "services.speech_io.diarization.main:app",
        host=os.environ.get("DIARIZATION_HOST", "0.0.0.0"),
        port=int(os.environ.get("DIARIZATION_PORT", "8015")),
        log_level=os.environ.get("LOG_LEVEL", "info").lower(),
    )


if __name__ == "__main__":
    _main()
