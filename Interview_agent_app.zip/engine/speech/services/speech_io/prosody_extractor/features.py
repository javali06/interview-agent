"""Per-utterance prosody features derived from STT word timestamps + PCM.

No second decode (§5.4 A-05): we take the word timings the STT already produced
and compute inter-word pauses from them. Pitch comes from a cheap autocorrelation
tracker over the utterance's PCM — optional; if no audio is provided the pitch
fields are zero.
"""

from __future__ import annotations

from collections.abc import Iterable

import numpy as np

from contracts.prosody_messages import ProsodyFeatures
from contracts.stt_messages import Word
from services.speech_io.vad_service.endpointing import estimate_pitch_hz


def compute(
    words: list[Word],
    audio: np.ndarray | None = None,
    sample_rate: int = 16_000,
    pitch_frame_ms: int = 40,
) -> ProsodyFeatures:
    if not words:
        return ProsodyFeatures(
            words_per_minute=0.0,
            inter_word_pause_ms_mean=0.0,
            inter_word_pause_ms_std=0.0,
            pitch_hz_mean=0.0,
            pitch_hz_std=0.0,
            utterance_duration_ms=0,
            word_count=0,
        )
    start_ms = min(w.start_ms for w in words)
    end_ms = max(w.end_ms for w in words)
    duration_ms = max(1, end_ms - start_ms)
    wpm = len(words) * 60_000 / duration_ms

    pauses = _inter_word_pauses_ms(words)
    pause_mean = float(np.mean(pauses)) if pauses else 0.0
    pause_std = float(np.std(pauses)) if pauses else 0.0

    pitch_mean, pitch_std = _pitch_stats(audio, sample_rate, pitch_frame_ms)

    return ProsodyFeatures(
        words_per_minute=wpm,
        inter_word_pause_ms_mean=pause_mean,
        inter_word_pause_ms_std=pause_std,
        pitch_hz_mean=pitch_mean,
        pitch_hz_std=pitch_std,
        utterance_duration_ms=duration_ms,
        word_count=len(words),
    )


def _inter_word_pauses_ms(words: Iterable[Word]) -> list[float]:
    ws = sorted(words, key=lambda w: w.start_ms)
    out: list[float] = []
    for prev, cur in zip(ws, ws[1:], strict=False):
        gap = cur.start_ms - prev.end_ms
        if gap >= 0:
            out.append(float(gap))
    return out


def _pitch_stats(
    audio: np.ndarray | None, sample_rate: int, frame_ms: int
) -> tuple[float, float]:
    if audio is None or audio.size == 0:
        return 0.0, 0.0
    win = sample_rate * frame_ms // 1000
    if win <= 0 or audio.size < win:
        return 0.0, 0.0
    estimates: list[float] = []
    for start in range(0, audio.size - win + 1, win):
        hz = estimate_pitch_hz(audio[start : start + win], sample_rate)
        if hz is not None:
            estimates.append(hz)
    if not estimates:
        return 0.0, 0.0
    return float(np.mean(estimates)), float(np.std(estimates))
