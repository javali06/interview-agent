"""A-05 prosody extractor service.

Subscribes to the STT WebSocket for a session, extracts a ProsodyEvent on each
final, and emits it to downstream subscribers. Stream B consumes these later.

Contract: one ProsodyEvent per completed utterance (§5.4 A-05 acceptance).
"""

from __future__ import annotations

import json
import os
from pathlib import Path

from fastapi import WebSocket, WebSocketDisconnect

from contracts.prosody_messages import ProsodyEvent
from contracts.stt_messages import FinalMessage
from services.speech_io.common.config import load_yaml
from services.speech_io.common.logging import configure_logging, get_logger
from services.speech_io.common.ws_server import make_app
from services.speech_io.prosody_extractor.features import compute

configure_logging("prosody_extractor")
log = get_logger(__name__)

_CFG_PATH = Path(__file__).parent / "config.yaml"
_CFG = load_yaml(_CFG_PATH)


async def _handle(ws: WebSocket, session_id: str) -> None:
    """Client pushes FinalMessage JSONs in; server pushes ProsodyEvent JSONs back.

    This lets any service (not just STT) feed us finals without needing a Redis
    subscription until Stream C lands.
    """
    log.info("prosody.ws.open", session_id=session_id)
    try:
        while True:
            msg = await ws.receive_text()
            try:
                payload = json.loads(msg)
            except json.JSONDecodeError:
                log.warning("prosody.bad_json", raw=msg[:100])
                continue
            if payload.get("type") != "final":
                continue
            try:
                final = FinalMessage.model_validate(payload)
            except Exception as e:
                log.warning("prosody.invalid_final", error=str(e))
                continue
            features = compute(final.words)
            event = ProsodyEvent(
                session_id=session_id,
                utterance_id=final.utterance_id,
                speaker="candidate",
                features=features,
            )
            await ws.send_text(event.model_dump_json())
    except WebSocketDisconnect:
        pass
    finally:
        log.info("prosody.ws.close", session_id=session_id)


app = make_app(
    service_name="prosody_extractor",
    ws_path="/prosody/{session_id}",
    handler=_handle,
)


def _main() -> None:
    import uvicorn

    uvicorn.run(
        "services.speech_io.prosody_extractor.main:app",
        host=os.environ.get("PROSODY_HOST", "0.0.0.0"),
        port=int(os.environ.get("PROSODY_PORT", "8014")),
        log_level=os.environ.get("LOG_LEVEL", "info").lower(),
    )


if __name__ == "__main__":
    _main()
