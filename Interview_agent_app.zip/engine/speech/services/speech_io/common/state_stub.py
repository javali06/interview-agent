"""In-memory session-state stub.

Stream A needs *somewhere* to write Turns and read VAD/TTS state while Stream C's
Redis adapter is not yet available. Keys mirror §7.4 so the swap is mechanical:
when C-02 lands, replace this module's import site with the Redis adapter and
no service logic changes.
"""

from __future__ import annotations

import asyncio
from collections import defaultdict
from collections.abc import AsyncIterator
from typing import Any


class InMemoryStateStub:
    """Per-process stand-in for session:{id}:* keys in §7.4."""

    def __init__(self) -> None:
        self._turns: dict[str, list[dict[str, Any]]] = defaultdict(list)
        self._vad: dict[str, dict[str, Any]] = defaultdict(dict)
        self._tts: dict[str, dict[str, Any]] = defaultdict(dict)
        self._flags: dict[str, list[dict[str, Any]]] = defaultdict(list)
        self._subs: dict[tuple[str, str], list[asyncio.Queue[dict[str, Any]]]] = defaultdict(list)
        self._lock = asyncio.Lock()

    # session:{id}:transcript
    async def append_turn(self, session_id: str, turn: dict[str, Any]) -> None:
        async with self._lock:
            self._turns[session_id].append(turn)
        await self._publish(session_id, "transcript", turn)

    async def get_turns(self, session_id: str) -> list[dict[str, Any]]:
        async with self._lock:
            return list(self._turns[session_id])

    # session:{id}:vad
    async def set_vad(self, session_id: str, **fields: Any) -> None:
        async with self._lock:
            self._vad[session_id].update(fields)
        await self._publish(session_id, "vad", dict(self._vad[session_id]))

    async def get_vad(self, session_id: str) -> dict[str, Any]:
        async with self._lock:
            return dict(self._vad[session_id])

    # session:{id}:tts
    async def set_tts(self, session_id: str, **fields: Any) -> None:
        async with self._lock:
            self._tts[session_id].update(fields)
        await self._publish(session_id, "tts", dict(self._tts[session_id]))

    async def get_tts(self, session_id: str) -> dict[str, Any]:
        async with self._lock:
            return dict(self._tts[session_id])

    # session:{id}:flags
    async def append_flag(self, session_id: str, flag: dict[str, Any]) -> None:
        async with self._lock:
            self._flags[session_id].append(flag)
        await self._publish(session_id, "flags", flag)

    # pub/sub, mirrors §7.3 subscriptions.py
    async def _publish(self, session_id: str, channel: str, payload: dict[str, Any]) -> None:
        for q in list(self._subs[(session_id, channel)]):
            await q.put(payload)

    async def subscribe(
        self, session_id: str, channel: str
    ) -> AsyncIterator[dict[str, Any]]:
        q: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        self._subs[(session_id, channel)].append(q)
        try:
            while True:
                yield await q.get()
        finally:
            self._subs[(session_id, channel)].remove(q)


_GLOBAL: InMemoryStateStub | None = None


def get_state() -> InMemoryStateStub:
    """Process-wide singleton. Replace call sites with Redis adapter at C-02."""
    global _GLOBAL
    if _GLOBAL is None:
        _GLOBAL = InMemoryStateStub()
    return _GLOBAL
