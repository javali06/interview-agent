"""YAML config loader. Each service owns its own config.yaml; this just parses it."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml


def load_yaml(path: str | Path) -> dict[str, Any]:
    with open(path) as f:
        return yaml.safe_load(f) or {}


def env_bool(name: str, default: bool = False) -> bool:
    raw = os.environ.get(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "on"}


def fake_backends_enabled() -> bool:
    """Single knob that flips STT/TTS/diarization into day-one fake mode."""
    return env_bool("STREAM_A_FAKE_BACKENDS", default=True)
