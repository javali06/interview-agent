"""FastAPI+WebSocket boilerplate reused by every Stream A service."""

from __future__ import annotations

from collections.abc import Awaitable, Callable

from fastapi import FastAPI, WebSocket

from services.speech_io.common.metrics import metrics_app

WebSocketHandler = Callable[[WebSocket, str], Awaitable[None]]


def make_app(
    service_name: str,
    ws_path: str,
    handler: WebSocketHandler,
) -> FastAPI:
    """Build a FastAPI app with /healthz, /metrics, and one WS endpoint.

    ws_path MUST contain a {session_id} placeholder (§4.2).
    """
    if "{session_id}" not in ws_path:
        raise ValueError("ws_path must include a {session_id} placeholder per §4.2")

    app = FastAPI(title=service_name)
    app.mount("/metrics", metrics_app())

    @app.get("/healthz")
    async def healthz() -> dict[str, str]:
        return {"status": "ok", "service": service_name}

    @app.websocket(ws_path)
    async def ws_endpoint(ws: WebSocket, session_id: str) -> None:
        await ws.accept()
        await handler(ws, session_id)

    return app
