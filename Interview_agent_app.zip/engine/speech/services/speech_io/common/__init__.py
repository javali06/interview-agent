"""Helpers shared across every Stream A service. No service-specific logic."""
