"""PCM16 helpers and a lock-free ring buffer used across Stream A services."""

from __future__ import annotations

import numpy as np

from contracts.wire_formats import SAMPLE_RATE_HZ


def pcm16_to_float32(pcm: bytes) -> np.ndarray:
    """Little-endian PCM16 bytes → float32 samples in [-1, 1]."""
    if len(pcm) % 2 != 0:
        raise ValueError("PCM byte length must be even")
    ints = np.frombuffer(pcm, dtype="<i2")
    return ints.astype(np.float32) / 32768.0


def float32_to_pcm16(samples: np.ndarray) -> bytes:
    """float32 in [-1, 1] → little-endian PCM16 bytes."""
    clipped = np.clip(samples, -1.0, 1.0)
    ints = (clipped * 32767.0).astype("<i2")
    return ints.tobytes()


def samples_to_ms(n_samples: int, sample_rate: int = SAMPLE_RATE_HZ) -> int:
    return n_samples * 1000 // sample_rate


def ms_to_samples(ms: int, sample_rate: int = SAMPLE_RATE_HZ) -> int:
    return ms * sample_rate // 1000


class PCMRingBuffer:
    """Fixed-capacity ring buffer for float32 mono audio.

    Single-producer single-consumer pattern (we call it from one asyncio task).
    """

    def __init__(self, capacity_samples: int) -> None:
        self._buf = np.zeros(capacity_samples, dtype=np.float32)
        self._capacity = capacity_samples
        self._size = 0
        self._read_idx = 0
        self._write_idx = 0

    @property
    def size(self) -> int:
        return self._size

    @property
    def capacity(self) -> int:
        return self._capacity

    def write(self, samples: np.ndarray) -> int:
        """Write samples; drop oldest on overflow (§4.1 backpressure policy)."""
        n = len(samples)
        if n >= self._capacity:
            samples = samples[-self._capacity :]
            n = self._capacity
            self._buf[:] = samples
            self._read_idx = 0
            self._write_idx = 0
            self._size = self._capacity
            return n

        # Possibly overwriting unread samples. Advance read_idx first.
        overflow = (self._size + n) - self._capacity
        if overflow > 0:
            self._read_idx = (self._read_idx + overflow) % self._capacity
            self._size -= overflow

        end = self._write_idx + n
        if end <= self._capacity:
            self._buf[self._write_idx : end] = samples
        else:
            first = self._capacity - self._write_idx
            self._buf[self._write_idx :] = samples[:first]
            self._buf[: n - first] = samples[first:]
        self._write_idx = end % self._capacity
        self._size += n
        return n

    def read(self, n: int) -> np.ndarray:
        """Drain at most n samples from the head. Returns a fresh array."""
        n = min(n, self._size)
        if n == 0:
            return np.empty(0, dtype=np.float32)
        end = self._read_idx + n
        if end <= self._capacity:
            out = self._buf[self._read_idx : end].copy()
        else:
            first = self._capacity - self._read_idx
            out = np.concatenate(
                [self._buf[self._read_idx :], self._buf[: n - first]]
            )
        self._read_idx = end % self._capacity
        self._size -= n
        return out

    def peek(self, n: int) -> np.ndarray:
        """Copy the oldest n samples without draining."""
        n = min(n, self._size)
        if n == 0:
            return np.empty(0, dtype=np.float32)
        end = self._read_idx + n
        if end <= self._capacity:
            return self._buf[self._read_idx : end].copy()
        first = self._capacity - self._read_idx
        return np.concatenate([self._buf[self._read_idx :], self._buf[: n - first]])

    def clear(self) -> None:
        self._size = 0
        self._read_idx = 0
        self._write_idx = 0
