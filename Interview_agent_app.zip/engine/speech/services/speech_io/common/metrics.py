"""Shared Prometheus registry + helpers. Every service mounts /metrics via metrics_app()."""

from __future__ import annotations

from prometheus_client import CollectorRegistry, make_asgi_app

REGISTRY = CollectorRegistry()


def metrics_app():
    """ASGI app that serves the registry at /metrics."""
    return make_asgi_app(registry=REGISTRY)
