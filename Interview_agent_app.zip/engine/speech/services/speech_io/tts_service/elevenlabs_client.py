"""ElevenLabs streaming client.

Real backend: POSTs to /v1/text-to-speech/{voice}/stream with PCM output format,
then yields PCM chunks as they arrive over the HTTPX response stream.

Fake backend: synthesises a 440Hz tone proportional to the text length so the
pipeline produces real-looking audio in CI without a network call.
"""

from __future__ import annotations

import asyncio
import math
import os
import struct
from collections.abc import AsyncIterator
from typing import Protocol

import httpx

from services.speech_io.common.config import fake_backends_enabled
from services.speech_io.common.logging import get_logger

log = get_logger(__name__)


class TTSClient(Protocol):
    async def stream(
        self, text: str, voice_id: str, sample_rate: int
    ) -> AsyncIterator[bytes]: ...


class FakeClient:
    """440 Hz tone, one 20ms chunk at a time."""

    async def stream(
        self, text: str, voice_id: str, sample_rate: int
    ) -> AsyncIterator[bytes]:
        n_chunks = max(5, len(text) // 3)
        samples_per_chunk = sample_rate * 20 // 1000
        for i in range(n_chunks):
            chunk = bytearray(samples_per_chunk * 2)
            for n in range(samples_per_chunk):
                t = (i * samples_per_chunk + n) / sample_rate
                val = int(16000 * math.sin(2 * math.pi * 440 * t))
                struct.pack_into("<h", chunk, n * 2, val)
            yield bytes(chunk)
            await asyncio.sleep(0.005)  # emulate ~5ms between chunks


class ElevenLabsClient:
    def __init__(
        self,
        api_key: str,
        model_id: str,
        base_url: str = "https://api.elevenlabs.io",
        timeout: float = 30.0,
    ) -> None:
        self._api_key = api_key
        self._model_id = model_id
        self._base_url = base_url.rstrip("/")
        self._client = httpx.AsyncClient(timeout=timeout)

    async def stream(
        self, text: str, voice_id: str, sample_rate: int
    ) -> AsyncIterator[bytes]:
        url = f"{self._base_url}/v1/text-to-speech/{voice_id}/stream"
        headers = {"xi-api-key": self._api_key, "accept": "audio/pcm"}
        params = {"output_format": f"pcm_{sample_rate}"}
        payload = {"text": text, "model_id": self._model_id}
        async with self._client.stream(
            "POST", url, headers=headers, params=params, json=payload
        ) as resp:
            resp.raise_for_status()
            async for chunk in resp.aiter_bytes():
                if chunk:
                    yield chunk

    async def close(self) -> None:
        await self._client.aclose()


def build_client_from_config(cfg: dict) -> TTSClient:
    backend = cfg.get("engine", {}).get("backend", "elevenlabs")
    if fake_backends_enabled() or backend == "fake":
        log.info("tts.client", backend="fake")
        return FakeClient()
    if backend == "elevenlabs":
        api_key = os.environ.get(cfg["engine"]["api_key_env"], "")
        model_id = os.environ.get(cfg["engine"]["model_id_env"], "eleven_turbo_v2_5")
        if not api_key:
            raise RuntimeError("ElevenLabs backend selected but ELEVENLABS_API_KEY is unset")
        return ElevenLabsClient(
            api_key=api_key,
            model_id=model_id,
            base_url=cfg["engine"]["base_url"],
        )
    if backend == "kokoro":
        from services.speech_io.tts_service.kokoro_client import KokoroClient

        engine_cfg = cfg["engine"]
        lang_code = os.environ.get(
            engine_cfg.get("lang_code_env", "KOKORO_LANG_CODE"),
            engine_cfg.get("default_lang_code", "a"),
        )
        voice_id = os.environ.get(
            engine_cfg.get("voice_id_env", "KOKORO_VOICE_ID"),
            engine_cfg.get("default_voice_id", "af_heart"),
        )
        return KokoroClient(lang_code=lang_code, default_voice_id=voice_id)
    raise ValueError(f"unknown TTS backend: {backend}")
