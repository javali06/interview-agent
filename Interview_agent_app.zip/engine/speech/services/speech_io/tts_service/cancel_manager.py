"""Tracks active TTS requests by request_id and flips an abort event on cancel.

Every synthesis task checks `is_cancelled(request_id)` between audio chunks. When
cancel is called, the event flips and the next chunk check returns True —
synthesis stops within the period of one chunk (typically <= 40ms).
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field


@dataclass(slots=True)
class Request:
    request_id: str
    abort: asyncio.Event = field(default_factory=asyncio.Event)


class CancelManager:
    def __init__(self) -> None:
        self._requests: dict[str, Request] = {}
        # Modified by STREAM_A_B_Integration:
        # When TTSSender broadcasts cancels for all sub-IDs of the current
        # turn (e.g. on barge-in), some of those sub-IDs may correspond to
        # speaks that are still queued (not yet registered by their
        # `_run_speak` worker). Without this set, those cancels are silently
        # dropped and the queued speaks proceed to synthesise + play audio
        # the candidate explicitly cancelled.
        # We remember the rejected IDs and pre-set the abort flag at
        # register time. The worker's `is_cancelled` check then aborts
        # immediately on the first synth chunk, before any audio frames
        # are sent.
        self._rejected_ids: set[str] = set()
        self._lock = asyncio.Lock()

    async def register(self, request_id: str) -> Request:
        async with self._lock:
            if request_id in self._requests:
                raise ValueError(f"request_id {request_id} already registered")
            req = Request(request_id=request_id)
            if request_id in self._rejected_ids:
                # This ID was cancelled before it was registered — pre-abort.
                req.abort.set()
                self._rejected_ids.discard(request_id)
            self._requests[request_id] = req
            return req

    async def cancel(self, request_id: str) -> bool:
        async with self._lock:
            req = self._requests.get(request_id)
            if req is None:
                # Not yet registered — remember this so register() pre-aborts.
                self._rejected_ids.add(request_id)
                return False
            req.abort.set()
            return True

    async def finish(self, request_id: str) -> None:
        async with self._lock:
            self._requests.pop(request_id, None)
            # Defensive: if a rejected_id never gets registered (e.g. the
            # speak was popped from the queue some other way), don't let
            # the set grow unbounded.
            self._rejected_ids.discard(request_id)

    def is_cancelled(self, request_id: str) -> bool:
        req = self._requests.get(request_id)
        return req is not None and req.abort.is_set()

    async def cancel_all(self) -> None:
        async with self._lock:
            for req in self._requests.values():
                req.abort.set()
