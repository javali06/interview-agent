"""Prometheus metrics for TTS service. Names match §17.1."""

from __future__ import annotations

from prometheus_client import Counter, Histogram

from services.speech_io.common.metrics import REGISTRY

tts_first_byte_ms = Histogram(
    "tts_first_byte_ms",
    "Ms from speak request to first audio chunk emitted.",
    buckets=(50, 100, 200, 300, 400, 500, 700, 1000, 1500, 2000),
    registry=REGISTRY,
)

tts_cancel_latency_ms = Histogram(
    "tts_cancel_latency_ms",
    "Ms from cancel request to last audio chunk emitted.",
    buckets=(10, 25, 50, 75, 100, 150, 200, 300, 500),
    registry=REGISTRY,
)

tts_underruns_total = Counter(
    "tts_underruns_total",
    "Output stalls where TTS produced < 1 frame for > 100ms.",
    registry=REGISTRY,
)

tts_requests_total = Counter(
    "tts_requests_total",
    "Speak requests by outcome.",
    ["outcome"],
    registry=REGISTRY,
)
