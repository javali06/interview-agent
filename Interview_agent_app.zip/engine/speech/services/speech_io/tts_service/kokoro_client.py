"""Kokoro-82M local TTS client.

Kokoro is a ~82M-param Apache-2.0 TTS model that runs fast on CPU. This wrapper:

- Builds a KPipeline once per service (heavy — don't recreate per request).
- For each speak request, runs KPipeline synchronously in a worker thread
  (Kokoro has no native async) and resamples its 24 kHz output down to the
  16 kHz our wire format uses.
- Yields PCM16 bytes chunk-by-chunk. Chunks are roughly one sentence each —
  Kokoro batches synthesis per sentence, so first-byte latency is "time to
  synthesise the first sentence" (typically 100–200ms on CPU).

Accent note: Kokoro has no Indian-English voice. We default to American
English with `af_heart` (Kokoro's most-natural American female voice);
swap to MeloTTS or XTTS when accent fidelity becomes required.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator

import numpy as np

from services.speech_io.common.audio import float32_to_pcm16
from services.speech_io.common.logging import get_logger

log = get_logger(__name__)

_KOKORO_NATIVE_SR = 24_000


class KokoroClient:
    def __init__(
        self,
        lang_code: str = "a",            # 'a'=AmEn, 'b'=BrEn, 'h'=Hindi, etc.
        default_voice_id: str = "af_heart",
    ) -> None:
        try:
            from kokoro import KPipeline  # local import so the dep is optional
        except ImportError as e:
            raise RuntimeError(
                "Kokoro backend requires `pip install -e '.[kokoro]'` "
                "and system-level espeak-ng (brew install espeak-ng)."
            ) from e
        self._pipeline = KPipeline(lang_code=lang_code)
        self._default_voice_id = default_voice_id
        log.info("tts.kokoro.ready", lang_code=lang_code, default_voice=default_voice_id)

    async def stream(
        self, text: str, voice_id: str, sample_rate: int
    ) -> AsyncIterator[bytes]:
        voice = voice_id or self._default_voice_id
        # Kokoro is a sync generator — we run it in a worker thread but pull
        # one sentence at a time and yield its PCM immediately. This makes
        # first-byte latency "time to synthesise the first sentence" instead
        # of "time to synthesise the whole utterance".
        loop = asyncio.get_running_loop()
        queue: asyncio.Queue[np.ndarray | None] = asyncio.Queue()

        # split_pattern controls Kokoro's internal chunking. Default is `\n+` which
        # treats a whole paragraph as one chunk — that kills streaming latency on
        # multi-sentence prompts. Splitting on `.`, `?`, `!` (followed by whitespace)
        # gives us per-sentence yields so first-byte = time to synthesise the
        # first sentence, not the whole thing.
        split_pattern = r"[.!?]+\s+|\n+"

        def producer() -> None:
            try:
                for _graphemes, _phonemes, audio in self._pipeline(
                    text, voice=voice, split_pattern=split_pattern
                ):
                    arr = _to_numpy_float32(audio)
                    chunk_16k = _resample_linear(arr, _KOKORO_NATIVE_SR, 16_000)
                    asyncio.run_coroutine_threadsafe(queue.put(chunk_16k), loop)
            finally:
                asyncio.run_coroutine_threadsafe(queue.put(None), loop)

        loop.run_in_executor(None, producer)
        while True:
            chunk_16k = await queue.get()
            if chunk_16k is None:
                return
            chunk_out = (
                chunk_16k if sample_rate == 16_000
                else _resample_linear(chunk_16k, 16_000, sample_rate)
            )
            yield float32_to_pcm16(chunk_out)


def _to_numpy_float32(audio) -> np.ndarray:
    """Kokoro returns a torch tensor. Convert without forcing a torch import here."""
    if hasattr(audio, "detach"):
        audio = audio.detach().cpu().numpy()
    arr = np.asarray(audio, dtype=np.float32).reshape(-1)
    # Clamp — Kokoro occasionally emits values slightly outside [-1, 1].
    return np.clip(arr, -1.0, 1.0)


def _resample_linear(audio: np.ndarray, src_sr: int, dst_sr: int) -> np.ndarray:
    """Simple linear resampler. Good enough for speech; upgrade to scipy if needed."""
    if src_sr == dst_sr or audio.size == 0:
        return audio
    duration_s = audio.size / src_sr
    out_n = int(round(duration_s * dst_sr))
    if out_n <= 1:
        return np.zeros(0, dtype=np.float32)
    src_x = np.linspace(0.0, 1.0, audio.size, endpoint=False, dtype=np.float32)
    dst_x = np.linspace(0.0, 1.0, out_n, endpoint=False, dtype=np.float32)
    return np.interp(dst_x, src_x, audio).astype(np.float32)
