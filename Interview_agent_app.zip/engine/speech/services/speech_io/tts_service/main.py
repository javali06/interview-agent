"""A-03 TTS WebSocket service on :8012.

Contract: §4.2 TTS block.
  Client → server: speak / cancel JSON.
  Server → client: audio_start / audio_end / cancelled JSON + outbound PCM frames
                   framed per §4.1 direction 2.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path

from fastapi import WebSocket, WebSocketDisconnect
from pydantic import ValidationError

from contracts.tts_messages import (
    AudioEnd,
    AudioStart,
    CancelledMessage,
    CancelRequest,
    SpeakRequest,
)
from contracts.wire_formats import encode_tts_frame
from services.speech_io.common.config import load_yaml
from services.speech_io.common.logging import configure_logging, get_logger
from services.speech_io.common.state_stub import get_state
from services.speech_io.common.ws_server import make_app
from services.speech_io.tts_service.cancel_manager import CancelManager
from services.speech_io.tts_service.elevenlabs_client import build_client_from_config
from services.speech_io.tts_service.metrics import (
    tts_cancel_latency_ms,
    tts_first_byte_ms,
    tts_requests_total,
    tts_underruns_total,
)

configure_logging("tts_service")
log = get_logger(__name__)

_CFG_PATH = Path(__file__).parent / "config.yaml"
_CFG = load_yaml(_CFG_PATH)
_CLIENT = build_client_from_config(_CFG)
_SAMPLE_RATE = int(_CFG["audio"]["sample_rate"])
_FRAME_MS = int(_CFG["audio"]["frame_ms"])
_FRAME_BYTES = _SAMPLE_RATE * _FRAME_MS // 1000 * 2

log.info(
    "tts.config",
    backend=_CFG["engine"]["backend"],
    sample_rate=_SAMPLE_RATE,
    frame_ms=_FRAME_MS,
    kokoro_lang_code=os.environ.get("KOKORO_LANG_CODE")
        or _CFG["engine"].get("default_lang_code"),
    kokoro_voice_id=os.environ.get("KOKORO_VOICE_ID")
        or _CFG["engine"].get("default_voice_id"),
    elevenlabs_voice_id=os.environ.get("ELEVENLABS_VOICE_ID") or None,
    elevenlabs_model_id=os.environ.get("ELEVENLABS_MODEL_ID") or None,
    max_cancel_latency_ms=int(_CFG["cancel"]["max_cancel_latency_ms"]),
)


async def _handle(ws: WebSocket, session_id: str) -> None:
    """Receive control messages and dispatch speaks SERIALLY through a queue.

    Modified by STREAM_A_B_Integration: previously each speak was processed
    concurrently via `asyncio.create_task` (line 90 in upstream). With
    sentence-level chunking and unique sub-request_ids, multiple tasks ran
    Kokoro synthesis in parallel. Because audio frames from each task were
    sent over the same WebSocket, whichever Kokoro synth completed first
    won the wire — so a short S3 could ship before a slow S2, producing
    out-of-order playback (the candidate heard "S1, S3, S2").

    Now we maintain a per-session FIFO queue of pending speaks, drained by
    a single worker task. Speaks are processed in arrival order. Cancels
    still process immediately (out-of-band) so barge-in latency is
    unaffected.
    """
    state = get_state()
    cancel_mgr = CancelManager()
    speak_queue: asyncio.Queue[SpeakRequest | None] = asyncio.Queue()
    log.info("tts.ws.open", session_id=session_id)

    async def speak_worker() -> None:
        while True:
            req = await speak_queue.get()
            if req is None:
                return
            try:
                await _run_speak(ws, session_id, req, cancel_mgr, state)
            except Exception as e:  # surface but keep the worker alive
                log.warning("tts.speak.worker_error", error=str(e))

    worker_task = asyncio.create_task(speak_worker())

    try:
        while True:
            msg = await ws.receive()
            if msg.get("type") == "websocket.disconnect":
                break
            if (text := msg.get("text")) is None:
                continue
            try:
                payload = json.loads(text)
            except json.JSONDecodeError:
                log.warning("tts.control.invalid_json")
                continue
            kind = payload.get("type")
            if kind == "speak":
                try:
                    req = SpeakRequest.model_validate(payload)
                except ValidationError as e:
                    log.warning("tts.speak.invalid", errors=e.errors())
                    continue
                # Enqueue — worker will process FIFO. Do NOT create_task here.
                await speak_queue.put(req)
            elif kind == "cancel":
                try:
                    cr = CancelRequest.model_validate(payload)
                except ValidationError:
                    continue
                # Cancels run immediately (out-of-band of the speak queue) so
                # barge-in latency stays low.
                await cancel_mgr.cancel(cr.request_id)
            else:
                log.warning("tts.control.unknown", kind=kind)
    except WebSocketDisconnect:
        pass
    finally:
        await cancel_mgr.cancel_all()
        # Tell worker to exit, then wait for it.
        await speak_queue.put(None)
        try:
            await asyncio.wait_for(worker_task, timeout=1.0)
        except asyncio.TimeoutError:
            worker_task.cancel()
        log.info("tts.ws.close", session_id=session_id)


async def _run_speak(
    ws: WebSocket,
    session_id: str,
    req: SpeakRequest,
    cancel_mgr: CancelManager,
    state,
) -> None:
    await cancel_mgr.register(req.request_id)
    started = time.perf_counter()
    first_byte: float | None = None
    cancelled = False
    buf = bytearray()
    outbound_ts_ms = 0
    try:
        await ws.send_text(AudioStart(request_id=req.request_id).model_dump_json())
        await state.set_tts(session_id, active_request_id=req.request_id, position_ms=0)
        last_chunk_at = started
        async for chunk in _CLIENT.stream(req.text, req.voice_id, _SAMPLE_RATE):
            if cancel_mgr.is_cancelled(req.request_id):
                cancelled = True
                break
            now = time.perf_counter()
            if first_byte is None:
                first_byte = now
                tts_first_byte_ms.observe((first_byte - started) * 1000)
            if (now - last_chunk_at) * 1000 > 100:
                tts_underruns_total.inc()
            last_chunk_at = now
            buf.extend(chunk)
            while len(buf) >= _FRAME_BYTES:
                if cancel_mgr.is_cancelled(req.request_id):
                    cancelled = True
                    break
                pcm_frame = bytes(buf[:_FRAME_BYTES])
                del buf[:_FRAME_BYTES]
                await ws.send_bytes(encode_tts_frame(outbound_ts_ms, pcm_frame))
                outbound_ts_ms += _FRAME_MS
                await state.set_tts(
                    session_id,
                    active_request_id=req.request_id,
                    position_ms=outbound_ts_ms,
                )
            if cancelled:
                break
        if cancelled:
            t_cancel = time.perf_counter()
            tts_cancel_latency_ms.observe((t_cancel - started) * 1000)
            await ws.send_text(CancelledMessage(request_id=req.request_id).model_dump_json())
            tts_requests_total.labels(outcome="cancelled").inc()
        else:
            if buf:
                await ws.send_bytes(encode_tts_frame(outbound_ts_ms, bytes(buf)))
            await ws.send_text(AudioEnd(request_id=req.request_id).model_dump_json())
            tts_requests_total.labels(outcome="completed").inc()
    except Exception as e:  # surface but do not crash the socket
        log.exception("tts.speak.error", error=str(e), request_id=req.request_id)
        tts_requests_total.labels(outcome="error").inc()
    finally:
        await cancel_mgr.finish(req.request_id)
        await state.set_tts(session_id, active_request_id=None, position_ms=0)


app = make_app(service_name="tts_service", ws_path="/tts/{session_id}", handler=_handle)


def _main() -> None:
    import uvicorn

    uvicorn.run(
        "services.speech_io.tts_service.main:app",
        host=os.environ.get("TTS_HOST", "0.0.0.0"),
        port=int(os.environ.get("TTS_PORT", "8012")),
        log_level=os.environ.get("LOG_LEVEL", "info").lower(),
    )


if __name__ == "__main__":
    _main()
