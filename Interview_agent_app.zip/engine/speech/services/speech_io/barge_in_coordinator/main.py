"""A-04 barge-in coordinator.

Not a public WebSocket server — it runs one supervisor task per session that:
  1. Subscribes to VAD updates (from state stub or Redis later)
  2. Watches TTS state (active_request_id, position_ms)
  3. On sustained candidate speech while TTS plays, opens a WS to tts_service and
     sends `{"type":"cancel","request_id":...}`.

For local bring-up the coordinator is also exposed on :8013 with a health endpoint
so `docker compose ps` shows status per service.
"""

from __future__ import annotations

import asyncio
import json
import os
import time
from pathlib import Path

import websockets
from fastapi import FastAPI

from services.speech_io.barge_in_coordinator.policy import (
    BargeDecision,
    PolicyConfig,
    PolicyInputs,
    decide,
)
from services.speech_io.common.config import load_yaml
from services.speech_io.common.logging import configure_logging, get_logger
from services.speech_io.common.metrics import metrics_app
from services.speech_io.common.state_stub import get_state

configure_logging("barge_in_coordinator")
log = get_logger(__name__)

_CFG_PATH = Path(__file__).parent / "config.yaml"
_CFG = load_yaml(_CFG_PATH)
_POLICY_CFG = PolicyConfig(
    min_interrupt_ms=int(_CFG["policy"]["min_interrupt_ms"]),
    cancel_debounce_ms=int(_CFG["policy"]["cancel_debounce_ms"]),
    ignore_during_first_ms=int(_CFG["policy"]["ignore_during_first_ms"]),
)
_TTS_URL = os.environ.get(
    _CFG["target"]["tts_ws_url_env"], _CFG["target"]["default_tts_ws_url"]
)

app = FastAPI(title="barge_in_coordinator")
app.mount("/metrics", metrics_app())
_supervisors: dict[str, asyncio.Task] = {}


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok", "service": "barge_in_coordinator"}


@app.post("/sessions/{session_id}/attach")
async def attach(session_id: str) -> dict[str, str]:
    if session_id in _supervisors:
        return {"status": "already_attached"}
    _supervisors[session_id] = asyncio.create_task(_supervise(session_id))
    return {"status": "attached"}


@app.post("/sessions/{session_id}/detach")
async def detach(session_id: str) -> dict[str, str]:
    task = _supervisors.pop(session_id, None)
    if task:
        task.cancel()
    return {"status": "detached"}


async def _supervise(session_id: str) -> None:
    state = get_state()
    last_cancel_at_ms: int | None = None
    speech_started_ms: int | None = None
    log.info("barge_in.supervise.start", session_id=session_id)
    try:
        while True:
            await asyncio.sleep(0.02)  # 20ms — matches frame cadence
            now_ms = int(time.time() * 1000)
            vad = await state.get_vad(session_id)
            tts = await state.get_tts(session_id)
            active_req = tts.get("active_request_id")
            if active_req is None:
                speech_started_ms = None
                continue
            tts_started_ms = tts.get("tts_started_ms")
            speech_start = vad.get("speech_start")
            speech_end = vad.get("speech_end")
            if speech_start is not None and (speech_end is None or speech_end < speech_start):
                if speech_started_ms is None:
                    speech_started_ms = speech_start
                speech_run_ms = max(0, now_ms - speech_started_ms)
            else:
                speech_started_ms = None
                speech_run_ms = 0
            inputs = PolicyInputs(
                tts_active=True,
                tts_started_ms=tts_started_ms,
                now_ms=now_ms,
                speech_run_ms=speech_run_ms,
                last_cancel_at_ms=last_cancel_at_ms,
            )
            decision = decide(inputs, _POLICY_CFG)
            if decision is BargeDecision.CANCEL:
                await _send_cancel(session_id, active_req)
                last_cancel_at_ms = now_ms
                log.info(
                    "barge_in.cancel",
                    session_id=session_id,
                    request_id=active_req,
                    trigger_ms=now_ms,
                    vad_speech_start=speech_start,
                    speech_run_ms=speech_run_ms,
                )
                await state.append_flag(
                    session_id,
                    {
                        "kind": "barge_in_cancel",
                        "severity": "info",
                        "raised_at_ms": now_ms,
                        "evidence": {
                            "request_id": active_req,
                            "speech_run_ms": speech_run_ms,
                            "vad_speech_start_ms": speech_start,
                        },
                    },
                )
    except asyncio.CancelledError:
        log.info("barge_in.supervise.stop", session_id=session_id)
        raise


async def _send_cancel(session_id: str, request_id: str) -> None:
    uri = f"{_TTS_URL}/tts/{session_id}"
    try:
        async with websockets.connect(uri, open_timeout=1.0) as ws:
            await ws.send(json.dumps({"type": "cancel", "request_id": request_id}))
    except Exception as e:
        log.warning("barge_in.cancel.error", error=str(e), session_id=session_id)


def _main() -> None:
    import uvicorn

    uvicorn.run(
        "services.speech_io.barge_in_coordinator.main:app",
        host=os.environ.get("BARGE_IN_HOST", "0.0.0.0"),
        port=int(os.environ.get("BARGE_IN_PORT", "8013")),
        log_level=os.environ.get("LOG_LEVEL", "info").lower(),
    )


if __name__ == "__main__":
    _main()
