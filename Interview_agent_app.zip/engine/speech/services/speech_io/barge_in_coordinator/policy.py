"""Barge-in policy — pure function, fully tested.

Decision inputs:
  - `tts_active`: is TTS currently emitting audio?
  - `tts_started_ms`: when the active TTS request began (wall-clock ms)
  - `now_ms`: current wall clock
  - `speech_run_ms`: continuous speech run duration from VAD
  - `last_cancel_at_ms`: last time we issued a cancel (for debounce)

Rules (first match wins):
  1. No TTS active       → NEVER
  2. Within first ignore-window of TTS start → NEVER
  3. Speech run < min_interrupt_ms → WAIT
  4. Debounce window active → WAIT
  5. Otherwise            → CANCEL
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class BargeDecision(str, Enum):
    NEVER = "never"
    WAIT = "wait"
    CANCEL = "cancel"


@dataclass(frozen=True, slots=True)
class PolicyConfig:
    min_interrupt_ms: int = 200
    cancel_debounce_ms: int = 500
    ignore_during_first_ms: int = 150


@dataclass(frozen=True, slots=True)
class PolicyInputs:
    tts_active: bool
    tts_started_ms: int | None
    now_ms: int
    speech_run_ms: int
    last_cancel_at_ms: int | None


def decide(inputs: PolicyInputs, cfg: PolicyConfig) -> BargeDecision:
    if not inputs.tts_active:
        return BargeDecision.NEVER
    if (
        inputs.tts_started_ms is not None
        and (inputs.now_ms - inputs.tts_started_ms) < cfg.ignore_during_first_ms
    ):
        return BargeDecision.NEVER
    if inputs.speech_run_ms < cfg.min_interrupt_ms:
        return BargeDecision.WAIT
    if (
        inputs.last_cancel_at_ms is not None
        and (inputs.now_ms - inputs.last_cancel_at_ms) < cfg.cancel_debounce_ms
    ):
        return BargeDecision.WAIT
    return BargeDecision.CANCEL
