"""orchestrator_new.live_main — CLI entry point.

What this does:
  1. Parse args (candidate name, role, models, thresholds, ...).
  2. Source GROQ_API_KEY (preferred) or OPENROUTER_API_KEY from env/.env.
  3. Build MicAudioSource + SpeakerAudioSink.
  4. Build a SessionConfig from args.
  5. Run InterviewSession.run_until_signal().
  6. Print the transcript + summary.

Stream A's STT/VAD/TTS subprocesses must be running before this is invoked.
The wrapper script (`scripts/run_live_v2.sh`) handles that — boots them,
waits for /healthz, then runs this module.

Hit Ctrl-C to end the session. The teardown order in
`stream_b_new.runtime.InterviewSession.__aexit__` is what avoids the v1
"1012 service restart" race.
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import os
import signal
import sys
from pathlib import Path
from uuid import UUID, uuid4

# Load .env BEFORE importing modules that read os.environ at import time.
# The admin spawner launches us via wt.exe → cmd → bat, and the bat only
# explicitly sources GROQ_API_KEY + OPENROUTER_API_KEY. Other env vars
# (AZURE_SPEECH_KEY, LANGFUSE_*, etc.) wouldn't reach us without this.
try:
    from dotenv import load_dotenv as _load_dotenv
    _load_dotenv(Path(__file__).resolve().parent.parent / ".env", override=False)
except ImportError:
    pass

from engine.brain.config import (
    load_system_config,
    resolve_providers,
    tuning_kwargs,
)
from engine.brain.contracts.session_state import CandidateProfile
from engine.brain.runtime import InterviewSession, SessionConfig

from engine.orchestrator.audio_sink import SpeakerAudioSink
from engine.orchestrator.audio_source import MicAudioSource
from engine.orchestrator.resume_parser import parse_resume, summarize_resume
from engine.orchestrator.web import WebLauncher  # Track B (web)

logger = logging.getLogger("engine.orchestrator")


def _parse_args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="engine.orchestrator.live_main",
        description="Live mic interview runner (stream_b_new + Stream A).",
    )
    p.add_argument("--candidate-name", default="Live Candidate")
    p.add_argument("--role", default="Senior Backend Engineer")
    p.add_argument("--resume-path", type=Path, default=None,
                   help="Path to the candidate's resume file. Accepts PDF, "
                        "DOCX, TXT, MD, and any other format the "
                        "`attachments` library supports. Extracted plain "
                        "text is embedded in the slow LLM's system prompt "
                        "alongside name and role.")
    # --initial-phase removed: the cadence plan's first phase is the
    # source of truth. Use --cadence-path or --cadence-description to
    # change the initial phase.
    p.add_argument("--cadence-path", type=Path, default=None,
                   help="Path to a YAML file defining the interview "
                        "cadence (phases, durations, question pools). "
                        "If omitted, uses the built-in 10s testing "
                        "cadence (warm_up→resume_deep_dive→technical_"
                        "questions→wrap_up).")
    p.add_argument("--cadence-description", type=Path, default=None,
                   help="Path to a free-form description of the "
                        "cadence (TXT/PDF/DOCX/MD). The slow LLM "
                        "converts it to the canonical YAML schema. "
                        "Mutually exclusive with --cadence-path.")
    p.add_argument("--skip-cadence-confirm", action="store_true",
                   help="Skip the y/n confirmation prompt before "
                        "starting the interview. Useful in CI/scripted "
                        "runs.")
    p.add_argument("--scheduled-token", default=None,
                   help="UUID of a session row in sessions/sessions.db "
                        "(written by the admin scheduler app). When set, "
                        "candidate_name, role, resume_path, cadence_path, "
                        "and event_log are all loaded from the DB and "
                        "any matching CLI flags are ignored. The "
                        "orchestrator also reports lifecycle status back "
                        "to the DB so the admin dashboard stays in sync.")
    p.add_argument("--config", type=Path, default=None,
                   help="Path to system_config.yaml. Holds all tuning knobs "
                        "(models, providers, STT/TTS/VAD endpoints, latency "
                        "thresholds, policy, AEC, runtime). Defaults to "
                        "<repo>/config/system_config.yaml. Edit that file to "
                        "tune behaviour — these are no longer CLI flags. "
                        "Secrets stay in .env; prompts live in "
                        "config/prompts.yaml.")
    p.add_argument("--i-acknowledge-no-headphones", action="store_true",
                   help="Suppress the headphones warning. Without headphones, "
                        "AI's own voice will feed back through the mic and "
                        "trigger spurious barge-ins. Consider aec.enabled "
                        "in system_config.yaml instead.")
    p.add_argument("--list-devices", action="store_true",
                   help="Print sounddevice's audio device list and exit.")
    p.add_argument("--mic-device", default=None,
                   help="Input device — pass an index (e.g. '2') or a name "
                        "substring (e.g. 'MacBook'). Default: system default input.")
    p.add_argument("--mic-gain", type=float, default=1.0,
                   help="Multiplier applied to mic input before sending to "
                        "STT/VAD. Try 3-5 if you see [MIC] DEAD MIC or "
                        "consistently low level= values in the log.")
    p.add_argument("--no-playback", action="store_true",
                   help="Don't actually open the speaker; events still log.")
    p.add_argument("--event-log", default="/tmp/integration/events.jsonl")
    p.add_argument("--log-level", default="INFO")
    WebLauncher.add_cli_args(p)  # Track B (web)
    return p.parse_args(argv)


def _find_env_var(var: str) -> str:
    """Look up `var` in os.environ, then in .env files alongside this script."""
    v = os.environ.get(var, "").strip()
    if v:
        return v
    here = Path(__file__).resolve().parent
    env_files = [here.parent / ".env", here.parent.parent / ".env"]
    for cand in env_files:
        if cand.is_file():
            for line in cand.read_text().splitlines():
                line = line.strip()
                if line.startswith(f"{var}="):
                    return line.split("=", 1)[1].strip()
    return ""


class _NullSink:
    """Drop-in for SpeakerAudioSink when --no-playback is passed."""

    sample_rate_hz = 16_000

    def start(self) -> None: ...
    async def play(self, pcm: bytes) -> None: ...
    async def flush(self) -> None: ...
    async def stop(self) -> None: ...
    def bytes_buffered(self) -> int: return 0


async def main_async(argv: list[str]) -> int:
    args = _parse_args(argv)
    logging.basicConfig(
        level=args.log_level.upper(),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    # --scheduled-token: load session config from the admin SQLite DB and
    # override the CLI args. Spawned by admin/spawner.py at "Approve" time.
    if args.scheduled_token:
        from app import db as admin_db
        from app.paths import session_dir
        row = admin_db.get(args.scheduled_token)
        if row is None:
            print(
                f"ERROR: scheduled-token {args.scheduled_token!r} not found "
                f"in sessions/sessions.db. Did the admin app run?",
                file=sys.stderr,
            )
            return 2
        sdir = session_dir(args.scheduled_token)
        args.candidate_name = row["candidate_name"]
        args.role = row["role"]
        args.resume_path = sdir / row["resume_path"]
        args.cadence_path = sdir / "cadence.yaml"
        args.cadence_description = None  # cadence_yaml is already on disk
        args.event_log = str(sdir / (row["event_log_path"] or "events.jsonl"))
        # Web UI is implicit for scheduled sessions — the candidate joins via
        # the admin-issued link. The orchestrator's WebLauncher blocks on
        # `wait_for_candidate()` until the lobby's "Start Interview" button
        # fires — the interview does NOT start before that click.
        args.web = True
        args.web_no_open_browser = True
        args.skip_cadence_confirm = True
        # NOTE: prewarm is force-disabled for scheduled sessions after the
        # config loads (see below) — the prewarm "Hi." would surface in the
        # browser caption before the candidate clicks Start.
        # The candidate clicks Start themselves; don't auto-start.
        # (web_no_wait_for_ui stays at its default — operator's choice.)
        logger.info("[scheduled-token] loaded %s for %s (%s)",
                    args.scheduled_token, args.candidate_name, args.role)

    # --list-devices: print and exit (no Stream A boot needed).
    if args.list_devices:
        import sounddevice as sd
        try:
            print(sd.query_devices())
        except Exception as e:
            print(f"sounddevice query failed: {e}", file=sys.stderr)
            return 2
        return 0

    # ── tuning + provider resolution (system_config.yaml) ─────────────
    # All non-secret tuning lives in config/system_config.yaml. Provider
    # keys are sourced from env by name (.env-aware via _find_env_var).
    try:
        sys_cfg = load_system_config(args.config)
    except FileNotFoundError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2
    tuning = tuning_kwargs(sys_cfg)
    # Scheduled (web) sessions must not prewarm: the prewarm "Hi." surfaces in
    # the browser caption before the candidate clicks Start.
    if args.scheduled_token:
        tuning["prewarm_kokoro"] = False
    providers = resolve_providers(sys_cfg, getenv=_find_env_var)
    if not providers["llm_api_key"]:
        print(
            "ERROR: no LLM key found. Set GROQ_API_KEY (preferred) or "
            "OPENROUTER_API_KEY in env or .env.", file=sys.stderr,
        )
        return 2
    logger.info(
        "[LLM] base_url=%s | slow=%s (%s) | fast=%s (%s order=%s)",
        providers["llm_base_url"], tuning["slow_model"],
        providers["slow_llm_base_url"] or "shared",
        tuning["fast_model"], providers["fast_llm_base_url"] or "shared",
        providers["fast_llm_provider_order"],
    )
    # Slow-LLM creds for cadence loading below (fall back to primary).
    slow_api_key = providers["slow_llm_api_key"] or providers["llm_api_key"]
    slow_base_url_resolved = providers["slow_llm_base_url"] or providers["llm_base_url"]

    # ── resolve mic-device (index or name substring) ──
    device: int | str | None = None
    if args.mic_device is not None:
        try:
            device = int(args.mic_device)
        except ValueError:
            # Name substring — let sounddevice resolve.
            device = args.mic_device

    # ── audio I/O ─────────────────────────────────────
    # Track B (web) — if --web is set, both mic and speakers move to the
    # browser. The local sounddevice path is bypassed entirely; getUserMedia
    # in Chrome/Edge handles AEC/AGC/NS for free, removing the headphones
    # requirement without server-side --aec.
    web = WebLauncher.from_args(args)  # Track B (web)
    if web is not None:  # Track B (web)
        source = web.audio_source()  # Track B (web)
        sink = web.audio_sink()  # Track B (web)
    else:
        source = MicAudioSource(device=device, gain=args.mic_gain)
        sink = (
            _NullSink() if args.no_playback else SpeakerAudioSink(sample_rate=tuning["tts_sample_rate_hz"])
        )

    # ── resume (parsed via the `attachments` library) ──────
    # On parse failure we log + fall back to the no-resume path rather
    # than aborting. The interview is more valuable than the resume —
    # a typo in --resume-path shouldn't kill an in-progress test run.
    # The slow LLM's system prompt already handles missing-resume by
    # rendering `resume_summary: (not provided)`.
    resume_text = ""
    if args.resume_path is not None:
        try:
            resume_text = parse_resume(args.resume_path)
            # Print a short visual confirmation so the operator can verify
            # the parsed text looks like actual resume content (not a blob
            # of garbage from a malformed PDF). First non-empty line + a
            # word count gives a strong "this looks like a resume" signal
            # without dumping the whole document to stdout.
            first_line = next(
                (ln.strip() for ln in resume_text.splitlines() if ln.strip()),
                "(empty)",
            )
            word_count = len(resume_text.split())
            preview = first_line if len(first_line) <= 80 else first_line[:77] + "..."
            print(f"[resume] ✓ loaded {args.resume_path}")
            print(f"[resume]   chars : {len(resume_text)}")
            print(f"[resume]   words : {word_count}")
            print(f"[resume]   first : {preview!r}")
            print(f"[resume]   → embedded into the slow LLM's system prompt "
                  f"as `resume_summary`.")
        except (ValueError, RuntimeError) as e:
            logger.warning(
                "[resume] could not parse %s: %s — continuing without resume "
                "(system prompt will render 'resume_summary: (not provided)')",
                args.resume_path, e,
            )
            print(f"[resume] WARNING — could not parse {args.resume_path}: "
                  f"{e}\n[resume] continuing without resume.",
                  file=sys.stderr)
            resume_text = ""
        except Exception as e:
            # Defensive: unexpected exception type. Same fall-back, but
            # log with traceback so we can fix the underlying issue.
            logger.exception(
                "[resume] unexpected error parsing %s — continuing without "
                "resume", args.resume_path,
            )
            print(f"[resume] WARNING — unexpected error parsing "
                  f"{args.resume_path}: {e}\n[resume] continuing without "
                  f"resume.", file=sys.stderr)
            resume_text = ""

    # ── resume → compact structured template ───────────────────────
    # Raw resume text is large and noisy. Summarize it once (LLM call) into
    # a tiny name + project-headings + tech-stack template so the slow LLM's
    # system prompt stays small. Falls back to raw text internally on any
    # failure, so this never blocks the interview.
    if resume_text:
        resume_text = await summarize_resume(
            resume_text,
            candidate_name=args.candidate_name,
            api_key=slow_api_key,
            base_url=slow_base_url_resolved,
            model=tuning["slow_model"],
        )
        print(f"[resume]   summary ({len(resume_text)} chars):")
        for line in resume_text.splitlines():
            print(f"[resume]     {line}")

    # ── cadence (load + confirm BEFORE Stream A starts) ────────────
    # Load order:
    #   1. --cadence-path foo.yaml             → direct YAML load
    #   2. --cadence-description foo.{txt,pdf} → slow LLM converts to YAML
    #   3. neither flag                        → built-in 10s testing cadence
    # The operator is shown the parsed plan and must confirm before the
    # interview begins. Mutually exclusive flags are validated by load_cadence.
    from engine.brain.cadence import load_cadence, confirm_cadence
    try:
        cadence = await load_cadence(
            cadence_path=args.cadence_path,
            cadence_description_path=args.cadence_description,
            role=args.role,
            candidate_name=args.candidate_name,
            api_key=slow_api_key,
            base_url=slow_base_url_resolved,
            model=tuning["slow_model"],
        )
    except (ValueError, RuntimeError) as e:
        print(f"[cadence] ERROR — could not load cadence: {e}", file=sys.stderr)
        return 2
    if not confirm_cadence(cadence, interactive=not args.skip_cadence_confirm):
        return 0  # operator declined; clean exit (no Stream A booted yet)

    # ── session config ────────────────────────────────
    # Tuning + provider kwargs come from system_config.yaml (resolved above).
    # Only per-session fields are supplied here.
    config = SessionConfig(
        candidate_profile=CandidateProfile(
            name=args.candidate_name,
            role=args.role,
            resume_summary=resume_text,
        ),
        cadence=cadence,
        event_log_path=Path(args.event_log),
        **tuning,
        **providers,
    )

    # ── headphones warning ────────────────────────────
    # AEC removes the AI's voice from the mic input digitally, so the
    # headphones warning isn't needed when --aec is set.
    # Track B (web) — same reasoning: getUserMedia in the browser does
    # AEC/AGC/NS upstream, and the orchestrator never opens local speakers
    # at all (the browser plays the AI's audio), so there's no feedback
    # loop to warn about.
    if not args.i_acknowledge_no_headphones and not tuning["aec_enabled"] and web is None:  # Track B (web)
        print()
        print("!" * 70)
        print("  HEADPHONES REQUIRED")
        print("")
        print("  Without headphones, the AI's voice plays through your speakers,")
        print("  the mic picks it up, and VAD treats the AI's own voice as YOU.")
        print("  This will cause:")
        print("    - barge-in firing on the AI's own audio (it cancels itself)")
        print("    - the strike counter racing to 3 in seconds")
        print("    - the AI getting stuck in protected-response mode")
        print("")
        print("  Plug in headphones or earbuds NOW.")
        print("  Then press [ENTER] to continue, or pass")
        print("    --i-acknowledge-no-headphones (also try --no-strikes)")
        print("  to skip this prompt next time.")
        print("!" * 70)
        try:
            input("> ")
        except (EOFError, KeyboardInterrupt):
            return 130

    # ── banner ────────────────────────────────────────
    print()
    print("=" * 70)
    print("  LIVE MIC MODE — speak into your microphone")
    print("  Press Ctrl-C to end the interview")
    print("=" * 70)
    print()
    print(f"  candidate : {args.candidate_name} ({args.role})")
    print(f"  config    : {args.config}")
    print(f"  models    : slow={tuning['slow_model']}  fast={tuning['fast_model']}")
    print(f"  filler    : {'on' if tuning['use_filler'] else 'off'}"
          f"{'  (canned)' if tuning['use_canned_filler'] else ''}")
    strike_disp = (
        "DISABLED" if tuning["strike_threshold"] >= 999_999
        else str(tuning["strike_threshold"])
    )
    print(f"  thresholds: filler={tuning['filler_threshold_ms']}ms "
          f"apology={tuning['apology_threshold_ms']}ms "
          f"warmup={tuning['barge_in_warmup_ms']}ms strikes={strike_disp}")
    aec_disp = (
        f"ON delay={tuning['aec_stream_delay_ms']}ms (re-enables barge-in)"
        if tuning["aec_enabled"] else "OFF"
    )
    print(f"  aec       : {aec_disp}")
    # Track B (web)
    web_disp = (
        f"ON ws=:{args.web_ws_port} http=:{args.web_http_port} "
        f"(browser AEC/AGC/NS, sounddevice bypassed)"
        if web is not None
        else "OFF"
    )
    print(f"  web mode  : {web_disp}")
    print(f"  event log : {args.event_log}")
    print()

    rc = 0
    # Track B (web) — start the WS broadcaster + static server BEFORE the
    # session boots so the candidate can begin loading the lobby while we
    # initialise STT/VAD/TTS clients. Block until they click Start.
    if web is not None:  # Track B (web)
        await web.start_servers()  # Track B (web)
        await web.wait_for_candidate()  # Track B (web)

    # When a scheduled-token is set, use IT as the InterviewSession
    # session_id so Langfuse traces are tagged with the same UUID the
    # admin's "View in Langfuse" deep-link points at — otherwise the
    # link lands on a "session expired" page because the tagged session
    # was a random uuid that the admin UI has never heard of.
    session_id_override: UUID | None = None
    if args.scheduled_token:
        try:
            session_id_override = UUID(args.scheduled_token)
        except ValueError:
            logger.warning(
                "[scheduled-token] %r is not a valid UUID — Langfuse "
                "session deep-link from admin will not resolve",
                args.scheduled_token,
            )
    async with InterviewSession(
        config=config,
        audio_source=source,
        audio_sink=sink,
        session_id=session_id_override,
    ) as session:
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, session.request_stop)
            except NotImplementedError:        # pragma: no cover (windows)
                pass
        if web is not None:  # Track B (web)
            await web.attach(session)  # Track B (web)
            async def _watch_end_signal():  # Track B (web)
                await web.end_signal.wait()  # Track B (web)
                session.request_stop()  # Track B (web)
            asyncio.create_task(_watch_end_signal(), name="web-end-watcher")  # Track B (web)

        # Scheduled-token: lifecycle hooks come from the shared module
        # so cloud (deploy/azure_app.py) gets the same behaviour without
        # us re-porting it every time. See orchestrator_new/scheduled_session.py
        if args.scheduled_token:
            from engine.orchestrator.scheduled_session import attach_db_lifecycle
            attach_db_lifecycle(session, args.scheduled_token)
        try:
            await session.run_until_signal()
        except KeyboardInterrupt:
            rc = 130
        finally:  # Track B (web)
            if web is not None:  # Track B (web)
                await web.shutdown()  # Track B (web)

    print()
    print(session.summary())
    print()
    print("Quick analysis:")
    print(f"  jq -r '.kind' {args.event_log} | sort | uniq -c | sort -rn")
    print(f"  jq 'select(.kind==\"ai_utterance\") | .payload.text' {args.event_log}")
    print(f"  jq 'select(.kind==\"stt_final\") | .payload.text' {args.event_log}")
    print()

    # ── Performance evaluation ───────────────────────────────────────
    # Shared with cloud: see orchestrator_new/scheduled_session.py. The
    # admin dashboard reads sessions/<token>/evaluation.json. The
    # orchestrator window stays open while the eval runs so the operator
    # sees it complete.
    if args.scheduled_token:
        print("=" * 70)
        print("  Generating performance evaluation…")
        print("=" * 70)
        from engine.orchestrator.scheduled_session import generate_post_session_evaluation
        evaluation = await generate_post_session_evaluation(args.scheduled_token)
        if evaluation is not None:
            band = evaluation.get("overall", {}).get("band", "?")
            score = evaluation.get("overall", {}).get("score", "?")
            print(f"  ✓ Evaluation written: score={score}/100 band={band}")
            print(f"    sessions/{args.scheduled_token}/evaluation.json")
            print(f"  Open the admin session detail page to view the dashboard.")
        else:
            print(f"  ✗ Evaluation failed (see logs above).")
            print(f"  You can retry from the admin UI (Regenerate button on")
            print(f"  the session detail page).")
        print()

    return rc


def main() -> int:
    try:
        return asyncio.run(main_async(sys.argv[1:]))
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
