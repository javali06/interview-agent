"""BrowserMicAudioSource — implements :class:`AudioSource` over a WebSocket.

A drop-in replacement for :class:`orchestrator_new.audio_source.MicAudioSource`
that reads 20ms PCM16 mono frames from the browser instead of the local mic.

InterviewSession is completely unaware of where the frames come from — the
:class:`AudioSource` protocol is the contract. Browser AEC/AGC/NS happens
upstream (in the candidate's Chrome/Edge), so by the time we receive frames
they're already cleaned. That's the entire point of Track B.

Lifecycle
---------
* ``start()`` — no-op besides recording a log line. The broadcaster is started
  by :class:`WebLauncher` before the session boots; mic frames simply arrive
  whenever the browser starts streaming.
* ``frames()`` — async-iterates the broadcaster's mic queue until ``stop()``
  is called. Pads with silence if a frame is the wrong length (defensive —
  the worklet should always produce 640-byte frames but a partial / variable
  read could in principle slip through; better to keep VAD timing accurate
  than to crash the pipeline).
* ``stop()`` — flips an internal event; the next queue iteration unblocks
  and the generator exits.

Mic-liveness: we track per-frame RMS energy here and expose it via
``mic_health()`` / ``stats()``. A dead/muted/blocked mic — or a saturated
uplink zero-filling frames — presents as frames arriving with ~zero RMS. The
session watchdog uses this to distinguish real think-time silence (which has a
noise floor) from "we can't hear the candidate at all" and flags the interview
(see the dead-air incident: frames arrived at ~43/s but zero speech).
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
from typing import AsyncIterator

try:  # numpy is in the session-tier image (requirements: numpy==1.26.4); guard anyway
    import numpy as _np
except Exception:  # pragma: no cover — degrade to no-RMS rather than break the mic path
    _np = None

from engine.brain.contracts.audio import (
    FRAME_BYTES,
    FRAME_SAMPLES,
    SAMPLE_RATE_HZ,
)

logger = logging.getLogger(__name__)

# RMS at/below this (PCM16, 0..32767 scale) counts as "silent" for the
# mic-liveness signal. A muted/blocked/dead mic yields ~0; a live mic in a quiet
# room keeps a noise floor comfortably above this. Env-tunable.
_MIC_SILENCE_RMS_FLOOR = float(os.getenv("MIC_SILENCE_RMS_FLOOR", "45"))


class BrowserMicAudioSource:
    """Reads PCM16 mono @ 16 kHz frames from a :class:`WebBroadcaster` queue."""

    # InterviewSession reads this when wiring the pipeline.
    sample_rate: int = SAMPLE_RATE_HZ
    frame_samples: int = FRAME_SAMPLES

    def __init__(self, mic_queue: asyncio.Queue[bytes]) -> None:
        self._mic_queue = mic_queue
        self._stopped = asyncio.Event()
        self._frames_in = 0
        self._frames_padded = 0
        self._frames_dropped_oversize = 0
        # ── TEMP DIAGNOSTIC (audio-rate drift investigation, 2026-06-01) ──
        # Track every distinct browser-packet size we see + the total count
        # of incoming packets, plus wall-clock start so we can compute the
        # arrival rate at session end.
        # The two failure modes we're hunting:
        #   1. Packet size != 640 → browser sending non-16kHz frames.
        #   2. Arrival rate != ~50/s → worklet's downsample ratio wrong;
        #      frames are the right size but arrive too fast (this would
        #      produce the 2x audio-time drift in trace 4c0c4d44).
        self._packets_in: int = 0
        self._packet_size_histogram: dict[int, int] = {}
        self._first_packet_wall_s: float | None = None
        self._last_packet_wall_s: float | None = None
        # ── Mic-liveness (energy) signal for the silence detector ──
        # A dead/muted/blocked mic (or a saturated uplink zero-filling frames)
        # arrives as frames with ~zero RMS. Track voiced vs silent frames + the
        # wall time of the last voiced frame so the watchdog can tell "candidate
        # is thinking" (real noise floor) from "we can't hear them at all".
        self._rms_frames: int = 0
        self._rms_sum: float = 0.0
        self._rms_max: float = 0.0
        self._voiced_frames: int = 0
        self._silent_frames: int = 0
        self._last_voiced_wall_s: float | None = None

    @staticmethod
    def _frame_rms(frame: bytes) -> float | None:
        """RMS of a PCM16 frame (0..32767), or None if numpy is unavailable / the
        buffer isn't valid int16. Vectorized in C — microseconds per frame."""
        if _np is None or not frame or (len(frame) & 1):
            return None
        try:
            x = _np.frombuffer(frame, dtype=_np.int16).astype(_np.float32)
            if x.size == 0:
                return None
            return float(_np.sqrt(_np.mean(x * x)))
        except Exception:  # pragma: no cover — never let RMS break the mic path
            return None

    def _observe_energy(self, frame: bytes, now_wall_s: float) -> None:
        rms = self._frame_rms(frame)
        if rms is None:
            return
        self._rms_frames += 1
        self._rms_sum += rms
        if rms > self._rms_max:
            self._rms_max = rms
        if rms >= _MIC_SILENCE_RMS_FLOOR:
            self._voiced_frames += 1
            self._last_voiced_wall_s = now_wall_s
        else:
            self._silent_frames += 1

    def mic_health(self) -> dict:
        """Lightweight snapshot for the session watchdog's mic-silence detector.

        `seconds_since_voiced` is None if we've NEVER seen a voiced frame (dead
        mic from the start); a large value means voiced-then-went-dead. Combined
        with `packets_in > 0` (frames ARE arriving) this cleanly separates a
        dead/muted mic from "candidate hasn't been sent any audio at all"."""
        total = self._voiced_frames + self._silent_frames
        since_voiced = (
            (time.monotonic() - self._last_voiced_wall_s)
            if self._last_voiced_wall_s is not None else None
        )
        return {
            "packets_in": self._packets_in,
            "first_packet_wall_s": self._first_packet_wall_s,
            "voiced_frames": self._voiced_frames,
            "silent_frames": self._silent_frames,
            "voiced_ratio": (self._voiced_frames / total) if total else 0.0,
            "seconds_since_voiced": since_voiced,
        }

    def stats(self) -> dict:
        """Snapshot of mic-delivery diagnostics for DURABLE logging (events.jsonl).

        Same numbers stop() logs to the console, but returned so the session can
        persist them in the per-interview artifact. The ACA console logs aren't
        retained (env app-logs destination is unset), so this is how we confirm
        the audio-rate drift after the fact: `arrival_rate_per_s` well above ~50
        or `dominant_packet_bytes` != 640 is the smoking gun (frames arriving
        faster than real time → the ~2x audio-time drift that degrades VAD + STT)."""
        dominant = max(
            self._packet_size_histogram.items(), key=lambda kv: kv[1],
            default=(0, 0),
        )[0] if self._packet_size_histogram else 0
        wall = 0.0
        if (self._first_packet_wall_s is not None
                and self._last_packet_wall_s is not None):
            wall = self._last_packet_wall_s - self._first_packet_wall_s
        rate = (self._packets_in / wall) if wall > 0 else 0.0
        return {
            "packets_in": self._packets_in,
            "frames_in": self._frames_in,
            "frames_padded": self._frames_padded,
            "frames_oversize": self._frames_dropped_oversize,
            "dominant_packet_bytes": dominant,
            "expected_packet_bytes": FRAME_BYTES,
            "wall_elapsed_s": round(wall, 1),
            "arrival_rate_per_s": round(rate, 1),
            "packet_size_histogram": dict(sorted(self._packet_size_histogram.items())),
            # Mic-liveness summary — resolves "silent capture vs lost-in-transit":
            # near-zero mean_rms with a healthy arrival_rate = the mic captured
            # silence (dead/muted/blocked or a zero-filling uplink), NOT our path.
            "mean_rms": round(self._rms_sum / self._rms_frames, 1) if self._rms_frames else 0.0,
            "max_rms": round(self._rms_max, 1),
            "voiced_frames": self._voiced_frames,
            "silent_frames": self._silent_frames,
            "voiced_ratio": round(
                self._voiced_frames / (self._voiced_frames + self._silent_frames), 3
            ) if (self._voiced_frames + self._silent_frames) else 0.0,
        }

    async def start(self) -> None:
        self._stopped.clear()
        logger.info(
            "[WEB-MIC] source ready — awaiting browser frames "
            "(expect %d-byte PCM16 @ %dHz)", FRAME_BYTES, SAMPLE_RATE_HZ,
        )

    async def drain(self) -> int:
        """Discard everything currently buffered in the mic queue.
        Returns the number of frames dropped.

        Called by InterviewSession._mic_pump_loop right before it starts
        consuming. Browser mic frames begin queueing the moment the
        WebSocket upgrades (broadcaster.handle_client_via_adapter
        starts immediately). During that window InterviewSession is
        still in __aenter__ — connecting Azure STT/TTS over WS, which
        on cold start can take 5-20 s. Without this drain, the pump
        consumes the entire backlog at unbounded rate; ts_ms (=
        seq*FRAME_MS) advances faster than wall clock, VAD's silence
        detector fires false endpoints, and Azure receives the burst
        with no real-silence gaps so it never fires `recognized`.

        The pre-session audio is just the candidate waiting on the
        "Connecting…" caption — discarding it costs nothing real.
        """
        dropped = 0
        while True:
            try:
                self._mic_queue.get_nowait()
                dropped += 1
            except asyncio.QueueEmpty:
                break
        return dropped

    async def stop(self) -> None:
        self._stopped.set()
        # Unblock any pending get() in frames() so the generator can exit.
        # Push a sentinel — frames() filters zero-length frames out.
        try:
            self._mic_queue.put_nowait(b"")
        except asyncio.QueueFull:
            pass
        # ── TEMP DIAGNOSTIC (audio-rate drift investigation, 2026-06-01) ──
        # Dump per-packet-size histogram so we can tell whether the browser
        # ever sent us oversize/odd-size frames. If the dominant size is
        # anything other than FRAME_BYTES (640), that's the smoking gun
        # for the 2x audio-time drift seen in trace 4c0c4d44.
        dominant_size = max(
            self._packet_size_histogram.items(),
            key=lambda kv: kv[1],
            default=(0, 0),
        )[0] if self._packet_size_histogram else 0
        if dominant_size and dominant_size != FRAME_BYTES:
            logger.warning(
                "[WEB-MIC] AUDIO RATE DRIFT SUSPECTED — dominant packet size "
                "= %d bytes (expected %d). Each oversize packet was split "
                "into N=%d sub-frames, which doubles/triples apparent audio "
                "time and breaks Azure STT silence segmentation.",
                dominant_size, FRAME_BYTES, dominant_size // FRAME_BYTES,
            )
        # Compute arrival rate. Expected: ~50 packets/s for 20 ms frames
        # at real time. If we see ~100/s, that's the 2x drift smoking gun.
        if (
            self._first_packet_wall_s is not None
            and self._last_packet_wall_s is not None
            and self._packets_in > 1
        ):
            wall_elapsed_s = self._last_packet_wall_s - self._first_packet_wall_s
            arrival_rate = (
                self._packets_in / wall_elapsed_s if wall_elapsed_s > 0 else 0.0
            )
        else:
            wall_elapsed_s = 0.0
            arrival_rate = 0.0
        if arrival_rate > 70.0:
            logger.warning(
                "[WEB-MIC] AUDIO RATE DRIFT SUSPECTED — packets arrived at "
                "%.1f/s (expected ~50/s for 20ms frames at real time). The "
                "browser is sending more frames than wall-clock allows; the "
                "downsample ratio in mic-worklet.js is likely wrong for this "
                "candidate's AudioContext.sampleRate.",
                arrival_rate,
            )
        logger.info(
            "[WEB-MIC] source stopped — packets_in=%d (in %.1fs wall, "
            "= %.1f pkts/s), frames_in=%d, padded=%d, oversize_events=%d, "
            "packet_size_histogram=%s",
            self._packets_in, wall_elapsed_s, arrival_rate,
            self._frames_in, self._frames_padded,
            self._frames_dropped_oversize,
            dict(sorted(self._packet_size_histogram.items())),
        )

    async def frames(self) -> AsyncIterator[bytes]:
        """Yield 20ms PCM16 mono frames until ``stop()`` is called."""
        while not self._stopped.is_set():
            try:
                frame = await self._mic_queue.get()
            except asyncio.CancelledError:
                return
            if not frame:
                # Either the stop() sentinel or an upstream hiccup. Loop and
                # re-check the stopped flag.
                continue
            n = len(frame)
            # TEMP DIAGNOSTIC: track packet-size distribution + arrival
            # rate (see stop()).
            now_wall_s = time.monotonic()
            if self._first_packet_wall_s is None:
                self._first_packet_wall_s = now_wall_s
            self._last_packet_wall_s = now_wall_s
            self._packets_in += 1
            self._packet_size_histogram[n] = (
                self._packet_size_histogram.get(n, 0) + 1
            )
            # Mic-liveness energy (pre-AEC — raw candidate mic). Cheap (numpy in C).
            self._observe_energy(frame, now_wall_s)
            if n == FRAME_BYTES:
                self._frames_in += 1
                yield frame
            elif n < FRAME_BYTES:
                # Short frame — pad with silence so downstream VAD/STT keep
                # accurate timing. Logged once per 100 occurrences so a
                # consistent under-run is visible without flooding.
                pad = FRAME_BYTES - n
                self._frames_padded += 1
                if self._frames_padded % 100 == 1:
                    logger.warning(
                        "[WEB-MIC] short frame: %d bytes (padded with %d zeros) — count=%d",
                        n, pad, self._frames_padded,
                    )
                yield frame + b"\x00" * pad
            else:
                # Oversize frame — the worklet shouldn't produce these, but
                # be defensive: split into FRAME_BYTES chunks, discard the tail.
                self._frames_dropped_oversize += 1
                if self._frames_dropped_oversize % 100 == 1:
                    logger.warning(
                        "[WEB-MIC] oversize frame: %d bytes (splitting into %d-byte chunks) — count=%d",
                        n, FRAME_BYTES, self._frames_dropped_oversize,
                    )
                offset = 0
                while offset + FRAME_BYTES <= n:
                    yield frame[offset : offset + FRAME_BYTES]
                    offset += FRAME_BYTES
                    self._frames_in += 1
