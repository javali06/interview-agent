"""WebBroadcaster — bidirectional WebSocket server for the candidate UI.

This is the counterpart to ``avatar.broadcaster.AvatarBroadcaster`` but with
two key differences:

1.  **Mic-in path** — binary frames received from the browser are deposited
    on an ``asyncio.Queue`` consumed by :class:`BrowserMicAudioSource`. The
    queue is bounded; on overflow we drop the oldest frame (mic should never
    pile up — if we're falling behind, dropping is the right call).

2.  **Control plane** — the browser sends:

        {"type":"start", "visual_mode":"avatar"|"minimal",
         "candidate":{"name":..., "role":...}}
        {"type":"end"}

    The launcher exposes the corresponding events (``start_signal``,
    ``end_signal``) so live_main can defer interview boot until the user
    clicks Start, and tear down cleanly when they click End.

3.  **STT echo** — extra JSON frames make their way to the browser for the
    live transcript:

        {"type":"stt_partial", "text":"..."}
        {"type":"stt_final",   "text":"..."}

Outgoing wire format (mirrors avatar/broadcaster.py to keep ui/candidate
compatible with ui/avatar conceptually)::

    {"type":"hello",        "sample_rate":N, "start_armed":bool}
    {"type":"audio_start",  "text":"...", "sample_rate":N, "sub_id":"..."}
    <binary PCM16 LE mono frames...>
    {"type":"audio_end",    "sub_id":"..."}
    {"type":"audio_cancel", "sub_id":"..."}     (barge-in)
    {"type":"stt_partial",  "text":"..."}
    {"type":"stt_final",    "text":"..."}
    {"type":"session_end"}                       (orchestrator hangs up)

Incoming wire format::

    {"type":"start", "visual_mode":..., "candidate":{...}}
    {"type":"end"}
    <binary PCM16 LE mono @ 16 kHz frames>       (mic from getUserMedia)

Design constraints
------------------
* All ``emit_*`` methods are NON-BLOCKING. They push to an outbound asyncio
  queue (drained by one consumer task) — the audio hot-path on either side
  of the wire must never be back-pressured.
* Mic-in queue is bounded (default 4096 frames ≈ 80s of audio at 20ms/frame).
* Zero clients connected is fine — TTS-out frames just queue and drain into
  the void; mic-in queue stays empty.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

import websockets
from websockets.asyncio.server import ServerConnection, serve

logger = logging.getLogger(__name__)

# Prometheus mic-drop counter (dashboard: audio backpressure at scale). Imported
# once and guarded so the local single-laptop path (or any import hiccup) never
# breaks the audio hot-path — mirrors log_timing's defensive metrics wiring.
try:
    from engine.brain.observability.prom import MIC_FRAMES_DROPPED
except Exception:  # pragma: no cover
    MIC_FRAMES_DROPPED = None

_QueueItem = tuple[str, Any]  # ("json", dict) or ("binary", bytes)

# Server→client binary frames carry a 1-byte source tag prefix. Only 0x00 (AI
# TTS) is sent now: 0x01 (candidate mic relayed to observers) and 0x02 (observer
# push-to-talk) retired with the observer feature — an interview is the AI and
# the candidate only. The tag stays rather than being dropped because the
# browser's audio path parses it; changing the wire format buys nothing.
# Client→server mic frames are UNTAGGED (raw PCM).
TAG_AI = b"\x00"


class WebBroadcaster:
    """Bidirectional WS server: TTS audio + STT text → browser;  mic → orchestrator."""

    def __init__(
        self,
        host: str = "localhost",
        port: int = 9100,
        sample_rate_hz: int = 16_000,
        outbound_queue_max: int = 4096,
        mic_queue_max: int = 4096,
    ) -> None:
        self._host = host
        self._port = port
        self._sample_rate_hz = sample_rate_hz
        # Interview token (== InterviewSession session_id) stamped on outbound
        # audio_start so the browser records ONLY this interview's AI audio even
        # when several interviews run concurrently on one shard. Set by the
        # session runner after construction; "" (unset) omits the guard → the
        # client falls back to legacy (trust-the-socket) behavior.
        self.session_id: str = ""
        self._clients: set[ServerConnection] = set()
        # Outbound: orchestrator → browser (JSON control + binary TTS PCM)
        self._out_q: asyncio.Queue[_QueueItem] = asyncio.Queue(maxsize=outbound_queue_max)
        # Inbound: browser → orchestrator (binary mic PCM frames)
        self._mic_q: asyncio.Queue[bytes] = asyncio.Queue(maxsize=mic_queue_max)
        self._server: Any = None
        self._consumer_task: asyncio.Task | None = None
        self._dropped_out_frames = 0
        self._dropped_mic_frames = 0

        # Control-plane events the launcher exposes upward
        self.start_signal: asyncio.Event = asyncio.Event()
        self.end_signal: asyncio.Event = asyncio.Event()
        # Stash of candidate metadata from the {"type":"start"} message
        self.candidate_meta: dict[str, Any] = {}

        # Coding feature: launcher sets this callback to publish inbound
        # coding_* WS messages to the session bus. Stays None when
        # CODING_ENABLED is off → broadcaster ignores coding messages.
        # See coding/INTEGRATION_GUIDE.md.
        self._coding_inbound_callback: Any = None

        # Visual Scenario Analysis: launcher sets this callback to publish
        # inbound scenario_media_* WS messages (playback ended/error/
        # skipped) to the session bus / Director. Mirrors
        # `_coding_inbound_callback` exactly.
        self._scenario_inbound_callback: Any = None
        # Last `scenario_item_start` payload sent, so a candidate WHO
        # RECONNECTS mid-item (browser refresh, not a session crash — the
        # Director itself never restarted) can be resent it immediately
        # instead of waiting for the next natural item transition. No
        # equivalent exists for coding today; this is scenario-specific.
        # Cleared whenever `emit_phase` reports leaving the phase it was
        # sent for.
        self._last_scenario_state: dict[str, Any] | None = None

        # Latest interview phase id (warm_up, project_architecture, …). Cached
        # so a client that connects mid-interview is seeded with the current
        # phase on connect (see _handle_client) — the bus only fires
        # phase_changed on transitions, which a late joiner would miss.
        self._phase: str = ""
        # Which transport the brain listens on ("livekit" | "websocket"), once
        # decided. Re-sent on every attach: a page that refreshes mid-interview
        # must learn it again, and the runner only decides it once.
        self._media_transport: str = ""

        # LiveKit control channel (Phase 2): when the page talks to us through
        # the room, every JSON message also goes out through `_room_send`, and
        # the room's inbound messages come in through handle_room_message().
        self._room_send: Any = None
        self._room_present: Any = None
        # Set when the interview is being handed off (to another replica, or to
        # the WebSocket path): the runner's teardown must not mark it completed.
        self.handover: bool = False

        # Audio playback ack callback — fires when the candidate browser confirms
        # TTS audio started/finished playing on the speaker
        # ({"type":"audio_playback_finished","sub_id":...}). Wired by the session
        # runner to drive the real playout signal (silence timer + wrap-up hold).
        self._audio_ack_callback: Any = None

        # Mic mute callback — fires when the candidate mutes or unmutes
        # themselves ({"type":"mic_muted","muted":true}).
        self._mic_mute_callback: Any = None

    def set_mic_mute_callback(self, cb) -> None:
        """Install a callback for candidate mic mute/unmute.

        Signature: `async def cb(muted: bool) -> None`. Wired by the session
        runner to the director, which treats a mute mid-utterance as an
        explicit endpoint — the VAD cannot see one, because mute stops the
        very frames the endpoint would be made of.
        """
        self._mic_mute_callback = cb

    def set_coding_inbound_callback(self, cb) -> None:
        """Install a callback that receives parsed coding_* JSON messages.

        Signature: `async def cb(payload: dict) -> None`. The launcher uses
        this to publish messages onto the session event bus so the director
        and event log see them.
        """
        self._coding_inbound_callback = cb

    def set_scenario_inbound_callback(self, cb) -> None:
        """Install a callback that receives parsed scenario_media_* JSON
        messages (playback ended / error / skipped). Mirrors
        `set_coding_inbound_callback`.

        Signature: `async def cb(payload: dict) -> None`.
        """
        self._scenario_inbound_callback = cb

    def set_audio_ack_callback(self, cb) -> None:
        """Install a callback for candidate audio-playback ack messages
        ({"type":"audio_playback_finished"|"audio_playback_started","sub_id":...}).

        Signature: `async def cb(parsed: dict) -> None`. Fires when the candidate
        browser reports TTS playback progress on the speaker — the real signal for
        the silence timer + wrap-up teardown."""
        self._audio_ack_callback = cb

    def emit_control(self, msg_type: str, **payload) -> None:
        """Broadcast a control JSON message to ALL connected clients.

        Used for session-lifecycle events the candidate should be aware of
        even though they don't come off the bus — e.g.
        `{"type":"session_ended","reason":"..."}` when the session is torn
        down by the runner, instead of a silent disconnect.
        """
        msg = {"type": msg_type}
        msg.update(payload)
        self._enqueue_out(("json", msg))

    @property
    def media_transport(self) -> str:
        return self._media_transport

    def set_media_transport(self, transport: str) -> None:
        self._media_transport = transport
        self.emit_control("media_transport", transport=transport)

    def emit_phase(self, phase: str) -> None:
        """Broadcast the current interview phase to all clients and cache it.

        The brain emits phase_changed on the bus only at transitions; this
        relays it to the browser (transcript marker) AND remembers it so a
        reconnecting client gets seeded on connect. Skips no-op re-emits so we
        don't append duplicate phase rows.
        """
        if not phase or phase == self._phase:
            return
        self._phase = phase
        self.emit_control("phase_changed", to_phase=phase)
        # A phase change means we've left whatever phase the cached scenario
        # state was for (scenario items never span a phase boundary) — drop
        # it so a LATER reconnect doesn't wrongly reseed a stale item.
        self._last_scenario_state = None

    def emit_coding_event(self, event_type: str, payload: dict[str, Any]) -> None:
        """Forward a coding-related event to the browser as `{type: event_type, ...payload}`.

        Called from `WebLauncher._subscribe_to_bus` when a coding bus event
        fires. Goes through the same outbound queue as audio/STT messages,
        so it's serialized with all other browser-bound traffic.
        """
        msg = {"type": event_type}
        msg.update(payload)
        self._enqueue_out(("json", msg))

    def emit_scenario_event(self, event_type: str, payload: dict[str, Any]) -> None:
        """Forward a Visual Scenario Analysis event to the browser as
        `{type: event_type, ...payload}`. Mirrors `emit_coding_event`.

        Caches `scenario_item_start` payloads (see `_last_scenario_state`)
        so a reconnecting candidate can be reseeded — cleared on the next
        `emit_phase` (see there)."""
        msg = {"type": event_type}
        msg.update(payload)
        if event_type == "scenario_item_start":
            self._last_scenario_state = dict(msg)
        self._enqueue_out(("json", msg))

    # ── LiveKit control channel ──────────────────────────────────────────
    def attach_room(self, send, present=None) -> None:
        """``async send(text)`` publishes one JSON message to the page via the
        room; ``present(identity=None) -> bool`` says whether the candidate (or
        one particular tab) is in it."""
        self._room_send = send
        self._room_present = present

    def detach_room(self) -> None:
        self._room_send = None
        self._room_present = None

    def room_present(self, identity: str | None = None) -> bool:
        try:
            return bool(self._room_present and self._room_present(identity))
        except Exception:
            return False

    async def handle_room_message(self, text: str) -> None:
        try:
            parsed = json.loads(text)
        except (TypeError, ValueError):
            return
        if parsed.get("type") == "attach":
            # The page joined (or rejoined) the room: bring it up to date, as
            # a WebSocket attach does.
            if self._room_send is not None:
                for m in self._seed_messages():
                    try:
                        await self._room_send(json.dumps(m))
                    except Exception as e:
                        logger.warning("[WEB] room seed send failed: %s", e)
            return
        await self.handle_inbound_json(parsed)

    async def flush(self, timeout_s: float = 2.0) -> None:
        """Wait (bounded) until queued outbound messages have been sent."""
        deadline = asyncio.get_running_loop().time() + timeout_s
        while not self._out_q.empty() and asyncio.get_running_loop().time() < deadline:
            await asyncio.sleep(0.05)
        await asyncio.sleep(0.1)  # the last item is dequeued before it's sent

    # ── lifecycle ────────────────────────────────────────────────────────

    async def start(self) -> None:
        self._server = await serve(self._handle_client, self._host, self._port)
        self._consumer_task = asyncio.create_task(
            self._consumer_loop(), name="web-broadcaster"
        )
        logger.info(
            "[WEB] broadcaster listening on ws://%s:%d (sample_rate=%dHz)",
            self._host, self._port, self._sample_rate_hz,
        )

    async def start_embedded(self) -> None:
        """Start ONLY the outbound consumer loop — skip the websockets server.

        Used when the broadcaster is hosted inside a foreign WS server (e.g.
        FastAPI on Azure App Service, which routes a single external port to
        a `@app.websocket(...)` route). The host accepts the WebSocket and
        calls :meth:`handle_client_via_adapter` to drive the same per-client
        protocol the standalone server runs."""
        self._consumer_task = asyncio.create_task(
            self._consumer_loop(), name="web-broadcaster-embedded"
        )
        logger.info(
            "[WEB] broadcaster embedded (no internal WS server, sample_rate=%dHz)",
            self._sample_rate_hz,
        )

    async def handle_client_via_adapter(self, conn) -> None:
        """Public entry point for foreign WS hosts.

        `conn` must look like a `websockets` ``ServerConnection``: it needs
        ``async def send(data: str | bytes)`` and ``async for msg in conn``
        that yields ``str`` or ``bytes`` messages. See
        ``deploy/azure_app.py`` for the FastAPI adapter."""
        return await self._handle_client(conn)

    async def stop(self) -> None:
        if self._consumer_task is not None:
            self._consumer_task.cancel()
            try:
                await self._consumer_task
            except (asyncio.CancelledError, Exception):
                pass
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()
        if self._dropped_out_frames:
            logger.warning(
                "[WEB] dropped %d outbound frames (queue overflow)",
                self._dropped_out_frames,
            )
        if self._dropped_mic_frames:
            logger.warning(
                "[WEB] dropped %d mic frames (queue overflow — browser sending faster than orchestrator consuming)",
                self._dropped_mic_frames,
            )

    # ── outbound: orchestrator → browser ────────────────────────────────

    def emit_audio_start(self, text: str, sub_id: str = "") -> None:
        self._enqueue_out(("json", {
            "type": "audio_start",
            "text": text,
            "sub_id": sub_id,
            "sample_rate": self._sample_rate_hz,
            # Interview identity — the browser records only AI audio whose
            # session_id matches its own token (guards cross-interview bleed).
            "session_id": self.session_id,
        }))

    def emit_pcm(self, pcm: bytes) -> None:
        if pcm:
            self._enqueue_out(("binary", TAG_AI + pcm))

    def emit_audio_end(self, sub_id: str = "", duration_ms: int | None = None) -> None:
        msg: dict = {"type": "audio_end", "sub_id": sub_id}
        if duration_ms is not None:
            msg["duration_ms"] = duration_ms
        self._enqueue_out(("json", msg))

    def emit_audio_cancel(self, sub_id: str = "") -> None:
        self._enqueue_out(("json", {"type": "audio_cancel", "sub_id": sub_id}))

    def emit_stt_partial(self, text: str, speaker: str = "") -> None:
        if text:
            msg = {"type": "stt_partial", "text": text}
            if speaker:
                msg["speaker"] = speaker
            self._enqueue_out(("json", msg))

    def emit_stt_final(self, text: str, speaker: str = "") -> None:
        if text:
            msg = {"type": "stt_final", "text": text}
            if speaker:
                msg["speaker"] = speaker
            self._enqueue_out(("json", msg))

    def emit_session_end(self) -> None:
        self._enqueue_out(("json", {"type": "session_end"}))

    def _enqueue_out(self, item: _QueueItem) -> None:
        try:
            self._out_q.put_nowait(item)
        except asyncio.QueueFull:
            self._dropped_out_frames += 1
            if self._dropped_out_frames % 100 == 1:
                logger.warning(
                    "[WEB] outbound queue full — dropping (total=%d)",
                    self._dropped_out_frames,
                )

    # ── inbound: browser → orchestrator (mic PCM) ───────────────────────

    @property
    def mic_queue(self) -> asyncio.Queue[bytes]:
        """The queue BrowserMicAudioSource awaits frames from."""
        return self._mic_q

    # ── consumer loop ────────────────────────────────────────────────────

    async def _consumer_loop(self) -> None:
        try:
            while True:
                kind, payload = await self._out_q.get()
                room_send = self._room_send
                if not self._clients and room_send is None:
                    continue
                # "json" control messages are serialized here; "binary" is TTS PCM.
                data = json.dumps(payload) if kind == "json" else payload
                if self._clients:
                    await self._broadcast(data)
                # Audio never goes through the room's data channel (it has its
                # own track); only control messages do.
                if room_send is not None and kind == "json":
                    try:
                        await room_send(data)
                    except Exception as e:
                        logger.warning("[WEB] room control send failed: %s", e)
        except asyncio.CancelledError:
            raise
        except Exception as e:  # pragma: no cover
            logger.error("[WEB] consumer loop crashed: %s", e)

    async def _broadcast(self, data: str | bytes) -> None:
        """Send `data` to every connected client — the candidate's browser
        (more than one only while a refreshed tab's old socket drains)."""
        dead: list[ServerConnection] = []
        for ws in self._clients:
            try:
                await ws.send(data)
            except websockets.ConnectionClosed:
                dead.append(ws)
            except Exception as e:  # pragma: no cover
                logger.warning("[WEB] send failed for client: %s", e)
                dead.append(ws)
        for ws in dead:
            self._clients.discard(ws)


    async def handle_inbound_json(self, parsed: dict[str, Any]) -> None:
        """One control message from the page, from either channel."""
        msg_type = parsed.get("type")
        if msg_type == "start" and not self.start_signal.is_set():
            self.candidate_meta = parsed.get("candidate") or {}
            logger.info(
                "[WEB] start signal received (visual=%s, candidate=%s)",
                parsed.get("visual_mode"), self.candidate_meta,
            )
            self.start_signal.set()
        elif msg_type == "end":
            logger.info("[WEB] end signal received from browser")
            self.end_signal.set()
        elif msg_type in ("audio_playback_finished", "audio_playback_started"):
            # Candidate browser confirming TTS playback progress on the
            # speaker — the real signal for the silence timer + wrap-up
            # hold.
            if self._audio_ack_callback is not None:
                try:
                    await self._audio_ack_callback(parsed)
                except Exception as e:
                    logger.warning("[WEB] audio ack callback error: %s", e)
        elif msg_type == "mic_muted":
            # The candidate muted/unmuted themselves. The server has no other
            # way to learn this: mute stops the frames, and "no frames" is
            # indistinguishable from a stalled network to the VAD, which needs
            # to HEAR silence to call the end of an utterance. Without this the
            # director latches on candidate_speaking and the AI never speaks
            # again. Dropped silently when no callback is installed (an older
            # browser simply never sends it).
            if self._mic_mute_callback is not None:
                try:
                    await self._mic_mute_callback(bool(parsed.get("muted")))
                except Exception as e:
                    logger.warning("[WEB] mic mute callback error: %s", e)
        elif isinstance(msg_type, str) and msg_type.startswith("coding_"):
            # Coding feature inbound dispatch. Launcher installs the
            # callback; if not installed (CODING_ENABLED off), drop
            # silently — old browsers without coding panel won't send
            # these messages, and feature-off deploys ignore them.
            if self._coding_inbound_callback is not None:
                try:
                    await self._coding_inbound_callback(parsed)
                except Exception as e:
                    logger.warning(
                        "[WEB] coding inbound callback error: %s", e
                    )
        elif isinstance(msg_type, str) and msg_type.startswith("scenario_"):
            # Visual Scenario Analysis inbound dispatch (media
            # playback ended/error/skipped acks). Mirrors the coding
            # branch immediately above.
            if self._scenario_inbound_callback is not None:
                try:
                    await self._scenario_inbound_callback(parsed)
                except Exception as e:
                    logger.warning(
                        "[WEB] scenario inbound callback error: %s", e
                    )

    # ── per-client handler ──────────────────────────────────────────────

    def _seed_messages(self) -> list[dict[str, Any]]:
        """What a page needs on (re)attach, whichever channel it uses."""
        msgs: list[dict[str, Any]] = [{
            "type": "hello",
            "sample_rate": self._sample_rate_hz,
            "start_armed": not self.start_signal.is_set(),
        }]
        # The current phase, so a candidate reconnecting mid-interview shows
        # the live phase instead of a blank pill until the next transition.
        if self._phase:
            msgs.append({"type": "phase_changed", "to_phase": self._phase})
        if self._media_transport:
            msgs.append({"type": "media_transport", "transport": self._media_transport})
        # The CURRENT Visual Scenario Analysis item too, so a candidate who
        # reconnects mid-item (browser refresh — the Director itself never
        # restarted) gets it back immediately instead of waiting for the next
        # natural item transition. `resync=True` tells the client this is a
        # reseed, not a fresh dispatch, so it must NOT autoplay a video/audio
        # item from the start — show a Play button instead (see
        # ui/web/src/lib/candidateEngine.ts).
        if self._last_scenario_state:
            msgs.append({**self._last_scenario_state, "resync": True})
        return msgs

    async def _handle_client(self, ws: ServerConnection) -> None:
        self._clients.add(ws)
        logger.info("[WEB] client connected (%d total)", len(self._clients))
        try:
            for m in self._seed_messages():
                try:
                    await ws.send(json.dumps(m))
                except websockets.ConnectionClosed:
                    raise
                except Exception:
                    pass
            async for msg in ws:
                if isinstance(msg, (bytes, bytearray)):
                    # Binary frame = the candidate's mic PCM → the brain.
                    frame = bytes(msg)
                    try:
                        self._mic_q.put_nowait(frame)
                    except asyncio.QueueFull:
                        try:
                            self._mic_q.get_nowait()    # drop oldest
                            self._mic_q.put_nowait(frame)
                        except Exception:
                            pass
                        self._dropped_mic_frames += 1
                        if MIC_FRAMES_DROPPED is not None:
                            MIC_FRAMES_DROPPED.inc()
                        if self._dropped_mic_frames % 500 == 1:
                            logger.warning(
                                "[WEB] mic queue full — dropping oldest (total=%d)",
                                self._dropped_mic_frames,
                            )
                    continue

                # Text frame = JSON control message.
                try:
                    parsed = json.loads(msg)
                except (TypeError, ValueError):
                    continue
                await self.handle_inbound_json(parsed)
        except websockets.ConnectionClosed:
            pass
        finally:
            self._clients.discard(ws)
            logger.info("[WEB] client disconnected (%d remaining)", len(self._clients))
