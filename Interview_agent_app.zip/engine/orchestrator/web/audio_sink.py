"""BrowserSpeakerAudioSink — implements :class:`AudioSink` over a WebSocket.

Sends TTS PCM out to the browser as binary frames. The browser plays them
through ``<audio>`` (or TalkingHead) via Web Audio API. There is no local
playback in this path — the browser IS the speaker.

Why ``bytes_buffered()`` returns 0
-----------------------------------
With local sounddevice playback, the orchestrator inspects
``bytes_buffered()`` to know "are the speakers caught up yet?" — that
decides when to mark a TTS turn as audibly complete (LatencyOrchestrator's
``_finalize_after_sink_drain``). With browser playback, the orchestrator has
NO ground-truth signal on when the browser actually finishes playing a frame
(short of an explicit ack round-trip, which we don't have today).

Returning ``0`` here means "I'm always considered drained" → the orchestrator
finalises the turn the moment the last PCM frame is queued for send. In
practice this is fine:

  * the WS queue drains in ~milliseconds (single-digit ms LAN, ~50ms remote)
  * the browser's own buffering smooths anything underneath that
  * the candidate's "Your turn" indicator flips sooner than truly accurate
    sink drain, but that's GOOD for snappy UX (no awkward silent gap)

If we ever need true drain accuracy, the browser can send a JSON ack on
each ``audio_end`` actually playing out — a small protocol addition.
"""
from __future__ import annotations

import asyncio
import logging
import time

from engine.brain.contracts.audio import SAMPLE_RATE_HZ

logger = logging.getLogger(__name__)


class BrowserSpeakerAudioSink:
    """Streams PCM out over a :class:`WebBroadcaster`."""

    def __init__(self, broadcaster, sample_rate_hz: int = SAMPLE_RATE_HZ) -> None:
        # Duck-typed `broadcaster` — avoid the import-time dependency so the
        # broadcaster module can keep evolving without forcing a redeploy here.
        self._broadcaster = broadcaster
        self.sample_rate_hz: int = sample_rate_hz
        self._bytes_sent = 0
        self._cancelled = False
        # Passive playout clock. bytes_buffered() stays 0 (see docstring) so
        # per-turn finalisation is unchanged, but we ALSO model when the browser
        # will finish playing what we've queued: each queued PCM chunk advances a
        # monotonic "playout end" by its real-time duration. remaining_playout_s()
        # then estimates how much audio is still to be heard. Used ONLY at session
        # end (InterviewSession.__aexit__) to hold teardown until the farewell has
        # actually played out — Azure TTS generates far faster than real time, so
        # "last PCM generated" is seconds ahead of "last PCM heard", and tearing
        # down at generation-time cut the AI off mid-sentence.
        self._playout_end_monotonic: float = 0.0

        # ── Real browser playout ack ────────────────────────────────────────
        # The browser sends {"type":"audio_playback_finished","sub_id":...} when
        # an utterance has actually finished playing on the speaker (wall-clock in
        # avatar mode, audio-clock in minimal mode). We track the sub_id we're
        # waiting on (set at audio_start via expect_playout) and clear it on the
        # ack (mark_played). While waiting, bytes_buffered() returns non-zero so
        # the orchestrator's _finalize_after_sink_drain — and thus AUDIO_DONE, the
        # silence-timer start, and the wrap-up gate — wait for REAL playback end
        # instead of generation end. _playout_done_event lets __aexit__ hold
        # teardown until the farewell truly finished.
        self._awaiting_sub: str | None = None
        self._playout_done_event: asyncio.Event = asyncio.Event()
        self._playout_done_event.set()  # nothing outstanding at start

    def expect_playout(self, sub_id: str) -> None:
        """Mark that an utterance (sub_id) has started streaming to the browser
        and we're now awaiting its playback-finished ack. Called at audio_start,
        BEFORE the PCM/drain — so bytes_buffered() reports 'still playing' until
        the browser confirms. A newer sub_id supersedes an older wait."""
        self._awaiting_sub = sub_id or "?"
        self._playout_done_event.clear()

    def mark_played(self, sub_id: str = "") -> None:
        """The browser confirmed sub_id finished playing on the speaker. Clears
        the wait if it matches the one we're awaiting (empty sub_id matches the
        current wait, for robustness)."""
        if self._awaiting_sub is None:
            return
        if not sub_id or sub_id == self._awaiting_sub:
            self._awaiting_sub = None
            self._playout_done_event.set()

    @property
    def playout_done_event(self) -> asyncio.Event:
        """Set when no utterance is awaiting a playback-finished ack. __aexit__
        awaits this (bounded) so wrap-up teardown holds for the real farewell."""
        return self._playout_done_event

    def _advance_playout(self, pcm: bytes) -> None:
        # 16-bit mono → 2 bytes/sample. max(now, prev) so a gap between turns
        # resets the clock to real time rather than compounding stale lead.
        now = time.monotonic()
        dur_s = len(pcm) / float(self.sample_rate_hz * 2)
        self._playout_end_monotonic = max(self._playout_end_monotonic, now) + dur_s

    def remaining_playout_s(self) -> float:
        """Estimated seconds of already-queued audio the browser has yet to play.
        0.0 once the modelled playout has caught up (or nothing is queued)."""
        return max(0.0, self._playout_end_monotonic - time.monotonic())

    # ── AudioSink protocol ──────────────────────────────────────────────

    def start(self) -> None:
        # Broadcaster is already started by the launcher — this is a no-op
        # to satisfy the SpeakerAudioSink-like surface InterviewSession
        # expects.
        logger.info(
            "[WEB-SINK] sink ready @ %d Hz (browser handles playback)",
            self.sample_rate_hz,
        )

    async def stop(self) -> None:
        logger.info(
            "[WEB-SINK] sink stopped (total bytes sent=%d)", self._bytes_sent,
        )

    async def play(self, pcm: bytes) -> None:
        """Queue PCM for transmission to the browser. Non-blocking."""
        if not pcm:
            return
        self._broadcaster.emit_pcm(pcm)
        self._bytes_sent += len(pcm)
        self._advance_playout(pcm)

    def play_sync(self, pcm: bytes) -> None:
        """Synchronous variant used by ``InterviewSession._on_pcm``. Same
        behaviour as :meth:`play` — both are non-blocking because the
        broadcaster's emit_pcm pushes onto an asyncio.Queue with no await."""
        if not pcm:
            return
        self._broadcaster.emit_pcm(pcm)
        self._bytes_sent += len(pcm)
        self._advance_playout(pcm)

    async def flush(self) -> None:
        """Cancel any in-flight utterance on the browser side. Used for
        barge-in: stop the avatar from finishing a sentence the user just
        interrupted."""
        self._broadcaster.emit_audio_cancel()
        # Barge-in drops whatever was queued on the browser too, so the modelled
        # playout is no longer outstanding — reset the clock to now and release
        # any playback-finished wait (the browser won't ack a cancelled utterance).
        self._playout_end_monotonic = time.monotonic()
        self._awaiting_sub = None
        self._playout_done_event.set()

    def bytes_buffered(self) -> int:
        # Ack-aware: non-zero while we're awaiting the browser's real
        # playback-finished ack for the current utterance, so the orchestrator's
        # drain loop waits for actual playback end (bounded by its own deadline).
        # 0 once the ack arrives (or nothing outstanding). This is what makes the
        # silence timer + wrap-up gate fire at real playback end, not generation.
        return 1 if self._awaiting_sub is not None else 0
