"""Static HTTP server for ``ui/candidate/``.

Identical in shape to :mod:`orchestrator_new.avatar.http_server` — both serve
a static directory in a background thread so the operator gets one clickable
URL instead of running ``python -m http.server`` separately.

Kept as a separate file (rather than reusing the avatar version) so the
``web/`` subpackage has zero import-time dependencies on ``avatar/``. The
two can evolve independently or one can be retired without breaking the other.
"""
from __future__ import annotations

import http.server
import logging
import socketserver
import threading
from pathlib import Path

logger = logging.getLogger(__name__)


class _QuietHandler(http.server.SimpleHTTPRequestHandler):
    # Suppress per-request access logs — the orchestrator's stdout is busy.
    def log_message(self, *_args) -> None:  # noqa: D401
        return


class _ReusableServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


class CandidateStaticServer:
    """Serves the candidate UI directory in a background thread."""

    def __init__(self, directory: Path, host: str, port: int) -> None:
        self._directory = directory
        self._host = host
        self._port = port
        self._httpd: _ReusableServer | None = None
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        directory = str(self._directory)

        def _factory(*args, **kwargs):
            return _QuietHandler(*args, directory=directory, **kwargs)

        self._httpd = _ReusableServer((self._host, self._port), _factory)
        self._thread = threading.Thread(
            target=self._httpd.serve_forever,
            name="web-static-http",
            daemon=True,
        )
        self._thread.start()
        logger.info(
            "[WEB] static UI on http://%s:%d (serving %s)",
            self._host, self._port, self._directory,
        )

    def stop(self) -> None:
        if self._httpd is not None:
            self._httpd.shutdown()
            self._httpd.server_close()
            self._httpd = None
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None
