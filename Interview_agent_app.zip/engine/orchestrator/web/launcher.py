"""WebLauncher — single entry point used by ``live_main`` for Track B.

Encapsulates EVERYTHING the browser candidate UI needs at runtime so
``live_main`` stays a thin wiring layer. The launcher:

  * registers its own CLI flags (``add_cli_args``)
  * decides whether the web path is enabled (``from_args``)
  * exposes the audio source + sink that REPLACE sounddevice
    (``audio_source``, ``audio_sink``)
  * attaches to a running ``InterviewSession`` — starts the WS broadcaster,
    starts the static HTTP server, monkey-patches ``speak_chunk`` to capture
    text for the avatar, subscribes to the event bus for STT echo + TTS
    lifecycle, prints the URL banner, opens the browser, awaits the user
    clicking "Start Interview" in the lobby (``attach``)
  * tears everything down cleanly (``shutdown``)

When the web path is disabled (no ``--web``), ``from_args`` returns ``None``
and ``live_main`` treats it as if this subpackage didn't exist — the legacy
sounddevice path runs unchanged.

Why monkey-patch ``speak_chunk``?
---------------------------------
Same reason as :mod:`orchestrator_new.avatar.launcher` — the browser's
TalkingHead needs the TEXT of each utterance to derive viseme timings, and
subscribing to ``TTS_SPEAK_CHUNK_SENT`` alone misses the filler / apology /
STT-wait code paths. Patching ``TTSClient.speak_chunk`` catches every code
path that produces TTS audio. Text is keyed by ``f"{turn_id}-{sequence_id}"``
which matches the ``request_id`` field on subsequent ``TTS_AUDIO_*`` events.

End-of-session
--------------
Two ways the interview ends:
  * Browser sends ``{"type":"end"}`` → ``end_signal`` set → live_main exits
    the session run loop.
  * Orchestrator decides to end (e.g. score complete) → ``emit_session_end()``
    notifies the browser to swap to the done screen.
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import webbrowser
from pathlib import Path
from typing import Optional, Tuple

from engine.orchestrator.web.broadcaster import WebBroadcaster
from engine.orchestrator.web.http_server import CandidateStaticServer
from engine.orchestrator.web.audio_source import BrowserMicAudioSource
from engine.orchestrator.web.audio_sink import BrowserSpeakerAudioSink

logger = logging.getLogger(__name__)

# Candidate UI lives at <repo_root>/ui/candidate/. This file is at
# <repo_root>/orchestrator_new/web/launcher.py → two parents up.
_UI_DIR: Path = Path(__file__).resolve().parent.parent.parent.parent / "ui" / "candidate"


class WebLauncher:
    """Coordinator for the browser candidate UI. Created via ``from_args``."""

    # ── CLI ──────────────────────────────────────────────────────────────

    @staticmethod
    def add_cli_args(parser: argparse.ArgumentParser) -> None:
        g = parser.add_argument_group("web candidate UI (Track B — production)")
        g.add_argument(
            "--web", action="store_true",
            help="Run with the browser candidate UI instead of local "
                 "sounddevice. Mic + speakers move to the browser; getUserMedia "
                 "handles AEC/AGC/NS for free. The orchestrator boots a static "
                 "server for ui/candidate/ + a WebSocket on --web-ws-port.",
        )
        g.add_argument(
            "--web-host", default="localhost",
            help="Bind host for both the WebSocket and the static HTTP "
                 "server. Default: localhost.",
        )
        g.add_argument(
            "--web-ws-port", type=int, default=9100,
            help="WebSocket port for browser ↔ orchestrator. Default: 9100. "
                 "(Avoids 9000 which the legacy --avatar flag uses.)",
        )
        g.add_argument(
            "--web-http-port", type=int, default=8090,
            help="Static-file port for the candidate UI. Default: 8090. "
                 "Operator opens http://<host>:<port>/?ws=<ws_port>.",
        )
        g.add_argument(
            "--web-no-open-browser", action="store_true",
            help="With --web set, don't auto-open a browser tab. URL is "
                 "printed regardless.",
        )
        g.add_argument(
            "--web-no-wait-for-ui", action="store_true",
            help="With --web set, start the interview immediately instead of "
                 "waiting for the candidate to complete the lobby and click "
                 "Start. Useful for backend dev without a browser.",
        )

    # ── construction ─────────────────────────────────────────────────────

    @classmethod
    def from_args(cls, args: argparse.Namespace) -> Optional["WebLauncher"]:
        if not getattr(args, "web", False):
            return None
        return cls(
            host=args.web_host,
            ws_port=args.web_ws_port,
            http_port=args.web_http_port,
            candidate_name=getattr(args, "candidate_name", "Candidate") or "Candidate",
            role=getattr(args, "role", "the role") or "the role",
            sample_rate_hz=getattr(args, "tts_sample_rate", 16_000),
            open_browser=not args.web_no_open_browser,
            wait_for_ui=not args.web_no_wait_for_ui,
        )

    def __init__(
        self,
        host: str,
        ws_port: int,
        http_port: int,
        candidate_name: str,
        role: str,
        sample_rate_hz: int,
        open_browser: bool,
        wait_for_ui: bool,
    ) -> None:
        self._host = host
        self._ws_port = ws_port
        self._http_port = http_port
        self._candidate_name = candidate_name
        self._role = role
        self._open_browser = open_browser
        self._wait_for_ui = wait_for_ui

        self._broadcaster = WebBroadcaster(
            host=host, port=ws_port, sample_rate_hz=sample_rate_hz,
        )
        self._static = CandidateStaticServer(
            directory=_UI_DIR, host=host, port=http_port,
        )
        self._patch_restore = None
        self._sub_text: dict[str, str] = {}

        # Cached audio I/O so live_main can ask for the same instances
        # before and after the session boots.
        self._audio_source: BrowserMicAudioSource | None = None
        self._audio_sink: BrowserSpeakerAudioSink | None = None

    # ── public API live_main uses ────────────────────────────────────────

    @property
    def url(self) -> str:
        # ?name=...&role=...&ws=... so the lobby pre-fills the candidate's
        # name and role and the WS client uses the right port.
        from urllib.parse import urlencode
        qs = urlencode({
            "name": self._candidate_name,
            "role": self._role,
            "ws":   self._ws_port,
        })
        return f"http://{self._host}:{self._http_port}/?{qs}"

    @property
    def end_signal(self) -> asyncio.Event:
        """Set when the candidate clicks End in the browser."""
        return self._broadcaster.end_signal

    def audio_source(self) -> BrowserMicAudioSource:
        if self._audio_source is None:
            self._audio_source = BrowserMicAudioSource(self._broadcaster.mic_queue)
        return self._audio_source

    def audio_sink(self) -> BrowserSpeakerAudioSink:
        if self._audio_sink is None:
            self._audio_sink = BrowserSpeakerAudioSink(self._broadcaster)
        return self._audio_sink

    async def start_servers(self) -> None:
        """Start the WS broadcaster + static HTTP server. Call BEFORE the
        InterviewSession boots so the candidate can begin loading the lobby
        while we're still wiring."""
        await self._broadcaster.start()
        self._static.start()
        print()
        print("=" * 70)
        print(f"  CANDIDATE UI →  {self.url}")
        print("=" * 70)
        print()
        if self._open_browser:
            try:
                webbrowser.open(self.url)
            except Exception as e:
                logger.warning("[WEB] webbrowser.open failed: %s", e)

    async def wait_for_candidate(self) -> None:
        """Block until the candidate clicks Start in the lobby (or skip
        immediately if ``--web-no-wait-for-ui``)."""
        if not self._wait_for_ui:
            return
        print("  waiting for candidate → click 'Start Interview' in the browser")
        print("  (or pass --web-no-wait-for-ui to skip)…")
        await self._broadcaster.start_signal.wait()
        meta = self._broadcaster.candidate_meta
        print(f"  ↳ candidate ready (visual={meta.get('visual_mode', '?')})")
        print()

    async def attach(self, session) -> None:
        """Hook into the running session — install text-capture patch and
        subscribe to the bus for STT echo + TTS lifecycle. Must be called
        AFTER ``async with InterviewSession(...) as session:`` so the bus is
        bound to the running loop."""
        self._install_speak_chunk_patch(session)
        self._subscribe_to_bus(session)

    async def shutdown(self) -> None:
        # Tell the browser to switch to the done screen.
        try:
            self._broadcaster.emit_session_end()
        except Exception:
            pass
        if self._patch_restore is not None:
            try:
                self._patch_restore()
            except Exception:
                pass
            self._patch_restore = None
        await self._broadcaster.stop()
        self._static.stop()

    # ── internals ────────────────────────────────────────────────────────

    def _install_speak_chunk_patch(self, session) -> None:
        """Wrap ``session._tts.speak_chunk`` to record per-utterance text.
        See module docstring for rationale (same as avatar launcher)."""
        tts = session._tts
        original = tts.speak_chunk
        sub_text = self._sub_text

        async def patched(turn_id, sequence_id, text):
            sub_id = f"{turn_id}-{sequence_id}"
            if text and text.strip():
                sub_text[sub_id] = text
            return await original(turn_id, sequence_id, text)

        tts.speak_chunk = patched  # type: ignore[method-assign]
        self._patch_restore = lambda: setattr(tts, "speak_chunk", original)

    def _subscribe_to_bus(self, session) -> None:
        """Translate bus events into JSON frames for the browser:
          * TTS_AUDIO_START → audio_start (with text from the patch cache)
          * TTS_AUDIO_END   → audio_end
          * TTS_CANCELLED   → audio_cancel
          * STT_PARTIAL     → stt_partial (live transcript "typing")
          * STT_FINAL       → stt_final  (committed transcript line)
          * coding_phase_started → coding_phase_start (coding feature)
          * coding_phase_ended   → coding_phase_end
          * coding_hint_delivered → coding_hint
          * scenario_item_dispatched → scenario_item_start (Visual Scenario
            Analysis feature)
        """
        from engine.brain.contracts.events import EventKind

        broadcaster = self._broadcaster
        sub_text = self._sub_text

        # Coding bus-kind → outbound WS type. Bus uses past tense (started/
        # ended/delivered); WS uses imperative (start/end/_). Mapping kept
        # tiny on purpose — most coding events are server-side only.
        _CODING_OUTBOUND: dict[str, str] = {
            "coding_phase_started": "coding_phase_start",
            "coding_phase_ended": "coding_phase_end",
            "coding_hint_delivered": "coding_hint",
            # Fired once per session by the director if the cadence has a
            # coding phase. Browser handler at ui/candidate/app.js:665-667
            # lazy-imports coding_panel.js and starts Pyodide download.
            "coding_preload": "coding_preload",
        }

        # Visual Scenario Analysis bus-kind → outbound WS type. Kept in its
        # OWN dict (mirroring _CODING_OUTBOUND's shape exactly) rather than
        # folded into it — the two features are unrelated and mutually
        # exclusive per phase.
        _SCENARIO_OUTBOUND: dict[str, str] = {
            "scenario_item_dispatched": "scenario_item_start",
            "scenario_phase_ended": "scenario_phase_end",
        }

        def _payload_to_dict(payload) -> dict:
            """Coerce a dataclass / dict / object to a plain JSON-safe dict."""
            if isinstance(payload, dict):
                return payload
            if hasattr(payload, "__dict__"):
                # Strip private attrs, dataclass fields keep their names
                return {k: v for k, v in vars(payload).items()
                        if not k.startswith("_")}
            return {}

        async def _on_event(evt) -> None:
            try:
                kind = evt.kind.value if hasattr(evt.kind, "value") else evt.kind
                p = evt.payload or {}
                if kind == EventKind.TTS_AUDIO_START.value:
                    sub_id = p.get("request_id") or p.get("turn_id_subbed", "")
                    text = sub_text.pop(sub_id, "")
                    broadcaster.emit_audio_start(text, sub_id=sub_id)
                elif kind == EventKind.TTS_AUDIO_END.value:
                    sub_id = p.get("request_id") or p.get("turn_id_subbed", "")
                    broadcaster.emit_audio_end(sub_id=sub_id)
                elif kind == EventKind.TTS_CANCELLED.value:
                    sub_id = p.get("request_id") or p.get("turn_id_subbed", "")
                    broadcaster.emit_audio_cancel(sub_id=sub_id)
                elif kind == EventKind.STT_PARTIAL.value:
                    text = p.get("text") or p.get("transcript") or ""
                    broadcaster.emit_stt_partial(text, speaker=p.get("speaker") or "")
                elif kind == EventKind.STT_FINAL.value:
                    text = p.get("text") or p.get("transcript") or ""
                    broadcaster.emit_stt_final(text, speaker=p.get("speaker") or "")
                elif kind == EventKind.PHASE_CHANGED.value:
                    # Only the APPLIED transition reflects the live phase — the
                    # director also fires queued=True phase_changed events for
                    # pending transitions, which haven't taken effect yet.
                    if not p.get("queued"):
                        broadcaster.emit_phase(p.get("to_phase") or p.get("to") or "")
                elif isinstance(kind, str) and kind in _CODING_OUTBOUND:
                    # Coding bus event → browser. Payload may be a dataclass.
                    ws_type = _CODING_OUTBOUND[kind]
                    pdict = _payload_to_dict(p)
                    logger.info(
                        "[WEB] forwarding coding event %s → WS type=%s (keys=%s)",
                        kind, ws_type, sorted(pdict.keys()),
                    )
                    broadcaster.emit_coding_event(ws_type, pdict)
                elif isinstance(kind, str) and kind in _SCENARIO_OUTBOUND:
                    ws_type = _SCENARIO_OUTBOUND[kind]
                    pdict = _payload_to_dict(p)
                    logger.info(
                        "[WEB] forwarding scenario event %s → WS type=%s (item=%s)",
                        kind, ws_type, pdict.get("item_id"),
                    )
                    broadcaster.emit_scenario_event(ws_type, pdict)
            except Exception as e:
                logger.warning("[WEB] event handler error: %s", e)

        session._bus.subscribe(_on_event)

        # Seed the opening phase now. SESSION_STARTED already fired during
        # __aenter__ (attach() runs after the session context is entered), so
        # we read the current phase off session state rather than wait for an
        # event we'd miss. Live transitions arrive via PHASE_CHANGED above.
        try:
            broadcaster.emit_phase(getattr(session._state, "phase", "") or "")
        except Exception:
            pass

        # Coding feature: install inbound dispatch. Browser sends coding_*
        # WS messages → broadcaster receives → we publish to session bus →
        # director consumes (advance phase on coding_code_submitted, etc.).
        # No-op unless CODING_ENABLED is set.
        try:
            from features.coding import is_enabled as _coding_is_enabled
            from features.coding.messages import is_coding_message as _is_coding_msg
        except ImportError:
            _coding_is_enabled = lambda: False  # type: ignore[assignment]
            _is_coding_msg = lambda _p: False  # type: ignore[assignment]

        if _coding_is_enabled():
            bus_ref = session._bus

            # Per-session hint state — tracks which hint to deliver next per
            # coding phase. Key=phase_id, value=next hint index to deliver.
            # Hint level per (phase_id, question_id) — key is "phase::qid".
            _hint_levels: dict[str, int] = {}
            # Submitted question ids per phase. Multi-question coding phases
            # only advance once every qid in coding_question_ids has fired
            # a coding_code_submitted. Tracked here so the phase apply isn't
            # gated on a stateful WS rollup.
            _submitted_qids: dict[str, set[str]] = {}

            # WS message type → bus event kind. Most are pass-through; a few
            # have suffix tweaks to match the bus tense convention.
            _CODING_INBOUND: dict[str, str] = {
                "coding_code_submitted": "coding_code_submitted",
                "coding_code_run_result": "coding_code_run_result",
                "coding_code_run": "coding_code_run",
                "coding_code_edit": "coding_code_edit",
                "coding_hint_request": "coding_hint_requested",
                "coding_anti_cheat": "coding_anti_cheat",
                "coding_preload_ready": "coding_preload_ready",
                "coding_force_talk": "coding_force_talk_requested",
                "coding_panel_closed": "coding_panel_closed",
            }

            # Tracer (has session_id baked in) is the right path for publishing
            # to the bus. The bus's own publish_sync needs an Event object —
            # tracer.event() constructs and publishes for us.
            tracer_ref = session._tracer

            async def _on_coding_inbound(payload: dict) -> None:
                if not _is_coding_msg(payload):
                    return
                ws_type = payload.get("type", "")
                bus_kind = _CODING_INBOUND.get(ws_type)
                if bus_kind:
                    # Persist to bus → events.jsonl + any subscribers
                    try:
                        tracer_ref.event(bus_kind, **payload)
                    except Exception as e:
                        logger.warning(
                            "[WEB] failed to publish coding bus event %s: %s",
                            bus_kind, e,
                        )

                # Panel-close ack: browser unmounted the coding editor → release
                # the director's code-discussion handshake (see
                # Director.on_coding_panel_closed).
                if ws_type == "coding_panel_closed":
                    try:
                        session._director.on_coding_panel_closed()
                    except Exception as e:
                        logger.warning("[WEB] coding panel_closed failed: %s", e)

                # Hint request: deliver the next hint from library.yaml.
                # Looks up the question + current hint level for this phase,
                # emits coding_hint_delivered bus event AND voices the hint
                # via TTS (bypassing the slow LLM — same pattern as filler
                # agent uses for canned text). Browser shows text in banner;
                # candidate hears AI speak the hint.
                if ws_type == "coding_hint_request":
                    try:
                        phase_id = payload.get("phase_id", "")
                        from features.coding import get_question
                        from features.coding.events import (
                            CODING_HINT_DELIVERED as _CHD,
                        )
                        # Multi-question form: browser sends the specific
                        # question_id this hint is for. Legacy single-form
                        # browser doesn't send it — fall back to the FIRST
                        # question id on the phase.
                        qid = payload.get("question_id") or ""
                        if not qid:
                            cur_phase_obj = session._tracker.plan.get_phase(phase_id)
                            qids = getattr(cur_phase_obj, "coding_question_ids", []) or []
                            qid = qids[0] if qids else ""
                        if qid:
                            q = get_question(qid)
                            # Hint level tracked per (phase, question)
                            hint_key = f"{phase_id}::{qid}"
                            level = _hint_levels.get(hint_key, 0)
                            hint_text = None
                            if level < len(q.hints):
                                hint_text = q.hints[level]
                                _hint_levels[hint_key] = level + 1
                                announce_level = level + 1
                            else:
                                hint_text = (
                                    "You've used all available hints. "
                                    "Try clicking Talk to AI to ask a specific question."
                                )
                                announce_level = level
                            tracer_ref.event(
                                _CHD,
                                phase_id=phase_id,
                                question_id=qid,
                                hint_level=announce_level,
                                hint_text=hint_text,
                            )
                            try:
                                tts = session._tts
                                turn_id = f"hint-{phase_id}-{qid}-{announce_level}"
                                spoken = f"Hint: {hint_text}"
                                await tts.speak_chunk(turn_id, 1, spoken)
                                logger.info(
                                    "[coding] hint TTS dispatched phase=%s qid=%s level=%d",
                                    phase_id, qid, announce_level,
                                )
                            except Exception as tts_e:
                                logger.warning(
                                    "[coding] hint TTS failed: %s "
                                    "(text still delivered to browser)", tts_e,
                                )
                            logger.info(
                                "[coding] hint delivered phase=%s qid=%s level=%d/%d",
                                phase_id, qid, announce_level, len(q.hints),
                            )
                    except Exception as e:
                        logger.warning("[coding] hint dispatch failed: %s", e)

                # Force-talk: candidate clicked "Talk to AI" while in coding
                # phase. Reset ai_activity → IDLE so the director's dispatch
                # gate (which checks for non-phase_transition triggers in a
                # coding phase) becomes a no-op for this tick. AI will say
                # something like "Need any hints? What's giving you trouble?"
                if ws_type == "coding_force_talk":
                    try:
                        from engine.brain.contracts.session_state import (
                            AIActivityState as _AIState,
                        )
                        async def _unmute_for_force_talk(s):
                            s.ai_activity = _AIState.IDLE
                            # Also flip candidate-spoke flag so director treats
                            # this as an endpoint (not silence_prompt) and the
                            # slow LLM gets a "candidate signalled they want
                            # help" framing in its prompt.
                            s.candidate_spoke_since_last_ai = True
                        await session._store.mutate(_unmute_for_force_talk)
                        logger.info("[coding] force_talk — ai_activity unblocked")
                    except Exception as e:
                        logger.warning("[coding] force_talk failed: %s", e)

                # Auto-advance on Submit. Phase override still works for
                # voice ("I'm done") — this is the explicit-button path.
                # We set pending_phase to the next phase id and bump
                # ai_activity → AUDIO_DONE so the director's pending-apply
                # gate unblocks on the next tick.
                if ws_type == "coding_code_submitted":
                    try:
                        from engine.brain.contracts.session_state import (
                            AIActivityState as _AIState,
                        )
                        # Capture this submission and decide whether the
                        # phase advances. With multi-question phases the
                        # phase only advances when ALL questions have been
                        # submitted (or expired) — partial submits go into
                        # the bookkeeping but don't trigger the transition.
                        try:
                            from features.coding import get_question as _cd_get_q
                            sub_phase_id = payload.get("phase_id", "")
                            # Multi-question form: browser sends question_id;
                            # legacy single-question browser doesn't, so we
                            # fall back to the phase's first question.
                            sub_qid = payload.get("question_id") or ""
                            ph = session._tracker.plan.get_phase(sub_phase_id)
                            phase_qids = list(
                                getattr(ph, "coding_question_ids", []) or []
                            )
                            if not sub_qid and phase_qids:
                                sub_qid = phase_qids[0]
                            q_prompt = ""
                            fn_name = ""
                            if sub_qid:
                                _q = _cd_get_q(sub_qid)
                                q_prompt = _q.prompt or ""
                                fn_name = _q.function_name or ""
                            sub_snapshot = {
                                "phase_id": sub_phase_id,
                                "question_id": sub_qid or "",
                                "question_prompt": q_prompt,
                                "function_name": fn_name,
                                "code": payload.get("final_code", ""),
                                "test_results": payload.get("final_test_results", []),
                                "runs_used": payload.get("runs_used", 0),
                            }
                            async def _capture_submission(s):
                                # last_coding_submission is the MOST RECENT
                                # submission, used by the next phase's slow
                                # LLM to ground the discussion.
                                s.last_coding_submission = sub_snapshot
                            await session._store.mutate(_capture_submission)
                            logger.info(
                                "[coding] captured submission phase=%s qid=%s "
                                "code_len=%d tests=%d",
                                sub_phase_id, sub_qid, len(sub_snapshot["code"]),
                                len(sub_snapshot["test_results"]),
                            )
                            # Multi-question phase: only advance when ALL
                            # questions have been submitted. Track set of
                            # submitted qids per phase in the launcher's
                            # closure (mirrors _hint_levels).
                            submitted_set = _submitted_qids.setdefault(
                                sub_phase_id, set()
                            )
                            submitted_set.add(sub_qid)
                            remaining = [
                                q for q in phase_qids if q not in submitted_set
                            ]
                            if remaining:
                                logger.info(
                                    "[coding] partial submit on phase=%s — "
                                    "%d/%d done, waiting on %r",
                                    sub_phase_id, len(submitted_set),
                                    len(phase_qids), remaining,
                                )
                                # Keep the phase alive; don't advance yet.
                                # Browser stays on the editor for remaining
                                # questions.
                                return
                            logger.info(
                                "[coding] ALL %d question(s) submitted on "
                                "phase=%s — advancing", len(phase_qids),
                                sub_phase_id,
                            )
                        except Exception as cap_e:
                            logger.warning(
                                "[coding] failed to capture submission: %s",
                                cap_e,
                            )
                        cur_phase = session._store.state.phase
                        next_id = session._tracker.plan.next_phase_id(cur_phase)
                        if next_id is None:
                            # Terminal coding phase: arm the wrap-up auto-end
                            # gate AND dispatch a brief TTS farewell so the
                            # candidate gets a graceful exit. The director's
                            # auto-end gate (director.py:289-314) waits for an
                            # AUDIO_END that's > _end_request_ts_ms; without
                            # the farewell, no such audio_end ever fires (AI
                            # was gated silent during CODING) and the session
                            # would hang.
                            async def _exit_coding(s):
                                s.ai_activity = _AIState.AUDIO_DONE
                            await session._store.mutate(_exit_coding)
                            try:
                                session._director.request_session_end(
                                    reason="coding_submit_terminal",
                                )
                                tts = session._tts
                                await tts.speak_chunk(
                                    f"end-{cur_phase}", 1,
                                    "Thanks for your submission. We'll be in touch soon.",
                                )
                            except Exception as ee:
                                logger.warning(
                                    "[coding] terminal-end TTS failed: %s", ee,
                                )
                            logger.info(
                                "[coding] submit on terminal phase %s — "
                                "session end armed + farewell dispatched", cur_phase,
                            )
                        else:
                            async def _advance(s):
                                s.pending_phase = next_id
                                s.ai_activity = _AIState.AUDIO_DONE
                            await session._store.mutate(_advance)
                            logger.info(
                                "[coding] auto-advance on submit: %s → %s",
                                cur_phase, next_id,
                            )
                    except Exception as e:
                        logger.warning(
                            "[coding] submit auto-advance failed: %s", e
                        )

            broadcaster.set_coding_inbound_callback(_on_coding_inbound)
            logger.info("[WEB] coding feature enabled — inbound dispatch installed")

        # Visual Scenario Analysis: install inbound dispatch UNCONDITIONALLY
        # (unlike coding, there's no separate feature flag — a cadence
        # either has scenario_items phases or it doesn't, and
        # Director.on_scenario_media_ack is already a no-op when none is
        # active). Browser sends scenario_media_ended/_error/_skipped →
        # straight to the Director; no bus event needed for these (unlike
        # coding's hint-delivery flow, there's nothing else that consumes
        # them), so this skips the tracer_ref.event() step coding's version
        # has for its OTHER message types.
        async def _on_scenario_inbound(payload: dict) -> None:
            ws_type = payload.get("type", "")
            if ws_type not in (
                "scenario_media_ended", "scenario_media_error", "scenario_media_skipped",
            ):
                return
            try:
                session._director.on_scenario_media_ack(ws_type)
            except Exception as e:
                logger.warning("[WEB] scenario media ack failed: %s", e)

        broadcaster.set_scenario_inbound_callback(_on_scenario_inbound)
