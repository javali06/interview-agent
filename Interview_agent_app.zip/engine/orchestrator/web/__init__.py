"""Browser-based candidate UI integration (Track B).

This subpackage is the production-path counterpart to ``orchestrator_new.avatar``.
Where ``avatar/`` is an OPT-IN fan-out of TTS audio to a passive 3D-avatar UI,
``web/`` is the BIDIRECTIONAL candidate experience:

  * the browser captures candidate mic (with `getUserMedia` AEC/AGC/NS for free)
    and streams PCM16 mono @ 16 kHz over a WebSocket;
  * the orchestrator's audio pipeline consumes those frames via the standard
    ``AudioSource`` protocol — InterviewSession doesn't know the mic is remote;
  * TTS audio flows back the other way through ``BrowserSpeakerAudioSink`` →
    binary frames on the same socket → ``<audio>`` (or TalkingHead) playback;
  * STT partials/finals are also broadcast as JSON for the live transcript UI.

Why is this a separate subpackage from ``avatar/``?
---------------------------------------------------
* ``avatar/`` is one-way (server → browser).  ``web/`` is two-way.
* ``avatar/`` is OPT-IN and stacks on top of sounddevice.  ``web/`` REPLACES
  sounddevice — no local mic, no local speakers.
* Mixing the two would couple unrelated concerns and force ``avatar/`` to
  carry browser-mic plumbing it doesn't need.  Keeping them as siblings means
  both can evolve (or be retired) independently.

Public API
----------
Only ``WebLauncher`` is intended for use by ``live_main.py``.  The audio
source/sink classes are implementation details exposed through the launcher.
"""
from engine.orchestrator.web.launcher import WebLauncher

__all__ = ["WebLauncher"]
