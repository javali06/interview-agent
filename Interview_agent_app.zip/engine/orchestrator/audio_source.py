"""Microphone audio source.

Implements `stream_b_new.contracts.audio.AudioSource`. Captures the default
input device at 16 kHz mono float32, converts to PCM16, yields 20ms frames
(640 bytes each) via async iterator.

Includes loud diagnostics: device discovery at startup, RMS amplitude
monitoring with periodic logs, and a "DEAD MIC" warning if amplitude
stays near-zero. Stream A's Silero VAD won't fire speech_start on
inaudible audio — the agent then thinks you're not speaking.
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import AsyncIterator

import numpy as np
import sounddevice as sd

from engine.brain.contracts.audio import (
    FRAME_SAMPLES,
    SAMPLE_RATE_HZ,
)

logger = logging.getLogger(__name__)


# RMS thresholds for the dead-mic warning. Float32 samples in [-1, 1].
# A normal voice ~0.05–0.3 RMS. Below 0.001 over multiple seconds = mic dead.
_RMS_WARN_THRESHOLD = 0.001
_RMS_WARN_AFTER_S = 5.0


class MicAudioSource:
    """Default microphone → 20ms PCM16 frames."""

    def __init__(
        self,
        sample_rate: int = SAMPLE_RATE_HZ,
        frame_samples: int = FRAME_SAMPLES,
        *,
        device: int | str | None = None,
        gain: float = 1.0,
        rms_log_interval_s: float = 2.0,
    ) -> None:
        self.sample_rate = sample_rate
        self.frame_samples = frame_samples
        self._device = device
        self._gain = gain
        self._stream: sd.InputStream | None = None
        self._queue: asyncio.Queue[bytes] = asyncio.Queue(maxsize=128)
        self._loop: asyncio.AbstractEventLoop | None = None
        self._stopped = asyncio.Event()
        # Mic-level monitor.
        self._rms_log_interval_s = rms_log_interval_s
        self._rms_window: list[float] = []
        self._last_rms_log_t: float = 0.0
        self._dead_since: float | None = None

    async def start(self) -> None:
        self._loop = asyncio.get_running_loop()

        # ── device discovery — print available inputs so the user can see ──
        try:
            devices = sd.query_devices()
            default_in_idx = sd.default.device[0] if sd.default.device else None
            logger.info("=" * 60)
            logger.info("AUDIO INPUT DEVICES:")
            for i, dev in enumerate(devices):
                if dev.get("max_input_channels", 0) > 0:
                    is_default = " [DEFAULT]" if i == default_in_idx else ""
                    logger.info(
                        "  [%d] %s  (%d in, %d Hz)%s",
                        i, dev["name"],
                        dev["max_input_channels"],
                        int(dev.get("default_samplerate", 0)),
                        is_default,
                    )
            logger.info("=" * 60)
        except Exception as e:  # pragma: no cover
            logger.warning("device discovery failed: %s", e)

        self._stream = sd.InputStream(
            samplerate=self.sample_rate,
            channels=1,
            dtype="float32",
            blocksize=self.frame_samples,
            device=self._device,
            callback=self._sd_callback,
        )
        self._stream.start()
        active_dev = self._stream.device if hasattr(self._stream, "device") else "default"
        logger.info(
            "[MIC] capture started: device=%s sr=%d Hz frame=%d samples (%dms) gain=%.2fx",
            active_dev, self.sample_rate, self.frame_samples,
            int(self.frame_samples / self.sample_rate * 1000),
            self._gain,
        )
        logger.info("[MIC] watching levels — RMS will print every %.1fs", self._rms_log_interval_s)
        self._last_rms_log_t = time.time()

    async def stop(self) -> None:
        self._stopped.set()
        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception as e:  # pragma: no cover
                logger.warning("mic stream close error: %s", e)
            finally:
                self._stream = None

    def _sd_callback(self, indata, _frames, _time_info, status) -> None:
        if status:
            logger.debug("mic input status: %s", status)
        if self._loop is None:
            return
        # indata: (frames, channels) float32 in [-1, 1]
        chunk = indata[:, 0]
        # Apply gain (>1 amplifies quiet mics so VAD has a chance).
        if self._gain != 1.0:
            chunk = np.clip(chunk * self._gain, -1.0, 1.0)
        # RMS monitor — captures actual audio level the system is seeing.
        rms = float(np.sqrt(np.mean(chunk * chunk))) if chunk.size else 0.0
        self._rms_window.append(rms)
        pcm = (np.clip(chunk, -1.0, 1.0) * 32767.0).astype("<i2").tobytes()
        try:
            self._loop.call_soon_threadsafe(self._safe_put, pcm)
            self._loop.call_soon_threadsafe(self._maybe_log_rms)
        except RuntimeError:
            # Loop closed during teardown — fine.
            pass

    def _maybe_log_rms(self) -> None:
        now = time.time()
        if now - self._last_rms_log_t < self._rms_log_interval_s:
            return
        if not self._rms_window:
            return
        avg_rms = sum(self._rms_window) / len(self._rms_window)
        peak_rms = max(self._rms_window)
        self._rms_window.clear()
        self._last_rms_log_t = now

        bar_len = min(40, int(avg_rms * 200))
        bar = "█" * bar_len + "·" * (40 - bar_len)
        if avg_rms < _RMS_WARN_THRESHOLD:
            if self._dead_since is None:
                self._dead_since = now
            elif now - self._dead_since >= _RMS_WARN_AFTER_S:
                logger.warning(
                    "[MIC] !!! DEAD MIC !!! RMS=%.5f peak=%.5f for %.1fs — "
                    "Stream A's VAD WILL NOT FIRE on this. "
                    "Check mic permissions, mic device, mic mute switch, or "
                    "pass --mic-gain 5 to amplify.",
                    avg_rms, peak_rms, now - self._dead_since,
                )
                # Throttle the warning so it doesn't spam.
                self._dead_since = now - _RMS_WARN_AFTER_S / 2
            else:
                logger.info(
                    "[MIC] level=%.4f peak=%.4f |%s| (low — speak louder?)",
                    avg_rms, peak_rms, bar,
                )
        else:
            self._dead_since = None
            logger.info(
                "[MIC] level=%.4f peak=%.4f |%s|",
                avg_rms, peak_rms, bar,
            )

    def _safe_put(self, pcm: bytes) -> None:
        try:
            self._queue.put_nowait(pcm)
        except asyncio.QueueFull:
            logger.warning("mic queue full — dropping frame")

    async def frames(self) -> AsyncIterator[bytes]:
        while not self._stopped.is_set():
            try:
                pcm = await asyncio.wait_for(self._queue.get(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            yield pcm
