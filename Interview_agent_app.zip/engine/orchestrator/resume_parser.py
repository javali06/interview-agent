"""Resume → plain text for the slow LLM's system prompt.

Wraps the `attachments` library (https://pypi.org/project/attachments/),
which handles PDF, DOCX, TXT, MD, PPTX, CSV, JSON, and more via a single
`Attachments(path)` call. We extract the rendered body, trim it to fit
the LLM's context budget, and feed it into `CandidateProfile`.

Two small bits of hygiene the wrapper handles:
  1. `attachments` prints verbose pipeline progress to stdout at low
     file-descriptor level (bypasses `contextlib.redirect_stdout`). We
     dup2 fd 1 and 2 to /dev/null around the call so the noise doesn't
     pollute the orchestrator's stdout.
  2. `str(Attachments(path))` returns markdown like:
        # /path/to/file.pdf
        *Object type: <class 'str'>*
        ```
        <actual content>
        ```
     We pull the body out of the first ``` fence so the LLM sees only
     the resume content, not the source-label wrapper.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import sys
from pathlib import Path

from pydantic import BaseModel, Field, ValidationError

from engine.brain.prompts import load as load_prompt

logger = logging.getLogger(__name__)


# Hard cap so a long resume (5+ pages) doesn't eat the slow LLM's context
# budget. ~8000 chars ≈ 2000 tokens, plenty for a 1-2 page resume. If
# someone passes a longer doc we truncate and warn.
MAX_RESUME_CHARS = 8000

_CODE_FENCE_RE = re.compile(r"```(?:[a-zA-Z]*\n)?(.*?)```", re.DOTALL)


def _silence_load(path: str) -> str:
    """Run Attachments(path) with stdout/stderr suppressed.

    Originally used `os.dup2(devnull_fd, 1/2)` to silence the C-level prints
    from attachments' pipeline progress logging. That works on Linux/macOS
    but on Windows (some setups) breaks pdfplumber with
    `[WinError 1] Incorrect function` — apparently the NUL device handle
    confuses something inside the PDF pipeline. So we fall back to the
    Python-level `contextlib.redirect_stdout` / `redirect_stderr` which is
    more permissive: it catches Python `print()` calls but NOT C-level
    output. The orchestrator-window noise from attachments' INFO lines
    ([Attachments] Running primary processor ...) is harmless — they go
    only to the operator's terminal, not to the candidate UI or logs.
    """
    from attachments import Attachments  # local: keeps top-level import optional
    import contextlib
    import io

    if sys.platform == "win32":
        # Skip the FD-level silencer; Python-level redirect is enough.
        buf_out, buf_err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(buf_out), contextlib.redirect_stderr(buf_err):
            ctx = Attachments(path)
            return str(ctx)

    devnull_fd = os.open(os.devnull, os.O_WRONLY)
    saved_out, saved_err = os.dup(1), os.dup(2)
    try:
        os.dup2(devnull_fd, 1)
        os.dup2(devnull_fd, 2)
        ctx = Attachments(path)
        return str(ctx)
    finally:
        os.dup2(saved_out, 1)
        os.dup2(saved_err, 2)
        os.close(saved_out)
        os.close(saved_err)
        os.close(devnull_fd)


def _strip_markdown_wrapper(rendered: str) -> str:
    """Pull the body out of the first ``` ... ``` fence in the rendered
    markdown. Falls back to the whole string if no fence is present."""
    m = _CODE_FENCE_RE.search(rendered)
    if m:
        return m.group(1).strip()
    return rendered.strip()


def parse_resume(path: Path) -> str:
    """Return plain text extracted from a resume file.

    Raises ValueError on file-not-found / parse failure / empty result.
    Raises RuntimeError if the `attachments` package isn't installed.
    """
    if not path.exists():
        raise ValueError(f"Resume file not found: {path}")
    if not path.is_file():
        raise ValueError(f"Resume path is not a file: {path}")

    try:
        import attachments  # noqa: F401 — just probe availability
    except ImportError as e:
        raise RuntimeError(
            "The `attachments` package is required to parse resume files. "
            "Install with: pip install attachments"
        ) from e

    # Retry on transient failures — OneDrive often returns a placeholder for
    # cloud-only files on first read and forces a download on the second.
    # Attachments' silent fallback ("⚠️ Could not process ...") would otherwise
    # be accepted as the resume text and degrade the slow LLM's grounding.
    last_err: Exception | None = None
    rendered = ""
    for attempt in (1, 2, 3):
        try:
            rendered = _silence_load(str(path))
        except Exception as e:
            last_err = e
            logger.warning(
                "[resume] attempt %d/3: attachments raised %s",
                attempt, e,
            )
            continue
        # Attachments doesn't raise on PDF failure — it returns a fallback
        # text starting with "⚠️ Could not process ...". Detect that here.
        if "⚠️ Could not process" in rendered or "Could not process" in rendered[:80]:
            last_err = RuntimeError(rendered[:300])
            logger.warning(
                "[resume] attempt %d/3: attachments fallback string detected. "
                "Retrying — likely OneDrive sync placeholder. Details: %s",
                attempt, rendered[:200],
            )
            # Force a file read to nudge OneDrive into downloading the full file.
            try:
                with open(path, "rb") as f:
                    f.read(4096)
            except Exception:
                pass
            import time
            time.sleep(0.5 * attempt)
            continue
        # Success
        last_err = None
        break

    if last_err is not None:
        raise ValueError(
            f"Failed to parse resume {path} after 3 attempts: {last_err}"
        ) from last_err

    text = _strip_markdown_wrapper(rendered)
    if not text:
        raise ValueError(f"Resume {path} produced empty text after parsing")
    # Defensive: even if attachments returned the fallback string but our
    # detection above missed an unusual variant, refuse to ship a warning
    # message into the LLM prompt.
    if text.lstrip().startswith("⚠️") and "Could not process" in text[:80]:
        raise ValueError(
            f"Resume {path} returned attachments-fallback text instead of "
            f"PDF content: {text[:200]}"
        )

    if len(text) > MAX_RESUME_CHARS:
        logger.warning(
            "Resume %s is %d chars; truncating to %d for the system prompt.",
            path, len(text), MAX_RESUME_CHARS,
        )
        text = text[:MAX_RESUME_CHARS].rstrip() + "\n...(truncated)"

    logger.info(
        "Parsed resume %s (%d chars) — raw text ready for summarization.",
        path, len(text),
    )
    return text


# A resume's own contact email is almost always near the top (header/contact
# block), so the FIRST match wins rather than trying to disambiguate multiple
# addresses (e.g. a referee's email later in the document).
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")


def extract_email(text: str) -> str | None:
    """Best-effort contact email pulled from parsed resume text.

    Used as a fallback when the admin left the candidate-email field blank
    at schedule time (see app.jobs.jobs._resume_summary) — never overrides
    an email the admin actually typed in. Returns None if no email-shaped
    string is found; never raises.
    """
    match = _EMAIL_RE.search(text)
    return match.group(0) if match else None


# ── Resume → compact structured template ───────────────────────────────────
# The raw parsed resume (up to MAX_RESUME_CHARS) is large and noisy — bullet
# prose, dates, contact lines, awards. Dumping all of it into the slow LLM's
# system prompt every turn bloats the prompt for zero conversational benefit:
# we don't need the resume's wording, we need a map of WHAT to ask about.
# `summarize_resume` makes ONE LLM call at session startup to extract just
# that map — the candidate's name, their project headings, and the concrete
# tech stack — and renders it into a tiny fixed template. Details get drawn
# out live in the interview, so headings alone are enough.


class _ResumeSummary(BaseModel):
    """Validated shape of the LLM's resume extraction."""
    name: str = ""
    # Project TITLES / headings only — no descriptions. We probe details live.
    projects: list[str] = Field(default_factory=list)
    # Flat, deduplicated list of concrete technologies (languages, frameworks,
    # libraries, cloud services, databases, tools).
    tech_stack: list[str] = Field(default_factory=list)




_JSON_OBJECT_RE = re.compile(r"\{.*\}", re.DOTALL)
_THINK_BLOCK_RE = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)


def _extract_json_object(raw: str) -> str:
    """Pull a JSON object out of an LLM response. Strips any <think> reasoning
    block (gpt-oss and other reasoning models emit one) and markdown fences,
    then returns the outermost { ... } span."""
    cleaned = _THINK_BLOCK_RE.sub("", raw)
    m = _JSON_OBJECT_RE.search(cleaned)
    return m.group(0) if m else cleaned.strip()


def _render_template(summary: _ResumeSummary, fallback_name: str) -> str:
    """Render the validated summary into the compact text block that goes
    into the slow LLM's system prompt as `resume_summary`."""
    name = summary.name.strip() or fallback_name.strip() or "(unknown)"
    lines = [f"name: {name}"]

    projects = [p.strip() for p in summary.projects if p.strip()]
    if projects:
        lines.append("projects (headings only — ask for details live):")
        lines.extend(f"  - {p}" for p in projects)
    else:
        lines.append("projects: (none listed)")

    stack = [t.strip() for t in summary.tech_stack if t.strip()]
    if stack:
        lines.append("tech_stack: " + ", ".join(stack))
    else:
        lines.append("tech_stack: (none listed)")

    return "\n".join(lines)


async def summarize_resume(
    raw_text: str,
    *,
    candidate_name: str = "",
    api_key: str,
    base_url: str,
    model: str,
    attempts: int = 3,
    fallback_to_raw: bool = True,
) -> str:
    """Extract a compact structured template (name + project headings + tech
    stack) from raw resume text via an LLM call.

    Runs off the interview hot path (precomputed at schedule time by the
    resume_summary worker job), so it's tuned for RELIABILITY, not speed: it
    RETRIES up to `attempts` times until the model returns JSON that validates
    against `_ResumeSummary`, feeding the format error back each retry (like the
    cadence loader). Only after all attempts fail does it fall back to the raw
    text so the interview still has resume context — summarization is an
    optimization, never a hard dependency. Each attempt is bounded by
    RESUME_SUMMARY_TIMEOUT_S so one hung call can't stall the job forever.
    """
    if not raw_text.strip():
        return ""
    if not api_key:
        logger.warning("[resume] no LLM key for summarization — using raw text")
        return raw_text if fallback_to_raw else ""

    from openai import AsyncOpenAI  # local import keeps top-level deps light

    client = AsyncOpenAI(api_key=api_key, base_url=base_url)
    system = load_prompt("resume_summary")
    per_attempt_timeout = float(os.environ.get("RESUME_SUMMARY_TIMEOUT_S", "45"))
    last_err: Exception | None = None

    for attempt in range(1, max(1, attempts) + 1):
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": raw_text},
        ]
        if attempt > 1 and last_err is not None:
            # Feed the failure back so the model corrects its format; nudge
            # temperature up so a near-deterministic model doesn't just repeat the
            # same malformed output.
            messages.append({
                "role": "user",
                "content": (
                    "Your previous reply was NOT valid JSON for the schema "
                    "{name: string, projects: string[], tech_stack: string[]}. "
                    "Return ONLY that JSON object — no prose, no code fences, no "
                    f"<think> blocks. Error: {last_err}"
                ),
            })
        try:
            resp = await asyncio.wait_for(
                client.chat.completions.create(
                    model=model,
                    messages=messages,
                    temperature=0.1 + 0.15 * (attempt - 1),
                ),
                timeout=per_attempt_timeout,
            )
            content = resp.choices[0].message.content or ""
            summary = _ResumeSummary.model_validate_json(_extract_json_object(content))
        except (ValidationError, json.JSONDecodeError) as e:
            last_err = e
            logger.warning(
                "[resume] summary JSON invalid (attempt %d/%d): %s", attempt, attempts, e,
            )
            continue
        except Exception as e:  # API / network / timeout — retry, then fall back
            last_err = e
            logger.warning(
                "[resume] summarization call failed (attempt %d/%d): %s",
                attempt, attempts, e,
            )
            continue

        template = _render_template(summary, candidate_name)
        logger.info(
            "[resume] summarized to compact template (%d chars, was %d raw) — "
            "%d projects, %d tech-stack items (attempt %d)",
            len(template), len(raw_text), len(summary.projects),
            len(summary.tech_stack), attempt,
        )
        return template

    logger.warning(
        "[resume] all %d summarization attempts failed (%s) — %s",
        attempts, last_err,
        "falling back to raw text" if fallback_to_raw else "returning empty (caller keeps parsed)",
    )
    return raw_text if fallback_to_raw else ""
