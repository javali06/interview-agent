"""Server-side recording of the interview's audio (LiveKit room-composite egress).

LiveKit mixes every audio track in the room (the AI's voice + the candidate's
mic) and writes one OGG/Opus file straight to Azure Blob, next to the browser's
own recording: ``<container>/<token>/recording/livekit-audio-<start>.ogg``. Unlike the
browser recording it doesn't depend on the candidate's tab staying open or
their upload getting through.

Audio only, on purpose: camera and screen are not published to the room (no
live video leaves the candidate's browser), so they stay in the browser
recording. Publishing them is a separate decision (bandwidth + cost).

Env: ``LIVEKIT_EGRESS_AZURE_ACCOUNT_NAME`` / ``_ACCOUNT_KEY`` / ``_CONTAINER``
(all three, or egress is off). ``LIVEKIT_EGRESS=0`` switches it off with the
credentials still set.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Optional

from engine.orchestrator.livekit.config import LiveKitSettings

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class EgressSettings:
    account_name: str
    account_key: str
    container: str


def egress_settings() -> Optional[EgressSettings]:
    if (os.getenv("LIVEKIT_EGRESS") or "1").strip().lower() in ("0", "false", "no", "off"):
        return None
    s = EgressSettings(
        account_name=(os.getenv("LIVEKIT_EGRESS_AZURE_ACCOUNT_NAME") or "").strip(),
        account_key=(os.getenv("LIVEKIT_EGRESS_AZURE_ACCOUNT_KEY") or "").strip(),
        container=(os.getenv("LIVEKIT_EGRESS_AZURE_CONTAINER") or "").strip(),
    )
    return s if (s.account_name and s.account_key and s.container) else None


def egress_blob_name(token: str, started_at: float) -> str:
    """Where the file lands inside the container — the same folder as the
    browser recording, so one listing of ``<token>/recording/`` finds both.
    One file per runner, named by when it started: an interview that is handed
    off (drain, crash) is recorded again by the replica that resumes it, and a
    fixed name would overwrite everything said before the hand-off."""
    return f"{token}/recording/livekit-audio-{int(started_at)}.ogg"


def egress_part_names(names: list[str]) -> list[str]:
    """The server-recording files among a recording folder's blobs, in the
    order they were recorded (the pre-parts single file first)."""
    import re
    parts = []
    for n in names:
        m = re.fullmatch(r".*/recording/livekit-audio(?:-(\d+))?\.ogg", n)
        if m:
            parts.append((int(m.group(1) or 0), n))
    return [n for _, n in sorted(parts)]


# ── Part manifests ────────────────────────────────────────────────────────────
# LiveKit uploads the file only once the recording has stopped, a few seconds
# after we ask it to — and if it fails, there is no file at all. So the file's
# presence can't say "still being written" or "failed". Each part gets a small
# manifest beside it (``<part>.ogg.json``) that says which: the session writes
# "recording" at start and "processing" at stop; the worker's
# recording_finalize job writes the final "ready" / "failed". One manifest per
# part, so the jobs for a handed-off interview's parts never write the same file.
MANIFEST_SUFFIX = ".json"
TERMINAL = ("ready", "failed")


def manifest_name(blob_name: str) -> str:
    return blob_name + MANIFEST_SUFFIX


def write_manifest(blob_name: str, status: str, **fields) -> bool:
    """Best-effort and blocking (blob I/O): call it off the event loop."""
    import io
    import json
    import time
    from app import blob_store
    doc = {"blob": blob_name, "status": status, "updated_at": int(time.time()), **fields}
    return blob_store.upload_fileobj(io.BytesIO(json.dumps(doc).encode()),
                                     manifest_name(blob_name))


def read_manifest(blob_name: str) -> dict | None:
    import json
    from app import blob_store
    raw = blob_store.download_bytes(manifest_name(blob_name))
    if not raw:
        return None
    try:
        return json.loads(raw)
    except ValueError:
        return None


def part_statuses(names: list[str]) -> list[dict]:
    """Every server-recording part of an interview, in recording order, with
    what the admin page should say about it: recording / processing / ready /
    failed / unavailable. ``part`` is the index the download
    route takes (/recording/livekit?part=i), None while there is no file.

    The file wins over a stale manifest: a runner that crashed never wrote
    "processing", yet LiveKit still uploads the file once the room empties."""
    files = egress_part_names(names)
    manifests = [n[:-len(MANIFEST_SUFFIX)] for n in names
                 if n.endswith(".ogg" + MANIFEST_SUFFIX)]
    out = []
    for blob in egress_part_names(sorted(set(files) | set(manifests))):
        m = read_manifest(blob) if blob in manifests else None
        has_file = blob in files
        status = (m or {}).get("status") or "ready"
        if has_file and status != "failed":
            status = "ready"
        elif not has_file and status == "ready":
            # LiveKit says it saved the file, yet this server can't see it —
            # storage the app doesn't read (a local stack whose blob store is
            # the disk fallback), or a file removed since. Not a failed recording.
            status = "unavailable"
        out.append({
            "part": files.index(blob) if has_file else None,
            "status": status,
            "duration_s": (m or {}).get("duration_s"),
            "error": (m or {}).get("error") or "",
        })
    return out


async def egress_info(lk: LiveKitSettings, egress_id: str):
    """LiveKit's current record of one egress (None if it has none)."""
    from livekit import api
    client = api.LiveKitAPI(lk.url, lk.api_key, lk.api_secret)
    try:
        res = await client.egress.list_egress(api.ListEgressRequest(egress_id=egress_id))
        return res.items[0] if res.items else None
    finally:
        await client.aclose()


async def start_audio_egress(lk: LiveKitSettings, eg: EgressSettings, room: str,
                             blob_name: str) -> str:
    """Start recording ``room`` into ``blob_name``; returns the egress id."""
    from livekit import api

    req = api.RoomCompositeEgressRequest(
        room_name=room,
        audio_only=True,
        file_outputs=[api.EncodedFileOutput(
            file_type=api.EncodedFileType.OGG,
            filepath=blob_name,
            azure=api.AzureBlobUpload(
                account_name=eg.account_name,
                account_key=eg.account_key,
                container_name=eg.container,
            ),
        )],
    )
    client = api.LiveKitAPI(lk.url, lk.api_key, lk.api_secret)
    try:
        info = await client.egress.start_room_composite_egress(req)
        return info.egress_id
    finally:
        await client.aclose()


async def stop_egress(lk: LiveKitSettings, egress_id: str) -> None:
    """Stop recording. LiveKit then finalises the file and uploads it, which
    takes a few seconds after this returns."""
    from livekit import api

    client = api.LiveKitAPI(lk.url, lk.api_key, lk.api_secret)
    try:
        await client.egress.stop_egress(api.StopEgressRequest(egress_id=egress_id))
    finally:
        await client.aclose()
