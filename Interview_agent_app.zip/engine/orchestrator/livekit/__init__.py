"""LiveKit media transport (Phase 1 of the prod-rearchitecture roadmap).

Replaces the raw-PCM-over-WebSocket AUDIO path with a WebRTC SFU: Opus,
adaptive bitrate, congestion control, FEC, global edge — fixing the global
latency + transport-reliability problems by construction. Only AUDIO moves
here; the existing WebSocket (WebBroadcaster) still carries control,
captions, phases and the coding panel. Gated by MEDIA_TRANSPORT=livekit
(default 'websocket' → today's behavior unchanged).
"""
