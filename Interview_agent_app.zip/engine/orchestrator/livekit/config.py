"""Media-transport selection + LiveKit connection settings (env-driven).

`MEDIA_TRANSPORT` chooses the audio transport for a session:
  - "websocket" (default) → the existing raw-PCM WebSocket path (unchanged).
  - "livekit"             → the WebRTC path (this package).

Keeping this a single, env-tunable switch (no rebuild) lets us roll LiveKit out
per-shard / canary and fall back instantly by flipping the env.
"""
from __future__ import annotations

import os
from dataclasses import dataclass


def media_transport() -> str:
    return (os.getenv("MEDIA_TRANSPORT") or "websocket").strip().lower()


def livekit_enabled() -> bool:
    return media_transport() == "livekit"


@dataclass(frozen=True)
class LiveKitSettings:
    url: str
    api_key: str
    api_secret: str

    def is_complete(self) -> bool:
        return bool(self.url and self.api_key and self.api_secret)


def livekit_settings() -> LiveKitSettings:
    """Read LIVEKIT_URL / LIVEKIT_API_KEY / LIVEKIT_API_SECRET (ACA secretrefs)."""
    return LiveKitSettings(
        url=(os.getenv("LIVEKIT_URL") or "").strip(),
        api_key=(os.getenv("LIVEKIT_API_KEY") or "").strip(),
        api_secret=(os.getenv("LIVEKIT_API_SECRET") or "").strip(),
    )


def connect_timeout_s() -> float:
    """How long the agent waits to join the room before falling back to the
    WebSocket path (LIVEKIT_CONNECT_TIMEOUT_S, default 10 s)."""
    try:
        return max(1.0, float(os.getenv("LIVEKIT_CONNECT_TIMEOUT_S") or 10))
    except ValueError:
        return 10.0


def candidate_join_timeout_s() -> float:
    """How long the agent waits for the candidate's page to join the room (mic
    published + AI voice subscribed) before falling back to the WebSocket path
    (LIVEKIT_CANDIDATE_JOIN_TIMEOUT_S, default 20 s). Covers a candidate whose
    network can't reach LiveKit at all."""
    try:
        return max(1.0, float(os.getenv("LIVEKIT_CANDIDATE_JOIN_TIMEOUT_S") or 20))
    except ValueError:
        return 20.0
