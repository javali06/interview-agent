"""LiveKit access-token minting (livekit-api).

Room name = the interview token, so a candidate's join token grants access only
to their own room. The candidate publishes their mic + subscribes to the AI
voice; the agent (the brain) does the mirror. Tokens are short-lived and scoped
to the single room — never a wildcard grant.
"""
from __future__ import annotations

import logging
from datetime import timedelta
from typing import Optional

from .config import LiveKitSettings, livekit_enabled, livekit_settings

logger = logging.getLogger(__name__)

# Interviews run well under an hour, but reconnects must still hold a valid
# token; 4h covers the longest session + a stalled reconnect without re-minting.
_DEFAULT_TTL_S = 4 * 3600


def _mint(settings: LiveKitSettings, *, identity: str, name: str, room: str,
          ttl_s: int, can_publish: bool = True, can_subscribe: bool = True) -> str:
    from livekit import api  # lazy — keep import off module load

    grants = api.VideoGrants(
        room_join=True,
        room=room,
        can_publish=can_publish,
        can_subscribe=can_subscribe,
        can_publish_data=True,
    )
    token = (
        api.AccessToken(settings.api_key, settings.api_secret)
        .with_identity(identity)
        .with_name(name)
        .with_grants(grants)
        .with_ttl(timedelta(seconds=ttl_s))
    )
    return token.to_jwt()


def candidate_token(settings: LiveKitSettings, *, room: str, identity: str,
                    name: str, ttl_s: int = _DEFAULT_TTL_S) -> str:
    """Join token for the candidate's browser (publish mic + subscribe AI)."""
    return _mint(settings, identity=identity, name=name, room=room, ttl_s=ttl_s)


def agent_token(settings: LiveKitSettings, *, room: str, identity: str = "agent",
                ttl_s: int = _DEFAULT_TTL_S) -> str:
    """Join token for the interview brain (publish AI voice + subscribe mic)."""
    return _mint(settings, identity=identity, name=identity, room=room, ttl_s=ttl_s)


# The statuses in which a candidate can actually be in the interview — the same
# definition app/db.py uses for "active" (approved link, or already started).
_JOINABLE = ("ready", "in_progress")


def _live_interview(room: Optional[str], row: Optional[dict]) -> bool:
    return bool(room and row and row.get("status") in _JOINABLE and not row.get("is_template"))


def livekit_offer(room: Optional[str], row: Optional[dict]) -> Optional[dict]:
    """The `livekit` block of /session-info: `{"enabled": true}`, or None → the
    page stays on the WebSocket path.

    ONE definition, called by both /session-info handlers (app/main.py, which
    the gateway serves and the candidate actually reaches, and deploy/
    azure_app.py's copy), so they cannot drift.

    Deliberately carries NO token. /session-info is unauthenticated and answers
    every tab, so a token here would let a second tab join the room as the
    candidate and knock the real one out. The token comes from the shard that
    runs the interview, after it has checked which tab owns it
    (``candidate_room_access``). Offered only for a real, live interview."""
    if not livekit_enabled() or not _live_interview(room, row):
        return None
    if not livekit_settings().is_complete():
        return None
    return {"enabled": True}


def candidate_identity(client: str) -> str:
    """One identity per browser tab. A refresh keeps its tab id, so it rejoins
    as the same participant and LiveKit drops the stale one; a different tab
    is a different participant (and only gets a token if the shard lets it)."""
    safe = "".join(ch for ch in (client or "") if ch.isalnum() or ch == "-")[:40]
    return f"candidate-{safe or 'tab'}"


def candidate_room_access(room: str, client: str, row: Optional[dict]) -> Optional[dict]:
    """`{url, token}` for the tab that owns the interview — minted only by the
    session shard, after the one-tab check. None if LiveKit isn't usable.
    Never raises.

    Doesn't re-decide whether the interview may run: the shard already applied
    the one rule for that (interview_checkpoint.interview_over), under which a
    crashed or handed-off interview reads `completed` yet is resumable. Only an
    unknown, template or cancelled interview is refused here."""
    if not room or not row or row.get("is_template") or row.get("status") == "cancelled":
        return None
    settings = livekit_settings()
    if not settings.is_complete():
        return None
    try:
        return {
            "url": settings.url,
            "token": candidate_token(settings, room=room, identity=candidate_identity(client),
                                     name=(row.get("role") or "").strip() or "candidate"),
        }
    except Exception as e:
        logger.warning("[livekit] candidate token mint failed %s: %s", room[:8], e)
        return None
