"""LiveKit room transport + AudioSource/AudioSink adapters.

One ``rtc.Room`` per interview (room name = the interview token). The interview
brain connects as the "agent" participant; the candidate joins the same room
from the browser. This module bridges the room to the brain's transport-agnostic
contracts (``engine.brain.contracts.audio``):

  * ``LiveKitAudioSource`` — subscribes to the candidate's mic track and yields
    20 ms / 16 kHz / PCM16 mono frames. LiveKit does the Opus decode + resample
    to our exact contract via ``AudioStream(sample_rate=16000, frame_size_ms=20)``.
  * ``LiveKitAudioSink`` — publishes the AI's PCM as a LiveKit audio track via
    ``rtc.AudioSource.capture_frame``; LiveKit Opus-encodes to the edge.

The brain is unchanged — it sees only the two protocols. Only audio rides
LiveKit; control/video/coding stay on the existing WebSocket.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import uuid
from typing import AsyncIterator

from engine.brain.contracts.audio import FRAME_MS, FRAME_SAMPLES, SAMPLE_RATE_HZ

logger = logging.getLogger(__name__)

# Publish the AI voice at the brain's native rate; LiveKit resamples to the
# 48 kHz Opus wire internally. Keeping it 16 kHz avoids an extra resample here.
_AI_PUBLISH_RATE_HZ = SAMPLE_RATE_HZ

# ── control channel (Phase 2) ────────────────────────────────────────────────
# The page's control messages (captions, phases, coding/scenario events, the
# playback ack, start/end) ride the room's reliable data channel instead of a
# WebSocket to this server — same JSON shapes. A reliable packet should stay
# well under ~15 KB, so bigger messages (a coding question with its tests) go as
# ordered chunks: {"type":"__chunk","id","i","n","d"}. One publisher's
# reliable packets arrive in order, so reassembly needs no reordering.
# ui/web/src/lib/livekitMedia.ts speaks the same format.
CONTROL_TOPIC = "ctl"
_CHUNK_CHARS = 2000   # ≤ ~12 KB even if every char is \uXXXX-escaped


def control_packets(text: str) -> list[str]:
    if len(text) <= _CHUNK_CHARS:
        return [text]
    mid = uuid.uuid4().hex[:12]
    parts = [text[i:i + _CHUNK_CHARS] for i in range(0, len(text), _CHUNK_CHARS)]
    return [json.dumps({"type": "__chunk", "id": mid, "i": i, "n": len(parts), "d": p})
            for i, p in enumerate(parts)]


class ControlReassembler:
    """Turns received packets back into whole messages (chunks or not)."""

    def __init__(self) -> None:
        self._parts: dict[str, list[str | None]] = {}

    def feed(self, text: str) -> str | None:
        # Python and JS space JSON differently; the marker sits in the first bytes.
        if '"__chunk"' not in text[:32]:
            return text
        try:
            c = json.loads(text)
            buf = self._parts.setdefault(c["id"], [None] * int(c["n"]))
            buf[int(c["i"])] = c["d"]
        except (ValueError, KeyError, IndexError, TypeError):
            return None
        if any(p is None for p in buf):
            return None
        del self._parts[c["id"]]
        return "".join(buf)  # type: ignore[arg-type]


class LiveKitTransport:
    """Owns the agent's ``rtc.Room`` connection for one interview and exposes a
    matching ``source`` / ``sink``. Construct → ``connect()`` → hand ``.source``
    and ``.sink`` to ``InterviewSession`` → ``close()`` on teardown."""

    def __init__(self, url: str, token: str, room_name: str,
                 out_sample_rate_hz: int = _AI_PUBLISH_RATE_HZ) -> None:
        # Import lazily so tiers without the SDK (or import-time) never break.
        from livekit import rtc  # noqa: WPS433 (deliberate lazy import)

        self._rtc = rtc
        self._url = url
        self._token = token
        self._room_name = room_name
        self._out_rate = out_sample_rate_hz

        self._room = rtc.Room()
        # Outgoing AI audio: a server-owned AudioSource feeding a published track.
        self._out_source = rtc.AudioSource(out_sample_rate_hz, 1)
        self._out_track = rtc.LocalAudioTrack.create_audio_track("ai-voice", self._out_source)

        # The candidate's mic arrives on whichever track they published most
        # recently: a refresh rejoins with the same identity, LiveKit drops the
        # old participant, and the source must follow the NEW track.
        self._cand_track = None
        self._cand_ready = asyncio.Event()     # a candidate mic track is subscribed
        self._ai_subscribed = asyncio.Event()  # the candidate subscribed to ai-voice
        self._connected = False
        self._room.on("track_subscribed", self._on_track_subscribed)
        self._room.on("track_unsubscribed", self._on_track_unsubscribed)
        # Fires on the FIRST subscription only, which is all start-up needs.
        self._room.on("local_track_subscribed", lambda track: self._ai_subscribed.set())

        # Control channel: packets from the candidate, reassembled, handed to
        # one consumer in arrival order (a task per packet could reorder them).
        self._control_cb = None
        self._control_in: asyncio.Queue[str] = asyncio.Queue()
        self._control_task: asyncio.Task | None = None
        self._reassembler = ControlReassembler()
        self._room.on("data_received", self._on_data)

        # Constructed once so InterviewSession holds stable references.
        self.source = LiveKitAudioSource(self)
        self.sink = LiveKitAudioSink(self)

    # ── room lifecycle ──────────────────────────────────────────────────────
    def _on_track_subscribed(self, track, publication, participant) -> None:
        # Robust against proto-enum naming: match by concrete type.
        if not isinstance(track, self._rtc.RemoteAudioTrack):
            return
        self._cand_track = track
        self._cand_ready.set()
        self.source._follow(track)
        logger.info("[livekit] candidate audio subscribed room=%s participant=%s",
                    self._room_name, getattr(participant, "identity", "?"))

    def _on_track_unsubscribed(self, track, publication, participant) -> None:
        if track is self._cand_track:
            self._cand_track = None
            self._cand_ready.clear()

    # ── control channel ──
    def set_control_handler(self, cb) -> None:
        """``async cb(text)`` for each whole control message from the candidate."""
        self._control_cb = cb
        if self._control_task is None:
            self._control_task = asyncio.get_running_loop().create_task(self._control_loop())

    def _on_data(self, packet) -> None:
        if getattr(packet, "topic", "") != CONTROL_TOPIC:
            return
        who = getattr(getattr(packet, "participant", None), "identity", "") or ""
        if not who.startswith("candidate-"):
            return  # only the candidate's page talks on this channel
        try:
            text = bytes(packet.data).decode("utf-8")
        except Exception:
            return
        whole = self._reassembler.feed(text)
        if whole is not None:
            self._control_in.put_nowait(whole)

    async def _control_loop(self) -> None:
        while True:
            text = await self._control_in.get()
            if self._control_cb is None:
                continue
            try:
                await self._control_cb(text)
            except Exception as e:
                logger.warning("[livekit] control message handler failed: %s", e)

    async def send_control(self, text: str) -> None:
        """Send one control message to the page (chunked if large)."""
        if not self._connected:
            return
        for pkt in control_packets(text):
            await self._room.local_participant.publish_data(
                pkt.encode("utf-8"), reliable=True, topic=CONTROL_TOPIC)

    def candidate_present(self, identity: str | None = None) -> bool:
        """Is the candidate (a specific tab, if ``identity``) in the room now?"""
        for ident in self._room.remote_participants:
            if identity is not None and ident == identity:
                return True
            if identity is None and ident.startswith("candidate-"):
                return True
        return False

    async def wait_candidate_ready(self, timeout_s: float) -> bool:
        """True once the candidate is really in the room: their mic is
        subscribed AND they subscribed to the AI's voice. Audio published
        before that is simply lost (an SFU doesn't buffer for late joiners), so
        the interview must not greet until both are true. False on timeout —
        e.g. the candidate's network can't reach LiveKit."""
        try:
            await asyncio.wait_for(
                asyncio.gather(self._cand_ready.wait(), self._ai_subscribed.wait()),
                timeout=timeout_s,
            )
            return True
        except asyncio.TimeoutError:
            return False

    async def connect(self) -> None:
        opts = self._rtc.RoomOptions(auto_subscribe=True)
        await self._room.connect(self._url, self._token, opts)
        # Publish the AI voice track (default options — audio flows without a
        # source-classification enum, which we intentionally don't depend on).
        await self._room.local_participant.publish_track(
            self._out_track, self._rtc.TrackPublishOptions(),
        )
        self._connected = True
        logger.info("[livekit] agent connected + published room=%s", self._room_name)

    async def close(self) -> None:
        self._connected = False
        if self._control_task is not None:
            self._control_task.cancel()
        await self.source.stop()
        try:
            await self._out_source.aclose()
        except Exception:  # pragma: no cover
            pass
        try:
            await self._room.disconnect()
        except Exception:  # pragma: no cover
            pass


class LiveKitAudioSource:
    """AudioSource over the candidate's LiveKit mic track (16 kHz / 20 ms PCM16).

    One pump task per candidate track feeds a single queue; a newer track
    (the candidate refreshed) cancels the old pump. Cancelling is the reliable
    way to stop reading a track — closing its stream does not promise to wake a
    reader blocked on it.
    """

    sample_rate: int = SAMPLE_RATE_HZ
    frame_samples: int = FRAME_SAMPLES

    # ~5 s of 20 ms frames. Only fills if the brain stalls; then the OLDEST
    # audio goes, so it always hears the candidate's latest words.
    _QUEUE_FRAMES = 250
    # A published, unmuted mic delivers a frame every 20 ms, silence included.
    # Nothing for this long means our reader is stuck on a dead stream (seen
    # after the agent's room connection was rebuilt on a flaky network: the
    # speech detector then waits forever for the end of a sentence).
    _STALL_S = float(os.getenv("LIVEKIT_MIC_STALL_S", "3"))

    def __init__(self, transport: "LiveKitTransport") -> None:
        self._t = transport
        self._q: asyncio.Queue[bytes | None] = asyncio.Queue(maxsize=self._QUEUE_FRAMES)
        self._pump: asyncio.Task | None = None
        self._watchdog: asyncio.Task | None = None
        # Frames are dropped until start(): audio from while the candidate was
        # joining (before the greeting) is not an answer to anything.
        self._started = False
        self._stopped = False
        # Same health/stats surface as BrowserMicAudioSource, so the session's
        # mic-silence detector and mic_delivery_stats work on LiveKit too.
        self._frames_in = 0
        self._first_frame_wall: float | None = None
        self._last_frame_wall: float | None = None
        self._last_voiced_wall: float | None = None
        self._voiced = 0
        self._silent = 0
        self._rms_sum = 0.0
        self._rms_max = 0.0
        self._pumps = 0
        self._heals = 0

    async def start(self) -> None:
        self._started = True
        self._last_frame_wall = time.monotonic()  # the stall clock starts now
        self._watchdog = asyncio.get_running_loop().create_task(self._watch())
        logger.info("[livekit] audio source started")

    async def stop(self) -> None:
        if self._stopped:
            return
        self._stopped = True
        for t in (self._pump, self._watchdog):
            if t is not None and not t.done():
                t.cancel()
        self._put(None)

    def _follow(self, track) -> None:
        if self._stopped:
            return
        if self._pump is not None and not self._pump.done():
            self._pump.cancel()
        self._pumps += 1
        self._pump = asyncio.get_running_loop().create_task(self._run_pump(track))

    def _candidate_track(self):
        """The candidate's current (track, muted) — from our subscription, or
        found in the room if a subscription event was missed."""
        rtc = self._t._rtc
        room = getattr(self._t, "_room", None)
        for ident, p in (room.remote_participants.items() if room is not None else ()):
            if not ident.startswith("candidate-"):
                continue
            for pub in p.track_publications.values():
                track = getattr(pub, "track", None)
                if isinstance(track, rtc.RemoteAudioTrack):
                    return track, bool(getattr(pub, "muted", False))
        return self._t._cand_track, False

    async def _watch(self) -> None:
        while not self._stopped:
            await asyncio.sleep(1.0)
            idle = time.monotonic() - (self._last_frame_wall or time.monotonic())
            if idle < self._STALL_S:
                continue
            track, muted = self._candidate_track()
            if track is None or muted:
                continue  # nobody to hear, or muted on purpose — nothing is wrong
            self._heals += 1
            try:
                from engine.brain.observability import prom as _prom
                _prom.LIVEKIT_MIC_STALL_HEALS.inc()
            except Exception:
                pass
            logger.warning("[livekit] no candidate audio for %.1fs — re-reading the "
                           "current mic track (heal #%d)", idle, self._heals)
            self._t._cand_track = track
            self._follow(track)
            self._last_frame_wall = time.monotonic()  # give the new reader a full window

    def mic_health(self) -> dict:
        total = self._voiced + self._silent
        return {
            "packets_in": self._frames_in,
            "first_packet_wall_s": self._first_frame_wall,
            "voiced_frames": self._voiced,
            "silent_frames": self._silent,
            "voiced_ratio": (self._voiced / total) if total else 0.0,
            "seconds_since_voiced": (time.monotonic() - self._last_voiced_wall)
            if self._last_voiced_wall is not None else None,
        }

    def stats(self) -> dict:
        wall = 0.0
        if self._first_frame_wall is not None and self._last_frame_wall is not None:
            wall = self._last_frame_wall - self._first_frame_wall
        total = self._voiced + self._silent
        return {
            "transport": "livekit",
            "packets_in": self._frames_in,
            "frames_in": self._frames_in,
            "wall_elapsed_s": round(wall, 1),
            "arrival_rate_per_s": round(self._frames_in / wall, 1) if wall > 0 else 0.0,
            "mean_rms": round(self._rms_sum / total, 1) if total else 0.0,
            "max_rms": round(self._rms_max, 1),
            "voiced_frames": self._voiced,
            "silent_frames": self._silent,
            "voiced_ratio": round(self._voiced / total, 3) if total else 0.0,
            "tracks_followed": self._pumps,
            "stall_heals": self._heals,
        }

    def _count(self, data: bytes) -> None:
        from engine.orchestrator.web.audio_source import (
            _MIC_SILENCE_RMS_FLOOR, BrowserMicAudioSource)
        now = time.monotonic()
        self._frames_in += 1
        if self._first_frame_wall is None:
            self._first_frame_wall = now
        self._last_frame_wall = now
        rms = BrowserMicAudioSource._frame_rms(data)
        if rms is None:
            return
        self._rms_sum += rms
        self._rms_max = max(self._rms_max, rms)
        if rms >= _MIC_SILENCE_RMS_FLOOR:
            self._voiced += 1
            self._last_voiced_wall = now
        else:
            self._silent += 1

    async def _run_pump(self, track) -> None:
        # LiveKit decodes Opus + resamples to our exact contract.
        stream = self._t._rtc.AudioStream(
            track, sample_rate=SAMPLE_RATE_HZ, num_channels=1, frame_size_ms=FRAME_MS,
        )
        try:
            async for event in stream:
                if not self._started:
                    continue
                frame = getattr(event, "frame", event)
                data = bytes(frame.data)
                if data:
                    self._count(data)
                    self._put(data)
        finally:
            try:
                await stream.aclose()
            except Exception:  # pragma: no cover
                pass

    def _put(self, item: bytes | None) -> None:
        if self._q.full():
            try:
                self._q.get_nowait()
            except asyncio.QueueEmpty:  # pragma: no cover
                pass
        self._q.put_nowait(item)

    async def frames(self) -> AsyncIterator[bytes]:
        while True:
            item = await self._q.get()
            if item is None:
                return
            yield item


class LiveKitAudioSink:
    """AudioSink publishing the AI's PCM to the room via ``AudioSource.capture_frame``.

    Same contract as ``BrowserSpeakerAudioSink`` (engine/orchestrator/web/
    audio_sink.py), because the brain keys real behaviour off it:

      * ``play_sync`` is NON-blocking. ``InterviewSession._on_pcm`` calls it per
        TTS chunk; without it the session falls back to one
        ``create_task(play())`` per chunk, which piles up tasks and makes drain
        readings meaningless (the old "Bug #4"). ``capture_frame`` is async, so
        chunks go onto a local queue that ONE feeder task pushes in order.
      * the playout ack (``expect_playout`` / ``mark_played`` /
        ``playout_done_event``) is unchanged: the browser still reports
        ``audio_playback_finished`` over the WebSocket. The silence timer and the
        wrap-up hold wait on it — dropping it is how the farewell got cut off
        before (v10/v20).
      * ``bytes_buffered`` is non-zero while EITHER the browser hasn't acked OR
        audio is still queued here / in LiveKit. Both must be true for "heard":
        the server can't be done before it has sent everything, and a browser
        ack is the only proof it was played.
    """

    def __init__(self, transport: "LiveKitTransport") -> None:
        self._t = transport
        self.sample_rate_hz: int = transport._out_rate
        self._frame_bytes = FRAME_SAMPLES * 2 * self.sample_rate_hz // SAMPLE_RATE_HZ

        self._q: asyncio.Queue[tuple[int, bytes]] = asyncio.Queue()
        self._queued_bytes = 0
        self._carry = b""          # odd trailing byte — a frame must be whole samples
        self._gen = 0              # bumped by flush(); frames from an older gen are dropped
        self._feeder: asyncio.Task | None = None
        self._bytes_sent = 0

        # Passive playout clock — see BrowserSpeakerAudioSink._advance_playout.
        self._playout_end_monotonic: float = 0.0
        self._awaiting_sub: str | None = None
        self._playout_done_event: asyncio.Event = asyncio.Event()
        self._playout_done_event.set()

    # ── playout ack (driven by the WebSocket control channel) ───────────────
    def expect_playout(self, sub_id: str) -> None:
        self._awaiting_sub = sub_id or "?"
        self._playout_done_event.clear()

    def mark_played(self, sub_id: str = "") -> None:
        if self._awaiting_sub is None:
            return
        if not sub_id or sub_id == self._awaiting_sub:
            self._awaiting_sub = None
            self._playout_done_event.set()

    @property
    def playout_done_event(self) -> asyncio.Event:
        return self._playout_done_event

    def remaining_playout_s(self) -> float:
        modelled = self._playout_end_monotonic - time.monotonic()
        return max(0.0, modelled, self._pending_s())

    def _pending_s(self) -> float:
        local = self._queued_bytes / float(self.sample_rate_hz * 2)
        try:
            remote = float(self._t._out_source.queued_duration)
        except Exception:  # pragma: no cover
            remote = 0.0
        return local + remote

    # ── AudioSink protocol ──────────────────────────────────────────────────
    def start(self) -> None:
        logger.info("[livekit] sink ready @ %d Hz", self.sample_rate_hz)

    def play_sync(self, pcm: bytes) -> None:
        if not pcm:
            return
        pcm = self._carry + pcm
        whole = len(pcm) - (len(pcm) % 2)
        self._carry = pcm[whole:]
        if whole <= 0:
            return
        # 20 ms frames: capture_frame waits for room in LiveKit's ~1 s queue, so
        # one multi-second TTS chunk as a single frame could never fit.
        gen = self._gen
        for i in range(0, whole, self._frame_bytes):
            chunk = pcm[i:min(i + self._frame_bytes, whole)]
            self._q.put_nowait((gen, chunk))
            self._queued_bytes += len(chunk)
        now = time.monotonic()
        self._playout_end_monotonic = (max(self._playout_end_monotonic, now)
                                       + whole / float(self.sample_rate_hz * 2))
        if self._feeder is None or self._feeder.done():
            self._feeder = asyncio.get_running_loop().create_task(self._feed())

    async def play(self, pcm: bytes) -> None:
        self.play_sync(pcm)

    async def _feed(self) -> None:
        rtc = self._t._rtc
        while True:
            gen, chunk = await self._q.get()
            self._queued_bytes -= len(chunk)
            if gen != self._gen:
                continue
            frame = rtc.AudioFrame(chunk, self.sample_rate_hz, 1, len(chunk) // 2)
            try:
                await self._t._out_source.capture_frame(frame)
                self._bytes_sent += len(chunk)
            except Exception as e:
                # A dead room must not kill the feeder silently mid-interview;
                # log once per failure and keep draining so bytes_buffered()
                # still reaches 0 and the turn can finalise.
                logger.warning("[livekit] capture_frame failed: %s", e)

    async def flush(self) -> None:
        # Barge-in / cancel: drop what's queued here AND in LiveKit, and release
        # the playout wait — the browser won't ack an utterance that was cut.
        self._gen += 1
        self._carry = b""
        while not self._q.empty():
            _, chunk = self._q.get_nowait()
            self._queued_bytes -= len(chunk)
        try:
            self._t._out_source.clear_queue()
        except Exception:  # pragma: no cover
            pass
        self._playout_end_monotonic = time.monotonic()
        self._awaiting_sub = None
        self._playout_done_event.set()

    async def stop(self) -> None:
        # Room teardown is owned by LiveKitTransport.close().
        if self._feeder is not None and not self._feeder.done():
            self._feeder.cancel()
        logger.info("[livekit] sink stopped (total bytes sent=%d)", self._bytes_sent)

    def bytes_buffered(self) -> int:
        if self._awaiting_sub is not None:
            return 1
        return int(self._pending_s() * self.sample_rate_hz * 2)
