"""Speaker audio sink.

Implements `stream_b_new.contracts.audio.AudioSink`. Receives raw PCM16 mono
chunks (header already stripped by TTSClient), plays them through the
default output device.

Threading: `play()` is called from the asyncio main thread (via TTSClient's
parallel reader). `_callback` runs on a sounddevice background thread. A
thread-safe queue bridges the two.

Bug #4 fix: TTSClient's `_on_pcm` originally did
`asyncio.create_task(self._sink.play(pcm))` per frame — but `play()` has no
awaits, so wrapping it in a coroutine just added scheduler latency. Under
heavy TTS streaming, dozens of pending `play()` tasks would pile up in the
event loop, draining at scheduler pace instead of TTS-arrival pace. The
audio_sink's internal queue then reported 3-5 seconds of buffered audio
even when only 1.5s had actually arrived. We now expose `play_sync()` for
the synchronous call path.

AEC hook (Exp #2): `set_pcm_consumed_callback(cb)` lets the AEC code register
a callback that fires from the sounddevice thread WHEN bytes are about to
hit the speaker hardware. That's the moment the candidate's mic will hear
the echo, ~50ms later. Used to feed the AEC reverse stream in lockstep with
real-world playback timing (the buffered `play_sync` queue still has a
latency relative to actual playback because Kokoro generates faster than
realtime; this callback fires inside the playback pipeline itself, so
timing is correct).
"""
from __future__ import annotations

import asyncio
import logging
import queue
import threading
from typing import Callable

import numpy as np
import sounddevice as sd

logger = logging.getLogger(__name__)

DEFAULT_SAMPLE_RATE = 16_000
BLOCK_SIZE = 1024

# Callback that receives PCM16 bytes as they're about to be written to the
# speaker hardware. Called from the sounddevice background thread. Must be
# fast (no allocations, no awaits) — anything heavy should be deferred via
# a thread-safe queue. Used by the AEC reference-timing path.
PcmConsumedCallback = Callable[[bytes], None]


class SpeakerAudioSink:
    def __init__(self, sample_rate: int = DEFAULT_SAMPLE_RATE) -> None:
        self.sample_rate_hz = sample_rate
        self._chunks: queue.Queue[np.ndarray] = queue.Queue(maxsize=4096)
        self._leftover: np.ndarray = np.zeros(0, dtype=np.float32)
        self._stream: sd.OutputStream | None = None
        self._lock = threading.Lock()
        # Optional callback fired from `_callback()` when bytes are about
        # to be written to the speakers. Used by AEC to align the
        # reverse-stream feed with actual playback timing instead of with
        # TTS-arrival timing. See class docstring for rationale.
        self._on_pcm_consumed: PcmConsumedCallback | None = None

    def start(self) -> None:
        with self._lock:
            if self._stream is not None:
                return
            self._stream = sd.OutputStream(
                samplerate=self.sample_rate_hz,
                channels=1,
                dtype="float32",
                blocksize=BLOCK_SIZE,
                callback=self._callback,
            )
            self._stream.start()
            logger.info("speaker output started @ %d Hz", self.sample_rate_hz)

    async def stop(self) -> None:
        with self._lock:
            if self._stream is None:
                return
            try:
                self._stream.stop()
                self._stream.close()
            except Exception as e:  # pragma: no cover
                logger.warning("speaker stream close error: %s", e)
            finally:
                self._stream = None

    async def play(self, pcm: bytes) -> None:
        # Kept for AudioSink protocol compliance. Now just delegates to
        # play_sync — see class docstring for the Bug #4 history.
        self.play_sync(pcm)

    def play_sync(self, pcm: bytes) -> None:
        """Synchronous enqueue of a PCM frame.

        Bug #4 fix: TTSClient's `_on_pcm` should call THIS directly rather
        than wrapping in `asyncio.create_task(play(...))`. play() has no
        awaits, and `create_task` per frame caused dozens of pending
        coroutines to pile up in the event loop, draining at scheduler
        pace instead of TTS-arrival pace. Calling synchronously keeps the
        sink queue's depth in lockstep with actual TTS arrival.
        """
        if not pcm:
            return
        if len(pcm) % 2 != 0:
            pcm = pcm + b"\x00"
        samples = np.frombuffer(pcm, dtype="<i2").astype(np.float32) / 32768.0
        try:
            self._chunks.put_nowait(samples)
        except queue.Full:
            logger.warning("speaker buffer full — dropping %d samples", samples.size)

    def set_pcm_consumed_callback(self, cb: PcmConsumedCallback | None) -> None:
        """Register/unregister a callback fired when bytes hit the speaker.

        The callback runs on the sounddevice background thread. It receives
        the PCM16 bytes that were just written to outdata in the current
        callback. Keep it FAST — no allocations, no awaits, use a
        thread-safe queue to defer real work to the asyncio loop.

        Used by AEC to feed the reverse stream at the moment bytes
        actually hit the speaker, instead of at TTS-arrival time. That
        keeps the reference vs mic timing tight (~50 ms) instead of
        catastrophically misaligned (~5 s).
        """
        self._on_pcm_consumed = cb

    async def flush(self) -> None:
        """Drain queued PCM chunks AND the in-flight leftover slice so the
        speakers go silent immediately. Used on barge-in / watchdog cancel —
        without clearing `_leftover` the next callback would still play up
        to one BLOCK_SIZE of audio after cancel."""
        while True:
            try:
                self._chunks.get_nowait()
            except queue.Empty:
                break
        # Single-writer scalar reassignment is fine without a lock; the
        # audio thread reads `_leftover` next callback and sees the empty.
        self._leftover = np.zeros(0, dtype=np.float32)

    def bytes_buffered(self) -> int:
        """Approximate number of PCM16 bytes still pending playback.

        Sums the actual sample counts in every queued chunk + the in-flight
        `_leftover` slice (the partial chunk from the most recent callback).
        Returns 0 only when the speakers will truly emit silence on the next
        callback — used by the orchestrator's sink-drain wait to decide when
        the AI is *audibly* done speaking (vs. Stream A's audio_end which
        only means PCM stopped arriving on the wire)."""
        try:
            samples = self._leftover.size
            # queue.Queue isn't safely iterable from another thread; peek at
            # the internal deque under its lock. This is fine — we accept
            # a slightly stale snapshot.
            with self._chunks.mutex:
                for chunk in self._chunks.queue:
                    samples += int(chunk.size)
            return samples * 2     # PCM16 = 2 bytes per sample
        except Exception:
            return 0

    def _callback(self, outdata, frames: int, _time, status) -> None:
        if status:
            logger.debug("speaker output status: %s", status)
        idx = 0
        if self._leftover.size > 0:
            n = min(self._leftover.size, frames)
            outdata[:n, 0] = self._leftover[:n]
            self._leftover = self._leftover[n:]
            idx = n
        while idx < frames:
            try:
                chunk = self._chunks.get_nowait()
            except queue.Empty:
                outdata[idx:, 0] = 0.0
                # Fire the consumer-callback even for the partial-or-silent
                # block, so AEC sees consistent timing alignment. The
                # trailing silence helps the AEC filter know "speakers
                # went quiet here".
                self._fire_pcm_consumed_safe(
                    outdata[:idx, 0] if idx > 0 else outdata[:0, 0],
                )
                return
            n = min(chunk.size, frames - idx)
            outdata[idx : idx + n, 0] = chunk[:n]
            if n < chunk.size:
                self._leftover = chunk[n:]
            idx += n
        # Full block written. Fire the consumer-callback with what we just
        # wrote, so AEC can feed it as the reverse-stream reference.
        self._fire_pcm_consumed_safe(outdata[:, 0])

    def _fire_pcm_consumed_safe(self, samples_f32: np.ndarray) -> None:
        """Convert float32 [-1, 1] back to PCM16 bytes and invoke the cb.

        Runs on the sounddevice thread. Defensive: never let a callback
        exception interrupt audio playback. Skips work entirely if no
        callback is registered.
        """
        cb = self._on_pcm_consumed
        if cb is None or samples_f32.size == 0:
            return
        try:
            pcm16 = (samples_f32 * 32768.0).clip(-32768, 32767).astype("<i2").tobytes()
            cb(pcm16)
        except Exception as e:  # pragma: no cover — never break the audio thread
            logger.warning("pcm-consumed callback raised: %s", e)
