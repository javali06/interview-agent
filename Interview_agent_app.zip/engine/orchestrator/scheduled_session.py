"""Shared lifecycle hooks for admin-scheduled interview sessions.

Why this file exists
====================
We have two entry points that can drive a scheduled interview:

    orchestrator_new/live_main.py    – local CLI, spawned by admin/spawner
    deploy/azure_app.py              – cloud FastAPI, attaches in-process
                                        when the candidate's WS arrives

Both need to do the SAME two things around the InterviewSession lifecycle:

  1. As the session crosses SESSION_STARTED / SESSION_ENDED, write
     status='in_progress' / 'completed' back to the admin SQLite row so
     the dashboard shows live state.
  2. Once the session has fully ended, kick off
     admin.evaluation_service.generate_evaluation() so the performance
     dashboard gets populated.

Until this module existed, the cloud path was missing piece (2) entirely
— sessions ran fine but the dashboard stayed empty because nobody told
the eval service to run. Local worked because live_main hand-rolled
both pieces inline. Anything live_main added would silently NOT happen
in cloud until somebody noticed and re-ported it.

This module is the single source of truth. Both entry points call
``attach_db_lifecycle`` after constructing the InterviewSession and
``generate_post_session_evaluation`` after ``session.run_until_signal``
returns. Future lifecycle features land here once, not twice.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


def attach_db_lifecycle(session: Any, token: str, is_handover=None) -> None:
    """Subscribe to the InterviewSession's event bus so SESSION_STARTED
    flips the SQLite row to status='in_progress' (with started_at) and
    SESSION_ENDED flips it to 'completed' (with ended_at).

    Failures are logged at WARNING and swallowed — the admin dashboard
    showing a stale status is a far better failure mode than the
    interview hanging because the DB hiccupped.
    """
    # Late imports — `admin` and `stream_b_new` are heavyweight; keep
    # them off the hot import path for code paths that don't need them.
    from app import db as admin_db
    from engine.brain.contracts.events import EventKind

    async def _hook(evt: Any) -> None:
        try:
            kind = evt.kind.value if hasattr(evt.kind, "value") else evt.kind
            if kind == EventKind.SESSION_STARTED.value:
                # DB is synchronous SQLAlchemy — offload so the (Postgres,
                # cross-network) write never blocks the shared event loop, which
                # every concurrent interview on this replica runs on.
                await asyncio.to_thread(
                    admin_db.update, token,
                    status="in_progress", started_at=admin_db.now_iso(),
                )
                logger.info("[scheduled-token] %s → in_progress", token[:8])
            elif kind == EventKind.SESSION_ENDED.value:
                # A hand-off ends THIS runner, not the interview: it goes on
                # on another replica (or the WebSocket path), so don't mark it
                # completed under the runner that has it now.
                if is_handover is not None and is_handover():
                    logger.info("[scheduled-token] %s handed off — status left as is", token[:8])
                else:
                    await asyncio.to_thread(
                        admin_db.update, token,
                        status="completed", ended_at=admin_db.now_iso(),
                    )
                    logger.info("[scheduled-token] %s → completed", token[:8])
                # Persist the per-model cost rollup so the admin dashboard
                # can render it even after the worker process restarts.
                # The in-process accumulator gets cleared once persisted.
                try:
                    from app.paths import session_dir
                    from engine.brain.observability.cost_tracker import (
                        clear as _ct_clear,
                        persist as _ct_persist,
                    )
                    out = session_dir(token) / "cost_summary.json"
                    # File write lands on the Azure Files mount — offload it too.
                    await asyncio.to_thread(_ct_persist, token, out)
                    _ct_clear(token)
                except Exception as cte:
                    logger.warning(
                        "[cost_tracker] persist failed for %s: %s",
                        token[:8], cte,
                    )
        except Exception as e:
            logger.warning("[scheduled-token] DB lifecycle update failed: %s", e)

    session._bus.subscribe(_hook)


async def generate_post_session_evaluation(token: str) -> Optional[dict]:
    """Run admin.evaluation_service.generate_evaluation() for a finished
    session. Reads sessions/{token}/events.jsonl (the full transcript
    + cadence + event timeline) and writes
    sessions/{token}/evaluation.json which the admin dashboard renders.

    Returns the evaluation dict on success, or None on failure (the
    caller is the session's cleanup path — it shouldn't crash because
    an LLM hiccupped during scoring; the admin UI's manual
    'Regenerate' button is the recovery path).
    """
    try:
        # Dispatcher: v2 plugin pipeline when EVAL_PLUGINS_ENABLED, else v1.
        from app.plugin_evaluation import run_evaluation as generate_evaluation
    except ImportError:
        logger.info(
            "[evaluation] admin.evaluation_service not importable — "
            "skipping eval generation for token=%s", token[:8],
        )
        return None
    try:
        logger.info("[evaluation] generating for token=%s ...", token[:8])
        evaluation = await generate_evaluation(token)
        overall = evaluation.get("overall", {}) if isinstance(evaluation, dict) else {}
        score = overall.get("score", "?")
        band = overall.get("band", "?")
        logger.info(
            "[evaluation] %s done — score=%s/100 band=%s "
            "(sessions/%s/evaluation.json)",
            token[:8], score, band, token,
        )
        return evaluation
    except Exception as e:
        logger.exception(
            "[evaluation] generation failed for token=%s — admin UI "
            "Regenerate button can retry: %s",
            token[:8], e,
        )
        return None
