"""orchestrator_new — thin shim around engine.brain's InterviewSession.

Owns mic capture and speaker playback. Boots Stream A's STT/VAD/TTS
subprocesses (via `scripts/run_live_v2.sh`) but is happy to run against
already-running services.

Intentionally tiny: ~300 lines across audio_source.py, audio_sink.py, and
live_main.py. No agent logic — that all lives in engine.brain.
"""
__version__ = "0.1.0"
