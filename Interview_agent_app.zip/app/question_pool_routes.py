"""Question pools API (`/api/question-pools`): CRUD plus the maker-checker workflow.

Every route is gated on a permission. Writes go to the draft prefix; interviews
read only the published one (`/{pool_id}/for-phase`), so a draft can never reach
a candidate. Built-in pools are read-only; Duplicate makes an editable copy.

Design notes: docs/question-pool-maker-checker.md.
"""
from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Optional

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import JSONResponse, PlainTextResponse, Response
from pydantic import BaseModel

from app import approval_service as approvals
from app import question_pools as qp
from app.constants import (
    GLOBAL_TEAM,
    POOL_BUILTIN,
    POOL_DRAFT,
    POOL_PENDING,
    POOL_PUBLISHED,
    POOL_SOURCE_BUILTIN,
    POOL_SOURCE_CUSTOM,
    POOL_SOURCE_DRAFT,
)
from app.rbac import describe_user, ensure_permission, grants_for, permitted_teams, require

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/question-pools", tags=["question-pools"])


@contextmanager
def _as_http(*, value_error_is_conflict: bool = False):
    """Map ApprovalError to its HTTP status/message (and ValueError to 409 if asked) for workflow routes."""
    try:
        yield
    except approvals.ApprovalError as e:
        raise HTTPException(status_code=e.status, detail=str(e)) from e
    except ValueError as e:
        if not value_error_is_conflict:
            raise
        raise HTTPException(status_code=409, detail=str(e)) from e


def _draft_visibility(user_id: int):
    """Return a `team -> bool` check for draft visibility (edit or approve), reading grants only once."""
    grants = grants_for(user_id)
    edit = grants.get("pools.edit", set())
    approve = grants.get("pools.approve", set())

    def _can(team: str) -> bool:
        """True if the person may edit or approve for `team` (or `*`)."""
        return any(team in held or GLOBAL_TEAM in held for held in (edit, approve))

    return _can


def _may_see_draft(user_id: int, team: str) -> bool:
    """True if this person may read a draft of `team`; `pools.view` alone is not enough."""
    return _draft_visibility(user_id)(team)


def _visible_editable(pool_id: str, user_id: int) -> qp.QuestionPool:
    """The draft-or-published pool, or 404; 403 unless this person may see that team's drafts and reviews."""
    pool = qp.load_editable(pool_id)
    if pool is None:
        raise HTTPException(status_code=404, detail="pool not found")
    if not _may_see_draft(user_id, _team_of(pool)):
        raise HTTPException(
            status_code=403,
            detail="Only this team's authors and checkers can see its reviews.",
        )
    return pool


def _team_of(pool: qp.QuestionPool) -> str:
    """The pool's owning team key, treating a pool with no team as `*` (every team)."""
    return pool.team or GLOBAL_TEAM


def _team_refusal(user_id: int, team: str) -> str:
    """A 403 message that names the teams this person CAN author for, so they know what to pick."""
    mine = sorted(t for t in permitted_teams(user_id, "pools.edit") if t != GLOBAL_TEAM)
    which = ", ".join(mine) if mine else "none"
    if team == GLOBAL_TEAM:
        return (
            "Choose a team for this pool — leaving it blank means every team, "
            f"which you cannot author for. Yours: {which}."
        )
    return f"You cannot author pools for team {team}. Yours: {which}."


def _actor_email(user_id: int) -> str:
    """The acting user's email, stamped as created_by/updated_by (which bars self-approval)."""
    info = describe_user(user_id)
    return info["email"] if info else ""


def _stamp_new(pool: qp.QuestionPool, team: str, user_id: int) -> None:
    """Set the owning team and the creator as author on a brand-new pool (create / duplicate)."""
    email = _actor_email(user_id)
    pool.team = team
    pool.created_by = email
    pool.updated_by = email


def _saved_draft(saved: qp.QuestionPool) -> JSONResponse:
    """The shared "draft saved" response returned by create, update and duplicate."""
    return JSONResponse({"ok": True, "state": POOL_DRAFT, **saved.summary(source=POOL_SOURCE_DRAFT)})


class _PoolBody(BaseModel):
    """Request body for creating or saving a pool."""
    pool_name: str
    description: str = ""
    pool_kind: str = qp.SPOKEN_KIND
    questions: list[dict] = []
    team: str = ""                 # blank means `*` (every team)


def _validated(body: _PoolBody) -> qp.QuestionPool:
    """Validate the request body into a QuestionPool, turning failures into a readable 400."""
    try:
        return qp.QuestionPool.model_validate({
            "pool_name": body.pool_name,
            "description": body.description,
            "pool_kind": body.pool_kind,
            "questions": body.questions,
        })
    except Exception as e:
        raise HTTPException(status_code=400, detail=_first_error(e)) from e


def _first_error(e: Exception) -> str:
    """The first readable line of a pydantic error, which the editor shows inline."""
    errs = getattr(e, "errors", None)
    if callable(errs):
        try:
            first = errs()[0]
            loc = ".".join(str(p) for p in first.get("loc", ()) if p != "__root__")
            msg = str(first.get("msg", "")).replace("Value error, ", "")
            return f"{loc}: {msg}" if loc else msg
        except Exception:
            pass
    return str(e)


@router.get("/kinds", dependencies=[Depends(require("pools.view"))])
def list_kinds() -> JSONResponse:
    """Every question kind and its fields, so the pool editor form can render itself from data."""
    from engine.brain.cadence import question_types as _qt

    kinds = [{
        "id": qp.SPOKEN_KIND,
        "label": "Specific question",
        "description": "A specific, pre-written question the interviewer asks out loud — the "
                        "candidate answers by talking, and the interviewer follows up on anything "
                        "the answer misses.",
        "written": False,
        "prompt_label": "The question",
        "prompt_required": True,
        "block": "",                # which block on the question `fields` read and write
        "fields": [],
    }, {
        "id": qp.CODING_KIND,
        "label": "Coding question",
        "description": "A live coding exercise — the candidate writes a function "
                       "in the editor and it is checked against your test cases.",
        "written": False,
        "block": "coding",
        "prompt_label": "Problem statement",
        "prompt_required": True,
        "prompt_placeholder": "Describe the problem, with an example of the "
                              "expected input and output…",
        # Mirrors features/coding/questions/library.yaml, not the generic pool shape.
        "fields": [
            {"name": "title", "kind": "text", "label": "Title",
             "required": False, "ui_required": True,
             "help": "Short name shown in the picker and on the candidate's tab, "
                     "e.g. Running Sum of a List."},
            {"name": "starter_code", "kind": "code", "label": "Starter code",
             "required": True, "ui_required": True, "language": "python",
             "help": "What the candidate sees in the editor to begin with."},
            {"name": "function_name", "kind": "text", "label": "Function name",
             "required": True, "ui_required": True,
             "help": "The function your test cases call, e.g. two_sum."},
            {"name": "test_cases", "kind": "test_cases", "label": "Test cases",
             "required": True, "ui_required": True,
             "help": "Input is the argument list as Python source (e.g. "
                     "[2, 7, 11, 15], 9); expected is the result as Python "
                     "source (e.g. (0, 1))."},
            {"name": "solution", "kind": "code", "label": "Reference solution",
             "required": False, "ui_required": False, "language": "python",
             "help": "Never shown to the candidate. Used to verify the question "
                     "and to brief the interviewer."},
            {"name": "hints", "kind": "string_list", "label": "Hints",
             "required": False, "ui_required": False,
             "help": "Released one at a time when the candidate asks. Order them "
                     "nudge → direction → near-answer."},
            {"name": "topics", "kind": "chips", "label": "Topics",
             "required": False, "ui_required": True,
             "options": list(qp.CODING_TOPICS),
             "help": "What the question exercises. The coding-phase picker "
                     "filters on these, so pick every one that applies."},
            {"name": "role_fit", "kind": "chips", "label": "Suitable for",
             "required": False, "ui_required": False,
             "options": list(qp.CODING_ROLES),
             "help": "Which roles this question suits. Leave empty if it suits any."},
            {"name": "estimated_time_s", "kind": "duration",
             "label": "Time budget", "required": False, "ui_required": False,
             "help": "Minutes on the clock for this question. Blank uses the "
                     "difficulty default: easy 10, medium 20, hard 30."},
        ],
    }, {
        "id": qp.SCENARIO_KIND,
        "label": "Visual Scenario Analysis",
        "description": "Show the candidate an image, video, or audio clip and ask a "
                       "question about it — the interviewer may follow up against what "
                       "a good answer should mention.",
        "written": False,
        "block": "scenario",
        "prompt_label": "The question",
        "prompt_required": True,
        "prompt_placeholder": "What do you want the candidate to notice or explain "
                              "about this media?",
        "fields": [
            {"name": "media", "kind": "asset_media", "label": "Media (image, video, or audio)",
             "required": True, "ui_required": True,
             "help": "What the candidate is shown before answering."},
            {"name": "max_followups", "kind": "count", "label": "Follow-ups",
             "required": False, "ui_required": False,
             "help": "How many times the interviewer may probe against the answer "
                     "points below. Defaults to 2."},
        ],
    }]
    for spec in _qt.QUESTION_TYPES:
        kinds.append({
            "id": spec.id,
            "block": "written_response",
            "label": spec.label,
            "description": spec.description,
            "written": True,
            "prompt_label": spec.prompt_label,
            "prompt_required": spec.prompt_required,
            "prompt_hidden": spec.prompt_hidden,
            "prompt_placeholder": spec.prompt_placeholder,
            # Question-scoped fields only: a pool has no phase.
            # `required` is the schema rule; `ui_required` is the stricter form rule.
            "fields": [
                {"name": f.name, "kind": f.kind, "label": f.label,
                 "required": f.required, "ui_required": f.required or f.ui_required,
                 "help": f.help,
                 **({"asset_kind": _qt.ASSET_FIELD_KINDS[f.kind]}
                    if f.kind in _qt.ASSET_FIELD_KINDS else {})}
                for f in _qt.question_fields(spec.id)
            ],
        })
    return JSONResponse({"kinds": kinds, "languages": _qt.api_catalog()["languages"]})


# Must stay above the /{pool_id} routes (FastAPI matches in declaration order).
@router.post("/assets", dependencies=[Depends(require("pools.edit"))])
async def upload_pool_asset(kind: str, file: UploadFile = File(...)) -> JSONResponse:
    """Upload a question's audio/image/video and return its stored name (works before the pool has an id)."""
    data = await file.read()
    try:
        name = qp.store_asset(kind, file.filename or "", data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    except Exception as e:
        logger.exception("[pools] asset upload failed")
        raise HTTPException(status_code=500, detail=str(e)) from e
    return JSONResponse({"ok": True, "name": name,
                         "url": f"/api/question-pools/assets/{name}"})


@router.get("/assets/{name}", dependencies=[Depends(require("pools.view"))])
def get_pool_asset(name: str):
    """Return an uploaded pool asset's bytes so the editor can preview it."""
    data = qp.load_asset(name)
    if data is None:
        raise HTTPException(status_code=404, detail="asset not found")
    return Response(content=data, media_type="application/octet-stream")


@router.get("")
def list_pools(user_id: int = Depends(require("pools.view"))) -> JSONResponse:
    """The pools page: built-ins, published pools and visible drafts, one row each with workflow state."""
    from app.main import _builtin_pool_summaries    # local: avoids a circular import

    published = qp.list_pools()
    all_drafts = qp.list_drafts()
    draft_ids = {d["pool_id"] for d in all_drafts}
    published_ids = {p["pool_id"] for p in published}

    # One ledger query and one grants read for the whole page.
    states = approvals.pool_states(published_ids | draft_ids)
    may_see = _draft_visibility(user_id)

    def _annotate(item: dict, state: str, has_draft: bool) -> None:
        """Add the storage state and workflow fields the list UI needs to one pool row."""
        status = states.get(item["pool_id"]) or {}
        item["state"] = state
        item["submitted_by"] = status.get("submitted_by")
        item["steps"] = status.get("steps") or []
        item["workflow"] = status.get("state", POOL_DRAFT)
        item["next_step"] = status.get("next_step")
        item["has_draft"] = has_draft

    for item in published:
        team = item.get("team") or GLOBAL_TEAM
        _annotate(item, POOL_PUBLISHED, item["pool_id"] in draft_ids and may_see(team))

    drafts = []
    for item in all_drafts:
        if item["pool_id"] in published_ids:
            continue                      # shown on its published row
        if not may_see(item.get("team") or GLOBAL_TEAM):
            continue
        _annotate(item, POOL_DRAFT, True)
        drafts.append(item)

    return JSONResponse({
        "pools": _builtin_pool_summaries() + published + drafts,
    })


@router.post("")
def create_pool(
    body: _PoolBody, user_id: int = Depends(require("pools.edit"))
) -> JSONResponse:
    """Maker creates a pool for a team; it is saved as a draft and goes live only after approval."""
    pool = _validated(body)
    team = (body.team or "").strip() or GLOBAL_TEAM
    ensure_permission(user_id, "pools.edit", team, lambda: _team_refusal(user_id, team))
    _stamp_new(pool, team, user_id)
    try:
        saved = qp.save_draft(pool)
    except Exception as e:
        logger.exception("[pools] create failed")
        raise HTTPException(status_code=500, detail=str(e)) from e
    return _saved_draft(saved)


def _builtin_pool_detail(pool_id: str) -> JSONResponse:
    """Show a shipped (built-in) pool in the custom-pool shape, read-only and without workflow."""
    from app.main import _builtin_pool_load    # local: avoids a circular import

    data = _builtin_pool_load(pool_id)
    if data is None:
        raise HTTPException(status_code=404, detail="pool not found")
    try:
        pool = qp.QuestionPool.model_validate({
            "pool_name": data.get("pool_name") or pool_id,
            "description": data.get("description") or "",
            "questions": data.get("questions") or [],
        })
    except Exception as e:
        # A malformed shipped file is a deploy problem, not a missing pool.
        raise HTTPException(
            status_code=500, detail=f"built-in pool {pool_id} is unreadable: {e}"
        ) from e
    pool.pool_id = pool_id
    return JSONResponse({
        **pool.summary(source=POOL_SOURCE_BUILTIN),
        "questions": [q.model_dump() for q in pool.questions],
        "state": POOL_BUILTIN,
        "workflow": POOL_BUILTIN,
        "next_step": None,
        "last_comment": None,
        "has_published": True,
    })


@router.get("/{pool_id}")
def get_pool(
    pool_id: str, user_id: int = Depends(require("pools.view"))
) -> JSONResponse:
    """Open a pool: the draft if this person may see it, else published, else a built-in."""
    published = qp.load_pool(pool_id)
    draft = qp.load_draft(pool_id)
    pool = published
    is_draft = False
    can_see = _draft_visibility(user_id)
    if draft is not None and can_see(_team_of(draft)):
        pool, is_draft = draft, True
    if pool is None:
        return _builtin_pool_detail(pool_id)      # built-ins live in the image, not Blob
    status = approvals.pool_status(pool_id)
    return JSONResponse({
        **pool.summary(source=POOL_SOURCE_DRAFT if is_draft else POOL_SOURCE_CUSTOM),
        "questions": [q.model_dump() for q in pool.questions],
        "state": POOL_DRAFT if is_draft else POOL_PUBLISHED,
        "workflow": status["state"],
        "next_step": status["next_step"],
        # The return comment is about the draft, so it follows the draft's visibility.
        "last_comment": status["last_comment"] if can_see(_team_of(pool)) else "",
        "has_published": published is not None,
    })


@router.put("/{pool_id}")
def update_pool(
    pool_id: str, body: _PoolBody, user_id: int = Depends(require("pools.edit"))
) -> JSONResponse:
    """Maker edits a pool: always writes the draft, so the published version stays live until approval."""
    existing = qp.load_editable(pool_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="pool not found")

    # Checked against the pool's CURRENT team, then the new one: naming your own
    # team in the body must not move another team's pool into your chain.
    current = _team_of(existing)
    ensure_permission(user_id, "pools.edit", current, f"You cannot edit pools for team {current}.")
    team = (body.team or "").strip() or current
    if team != current:
        ensure_permission(user_id, "pools.edit", team,
                          f"You cannot move this pool to team {team}.")
    status = approvals.pool_status(pool_id)
    if status["state"] == POOL_PENDING:
        raise HTTPException(
            status_code=409,
            detail="This pool is waiting for approval. Withdraw it first if you "
                   "need to change it.",
        )

    pool = _validated(body)
    pool.team = team
    # created_by is kept across edits; both it and updated_by bar approving it.
    pool.created_by = existing.created_by or _actor_email(user_id)
    pool.updated_by = _actor_email(user_id)
    try:
        saved = qp.save_draft(pool, pool_id=pool_id)
    except Exception as e:
        logger.exception("[pools] update failed")
        raise HTTPException(status_code=500, detail=str(e)) from e
    return _saved_draft(saved)


@router.delete("/{pool_id}")
def remove_pool(
    pool_id: str, user_id: int = Depends(require("pools.view"))
) -> JSONResponse:
    """Delete a pool's draft (pools.edit) and/or published copy (pools.publish); refused while pending."""
    published = qp.load_pool(pool_id)
    draft = qp.load_draft(pool_id)
    if published is None and draft is None:
        raise HTTPException(status_code=404, detail="pool not found")

    status = approvals.pool_status(pool_id)
    if status["state"] == POOL_PENDING:
        raise HTTPException(
            status_code=409,
            detail="This pool is waiting for approval. Withdraw it first — the "
                   "history would otherwise point at a pool that no longer exists.",
        )

    # Every permission first, so a refusal never leaves the draft half-deleted.
    if draft is not None:
        ensure_permission(user_id, "pools.edit", _team_of(draft))
    if published is not None:
        ensure_permission(
            user_id, "pools.publish", _team_of(published),
            "Deleting a published pool needs pools.publish — interviews may be using it.",
        )
    if draft is not None:
        qp.delete_draft(pool_id)
    if published is not None:
        if not qp.delete_pool(pool_id):
            raise HTTPException(status_code=500, detail="could not delete the pool")
    return JSONResponse({"ok": True})


class _DuplicateBody(BaseModel):
    """Request body for copying a pool (custom or built-in) into a new editable draft."""
    source: str                    # a custom pool id, or a built-in's filename (*.yaml)
    pool_name: Optional[str] = None
    team: str = ""


@router.post("/duplicate")
def duplicate_pool(
    body: _DuplicateBody, user_id: int = Depends(require("pools.edit"))
) -> JSONResponse:
    """Copy a custom or built-in pool into a new draft for a team, which then goes through review."""
    from app.main import _builtin_pool_load

    src = (body.source or "").strip()
    questions: Optional[list[dict]] = None
    name = body.pool_name or ""
    kind = qp.SPOKEN_KIND
    if src.endswith(".yaml"):                     # a shipped pool (always spoken)
        loaded = _builtin_pool_load(src)
        if loaded is None:
            raise HTTPException(status_code=404, detail="built-in pool not found")
        questions = loaded.get("questions") or []
        name = name or f"{loaded.get('pool_name') or src} (copy)"
        description = loaded.get("description") or ""
    else:
        pool = qp.load_pool(src)
        if pool is None:
            raise HTTPException(status_code=404, detail="pool not found")
        questions = [q.model_dump() for q in pool.questions]
        name = name or f"{pool.pool_name} (copy)"
        description = pool.description
        kind = pool.pool_kind                     # a written pool must stay written

    pool = _validated(_PoolBody(pool_name=name, description=description,
                                pool_kind=kind, questions=questions or []))
    team = (body.team or "").strip() or GLOBAL_TEAM
    ensure_permission(user_id, "pools.edit", team, f"You cannot author pools for team {team}.")
    _stamp_new(pool, team, user_id)
    saved = qp.save_draft(pool)                   # new id, new draft: goes through review
    return _saved_draft(saved)


@router.get("/{pool_id}/for-phase",
            dependencies=[Depends(require("pools.view"))])
def questions_for_phase(pool_id: str, token: str, kind: str = "") -> JSONResponse:
    """PUBLISHED questions for an interview phase (copying media into it); drafts never reach here."""
    pool = qp.load_pool(pool_id)          # published prefix only. Do not relax.
    if pool is None:
        raise HTTPException(status_code=404, detail="pool not found")

    out: list[dict] = []
    copied, failed = 0, []

    def _copy(name: str) -> None:
        """Copy one asset into the interview, counting successes and recording failures."""
        nonlocal copied
        if qp.copy_asset_to_session(name, token):
            copied += 1
        else:
            failed.append(name)

    for q in pool.questions:
        if kind and q.kind != kind:       # a phase only takes its own kind
            continue
        item: dict = {"kind": q.kind, "text": q.text, "topic": q.topic,
                      "difficulty": q.difficulty,
                      "coverage_tags": list(q.coverage_tags)}
        wr = q.written_response.model_dump(exclude_none=True) if q.written_response else {}
        for asset_field in ("audio_asset", "image_asset"):
            if wr.get(asset_field):
                _copy(str(wr[asset_field]))
        if wr:
            item["written_response"] = wr
        if q.coding is not None:
            item["id"] = q.id             # the cadence keys inline questions by id
            item["coding"] = q.coding.model_dump(exclude_none=True)
        if q.scenario is not None:
            item["id"] = q.id
            block = q.scenario.model_dump(exclude_none=True)
            ref = (block.get("media") or {}).get("ref")
            if ref:
                _copy(str(ref))
            item["scenario"] = block
        out.append(item)

    return JSONResponse({
        "ok": True, "pool_name": pool.pool_name, "questions": out,
        "assets_copied": copied, "assets_missing": failed,
    })


@router.get("/{pool_id}/export", dependencies=[Depends(require("pools.view"))])
def export_pool(pool_id: str) -> PlainTextResponse:
    """Download the published pool as YAML in the built-in file shape (can be committed as a built-in)."""
    pool = qp.load_pool(pool_id)
    if pool is None:
        raise HTTPException(status_code=404, detail="pool not found")
    return PlainTextResponse(
        pool.to_yaml(),
        media_type="text/yaml",
        headers={"Content-Disposition": f'attachment; filename="{pool_id}.yaml"'},
    )


# -- the maker-checker workflow -----------------------------------------------
# /approvals/queue is safe below /{pool_id} only because it has two segments;
# a new ONE-segment literal route must be declared above the /{pool_id} routes.


class _CommentBody(BaseModel):
    """Optional comment sent with a submit/approve/return/withdraw/publish action."""
    comment: str = ""


@router.get("/approvals/queue")
def approvals_queue(user_id: int = Depends(require("pools.approve"))) -> JSONResponse:
    """The checker's approvals queue: pools they can sign, with name and question count."""
    items = approvals.queue_for(user_id)
    for item in items:
        pool = qp.load_editable(item["pool_id"])
        item["pool_name"] = pool.pool_name if pool else item["pool_id"]
        item["question_count"] = len(pool.questions) if pool else 0
    return JSONResponse({"queue": items})


class _QuestionVerdict(BaseModel):
    """A checker's approve/reject decision on one question."""
    question_id: str
    verdict: str                 # only approved | rejected; anything else is a 400
    comment: str = ""


class _ReviewBody(BaseModel):
    """Request body for a per-question review: one verdict per question."""
    verdicts: list[_QuestionVerdict]


@router.post("/{pool_id}/review")
def review_pool(
    pool_id: str,
    body: _ReviewBody,
    user_id: int = Depends(require("pools.approve")),
) -> JSONResponse:
    """Checker approves/rejects each question; "Approve all" uses this same route.

    A verdict other than approved or rejected is refused inside review(), so
    this route does not keep a second copy of that rule.
    """
    verdicts = {v.question_id: v.verdict for v in body.verdicts}
    comments = {v.question_id: v.comment for v in body.verdicts}
    draft = qp.load_draft(pool_id)
    if draft is not None:
        # Every question needs a decision, or "approve all" could publish unread ones.
        ids = {q.id for q in draft.questions}
        undecided = ids - set(verdicts)
        if undecided:
            raise HTTPException(
                status_code=400,
                detail=f"Decide on every question — {len(undecided)} has no verdict yet.",
            )
        unknown = set(verdicts) - ids
        if unknown:
            raise HTTPException(
                status_code=400,
                detail=f"These questions are not in the pool: {', '.join(sorted(unknown))}.",
            )
    with _as_http(value_error_is_conflict=True):
        status = approvals.review(
            pool_id,
            user_id,
            verdicts,
            comments=comments,
            on_publish=lambda ids: qp.stage_approved(pool_id, ids),
        )
    return JSONResponse({
        "ok": True,
        "status": status,
        "reviews": approvals.question_reviews(pool_id),
    })


@router.get("/{pool_id}/review")
def get_pool_review(
    pool_id: str, user_id: int = Depends(require("pools.view"))
) -> JSONResponse:
    """The review screen's data: questions, status and verdicts so far, so a checker can resume."""
    pool = _visible_editable(pool_id, user_id)
    status = approvals.pool_status(pool_id)
    return JSONResponse({
        "pool_id": pool_id,
        "pool_name": pool.pool_name,
        "team": pool.team or GLOBAL_TEAM,
        "status": status,
        "questions": [q.model_dump() for q in pool.questions],
        "reviews": approvals.question_reviews(pool_id),
    })


@router.get("/{pool_id}/history")
def pool_history(
    pool_id: str, user_id: int = Depends(require("pools.view"))
) -> JSONResponse:
    """A pool's full approval history plus its current status, for the history panel."""
    _visible_editable(pool_id, user_id)
    status = approvals.pool_status(pool_id)
    return JSONResponse({"history": approvals.history(pool_id), "status": status})


@router.post("/{pool_id}/submit")
def submit_pool(
    pool_id: str,
    body: _CommentBody,
    user_id: int = Depends(require("pools.submit")),
) -> JSONResponse:
    """Maker submits the draft into the approval chain of its team."""
    draft = qp.load_draft(pool_id)
    if draft is None:
        raise HTTPException(
            status_code=404,
            detail="There is no draft to submit. Edit the pool first.",
        )
    team = _team_of(draft)
    ensure_permission(user_id, "pools.submit", team, f"You cannot submit pools for team {team}.")
    with _as_http():
        status = approvals.submit(
            pool_id,
            user_id,
            team,
            author_emails=draft.author_emails(),
            comment=body.comment,
        )
    return JSONResponse({"ok": True, "status": status})


@router.post("/{pool_id}/approve")
def approve_pool(
    pool_id: str,
    body: _CommentBody,
    user_id: int = Depends(require("pools.approve")),
) -> JSONResponse:
    """Checker signs the whole pool's next step; the last step publishes the draft."""
    with _as_http(value_error_is_conflict=True):
        status = approvals.approve(
            pool_id,
            user_id,
            comment=body.comment,
            on_publish=lambda: qp.stage_draft(pool_id),
        )
    return JSONResponse(
        {"ok": True, "status": status, "published": status["state"] == POOL_PUBLISHED}
    )


@router.post("/{pool_id}/return")
def return_to_author(
    pool_id: str,
    body: _CommentBody,
    user_id: int = Depends(require("pools.approve")),
) -> JSONResponse:
    """Checker returns the pool to its author with a mandatory comment."""
    with _as_http():
        status = approvals.return_pool(pool_id, user_id, body.comment)
    return JSONResponse({"ok": True, "status": status})


@router.post("/{pool_id}/withdraw")
def withdraw_pool(
    pool_id: str, user_id: int = Depends(require("pools.submit"))
) -> JSONResponse:
    """The submitter withdraws their pending pool back to draft."""
    with _as_http():
        status = approvals.withdraw(pool_id, user_id)
    return JSONResponse({"ok": True, "status": status})


@router.post("/{pool_id}/publish")
def force_publish_pool(
    pool_id: str,
    body: _CommentBody,
    user_id: int = Depends(require("pools.publish")),
) -> JSONResponse:
    """Admin force-publishes the draft, skipping the chain (break-glass, recorded as such)."""
    draft = qp.load_draft(pool_id)
    if draft is None:
        raise HTTPException(status_code=404, detail="There is no draft to publish.")
    team = _team_of(draft)
    ensure_permission(user_id, "pools.publish", team,
                      f"You cannot publish pools for team {team}.")
    with _as_http():
        status = approvals.force_publish(
            pool_id,
            user_id,
            team,
            comment=body.comment,
            on_publish=lambda: qp.stage_draft(pool_id),
        )
    return JSONResponse({"ok": True, "status": status, "published": True})
