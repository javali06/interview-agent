"""Session-tier shard identity.

On Azure Container Apps the default ingress load-balances across a replica set,
so you cannot address a specific replica from outside. To keep an interview
pinned AND routable, the session tier runs as a pool of single-replica shard apps
(session-0, session-1, …), each with a stable internal FQDN. A token is placed on
one shard and every later connection (a reconnect) is routed there.

This module answers, from env:
  - who am I?            SHARD_ID / SHARD_FQDN   (used by the session tier)
  - who are all shards?  SESSION_SHARDS / SESSION_SHARD_FQDNS   (used by the gateway
                         to place a NEW token on the least-loaded shard)

The registry stores the owning shard's FQDN at claim time, so the gateway resolves
existing tokens from Redis; the static map here is only for placing new ones.
"""
from __future__ import annotations

import os
import socket


def is_pool() -> bool:
    """A replica of the scalable session POOL (Phase 3): many replicas behind one
    app, none addressable. It runs LiveKit interviews only — they need no
    inbound connection — and takes them from the shared placement queue."""
    return (os.environ.get("SESSION_POOL") or "").strip().lower() in ("1", "true", "yes")


def shard_id() -> str:
    """This replica's id. Shards are named by SHARD_ID; pool replicas share one
    env, so each is named by its own hostname. Defaults to a single local shard."""
    if is_pool():
        return f"pool-{socket.gethostname()}"
    return (os.environ.get("SHARD_ID") or "session-0").strip()


def shard_fqdn() -> str:
    """This replica's internal address the gateway proxies WebSockets to.
    "" for a pool replica: nothing can be routed to it. Defaults to a local
    host:port for dev."""
    if is_pool():
        return ""
    v = (os.environ.get("SHARD_FQDN") or "").strip()
    if v:
        return v
    port = os.environ.get("PORT", "8080")
    return f"localhost:{port}"


def all_shards() -> list[str]:
    """Every shard id in the pool (gateway view). Defaults to just this shard."""
    raw = (os.environ.get("SESSION_SHARDS") or "").strip()
    if raw:
        return [s.strip() for s in raw.split(",") if s.strip()]
    return [shard_id()]


def _fqdn_map() -> dict[str, str]:
    shards = all_shards()
    raw = (os.environ.get("SESSION_SHARD_FQDNS") or "").strip()
    if raw:
        fqdns = [f.strip() for f in raw.split(",") if f.strip()]
        if len(fqdns) == len(shards):
            return dict(zip(shards, fqdns))
    # Fallback: derive "<shard>:PORT" (works when shards share a DNS suffix
    # provided via SHARD_FQDN_SUFFIX, else bare shard name for local/tests).
    suffix = (os.environ.get("SHARD_FQDN_SUFFIX") or "").strip()
    port = os.environ.get("PORT", "8080")
    return {s: (f"{s}{suffix}:{port}" if suffix else f"{s}:{port}") for s in shards}


def fqdn_for(shard: str) -> str:
    """Resolve a shard id to its internal FQDN (gateway placement of new tokens)."""
    return _fqdn_map().get(shard, shard)
