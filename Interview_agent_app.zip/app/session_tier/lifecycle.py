"""Session claim / heartbeat / release — the distributed lifecycle that replaces
the in-process ``_token_sessions`` new-session logic.

Starting an interview on a shard is now a cluster operation:

  claim(token):  win the token lock  →  admit against cluster caps (active
                 sessions, this shard's load)  →  acquire Speech capacity
                 (Azure pool slot, else Groq)  →  register token→this shard.
                 Any step failing backs out the earlier ones and reports why.

  heartbeat_loop(token): refresh the registry TTL while the interview runs, so a
                 crashed replica's entries expire and the token can be re-claimed
                 (the distributed replacement for the orphan-reaper's cross-replica
                 half).

  release(token, claim): give back registry + admission + Speech on end.

A reconnect to a session still running in this process never reaches claim() — the
caller re-attaches it to the live runner first. So when claim() finds the token
already registered to THIS shard, its runner is dead (shard restart / crash) and
the token is ADOPTED: same admission slots, fresh Speech lease (see _adopt).
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass

from app.broker import stt_fallback
from app.coordination import admission, locks, registry
from app.session_tier import identity, placement

logger = logging.getLogger("session_tier.lifecycle")


@dataclass
class Claim:
    ok: bool
    reason: str = ""                              # why not, when ok is False
    stt: stt_fallback.SttLease | None = None      # Speech lease to release on end
    location: registry.SessionLocation | None = None  # set when owned elsewhere
    lease: registry.SessionLocation | None = None     # OUR fenced registry entry


async def claim(token: str) -> Claim:
    """Attempt to become the owning shard for ``token``. See module docstring."""
    async with locks.session_lock(token) as fence:
        if fence is None:
            # Another replica is mid-claim for the same token right now.
            return Claim(ok=False, reason="locked")

        existing = await registry.get(token)
        if existing is not None:
            if existing.shard == identity.shard_id():
                return await _adopt(token, existing)
            # Its owner is dead (no liveness key): take the interview over now
            # instead of waiting out the registry TTL — the new fence stops the
            # old owner should it come back. Only for fenced entries: a replica
            # still on pre-fencing code publishes no liveness key and must not
            # be mistaken for dead during a rollout.
            if existing.fence > 0 and not await placement.is_alive(existing.shard):
                logger.warning("[claim] token=%s owner %s is gone — taking over",
                               token[:8], existing.shard)
            else:
                return Claim(ok=False, reason="owned_elsewhere", location=existing)

        # Cluster admission: total live sessions + this shard's load.
        if not await admission.try_acquire(admission.ACTIVE_SESSIONS,
                                           admission.max_active_sessions()):
            return Claim(ok=False, reason="at_capacity")
        # This shard's load, capped at its CPU-bound comfort ceiling. Reject
        # (rather than silently overload one gunicorn event loop) when the shard
        # is full, and give back the cluster counter we just took. Uncapped by
        # default (SHARD_MAX_SESSIONS unset) → preserves today's behavior.
        if not await admission.try_acquire(
            admission.shard_counter(identity.shard_id()),
            admission.max_shard_sessions(),
        ):
            await admission.release(admission.ACTIVE_SESSIONS)
            return Claim(ok=False, reason="shard_at_capacity")

        # Speech capacity (Azure pool slot, else Groq fallback).
        try:
            stt = await stt_fallback.acquire_stt()
        except Exception as e:  # no Azure headroom and no Groq
            await admission.release(admission.ACTIVE_SESSIONS)
            await admission.release(admission.shard_counter(identity.shard_id()))
            logger.warning("[claim] token=%s no speech capacity: %s", token[:8], e)
            return Claim(ok=False, reason="no_speech_capacity")

        # Record the leased Azure Speech key_id (if any) so the admission
        # reconciler can rebuild adm:speech:{key} from the registry and heal
        # leaks. Groq leases have no speech key → "".
        speech_key = ""
        if stt is not None and getattr(stt, "speech", None) is not None:
            speech_key = stt.speech.speech_key.key_id
        lease = await registry.claim(token, identity.shard_id(), identity.shard_fqdn(),
                                     speech_key=speech_key)
        logger.info("[claim] token=%s -> shard=%s stt=%s fence=%d", token[:8],
                    identity.shard_id(), stt.provider, lease.fence)
        return Claim(ok=True, stt=stt, lease=lease)


async def _adopt(token: str, existing: registry.SessionLocation) -> Claim:
    """The registry says THIS shard owns ``token``, yet we were asked to claim it.

    The caller only claims when this process has no live runner for the token,
    so the owner is a dead predecessor: this shard restarted (or its runner
    died) and the candidate reconnected before the entry's TTL ran out. Nothing
    is left to re-attach to — and the dead runner's Speech lease died with it,
    so starting a runner without a fresh one crashes on "no azure_speech_key".

    Adopt the token: the admission slots the dead runner took are still counted
    for it (the reconciler derives them from this very registry entry), so keep
    them; take a NEW Speech lease and re-register with its key, so the
    reconciler drops the dead runner's slot on that key. The result is an
    ordinary claim — release() gives everything back at the end.
    """
    try:
        stt = await stt_fallback.acquire_stt()
    except Exception as e:
        logger.warning("[claim] token=%s adopt: no speech capacity: %s", token[:8], e)
        return Claim(ok=False, reason="no_speech_capacity")
    speech_key = ""
    if getattr(stt, "speech", None) is not None:
        speech_key = stt.speech.speech_key.key_id
    lease = await registry.claim(token, identity.shard_id(), identity.shard_fqdn(),
                                 speech_key=speech_key)
    logger.info("[claim] token=%s adopted from a dead runner on shard=%s "
                "(old speech_key=%s) stt=%s fence=%d", token[:8], identity.shard_id(),
                existing.speech_key or "-", stt.provider, lease.fence)
    return Claim(ok=True, stt=stt, lease=lease)


async def release(token: str, claim_: Claim | None) -> None:
    """Give back everything a successful claim took."""
    if claim_ is None or not claim_.ok:
        return
    try:
        # Fenced: if another replica has since taken the interview, its entry
        # stays; our own admission slots are still ours to give back.
        await registry.release(token, claim_.lease)
        await admission.release(admission.ACTIVE_SESSIONS)
        await admission.release(admission.shard_counter(identity.shard_id()))
        if claim_.stt is not None:
            await stt_fallback.release_stt(claim_.stt)
        logger.info("[release] token=%s freed", token[:8])
    except Exception as e:  # release must never crash teardown
        logger.warning("[release] token=%s cleanup hiccup: %s", token[:8], e)


async def heartbeat_loop(token: str, stop: asyncio.Event,
                         *, interval_s: float | None = None,
                         lease: registry.SessionLocation | None = None,
                         on_lost=None) -> None:
    """Renew our fenced lease until ``stop`` is set. ``interval_s`` overrides
    the derived cadence (tests pass a small value).

    If the lease is LOST — another replica holds or has claimed the interview —
    call ``on_lost()`` and stop renewing. Safety rule: a replica that cannot
    renew must stop working on the interview at once; ``on_lost`` does that
    (the shard cancels its runner). It never re-takes the entry blindly: an
    entry Redis lost is restored only when no newer claim exists."""
    ttl = registry.DEFAULT_TTL_S
    interval = interval_s if interval_s is not None else max(5, ttl // 3)
    if lease is None:
        lease = await registry.get(token)
        if lease is None:
            return
    while not stop.is_set():
        try:
            await asyncio.wait_for(stop.wait(), timeout=interval)
        except asyncio.TimeoutError:
            pass
        if stop.is_set():
            return
        try:
            status = await registry.renew(lease, ttl_s=ttl)
        except Exception as e:  # Redis blip: keep the interview, try next beat
            logger.warning("[heartbeat] token=%s renew failed: %s", token[:8], e)
            continue
        if status == registry.RESTORED:
            logger.info("[heartbeat] token=%s registry entry was lost — restored "
                        "(fence %d, no newer claim)", token[:8], lease.fence)
        elif status == registry.LOST:
            logger.warning("[heartbeat] token=%s lease LOST (fence %d) — another "
                           "replica has the interview; stopping it here", token[:8], lease.fence)
            if on_lost is not None:
                try:
                    on_lost()
                except Exception as e:  # pragma: no cover
                    logger.warning("[heartbeat] on_lost failed: %s", e)
            return
