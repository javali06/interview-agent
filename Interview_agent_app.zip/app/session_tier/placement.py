"""Placement — how an interview start reaches a session replica (Phase 3.2).

Once the session tier runs several replicas behind one app, the gateway cannot
address a specific replica, so starts travel through Redis instead of HTTP:

  * an interview nobody owns yet  → the SHARED queue; any replica with spare
    capacity takes the next one (first come, first served);
  * an interview a replica owns    → that replica's INBOX (a refresh, a second
    tab, a hand-off request: only the owner can answer those).

The gateway waits on a per-request reply key. A request carries a deadline, and
a replica drops one that has already expired, so a start the gateway gave up
on (and answered "use the WebSocket") is never run late.

Each replica also keeps a short-lived *alive* key. An owner whose key has
lapsed is dead (crash, OOM): its interviews may be taken over without waiting
out the registry TTL — safe because the registry lease is fenced (a replica
that was merely cut off from Redis finds its lease LOST and stops).
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from typing import Awaitable, Callable

from app.coordination import registry
from app.coordination.client import get_redis

logger = logging.getLogger("session_tier.placement")

SHARED_QUEUE = "place:room-start"
_INBOX = "place:inbox:{replica}"
_REPLY = "place:reply:{id}"
_ALIVE = "place:alive:{replica}"
ALIVE_TTL_S = 10
_REPLY_TTL_S = 60


def inbox(replica: str) -> str:
    return _INBOX.format(replica=replica)


async def is_alive(replica: str) -> bool:
    return bool(await get_redis().exists(_ALIVE.format(replica=replica)))


async def queue_length() -> int:
    return int(await get_redis().llen(SHARED_QUEUE))


# ── gateway side ──────────────────────────────────────────────────────────────
async def request_room_start(token: str, body: dict, *, timeout_s: float) -> tuple[int, dict]:
    """Send a start (or rejoin / hand-off request) to whoever should answer it,
    and wait for the answer. ``{"transport": "websocket"}`` if nobody answered
    in time — the page then takes the WebSocket path, which reports any real
    error itself."""
    r = get_redis()
    loc = await registry.get(token)
    owner = loc.shard if loc is not None else ""
    if owner and not await is_alive(owner):
        owner = ""  # dead owner: a live replica will take the interview over
    rid = uuid.uuid4().hex
    msg = json.dumps({"id": rid, "token": token, "body": body,
                      "deadline": time.time() + timeout_s})
    await r.rpush(inbox(owner) if owner else SHARED_QUEUE, msg)
    got = await r.blpop([_REPLY.format(id=rid)], timeout=max(1, int(timeout_s)))
    if got is None:
        logger.warning("[placement] token=%s: no replica answered within %.0fs",
                       token[:8], timeout_s)
        return 200, {"transport": "websocket"}
    reply = json.loads(got[1])
    return int(reply.get("status", 200)), reply.get("body") or {}


# ── replica side ──────────────────────────────────────────────────────────────
async def serve(me: str,
                handle: Callable[[str, dict], Awaitable[tuple[int, dict]]],
                *, has_capacity: Callable[[], bool], stop: asyncio.Event) -> None:
    """Answer starts until ``stop``: always our own inbox, and the shared queue
    only while ``has_capacity()`` (false when full or draining)."""
    r = get_redis()
    alive_key = _ALIVE.format(replica=me)
    last_alive = 0.0
    while not stop.is_set():
        try:
            now = time.monotonic()
            if now - last_alive > ALIVE_TTL_S / 3:
                await r.set(alive_key, "1", ex=ALIVE_TTL_S)
                last_alive = now
            keys = [inbox(me)] + ([SHARED_QUEUE] if has_capacity() else [])
            got = await r.blpop(keys, timeout=2)
            if got is None:
                continue
            msg = json.loads(got[1])
            if float(msg.get("deadline", 0)) < time.time():
                continue  # the gateway already gave up on this one
            # Answer in the background: a start waits for the AI to join the
            # room (seconds), and other requests must not queue behind it.
            asyncio.create_task(_answer(msg, handle), name=f"place-{msg['id'][:8]}")
        except asyncio.CancelledError:
            raise
        except Exception as e:  # Redis blip: keep serving
            logger.warning("[placement] serve loop error: %s", e)
            await asyncio.sleep(1)
    try:
        await r.delete(alive_key)
    except Exception:
        pass


async def _answer(msg: dict, handle) -> None:
    try:
        status, body = await handle(msg["token"], msg.get("body") or {})
    except Exception as e:
        logger.warning("[placement] start for token=%s failed: %r", str(msg.get("token"))[:8], e)
        status, body = 200, {"transport": "websocket"}
    key = _REPLY.format(id=msg["id"])
    r = get_redis()
    await r.rpush(key, json.dumps({"status": status, "body": body}))
    await r.expire(key, _REPLY_TTL_S)


async def pool_demand() -> int:
    """Interviews the pool must hold: those running on pool replicas plus those
    waiting in the queue for a replica. The pool's autoscaler divides this by
    interviews-per-replica (Phase 3.4); it never drops while interviews run, so
    scale-in only removes replicas that are actually idle in aggregate."""
    r = get_redis()
    running = 0
    async for key in r.scan_iter(match="adm:shard:pool-*", count=200):
        running += int(await r.get(key) or 0)
    return running + await queue_length()
