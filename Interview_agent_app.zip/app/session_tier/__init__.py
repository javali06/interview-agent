"""Session tier — the stateful, pinned live-interview core, made multi-replica.

  identity.py   shard id / FQDN + the pool map (shard-addressed replicas)
  lifecycle.py  claim / heartbeat / release around Redis coord + the broker

The live objects (WebBroadcaster, brain, SessionState) still live in the owning
replica's memory; these modules externalize only the routing pointer + capacity
accounting so more than one replica can run at once.
"""
from __future__ import annotations

from app.session_tier import identity, lifecycle

__all__ = ["identity", "lifecycle"]
