"""Persistence for human review of an LLM evaluation.

Append-only: a new verdict on a section SUPERSEDES that section's previous
active rows rather than updating them, so "what does this section say now" has
exactly one answer and the history of who thought what, when, is still on disk.

One submission = one coherent statement about one section (the lines moved, an
optional direct total, one reason). Superseding by section rather than by
individual row is what keeps that true: a reviewer who edits two dimensions and
then re-edits one of them does not end up with a half-old, half-new section.
"""
from __future__ import annotations

from typing import Any, Iterable, Optional

from sqlalchemy import select, update

from db.engine import session_scope
from db.models import EvaluationReview
from features.eval.review import ReviewRecord, ReviewTarget


def _to_row(r: ReviewRecord) -> EvaluationReview:
    return EvaluationReview(
        record_id=r.record_id, token=r.token,
        segment_id=r.target.segment_id, section=r.target.section,
        item_label=r.target.item_label, kind=r.kind,
        ai_value=r.ai_value, human_value=r.human_value,
        ai_state=r.ai_state, human_state=r.human_state, body=r.body,
        reason_kind=r.reason_kind, reason=r.reason,
        reviewer=r.reviewer, created_at=r.created_at,
        evaluation_generated_at=r.evaluation_generated_at,
        ai_rationale=r.ai_rationale, status=r.status, supersedes=r.supersedes,
    )


def _from_row(row: EvaluationReview) -> ReviewRecord:
    return ReviewRecord(
        record_id=row.record_id, token=row.token,
        target=ReviewTarget(segment_id=row.segment_id, section=row.section,
                            item_label=row.item_label),
        kind=row.kind, ai_value=row.ai_value, human_value=row.human_value,
        ai_state=row.ai_state, human_state=row.human_state, body=row.body or "",
        reason_kind=row.reason_kind, reason=row.reason or "",
        reviewer=row.reviewer or "", created_at=row.created_at,
        evaluation_generated_at=row.evaluation_generated_at or "",
        ai_rationale=row.ai_rationale or "",
        status=row.status, supersedes=row.supersedes,
    )


def save(records: Iterable[ReviewRecord]) -> int:
    """Insert one submission's rows, superseding the sections they replace.

    Every record in a call belongs to the same submission, so the sections it
    touches are retired together, in one transaction — a partially applied
    review would show a total that no reason explains."""
    recs = list(records)
    if not recs:
        return 0
    token = recs[0].token
    sections = {(r.target.segment_id, r.target.section) for r in recs}
    with session_scope() as s:
        for segment_id, section in sections:
            s.execute(
                update(EvaluationReview)
                .where(EvaluationReview.token == token,
                       EvaluationReview.segment_id == segment_id,
                       EvaluationReview.section == section,
                       EvaluationReview.status == "active")
                .values(status="superseded")
            )
        s.add_all([_to_row(r) for r in recs])
    return len(recs)


def load(token: str, *, active_only: bool = True) -> list[ReviewRecord]:
    """Every review record for one session, oldest first."""
    stmt = select(EvaluationReview).where(EvaluationReview.token == token)
    if active_only:
        stmt = stmt.where(EvaluationReview.status == "active")
    with session_scope() as s:
        return [_from_row(r) for r in s.execute(stmt.order_by(EvaluationReview.created_at)).scalars()]


def withdraw(token: str, segment_id: str, section: str) -> int:
    """Retire a section's review entirely — the scorecard falls back to the AI's
    own numbers. Still not a delete: the rows stay, marked superseded."""
    with session_scope() as s:
        res = s.execute(
            update(EvaluationReview)
            .where(EvaluationReview.token == token,
                   EvaluationReview.segment_id == segment_id,
                   EvaluationReview.section == section,
                   EvaluationReview.status == "active")
            .values(status="superseded")
        )
    return int(res.rowcount or 0)


def merge_into(token: str, doc: dict[str, Any],
               records: Optional[list[ReviewRecord]] = None) -> dict[str, Any]:
    """The export joined with this session's reviews.

    The ONE place the join happens, called by both the scorecard endpoint and
    the download — the two must stay the same document, and a second
    implementation is how they would stop being one."""
    from features.eval.review import apply_reviews
    try:
        recs = records if records is not None else load(token)
    except Exception:
        # A review store that is unavailable must never take the evaluation
        # down with it — the AI's scores are still the truth on their own.
        return doc
    return apply_reviews(doc, recs)
