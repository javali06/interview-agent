"""Outbound candidate notifications (currently: the interview-invite email).

Kept as its own package, not folded into app/jobs, so the SMTP/template code
has one clear home as more notification types show up later (reminders,
resend, etc.) — mirrors how app/broker and app/coordination are each one
concern with their own package.
"""
