"""Builds the (subject, html_body) for the candidate interview-invite email.

Table-based, fully inline-styled HTML (no external CSS/fonts) — the same
email-client-safe approach as smtp-notification-service/services/
notification_service.py, since most mail clients strip <style> blocks and
@import fonts. Pure functions, easy to unit test without touching SMTP.
"""
from __future__ import annotations

from html import escape

_ACCENT = "#ef43b3"      # the app's own CTA magenta (ui/candidate/style.css --accent)
_INK = "#1a0010"         # the app's own heading ink (ui/candidate/style.css --text)
_MUTE = "#80606e"        # the app's own muted text (ui/candidate/style.css --text-mute)


def build_subject(role: str) -> str:
    """The invite email's subject line.

    Example:
        subject = build_subject("Senior AI Engineer")
        # "Your Senior AI Engineer interview is ready"
    """
    return f"Your {role} interview is ready"


_EMAIL_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<body style="margin:0;padding:0;background-color:#f4f0f7;font-family:'Segoe UI',Arial,Helvetica,sans-serif;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"
         style="background-color:#f4f0f7;padding:24px 0;">
    <tr>
      <td align="center">
        <table role="presentation" width="580" cellpadding="0" cellspacing="0" border="0"
               style="width:580px;max-width:580px;background-color:#ffffff;border:1px solid #e8dfd9;border-radius:12px;overflow:hidden;">
          <tr>
            <td style="background-color:{accent};padding:22px 28px;">
              <p style="margin:0;font-family:'Segoe UI',Arial,sans-serif;font-size:18px;
                        font-weight:600;color:#ffffff;">Your interview is ready</p>
              <p style="margin:2px 0 0 0;font-family:'Segoe UI',Arial,sans-serif;font-size:13px;
                        font-weight:400;color:#ffffff;">{role}</p>
            </td>
          </tr>
          <tr>
            <td style="padding:28px 28px 8px 28px;">
              <p style="margin:0 0 16px 0;font-family:'Segoe UI',Arial,sans-serif;
                        font-size:15px;line-height:22px;color:{ink};">Hi {candidate_name},</p>
              <p style="margin:0 0 20px 0;font-family:'Segoe UI',Arial,sans-serif;
                        font-size:14px;line-height:21px;color:{ink};">
                Thank you for your interest in the <strong>{role}</strong> position. Your interview has
                been scheduled and is ready for you to begin at your convenience. The session will be
                conducted by Ava, our AI interviewer, directly through your web browser.</p>
            </td>
          </tr>
          <tr>
            <td align="center" style="padding:4px 28px 24px 28px;">
              <a href="{link}"
                 style="display:inline-block;background-color:{accent};color:#ffffff;text-decoration:none;
                        font-family:'Segoe UI',Arial,sans-serif;font-size:15px;font-weight:600;
                        padding:13px 30px;border-radius:8px;">Start your interview</a>
            </td>
          </tr>
          <tr>
            <td style="padding:0 28px 8px 28px;">
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                <tr>
                  <td style="background-color:#f7f2f9;border-left:4px solid {accent};
                             padding:14px 16px;font-family:'Segoe UI',Arial,sans-serif;
                             font-size:13px;line-height:19px;color:{ink};">
                    <strong>Before you start:</strong> please find a quiet space with a working camera
                    and microphone, and use a laptop or desktop computer with Chrome or Edge for the
                    best experience. This link is unique to you; please do not share it with anyone.</td>
                </tr>
              </table>
            </td>
          </tr>
          <tr>
            <td style="padding:20px 28px 28px 28px;">
              <p style="margin:0;font-family:'Segoe UI',Arial,sans-serif;font-size:14px;
                        line-height:21px;color:{ink};">We wish you the best of luck with your interview.
                        <br><br>Sincerely,<br><strong>The Hiring Team</strong></p>
            </td>
          </tr>
          <tr>
            <td style="background-color:#f4f0f7;padding:14px 28px;border-top:1px solid #e8dfd9;">
              <p style="margin:0;font-family:'Segoe UI',Arial,sans-serif;font-size:11px;
                        line-height:16px;color:{mute};">
                This link was sent to you because you applied for this role. If that wasn't you,
                you can safely ignore this email.</p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>"""


def build_invite_email(candidate_name: str, role: str, link: str) -> tuple[str, str]:
    """Builds the (subject, html_body) for a candidate's interview-invite email.

    Parameters:
        candidate_name: the candidate's name, as entered at schedule time.
        role: the role they're interviewing for.
        link: the full candidate interview URL (token included).
    Returns:
        (subject, html_body) ready to pass to email_client.send_email.
    Example:
        subject, body = build_invite_email("Priya Rao", "Senior AI Engineer",
                                            "https://.../app/candidate?token=...")
    """
    html_body = _EMAIL_TEMPLATE.format(
        accent=_ACCENT,
        ink=_INK,
        mute=_MUTE,
        candidate_name=escape(candidate_name),
        role=escape(role),
        link=escape(link, quote=True),
    )
    return build_subject(role), html_body
