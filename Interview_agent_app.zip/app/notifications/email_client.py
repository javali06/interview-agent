"""SMTP sending — one shared mailbox, one function.

Same shape as smtp-notification-service/services/email_sender.py (a
separate, already-deployed project): connect to the configured SMTP host
with the shared mailbox's own credentials and send one MIME message. No
Settings class here, by design — this repo's convention (see CLAUDE.md § Env
vars) is env vars read ad hoc via os.environ.get, not a central config object.
"""
from __future__ import annotations

import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import aiosmtplib


class EmailNotConfigured(RuntimeError):
    """Raised when SMTP_HOST/SMTP_FROM_ADDRESS aren't set — the caller
    should treat this as "sending is disabled here", not a hard failure."""


def is_configured() -> bool:
    return bool(os.environ.get("SMTP_HOST") and os.environ.get("SMTP_FROM_ADDRESS"))


async def send_email(to: str, subject: str, html_body: str) -> None:
    """Sends one HTML email to `to` over SMTP using the shared mailbox's
    credentials from the environment.

    Env: SMTP_HOST, SMTP_PORT (default 587), SMTP_USERNAME, SMTP_PASSWORD,
    SMTP_FROM_ADDRESS, SMTP_USE_TLS (default "true").

    Raises EmailNotConfigured if SMTP isn't set up yet (dev/test with no
    mailbox provisioned); raises aiosmtplib.SMTPException on a real send
    failure (connection/auth/rejected) so the caller's retry logic sees it.
    """
    host = os.environ.get("SMTP_HOST", "")
    from_address = os.environ.get("SMTP_FROM_ADDRESS", "")
    if not host or not from_address:
        raise EmailNotConfigured("SMTP_HOST / SMTP_FROM_ADDRESS not set — email sending is disabled")

    port = int(os.environ.get("SMTP_PORT", "587"))
    username = os.environ.get("SMTP_USERNAME") or None
    password = os.environ.get("SMTP_PASSWORD") or None
    use_tls = os.environ.get("SMTP_USE_TLS", "true").strip().lower() not in ("0", "false", "no")

    message = MIMEMultipart("alternative")
    message["From"] = from_address
    message["To"] = to
    message["Subject"] = subject
    message.attach(MIMEText(html_body, "html"))

    # Port 465 = implicit TLS from connect; anything else (587 typically) =
    # plaintext connect then STARTTLS — same distinction the reference
    # project's sender makes.
    use_implicit_tls = port == 465
    await aiosmtplib.send(
        message,
        hostname=host,
        port=port,
        username=username,
        password=password,
        use_tls=use_implicit_tls,
        start_tls=use_tls and not use_implicit_tls,
    )
