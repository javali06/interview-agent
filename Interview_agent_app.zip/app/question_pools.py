"""User-authored question pools: the model, and CRUD over Blob.

Stored in Blob (not the image, which is read-only) as YAML in the same shape as
the built-in pools, so downstream code treats both alike. The YAML files are the
only source of truth; there is no index table.
"""
from __future__ import annotations

import io
import logging
import re
import uuid
from datetime import datetime, timezone
from typing import Any, Callable, Optional

import yaml
from pydantic import BaseModel, Field, field_validator, model_validator

from app.constants import (
    GLOBAL_TEAM,
    POOL_SOURCE_BUILTIN,
    POOL_SOURCE_CUSTOM,
    POOL_SOURCE_DRAFT,
)
from engine.brain.cadence import question_types as qt
from engine.brain.cadence.schema import ScenarioMedia, WrittenQuestion, WrittenResponse

logger = logging.getLogger(__name__)

# Published pools. The id goes into a blob path, so it is generated server-side
# and matches _POOL_ID_RE (no slashes, dots or traversal).
BLOB_PREFIX = "question_pools/"

# Drafts. A SIBLING prefix (not a subfolder, which list_pools would scan).
# This split is the control: cadence only reads BLOB_PREFIX, so a draft cannot
# reach an interview; only an approval copies it across.
DRAFT_PREFIX = "question_pool_drafts/"

_POOL_ID_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")

DIFFICULTIES = ("easy", "medium", "hard")

# Only python can actually EXECUTE today (the browser runner is Pyodide).
# The field exists so pools authored now survive a future JS/TS runner.
CODING_LANGUAGES = ("python",)

# Curated vocabularies, lifted from what `features/coding/questions/library.yaml`
# actually uses. Curated rather than free text for the same reason LANGUAGES is:
# the coding-phase picker FILTERS on these, so one typo ("algos") silently makes
# a question unfindable instead of failing loudly.
CODING_TOPICS = ("algo", "dict", "dp", "graph", "heap", "list", "numpy",
                 "recursion", "string", "tree")
CODING_ROLES = ("ai", "backend", "data", "generalist")

# Per-difficulty default time budget, mirroring the coding loader's own table so
# a pooled question and a shipped one get the same default.
_TIME_BY_DIFFICULTY = {"easy": 600, "medium": 1200, "hard": 1800}

_FUNC_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# The kind of question a pool holds. "spoken" is the classic conversational
# question (what pools were before this); every other kind is a WRITTEN task and
# comes straight from the question-type registry.
#
# Extensibility is the whole point: adding MCQ later means adding ONE entry to
# question_types.QUESTION_TYPES — this module, the API, the editor form and the
# validator all pick it up with no further edits, because none of them enumerate
# the kinds themselves.
SPOKEN_KIND = "spoken"
# A live coding exercise: Monaco editor + test runner, not a conversation and
# not a written passage. It carries its own `coding` block (starter code, tests,
# reference solution) — deliberately NOT a `written_response`, whose whole model
# is "one prose answer under a character limit".
CODING_KIND = "coding"
# A Visual Scenario Analysis item: a media asset (image/video/audio) + a
# question about it. Carries its own `scenario` block (the media reference +
# max_followups) — not a `written_response` (no candidate-authored material,
# no char limit) and not `coding` (no editor/test runner).
SCENARIO_KIND = "scenario"


def pool_kind_ids() -> tuple[str, ...]:
    """Every allowed question kind: spoken, coding, scenario, plus the written types registry."""
    from engine.brain.cadence import question_types as _qt
    return (SPOKEN_KIND, CODING_KIND, SCENARIO_KIND, *_qt.QUESTION_TYPE_IDS)


def is_written_kind(kind: str) -> bool:
    """True only for written-response kinds, which are validated against `WrittenResponse`."""
    return kind not in (SPOKEN_KIND, CODING_KIND, SCENARIO_KIND)


def is_coding_kind(kind: str) -> bool:
    """True for a live-coding question, which is validated by its own `coding` block."""
    return kind == CODING_KIND


def is_scenario_kind(kind: str) -> bool:
    """True for a Visual Scenario Analysis question (media + question)."""
    return kind == SCENARIO_KIND


def _slug(text: str, fallback: str = "q") -> str:
    """A lowercase, underscore-separated id from free text (max 48 chars), used for ids and topics."""
    s = re.sub(r"[^a-z0-9]+", "_", (text or "").strip().lower())
    s = re.sub(r"_+", "_", s).strip("_")
    if not s or not s[0].isalpha():
        s = f"{fallback}_{s}" if s else fallback
    return s[:48]


def _vocab_list(v: Any, allowed: tuple[str, ...], label: str) -> list[str]:
    """Normalise a multi-select against an allowed list (deduped, ordered); refuse off-list values."""
    if v is None:
        return []
    if isinstance(v, str):
        v = [p for p in re.split(r"[,\n;]", v)]
    out, seen = [], set()
    for item in v:
        s = str(item).strip().lower()
        if not s or s in seen:
            continue
        if s not in allowed:
            raise ValueError(
                f"{label} must be one of {', '.join(allowed)} (got {item!r})")
        seen.add(s)
        out.append(s)
    return out


class CodingTestCase(BaseModel):
    """One coding test case; `input`/`expected` are Python source, as the browser runner expects."""

    name: str = Field(default="", max_length=120)
    input: str = Field(default="", max_length=4000)
    expected: str = Field(default="", max_length=4000)

    @field_validator("name", "input", "expected", mode="before")
    @classmethod
    def _strip(cls, v: Any) -> Any:
        """Trim surrounding whitespace from text fields before validation."""
        return v.strip() if isinstance(v, str) else v


class CodingBlock(BaseModel):
    """A coding question's material (starter code, tests, solution); same fields as the built-in library."""

    # Reserved for multi-language support; the browser runner is Pyodide today,
    # so anything other than python has nowhere to execute. Stored (not dropped)
    # so a future JS/TS runner needs no migration of existing pools.
    language: str = "python"
    # The library's human-readable name, separate from the problem statement —
    # it is what the picker lists and what the candidate sees as the tab label.
    title: str = Field(default="", max_length=160)
    starter_code: str = Field(default="", max_length=8000)
    function_name: str = Field(default="", max_length=120)
    test_cases: list[CodingTestCase] = Field(default_factory=list)
    solution: str = Field(default="", max_length=8000)
    hints: list[str] = Field(default_factory=list)
    estimated_time_s: int = 0
    # A LIST, like the library's `topic:` — a question is genuinely about more
    # than one thing ([dict, string]), and the picker's topic filter matches on
    # membership. The generic pool's single `topic` slug cannot express this.
    topics: list[str] = Field(default_factory=list)
    role_fit: list[str] = Field(default_factory=list)

    @field_validator("starter_code", "function_name", "solution", "title",
                     mode="before")
    @classmethod
    def _strip(cls, v: Any) -> Any:
        """Trim surrounding whitespace from text fields before validation."""
        return v.strip() if isinstance(v, str) else v

    @field_validator("language", mode="before")
    @classmethod
    def _lang(cls, v: Any) -> str:
        """Allow only languages the browser runner can execute (python today)."""
        s = str(v or "python").strip().lower()
        if s not in CODING_LANGUAGES:
            raise ValueError(
                f"language must be one of {', '.join(CODING_LANGUAGES)} (got {v!r})"
            )
        return s

    @field_validator("topics", mode="before")
    @classmethod
    def _topics(cls, v: Any) -> list[str]:
        """Check coding topics against CODING_TOPICS, since the picker filters on them."""
        return _vocab_list(v, CODING_TOPICS, "topic")

    @field_validator("role_fit", mode="before")
    @classmethod
    def _roles(cls, v: Any) -> list[str]:
        """Check role_fit against CODING_ROLES."""
        return _vocab_list(v, CODING_ROLES, "role_fit")

    @field_validator("hints", mode="before")
    @classmethod
    def _hints(cls, v: Any) -> list[str]:
        """Accept hints as a list or newline text; drop blanks and cap each at 500 chars."""
        if v is None:
            return []
        if isinstance(v, str):
            v = v.split("\n")
        return [str(h).strip()[:500] for h in v if str(h).strip()]

    @field_validator("estimated_time_s", mode="before")
    @classmethod
    def _secs(cls, v: Any) -> int:
        """Coerce the time budget to whole seconds between 0 and 2 hours (bad input -> 0)."""
        try:
            n = int(v or 0)
        except (TypeError, ValueError):
            return 0
        return max(0, min(n, 7200))

    def missing_requirements(self) -> list[str]:
        """What a coding question still lacks to be runnable; shared with the phase builder."""
        problems: list[str] = []
        if not self.starter_code.strip():
            problems.append("starter code")
        if not self.function_name.strip():
            problems.append("a function name")
        elif not _FUNC_NAME_RE.match(self.function_name):
            problems.append("a valid function name (letters, digits, underscore)")
        real = [t for t in self.test_cases if t.input.strip() or t.expected.strip()]
        if not real:
            problems.append("at least one test case")
        else:
            for i, t in enumerate(real, start=1):
                if not t.expected.strip():
                    problems.append(f"an expected value for test case {i}")
        return problems


class ScenarioBlock(BaseModel):
    """A scenario question's media + follow-up cap; reuses the cadence's `ScenarioMedia` unchanged."""

    media: Optional[ScenarioMedia] = None
    max_followups: int = Field(default=2, ge=0, le=5)

    def missing_requirements(self) -> list[str]:
        """What a scenario question still lacks (its media file), so it can't fail later in a cadence."""
        if self.media is None:
            return ["a media file (image, video, or audio)"]
        return []


class PoolQuestion(BaseModel):
    """One pool question; `coverage_tags` are what the verifier checks the answer against."""

    id: str = Field(default="", max_length=64)
    # What KIND of question this is — per question, not per pool, so one pool can
    # hold a spoken question, then a translation, then a comprehension task.
    # Defaults to "spoken", which is what every pool held before kinds existed.
    kind: str = SPOKEN_KIND
    # NOT required up front: a type whose prompt is hidden (translation) never
    # has one written by hand — it is synthesised from the question's own
    # language pair in QuestionPool._finalise, exactly as the cadence builder
    # does, so the two can never disagree.
    text: str = Field(default="", max_length=2000)
    topic: str = Field(default="", max_length=64)
    difficulty: str = "medium"
    coverage_tags: list[str] = Field(default_factory=list)
    # Only for a WRITTEN pool: the limits + the material the candidate works
    # from (source passage, audio clip, image, language pair). Reuses the very
    # same model the cadence stores, so a pooled question drops into a phase
    # with no conversion — and is validated by the same rules.
    written_response: Optional["WrittenQuestion"] = None
    # Only for a CODING question: the editor material (starter code, tests,
    # reference solution). Mutually exclusive with written_response — enforced
    # in QuestionPool._finalise, since a block foreign to the kind would be
    # silently ignored at apply time.
    coding: Optional[CodingBlock] = None
    # Only for a SCENARIO question: the media reference + follow-up cap.
    # Mutually exclusive with written_response/coding — same enforcement.
    scenario: Optional[ScenarioBlock] = None

    @model_validator(mode="before")
    @classmethod
    def _accept_library_shape(cls, data: Any) -> Any:
        """Accept a coding question in library.yaml's flat layout by moving fields under `coding`."""
        if not isinstance(data, dict):
            return data
        if str(data.get("kind") or "").strip().lower() != CODING_KIND:
            return data
        data = dict(data)
        block = dict(data.get("coding") or {})
        # `prompt` is the library's name for what a pool calls `text`.
        if not data.get("text") and data.get("prompt"):
            data["text"] = data.pop("prompt")
        else:
            data.pop("prompt", None)
        for src, dst in (
            ("title", "title"), ("starter_code", "starter_code"),
            ("function_name", "function_name"), ("test_cases", "test_cases"),
            ("solution", "solution"), ("hints", "hints"),
            ("estimated_time_s", "estimated_time_s"), ("language", "language"),
            # singular in the library, plural on the block (it is a list).
            ("topic", "topics"), ("role_fit", "role_fit"),
        ):
            if src not in data:
                continue
            val = data[src]
            # `topic` is a LIST in the library but a single slug on a generic
            # pool question — only lift the list form, so a spoken-style
            # `topic: algo` string still lands on the envelope.
            if src == "topic" and not isinstance(val, list):
                continue
            data.pop(src)
            if dst not in block or block[dst] in (None, "", [], 0):
                block[dst] = val
        if block:
            data["coding"] = block
        return data

    @field_validator("text", "topic", mode="before")
    @classmethod
    def _strip(cls, v: Any) -> Any:
        """Trim surrounding whitespace from text fields before validation."""
        return v.strip() if isinstance(v, str) else v

    @field_validator("kind", mode="before")
    @classmethod
    def _kind(cls, v: Any) -> str:
        """Normalise a question's kind (default spoken) and refuse unknown kinds."""
        s = str(v or SPOKEN_KIND).strip().lower()
        allowed = pool_kind_ids()
        if s not in allowed:
            raise ValueError(f"kind must be one of {', '.join(allowed)} (got {v!r})")
        return s

    @field_validator("difficulty", mode="before")
    @classmethod
    def _difficulty(cls, v: Any) -> str:
        """Normalise difficulty to easy/medium/hard (default medium) and refuse anything else."""
        s = str(v or "medium").strip().lower()
        if s not in DIFFICULTIES:
            raise ValueError(
                f"difficulty must be one of {', '.join(DIFFICULTIES)} (got {v!r})"
            )
        return s

    @field_validator("topic", mode="after")
    @classmethod
    def _topic_slug(cls, v: str) -> str:
        """Slug the topic so the customizer's topic filter matches it consistently."""
        return _slug(v, fallback="") if v else ""

    @field_validator("coverage_tags", mode="before")
    @classmethod
    def _tags(cls, v: Any) -> list[str]:
        """Accept coverage tags as a list or pasted text; dedupe case-insensitively, cap at 200 chars."""
        if v is None:
            return []
        if isinstance(v, str):                       # tolerate a pasted list
            v = [p for p in re.split(r"[\n;]|,(?![^(]*\))", v)]
        out, seen = [], set()
        for t in v:
            s = str(t).strip()
            if s and s.lower() not in seen:
                seen.add(s.lower())
                out.append(s[:200])
        return out


class QuestionPool(BaseModel):
    """A whole pool: name, description and questions (built-in shape) plus id/team/author metadata."""

    pool_id: str = ""
    pool_name: str = Field(min_length=1, max_length=120)
    description: str = Field(default="", max_length=2000)
    # What kind of question this pool holds. Defaults to "spoken" so every pool
    # authored (or shipped) before kinds existed keeps working untouched.
    pool_kind: str = SPOKEN_KIND
    questions: list[PoolQuestion] = Field(default_factory=list)
    updated_at: str = ""

    # ── ownership (maker–checker) ────────────────────────────────────────
    # Stored as portable values (team KEY, people by EMAIL). No team means `*`.
    team: str = ""
    created_by: str = ""
    updated_by: str = ""

    @field_validator("pool_name", "description", mode="before")
    @classmethod
    def _strip(cls, v: Any) -> Any:
        """Trim surrounding whitespace from text fields before validation."""
        return v.strip() if isinstance(v, str) else v

    @field_validator("pool_kind", mode="before")
    @classmethod
    def _kind(cls, v: Any) -> str:
        """Normalise the pool's default kind (legacy, default spoken) and refuse unknown kinds."""
        s = str(v or SPOKEN_KIND).strip().lower()
        allowed = pool_kind_ids()
        if s not in allowed:
            raise ValueError(
                f"pool_kind must be one of {', '.join(allowed)} (got {v!r})"
            )
        return s

    @model_validator(mode="after")
    def _finalise(self) -> "QuestionPool":
        """Validate every question for its kind, fill derived fields and assign unique ids."""
        if not self.questions:
            raise ValueError("a pool needs at least one question")

        # A WRITTEN pool's questions must be answerable, and the check is the
        # SAME one the cadence runs — WrittenResponse.resolved_for(...)
        # .missing_requirements(). Reusing it (rather than re-listing fields
        # here) is what stops a pooled question passing validation now and
        # failing later when it is applied to a phase, and is why a future
        # question type needs no edit in this file.
        for i, q in enumerate(self.questions, start=1):
            # A pool authored before per-question kinds carries one kind at pool
            # level; inherit it so those files keep validating unchanged.
            if q.kind == SPOKEN_KIND and is_written_kind(self.pool_kind):
                q.kind = self.pool_kind
            if is_coding_kind(q.kind):
                # A coding question is validated by its OWN block. The check is
                # the same one the phase builder runs, so a question that saves
                # here can always be applied to a cadence.
                q.written_response = None
                q.scenario = None
                if q.coding is None:
                    raise ValueError(
                        f"Question {i}: a coding question needs its starter code, "
                        f"function name and test cases"
                    )
                problems = q.coding.missing_requirements()
                if problems:
                    raise ValueError(
                        f"Question {i}: coding question needs {', '.join(problems)}"
                    )
                # Drop rows the admin started and abandoned — an editing
                # artefact, not data (mirrors the blank answer-point rows).
                q.coding.test_cases = [
                    t for t in q.coding.test_cases
                    if t.input.strip() or t.expected.strip()
                ]
                # ── keep the ENVELOPE consistent with the library-shaped block ──
                # A coding question is authored in the library's own template;
                # these generic pool fields are derived from it rather than typed
                # twice, so the two can never disagree.
                if not q.coding.title:
                    # Fall back to the first line of the problem statement, the
                    # same way a reader would name it.
                    q.coding.title = (q.text.strip().split("\n")[0] or q.id)[:160]
                if not q.coding.estimated_time_s:
                    q.coding.estimated_time_s = _TIME_BY_DIFFICULTY.get(
                        q.difficulty, 600)
                # `topic` (singular) drives the pool's coverage matrix; the real
                # list lives on the block. Mirror the first one so a coding pool
                # still shows up in the summary.
                q.topic = q.coding.topics[0] if q.coding.topics else ""
                # Answer points steer the spoken verifier — a coding answer is
                # graded by its TEST CASES, so carrying them would be dead data
                # the authoring form doesn't even show.
                q.coverage_tags = []
                continue
            if is_scenario_kind(q.kind):
                # A scenario question is validated by its OWN block (just the
                # media + follow-up cap — question text/coverage_tags are the
                # envelope fields every kind already has).
                q.written_response = None
                q.coding = None
                if q.scenario is None:
                    raise ValueError(
                        f"Question {i}: a scenario question needs its media file"
                    )
                problems = q.scenario.missing_requirements()
                if problems:
                    raise ValueError(
                        f"Question {i}: scenario question needs {', '.join(problems)}"
                    )
                continue
            # Not coding or scenario → a stray coding block would be silently ignored.
            q.coding = None
            q.scenario = None
            if not is_written_kind(q.kind):
                # A spoken question carries no written material; a stray block
                # would be silently ignored at apply time.
                q.written_response = None
                continue
            try:
                resolved = WrittenResponse(question_type=q.kind).resolved_for(
                    q.written_response)
            except Exception as e:          # a field foreign to this kind
                raise ValueError(f"Question {i}: {e}") from e
            problems = resolved.missing_requirements()
            if problems:
                raise ValueError(
                    f"Question {i}: {qt.spec_for(q.kind).label} needs "
                    f"{', '.join(problems)}"
                )
            spec = qt.spec_for(q.kind)
            # Synthesise the instruction when the type hides it (or leaves it
            # optional and the admin left it blank). Deterministic, never
            # LLM-authored — same helper the cadence builder uses.
            if spec.prompt_hidden or not q.text:
                synthesised = qt.default_prompt(
                    q.kind, resolved.source_language or "",
                    resolved.target_language or "")
                if spec.prompt_hidden or synthesised:
                    q.text = synthesised or q.text
        for i, q in enumerate(self.questions, start=1):
            if not q.text.strip():
                label = qt.spec_for(q.kind).label if is_written_kind(q.kind) else "Question"
                raise ValueError(f"Question {i}: {label} needs its question text")

        # Ids are derived from the question text and uniquified HERE rather than
        # trusted from the client: they key the pool at runtime, and a duplicate
        # would make the tracker treat two questions as one.
        used: set[str] = set()
        for i, q in enumerate(self.questions, start=1):
            # A coding id is slugged from the TITLE, so it reads like the
            # library's own keys (running_sum, two_sum) instead of a slug of the
            # entire problem statement.
            seed = q.id.strip()
            if not seed and is_coding_kind(q.kind) and q.coding is not None:
                seed = q.coding.title
            base = seed or _slug(q.text, fallback=f"q{i}")
            base = _slug(base, fallback=f"q{i}")
            cand, n = base, 2
            while cand in used:
                cand = f"{base}_{n}"
                n += 1
            used.add(cand)
            q.id = cand
        return self

    # ── serialisation ────────────────────────────────────────────────────────
    def _coding_entry(self, q: "PoolQuestion") -> dict:
        """One coding question in library.yaml's flat shape, so an export can be pasted there verbatim."""
        c = q.coding
        assert c is not None
        entry = {
            "id": q.id,
            "kind": CODING_KIND,          # the pool needs it; the library ignores it
            "title": c.title,
            "prompt": q.text,
            "starter_code": c.starter_code,
            "function_name": c.function_name,
            "test_cases": [
                {"name": t.name, "input": t.input, "expected": t.expected}
                for t in c.test_cases
            ],
            "difficulty": q.difficulty,
            "estimated_time_s": c.estimated_time_s,
        }
        if c.solution:
            entry["solution"] = c.solution
        if c.hints:
            entry["hints"] = list(c.hints)
        if c.topics:
            entry["topic"] = list(c.topics)      # `topic`, matching the library
        if c.role_fit:
            entry["role_fit"] = list(c.role_fit)
        if c.language and c.language != "python":
            entry["language"] = c.language
        return entry

    def to_yaml(self) -> str:
        """The pool as YAML in the built-in shape plus id/time/ownership, for Blob storage and export."""
        return yaml.safe_dump(
            {
                "pool_name": self.pool_name,
                "description": self.description,
                "pool_id": self.pool_id,
                "pool_kind": self.pool_kind,
                "updated_at": self.updated_at,
                # Omitted when empty so a spoken pool's export stays
                # byte-identical to the built-in file shape and can still be
                # committed to questions_pool/ verbatim.
                **({"team": self.team} if self.team else {}),
                **({"created_by": self.created_by} if self.created_by else {}),
                **({"updated_by": self.updated_by} if self.updated_by else {}),
                "questions": [
                    self._coding_entry(q) if is_coding_kind(q.kind) else
                    {
                        "id": q.id,
                        # Omitted ONLY for a spoken question, so a spoken pool's
                        # export stays byte-identical to the built-in file shape
                        # and can still be committed to questions_pool/ verbatim.
                        # Every other kind MUST round-trip its own id — writing
                        # the condition as `is_written_kind` silently reloaded
                        # coding questions as spoken, which then nulled their block.
                        **({"kind": q.kind} if q.kind != SPOKEN_KIND else {}),
                        "text": q.text,
                        "topic": q.topic,
                        "difficulty": q.difficulty,
                        "coverage_tags": list(q.coverage_tags),
                        # Written kinds only — omitted entirely for a spoken
                        # pool so the file stays the shape the built-ins use.
                        **({"written_response": q.written_response.model_dump(
                            exclude_none=True)} if q.written_response else {}),
                        **({"coding": q.coding.model_dump(exclude_none=True)}
                           if q.coding else {}),
                        **({"scenario": q.scenario.model_dump(exclude_none=True)}
                           if q.scenario else {}),
                    }
                    for q in self.questions
                ],
            },
            sort_keys=False,
            allow_unicode=True,
        )

    def summary(self, *, source: str = POOL_SOURCE_CUSTOM) -> dict:
        """List-row metadata (counts by topic and difficulty, team, authors, editable) for pickers and lists."""
        counts: dict[str, dict[str, int]] = {}
        for q in self.questions:
            topic = q.topic or "(none)"
            counts.setdefault(topic, {d: 0 for d in DIFFICULTIES})
            counts[topic][q.difficulty] += 1
        return {
            "pool_id": self.pool_id,
            "pool_file": self.pool_id,          # what /customize is handed
            "pool_name": self.pool_name,
            "pool_kind": self.pool_kind,          # legacy: the pool's default
            # What this pool ACTUALLY holds — the Add-Phase picker offers a pool
            # when it has at least one question of the phase's type.
            "kinds": sorted({q.kind for q in self.questions}),
            "description": self.description,
            "question_count": len(self.questions),
            "topics": sorted({q.topic for q in self.questions if q.topic}),
            "counts": counts,
            "updated_at": self.updated_at,
            "source": source,                   # one of app.constants.POOL_SOURCE_*
            "editable": source != POOL_SOURCE_BUILTIN,   # built-ins live in the image
            "team": self.team or GLOBAL_TEAM,
            "created_by": self.created_by,
            "updated_by": self.updated_by,
        }

    def author_emails(self) -> list[str]:
        """Emails of the creator and last editor; frozen at submit so they cannot approve it."""
        return sorted({e for e in (self.created_by, self.updated_by) if e})


# ── blob paths ───────────────────────────────────────────────────────────────
def is_valid_pool_id(pool_id: str) -> bool:
    """True if the id is safe to use in a blob path (lowercase, digits, `_`/`-`, no slashes)."""
    return bool(_POOL_ID_RE.match(pool_id or ""))


def _path(prefix: str, pool_id: str) -> str:
    """Blob path `<prefix><id>.yaml`; raises on a bad id so nothing outside the prefix is reachable."""
    if not is_valid_pool_id(pool_id):
        raise ValueError(f"invalid pool id: {pool_id!r}")
    return f"{prefix}{pool_id}.yaml"


def _new_pool_id(name: str) -> str:
    """A readable new id (name slug + random suffix) so two pools with one name never collide."""
    base = _slug(name, fallback="pool")[:40].strip("_") or "pool"
    return f"{base}-{uuid.uuid4().hex[:6]}"


# ── uploaded material (audio clips / images a written question needs) ────────
# Flat, not per pool: a new pool has no id yet. A random name prefix avoids
# collisions. Applying a pool copies the file into the interview.
_ASSET_PREFIX = "question_pool_assets/"


def _safe_asset_name(filename: str) -> str:
    """Sanitise an uploaded filename so it cannot escape the asset folder (path traversal guard)."""
    base = re.sub(r"[^A-Za-z0-9._-]+", "_", (filename or "").strip()).lstrip(".")
    base = base[-120:] or "asset"
    if "/" in base or "\\" in base or ".." in base:
        raise ValueError("unsafe file name")
    return base


def store_asset(kind: str, filename: str, data: bytes) -> str:
    """Check an upload against the cadence uploader's rules, store it, and return its stored name."""
    from app import blob_store

    safe = _safe_asset_name(filename)
    problem = qt.check_asset(kind, safe, len(data))
    if problem:
        raise ValueError(problem)
    name = f"{uuid.uuid4().hex[:8]}_{safe}"
    if not blob_store.upload_fileobj(io.BytesIO(data), _ASSET_PREFIX + name):
        raise RuntimeError("could not store the file")
    return name


def load_asset(name: str) -> Optional[bytes]:
    """Read an uploaded pool asset's bytes, or None if the name is unsafe or missing."""
    from app import blob_store

    try:
        safe = _safe_asset_name(name)
    except ValueError:
        return None
    return blob_store.download_bytes(_ASSET_PREFIX + safe)


def copy_asset_to_session(name: str, token: str) -> bool:
    """Copy a pool asset into the interview's folder so later pool edits cannot break it."""
    from app import blob_store

    data = load_asset(name)
    if data is None:
        return False
    try:
        safe = _safe_asset_name(name)
    except ValueError:
        return False
    return blob_store.upload_fileobj(io.BytesIO(data), f"{token}/phase_assets/{safe}")


# ── CRUD ─────────────────────────────────────────────────────────────────────
# A draft and its published version share one pool_id under two prefixes.
# Cadence reads published only (load_pool / list_pools / pool_questions);
# anything that wants the work in progress asks for the draft explicitly.


def _save(prefix: str, pool: QuestionPool, pool_id: Optional[str], what: str) -> QuestionPool:
    """Write a pool as YAML under `prefix` (assigning an id and timestamp); raises if storage fails."""
    from app import blob_store

    pool.pool_id = pool_id or pool.pool_id or _new_pool_id(pool.pool_name)
    if not is_valid_pool_id(pool.pool_id):
        raise ValueError(f"invalid pool id: {pool.pool_id!r}")
    pool.updated_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    raw = pool.to_yaml().encode("utf-8")
    if not blob_store.upload_fileobj(io.BytesIO(raw), _path(prefix, pool.pool_id)):
        raise RuntimeError(f"could not write the {what} to storage")
    return pool


def _load(prefix: str, pool_id: str, label: str) -> Optional[QuestionPool]:
    """Read and validate one pool from `prefix`; None if missing or unreadable (with a warning)."""
    from app import blob_store

    if not is_valid_pool_id(pool_id):
        return None
    raw = blob_store.download_bytes(_path(prefix, pool_id))
    if not raw:
        return None
    try:
        return QuestionPool.model_validate(yaml.safe_load(raw.decode("utf-8")) or {})
    except Exception as e:
        logger.warning("[pools] %s%s is unreadable: %s", label, pool_id, e)
        return None


def _delete(prefix: str, pool_id: str) -> bool:
    """Delete one pool's blob under `prefix`; False for a bad id or a failed delete."""
    from app import blob_store

    if not is_valid_pool_id(pool_id):
        return False
    return blob_store.delete_blob(_path(prefix, pool_id))


def _list(prefix: str, load, source: str, what: str) -> list[dict]:
    """Sorted summaries of every pool under `prefix`; one unreadable file is skipped, not fatal."""
    from app import blob_store

    out: list[dict] = []
    for name in blob_store.list_blobs(prefix):
        if not name.endswith(".yaml"):
            continue
        pool = load(name[len(prefix):-len(".yaml")])
        if pool is None:
            logger.warning("[pools] skipping unreadable %s blob %r", what, name)
            continue
        out.append(pool.summary(source=source))
    return sorted(out, key=lambda p: (p["pool_name"] or "").lower())


def save_pool(pool: QuestionPool, *, pool_id: Optional[str] = None) -> QuestionPool:
    """Write the PUBLISHED pool (what interviews use); only publishing should call this."""
    return _save(BLOB_PREFIX, pool, pool_id, "pool")


def load_pool(pool_id: str) -> Optional[QuestionPool]:
    """Read the PUBLISHED pool only; cadence uses this, so drafts can never reach an interview."""
    return _load(BLOB_PREFIX, pool_id, "")


def delete_pool(pool_id: str) -> bool:
    """Delete the published pool."""
    return _delete(BLOB_PREFIX, pool_id)


def list_pools() -> list[dict]:
    """Summaries of all published pools."""
    return _list(BLOB_PREFIX, load_pool, POOL_SOURCE_CUSTOM, "pool")


def save_draft(pool: QuestionPool, *, pool_id: Optional[str] = None) -> QuestionPool:
    """Write the work-in-progress draft; never touches the published pool."""
    return _save(DRAFT_PREFIX, pool, pool_id, "draft")


def load_draft(pool_id: str) -> Optional[QuestionPool]:
    """Read the draft, if one exists (for authors and checkers, never for interviews)."""
    return _load(DRAFT_PREFIX, pool_id, "draft ")


def has_draft(pool_id: str) -> bool:
    """True if the pool has unpublished work in progress."""
    return load_draft(pool_id) is not None


def delete_draft(pool_id: str) -> bool:
    """Delete the draft (after publishing, or when the author discards it)."""
    return _delete(DRAFT_PREFIX, pool_id)


def list_drafts() -> list[dict]:
    """Summaries of all drafts; the caller filters them by who may see each team's drafts."""
    return _list(DRAFT_PREFIX, load_draft, POOL_SOURCE_DRAFT, "draft")


def load_editable(pool_id: str) -> Optional[QuestionPool]:
    """What an author or checker works on: the draft if there is one, else the published pool."""
    return load_draft(pool_id) or load_pool(pool_id)


# The stage_* publishers run inside the approval transaction, so they raise on
# failure. They only write the live pool; the draft is changed by the cleanup
# they return, run after the ledger commits, so a failed commit can be retried.


def stage_draft(pool_id: str) -> Callable[[], None]:
    """Whole-pool approval: copy the draft over the live pool; returns the draft deletion."""
    draft = load_draft(pool_id)
    if draft is None:
        raise ValueError(f"no draft to publish for {pool_id!r}")
    save_pool(draft, pool_id=pool_id)
    return lambda: delete_draft(pool_id)


def stage_approved(pool_id: str, approved_ids: set[str]) -> Callable[[], None]:
    """Per-question approval: publish the approved questions; returns the rewrite of the draft to the rejected ones."""
    draft = load_draft(pool_id)
    if draft is None:
        raise ValueError(f"no draft to publish for {pool_id!r}")

    approved = [q for q in draft.questions if q.id in approved_ids]
    rejected = [q for q in draft.questions if q.id not in approved_ids]
    if not approved:
        raise ValueError("nothing was approved, so there is nothing to publish")

    # Merge by id even when everything is approved: after a partial review the
    # draft holds only the rejected questions, so copying it over the live pool
    # would drop every question approved in the earlier cycle.
    live = load_pool(pool_id)
    merged: dict[str, PoolQuestion] = {q.id: q for q in (live.questions if live else [])}
    for q in approved:
        merged[q.id] = q

    def _like_draft(questions: list[PoolQuestion]) -> QuestionPool:
        """A pool with the draft's name/description/team (what the checker reviewed) and these questions."""
        return QuestionPool(
            pool_id=pool_id,
            pool_name=draft.pool_name,
            description=draft.description,
            pool_kind=draft.pool_kind,
            questions=questions,
            team=draft.team,
            created_by=draft.created_by,
        )

    save_pool(_like_draft(list(merged.values())), pool_id=pool_id)
    if not rejected:
        return lambda: delete_draft(pool_id)
    return lambda: save_draft(_like_draft(rejected), pool_id=pool_id)


def publish_draft(pool_id: str) -> QuestionPool:
    """`stage_draft` plus its cleanup, for callers outside an approval transaction."""
    stage_draft(pool_id)()
    return load_pool(pool_id)


def publish_approved(pool_id: str, approved_ids: set[str]) -> QuestionPool:
    """`stage_approved` plus its cleanup, for callers outside an approval transaction."""
    stage_approved(pool_id, approved_ids)()
    return load_pool(pool_id)


def pool_questions(pool_id: str) -> Optional[list[dict]]:
    """The published pool's questions as plain dicts for the cadence customizer, or None."""
    pool = load_pool(pool_id)
    if pool is None:
        return None
    return [
        {
            "id": q.id, "kind": q.kind, "text": q.text, "topic": q.topic,
            "difficulty": q.difficulty, "coverage_tags": list(q.coverage_tags),
            **({"written_response": q.written_response.model_dump(exclude_none=True)}
               if q.written_response else {}),
            **({"coding": q.coding.model_dump(exclude_none=True)} if q.coding else {}),
            **({"scenario": q.scenario.model_dump(exclude_none=True)} if q.scenario else {}),
        }
        for q in pool.questions
    ]
