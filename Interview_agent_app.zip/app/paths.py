"""Single source of truth for filesystem paths the admin app uses."""
from __future__ import annotations

import os
from pathlib import Path

REPO_ROOT: Path = Path(__file__).resolve().parent.parent

# Cloud deploys override SESSIONS_DIR via env var to point at a persistent
# volume (e.g. /home/data/sessions on Azure App Service, which survives
# container restarts). Default keeps the local-dev location at
# <repo>/sessions/ so existing flows are unchanged.
SESSIONS_DIR: Path = Path(os.environ.get("SESSIONS_DIR", str(REPO_ROOT / "sessions")))
DB_PATH: Path = SESSIONS_DIR / "sessions.db"


def session_dir(token: str) -> Path:
    return SESSIONS_DIR / token


def ensure_dirs() -> None:
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
