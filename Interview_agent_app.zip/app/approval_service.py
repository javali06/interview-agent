"""Maker-checker for question pools: the workflow rules, as functions over the DB.

- State is derived from the append-only `pool_approvals` ledger, never stored.
- The approval chain and the authors are frozen on the `submitted` row, so an
  edit to either mid-cycle cannot change the rules for that cycle.
- Publishing is a caller-supplied `on_publish` callback, run inside the
  transaction: if storage fails, no `published` row is written. It may return
  a cleanup callable, run only after the transaction commits.

Design notes: docs/question-pool-maker-checker.md §6.
"""
from __future__ import annotations

import logging
import uuid
from typing import Callable, Iterable, Optional

from sqlalchemy import select
from sqlalchemy import text as sql_text

from app.constants import (
    ACTION_APPROVED,
    ACTION_PUBLISHED,
    ACTION_RETURNED,
    ACTION_SUBMITTED,
    ACTION_WITHDRAWN,
    GLOBAL_TEAM,
    POOL_DRAFT,
    POOL_PENDING,
    POOL_PUBLISHED,
    QUESTION_APPROVED,
    QUESTION_REJECTED,
)
from db.engine import session_scope
from db.models import (
    AppApprovalStep,
    AppRole,
    AppTeam,
    AppUser,
    AppUserRole,
    AuditLog,
    PoolApproval,
    PoolQuestionReview,
)

logger = logging.getLogger(__name__)


class ApprovalError(Exception):
    """A workflow refusal carrying a readable message, a stable `code` and an HTTP `status`."""

    def __init__(self, message: str, code: str = "refused", status: int = 400):
        """Store the message (as args[0]), the machine-readable code and the HTTP status."""
        super().__init__(message)
        self.code = code
        self.status = status


def _not_pending() -> ApprovalError:
    """The shared 409 for acting on a pool that is not waiting for approval."""
    return ApprovalError("This pool is not waiting for approval.", "not_pending", 409)


def _no_step() -> ApprovalError:
    """The shared 409 for a pending pool whose chain has no step left to sign."""
    return ApprovalError(
        "This pool has no approval step left to sign — an administrator "
        "should look at its chain.",
        "no_step",
        409,
    )


def _lock(s, pool_id: str) -> None:
    """Serialise transitions on one pool, so two checkers acting at once cannot both sign or publish."""
    # SQLite already serialises writers; Postgres needs an explicit lock.
    if s.get_bind().dialect.name == "postgresql":
        s.execute(sql_text("SELECT pg_advisory_xact_lock(hashtext(:k))"), {"k": f"pool:{pool_id}"})


# ── lookups ──────────────────────────────────────────────────────────────


def _team(s, team_key: str) -> AppTeam:
    """Load a team by key, or refuse with `unknown_team` so a typo cannot create a cycle."""
    team = s.execute(select(AppTeam).where(AppTeam.key == team_key)).scalar_one_or_none()
    if team is None:
        raise ApprovalError(f"No such team: {team_key}", "unknown_team", 400)
    return team


def _team_key(s, team_id: Optional[int]) -> Optional[str]:
    """Turn a stored team id back into its key for the API, or None if missing."""
    if not team_id:
        return None
    team = s.get(AppTeam, team_id)
    return team.key if team else None


def _email(s, user_id: Optional[int]) -> str:
    """A user's email for display and author checks, or "" if unknown."""
    if not user_id:
        return ""
    user = s.get(AppUser, user_id)
    return user.email if user else ""


def _chain_rows(s, team_key: str) -> list[dict]:
    """The team's active approval steps in order, falling back to the `*` chain if it has none."""
    team = s.execute(select(AppTeam).where(AppTeam.key == team_key)).scalar_one_or_none()
    rows = []
    if team is not None:
        rows = s.execute(
            select(AppApprovalStep, AppRole.key)
            .join(AppRole, AppRole.id == AppApprovalStep.approver_role_id)
            .where(
                AppApprovalStep.team_id == team.id,
                AppApprovalStep.is_active.is_(True),
            )
            .order_by(AppApprovalStep.step_no)
        ).all()
    if not rows and team_key != GLOBAL_TEAM:
        return _chain_rows(s, GLOBAL_TEAM)
    return [{"step_no": st.step_no, "role": role_key, "name": st.name} for st, role_key in rows]


def _ledger(s, pool_id: str) -> list[PoolApproval]:
    """Every ledger row for one pool, oldest first: the input every state is derived from."""
    return list(
        s.execute(
            select(PoolApproval)
            .where(PoolApproval.pool_id == pool_id)
            .order_by(PoolApproval.created_at, PoolApproval.id)
        ).scalars()
    )


def _opened(rows: list[PoolApproval], cycle_id: Optional[str]) -> Optional[PoolApproval]:
    """The `submitted` row that opened this cycle; it holds the frozen chain, authors and team."""
    return next(
        (r for r in rows if r.cycle_id == cycle_id and r.action == ACTION_SUBMITTED), None
    )


def _record(s, pool_id: str, team_id: int, cycle_id: str, action: str, actor_id: int,
            step_no: Optional[int] = None, comment: str = "",
            chain_snapshot: Optional[dict] = None) -> None:
    """Append one transition row to the ledger (rows are never updated or deleted)."""
    s.add(
        PoolApproval(
            pool_id=pool_id,
            team_id=team_id,
            cycle_id=cycle_id,
            action=action,
            step_no=step_no,
            chain_snapshot=chain_snapshot,
            actor_user_id=actor_id,
            comment=comment or "",
        )
    )


def _audit(s, actor_id: int, action: str, pool_id: str, detail: dict) -> None:
    """Write an audit-log entry for a publish, so going live is traceable outside the ledger."""
    s.add(AuditLog(actor_user_id=actor_id, action=action, target_type="pool",
                   target_id=pool_id, detail=detail))


# ── deriving the state ───────────────────────────────────────────────────


def pool_status(pool_id: str) -> dict:
    """One pool's current state (state, cycle, team, steps, signatures, next step, last comment)."""
    with session_scope() as s:
        return _derive(s, _ledger(s, pool_id))


def pool_states(pool_ids: Iterable[str]) -> dict[str, dict]:
    """`pool_status` for many pools in one query, so the pool list does not cost a query per pool."""
    ids = [p for p in pool_ids if p]
    if not ids:
        return {}
    with session_scope() as s:
        by_pool = _ledgers_by_pool(s, ids)
        return {pid: _derive(s, by_pool.get(pid, [])) for pid in ids}


def _ledgers_by_pool(s, pool_ids: Optional[list[str]] = None) -> dict[str, list[PoolApproval]]:
    """Ledger rows grouped by pool in one query (all pools when `pool_ids` is None)."""
    query = select(PoolApproval).order_by(PoolApproval.created_at, PoolApproval.id)
    if pool_ids is not None:
        query = query.where(PoolApproval.pool_id.in_(pool_ids))
    by_pool: dict[str, list[PoolApproval]] = {}
    for r in s.execute(query).scalars():
        by_pool.setdefault(r.pool_id, []).append(r)
    return by_pool


def _blank(state: str = POOL_DRAFT) -> dict:
    """An empty status dict in the given state, so every status has the same keys."""
    return {
        "state": state,
        "cycle_id": None,
        "team": None,
        "steps": [],
        "signed": [],
        "next_step": None,
        "submitted_by": None,
        "last_comment": "",
    }


def _derive(s, rows: list[PoolApproval]) -> dict:
    """Work out a pool's status from its ledger rows; state is never stored, always derived."""
    if not rows:
        return _blank()

    submissions = [r for r in rows if r.action == ACTION_SUBMITTED]
    if not submissions:
        # Only ever force-published: no cycle, but live.
        if any(r.action == ACTION_PUBLISHED for r in rows):
            out = _blank(POOL_PUBLISHED)
            out["team"] = _team_key(s, rows[-1].team_id)
            return out
        return _blank()

    opened = submissions[-1]
    cycle = opened.cycle_id
    # A force-publish after the last cycle closed has a cycle of its own.
    later = [r for r in rows[rows.index(opened) + 1:]
             if r.action == ACTION_PUBLISHED and r.cycle_id != cycle]
    if later:
        out = _blank(POOL_PUBLISHED)
        out["team"] = _team_key(s, later[-1].team_id)
        return out

    in_cycle = [r for r in rows if r.cycle_id == cycle]
    steps = list((opened.chain_snapshot or {}).get("steps") or [])

    out = _blank()
    out.update(
        cycle_id=cycle,
        team=_team_key(s, opened.team_id),
        steps=steps,
        submitted_by=opened.actor_user_id,
    )

    # The LAST closing action decides: a partial review publishes, then returns.
    closing = [r for r in in_cycle
               if r.action in (ACTION_PUBLISHED, ACTION_RETURNED, ACTION_WITHDRAWN)]
    if closing and closing[-1].action == ACTION_PUBLISHED:
        out["state"] = POOL_PUBLISHED
        return out
    if closing:
        returns = [r for r in in_cycle if r.action == ACTION_RETURNED]
        out["state"] = POOL_DRAFT
        out["last_comment"] = returns[-1].comment if returns else ""
        out["cycle_id"] = None          # a closed cycle is not signable
        return out

    signed_rows = [r for r in in_cycle if r.action == ACTION_APPROVED]
    out["signed"] = [
        {
            "step_no": r.step_no,
            "by": r.actor_user_id,
            "by_email": _email(s, r.actor_user_id),
            "at": r.created_at.isoformat() if r.created_at else None,
        }
        for r in signed_rows
    ]
    signed_steps = {r.step_no for r in signed_rows}
    remaining = [st for st in steps if st["step_no"] not in signed_steps]

    # No step left only happens with an empty chain; keep it pending for a human.
    out["state"] = POOL_PENDING
    out["next_step"] = remaining[0] if remaining else None
    return out


# ── the transitions ──────────────────────────────────────────────────────


def _completes_chain(status: dict, step: dict) -> bool:
    """True if signing `step` leaves no step of the frozen chain unsigned."""
    signed = {sig["step_no"] for sig in status["signed"]} | {step["step_no"]}
    return all(st["step_no"] in signed for st in status["steps"])


def _publish(s, pool_id: str, team_id: int, cycle: str, actor_id: int, step_no: int,
             steps: int, on_publish: Optional[Callable[[], object]]) -> object:
    """Run the caller's publish and record it; returns whatever the callback returned (a cleanup, maybe)."""
    finish = on_publish() if on_publish is not None else None     # raising rolls back
    _record(s, pool_id, team_id, cycle, ACTION_PUBLISHED, actor_id, step_no=step_no)
    _audit(s, actor_id, "pool.published", pool_id, {"cycle_id": cycle, "steps": steps})
    return finish


def _after_commit(finish: object) -> None:
    """Run a publish callback's cleanup once the ledger has committed (e.g. deleting the draft)."""
    if callable(finish):
        finish()


def submit(
    pool_id: str,
    actor_id: int,
    team_key: str,
    author_emails: Iterable[str] = (),
    comment: str = "",
) -> dict:
    """Maker sends a draft for review: opens a cycle with the chain and authors frozen onto it."""
    with session_scope() as s:
        _lock(s, pool_id)
        if _derive(s, _ledger(s, pool_id))["state"] == POOL_PENDING:
            raise ApprovalError(
                "This pool is already waiting for approval.", "already_pending", 409
            )
        team = _team(s, team_key)
        steps = _chain_rows(s, team_key)
        if not steps:
            raise ApprovalError(
                "No approval steps are configured, so this pool cannot be "
                "submitted. An administrator sets them up per team.",
                "no_chain",
                409,
            )
        authors = sorted({(e or "").strip().lower() for e in author_emails if e})
        _record(s, pool_id, team.id, str(uuid.uuid4()), ACTION_SUBMITTED, actor_id,
                comment=comment, chain_snapshot={"steps": steps, "author_emails": authors})
    return pool_status(pool_id)


def _pending(s, pool_id: str) -> tuple[list[PoolApproval], dict, dict, PoolApproval]:
    """Lock the pool and load (rows, status, next step, opening row), refusing unless it is pending."""
    _lock(s, pool_id)
    rows = _ledger(s, pool_id)
    status = _derive(s, rows)
    if status["state"] != POOL_PENDING:
        raise _not_pending()
    step = status["next_step"]
    if step is None:
        raise _no_step()
    return rows, status, step, _opened(rows, status["cycle_id"])


def approve(
    pool_id: str,
    actor_id: int,
    comment: str = "",
    on_publish: Optional[Callable[[], object]] = None,
) -> dict:
    """Checker signs the next step; the last signature publishes, inside the same transaction."""
    finish = None
    with session_scope() as s:
        rows, status, step, opened = _pending(s, pool_id)
        cycle = status["cycle_id"]
        _refuse_unless_can_sign(s, actor_id, rows, status, opened)

        _record(s, pool_id, opened.team_id, cycle, ACTION_APPROVED, actor_id,
                step_no=step["step_no"], comment=comment)
        if _completes_chain(status, step):
            finish = _publish(s, pool_id, opened.team_id, cycle, actor_id, step["step_no"],
                              len(status["steps"]), on_publish)
    _after_commit(finish)
    return pool_status(pool_id)


def return_pool(pool_id: str, actor_id: int, comment: str) -> dict:
    """Checker sends the pool back with a required reason, closing the cycle (resubmit starts fresh)."""
    text = (comment or "").strip()
    if not text:
        raise ApprovalError(
            "Say why you are returning it — the author cannot act on a blank "
            "rejection.",
            "comment_required",
            400,
        )
    with session_scope() as s:
        _lock(s, pool_id)
        rows = _ledger(s, pool_id)
        status = _derive(s, rows)
        if status["state"] != POOL_PENDING:
            raise _not_pending()
        opened = _opened(rows, status["cycle_id"])
        if status["next_step"] is not None:
            _refuse_wrong_team(s, actor_id, status["next_step"]["role"], status["team"])
        _record(s, pool_id, opened.team_id, status["cycle_id"], ACTION_RETURNED, actor_id,
                comment=text)
    return pool_status(pool_id)


def review(
    pool_id: str,
    actor_id: int,
    verdicts: dict[str, str],
    comments: Optional[dict[str, str]] = None,
    on_publish: Optional[Callable[[set[str]], object]] = None,
) -> dict:
    """Checker's per-question verdicts, applied in one transaction after the same refusals approve() runs."""
    comments = comments or {}
    # An unrecognised value is not a decision. Skipping it would publish the
    # approved questions and treat the gap as a rejection, with no return row
    # and no required comment.
    invalid = [q for q, v in verdicts.items() if v not in (QUESTION_APPROVED, QUESTION_REJECTED)]
    if invalid:
        raise ApprovalError(
            "Each verdict must be approved or rejected — "
            f"{len(invalid)} is neither.",
            "invalid_verdict",
            400,
        )
    approved_ids = {q for q, v in verdicts.items() if v == QUESTION_APPROVED}
    rejected_ids = {q for q, v in verdicts.items() if v == QUESTION_REJECTED}
    if not approved_ids and not rejected_ids:
        raise ApprovalError(
            "No verdicts were given — approve or reject at least one question.",
            "no_verdicts",
            400,
        )
    unexplained = [q for q in rejected_ids if not (comments.get(q) or "").strip()]
    if unexplained:
        raise ApprovalError(
            "Say why each rejected question needs work — "
            f"{len(unexplained)} has no comment.",
            "comment_required",
            400,
        )

    summary = "; ".join(
        f"{q}: {(comments.get(q) or '').strip()}" for q in sorted(rejected_ids)
    )
    finish = None
    with session_scope() as s:
        rows, status, step, opened = _pending(s, pool_id)
        cycle = status["cycle_id"]
        # Refuse BEFORE anything is written: approving any question is signing.
        if approved_ids:
            _refuse_unless_can_sign(s, actor_id, rows, status, opened)
        else:
            _refuse_wrong_team(s, actor_id, step["role"], status["team"])

        for question_id, verdict in verdicts.items():
            if verdict in (QUESTION_APPROVED, QUESTION_REJECTED):
                s.add(PoolQuestionReview(
                    pool_id=pool_id,
                    cycle_id=cycle,
                    question_id=question_id,
                    verdict=verdict,
                    comment=(comments.get(question_id) or "").strip(),
                    actor_user_id=actor_id,
                ))

        published = False
        if approved_ids:
            note = (f"Approved all {len(approved_ids)} questions." if not rejected_ids
                    else f"Approved {len(approved_ids)} questions.")
            _record(s, pool_id, opened.team_id, cycle, ACTION_APPROVED, actor_id,
                    step_no=step["step_no"], comment=note)
            if _completes_chain(status, step):
                finish = _publish(
                    s, pool_id, opened.team_id, cycle, actor_id, step["step_no"],
                    len(status["steps"]),
                    (lambda: on_publish(approved_ids)) if on_publish else None,
                )
                published = True

        if rejected_ids:
            if not approved_ids:
                reason = f"No questions approved. {summary}"
            elif published:
                reason = (f"Published {len(approved_ids)} approved; "
                         f"{len(rejected_ids)} need work. {summary}")
            else:
                # An earlier step of a longer chain: nothing goes live yet.
                reason = (f"{len(rejected_ids)} need work, so nothing was published "
                         f"at this step. {summary}")
            _record(s, pool_id, opened.team_id, cycle, ACTION_RETURNED, actor_id,
                    comment=reason)
    _after_commit(finish)
    return pool_status(pool_id)


def question_reviews(pool_id: str, cycle_id: Optional[str] = None) -> dict[str, dict]:
    """Latest verdict per question for a cycle (open one, else the last reviewed) so authors see fixes."""
    if cycle_id is None:
        cycle_id = pool_status(pool_id).get("cycle_id") or ""
    with session_scope() as s:
        if not cycle_id:
            cycle_id = s.scalars(
                select(PoolQuestionReview.cycle_id)
                .where(PoolQuestionReview.pool_id == pool_id)
                .order_by(PoolQuestionReview.created_at.desc(), PoolQuestionReview.id.desc())
                .limit(1)
            ).first() or ""
        if not cycle_id:
            return {}
        rows = s.scalars(
            select(PoolQuestionReview)
            .where(
                PoolQuestionReview.pool_id == pool_id,
                PoolQuestionReview.cycle_id == cycle_id,
            )
            .order_by(PoolQuestionReview.created_at, PoolQuestionReview.id)
        ).all()
        # Later rows overwrite earlier ones: latest verdict wins.
        return {
            r.question_id: {
                "verdict": r.verdict,
                "comment": r.comment or "",
                "by": _email(s, r.actor_user_id),
            }
            for r in rows
        }


def withdraw(pool_id: str, actor_id: int) -> dict:
    """The submitter pulls their own pending pool back to draft (e.g. to edit it)."""
    with session_scope() as s:
        _lock(s, pool_id)
        rows = _ledger(s, pool_id)
        status = _derive(s, rows)
        if status["state"] != POOL_PENDING:
            raise ApprovalError("There is nothing to withdraw.", "not_pending", 409)
        if status["submitted_by"] != actor_id:
            raise ApprovalError(
                "Only the person who submitted this can withdraw it.",
                "not_submitter",
                403,
            )
        opened = _opened(rows, status["cycle_id"])
        _record(s, pool_id, opened.team_id, status["cycle_id"], ACTION_WITHDRAWN, actor_id)
    return pool_status(pool_id)


def force_publish(
    pool_id: str,
    actor_id: int,
    team_key: str,
    comment: str = "",
    on_publish: Optional[Callable[[], object]] = None,
) -> dict:
    """Break-glass publish that skips the chain; logged separately so it never looks like an approval."""
    with session_scope() as s:
        _lock(s, pool_id)
        team = _team(s, team_key)
        status = _derive(s, _ledger(s, pool_id))
        finish = on_publish() if on_publish is not None else None
        _record(s, pool_id, team.id, status["cycle_id"] or str(uuid.uuid4()),
                ACTION_PUBLISHED, actor_id, comment=comment)
        _audit(s, actor_id, "pool.force_published", pool_id,
               {"bypassed_chain": True, "comment": comment or ""})
    _after_commit(finish)
    return pool_status(pool_id)


# ── the refusals ─────────────────────────────────────────────────────────


def _refuse_unless_can_sign(s, actor_id: int, rows: list[PoolApproval], status: dict,
                            opened: PoolApproval) -> None:
    """Run every signing check in one place, so the queue and approve() can never disagree."""
    _refuse_self_approval(s, actor_id, opened)
    _refuse_wrong_team(s, actor_id, status["next_step"]["role"], status["team"])
    _refuse_signing_twice(actor_id, rows, status["cycle_id"])


def _refuse_self_approval(s, actor_id: int, opened: PoolApproval) -> None:
    """Refuse if the actor submitted or authored the pool: nobody approves their own work."""
    if opened.actor_user_id == actor_id:
        raise ApprovalError(
            "You submitted this pool, so you cannot approve it. It needs a "
            "second pair of eyes.",
            "self_approval",
            403,
        )
    authors = {e.lower() for e in ((opened.chain_snapshot or {}).get("author_emails") or [])}
    if authors:
        email = _email(s, actor_id).lower()
        if email and email in authors:
            raise ApprovalError(
                "You are named as an author of this pool, so you cannot approve "
                "it.",
                "self_approval",
                403,
            )


def _refuse_wrong_team(s, actor_id: int, required_role: str, team_key: Optional[str]) -> None:
    """Refuse unless the actor holds the step's role for this pool's team (or `*`)."""
    if not team_key:
        raise ApprovalError("This pool has no team.", "no_team", 409)
    held = s.execute(
        select(AppTeam.key)
        .join(AppUserRole, AppUserRole.team_id == AppTeam.id)
        .join(AppRole, AppRole.id == AppUserRole.role_id)
        .where(
            AppUserRole.user_id == actor_id,
            AppRole.key == required_role,
            # A grant on a team that is switched off does not sign anything.
            AppTeam.is_active.is_(True),
        )
    ).scalars().all()
    if team_key not in held and GLOBAL_TEAM not in held:
        raise ApprovalError(
            "You are not a checker for this pool's team.", "wrong_team", 403
        )


def _refuse_signing_twice(actor_id: int, rows: list[PoolApproval], cycle: str) -> None:
    """Refuse a second signature from the same person in a cycle, so two steps mean two people."""
    if any(
        r.cycle_id == cycle and r.action == ACTION_APPROVED and r.actor_user_id == actor_id
        for r in rows
    ):
        raise ApprovalError(
            "You have already approved this pool at an earlier step. A second "
            "level needs a different person.",
            "already_signed",
            403,
        )


# ── reading ──────────────────────────────────────────────────────────────


def history(pool_id: str) -> list[dict]:
    """Every transition for a pool, oldest first, with actor emails, for the history panel."""
    with session_scope() as s:
        return [
            {
                "action": r.action,
                "step_no": r.step_no,
                "cycle_id": r.cycle_id,
                "actor": _email(s, r.actor_user_id),
                "actor_id": r.actor_user_id,
                "comment": r.comment,
                "at": r.created_at.isoformat() if r.created_at else None,
            }
            for r in _ledger(s, pool_id)
        ]


def queue_for(user_id: int) -> list[dict]:
    """The checker's to-do list: pending pools whose next step this person is allowed to sign."""
    out: list[dict] = []
    with session_scope() as s:
        for pool_id, rows in _ledgers_by_pool(s).items():
            status = _derive(s, rows)
            if status["state"] != POOL_PENDING or not status["next_step"]:
                continue
            opened = _opened(rows, status["cycle_id"])
            if opened is None:
                continue
            try:
                _refuse_unless_can_sign(s, user_id, rows, status, opened)
            except ApprovalError:
                continue
            out.append({
                "pool_id": pool_id,
                "team": status["team"],
                "step": status["next_step"],
                "submitted_by": _email(s, status["submitted_by"]),
                "cycle_id": status["cycle_id"],
            })
    return out
