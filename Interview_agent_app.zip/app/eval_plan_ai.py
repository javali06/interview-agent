"""AI-assisted evaluation-plan generation .

When the operator clicks **Regenerate** in the Evaluation panel, we ask the slow
LLM to choose the best-fit evaluation plugin for EACH cadence phase and to
configure it — from the phase's intent + metadata, matched against every
plugin's own description of what it does and when to use it.

What the LLM sees per phase (deliberately LEAN — we do NOT send the actual
specific questions/prompts, only metadata):
  - generic phase:  id, duration_s, intent, question_mode, generic_prompts
  - specific phase: id, duration_s, intent, question_mode + STRUCTURAL flags
    (question_count, whether every question has a difficulty, whether coverage
    tags are present, adaptive?) — NOT the question text.
and the full plugin catalog (name / when-to-use / how-it-scores / config shape).

Robustness (so the result is always valid + scoreable):
  - each returned config is validated against the plugin's own schema; invalid →
    the plugin's defaults.
  - if the chosen plugin's cadence assumptions aren't met (e.g. dynamic_difficulty
    on a phase whose questions have no difficulty), we fall back to
    `conversational_rubric`, which scores any phase.
  - any LLM/parse failure → deterministic all-unscored plan (caller's fallback),
    so Regenerate never hard-fails.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from typing import Any, Optional

import yaml

from app.cadence_service import _resolve_llm
from features.eval.plan import EvaluationPlan, PhasePlan, PluginAssignment, _now
from features.eval.plugins.registry import get_plugin, has_plugin, plugin_catalog
from features.eval.schema import CANONICAL_DIMS

logger = logging.getLogger(__name__)

# Safe universal fallback: rates any phase transcript on behavioral dimensions,
# no per-question structure or cadence preconditions required.
_FALLBACK_PLUGIN = "conversational_rubric"


def _phase_descriptor(ph: dict) -> dict:
    """Metadata sent to the LLM for one phase. Specific phases send structural
    flags, NOT the question text/pool (per the design)."""
    d: dict[str, Any] = {
        "id": ph.get("id"),
        "duration_s": ph.get("duration_s"),
        "intent": (ph.get("intent") or "").strip(),
        "question_mode": ph.get("question_mode"),
    }
    if ph.get("coding_question_ids"):
        d["is_coding"] = True
    if ph.get("question_mode") == "generic":
        d["generic_prompts"] = [str(p) for p in (ph.get("generic_prompts") or [])]
    else:  # specific — describe the pool WITHOUT sending its questions
        pool = [q for q in (ph.get("question_pool") or []) if isinstance(q, dict)]
        d["question_count"] = len(pool)
        d["all_questions_have_difficulty"] = bool(pool) and all(q.get("difficulty") for q in pool)
        d["questions_have_coverage_tags"] = any(q.get("coverage_tags") for q in pool)
        d["adaptive_difficulty"] = bool(ph.get("adaptive_difficulty"))
    return d


def _plugin_guide() -> list[dict]:
    """Compact, LLM-facing view of each plugin: identity + when-to-use + how it
    scores + what to configure + a concrete config shape (its defaults)."""
    guide: list[dict] = []
    for entry in plugin_catalog():
        help_ = entry.get("help") or {}
        guide.append({
            "id": entry["id"],
            "name": entry["name"],
            "method": entry["method"],
            "best_for": help_.get("best_for") or entry.get("description"),
            "how_it_scores": help_.get("how_it_works") or [],
            "you_configure": help_.get("you_configure") or [],
            "needs_from_cadence": [
                a.get("description") for a in (entry.get("assumptions") or [])
                if a.get("author_actionable", True)
            ],
            # Concrete keys/values to base the config on.
            "config_example": entry.get("default_config") or {},
        })
    return guide


_SYSTEM = """\
You configure automated scoring for a voice interview. You are given the
interview's PHASES (metadata only) and the catalog of available EVALUATION
PLUGINS (what each does, when to use it, and its config shape).

For EACH phase, choose the single best-fit plugin and produce its configuration,
matching the phase's intent + metadata to the plugin whose "best_for"/"how it
scores" fits best:
- Technical Q&A phases where questions carry a difficulty AND coverage tags →
  a difficulty-weighted plugin.
- Phases whose answers must hit specific concepts → a concept-coverage plugin.
- Coding phases → the coding plugin.
- Open / free-form phases with no per-question structure (resume deep-dive,
  behavioral, system design, warm-up) → the conversational rubric.
- Rubric-style scoring where you author +/- options → the marks rubric.

Rules:
- Pick plugin_id ONLY from the given catalog ids.
- Only choose a plugin whose "needs_from_cadence" the phase actually satisfies
  (e.g. don't pick a difficulty-weighted plugin unless the phase says
  all_questions_have_difficulty is true).
- Produce `config` as a JSON object using the SAME keys as that plugin's
  config_example, adjusting values to fit THIS phase.
  * For the marks rubric, populate `criteria` with 3-6 options, each
    {"description": <what to look for>, "marks": <+2/+1/-1>} derived from the
    phase intent (positive marks for good answers, negative for clear pitfalls).
  * For the conversational rubric, set `purpose` from the phase intent and pick
    1-3 `score_dimensions` from the ALLOWED DIMENSIONS list.
- A pure logistics phase with nothing to assess (e.g. a wrap-up/goodbye) may be
  left unscored: use plugin_id "".

Return STRICT JSON only, no prose/code-fences/<think>:
{"assignments": [{"phase_id": "...", "plugin_id": "...", "config": { ... }}]}"""


def _extract_json(raw: str) -> dict:
    raw = raw.strip()
    # Strip code fences if present.
    if raw.startswith("```"):
        raw = re.sub(r"^```[a-zA-Z]*\n?|\n?```$", "", raw).strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        # Grab the outermost {...}.
        m = re.search(r"\{.*\}", raw, re.DOTALL)
        if not m:
            raise
        return json.loads(m.group(0))


def _coerce_assignment(phase: dict, plugin_id: str, config: dict) -> PluginAssignment:
    """Validate config against the plugin schema + cadence assumptions; fall back
    to conversational_rubric (then to unscored) so the result always validates."""
    pid = (plugin_id or "").strip()
    if not pid or not has_plugin(pid):
        return PluginAssignment(plugin_id="", config={}, enabled=False)

    def _try(pid_: str, cfg: dict) -> Optional[PluginAssignment]:
        cls = get_plugin(pid_)
        try:
            parsed = cls.parse_config(cfg)
        except Exception:
            try:
                parsed = cls.default_config()  # keep the plugin, drop bad config
            except Exception:
                return None
        try:
            if not cls().precheck_cadence(phase, parsed).ok:
                return None
        except Exception:
            return None
        return PluginAssignment(plugin_id=pid_, config=parsed.model_dump(mode="json"), enabled=True)

    a = _try(pid, config or {})
    if a is not None:
        return a
    # Chosen plugin can't score this phase → universal fallback.
    if pid != _FALLBACK_PLUGIN and has_plugin(_FALLBACK_PLUGIN):
        fb = _try(_FALLBACK_PLUGIN, _fallback_config(phase))
        if fb is not None:
            return fb
    return PluginAssignment(plugin_id="", config={}, enabled=False)


def _fallback_config(phase: dict) -> dict:
    """Sensible conversational_rubric config for a phase we're defaulting."""
    is_coding = bool(phase.get("coding_question_ids"))
    dims = (["code_quality", "problem_solving_process"] if is_coding
            else ["technical_depth", "communication_clarity"])
    dims = [d for d in dims if d in CANONICAL_DIMS][:3]
    return {
        "marks_possible": 10.0,
        "purpose": (phase.get("intent") or "").strip()[:200],
        "score_dimensions": dims,
    }


async def generate_ai_plan(
    cadence_yaml: str, *, role: str = "", token: Optional[str] = None,
) -> EvaluationPlan:
    """LLM-driven plan: best-fit + configured plugin per phase. Raises on total
    failure (no phases, no LLM key, or all attempts fail) so the caller can fall
    back to the deterministic all-unscored plan.

    `token` (the schedule token) is optional — passed through so this call's
    cost/Langfuse trace is attributed to the right interview's "cost for
    setting up interview" table."""
    data = yaml.safe_load(cadence_yaml) or {}
    phases = [p for p in (data.get("phases") or []) if isinstance(p, dict) and p.get("id")]
    if not phases:
        raise ValueError("cadence has no phases to plan")

    api_key, base_url, model = _resolve_llm()  # raises if no key
    from openai import AsyncOpenAI

    client = AsyncOpenAI(api_key=api_key, base_url=base_url)
    guide = _plugin_guide()
    payload = {
        "role": role or "",
        "phases": [_phase_descriptor(p) for p in phases],
        "plugins": guide,
        "allowed_dimensions": list(CANONICAL_DIMS.keys()),
    }
    extra_body = (
        {"reasoning": {"effort": "low"}, "provider": {"sort": "throughput"}}
        if "openrouter" in (base_url or "") else {}
    )
    per_attempt_timeout = float(os.environ.get("EVAL_PLAN_AI_TIMEOUT_S", "60"))

    last_err: Optional[str] = None
    chosen: dict[str, dict] = {}
    for attempt in (1, 2):
        messages = [
            {"role": "system", "content": _SYSTEM},
            {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
        ]
        if last_err:
            messages.append({"role": "user", "content": (
                f"Your previous reply was invalid: {last_err}. Return STRICT JSON "
                '{"assignments":[{"phase_id","plugin_id","config"}]} only.'
            )})
        try:
            from app.setup_cost_tracker import trace_call

            with trace_call(
                token=token, purpose="generate_eval_plugin", model=model, input_data=messages,
            ) as finish:
                resp = await asyncio.wait_for(
                    client.chat.completions.create(
                        model=model, messages=messages, temperature=0.1,
                        response_format={"type": "json_object"}, extra_body=extra_body,
                    ),
                    timeout=per_attempt_timeout,
                )
                finish(resp)
            obj = _extract_json(resp.choices[0].message.content or "")
            assignments = obj.get("assignments")
            if not isinstance(assignments, list):
                raise ValueError("missing 'assignments' list")
            chosen = {
                str(a.get("phase_id")): a for a in assignments
                if isinstance(a, dict) and a.get("phase_id")
            }
            break
        except Exception as e:  # timeout / API / JSON — retry once, then raise
            last_err = str(e).splitlines()[0]
            logger.warning("[eval_plan_ai] attempt %d failed: %s", attempt, last_err)
            continue
    else:
        raise RuntimeError(f"AI plan generation failed: {last_err}")

    # Build the plan in cadence order; every phase gets an assignment (a chosen +
    # configured plugin, or an explicit unscored entry).
    phases_out: list[PhasePlan] = []
    for ph in phases:
        pid = ph.get("id")
        a = chosen.get(pid) or {}
        assignment = _coerce_assignment(ph, a.get("plugin_id", ""), a.get("config") or {})
        phases_out.append(PhasePlan(phase_id=pid, plugins=[assignment]))

    scored = sum(1 for p in phases_out if p.plugins[0].enabled and p.plugins[0].plugin_id)
    logger.info("[eval_plan_ai] generated plan: %d/%d phases scored", scored, len(phases_out))
    return EvaluationPlan(source="ai_generated", generated_at=_now(), phases=phases_out)
