"""Seed the access-control tables: teams, roles, the permission grid, the default
approval chain, and the team's accounts with their roles. Idempotent; safe to run
on every start.

The grid is seeded only when `app_role_permissions` is EMPTY, so a restart never
undoes an admin's edit. Teams, roles and accounts are created if missing.

Design notes: docs/question-pool-maker-checker.md §0 and §7.
"""
from __future__ import annotations

import logging
from typing import Optional

from sqlalchemy import select

from app.constants import GLOBAL_TEAM
from app.rbac import ALL_PERMISSIONS, validate_permission
from db.engine import session_scope
from db.models import (
    AppApprovalStep,
    AppRole,
    AppRolePermission,
    AppTeam,
    AppUser,
    AppUserRole,
)

logger = logging.getLogger(__name__)


# ── teams ────────────────────────────────────────────────────────────────
# `*` means every team; two real teams make cross-team refusals testable.

TEAMS = [
    {"key": GLOBAL_TEAM, "name": "All teams", "is_system": True},
    {"key": "backend", "name": "Backend Engineering", "is_system": False},
    {"key": "qa", "name": "Quality Assurance", "is_system": False},
]


# ── roles ────────────────────────────────────────────────────────────────

ROLES = [
    {
        "key": "admin",
        "name": "Platform Admin",
        "description": "Everything, including managing people, teams and approval chains.",
        "is_system": True,
        "scope_kind": "global",
    },
    {
        "key": "pool_author",
        "name": "Question Author",
        "description": "Writes and edits question pools for their team, and submits them for approval.",
        "is_system": False,
        "scope_kind": "team",
    },
    {
        "key": "pool_checker",
        "name": "Question Checker",
        "description": "Approves or returns a submitted pool. Cannot approve their own work.",
        "is_system": False,
        "scope_kind": "team",
    },
    {
        "key": "hr",
        "name": "HR / Recruiter",
        "description": "Schedules interviews and reads results. Holds no access to question pools.",
        "is_system": False,
        "scope_kind": "global",
    },
]


# ── the grid ─────────────────────────────────────────────────────────────
# `hr` deliberately holds no pools.* permission.

ROLE_PERMISSIONS: dict[str, tuple[str, ...]] = {
    "admin": ALL_PERMISSIONS,
    "pool_author": ("pools.view", "pools.edit", "pools.submit"),
    "pool_checker": ("pools.view", "pools.approve"),
    "hr": ("interviews.view", "interviews.schedule", "interviews.cancel"),
}


# ── the default approval chain ───────────────────────────────────────────
# One step on `*`, used by every team without its own chain.

DEFAULT_CHAIN = [
    {"team": GLOBAL_TEAM, "step_no": 1, "role": "pool_checker", "name": "Review"},
]


# ── the accounts ─────────────────────────────────────────────────────────
# Dev accounts with roles pre-granted. Two exist to prove refusals: harika
# (Backend checker) must be refused on hasini's QA pool, and javali (HR) on
# every pools.* route.

SEED_USERS = [
    {
        "email": "ayush.kothiyal@centific.com",
        "name": "Ayush Kothiyal",
        "grants": [("admin", GLOBAL_TEAM)],
    },
    {
        "email": "sathwik.badda@centific.com",
        "name": "Sathwik Badda",
        "grants": [("admin", GLOBAL_TEAM)],
    },
    {
        "email": "md.azhar@centific.com",
        "name": "Md Azhar",
        "grants": [("pool_author", "backend")],
    },
    {
        "email": "puchalapalli.harika@centific.com",
        "name": "Harika Puchalapalli",
        "grants": [("pool_checker", "backend")],
    },
    {
        "email": "sai.kambampati@centific.com",
        "name": "Sai Shobit Kambampati",
        "grants": [("pool_checker", GLOBAL_TEAM)],
    },
    {
        "email": "hasini.gandhe@centific.com",
        "name": "Hasini Gandhe",
        "grants": [("pool_author", "qa")],
    },
    {
        "email": "javali.manda@centific.com",
        "name": "Javali Manda",
        "grants": [("hr", GLOBAL_TEAM)],
    },
]


def _ids_by_key(s, model, specs: list[dict], created: dict, counter: str) -> dict[str, int]:
    """Create any team/role row that is missing (matched on `key`) and return {key: id} for linking."""
    ids: dict[str, int] = {}
    for spec in specs:
        row = s.execute(select(model).where(model.key == spec["key"])).scalar_one_or_none()
        if row is None:
            row = model(**spec)
            s.add(row)
            s.flush()
            created[counter] += 1
        ids[spec["key"]] = row.id
    return ids


def seed_rbac(*, with_users: bool = True) -> dict[str, int]:
    """Seed teams, roles, grid, chain (and dev users unless `with_users=False`) on startup; returns counts."""
    created = {"teams": 0, "roles": 0, "permissions": 0, "steps": 0, "users": 0, "grants": 0}

    with session_scope() as s:
        team_ids = _ids_by_key(s, AppTeam, TEAMS, created, "teams")
        role_ids = _ids_by_key(s, AppRole, ROLES, created, "roles")

        # The grid only when empty, so an admin's removal is never restored.
        existing_grid = s.execute(select(AppRolePermission).limit(1)).first()
        if existing_grid is None:
            for role_key, permissions in ROLE_PERMISSIONS.items():
                for permission in permissions:
                    validate_permission(permission)
                    s.add(
                        AppRolePermission(
                            role_id=role_ids[role_key], permission=permission
                        )
                    )
                    created["permissions"] += 1

        # -- the default chain --
        for spec in DEFAULT_CHAIN:
            team_id = team_ids[spec["team"]]
            row = s.execute(
                select(AppApprovalStep).where(
                    AppApprovalStep.team_id == team_id,
                    AppApprovalStep.step_no == spec["step_no"],
                )
            ).scalar_one_or_none()
            if row is None:
                s.add(
                    AppApprovalStep(
                        team_id=team_id,
                        step_no=spec["step_no"],
                        approver_role_id=role_ids[spec["role"]],
                        name=spec["name"],
                    )
                )
                created["steps"] += 1

        if not with_users:
            return created

        # -- accounts and their grants --
        for spec in SEED_USERS:
            email = spec["email"].strip().lower()
            user = s.execute(
                select(AppUser).where(AppUser.email == email)
            ).scalar_one_or_none()
            if user is not None:
                # Grants only at creation, like the shared admin: this runs on
                # every startup, and re-adding a missing grant would undo a
                # removal made on the Access page.
                continue
            user = AppUser(email=email, display_name=spec["name"])
            s.add(user)
            s.flush()
            created["users"] += 1
            for role_key, team_key in spec["grants"]:
                role_id = role_ids[role_key]
                team_id = team_ids[team_key]
                existing = s.get(AppUserRole, (user.id, role_id, team_id))
                if existing is None:
                    s.add(
                        AppUserRole(
                            user_id=user.id, role_id=role_id, team_id=team_id
                        )
                    )
                    created["grants"] += 1

    if any(created.values()):
        logger.info("[rbac] seeded %s", created)
    return created


def shared_admin_user_id(username: str) -> Optional[int]:
    """The account behind the shared username/password login.

    That login used to carry no `app_users` id, so it held no permissions: no
    question pools, no Access page. It is backed by a real row keyed by the
    username, granted `admin` on every team when the row is first created.
    Granting only at creation means an administrator who later removes or
    deactivates it is not silently overruled on the next sign-in.
    """
    key = (username or "").strip().lower()
    if not key:
        return None
    with session_scope() as s:
        row = s.execute(select(AppUser).where(AppUser.email == key)).scalar_one_or_none()
        if row is not None:
            return row.id
        row = AppUser(email=key, display_name="Shared admin login")
        s.add(row)
        s.flush()
        role = s.execute(select(AppRole).where(AppRole.key == "admin")).scalar_one_or_none()
        team = s.execute(select(AppTeam).where(AppTeam.key == GLOBAL_TEAM)).scalar_one_or_none()
        if role is not None and team is not None:
            s.add(AppUserRole(user_id=row.id, role_id=role.id, team_id=team.id))
        logger.info("[rbac] created the shared admin account %r", key)
        return row.id


def ensure_user(email: str, display_name: str = "") -> Optional[int]:
    """Find or create a person by email and return their id, so sign-in can map to a user row."""
    key = (email or "").strip().lower()
    if not key:
        return None
    with session_scope() as s:
        row = s.execute(select(AppUser).where(AppUser.email == key)).scalar_one_or_none()
        if row is None:
            row = AppUser(email=key, display_name=display_name or key)
            s.add(row)
            s.flush()
        return row.id
