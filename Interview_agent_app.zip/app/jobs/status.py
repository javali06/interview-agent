"""Durable job status in Postgres (the `jobs` table).

The queue (queue.py) carries only a job id; THIS is where a job's lifecycle
lives, so the gateway can answer "is the cadence for this draft ready?" by
polling, and a crashed worker leaves a truthful record behind. Core-level
access mirroring app/db.py (plain dict rows, no ORM session juggling).
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import select
from sqlalchemy import update as _update

from db.engine import get_engine
from db.models import Job

_T = Job.__table__

# Lifecycle states.
QUEUED = "queued"
RUNNING = "running"
SUCCEEDED = "succeeded"
FAILED = "failed"      # transient failure — will be retried off the queue
DEAD = "dead"          # exhausted retries — dead-lettered


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def create(job_type: str, payload: dict, *, token: Optional[str] = None) -> str:
    """Insert a queued job row and return its id (also the queue correlation id)."""
    job_id = uuid.uuid4().hex
    ts = now_iso()
    with get_engine().begin() as c:
        c.execute(_T.insert().values(
            id=job_id, type=job_type, status=QUEUED, token=token,
            payload=payload, result=None, error=None, attempts=0,
            created_at=ts, updated_at=ts,
        ))
    return job_id


def get(job_id: str) -> Optional[dict]:
    with get_engine().connect() as c:
        row = c.execute(select(_T).where(_T.c.id == job_id)).mappings().first()
        return dict(row) if row else None


def _set(job_id: str, **fields) -> None:
    fields["updated_at"] = now_iso()
    with get_engine().begin() as c:
        c.execute(_update(_T).where(_T.c.id == job_id).values(**fields))


def mark_running(job_id: str) -> None:
    """Flip to running and bump the attempt counter (retries re-enter here)."""
    with get_engine().begin() as c:
        row = c.execute(select(_T.c.attempts).where(_T.c.id == job_id)).first()
        attempts = (row[0] if row else 0) + 1
        c.execute(_update(_T).where(_T.c.id == job_id).values(
            status=RUNNING, attempts=attempts,
            started_at=now_iso(), updated_at=now_iso(),
        ))


def mark_succeeded(job_id: str, result: Optional[dict] = None) -> None:
    _set(job_id, status=SUCCEEDED, result=result or {}, error=None,
         finished_at=now_iso())


def mark_failed(job_id: str, error: str) -> None:
    """Transient failure — the message goes back on the queue for another try."""
    _set(job_id, status=FAILED, error=error[:4000])


def mark_dead(job_id: str, error: str) -> None:
    """Retries exhausted — parked so it can't loop forever or block the queue."""
    _set(job_id, status=DEAD, error=error[:4000], finished_at=now_iso())


def latest_for_token(token: str, job_type: Optional[str] = None) -> Optional[dict]:
    """Most recent job for a session token (optionally of one type) — the
    gateway uses this to report per-draft cadence/eval progress."""
    q = select(_T).where(_T.c.token == token)
    if job_type:
        q = q.where(_T.c.type == job_type)
    q = q.order_by(_T.c.created_at.desc()).limit(1)
    with get_engine().connect() as c:
        row = c.execute(q).mappings().first()
        return dict(row) if row else None
