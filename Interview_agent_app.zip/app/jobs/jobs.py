"""Job type registry + handlers.

Each handler wraps an EXISTING service function and moves it off the web request
path onto the worker tier. Handlers lazy-import their service so this module (and
the enqueue side, which runs in the gateway) stays light — the heavy deps only
load in the worker image.

A handler is `async (payload: dict) -> dict`; the returned dict is stored as the
job's `result`. Raising propagates to the worker, which retries (transient) or
dead-letters (exhausted).
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
from pathlib import Path
from typing import Awaitable, Callable

logger = logging.getLogger("app.jobs")

# ── job types ──────────────────────────────────────────────────────────────
# Only jobs with a real backing implementation are registered. Future job types
# (rubric_gen, recording_finalize, webhook, bulk_export) will be added here
# when those features are actually built — the queue/worker machinery already
# supports any registered handler.
CADENCE_GEN = "cadence_gen"
EVAL_V2 = "eval_v2"
SHORTLIST_SCORE = "shortlist_score"
RESUME_SUMMARY = "resume_summary"
INVITE_DISPATCH = "invite_dispatch"
RECORDING_FINALIZE = "recording_finalize"


# ── handlers ─────────────────────────────────────────────────────────────
async def _cadence_gen(payload: dict) -> dict:
    """Generate the interview cadence YAML for a draft and persist it.

    payload: {"token": <session token>}. Inputs (role / candidate / JD /
    requirements / resume) are read from the already-inserted draft row, so the
    schedule route can insert a `generating` draft and return instantly.
    """
    from app import db
    from app.cadence_service import (
        apply_modality_flag,
        apply_recording_flag,
        generate_cadence_yaml,
    )
    from app.paths import SESSIONS_DIR, session_dir

    token = payload["token"]
    row = db.get(token)
    if not row:
        raise RuntimeError(f"cadence_gen: no session row for token={token[:8]}")

    jd = row.get("jd_text")
    creq = row.get("cadence_requirements_text")
    if not (jd or creq):
        # No LLM input (e.g. a regenerate with cleared fields) — use the built-in
        # default for this modality (pool-backed default_text.yaml for text).
        from engine.brain.cadence.schema import default_yaml_path_for
        yaml_str = default_yaml_path_for(row.get("modality") or "voice").read_text(encoding="utf-8")
    else:
        resume_path = row.get("resume_path") or ""
        rp = Path(resume_path)
        if resume_path and not rp.is_absolute():
            rp = SESSIONS_DIR / resume_path
        yaml_str = await generate_cadence_yaml(
            role=row["role"],
            candidate_name=row["candidate_name"],
            jd_text=jd,
            cadence_requirements_text=creq,
            resume_path=rp if resume_path else None,
            work_dir=session_dir(token),
            token=token,
        )
    # Recording is admin-set and immutable — re-stamp the persisted (never the
    # request's) value here so it survives both initial generation and a
    # "regenerate cadence" edit, which both funnel through this one handler.
    yaml_str = apply_recording_flag(yaml_str, bool(row.get("record_enabled")))
    # Modality (voice|text) is admin-set + immutable — re-stamp the timing model
    # here so it survives generation AND a "regenerate cadence" edit (both funnel
    # through this handler), mirroring the recording flag above.
    yaml_str = apply_modality_flag(yaml_str, row.get("modality") or "voice")
    db.update(token, cadence_yaml=yaml_str, status="draft")
    return {"token": token, "cadence_chars": len(yaml_str)}


async def _resume_summary(payload: dict) -> dict:
    """Parse + LLM-summarize a candidate's resume AT SCHEDULE TIME, storing both
    as per-interview artifacts under ``sessions/{token}/resume/`` (parsed.txt +
    summary.txt) — a folder of its own, next to recordings — and mirroring them to
    blob (``{token}/resume/...``). The interview runner then just PULLS these; it
    never parses or calls the LLM on the candidate's start path (was ~20s+).

    payload: {"token": <session token>}. The resume file is already on disk (the
    schedule route writes it before enqueuing). parsed.txt is written FIRST so the
    interview has a usable fallback even if summarization can't produce a summary.
    Idempotent — a replaced resume re-enqueues this.
    """
    from app import blob_store, db
    from app.cadence_service import _resolve_llm
    from app.paths import SESSIONS_DIR, session_dir
    from engine.orchestrator.resume_parser import extract_email, parse_resume, summarize_resume

    token = payload["token"]
    row = db.get(token)
    if not row:
        raise RuntimeError(f"resume_summary: no session row for token={token[:8]}")

    resume_path = row.get("resume_path") or ""
    if not resume_path:
        return {"token": token, "skipped": "no_resume"}

    rp = Path(resume_path)
    if not rp.is_absolute():
        # resume_path is stored RELATIVE to the token's session dir (just the
        # filename — app/sessions.py writes `resume_path.relative_to(sdir)`), so
        # it MUST resolve under session_dir(token). The old `SESSIONS_DIR /
        # resume_path` dropped the {token} segment, so the file was never found →
        # the job always skipped ("file_missing") and NO parsed/summary artifact
        # was ever written or mirrored to blob (0 resume/ blobs across all
        # sessions, confirmed 2026-08-04). Matches evaluation_service's resolution.
        rp = session_dir(token) / resume_path
    if not rp.is_file():
        logger.warning("[resume_summary] file missing token=%s path=%s", token[:8], rp)
        return {"token": token, "skipped": "file_missing"}

    # Per-interview resume artifact folder (separate from recordings).
    rdir = session_dir(token) / "resume"
    rdir.mkdir(parents=True, exist_ok=True)

    # parse_resume does blocking PDF/docx extraction — keep it off the loop.
    raw = await asyncio.to_thread(parse_resume, rp) or ""
    if not raw.strip():
        return {"token": token, "skipped": "empty_resume"}
    # Save + mirror the PARSED text first — the interview's fallback is guaranteed
    # even if summarization fails below.
    parsed_fp = rdir / "parsed.txt"
    parsed_fp.write_text(raw, encoding="utf-8")
    await asyncio.to_thread(blob_store.upload_file, parsed_fp, f"{token}/resume/parsed.txt")

    # Fallback candidate email: only if the admin left the field blank at
    # schedule time — never overrides one they actually typed in. Done here
    # (right after parsing, before the slower LLM summarize call below) so it
    # lands in the DB well before the admin gets through cadence review and
    # clicks Approve, which is what actually reads candidate_email to decide
    # whether to send the invite (app.main._maybe_enqueue_invite).
    if not (row.get("candidate_email") or "").strip():
        found_email = extract_email(raw)
        if found_email:
            db.update(token, candidate_email=found_email)
            logger.info("[resume_summary] token=%s extracted candidate_email from resume", token[:8])

    # Summarize with retries; fallback_to_raw=False → empty (not raw) when it
    # can't produce a valid summary, so summary.txt cleanly means "the summary"
    # and the runner falls through to the parsed text.
    api_key, base_url, model = _resolve_llm()  # same slow provider/model cadence uses
    summary = await summarize_resume(
        raw,
        candidate_name=row.get("candidate_name", ""),
        api_key=api_key,
        base_url=base_url,
        model=model,
        fallback_to_raw=False,
    )
    summary_fp = rdir / "summary.txt"
    summary_fp.write_text(summary or "", encoding="utf-8")
    await asyncio.to_thread(blob_store.upload_file, summary_fp, f"{token}/resume/summary.txt")

    logger.info(
        "[resume_summary] token=%s parsed=%d summary=%d chars",
        token[:8], len(raw), len(summary or ""),
    )
    return {"token": token, "parsed_chars": len(raw), "summary_chars": len(summary or "")}


async def _eval_v2(payload: dict) -> dict:
    """Post-interview scoring — the flag-agnostic dispatcher (v2 plugins when
    EVAL_PLUGINS_ENABLED, else v1). Writes sessions/{token}/evaluation.json.

    The worker runs on a different container from the session shard, so it first
    hydrates the local session_dir from Blob (events.jsonl + cadence), then pushes
    evaluation.json back to Blob for the gateway to serve read-through."""
    import asyncio

    from app import blob_store
    from app.plugin_evaluation import run_evaluation

    token = payload["token"]
    # Pull inputs the session shard mirrored to Blob at end-of-interview.
    await asyncio.to_thread(blob_store.download_session_artifacts, token)

    evaluation = await run_evaluation(token, feedback=payload.get("feedback"))

    # Push evaluation.json (+ any refreshed artifacts) back to Blob.
    await asyncio.to_thread(blob_store.upload_session_artifacts, token)

    overall = evaluation.get("overall", {}) if isinstance(evaluation, dict) else {}
    return {"token": token, "score": overall.get("score"), "band": overall.get("band")}


async def _invite_dispatch(payload: dict) -> dict:
    """Emails the candidate their interview link over SMTP.

    payload: {"token", "to", "candidate_name", "role", "link"}. The link is
    passed in rather than re-derived here because it depends on the inbound
    request's host (see app.main._candidate_link_base) — there's nothing to
    look up from the token alone. Returns {"sent": False, "reason": ...} (not
    an error) when SMTP isn't configured, so a dev/test box with no mailbox
    provisioned just skips sending instead of failing the job.
    """
    from app.notifications import email_client
    from app.notifications.templates import build_invite_email

    token = payload["token"]
    to = payload["to"]
    subject, html_body = build_invite_email(
        candidate_name=payload["candidate_name"],
        role=payload["role"],
        link=payload["link"],
    )
    try:
        await email_client.send_email(to, subject, html_body)
    except email_client.EmailNotConfigured as e:
        logger.info("[invite_dispatch] token=%s skipped: %s", token[:8], e)
        return {"token": token, "sent": False, "reason": "not_configured"}
    logger.info("[invite_dispatch] token=%s sent to=%s", token[:8], to)
    return {"token": token, "sent": True}


async def _shortlist_score(payload: dict) -> dict:
    """Score a resume against a JD and persist (Shortlist). Wraps the existing
    synchronous scorer on a thread so the worker loop isn't blocked."""
    from features.shortlist.routes import _run_scoring
    resume_text = payload["resume_text"]
    jd_text = payload["jd_text"]
    resp = await asyncio.to_thread(_run_scoring, resume_text, jd_text)
    # ScoreResponse is a pydantic model; return a compact summary.
    final = getattr(resp, "final_score", None)
    return {"final_score": final, "recommendation": getattr(resp, "recommendation", None)}


class EgressStillRunning(RuntimeError):
    """The recording hasn't finished uploading yet — retried off the queue."""


async def _recording_finalize(payload: dict) -> dict:
    """Confirm a LiveKit server recording landed in storage, or record why not.

    payload: {"token", "egress_id", "blob"} — enqueued by the session runner
    when it stops the recording. LiveKit uploads the file a few seconds after
    the stop; this waits (bounded) for LiveKit to call the egress finished,
    then writes the part's manifest ("ready" with its duration and size, or
    "failed" with LiveKit's error) so the admin page can say which. Still
    running after the wait → raise, and the queue retries it later.
    """
    from engine.brain.observability import prom
    from engine.orchestrator.livekit import egress
    from engine.orchestrator.livekit.config import livekit_settings
    from livekit import api

    token, egress_id, blob = payload["token"], payload["egress_id"], payload["blob"]
    lk = livekit_settings()
    if not lk.is_complete():
        # Nothing to ask; the file (if it ever lands) still marks it ready.
        return {"token": token, "status": "unknown", "reason": "livekit_not_configured"}

    done = {api.EgressStatus.EGRESS_COMPLETE: "ready",
            api.EgressStatus.EGRESS_FAILED: "failed",
            api.EgressStatus.EGRESS_ABORTED: "failed",
            api.EgressStatus.EGRESS_LIMIT_REACHED: "ready"}  # stopped at a limit; the file is kept
    deadline = time.monotonic() + float(os.environ.get("RECORDING_FINALIZE_WAIT_S", "90"))
    while True:
        info = await egress.egress_info(lk, egress_id)
        if info is not None and info.status in done:
            break
        if time.monotonic() >= deadline:
            raise EgressStillRunning(
                f"egress {egress_id} still {getattr(info, 'status', 'unknown')}")
        await asyncio.sleep(2.0)

    status = done[info.status]
    fields: dict = {"egress_id": egress_id}
    if info.error:
        fields["error"] = info.error[:500]
    files = list(info.file_results) or ([info.file] if info.HasField("file") else [])
    if files:
        f = files[0]
        # LiveKit reports nanoseconds; 0 when it didn't get that far.
        fields["duration_s"] = round(f.duration / 1e9, 1) if f.duration else None
        fields["size_bytes"] = int(f.size) or None
    if status == "ready" and not files:
        status, fields["error"] = "failed", fields.get("error") or "no file was written"
    await asyncio.to_thread(egress.write_manifest, blob, status, **fields)
    prom.LIVEKIT_EGRESS.labels(outcome="complete" if status == "ready" else "failed").inc()
    logger.info("[recording_finalize] token=%s blob=%s %s", token[:8], blob, status)
    return {"token": token, "blob": blob, "status": status,
            "duration_s": fields.get("duration_s")}


# Registry — every entry is a real, wired handler.
HANDLERS: dict[str, Callable[[dict], Awaitable[dict]]] = {
    CADENCE_GEN: _cadence_gen,
    RESUME_SUMMARY: _resume_summary,
    EVAL_V2: _eval_v2,
    SHORTLIST_SCORE: _shortlist_score,
    INVITE_DISPATCH: _invite_dispatch,
    RECORDING_FINALIZE: _recording_finalize,
}


async def dispatch(job_type: str, payload: dict) -> dict:
    handler = HANDLERS.get(job_type)
    if handler is None:
        raise KeyError(f"unknown job type: {job_type!r}")
    return await handler(payload)


async def enqueue(job_type: str, payload: dict, *, token: str | None = None) -> str:
    """Create the durable status row + put the id on the queue. Returns job id.

    This is what the gateway routes call instead of running the work inline —
    the draft/job-id returns instantly and the worker finishes it.
    """
    from app.jobs import status
    from app.jobs.queue import get_queue

    if job_type not in HANDLERS:
        raise KeyError(f"unknown job type: {job_type!r}")
    job_id = status.create(job_type, payload, token=token)
    await get_queue().send(job_id)
    return job_id
