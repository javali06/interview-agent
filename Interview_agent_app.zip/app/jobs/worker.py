"""Worker tier entrypoint — drains the job queue.

Run as its own container/process (the worker ACA app). KEDA scales replicas on
queue depth, down to zero when idle. Each replica:

  receive a batch → for each message: load the job row, run its handler,
  DELETE on success. On failure, leave the message on the queue so it reappears
  after the visibility timeout (that IS the retry + backoff). Past
  JOBS_MAX_ATTEMPTS dequeues, dead-letter it to the poison queue so a bad job
  can't loop forever or block healthy work.

Local run:  python -m app.jobs.worker
"""
from __future__ import annotations

import asyncio
import logging
import os
import signal

from app.jobs import jobs, status
from app.jobs.queue import get_queue, max_attempts

logger = logging.getLogger("worker")

_POLL_IDLE_S = float(os.environ.get("JOBS_POLL_IDLE_S", "2.0"))
_BATCH = int(os.environ.get("JOBS_BATCH", "16"))
_CONCURRENCY = int(os.environ.get("JOBS_CONCURRENCY", "8"))


def _count(job_type: str, outcome: str) -> None:
    try:
        from engine.brain.observability import prom
        prom.JOBS.labels(type=job_type, outcome=outcome).inc()
    except Exception:
        pass


async def _render_metrics() -> bytes:
    from prometheus_client import generate_latest
    from engine.brain.observability.prom import REGISTRY
    return generate_latest(REGISTRY)


async def process_one(msg) -> None:
    """Run a single queued job to completion (success / retry / dead-letter)."""
    q = get_queue()
    job_id = msg.content
    row = status.get(job_id)

    if row is None:
        # Orphan message (job row deleted) — drop it so it can't loop.
        logger.warning("[worker] no job row for id=%s — dropping message", job_id)
        await q.delete(msg)
        return
    if row["status"] == status.SUCCEEDED:
        # Duplicate delivery of an already-finished job — just ack it.
        await q.delete(msg)
        return

    status.mark_running(job_id)
    try:
        result = await jobs.dispatch(row["type"], row["payload"] or {})
        status.mark_succeeded(job_id, result)
        await q.delete(msg)
        _count(row["type"], "succeeded")
        logger.info("[worker] %s %s ok (attempt %d)", row["type"], job_id[:8],
                    msg.dequeue_count)
    except Exception as e:  # noqa: BLE001 — worker must not die on one bad job
        err = f"{type(e).__name__}: {e}"
        if msg.dequeue_count >= max_attempts():
            status.mark_dead(job_id, err)
            await q.send_poison(job_id)
            await q.delete(msg)
            _count(row["type"], "dead")
            logger.error("[worker] %s %s DEAD after %d attempts: %s",
                         row["type"], job_id[:8], msg.dequeue_count, err)
        else:
            status.mark_failed(job_id, err)
            _count(row["type"], "retry")
            # Do NOT delete — the message reappears after the visibility timeout.
            logger.warning("[worker] %s %s failed (attempt %d), will retry: %s",
                           row["type"], job_id[:8], msg.dequeue_count, err)


async def run(stop: asyncio.Event | None = None) -> None:
    """Main receive→dispatch loop until `stop` is set."""
    stop = stop or asyncio.Event()
    q = get_queue()
    await q.ensure()
    sem = asyncio.Semaphore(_CONCURRENCY)
    logger.info("[worker] started (batch=%d concurrency=%d)", _BATCH, _CONCURRENCY)

    async def _guarded(m):
        async with sem:
            await process_one(m)

    # The worker has no ingress either: its metrics (job outcomes, the LLM
    # calls evaluations make, recording finalisation) reach Prometheus through
    # Redis and the gateway. Only where Redis is configured (the tiered deploy).
    metrics_task = None
    if os.environ.get("REDIS_URL"):
        import socket
        from app.coordination import metrics_push
        metrics_task = asyncio.create_task(metrics_push.publish_loop(
            f"worker-{socket.gethostname()}", "worker", _render_metrics, stop))

    while not stop.is_set():
        try:
            batch = await q.receive(max_messages=_BATCH)
        except Exception as e:  # transient queue/network hiccup
            logger.warning("[worker] receive hiccup: %s", e)
            await asyncio.sleep(_POLL_IDLE_S)
            continue
        if not batch:
            # Empty — back off briefly (KEDA scales the fleet to zero when idle).
            try:
                await asyncio.wait_for(stop.wait(), timeout=_POLL_IDLE_S)
            except asyncio.TimeoutError:
                pass
            continue
        await asyncio.gather(*[_guarded(m) for m in batch])

    if metrics_task is not None:
        metrics_task.cancel()
    logger.info("[worker] stopped")


def main() -> None:
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    # The Azure SDK's HTTP-logging policy dumps every request/response (headers
    # and all) at INFO — deafening for the worker's ~2s queue poll. Quiet it to
    # WARNING (real errors still surface). Override with AZURE_LOG_LEVEL.
    logging.getLogger("azure").setLevel(os.environ.get("AZURE_LOG_LEVEL", "WARNING"))
    # The worker shares the DB layer; make sure the schema exists.
    from app import db
    db.init_db()

    stop = asyncio.Event()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except NotImplementedError:  # e.g. Windows
            pass
    try:
        loop.run_until_complete(run(stop))
    finally:
        loop.run_until_complete(get_queue().close())
        loop.close()


if __name__ == "__main__":
    main()
