"""The durable job queue — Azure Storage Queue.

The to-do list for the worker tier. It survives restarts, and KEDA scales the
worker replicas on its depth (down to zero when idle). Reuses the SAME storage
account already used for Blob recordings, so it adds no new Azure resource.

Retry model is the queue's own visibility timeout: the worker receives a message
(making it invisible), and only DELETES it on success. A crash or a transient
failure means the message reappears after the timeout for another attempt.
`dequeue_count` is how many times it's been tried; past the limit the worker
dead-letters it to a `<queue>-poison` queue so a poison job can't loop forever
or wedge the queue.

The class is async (the worker runs on an asyncio loop). `InMemoryQueue` is the
test/local seam — the same interface with no Azure dependency.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Message:
    """Normalized queue message across the Azure and in-memory backends."""
    id: str
    content: str            # the job id
    dequeue_count: int      # how many times this has been received
    pop_receipt: str = ""   # Azure delete token
    raw: Any = None         # underlying SDK object (Azure) for delete


def queue_name() -> str:
    return (os.environ.get("JOBS_QUEUE_NAME") or "jobs").strip()


def max_attempts() -> int:
    return int(os.environ.get("JOBS_MAX_ATTEMPTS", "5"))


def visibility_timeout_s() -> int:
    # How long a received message stays invisible while the worker runs it.
    # Must exceed the slowest job (eval-v2 multi-segment LLM ~60s).
    return int(os.environ.get("JOBS_VISIBILITY_TIMEOUT_S", "300"))


class AzureStorageQueue:
    """Async Azure Storage Queue client (lazy SDK import)."""

    def __init__(self, conn_str: str, name: str):
        from azure.storage.queue.aio import QueueClient  # lazy
        self._name = name
        self._client = QueueClient.from_connection_string(conn_str, name)
        self._poison = QueueClient.from_connection_string(conn_str, f"{name}-poison")
        self._ensured = False

    async def ensure(self) -> None:
        from azure.core.exceptions import ResourceExistsError
        for c in (self._client, self._poison):
            try:
                await c.create_queue()
            except ResourceExistsError:
                pass
        self._ensured = True

    async def send(self, content: str) -> None:
        # Enqueue happens on the gateway/session, which may run before the worker
        # has created the queue — ensure it exists once so the first enqueue can't
        # race a not-yet-created queue (the worker scales from zero).
        if not self._ensured:
            await self.ensure()
        await self._client.send_message(content)

    async def receive(self, *, max_messages: int = 16,
                      visibility_timeout: int | None = None) -> list[Message]:
        vt = visibility_timeout or visibility_timeout_s()
        out: list[Message] = []
        # receive_messages yields an async iterator; cap it at max_messages.
        async for m in self._client.receive_messages(
            messages_per_page=max_messages, visibility_timeout=vt,
        ):
            out.append(Message(
                id=m.id, content=m.content, dequeue_count=m.dequeue_count,
                pop_receipt=m.pop_receipt, raw=m,
            ))
            if len(out) >= max_messages:
                break
        return out

    async def delete(self, msg: Message) -> None:
        await self._client.delete_message(msg.raw if msg.raw is not None else msg.id,
                                          msg.pop_receipt)

    async def send_poison(self, content: str) -> None:
        await self._poison.send_message(content)

    async def approx_count(self) -> int:
        props = await self._client.get_queue_properties()
        return int(props.approximate_message_count or 0)

    async def close(self) -> None:
        await self._client.close()
        await self._poison.close()


class InMemoryQueue:
    """Minimal in-process queue for tests / local dev without Azure.

    Visibility is naive (received messages stay listed); the worker's retry
    logic is driven by dequeue_count, which this increments on receive — enough
    to exercise success / retry / dead-letter paths deterministically.
    """

    def __init__(self) -> None:
        self._msgs: list[Message] = []
        self.poison: list[str] = []
        self._seq = 0

    async def ensure(self) -> None:
        return None

    async def send(self, content: str) -> None:
        self._seq += 1
        self._msgs.append(Message(id=f"m{self._seq}", content=content, dequeue_count=0))

    async def receive(self, *, max_messages: int = 16,
                      visibility_timeout: int | None = None) -> list[Message]:
        out = self._msgs[:max_messages]
        for m in out:
            m.dequeue_count += 1
        return list(out)

    async def delete(self, msg: Message) -> None:
        self._msgs = [m for m in self._msgs if m.id != msg.id]

    async def send_poison(self, content: str) -> None:
        self.poison.append(content)

    async def approx_count(self) -> int:
        return len(self._msgs)

    async def close(self) -> None:
        return None


_queue: AzureStorageQueue | InMemoryQueue | None = None


def get_queue():
    global _queue
    if _queue is None:
        conn = (os.environ.get("AZURE_STORAGE_CONNECTION_STRING") or "").strip()
        if not conn:
            raise RuntimeError(
                "AZURE_STORAGE_CONNECTION_STRING is not set. The worker tier's job "
                "queue requires it (Azure Storage Queue on the existing storage "
                "account). For local dev point it at Azurite."
            )
        _queue = AzureStorageQueue(conn, queue_name())
    return _queue


def set_queue(q) -> None:
    """Inject a queue backend (tests use InMemoryQueue)."""
    global _queue
    _queue = q
