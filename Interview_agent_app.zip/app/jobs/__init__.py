"""Async worker tier — slow/bursty jobs off the web request path.

  queue.py   the durable to-do list (Azure Storage Queue; InMemory for tests)
  status.py  durable per-job lifecycle in Postgres (the `jobs` table)
  jobs.py    job types + handlers (wrap existing services) + enqueue()
  worker.py  the consumer: receive -> dispatch -> ack / retry / dead-letter

Gateway routes call ``jobs.enqueue(type, payload)`` and return instantly; the
worker finishes the work. KEDA scales the worker on queue depth (to zero idle).
"""
from __future__ import annotations

from app.jobs import jobs, queue, status

__all__ = ["jobs", "queue", "status"]
