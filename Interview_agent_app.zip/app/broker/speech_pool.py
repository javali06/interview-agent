"""Multi-key Azure Speech pool with cluster-wide admission.

Azure Speech allows ~5 concurrent streams per key. One key across the whole
fleet caps you at 5 live interviews; each replica deciding alone would blow that
and earn 429s. This pool turns N keys into N×5 slots and hands them out through
the shared Redis admission counters, so a slot is granted only if it actually
exists cluster-wide.

Keys come from ``AZURE_SPEECH_KEYS`` — a comma list of ``key`` or ``key:region``
entries (falls back to the single ``AZURE_SPEECH_KEY`` + ``AZURE_SPEECH_REGION``).
A key's admission counter id is a short hash of the key, so it's stable across
restarts and independent of list order, and never logs the secret.
"""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass

from app.coordination import admission


@dataclass(frozen=True)
class SpeechKey:
    key_id: str    # short stable hash — used for the admission counter + logs
    key: str       # the secret
    region: str


@dataclass
class SpeechLease:
    """A granted Speech slot. MUST be released (use `lease()` or try/finally)."""
    speech_key: SpeechKey


def _key_id(secret: str) -> str:
    return hashlib.sha256(secret.encode()).hexdigest()[:8]


def parse_keys() -> list[SpeechKey]:
    raw = (os.environ.get("AZURE_SPEECH_KEYS") or "").strip()
    default_region = (os.environ.get("AZURE_SPEECH_REGION") or "eastus").strip()
    keys: list[SpeechKey] = []
    if raw:
        for part in raw.split(","):
            part = part.strip()
            if not part:
                continue
            if ":" in part:
                secret, region = part.split(":", 1)
                secret, region = secret.strip(), region.strip() or default_region
            else:
                secret, region = part, default_region
            keys.append(SpeechKey(key_id=_key_id(secret), key=secret, region=region))
    else:
        single = (os.environ.get("AZURE_SPEECH_KEY") or "").strip()
        if single:
            keys.append(SpeechKey(key_id=_key_id(single), key=single, region=default_region))
    return keys


async def acquire() -> SpeechLease | None:
    """Grant a Speech slot on the least-loaded key with headroom, or None if the
    whole pool is at capacity (caller then falls back to Groq — see stt_fallback)."""
    keys = parse_keys()
    if not keys:
        raise RuntimeError(
            "No Azure Speech keys configured. Set AZURE_SPEECH_KEYS (comma list "
            "of key or key:region) or AZURE_SPEECH_KEY."
        )
    cap = admission.speech_streams_per_key()

    # Least-loaded first so streams spread evenly across keys.
    loads = [(await admission.value(admission.speech_key_counter(k.key_id)), k) for k in keys]
    loads.sort(key=lambda t: t[0])
    for _, k in loads:
        if await admission.try_acquire(admission.speech_key_counter(k.key_id), cap):
            return SpeechLease(speech_key=k)
    return None


async def release(lease: SpeechLease) -> None:
    await admission.release(admission.speech_key_counter(lease.speech_key.key_id))


import contextlib


@contextlib.asynccontextmanager
async def lease():
    """`async with lease() as l:` — l is a SpeechLease or None (pool full)."""
    granted = await acquire()
    try:
        yield granted
    finally:
        if granted is not None:
            await release(granted)
