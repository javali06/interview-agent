"""STT provider selection with Azure↔Groq fallback.

Speech-to-text has two backends already in the codebase (azure_stt_client,
groq_stt_client). Azure is the primary but capped (5 streams/key); Groq Whisper
is the overflow/backup. This module makes the choice a capacity decision: take an
Azure slot from the pool if one exists, otherwise fall back to Groq so a full
pool degrades gracefully instead of wedging the interview.

The returned lease tells the session which client to build; on end the session
calls ``release`` so the Azure slot returns to the pool (Groq leases are a no-op).
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass

from app.broker import speech_pool

logger = logging.getLogger("broker.stt")

AZURE = "azure"
GROQ = "groq"


@dataclass
class SttLease:
    provider: str                                   # "azure" | "groq"
    speech: speech_pool.SpeechLease | None = None   # set when provider == azure
    key: str = ""                                   # azure key (for client build)
    region: str = ""


def _groq_available() -> bool:
    return bool((os.environ.get("GROQ_API_KEY") or "").strip())


async def acquire_stt() -> SttLease:
    """Pick an STT backend. Prefer an Azure pool slot; fall back to Groq."""
    lease = await speech_pool.acquire()
    if lease is not None:
        return SttLease(provider=AZURE, speech=lease,
                        key=lease.speech_key.key, region=lease.speech_key.region)
    if _groq_available():
        logger.warning("[stt] Azure Speech pool full — falling back to Groq Whisper")
        return SttLease(provider=GROQ)
    # No Azure headroom and no Groq: caller must handle (admission should have
    # blocked the session before this point).
    raise RuntimeError("no STT capacity: Azure pool full and GROQ_API_KEY unset")


async def release_stt(lease: SttLease) -> None:
    if lease.provider == AZURE and lease.speech is not None:
        await speech_pool.release(lease.speech)
