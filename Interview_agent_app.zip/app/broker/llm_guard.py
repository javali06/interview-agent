"""LLM call guard — timeout, backup failover, and inflight admission.

The interview's turn loop calls a slow + a fast LLM. Two failure modes hurt at
scale: a single slow provider stalls the ~900ms budget, and unbounded concurrent
calls trip the provider's rate limits. This wraps a call so it (a) is cut loose
after a timeout and retried against a named backup, and (b) counts against the
cluster-wide ``llm_inflight`` counter so the fleet admits only as many calls as
it has headroom for.

Provider-agnostic: callers pass factories that each return a fresh awaitable
(coroutine), so a retry actually re-issues the request.
"""
from __future__ import annotations

import asyncio
import contextlib
import logging
from typing import Awaitable, Callable, Sequence, TypeVar

from app.coordination import admission

logger = logging.getLogger("broker.llm")

T = TypeVar("T")
Factory = Callable[[], Awaitable[T]]


async def try_acquire_llm() -> bool:
    return await admission.try_acquire(admission.LLM_INFLIGHT, admission.max_llm_inflight())


async def release_llm() -> None:
    await admission.release(admission.LLM_INFLIGHT)


@contextlib.asynccontextmanager
async def llm_slot():
    """`async with llm_slot() as ok:` — ok is False if the fleet is at the LLM cap."""
    ok = await try_acquire_llm()
    try:
        yield ok
    finally:
        if ok:
            await release_llm()


async def call_with_backup(primary: Factory, *, timeout_s: float,
                           backups: Sequence[Factory] = ()) -> T:
    """Run ``primary`` under a timeout; on timeout/error try each backup in turn.

    Each argument is a zero-arg factory returning a fresh awaitable so retries
    re-issue the request. Raises the last error if everything fails.
    """
    factories = [primary, *backups]
    last: Exception | None = None
    for i, factory in enumerate(factories):
        try:
            return await asyncio.wait_for(factory(), timeout=timeout_s)
        except (asyncio.TimeoutError, Exception) as e:  # noqa: BLE001
            last = e
            where = "primary" if i == 0 else f"backup#{i}"
            logger.warning("[llm] %s failed (%s: %s) — %s", where, type(e).__name__, e,
                           "trying backup" if i + 1 < len(factories) else "no more backups")
    assert last is not None
    raise last
