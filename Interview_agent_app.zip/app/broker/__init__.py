"""Capacity / Speech broker — the single authority for scarce voice + LLM
capacity across all replicas.

  speech_pool.py  multi-key Azure Speech rotation (N×5 slots via Redis admission)
  stt_fallback.py Azure↔Groq STT selection when the pool is full
  llm_guard.py    LLM timeout + backup failover + inflight admission

Admission is cluster-wide (backed by app.coordination.admission), so no replica
overshoots a shared external limit. A session should acquire capacity before
starting Stream A and release it on end.
"""
from __future__ import annotations

from app.broker import llm_guard, speech_pool, stt_fallback

__all__ = ["speech_pool", "stt_fallback", "llm_guard"]
