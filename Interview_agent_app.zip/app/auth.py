"""Single-user admin auth.

Username + bcrypt-hashed password from env (`ADMIN_USERNAME`,
`ADMIN_PASSWORD_HASH`). Signed-cookie session via `itsdangerous` so we don't
need any server-side session store. Cookie expires after 12 hours.
"""
from __future__ import annotations

import os
from typing import Optional

import bcrypt
from fastapi import HTTPException, Request, status
from fastapi.responses import RedirectResponse
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

COOKIE_NAME = "admin_session"
COOKIE_MAX_AGE_S = 12 * 60 * 60  # 12 hours


_DEV_FALLBACK_SECRET = "dev-only-INSECURE-set-ADMIN_SECRET_KEY-in-.env"
_warned_about_secret = False


def _serializer() -> URLSafeTimedSerializer:
    global _warned_about_secret
    secret = os.environ.get("ADMIN_SECRET_KEY", "").strip()
    if not secret:
        if not _warned_about_secret:
            import logging
            logging.getLogger(__name__).warning(
                "ADMIN_SECRET_KEY not set in .env — falling back to an INSECURE "
                "dev key. Sessions will not survive across .env edits or hosts. "
                "Generate one with `python -c \"import secrets; "
                "print(secrets.token_urlsafe(32))\"` and put it in .env."
            )
            _warned_about_secret = True
        secret = _DEV_FALLBACK_SECRET
    return URLSafeTimedSerializer(secret, salt="admin-session-v1")


def verify_password(plaintext: str) -> bool:
    """Compare against the bcrypt hash in env. Returns True if the password
    matches OR if the env hash is empty (dev-only fallback to 'centific123')."""
    stored = os.environ.get("ADMIN_PASSWORD_HASH", "")
    if not stored:
        # Dev fallback so the app works on first run before the hash is set.
        # The login page surfaces a warning when this branch fires.
        return plaintext == "centific123"
    try:
        return bcrypt.checkpw(plaintext.encode("utf-8"), stored.encode("utf-8"))
    except ValueError:
        return False


def issue_cookie(username: str, user_id: Optional[int] = None) -> str:
    """Sign a session cookie.

    `user_id` is an `app_users.id` and is what every permission check reads.
    It is OPTIONAL so the legacy shared login keeps issuing exactly the cookie
    it always did: that account has no row in `app_users`, gets no user id, and
    therefore fails every permission check closed while continuing to work on
    the routes that ask only "is someone signed in".
    """
    payload: dict = {"u": username}
    if user_id is not None:
        payload["uid"] = int(user_id)
    return _serializer().dumps(payload)


def _read_payload(value: str) -> Optional[dict]:
    try:
        data = _serializer().loads(value, max_age=COOKIE_MAX_AGE_S)
    except SignatureExpired:
        return None
    except BadSignature:
        return None
    return data if isinstance(data, dict) else None


def read_cookie(value: str) -> Optional[str]:
    data = _read_payload(value)
    return data.get("u") if data else None


def get_current_user(request: Request) -> Optional[str]:
    cookie = request.cookies.get(COOKIE_NAME)
    if not cookie:
        return None
    return read_cookie(cookie)


def get_current_user_id(request: Request) -> Optional[int]:
    """The signed-in person's `app_users.id`, or None.

    None means "no identity we can authorise" — either nobody is signed in, or
    it is the legacy shared account. Both fail every permission check, which is
    the intended behaviour: the old login is a way in, not a set of rights.
    """
    cookie = request.cookies.get(COOKIE_NAME)
    if not cookie:
        return None
    data = _read_payload(cookie)
    if not data:
        return None
    raw = data.get("uid")
    try:
        return int(raw) if raw is not None else None
    except (TypeError, ValueError):
        return None


def require_login(request: Request) -> str:
    """FastAPI dependency. 302-redirects to /admin/login if no valid cookie."""
    user = get_current_user(request)
    if user is None:
        # Raising a 307 with a Location header is awkward through FastAPI's
        # dependency-injection error path; the route-level handler converts
        # this into a RedirectResponse. We just signal "unauthenticated."
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="login required",
            headers={"X-Redirect": "/admin/login"},
        )
    return user


def redirect_to_login() -> RedirectResponse:
    return RedirectResponse(url="/admin/login", status_code=302)
