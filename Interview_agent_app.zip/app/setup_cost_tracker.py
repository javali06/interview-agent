"""Setup-time cost tracker: cadence generation/revision, eval-plugin/rubric
generation — LLM calls that happen BEFORE (or independent of) a live
interview session.

WHY SEPARATE from `engine.brain.observability.cost_tracker`: that module's
in-memory map is keyed by session_id/token and only cleared at
SESSION_ENDED. Setup calls (cadence gen, revise, eval-plan/rubric gen)
happen at schedule/review time under the SAME token an interview later uses
as its Langfuse session_id — recording into that map would silently merge
setup costs into the live interview's "Cost by model" table the moment the
interview starts (this already happens today, invisibly — cadence-gen's
model shows up in a completed interview's per-model table even though the
interview itself never calls it). This module keeps a completely separate,
disk-persisted rollup per token so the two "Data & cost" tables never mix.

Persisted at `sessions/{token}/setup_cost_summary.json` — read-modify-write
per call. These are low-frequency, one-shot admin/worker actions (not a hot
path), so plain synchronous file I/O + a `threading.Lock` is enough; no
in-process map is needed (mirrors the single-process assumption already
documented in `cost_tracker.py`).
"""
from __future__ import annotations

import json
import logging
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable, Iterator, Optional

from app.paths import session_dir

logger = logging.getLogger(__name__)

_FILE_LOCK = threading.Lock()
_SIDECAR_NAME = "setup_cost_summary.json"

# Unit separator — never collides with a real model name or purpose string,
# so "model + purpose" makes a safe compound dict key.
_KEY_SEP = "\x1f"


def _sidecar_path(token: str) -> Path:
    return session_dir(token) / _SIDECAR_NAME


def record(
    *,
    token: Optional[str],
    model: Optional[str],
    purpose: str,
    tokens_in: Optional[int],
    tokens_out: Optional[int],
    tokens_cached: Optional[int] = 0,
    cost_usd: Optional[float],
) -> None:
    """Append one LLM call's contribution to the token's setup-cost sidecar.
    No-op if token/model is missing (e.g. an unscoped call with no schedule
    row yet — never worth failing the caller's actual work over)."""
    if not token or not model:
        return
    path = _sidecar_path(token)
    key = f"{model}{_KEY_SEP}{purpose}"
    with _FILE_LOCK:
        try:
            data = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
        except Exception:
            data = {}
        rows: dict[str, dict[str, Any]] = data.get("rows") or {}
        row = rows.setdefault(key, {
            "model": model, "purpose": purpose, "calls": 0,
            "tokens_in": 0, "tokens_out": 0, "tokens_cached": 0, "cost_usd": 0.0,
        })
        row["calls"] += 1
        row["tokens_in"] += int(tokens_in or 0)
        row["tokens_out"] += int(tokens_out or 0)
        row["tokens_cached"] += int(tokens_cached or 0)
        row["cost_usd"] += float(cost_usd or 0.0)
        data["rows"] = rows
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception as e:
            logger.warning("[setup_cost_tracker] failed to persist %s: %s", path, e)


def _human_usd(usd: float) -> str:
    """Same compact $-formatting as `event_viewer._human_usd` — kept as its
    own copy (not a cross-import of that private helper) so this module has
    no dependency on `event_viewer`'s internals."""
    if usd <= 0:
        return "$0"
    if usd < 0.0001:
        return f"${usd:.6f}"
    if usd < 0.01:
        return f"${usd:.5f}"
    if usd < 1:
        return f"${usd:.4f}"
    return f"${usd:.2f}"


def load(token: str) -> dict[str, Any]:
    """Return {"rows": [...], "total_cost_usd": float, "total_cost_human": str}
    for the token's setup costs, rows sorted by cost descending (each row also
    carries "cost_human"). Empty rows list if none recorded — callers should
    skip rendering the UI box entirely in that case."""
    path = _sidecar_path(token)
    try:
        data = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
    except Exception:
        data = {}
    rows = [dict(r) for r in (data.get("rows") or {}).values()]
    rows.sort(key=lambda r: -float(r.get("cost_usd") or 0.0))
    for r in rows:
        r["cost_human"] = _human_usd(float(r.get("cost_usd") or 0.0))
    total = sum(float(r.get("cost_usd") or 0.0) for r in rows)
    return {
        "rows": rows,
        "total_cost_usd": round(total, 6),
        "total_cost_human": _human_usd(total),
    }


@contextmanager
def trace_call(
    *, token: Optional[str], purpose: str, model: str, input_data: Any = None,
) -> Iterator[Callable[[Any], None]]:
    """Wrap ONE setup-time LLM call (cadence gen/revise, eval-plugin/rubric
    gen) in a Langfuse `generation` observation, and record its cost into the
    setup-cost sidecar. Usage:

        with trace_call(token=token, purpose="generate_cadence",
                         model=model, input_data=messages) as finish:
            resp = await client.chat.completions.create(...)
            finish(resp)

    `finish(resp)` reads `resp.usage` (raw OpenAI SDK response shape),
    computes cost via the SAME per-model YAML pricing table the live
    interview uses (`engine.brain.llm.pricing.compute_cost`), updates the
    Langfuse observation, and calls `record()` above.

    Deliberately does NOT go through `apply_llm_result` — that helper also
    writes into the LIVE `cost_tracker` map keyed by the same token, which
    would leak setup costs into the interview's own "Cost by model" table
    (see module docstring). This function's Langfuse trace still groups
    under the same `session_id=token`, so "View in Langfuse" shows the full
    story end-to-end — only the LOCAL cost rollup is kept separate.

    Best-effort throughout: a tracing/pricing failure never raises — the
    caller's actual cadence/eval-plugin work must never fail because of
    this. Safe to call even when Langfuse is disabled (`observe_llm` yields
    a no-op observation) or `token` is None (falls back to a
    Langfuse-only-grouping id; `record()` itself no-ops without a token)."""
    from engine.brain.llm.pricing import compute_cost
    from engine.brain.observability.langfuse_client import observe_llm

    session_id = token or "unscheduled"
    with observe_llm(
        agent=f"cadence.{purpose}", model=model, session_id=session_id,
        input_data=input_data, metadata={"purpose": purpose},
    ) as obs:
        def finish(resp: Any) -> None:
            try:
                usage = getattr(resp, "usage", None)
                tokens_in = getattr(usage, "prompt_tokens", None) if usage else None
                tokens_out = getattr(usage, "completion_tokens", None) if usage else None
                cached = 0
                details = getattr(usage, "prompt_tokens_details", None) if usage else None
                if details is not None:
                    cached = getattr(details, "cached_tokens", 0) or 0

                bd = None
                try:
                    bd = compute_cost(
                        model, tokens_in=tokens_in, tokens_out=tokens_out,
                        tokens_cached=cached, tokens_cache_write=0,
                    )
                except Exception as e:
                    logger.debug("[setup_cost_tracker] compute_cost failed: %s", e)
                cost_usd = bd.total if bd is not None else None

                try:
                    update_kwargs: dict[str, Any] = {}
                    usage_details: dict[str, int] = {}
                    if tokens_in is not None:
                        usage_details["input"] = int(tokens_in)
                    if tokens_out is not None:
                        usage_details["output"] = int(tokens_out)
                    if cached:
                        usage_details["input_cached"] = int(cached)
                    if usage_details:
                        update_kwargs["usage_details"] = usage_details
                    if bd is not None:
                        update_kwargs["cost_details"] = bd.as_langfuse_cost_details()
                    if update_kwargs:
                        obs.update(**update_kwargs)
                except Exception as e:
                    logger.debug("[setup_cost_tracker] langfuse update failed: %s", e)

                record(
                    token=token, model=model, purpose=purpose,
                    tokens_in=tokens_in, tokens_out=tokens_out,
                    tokens_cached=cached, cost_usd=cost_usd,
                )
            except Exception as e:
                logger.debug("[setup_cost_tracker] finish() failed: %s", e)

        yield finish
