"""app/ — FastAPI composition root for the Interview Agent.

A small FastAPI app that lets a non-technical operator schedule interviews,
review/edit the auto-generated cadence YAML, hand the candidate an access
link, and browse past sessions with highlighted event logs.

Companion to the existing `orchestrator_new.live_main` CLI: the admin app
DOES NOT re-implement the interview runtime. It only manages SQLite metadata,
saves uploaded files, and spawns `python -m orchestrator_new.live_main
--scheduled-token <uuid>` in a new terminal window when the admin approves
a cadence.

Entry point: `python -m uvicorn admin.main:app` — but use `run_app.bat` /
`run_app.sh` at the repo root, which also boots Stream A first.
"""
