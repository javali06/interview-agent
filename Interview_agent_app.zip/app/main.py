"""FastAPI app for the admin scheduler UI.

Routes:
    GET  /                                  → redirect to dashboard / login
    GET  /admin/login                       → login form
    POST /admin/login                       → validate, set cookie
    POST /admin/logout                      → clear cookie
    GET  /admin/dashboard                   → list scheduled + past sessions
    GET  /admin/schedule                    → new-session form
    POST /admin/schedule                    → save uploads, generate cadence,
                                              redirect to /cadence review
    GET  /admin/schedule/{token}/cadence    → cadence textarea + validate +
                                              approve buttons
    POST /api/cadence/validate              → JSON {ok, error}
    POST /admin/schedule/{token}/approve    → persist cadence, spawn
                                              orchestrator, show candidate link
    GET  /admin/sessions/{token}            → highlighted event log
    GET  /candidate                         → token → 302 to orchestrator UI
"""
from __future__ import annotations

import logging
import os
import random
import re
from pathlib import Path
from typing import Optional
from urllib.parse import urlencode

from dotenv import load_dotenv
from fastapi import (
    Cookie,
    Depends,
    FastAPI,
    File,
    Form,
    HTTPException,
    Request,
    Response,
    UploadFile,
)
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

from app import auth, db, event_viewer, sessions, spawner
from app.cadence_service import (
    append_coding_phase,
    append_essay_phase,
    append_scenario_analysis_phase,
    append_written_phase,
    backfill_coding_in_yaml,
    remove_coding_phase,
    remove_scenario_analysis_phase,
    revise_cadence_conversational,
    set_coding_phase,
    update_scenario_analysis_phase,
    update_written_phase,
    validate_cadence_yaml,
)
from app.cadence_service import CONTEXT_TRIGGER_TERMS as _REVISE_CONTEXT_TERMS
from app.evaluation_service import (
    build_coding_performance,
    load_evaluation,
)
# Dispatcher: routes to the v2 plugin pipeline when EVAL_PLUGINS_ENABLED, else
# the v1 single-pass evaluator. Aliased so the evaluate/regenerate/revise
# routes stay flag-agnostic.
from app.plugin_evaluation import run_evaluation as generate_evaluation
from app.constants import POOL_SOURCE_BUILTIN
from app.paths import REPO_ROOT, SESSIONS_DIR, ensure_dirs, session_dir
from engine.brain.cadence import question_types as _qt

# Load .env BEFORE anything reads os.environ
load_dotenv(REPO_ROOT / ".env")

logging.basicConfig(
    level=os.environ.get("LOG_LEVEL", "INFO").upper(),
    format="%(asctime)s %(levelname)s %(name)s %(message)s",
)
# Quiet the Azure SDK's per-request HTTP logging (Blob/Queue) — INFO-level noise.
logging.getLogger("azure").setLevel(os.environ.get("AZURE_LOG_LEVEL", "WARNING"))
logger = logging.getLogger(__name__)

ADMIN_DIR = Path(__file__).resolve().parent
_jinja_templates = Jinja2Templates(directory=str(ADMIN_DIR / "templates"))

# Cache-bust admin.css / admin.js with the file's mtime. Browsers strongly
# cache static assets; without this, a deploy ships new HTML referencing
# the same `/admin/static/admin.js` URL the browser already has cached —
# users get the new page wired up to yesterday's JS and tabs go dead.
# The image is rebuilt on every deploy → mtime changes → new URL → fresh
# fetch. One value covers both files since they ship together.
ASSET_VERSION = str(int((ADMIN_DIR / "static" / "admin.js").stat().st_mtime))
_jinja_templates.env.globals["asset_v"] = ASSET_VERSION


class _TemplatesShim:
    """Adapter so existing `templates.TemplateResponse(name, {"request": req, ...})`
    calls keep working under Starlette >= 0.46 (new signature is
    `TemplateResponse(request, name, context)`). Detects the old form by
    sniffing whether the first positional arg is a string or a Request."""

    def TemplateResponse(self, *args, **kwargs):
        # New-style: (request, name, context) — pass through unchanged.
        # Old-style: (name, context) where context contains "request".
        if args and isinstance(args[0], str):
            name = args[0]
            context = args[1] if len(args) > 1 else (kwargs.pop("context", None) or {})
            request = context.pop("request", None) or kwargs.pop("request", None)
            if request is None:
                raise RuntimeError("TemplateResponse called without a request")
            return _jinja_templates.TemplateResponse(request, name, context, **kwargs)
        return _jinja_templates.TemplateResponse(*args, **kwargs)


templates = _TemplatesShim()

app = FastAPI(title="Interview Agent Admin")


# ── least privilege for a person with no roles ───────────────────────────
# Signing in and being allowed to DO something are different, and until Entra
# they were effectively the same: the only ways in were one shared password and
# a dev switch that is off in production, so "signed in" meant "an admin who
# was given the password". Microsoft sign-in breaks that — ANY Centific
# employee can now authenticate — while most routes still ask only
# `auth.get_current_user(request) is not None` ("is anyone signed in"), inline
# and in 20-odd places. Only `app/question_pool_routes.py` checks permissions.
#
# So a brand-new employee with no roles could reach the dashboard, the
# interview list, transcripts, evaluations and the Shortlist's resumes — real
# candidate data — purely by signing in.
#
# ONE middleware rather than a dependency on each route: the checks are
# scattered and inline, so anything per-route can be forgotten by the next
# person, and forgetting fails OPEN. This cannot be forgotten.
#
# Two rules live here, because both are easy to forget on the next route:
# a person with no grants at all is refused, and a person who has some other
# grant still needs the interview permission to open an interview page.
# Question pools and Access check their own permission on the route.
# The shared password login signs in as an admin account. An older cookie
# with no user id has nothing to read and is left alone, so those routes
# keep working.

# Surfaces a grantless person must still reach: to be told they have no access,
# to sign out, and to try again. Candidate routes are here because a candidate
# is not signed in at all — their link is the credential.
_NO_GRANT_ALLOWED = (
    "/auth/", "/api/auth/", "/api/me", "/api/login", "/api/logout",
    "/admin/login", "/admin/logout",
    "/app", "/candidate", "/ws/", "/text/", "/healthz", "/metrics", "/favicon",
)


@app.middleware("http")
async def _require_some_grant(request: Request, call_next):
    """Refuse a signed-in person who holds no permissions at all."""
    path = request.url.path
    if path.startswith(_NO_GRANT_ALLOWED):
        return await call_next(request)
    try:
        from app import rbac

        user_id = rbac.current_user_id(request)
        # None = nobody signed in, or the legacy shared login. Neither is this
        # rule's business: the first is handled by each route's own auth check,
        # the second is the fallback door and is removed separately.
        if user_id is not None and not rbac.grants_for(user_id):
            logger.info("[access] %s has no roles — refused %s", user_id, path)
            return JSONResponse(
                {"error": "no_access",
                 "detail": "Your account has no access yet. Ask an administrator "
                           "to give you a role."},
                status_code=403,
            )
        needed = rbac.interview_permission(request.method, path)
        if needed and user_id is not None and not rbac.has_permission(user_id, needed):
            logger.info("[access] %s lacks %s — refused %s", user_id, needed, path)
            return JSONResponse(
                {"error": "forbidden", "detail": f"missing permission: {needed}"},
                status_code=403,
            )
    except Exception as e:      # never let this gate take the app down
        logger.warning("[access] grant check failed, allowing: %s", e)
    return await call_next(request)
app.mount("/admin/static", StaticFiles(directory=str(ADMIN_DIR / "static")), name="static")


# ── lifecycle ────────────────────────────────────────────────────────────


@app.on_event("startup")
def _on_startup() -> None:
    ensure_dirs()
    db.init_db()
    logger.info("[admin] SQLite at %s, sessions dir %s", db.DB_PATH, SESSIONS_DIR)
    # Access-control seed: teams, roles, the permission grid, the default
    # approval chain, and the accounts we sign in as until Entra lands.
    # Best-effort — a seed problem must not stop the app booting, and the
    # tables it writes are additive so a partial seed is re-run next start.
    try:
        from app.rbac_seed import seed_rbac

        seed_rbac()
    except Exception:
        logger.exception("[admin] RBAC seed failed")


# ── auth helpers ─────────────────────────────────────────────────────────


def _require_user_or_redirect(request: Request) -> Optional[Response]:
    """Return a RedirectResponse if the user is not logged in, else None."""
    if auth.get_current_user(request) is None:
        return RedirectResponse(url="/admin/login", status_code=302)
    return None


def _api_require_user(request: Request) -> None:
    """FastAPI dependency for JSON API routers: 401 if not authenticated.
    (HTML routes use _require_user_or_redirect; APIs should not redirect.)"""
    if auth.get_current_user(request) is None:
        raise HTTPException(status_code=401, detail="unauthorized")


# ── feature routers (mounted behind admin auth) ──────────────────────────
# Shortlist (resume→role scoring) lives in features/shortlist; its router is
# auth-gated here so the module stays decoupled from admin/auth. Lazy import
# so a stray import error in the feature can't take down the whole admin app.
try:
    from features.shortlist.routes import router as _shortlist_router

    app.include_router(_shortlist_router, dependencies=[Depends(_api_require_user)])
    logger.info("[admin] mounted shortlist router at /api/shortlist")
except Exception:  # pragma: no cover - defensive
    logger.exception("[admin] shortlist router not mounted")

try:
    from features.shortlist.role_routes import router as _roles_router

    app.include_router(_roles_router, dependencies=[Depends(_api_require_user)])
    logger.info("[admin] mounted roles router at /api/roles")
except Exception:  # pragma: no cover - defensive
    logger.exception("[admin] roles router not mounted")

try:
    from app.question_pool_routes import router as _pools_router

    app.include_router(_pools_router, dependencies=[Depends(_api_require_user)])
    logger.info("[admin] mounted question-pools router at /api/question-pools")
except Exception:  # pragma: no cover - defensive
    logger.exception("[admin] question-pools router not mounted")

try:
    from app.access_routes import router as _access_router

    app.include_router(_access_router, dependencies=[Depends(_api_require_user)])
    logger.info("[admin] mounted access router at /api/access")
except Exception:  # pragma: no cover - defensive
    logger.exception("[admin] access router not mounted")


# ── root ─────────────────────────────────────────────────────────────────


@app.get("/")
def root(request: Request) -> Response:
    # The React SPA at /app is the default front door; it gates auth itself.
    return RedirectResponse(url="/app", status_code=302)


# ── login / logout ───────────────────────────────────────────────────────


@app.get("/admin/login", response_class=HTMLResponse)
def login_form(request: Request, error: Optional[str] = None) -> Response:
    return templates.TemplateResponse("login.html", {"request": request, "error": error})


@app.post("/admin/login")
def login_submit(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
) -> Response:
    expected_user = os.environ.get("ADMIN_USERNAME", "admin")
    if username.strip() != expected_user or not auth.verify_password(password):
        return templates.TemplateResponse(
            "login.html",
            {"request": request, "error": "Invalid username or password."},
            status_code=401,
        )
    token = _shared_admin_cookie(username)
    resp = RedirectResponse(url="/admin/dashboard", status_code=302)
    resp.set_cookie(
        key=auth.COOKIE_NAME,
        value=token,
        max_age=auth.COOKIE_MAX_AGE_S,
        httponly=True,
        samesite="lax",
    )
    return resp


@app.post("/admin/logout")
def logout() -> Response:
    resp = RedirectResponse(url="/admin/login", status_code=302)
    resp.delete_cookie(auth.COOKIE_NAME)
    return resp


# ── JSON auth (for the React SPA) ─────────────────────────────────────────
# Same cookie + credentials as the Jinja form login above, but JSON in/out so
# the SPA can log in, check session, and log out without HTML redirects. One
# session cookie for both UIs during the migration.


class _LoginBody(BaseModel):
    username: str
    password: str


@app.get("/api/me")
def api_me(request: Request) -> JSONResponse:
    user = auth.get_current_user(request)
    if user is None:
        return JSONResponse({"authenticated": False}, status_code=401)
    return JSONResponse({"authenticated": True, "user": user})


def _named_session_cookie(user: dict) -> str:
    """Cookie for a real app_users row, and a stamp of when they signed in."""
    from datetime import datetime, timezone as _tz

    from db.engine import session_scope
    from db.models import AppUser

    with session_scope() as s:
        row = s.get(AppUser, user["id"])
        if row is not None:
            row.last_login_at = datetime.now(_tz.utc)
    return auth.issue_cookie(user["email"], user_id=user["id"])


def _session_response(body: dict, token: str) -> JSONResponse:
    resp = JSONResponse(body)
    resp.set_cookie(
        key=auth.COOKIE_NAME,
        value=token,
        max_age=auth.COOKIE_MAX_AGE_S,
        httponly=True,
        samesite="lax",
    )
    return resp


def _shared_admin_cookie(username: str) -> str:
    """Session cookie for the shared username/password login. It signs in as a
    real account holding `admin` on every team (`rbac_seed.shared_admin_user_id`),
    so permission checks see a person: question pools, approvals and the Access
    page all work. A DB failure falls back to the old id-less cookie rather than
    blocking sign-in."""
    from app import rbac
    from app.rbac_seed import shared_admin_user_id

    try:
        uid = shared_admin_user_id(username)
        user = rbac.user_by_email(username) if uid is not None else None
        if user is not None:
            return _named_session_cookie(user)
    except Exception as e:
        logger.warning("[auth] shared admin account unavailable: %r", e)
    return auth.issue_cookie(username.strip())


@app.post("/api/login")
def api_login(body: _LoginBody) -> JSONResponse:
    """The shared username/password login. Everyone else signs in with Microsoft.

    There is no other password path: the seeded people have no passwords, and
    the passwordless development sign-in was removed."""
    username = body.username.strip()
    expected_user = os.environ.get("ADMIN_USERNAME", "admin")
    if username != expected_user or not auth.verify_password(body.password):
        return JSONResponse({"ok": False, "error": "Invalid username or password."}, status_code=401)
    return _session_response({"ok": True, "user": username}, _shared_admin_cookie(username))


@app.post("/api/logout")
def api_logout() -> JSONResponse:
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(auth.COOKIE_NAME)
    return resp


# ── Microsoft sign-in (Entra ID) ──────────────────────────────────────────
# Three routes, and only the middle one does any work. All the Microsoft-facing
# code is in app/entra_auth.py; these just carry cookies and redirects.
#
# They 404 when no app registration is configured, so a deploy without
# credentials is unchanged.


@app.get("/auth/login")
def auth_login() -> Response:
    """Send the person to Microsoft.

    Renders nothing: it exists to build the sign-in URL (with a fresh
    state+nonce) and bounce the browser there.
    """
    from app import entra_auth

    cfg = entra_auth.settings()
    if cfg is None or not entra_auth.is_configured():
        raise HTTPException(status_code=404, detail="not found")
    url, flow_token = entra_auth.start_login(cfg)
    resp = RedirectResponse(url=url, status_code=302)
    # Parked for the round trip only. `secure` follows the redirect_uri rather
    # than a fixed value: a cookie marked secure is never sent over plain HTTP,
    # which would silently break local development on http://localhost.
    resp.set_cookie(
        key=entra_auth.FLOW_COOKIE,
        value=flow_token,
        max_age=entra_auth.FLOW_MAX_AGE_S,
        httponly=True,
        samesite="lax",
        secure=cfg.redirect_uri.startswith("https://"),
    )
    return resp


@app.get("/auth/callback")
def auth_callback(request: Request) -> Response:
    """Microsoft sends the person back here holding a one-time code.

    Everything of substance happens in this handler: verify the sign-in is one
    we started, trade the code for an identity (server to server, proving
    ourselves with the client secret), match the person, and issue OUR session.
    After this Microsoft is out of the picture — the existing roles and
    permissions run every later request.
    """
    from app import entra_auth

    cfg = entra_auth.settings()
    if cfg is None or not entra_auth.is_configured():
        raise HTTPException(status_code=404, detail="not found")

    # Microsoft reports a refusal (consent declined, blocked by a policy) by
    # redirecting here with an error rather than a code.
    if request.query_params.get("error"):
        logger.warning(
            "[entra] sign-in refused: %s — %s",
            request.query_params.get("error"),
            (request.query_params.get("error_description") or "")[:300],
        )
        return _auth_failed("Microsoft did not complete that sign-in.")

    code = request.query_params.get("code") or ""
    if not code:
        return _auth_failed("That sign-in link was incomplete.")

    try:
        who = entra_auth.finish_login(
            cfg,
            code=code,
            state=request.query_params.get("state") or "",
            flow_token=request.cookies.get(entra_auth.FLOW_COOKIE) or "",
        )
    except entra_auth.EntraError as e:
        return _auth_failed(str(e))

    person = entra_auth.find_or_create_user(who["oid"], who["email"], who["name"])
    if person is None:
        return _auth_failed("That account is not active on this platform.")

    resp = RedirectResponse(url="/app/", status_code=302)
    resp.delete_cookie(entra_auth.FLOW_COOKIE)
    # The platform's own session cookie — `uid` is what every permission
    # check reads, so nothing downstream knows or cares how the person signed in.
    resp.set_cookie(
        key=auth.COOKIE_NAME,
        value=auth.issue_cookie(person["email"], user_id=person["id"]),
        max_age=auth.COOKIE_MAX_AGE_S,
        httponly=True,
        samesite="lax",
        secure=cfg.redirect_uri.startswith("https://"),
    )
    logger.info("[entra] signed in %s", person["email"])
    return resp


@app.get("/auth/logout")
def auth_logout() -> Response:
    """Front-channel logout: MICROSOFT telling us this person signed out
    elsewhere (Outlook, Teams, another tab), so we should end their session too.

    Not the platform's own Sign out button — that is `POST /api/logout`, which
    deletes the same cookie and involves Microsoft not at all. This route is
    called by Microsoft's servers, not by a person, so it renders nothing.
    """
    resp = Response(status_code=200)
    resp.delete_cookie(auth.COOKIE_NAME)
    return resp


def _auth_failed(message: str) -> Response:
    """Send a failed sign-in back to the login page with something readable.

    A sign-in can fail for reasons the person can act on (a stale tab, the
    wrong account), so it must not surface as a raw 500.
    """
    from urllib.parse import quote

    return RedirectResponse(url=f"/app/login?auth_error={quote(message)}", status_code=302)


# ── sign-in methods ─────────────────────────────────────────────────────────


@app.get("/api/auth/methods")
def api_auth_methods() -> JSONResponse:
    """Which sign-in methods this deploy actually offers.

    The login page renders from this instead of guessing: a box with no app
    registration shows no Microsoft button. Public on purpose — it reveals nothing a person could not learn by
    clicking, and the page needs it before anyone is signed in.
    """
    from app import entra_auth

    return JSONResponse({"microsoft": entra_auth.is_configured()})


@app.get("/api/me/permissions")
def api_me_permissions(request: Request) -> JSONResponse:
    """Who is signed in and what they hold — what the SPA renders its menu
    from. The server enforces regardless; hiding a menu item is convenience,
    not security.

    A legacy shared-login session has no `app_users` row, so it reports no
    permissions rather than pretending to be somebody."""
    from app import rbac

    user_id = rbac.current_user_id(request)
    if user_id is None:
        legacy = auth.get_current_user(request)
        if legacy is None:
            return JSONResponse({"authenticated": False}, status_code=401)
        return JSONResponse(
            {"authenticated": True, "legacy": True, "user": legacy, "permissions": {}}
        )
    info = rbac.describe_user(user_id)
    if info is None:
        return JSONResponse({"authenticated": False}, status_code=401)
    return JSONResponse({"authenticated": True, "legacy": False, **info})


# ── dashboard JSON (for the React SPA) ─────────────────────────────────────
# These mirror the Jinja /admin/dashboard data + the archive/delete actions,
# but return JSON so the React console can render the sessions table. The
# HTML routes stay in place during the migration; both hit the same db layer.


@app.get("/api/sessions")
def api_sessions(request: Request) -> JSONResponse:
    if auth.get_current_user(request) is None:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    return JSONResponse({
        "rows": db.list_recent(limit=100),
        # Scaled system runs many interviews at once — report a LIVE count, not
        # the old single-at-a-time "active" row (which implied exclusivity).
        "active_count": db.count_active(),
        "candidate_link_base": _candidate_link_base(request),
    })


@app.post("/api/sessions/{token}/archive")
def api_session_archive(request: Request, token: str) -> JSONResponse:
    """Soft-delete twin of /admin/sessions/{token}/archive — see that route."""
    if auth.get_current_user(request) is None:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    row = db.get(token)
    if row is None:
        return JSONResponse({"error": "session not found"}, status_code=404)
    db.archive(token)
    logger.info(
        "[admin] (api) archived session token=%s candidate=%r prev_status=%s",
        token, row["candidate_name"], row["status"],
    )
    return JSONResponse({"ok": True})


@app.delete("/api/sessions/{token}")
async def api_session_delete(request: Request, token: str) -> JSONResponse:
    """Hard-delete twin of /admin/sessions/{token}/delete — drops the row AND
    rm -rf's the session_dir. Irreversible."""
    import shutil
    if auth.get_current_user(request) is None:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    row = db.get(token)
    if row is None:
        return JSONResponse({"error": "session not found"}, status_code=404)
    if row["status"] == "in_progress":
        await _end_live_session(token, reason="admin_delete")
    sdir = session_dir(token)
    db.delete(token)
    if sdir.is_dir():
        try:
            shutil.rmtree(sdir)
        except Exception as e:
            logger.warning("[admin] (api) delete: rm -rf %s failed: %s", sdir, e)
    logger.info(
        "[admin] (api) deleted session token=%s candidate=%r dir=%s",
        token, row["candidate_name"], sdir,
    )
    return JSONResponse({"ok": True})


# ── dashboard ────────────────────────────────────────────────────────────


@app.get("/admin/dashboard")
def dashboard(request: Request, error: Optional[str] = None) -> Response:
    # The console is the React SPA now. This route stays (POST-action handlers
    # still redirect here) but bounces to the SPA, which handles auth + render.
    return RedirectResponse(url="/app/dashboard", status_code=307)


# ── schedule form ────────────────────────────────────────────────────────


@app.get("/admin/schedule")
def schedule_form(
    request: Request,
    error: Optional[str] = None,
    token: Optional[str] = None,
) -> Response:
    """The schedule form is the React SPA now — bounce to it (preserving the
    edit token if present). The SPA's edit prefill comes from /api/schedule/{t}/edit."""
    target = f"/app/schedule?token={token}" if token else "/app/schedule"
    return RedirectResponse(url=target, status_code=307)


@app.post("/admin/schedule")
async def schedule_submit(
    request: Request,
    candidate_name: str = Form(...),
    role: str = Form(...),
    candidate_email: str = Form(""),
    jd_text: str = Form(""),
    jd_upload: UploadFile = File(None),
    resume_upload: UploadFile = File(None),
    cadence_requirements_text: str = Form(""),
    cadence_requirements_upload: UploadFile = File(None),
    token: Optional[str] = Form(None),
    regenerate_cadence: Optional[str] = Form(None),
    record_enabled: Optional[str] = Form(None),
    modality: Optional[str] = Form(None),
) -> Response:
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir

    editing = bool(token)
    if not candidate_name.strip() or not role.strip():
        return templates.TemplateResponse(
            "schedule.html",
            {
                "request": request,
                "error": "Candidate name and role are required.",
                "existing": (db.get(token) if editing else None),
            },
            status_code=400,
        )
    # Resume is required on CREATE; on EDIT the existing file is reused
    # when no new upload is provided.
    if not editing and (not resume_upload or not resume_upload.filename):
        return templates.TemplateResponse(
            "schedule.html",
            {"request": request, "error": "Resume file is required.", "existing": None},
            status_code=400,
        )

    form = sessions.ScheduleForm(
        candidate_name=candidate_name.strip(),
        role=role.strip(),
        candidate_email=candidate_email.strip(),
        jd_text=jd_text,
        jd_upload=jd_upload if jd_upload and jd_upload.filename else None,
        resume_upload=resume_upload,
        cadence_requirements_text=cadence_requirements_text,
        cadence_requirements_upload=(
            cadence_requirements_upload
            if cadence_requirements_upload and cadence_requirements_upload.filename
            else None
        ),
        record_enabled=(record_enabled == "1"),
        modality=(modality or "voice"),
    )

    if editing:
        existing = db.get(token)
        if existing is None:
            raise HTTPException(404, "session not found")
        if existing["status"] in ("in_progress", "completed"):
            return RedirectResponse(
                url=(
                    "/admin/dashboard?error="
                    + "Cannot+edit:+candidate+has+already+started+this+interview."
                ),
                status_code=303,
            )
        try:
            await sessions.update_draft(
                token,
                form,
                regenerate_cadence=bool(regenerate_cadence),
            )
        except Exception as e:
            logger.exception("[admin] update_draft failed")
            return templates.TemplateResponse(
                "schedule.html",
                {
                    "request": request,
                    "error": f"Failed to update session: {e}",
                    "existing": db.get(token),
                },
                status_code=500,
            )
        return RedirectResponse(url=f"/admin/schedule/{token}/cadence", status_code=303)

    try:
        token, _yaml = await sessions.create_draft(form)
    except Exception as e:
        logger.exception("[admin] create_draft failed")
        return templates.TemplateResponse(
            "schedule.html",
            {"request": request, "error": f"Failed to generate cadence: {e}", "existing": None},
            status_code=500,
        )

    return RedirectResponse(url=f"/admin/schedule/{token}/cadence", status_code=302)


@app.get("/api/schedule/{token}/edit")
def api_schedule_edit(request: Request, token: str) -> JSONResponse:
    """Prefill data for the React schedule form in edit mode."""
    if auth.get_current_user(request) is None:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    row = db.get(token)
    if row is None:
        return JSONResponse({"error": "session not found"}, status_code=404)
    if row["status"] in ("in_progress", "completed"):
        return JSONResponse(
            {"error": "Cannot edit: candidate has already started this interview."},
            status_code=409,
        )
    base = lambda p: os.path.basename(p) if p else None  # noqa: E731
    return JSONResponse({
        "candidate_name": row["candidate_name"],
        "role": row["role"],
        "candidate_email": row.get("candidate_email") or "",
        "jd_text": row["jd_text"] or "",
        "cadence_requirements_text": row["cadence_requirements_text"] or "",
        "resume_filename": base(row["resume_path"]),
        "jd_filename": base(row["jd_path"]),
        "cadence_requirements_filename": base(row["cadence_requirements_path"]),
        "status": row["status"],
        "record_enabled": bool(row["record_enabled"]),
        "modality": row.get("modality") or "voice",
    })


@app.post("/api/schedule")
async def api_schedule_submit(
    request: Request,
    candidate_name: str = Form(...),
    role: str = Form(...),
    candidate_email: str = Form(""),
    jd_text: str = Form(""),
    jd_upload: UploadFile = File(None),
    resume_upload: UploadFile = File(None),
    cadence_requirements_text: str = Form(""),
    cadence_requirements_upload: UploadFile = File(None),
    token: Optional[str] = Form(None),
    regenerate_cadence: Optional[str] = Form(None),
    record_enabled: Optional[str] = Form(None),
    modality: Optional[str] = Form(None),
) -> JSONResponse:
    """JSON twin of schedule_submit() — create or edit a draft (file uploads +
    LLM cadence generation), returning the token so the SPA can navigate to
    the cadence review screen. Same multipart contract as the Jinja form."""
    if auth.get_current_user(request) is None:
        return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)

    editing = bool(token)
    if not candidate_name.strip() or not role.strip():
        return JSONResponse(
            {"ok": False, "error": "Candidate name and role are required."}, status_code=400,
        )
    if not editing and (not resume_upload or not resume_upload.filename):
        return JSONResponse({"ok": False, "error": "Resume file is required."}, status_code=400)

    form = sessions.ScheduleForm(
        candidate_name=candidate_name.strip(),
        role=role.strip(),
        candidate_email=candidate_email.strip(),
        jd_text=jd_text,
        jd_upload=jd_upload if jd_upload and jd_upload.filename else None,
        resume_upload=resume_upload,
        cadence_requirements_text=cadence_requirements_text,
        cadence_requirements_upload=(
            cadence_requirements_upload
            if cadence_requirements_upload and cadence_requirements_upload.filename
            else None
        ),
        record_enabled=(record_enabled == "1"),
        modality=(modality or "voice"),
    )

    if editing:
        existing = db.get(token)
        if existing is None:
            return JSONResponse({"ok": False, "error": "session not found"}, status_code=404)
        if existing["status"] in ("in_progress", "completed"):
            return JSONResponse(
                {"ok": False, "error": "Cannot edit: candidate has already started this interview."},
                status_code=409,
            )
        try:
            await sessions.update_draft(token, form, regenerate_cadence=bool(regenerate_cadence))
        except Exception as e:
            logger.exception("[admin] (api) update_draft failed")
            return JSONResponse(
                {"ok": False, "error": f"Failed to update session: {e}"}, status_code=500,
            )
        return JSONResponse({"ok": True, "token": token})

    try:
        new_token, _yaml = await sessions.create_draft(form)
    except Exception as e:
        logger.exception("[admin] (api) create_draft failed")
        return JSONResponse(
            {"ok": False, "error": f"Failed to generate cadence: {e}"}, status_code=500,
        )
    return JSONResponse({"ok": True, "token": new_token})


# ── cadence review ──────────────────────────────────────────────────────


@app.get("/admin/schedule/{token}/cadence")
def cadence_review(request: Request, token: str) -> Response:
    # Cadence + rubric review is the React SPA now. This route stays
    # (schedule_submit + reopen redirect here) but bounces to the SPA, which
    # loads its context from /api/schedule/{token}/cadence + /api/rubric/{token}.
    return RedirectResponse(url=f"/app/schedule/{token}/cadence", status_code=307)


def _owning_role_public_id(row: dict) -> str:
    """The role this session is the cadence template for, if it is one."""
    if not row.get("is_template"):
        return ""
    try:
        from features.shortlist import role_store
        return (role_store.get_role_by_template_token(row["token"]) or {}).get("public_id", "")
    except Exception:
        return ""


@app.get("/api/schedule/{token}/cadence")
def api_cadence_review(request: Request, token: str) -> JSONResponse:
    """JSON page-context for the React cadence + rubric review screen —
    mirrors cadence_review()'s template context. The cadence customizer /
    validate / revise endpoints (/api/cadence/*) and rubric endpoints
    (/api/rubric/*) are already JSON and reused as-is by the SPA."""
    if auth.get_current_user(request) is None:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    row = db.get(token)
    if row is None:
        return JSONResponse({"error": "session not found"}, status_code=404)
    # A 'generating' draft has no cadence_yaml yet (the worker is producing it);
    # skip phase parsing so the SPA can poll this endpoint until status flips.
    phase_ids, _ = _phase_ids_from_yaml(row["cadence_yaml"]) if row["cadence_yaml"] else ([], None)
    # Shipped pools + whatever the admin authored (Blob). Both are addressed by
    # the same `pool_file` field on /customize — see _resolve_pool_data.
    pool_files = _list_pool_files()
    pool_topics = _pool_topics(pool_files)
    pool_labels: dict[str, str] = {n: n for n in (pool_files or [])}
    try:
        from app import question_pools as _qp
        for summary in _qp.list_pools():
            ref = summary["pool_id"]
            pool_files = (pool_files or []) + [ref]
            pool_topics[ref] = summary["topics"]
            # A generated id ("customer_support-a1b2c3") is not a label — the
            # dropdown shows the name the admin typed.
            pool_labels[ref] = summary["pool_name"]
    except Exception:
        logger.exception("[admin] could not list custom question pools")
    try:
        import features.eval as _rubric_mod
        rubric_enabled = _rubric_mod.is_enabled()
    except Exception:
        rubric_enabled = False
    return JSONResponse({
        "row": {
            "token": row["token"],
            "candidate_name": row["candidate_name"],
            "role": row["role"],
            "status": row["status"],
            "cadence_yaml": row["cadence_yaml"],
            # A role's cadence TEMPLATE, not somebody's interview: it is approved
            # rather than launched, so the page offers no candidate link and
            # sends the admin back to the role instead.
            "is_template": bool(row.get("is_template")),
        },
        # Scaled system runs many interviews concurrently — no single-active
        # exclusivity. Kept as constant falsy values for API back-compat.
        "active_blocker": False,
        "active": None,
        "role_public_id": _owning_role_public_id(row),
        "phase_ids": phase_ids,
        "default_phase_id": _pick_default_customize_phase(phase_ids),
        "pool_files": pool_files,
        "pool_dir_missing": pool_files is None,
        "pool_topics": pool_topics,
        "pool_labels": pool_labels,
        "default_topics": list(_DEFAULT_TOPICS),
        "rubric_enabled": rubric_enabled,
    })


class _ValidateBody(BaseModel):
    yaml: str


@app.post("/api/cadence/validate")
def cadence_validate(body: _ValidateBody) -> JSONResponse:
    ok, err = validate_cadence_yaml(body.yaml)
    return JSONResponse({"ok": ok, "error": err})


class _ReviseClarification(BaseModel):
    """One question the ROUTER agent asked on a previous turn, plus the admin's
    answer. The conversation is stateless server-side — the client replays the
    open threads it's answering, so any replica can serve any turn."""
    clause_id: str = ""
    text: str = ""
    question: str = ""
    answer: str = ""


class _ReviseBody(BaseModel):
    yaml: str
    # Empty when the admin is ONLY answering an outstanding clarification.
    feedback: str = ""
    # Optional: lets the revise LLM pull the candidate's resume + JD context when
    # the feedback references them (e.g. "ask about a project from the resume").
    token: Optional[str] = None
    clarifications: list[_ReviseClarification] = []


def _load_resume_text_for_revise(token: str, row: dict) -> str:
    """Best available resume text for a token: precomputed parsed.txt / summary.txt
    (from the resume_summary job), else parse the uploaded file on demand. "" if
    none."""
    rdir = session_dir(token) / "resume"
    for name in ("summary.txt", "parsed.txt"):
        fp = rdir / name
        try:
            if fp.is_file():
                text = fp.read_text(encoding="utf-8").strip()
                if text:
                    return text
        except Exception:
            pass
    resume_path = (row or {}).get("resume_path") or ""
    if not resume_path:
        return ""
    rp = Path(resume_path)
    if not rp.is_absolute():
        rp = session_dir(token) / resume_path
    if not rp.is_file():
        return ""
    try:
        from engine.orchestrator.resume_parser import parse_resume
        return (parse_resume(rp) or "").strip()
    except Exception as e:
        logger.warning("[revise] on-demand resume parse failed (%s): %s", token[:8], e)
        return ""


@app.post("/api/cadence/revise")
async def cadence_revise(body: _ReviseBody) -> JSONResponse:
    # When the ask references the resume/JD and we have a token, attach that
    # context so the LLM can ground questions in the candidate's real material.
    # Clarification ANSWERS count as part of the ask — "which phase?" → "the
    # resume deep-dive" is where the resume reference can first appear.
    ask_text = " ".join(
        [body.feedback] + [f"{c.text} {c.answer}" for c in body.clarifications]
    ).lower()
    context = ""
    if body.token and any(t in ask_text for t in _REVISE_CONTEXT_TERMS):
        row = db.get(body.token)
        if row is not None:
            parts: list[str] = []
            resume_text = _load_resume_text_for_revise(body.token, row)
            if resume_text:
                parts.append("# Candidate resume\n" + resume_text)
            jd_text = (row.get("jd_text") or "").strip()
            if jd_text:
                parts.append("# Job description\n" + jd_text)
            context = "\n\n".join(parts)
    try:
        # Multi-agent conversational path: ROUTER splits the ask into clauses
        # (per-phase / structure / needs-clarification / out-of-capability),
        # MODIFYING applies the resolved ones in parallel with only the phase
        # or metadata each needs, VALIDATING re-checks the result against the
        # admin's own words and retries what fell short. The full raw YAML is
        # sent ONLY as a last-resort fallback (unparseable cadence, router
        # failure, or a merged plan that won't validate).
        result = await revise_cadence_conversational(
            current_yaml=body.yaml, feedback=body.feedback,
            clarifications=[c.model_dump() for c in body.clarifications],
            context=context, token=body.token,
        )
    except ValueError as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    except Exception as e:
        logger.exception("[admin] cadence revise failed")
        return JSONResponse({"ok": False, "error": f"LLM error: {e}"}, status_code=500)
    return JSONResponse(result)


class _AddCodingBody(BaseModel):
    yaml: str


def _extend_rubric_after_cadence_change(token: str, new_yaml: str, role: str) -> None:
    """Side-effect: if a saved rubric exists, append heuristic sections for
    any newly-added cadence phase (coding_round / code_discussion etc.) so
    the rubric stays in lock-step with the cadence WITHOUT requiring the
    admin to click 'Regenerate'. Existing sections untouched. Silent
    no-op when no rubric file is present or anything goes wrong — the
    stale-rubric warning + Regenerate button remain the safety net."""
    try:
        import yaml as _yaml
        from features.eval import storage as _rubric_storage
        from features.eval.heuristic import extend_rubric_with_new_phases
        existing = _rubric_storage.load_rubric(token)
        if not existing:
            return
        cadence_dict = _yaml.safe_load(new_yaml)
        if not isinstance(cadence_dict, dict):
            return
        extended = extend_rubric_with_new_phases(existing, cadence_dict, role=role)
        if extended is not existing:  # any append happened
            _rubric_storage.save_rubric(token, extended)
    except Exception as e:
        logger.warning("[admin] rubric auto-extend failed: %s", e)


@app.post("/api/cadence/{token}/add_coding_phase")
async def cadence_add_coding(token: str, body: _AddCodingBody) -> JSONResponse:
    row = db.get(token)
    if not row:
        raise HTTPException(404, "session not found")
    try:
        revised = append_coding_phase(body.yaml, row["role"])
    except Exception as e:
        logger.exception("[admin] add_coding_phase failed")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    _extend_rubric_after_cadence_change(token, revised, row["role"])
    return JSONResponse({"ok": True, "yaml": revised})


class _WrittenQuestionBody(BaseModel):
    """One written question inside the phase. `id` is echoed back when EDITING an
    existing question so its id (referenced by events.jsonl / eval segments)
    survives; omit it for a new question. The material fields are the
    question-scoped ones in question_types — a type that needs none just omits
    them, so a new question type needs no new field here."""

    id: str | None = None
    prompt: str = ""
    char_limit: int | None = None
    word_limit: int | None = None     # legacy essays only (word-counted)
    time_limit_s: int | None = None   # None → untimed (submit when ready)
    source_text: str | None = None
    audio_asset: str | None = None
    image_asset: str | None = None
    # The language pair is question-scoped (one phase may mix pairs). These MUST
    # be listed: pydantic drops undeclared keys silently, so omitting them made
    # the picked languages vanish between the browser and the builder and the
    # phase then failed validation with "needs source language" even though the
    # admin had chosen one. tests/test_text_interview.py pins every
    # question-scoped field in the registry against this model for that reason.
    source_language: str | None = None
    target_language: str | None = None
    # transcription: exact reference transcript (str). translation /
    # image_description: accepted reference answers (list[str]). Server-side
    # only — never returned to the candidate.
    ground_truth: str | list[str] | None = None


# Fallback character limit when a (legacy, single-question) caller sends no limit
# at all — matches the Add Phase form's own default.
_DEFAULT_CHAR_LIMIT = 1500


class _AddPhaseBody(BaseModel):
    yaml: str
    question_type: str = _qt.DEFAULT_QUESTION_TYPE
    name: str = ""
    # Phase-scoped config (the language pair) — shared by every question.
    source_language: str = ""
    target_language: str = ""
    # None = the field wasn't sent at all → the legacy single-question shape
    # below is used. An explicit [] is an authoring error, not a legacy call.
    questions: list[_WrittenQuestionBody] | None = None
    # ── legacy single-question shape (a cached SPA bundle still posts this) ──
    prompt: str = ""
    char_limit: int | None = None
    word_limit: int | None = None
    time_limit_s: int | None = None
    config: dict[str, str] = {}


class _UpdatePhaseBody(BaseModel):
    yaml: str
    phase_id: str
    question_type: str = ""            # blank → keep the phase's current type
    source_language: str = ""
    target_language: str = ""
    questions: list[_WrittenQuestionBody] = []


@app.get("/api/cadence/question-types")
def cadence_question_types(request: Request) -> JSONResponse:
    """The question-type catalog the authoring UI renders from: each type's
    fields (in order), the language list, and the upload rules. ONE definition
    (engine/brain/cadence/question_types.py) drives the form, the backend
    validation, and the candidate renderer."""
    if auth.get_current_user(request) is None:
        return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)
    return JSONResponse(_qt.api_catalog())


def _written_questions(items: list[_WrittenQuestionBody]) -> list[dict]:
    """Request bodies → the plain dicts the builder takes, dropping unset keys so
    a missing field falls back to the phase default rather than overriding it
    with null."""
    return [
        {k: v for k, v in q.model_dump().items() if v is not None}
        for q in items
    ]


@app.post("/api/cadence/{token}/add_phase")
async def cadence_add_phase(token: str, body: _AddPhaseBody) -> JSONResponse:
    """Insert a written-response phase into a TEXT interview's cadence — the text
    counterpart to add_coding_phase. `question_type` selects what the candidate is
    given (a question, an audio clip, a passage to translate, an image) and the
    phase holds one or more questions of that type, each with its own material,
    character limit and (optional) countdown."""
    row = db.get(token)
    if not row:
        raise HTTPException(404, "session not found")
    try:
        char_limit = body.char_limit
        if body.questions is None and char_limit is None and body.word_limit is None:
            char_limit = _DEFAULT_CHAR_LIMIT
        # Filled by the builder with what it actually did — a NEW phase, or the
        # questions folded into an existing phase of the same type (adding the
        # same phase twice means "more questions", not a duplicate phase). The
        # SPA needs this to say which happened; a merge adds no phase, so
        # otherwise the admin sees nothing appear.
        outcome: dict = {}
        revised = append_written_phase(
            body.yaml,
            outcome=outcome,
            question_type=body.question_type,
            questions=(None if body.questions is None
                       else _written_questions(body.questions)),
            name=body.name,
            source_language=body.source_language,
            target_language=body.target_language,
            # legacy single-question fields (ignored when `questions` is sent)
            prompt=body.prompt,
            char_limit=char_limit,
            word_limit=body.word_limit,
            time_limit_s=body.time_limit_s,
            config=body.config,
        )
    except Exception as e:
        logger.exception("[admin] add_phase failed")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    _extend_rubric_after_cadence_change(token, revised, row["role"])
    return JSONResponse({"ok": True, "yaml": revised, **outcome})


@app.post("/api/cadence/{token}/update_phase")
async def cadence_update_phase(token: str, body: _UpdatePhaseBody) -> JSONResponse:
    """Replace an existing written-response phase's questions (add / edit /
    delete). The phase KEEPS its id — that id is what the evaluation plan and the
    events/eval segments key off — and any question id echoed back keeps its own
    for the same reason."""
    row = db.get(token)
    if not row:
        raise HTTPException(404, "session not found")
    try:
        revised = update_written_phase(
            body.yaml,
            body.phase_id,
            question_type=body.question_type,
            questions=_written_questions(body.questions),
            source_language=body.source_language,
            target_language=body.target_language,
        )
    except Exception as e:
        logger.exception("[admin] update_phase failed")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    _extend_rubric_after_cadence_change(token, revised, row["role"])
    return JSONResponse({"ok": True, "yaml": revised})


class _AddEssayBody(BaseModel):
    yaml: str
    prompt: str
    word_limit: int = 300
    time_limit_s: int | None = None   # None → untimed (submit when ready)
    name: str = ""


@app.post("/api/cadence/{token}/add_essay_phase")
async def cadence_add_essay(token: str, body: _AddEssayBody) -> JSONResponse:
    """LEGACY route, superseded by /add_phase. Kept because the SPA's hashed
    bundles are cached immutably — a browser still running the pre-Add-Phase JS
    must keep working. Word-limited comprehensive written response."""
    row = db.get(token)
    if not row:
        raise HTTPException(404, "session not found")
    try:
        revised = append_essay_phase(
            body.yaml, body.prompt, body.word_limit, body.time_limit_s, body.name,
        )
    except Exception as e:
        logger.exception("[admin] add_essay_phase failed")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    _extend_rubric_after_cadence_change(token, revised, row["role"])
    return JSONResponse({"ok": True, "yaml": revised})


# ── phase assets (transcription audio / image-description image) ─────────
# Stored beside the interview's other artifacts at `<token>/phase_assets/<name>`
# through the existing blob mirror (disk fallback when BLOB_ENABLED=0), and
# referenced from cadence.yaml by NAME only — the YAML never carries bytes.


def _safe_asset_name(name: Optional[str], default: str) -> str:
    """A filename safe to use as a blob path segment: the shared sanitizer plus
    a hard stop on path traversal (`.` / `..` / separators). Applied on BOTH
    upload and download so the two always agree on the stored name."""
    safe = sessions._safe_filename(name, default).replace(" ", "_")
    safe = safe.replace("/", "_").replace("\\", "_").lstrip(".")
    if not safe or safe in (".", ".."):
        return default
    return safe[:120]


@app.post("/api/cadence/{token}/phase-asset", dependencies=[Depends(_api_require_user)])
async def phase_asset_upload(
    token: str,
    kind: str,
    file: UploadFile = File(...),
) -> JSONResponse:
    """Admin uploads the material a question type needs (kind = audio|image).
    Validated against the ONE rule table in question_types.check_asset (extension
    + size), then stored at `<token>/phase_assets/<safe_name>`. Returns the name
    to put in the phase config plus the candidate-facing URL."""
    if db.get(token) is None:
        return JSONResponse({"ok": False, "error": "session not found"}, status_code=404)
    data = await file.read()
    err = _qt.check_asset(kind, file.filename or "", len(data))
    if err:
        return JSONResponse({"ok": False, "error": err}, status_code=400)

    safe_name = _safe_asset_name(file.filename, f"{kind}_asset")
    from io import BytesIO

    from app import blob_store
    if not blob_store.upload_fileobj(BytesIO(data), f"{token}/phase_assets/{safe_name}"):
        logger.warning("[phase-asset] upload failed for %s/%s", token, safe_name)
        return JSONResponse({"ok": False, "error": "upload failed"}, status_code=500)
    return JSONResponse({
        "ok": True,
        "name": safe_name,
        "url": f"/api/sessions/{token}/phase-asset/{safe_name}",
    })


# Extension → media type for the served asset. Kept narrow on purpose: only the
# types question_types.ASSET_RULES admits can be stored in the first place.
_ASSET_MEDIA_TYPES = {
    ".mp3": "audio/mpeg", ".wav": "audio/wav", ".m4a": "audio/mp4",
    ".ogg": "audio/ogg", ".oga": "audio/ogg", ".webm": "audio/webm",
    ".flac": "audio/flac", ".png": "image/png", ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif",
    # video (Visual Scenario Analysis items). .webm is deliberately NOT a
    # video extension here — see the comment on ASSET_RULES["video"].
    ".mp4": "video/mp4", ".mov": "video/quicktime", ".m4v": "video/x-m4v",
}


@app.get("/api/sessions/{token}/phase-asset/{name}")
def phase_asset_download(request: Request, token: str, name: str) -> Response:
    """Serve a phase asset to the CANDIDATE (and to the admin preview). No admin
    gate — the candidate is not logged in and the URL (token + name) is the
    capability. Range/206 supported so an
    <audio> element can seek in a long clip."""
    safe_name = _safe_asset_name(name, "")
    if not safe_name:
        raise HTTPException(404, "asset not available")
    from app import blob_store

    blob_name = f"{token}/phase_assets/{safe_name}"
    size = blob_store.blob_size(blob_name)
    if size is None:
        raise HTTPException(404, "asset not available")
    media_type = _ASSET_MEDIA_TYPES.get(
        Path(safe_name).suffix.lower(), "application/octet-stream",
    )

    base_headers = {"Accept-Ranges": "bytes", "Cache-Control": "private, max-age=300"}
    range_header = request.headers.get("range") or request.headers.get("Range")
    start, end, is_range = 0, size - 1, False
    if range_header and range_header.startswith("bytes="):
        spec = range_header[len("bytes="):].split(",")[0].strip()
        s, _, e = spec.partition("-")
        try:
            if s:
                start = int(s)
                end = int(e) if e else size - 1
            elif e:  # suffix range: bytes=-N → last N bytes
                start = max(0, size - int(e))
                end = size - 1
            if start > end or start >= size:
                raise ValueError("unsatisfiable")
            end = min(end, size - 1)
            is_range = True
        except ValueError:
            return Response(
                status_code=416,
                headers={**base_headers, "Content-Range": f"bytes */{size}"},
            )

    length = end - start + 1
    chunks = blob_store.download_stream(blob_name, offset=start, length=length)
    if chunks is None:
        raise HTTPException(404, "asset not available")
    headers = {**base_headers, "Content-Length": str(length)}
    status = 200
    if is_range:
        headers["Content-Range"] = f"bytes {start}-{end}/{size}"
        status = 206
    return StreamingResponse(chunks, status_code=status, media_type=media_type, headers=headers)


class _SetCodingBody(BaseModel):
    yaml: str
    question_ids: list[str]
    time_overrides: dict[str, int] | None = None
    # Full definitions for ids that came from a question POOL rather than the
    # built-in library, keyed by question id. Copied into the cadence.
    inline_questions: dict[str, dict] | None = None


@app.post("/api/cadence/{token}/set_coding_phase")
async def cadence_set_coding(token: str, body: _SetCodingBody) -> JSONResponse:
    row = db.get(token)
    if not row:
        raise HTTPException(404, "session not found")
    try:
        revised = set_coding_phase(
            body.yaml, row["role"], body.question_ids, body.time_overrides,
            body.inline_questions,
        )
    except Exception as e:
        logger.exception("[admin] set_coding_phase failed")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    _extend_rubric_after_cadence_change(token, revised, row["role"])
    return JSONResponse({"ok": True, "yaml": revised})


class _RemoveCodingBody(BaseModel):
    yaml: str


@app.post("/api/cadence/{token}/remove_coding_phase")
async def cadence_remove_coding(token: str, body: _RemoveCodingBody) -> JSONResponse:
    row = db.get(token)
    if not row:
        raise HTTPException(404, "session not found")
    try:
        revised = remove_coding_phase(body.yaml)
    except Exception as e:
        logger.exception("[admin] remove_coding_phase failed")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    return JSONResponse({"ok": True, "yaml": revised})


# ── Visual Scenario Analysis phase ──────────────────────────────────────────
# Voice/video only (see engine/brain/cadence/schema.py's
# CadencePlan._check_video_only_phases). Same stateless-builder shape as the
# coding/written-response routes above: every route takes the WORKING `yaml`
# string, returns a new one, and persists NOTHING — the SPA holds it in state
# until "Approve & generate link" writes it to the DB (app/sessions.py
# update_cadence). No media-deletion cleanup here, matching the pre-existing
# gap in image_description's own phase-asset routes above (see the module
# comment above _safe_asset_name).


class _ScenarioMediaBody(BaseModel):
    """An ALREADY-UPLOADED asset reference (see POST .../phase-asset). This
    body never carries bytes — only what the upload response returned."""

    kind: str
    ref: str
    filename: str
    mime_type: str


class _ScenarioItemBody(BaseModel):
    """One Visual Scenario Analysis item. `id` is echoed back when EDITING an
    existing item so its id survives (mirrors _WrittenQuestionBody); omit it
    for a new item — the builder assigns one from its position."""

    id: str | None = None
    media: _ScenarioMediaBody
    question: str = ""
    coverage_tags: list[str] = []
    max_followups: int = 2


def _scenario_items(items: list[_ScenarioItemBody]) -> list[dict]:
    """Request bodies -> plain dicts the builder/schema take. Items with no id
    get one derived from their position so ScenarioItem.id is never blank —
    the admin never sets an id by hand, only the frontend echoes one back."""
    out = []
    for i, it in enumerate(items, start=1):
        d = it.model_dump()
        if not (d.get("id") or "").strip():
            d["id"] = f"item_{i}"
        out.append(d)
    return out


def _missing_scenario_media(token: str, items: list[_ScenarioItemBody]) -> Optional[str]:
    """The I/O check Step 1 asks for: each item's media.ref must already exist
    in the asset store (it does NOT belong in schema.py, which does no I/O —
    see ScenarioMedia's docstring). Returns a clear admin-facing error naming
    the first missing file, or None when every ref resolves. Mirrors the
    existence check `phase_asset_download` already does for the same blob
    path (`blob_store.blob_size(...) is None` -> 404)."""
    from app import blob_store

    for it in items:
        safe_name = _safe_asset_name(it.media.ref, "")
        if not safe_name:
            return f"item has no media file attached"
        if blob_store.blob_size(f"{token}/phase_assets/{safe_name}") is None:
            return (
                f"media file '{it.media.filename or it.media.ref}' was not "
                "found — upload it before saving this phase (did the upload "
                "finish, or was it removed?)"
            )
    return None


def _rejects_text_modality(yaml_text: str) -> Optional[str]:
    """Step 1's explicit "reject creation for text-modality interviews with a
    clear message" — checked up front so the admin gets ONE clean sentence
    instead of a raw pydantic ValidationError dump (CadencePlan already
    enforces this at validation time via _check_video_only_phases; this is
    the same rule, surfaced legibly before the builder even runs). Mirrors
    the one existing modality gate's shape (text_service.start's `timed`
    check) — `timed` defaults True, so a missing/unparseable key reads as
    voice, never a false rejection."""
    import yaml as _yaml

    try:
        data = _yaml.safe_load(yaml_text)
    except Exception:
        return None  # let the builder's own YAML-parse error surface instead
    if isinstance(data, dict) and data.get("timed") is False:
        return (
            "Visual Scenario Analysis needs a voice/video interview — this "
            "interview is text-only, so items with media can't be shown live."
        )
    return None


class _AddScenarioPhaseBody(BaseModel):
    yaml: str
    name: str = "Visual Scenario Analysis"
    duration_s: int | None = None
    items: list[_ScenarioItemBody]


@app.post("/api/cadence/{token}/add_scenario_phase")
async def cadence_add_scenario_phase(token: str, body: _AddScenarioPhaseBody) -> JSONResponse:
    """Insert a Visual Scenario Analysis phase — the voice/video counterpart to
    add_phase (written-response) and add_coding_phase. Default position:
    between warm_up and wrap_up, before any coding round."""
    row = db.get(token)
    if not row:
        raise HTTPException(404, "session not found")
    reason = _rejects_text_modality(body.yaml)
    if reason:
        return JSONResponse({"ok": False, "error": reason}, status_code=400)
    if not body.items:
        return JSONResponse(
            {"ok": False, "error": "add at least one item (media + question) first"},
            status_code=400,
        )
    media_error = _missing_scenario_media(token, body.items)
    if media_error:
        return JSONResponse({"ok": False, "error": media_error}, status_code=400)
    try:
        revised = append_scenario_analysis_phase(
            body.yaml, _scenario_items(body.items),
            name=body.name, duration_s=body.duration_s,
        )
    except Exception as e:
        logger.exception("[admin] add_scenario_phase failed")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    return JSONResponse({"ok": True, "yaml": revised})


class _UpdateScenarioPhaseBody(BaseModel):
    yaml: str
    phase_id: str
    duration_s: int | None = None
    intent: str = ""
    generic_prompts: list[str] | None = None
    items: list[_ScenarioItemBody]


@app.post("/api/cadence/{token}/update_scenario_phase")
async def cadence_update_scenario_phase(token: str, body: _UpdateScenarioPhaseBody) -> JSONResponse:
    """Replace an existing Visual Scenario Analysis phase's items (add / edit /
    remove / reorder — the client always sends the full ordered list) and
    optionally its duration/intent/opening banter. The phase KEEPS its id."""
    row = db.get(token)
    if not row:
        raise HTTPException(404, "session not found")
    if not body.items:
        return JSONResponse(
            {"ok": False, "error": "a phase needs at least one item — remove "
                                    "the phase instead if you meant to delete it"},
            status_code=400,
        )
    media_error = _missing_scenario_media(token, body.items)
    if media_error:
        return JSONResponse({"ok": False, "error": media_error}, status_code=400)
    try:
        revised = update_scenario_analysis_phase(
            body.yaml, body.phase_id, items=_scenario_items(body.items),
            duration_s=body.duration_s, intent=body.intent,
            generic_prompts=body.generic_prompts,
        )
    except Exception as e:
        logger.exception("[admin] update_scenario_phase failed")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    return JSONResponse({"ok": True, "yaml": revised})


class _RemoveScenarioPhaseBody(BaseModel):
    yaml: str
    phase_id: str


@app.post("/api/cadence/{token}/remove_scenario_phase")
async def cadence_remove_scenario_phase(token: str, body: _RemoveScenarioPhaseBody) -> JSONResponse:
    row = db.get(token)
    if not row:
        raise HTTPException(404, "session not found")
    try:
        revised = remove_scenario_analysis_phase(body.yaml, body.phase_id)
    except Exception as e:
        logger.exception("[admin] remove_scenario_phase failed")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    return JSONResponse({"ok": True, "yaml": revised})


# ── evaluation rubric (cadence-driven lenses) ──────────────────────────
# Modular like coding/: all logic lives in rubric/; these routes are thin.
# The cadence-review page fetches GET on load, POSTs /generate when the
# rubric is missing or out of sync, and PUTs TA edits.


class _RubricGenerateBody(BaseModel):
    yaml: str


class _RubricPutBody(BaseModel):
    rubric: dict


def _rubric_disabled_response() -> Optional[JSONResponse]:
    import features.eval as rubric_mod

    if not rubric_mod.is_enabled():
        return JSONResponse({"ok": False, "error": "rubric feature disabled"}, status_code=404)
    return None


@app.get("/api/rubric/{token}")
def rubric_get(token: str) -> JSONResponse:
    if (resp := _rubric_disabled_response()) is not None:
        return resp
    import features.eval as rubric_mod

    current = rubric_mod.load_rubric(token)
    if current is None:
        return JSONResponse({"ok": False, "error": "no rubric yet"}, status_code=404)
    return JSONResponse({"ok": True, "rubric": current, "dims": rubric_mod.CANONICAL_DIMS})


@app.post("/api/rubric/{token}/generate")
async def rubric_generate(token: str, body: _RubricGenerateBody) -> JSONResponse:
    if (resp := _rubric_disabled_response()) is not None:
        return resp
    import features.eval as rubric_mod

    row = db.get(token)
    if row is None:
        return JSONResponse({"ok": False, "error": "session not found"}, status_code=404)
    ok, err = validate_cadence_yaml(body.yaml)
    if not ok:
        return JSONResponse({"ok": False, "error": f"cadence invalid: {err}"}, status_code=400)
    try:
        generated = await rubric_mod.generate_rubric(
            cadence_yaml=body.yaml,
            role=row["role"] or "",
            jd_text=row["jd_text"] or "",
            token=token,
        )
    except ValueError as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    except Exception as e:
        logger.exception("[admin] rubric generation failed")
        return JSONResponse({"ok": False, "error": f"rubric generation failed: {e}"}, status_code=500)
    saved = rubric_mod.save_rubric(token, generated.model_dump(mode="json"))
    return JSONResponse({"ok": True, "rubric": saved, "dims": rubric_mod.CANONICAL_DIMS})


@app.put("/api/rubric/{token}")
def rubric_put(token: str, body: _RubricPutBody) -> JSONResponse:
    if (resp := _rubric_disabled_response()) is not None:
        return resp
    import features.eval as rubric_mod

    if db.get(token) is None:
        return JSONResponse({"ok": False, "error": "session not found"}, status_code=404)
    data = dict(body.rubric)
    data["source"] = "ta_edited"
    data["generated_at"] = db.now_iso()
    validated, err = rubric_mod.validate_rubric_dict(data)
    if err is not None:
        return JSONResponse({"ok": False, "error": err}, status_code=400)
    saved = rubric_mod.save_rubric(token, validated.model_dump(mode="json"))
    return JSONResponse({"ok": True, "rubric": saved})


# ── plugin-based evaluation (v2) — plugin catalog ──────────────────────
# The per-phase evaluation plan (which plugin + config scores each phase) is
# served by the routes added alongside plan storage. This route exposes the
# registry so the UI can render config forms generically from each plugin's
# JSON-schema. Gated by EVAL_PLUGINS_ENABLED.


def _eval_plugins_disabled_response() -> Optional[JSONResponse]:
    import features.eval.plugins as plugins_mod

    if not plugins_mod.is_enabled():
        return JSONResponse({"ok": False, "error": "plugin evaluation disabled"}, status_code=404)
    return None


def _eval_plan_gate(token: str, cadence_yaml: str) -> Optional[str]:
    """Approval gate for the evaluation plan. Returns None when it's OK to
    approve, else a human-readable reason to block on.

    Rule (per operator decision):
      - NO plugin chosen anywhere → allowed. Not every interview needs scoring;
        an all-unscored plan simply produces no evaluation.
      - ANY plugin chosen (enabled + a plugin_id) → that phase MUST be valid
        against the CURRENT cadence: config parses and its cadence assumptions
        are met. A chosen-but-misconfigured plugin blocks approval.

    Enforced ONLY when the plugin evaluator is enabled (EVAL_PLUGINS_ENABLED).
    """
    import features.eval.plugins as plugins_mod

    if not plugins_mod.is_enabled():
        return None

    import yaml as _yaml

    from features.eval import plan as plan_mod
    from features.eval import plan_storage

    plan = plan_storage.load_plan(token)
    if plan is None:
        return None  # no plan == nothing chosen == allowed

    # Which phases actually chose a plugin (enabled + non-empty plugin_id)?
    chosen = [
        a for ph in (plan.get("phases") or [])
        for a in (ph.get("plugins") or [])
        if a.get("enabled", True) and a.get("plugin_id")
    ]
    if not chosen:
        return None  # all-unscored → allowed

    # Config validity (each enabled assignment parses against its plugin schema).
    _validated, err = plan_mod.validate_plan_dict(plan)
    if err is not None:
        return f"Evaluation config is invalid: {err}"

    # Cadence assumptions met for every enabled plugin.
    cadence = _yaml.safe_load(cadence_yaml) or {}
    results = plan_mod.validate_plan_against_cadence(plan, cadence)
    unmet: list[str] = []
    for ph in results:
        for pl in ph.get("plugins", []):
            if not pl.get("ok", True):
                # validate_plan_against_cadence already prefixes each unmet string
                # with "{phase_id} / {plugin_id}: " — don't re-add it here, or a
                # copied error reads doubled. Only the empty-list edge case (should
                # not normally happen when ok=False) needs it added back.
                items = pl.get("unmet") or []
                detail = "; ".join(items) if items else f"{ph.get('phase_id')} / {pl.get('plugin_id')}: requirements unmet"
                unmet.append(detail)
    if unmet:
        return "Evaluation plugins need attention before starting:\n• " + "\n• ".join(unmet)

    return None


@app.get("/api/eval/plugins")
def eval_plugins_catalog() -> JSONResponse:
    if (resp := _eval_plugins_disabled_response()) is not None:
        return resp
    import features.eval as rubric_mod
    import features.eval.plugins as plugins_mod

    return JSONResponse({
        "ok": True,
        "plugins": plugins_mod.plugin_catalog(),
        "dims": rubric_mod.CANONICAL_DIMS,
    })


class _EvalPlanGenerateBody(BaseModel):
    yaml: str


class _EvalPlanPutBody(BaseModel):
    plan: dict


@app.get("/api/eval/plan/{token}")
def eval_plan_get(token: str) -> JSONResponse:
    if (resp := _eval_plugins_disabled_response()) is not None:
        return resp
    from features.eval import plan_storage

    current = plan_storage.load_plan(token)
    if current is None:
        return JSONResponse({"ok": False, "error": "no evaluation plan yet"}, status_code=404)
    return JSONResponse({"ok": True, "plan": current})


@app.post("/api/eval/plan/{token}/generate")
async def eval_plan_generate(token: str, body: _EvalPlanGenerateBody) -> JSONResponse:
    """Regenerate the evaluation plan for the current cadence. The slow LLM picks
    the best-fit plugin for EACH phase and configures it from the phase intent +
    metadata . The result is saved and stays fully editable.

    Robust: if the LLM is unavailable or fails, we fall back to a deterministic
    all-unscored plan so Regenerate never hard-fails."""
    if (resp := _eval_plugins_disabled_response()) is not None:
        return resp
    import yaml as _yaml

    from features.eval import plan as plan_mod
    from features.eval import plan_storage

    row = db.get(token)
    if row is None:
        return JSONResponse({"ok": False, "error": "session not found"}, status_code=404)
    ok, err = validate_cadence_yaml(body.yaml)
    if not ok:
        # `err` is already humanized (no pydantic noise) — surface it directly.
        return JSONResponse({"ok": False, "error": err}, status_code=400)

    ai_used = True
    try:
        from app.eval_plan_ai import generate_ai_plan
        plan = await generate_ai_plan(body.yaml, role=row["role"] or "", token=token)
    except Exception as e:
        # LLM key missing / call failed → deterministic all-unscored fallback so
        # the operator still gets a plan to configure by hand.
        logger.warning("[admin] AI eval plan generation fell back to default: %s", e)
        ai_used = False
        try:
            cadence = _yaml.safe_load(body.yaml) or {}
            plan = plan_mod.plan_from_cadence(cadence, role=row["role"] or "")
        except Exception:
            logger.exception("[admin] eval plan generation failed")
            return JSONResponse(
                {"ok": False, "error": "Couldn't generate the evaluation plan for this cadence. Please review the cadence and try again."},
                status_code=500,
            )
    saved = plan_storage.save_plan(token, plan.model_dump(mode="json"))
    return JSONResponse({"ok": True, "plan": saved, "ai_used": ai_used})


@app.put("/api/eval/plan/{token}")
def eval_plan_put(token: str, body: _EvalPlanPutBody) -> JSONResponse:
    if (resp := _eval_plugins_disabled_response()) is not None:
        return resp
    from features.eval import plan as plan_mod
    from features.eval import plan_storage

    if db.get(token) is None:
        return JSONResponse({"ok": False, "error": "session not found"}, status_code=404)
    data = dict(body.plan)
    data["source"] = "ta_edited"
    data["generated_at"] = db.now_iso()
    validated, err = plan_mod.validate_plan_dict(data)
    if err is not None:
        return JSONResponse({"ok": False, "error": err}, status_code=400)
    saved = plan_storage.save_plan(token, validated.model_dump(mode="json"))
    return JSONResponse({"ok": True, "plan": saved})


class _EvalPlanValidateBody(BaseModel):
    yaml: str
    plan: dict


@app.post("/api/eval/plan/{token}/validate")
def eval_plan_validate(token: str, body: _EvalPlanValidateBody) -> JSONResponse:
    """Deterministically check each enabled plugin's assumptions against the
    CURRENT cadence (the editor's live YAML). Returns per-phase/per-plugin
    results so the UI shows hints in the matching card. No save, no LLM."""
    if (resp := _eval_plugins_disabled_response()) is not None:
        return resp
    import yaml as _yaml

    from features.eval import plan as plan_mod

    cadence = _yaml.safe_load(body.yaml) or {}
    results = plan_mod.validate_plan_against_cadence(body.plan, cadence)
    all_ok = all(p.get("ok", True) for ph in results for p in ph.get("plugins", []))
    return JSONResponse({"ok": True, "all_ok": all_ok, "results": results})


# ── coding question library (read-only) ───────────────────────────────
#
# Powers the cadence-review question picker. Returns a safe projection —
# library-internal `solution` field is always stripped server-side.


def _question_to_picker_dict(q: "Any") -> dict:
    # Picker shape: enough info to render a card + preview inline.
    # `solution` is intentionally NOT included.
    return {
        "id": q.id,
        "title": q.title,
        "prompt": (q.prompt or "").strip(),
        "starter_code": q.starter_code,
        "function_name": q.function_name,
        "test_case_count": len(q.test_cases or []),
        "difficulty": q.difficulty,
        "topic": list(q.topic or []),
        "role_fit": list(q.role_fit or []),
        "hint_count": len(q.hints or []),
    }


@app.get("/admin/coding/questions")
def coding_questions_list(
    request: Request,
    topic: Optional[str] = None,
    difficulty: Optional[str] = None,
    role_fit: Optional[str] = None,
) -> JSONResponse:
    redir = _require_user_or_redirect(request)
    if redir is not None:
        return JSONResponse({"ok": False, "error": "auth"}, status_code=401)
    try:
        from features.coding.questions.loader import load_library
    except Exception as e:
        return JSONResponse(
            {"ok": False, "error": f"coding library unavailable: {e}"},
            status_code=500,
        )
    try:
        lib = load_library()
    except Exception as e:
        return JSONResponse(
            {"ok": False, "error": f"library load failed: {e}"}, status_code=500,
        )
    items: list[dict] = []
    for q in lib.values():
        if topic and topic not in (q.topic or []):
            continue
        if difficulty and difficulty != q.difficulty:
            continue
        if role_fit and role_fit not in (q.role_fit or []):
            continue
        items.append(_question_to_picker_dict(q))
    # Stable sort: difficulty (easy → medium → hard), then id.
    _DIFF_ORDER = {"easy": 0, "medium": 1, "hard": 2}
    items.sort(key=lambda d: (_DIFF_ORDER.get(d.get("difficulty"), 9), d["id"]))
    return JSONResponse({"ok": True, "questions": items, "count": len(items)})


@app.get("/admin/coding/question/{qid}")
def coding_question_detail(request: Request, qid: str) -> JSONResponse:
    redir = _require_user_or_redirect(request)
    if redir is not None:
        return JSONResponse({"ok": False, "error": "auth"}, status_code=401)
    try:
        from features.coding.questions.loader import get_question
    except Exception as e:
        return JSONResponse(
            {"ok": False, "error": f"coding library unavailable: {e}"},
            status_code=500,
        )
    try:
        q = get_question(qid)
    except KeyError:
        return JSONResponse(
            {"ok": False, "error": f"no such question: {qid}"}, status_code=404,
        )
    data = _question_to_picker_dict(q)
    # Detail view includes hints + test cases (no solution).
    data["hints"] = list(q.hints or [])
    data["test_cases"] = [
        {"name": tc.get("name"), "input": tc.get("input"), "expected": tc.get("expected")}
        for tc in (q.test_cases or [])
    ]
    return JSONResponse({"ok": True, "question": data})


_POOL_DIR = REPO_ROOT / "engine" / "brain" / "cadence" / "questions_pool"
_PHASE_ID_RE = re.compile(r"^[a-z][a-z0-9_]*$")


def _list_pool_files() -> Optional[list[str]]:
    """Pool dir is created by a parallel agent; degrade gracefully if missing."""
    if not _POOL_DIR.is_dir():
        return None
    return sorted(p.name for p in _POOL_DIR.glob("*.yaml"))


def _builtin_pool_load(name: str) -> Optional[dict]:
    """Parse a SHIPPED pool by bare filename, or None if missing/unsafe/bad.

    Carries the path-traversal guard the customizer used to inline: the name
    must be a bare `*.yaml` that resolves inside _POOL_DIR."""
    import yaml as _yaml
    if not name or "/" in name or "\\" in name or not name.endswith(".yaml"):
        return None
    path = (_POOL_DIR / name).resolve()
    try:
        path.relative_to(_POOL_DIR.resolve())
    except ValueError:
        return None
    if not path.is_file():
        return None
    try:
        data = _yaml.safe_load(path.read_text(encoding="utf-8"))
    except Exception:
        return None
    if isinstance(data, list):        # bare list of questions
        return {"questions": data}
    return data if isinstance(data, dict) else None


def _builtin_pool_summaries() -> list[dict]:
    """Shipped pools in the same summary shape question_pools.summary() emits, so
    the picker renders both sources from one list. Read-only: editing a file that
    lives in the image would be undone by the next build."""
    out: list[dict] = []
    for name in _list_pool_files() or []:
        data = _builtin_pool_load(name)
        if not data:
            continue
        qs = [q for q in (data.get("questions") or []) if isinstance(q, dict)]
        counts: dict[str, dict[str, int]] = {}
        for q in qs:
            topic = str(q.get("topic") or "(none)").strip().lower()
            diff = str(q.get("difficulty") or "medium").strip().lower()
            counts.setdefault(topic, {"easy": 0, "medium": 0, "hard": 0})
            if diff in counts[topic]:
                counts[topic][diff] += 1
        out.append({
            "pool_id": name, "pool_file": name,
            "pool_name": str(data.get("pool_name") or name),
            # Every shipped pool is conversational; written pools are authored.
            "pool_kind": "spoken",
            "kinds": ["spoken"],
            "description": str(data.get("description") or ""),
            "question_count": len(qs),
            "topics": sorted({str(q["topic"]).strip().lower() for q in qs if q.get("topic")}),
            "counts": counts, "updated_at": "",
            "source": POOL_SOURCE_BUILTIN, "editable": False,
        })
    return out


def _resolve_pool_data(pool_ref: str) -> Optional[dict]:
    """A customizer pool reference → its parsed data.

    A `*.yaml` reference is a SHIPPED pool; anything else is a user-authored pool
    id stored in Blob. One resolver so both endpoints (and any future consumer)
    treat the two sources identically — the injected questions are the same shape
    either way. None when it can't be resolved."""
    ref = (pool_ref or "").strip()
    if not ref:
        return None
    if ref.endswith(".yaml"):
        return _builtin_pool_load(ref)
    from app import question_pools as _qp
    questions = _qp.pool_questions(ref)
    return None if questions is None else {"questions": questions}


def _pool_topics(pool_files: Optional[list[str]]) -> dict[str, list[str]]:
    """Read each pool YAML once and return {filename: [sorted unique topics]}.

    Used so the cadence-review template can render a topic checkbox grid per
    pool — the operator picks topics by clicking chips instead of typing a
    comma-separated string. A malformed pool yields an empty list (we'd
    rather show no chips than 500 the whole page).
    """
    import yaml as _yaml
    out: dict[str, list[str]] = {}
    for name in pool_files or []:
        path = _POOL_DIR / name
        try:
            data = _yaml.safe_load(path.read_text(encoding="utf-8"))
        except Exception:
            out[name] = []
            continue
        if isinstance(data, list):
            questions = data
        elif isinstance(data, dict):
            questions = data.get("questions") or []
        else:
            questions = []
        topics = {
            str(q["topic"]).strip().lower()
            for q in questions
            if isinstance(q, dict) and q.get("topic")
        }
        out[name] = sorted(topics)
    return out


# Defaults pre-checked on initial render and used if the operator submits
# with no chips selected. We pick three broad buckets that tend to exist
# in any AI-engineer pool; if any of these aren't in the chosen pool the
# server's exact-match logic surfaces a warning listing what IS available.
_DEFAULT_TOPICS = ("transformers", "rag", "deep_learning")


def _phase_ids_from_yaml(text: str) -> tuple[list[str], Optional[dict]]:
    import yaml as _yaml
    try:
        data = _yaml.safe_load(text)
    except Exception:
        return [], None
    if not isinstance(data, dict):
        return [], None
    phases = data.get("phases") or []
    ids = [p.get("id") for p in phases if isinstance(p, dict) and p.get("id")]
    return ids, data


def _pick_default_customize_phase(phase_ids: list[str]) -> str:
    """Pre-select `technical_questions` in the customizer dropdown when
    that phase exists in the cadence; otherwise fall back to the first
    phase id."""
    if "technical_questions" in phase_ids:
        return "technical_questions"
    return phase_ids[0] if phase_ids else ""


class _CustomizeBody(BaseModel):
    yaml: str
    difficulty: str  # easy | medium | hard
    phase: str  # existing phase id, or "__other__"
    custom_phase_name: Optional[str] = None
    anchor_phase: Optional[str] = None  # when phase=="__other__", append after this phase
    pool_file: str
    count: int
    topics: Optional[str] = None


@app.post("/api/cadence/{token}/customize")
def cadence_customize(token: str, body: _CustomizeBody) -> JSONResponse:
    import yaml as _yaml

    warnings: list[str] = []

    # ── validate inputs ───────────────────────────────────────────────
    difficulty = (body.difficulty or "").strip().lower()
    if difficulty not in ("easy", "medium", "hard"):
        return JSONResponse({"ok": False, "error": "difficulty must be easy/medium/hard"}, status_code=400)

    if body.count is None or body.count < 1:
        return JSONResponse({"ok": False, "error": "count must be a positive integer"}, status_code=400)

    pool_name = (body.pool_file or "").strip()
    # A shipped `*.yaml` or a user-authored pool id — _resolve_pool_data owns the
    # difference (and the path-traversal guard for the shipped case).
    _resolved_pool = _resolve_pool_data(pool_name)
    if _resolved_pool is None:
        return JSONResponse({"ok": False, "error": f"pool not found: {pool_name}"}, status_code=400)

    phase_ids, cadence_data = _phase_ids_from_yaml(body.yaml)
    if cadence_data is None:
        return JSONResponse({"ok": False, "error": "current cadence YAML is invalid"}, status_code=400)

    is_other = body.phase == "__other__"
    anchor_id: Optional[str] = None
    new_name: str = ""
    if is_other:
        new_name = (body.custom_phase_name or "").strip().lower().replace(" ", "_")
        if not new_name or not _PHASE_ID_RE.match(new_name):
            return JSONResponse(
                {"ok": False, "error": "custom phase name must be snake_case (lowercase letters/digits/underscore, start with a letter)"},
                status_code=400,
            )
        if new_name in phase_ids:
            return JSONResponse({"ok": False, "error": f"phase '{new_name}' already exists"}, status_code=400)
        anchor_id = (body.anchor_phase or "").strip() or None
        if anchor_id and anchor_id not in phase_ids:
            return JSONResponse({"ok": False, "error": f"anchor phase '{anchor_id}' not in cadence"}, status_code=400)
    else:
        if body.phase not in phase_ids:
            return JSONResponse({"ok": False, "error": f"phase '{body.phase}' not in cadence"}, status_code=400)

    # ── load pool ─────────────────────────────────────────────────────
    try:
        pool_data = _resolved_pool
    except Exception as e:
        return JSONResponse({"ok": False, "error": f"pool YAML parse error: {e}"}, status_code=400)
    # Accept either a top-level list of questions or {questions: [...]}.
    if isinstance(pool_data, list):
        questions = pool_data
        pool_difficulty = None
    elif isinstance(pool_data, dict):
        questions = pool_data.get("questions") or []
        pool_difficulty = pool_data.get("difficulty")
    else:
        return JSONResponse({"ok": False, "error": "pool YAML must be a list or mapping"}, status_code=400)
    if not isinstance(questions, list) or not questions:
        return JSONResponse({"ok": False, "error": "pool has no questions"}, status_code=400)

    # ── filter by difficulty ──────────────────────────────────────────
    # The other agent owns the pool schema; we accept either a top-level
    # `difficulty:` (bucket file) or a per-question `difficulty:` field.
    # If neither exists, skip difficulty filtering and warn the operator.
    has_top_diff = isinstance(pool_difficulty, str) and pool_difficulty.strip() != ""
    has_per_q_diff = any(
        isinstance(q, dict) and isinstance(q.get("difficulty"), str) for q in questions
    )
    if has_top_diff:
        if str(pool_difficulty).strip().lower() != difficulty:
            warnings.append(
                f"pool file's top-level difficulty is '{pool_difficulty}', not '{difficulty}' — using anyway"
            )
        filtered = list(questions)
    elif has_per_q_diff:
        filtered = [q for q in questions if isinstance(q, dict) and str(q.get("difficulty", "")).strip().lower() == difficulty]
        if not filtered:
            return JSONResponse(
                {"ok": False, "error": f"no questions in pool with difficulty='{difficulty}'"},
                status_code=400,
            )
    else:
        warnings.append("pool YAML has no `difficulty` field (top-level or per-question) — difficulty filter ignored")
        filtered = list(questions)

    # ── select questions ──────────────────────────────────────────────
    # When the operator passes a topic list we stratify: each listed topic
    # gets its fair share via round-robin allocation, then we sample
    # randomly within each bucket. Without this, flat random sampling can
    # silently shut out an entire requested topic (a 1-in-12 draw, but it
    # happens — the operator typed `transformers, prompting, rag` and got
    # 3 transformers + 2 vision_transformers + 0 rag).
    #
    # Bucket assignment is **exact match only** — listing `transformers`
    # does NOT pull in `vision_transformers` questions. The substring
    # fallback we tried first surprised operators (typed "transformers",
    # got a bunch of ViT). If a typed topic doesn't exist, we surface the
    # available topics in the warning so they can correct the spelling.
    wanted = [t.strip().lower() for t in (body.topics or "").split(",") if t.strip()]
    if wanted:
        buckets: dict[str, list] = {t: [] for t in wanted}
        for q in filtered:
            if not isinstance(q, dict):
                continue
            q_topic = str(q.get("topic", "")).strip().lower()
            if q_topic in buckets:
                buckets[q_topic].append(q)
        empty = [t for t in wanted if not buckets[t]]
        if empty:
            available = sorted({str(q.get("topic", "")).strip().lower() for q in filtered if isinstance(q, dict) and q.get("topic")})
            warnings.append(
                f"no questions in pool for topic(s): {', '.join(empty)} "
                f"— available at this difficulty: {', '.join(available) or '(none)'}"
            )
        if not any(buckets.values()):
            return JSONResponse(
                {"ok": False, "error": f"no questions match topics: {', '.join(wanted)}"},
                status_code=400,
            )
        # Round-robin allocation: walk topics in the operator's order,
        # give one to each bucket that still has capacity, until count is
        # hit or every bucket is drained.
        alloc = {t: 0 for t in wanted}
        remaining = body.count
        while remaining > 0:
            advanced = False
            for t in wanted:
                if remaining == 0:
                    break
                if alloc[t] < len(buckets[t]):
                    alloc[t] += 1
                    remaining -= 1
                    advanced = True
            if not advanced:
                break
        picks_raw: list = []
        for t in wanted:
            if alloc[t] > 0:
                picks_raw.extend(random.sample(buckets[t], alloc[t]))
        random.shuffle(picks_raw)
        if remaining > 0:
            warnings.append(
                f"only {len(picks_raw)} of {body.count} requested — pool ran out across the listed topics"
            )
    else:
        # No topic filter: flat random sample across the difficulty-filtered pool.
        k = min(body.count, len(filtered))
        picks_raw = random.sample(filtered, k) if k > 0 else []
        if k < body.count:
            warnings.append(
                f"only {k} of {body.count} requested — pool ran out at this difficulty"
            )
    if not picks_raw:
        return JSONResponse({"ok": False, "error": "no questions to pick after filtering"}, status_code=400)

    picks: list[dict] = []
    for i, q in enumerate(picks_raw):
        if not isinstance(q, dict):
            continue
        qid = str(q.get("id") or f"q_{i+1}")
        text = str(q.get("text") or "").strip()
        if not text:
            continue
        item = {"id": qid, "text": text}
        if q.get("topic"):
            item["topic"] = str(q["topic"])
        if isinstance(q.get("coverage_tags"), list) and q["coverage_tags"]:
            item["coverage_tags"] = [str(x) for x in q["coverage_tags"]]
        if isinstance(q.get("follow_ups"), list) and q["follow_ups"]:
            item["follow_ups"] = [str(x) for x in q["follow_ups"]]
        picks.append(item)
    if not picks:
        return JSONResponse({"ok": False, "error": "picked questions had no usable text"}, status_code=400)

    # ── mutate cadence in-memory ──────────────────────────────────────
    phases = cadence_data.get("phases") or []
    if is_other:
        # Default anchor = last phase if none specified.
        anchor = anchor_id or (phase_ids[-1] if phase_ids else None)
        # Reuse the selected phase's duration as a sane default; the operator
        # can edit the YAML afterward.
        donor = next((p for p in phases if p.get("id") == anchor), phases[-1] if phases else None)
        donor_duration = int(donor.get("duration_s", 60)) if isinstance(donor, dict) else 60
        new_phase = {
            "id": new_name,
            "duration_s": donor_duration,
            "intent": f"Custom phase: ask {len(picks)} {difficulty} question(s) from {pool_name}.",
            "question_mode": "specific",
            "question_pool": picks,
        }
        # Insert AFTER the anchor.
        if anchor is None:
            phases.append(new_phase)
        else:
            for i, p in enumerate(phases):
                if isinstance(p, dict) and p.get("id") == anchor:
                    phases.insert(i + 1, new_phase)
                    break
            else:
                phases.append(new_phase)
        # Bump total_duration_s so the cadence stays valid.
        cadence_data["total_duration_s"] = int(cadence_data.get("total_duration_s", 0)) + donor_duration
    else:
        target = next((p for p in phases if isinstance(p, dict) and p.get("id") == body.phase), None)
        if target is None:
            return JSONResponse({"ok": False, "error": f"phase '{body.phase}' vanished"}, status_code=500)
        target["question_mode"] = "specific"
        target["question_pool"] = picks
        # Clear conflicting field — schema rejects both populated.
        target.pop("generic_prompts", None)
    cadence_data["phases"] = phases

    # ── validate + serialise ──────────────────────────────────────────
    new_yaml = _yaml.safe_dump(cadence_data, sort_keys=False)
    ok, err = validate_cadence_yaml(new_yaml)
    if not ok:
        return JSONResponse(
            {"ok": False, "error": f"customisation produced invalid cadence: {err}", "yaml": new_yaml},
            status_code=400,
        )
    return JSONResponse({"ok": True, "yaml": new_yaml, "warnings": warnings})


class _AdaptiveBody(BaseModel):
    yaml: str
    phase: str  # existing phase id, or "__other__"
    custom_phase_name: Optional[str] = None
    anchor_phase: Optional[str] = None  # when phase=="__other__", append after this
    pool_file: str
    start_difficulty: Optional[str] = None  # easy | medium | hard (default easy)


@app.post("/api/cadence/{token}/customize_adaptive")
def cadence_customize_adaptive(token: str, body: _AdaptiveBody) -> JSONResponse:
    """Enable DYNAMIC (adaptive) difficulty on a phase.

    Unlike the static `customize` endpoint (which filters a pool to ONE
    difficulty and asks a fixed set), this loads the WHOLE pool — every
    difficulty — into the target phase, preserves each question's `difficulty`,
    and flips the phase to `adaptive_difficulty: true`. At runtime the
    CadenceTracker then escalates/de-escalates the next question's difficulty
    from the verifier's per-question outcomes (see stream_b_new/core/adaptive.py).

    Both features coexist: the static customizer is untouched.
    """
    import yaml as _yaml

    warnings: list[str] = []

    # ── validate inputs ───────────────────────────────────────────────
    pool_name = (body.pool_file or "").strip()
    # A shipped `*.yaml` or a user-authored pool id — _resolve_pool_data owns the
    # difference (and the path-traversal guard for the shipped case).
    _resolved_pool = _resolve_pool_data(pool_name)
    if _resolved_pool is None:
        return JSONResponse({"ok": False, "error": f"pool not found: {pool_name}"}, status_code=400)

    start_difficulty = (body.start_difficulty or "easy").strip().lower()
    if start_difficulty not in ("easy", "medium", "hard"):
        return JSONResponse({"ok": False, "error": "start_difficulty must be easy/medium/hard"}, status_code=400)

    phase_ids, cadence_data = _phase_ids_from_yaml(body.yaml)
    if cadence_data is None:
        return JSONResponse({"ok": False, "error": "current cadence YAML is invalid"}, status_code=400)

    is_other = body.phase == "__other__"
    anchor_id: Optional[str] = None
    new_name: str = ""
    if is_other:
        new_name = (body.custom_phase_name or "").strip().lower().replace(" ", "_")
        if not new_name or not _PHASE_ID_RE.match(new_name):
            return JSONResponse(
                {"ok": False, "error": "custom phase name must be snake_case (lowercase letters/digits/underscore, start with a letter)"},
                status_code=400,
            )
        if new_name in phase_ids:
            return JSONResponse({"ok": False, "error": f"phase '{new_name}' already exists"}, status_code=400)
        anchor_id = (body.anchor_phase or "").strip() or None
        if anchor_id and anchor_id not in phase_ids:
            return JSONResponse({"ok": False, "error": f"anchor phase '{anchor_id}' not in cadence"}, status_code=400)
    else:
        if body.phase not in phase_ids:
            return JSONResponse({"ok": False, "error": f"phase '{body.phase}' not in cadence"}, status_code=400)

    # ── load pool ─────────────────────────────────────────────────────
    try:
        pool_data = _resolved_pool
    except Exception as e:
        return JSONResponse({"ok": False, "error": f"pool YAML parse error: {e}"}, status_code=400)
    if isinstance(pool_data, list):
        questions = pool_data
    elif isinstance(pool_data, dict):
        questions = pool_data.get("questions") or []
    else:
        return JSONResponse({"ok": False, "error": "pool YAML must be a list or mapping"}, status_code=400)
    if not isinstance(questions, list) or not questions:
        return JSONResponse({"ok": False, "error": "pool has no questions"}, status_code=400)

    # ── build picks: ALL questions, difficulty preserved ──────────────
    # Adaptive needs a difficulty on every question. Skip (and warn about)
    # any that lack one rather than producing a cadence the schema rejects.
    picks: list[dict] = []
    skipped: list[str] = []
    seen_ids: set[str] = set()
    for i, q in enumerate(questions):
        if not isinstance(q, dict):
            continue
        diff = str(q.get("difficulty", "")).strip().lower()
        text = str(q.get("text") or "").strip()
        qid = str(q.get("id") or f"q_{i+1}")
        if diff not in ("easy", "medium", "hard"):
            skipped.append(qid)
            continue
        if not text:
            continue
        if qid in seen_ids:
            # Schema rejects duplicate ids within a phase — keep the first.
            continue
        seen_ids.add(qid)
        item: dict = {"id": qid, "text": text, "difficulty": diff}
        if q.get("topic"):
            item["topic"] = str(q["topic"])
        if isinstance(q.get("coverage_tags"), list) and q["coverage_tags"]:
            item["coverage_tags"] = [str(x) for x in q["coverage_tags"]]
        if isinstance(q.get("follow_ups"), list) and q["follow_ups"]:
            item["follow_ups"] = [str(x) for x in q["follow_ups"]]
        picks.append(item)

    if not picks:
        return JSONResponse(
            {"ok": False, "error": "no usable questions with a difficulty in this pool"},
            status_code=400,
        )
    if skipped:
        warnings.append(
            f"{len(skipped)} question(s) skipped — no difficulty field: "
            f"{', '.join(skipped[:8])}{'…' if len(skipped) > 8 else ''}"
        )

    # The start level must exist among the picks (schema enforces this when
    # set). If it doesn't, fall back to the lowest present level and warn.
    present_levels = {p["difficulty"] for p in picks}
    if start_difficulty not in present_levels:
        for lvl in ("easy", "medium", "hard"):
            if lvl in present_levels:
                warnings.append(
                    f"no '{start_difficulty}' questions in pool — starting at "
                    f"'{lvl}' instead"
                )
                start_difficulty = lvl
                break

    level_counts = {
        lvl: sum(1 for p in picks if p["difficulty"] == lvl)
        for lvl in ("easy", "medium", "hard")
    }

    # ── mutate cadence in-memory ──────────────────────────────────────
    phases = cadence_data.get("phases") or []
    if is_other:
        anchor = anchor_id or (phase_ids[-1] if phase_ids else None)
        donor = next((p for p in phases if p.get("id") == anchor), phases[-1] if phases else None)
        donor_duration = int(donor.get("duration_s", 120)) if isinstance(donor, dict) else 120
        new_phase = {
            "id": new_name,
            "duration_s": donor_duration,
            "intent": (
                f"Adaptive phase: questions auto-adjust difficulty "
                f"(start {start_difficulty}) from {pool_name}."
            ),
            "question_mode": "specific",
            "adaptive_difficulty": True,
            "adaptive_start_difficulty": start_difficulty,
            "question_pool": picks,
        }
        if anchor is None:
            phases.append(new_phase)
        else:
            for i, p in enumerate(phases):
                if isinstance(p, dict) and p.get("id") == anchor:
                    phases.insert(i + 1, new_phase)
                    break
            else:
                phases.append(new_phase)
        cadence_data["total_duration_s"] = int(cadence_data.get("total_duration_s", 0)) + donor_duration
    else:
        target = next((p for p in phases if isinstance(p, dict) and p.get("id") == body.phase), None)
        if target is None:
            return JSONResponse({"ok": False, "error": f"phase '{body.phase}' vanished"}, status_code=500)
        target["question_mode"] = "specific"
        target["adaptive_difficulty"] = True
        target["adaptive_start_difficulty"] = start_difficulty
        target["question_pool"] = picks
        # Clear conflicting field — schema rejects generic_prompts on specific.
        target.pop("generic_prompts", None)
    cadence_data["phases"] = phases

    # ── validate + serialise ──────────────────────────────────────────
    new_yaml = _yaml.safe_dump(cadence_data, sort_keys=False)
    ok, err = validate_cadence_yaml(new_yaml)
    if not ok:
        return JSONResponse(
            {"ok": False, "error": f"adaptive customisation produced invalid cadence: {err}", "yaml": new_yaml},
            status_code=400,
        )
    warnings.insert(
        0,
        f"loaded {len(picks)} questions (easy={level_counts['easy']}, "
        f"medium={level_counts['medium']}, hard={level_counts['hard']}); "
        f"starts at {start_difficulty}, then adapts to the candidate.",
    )
    return JSONResponse({"ok": True, "yaml": new_yaml, "warnings": warnings})


@app.post("/admin/schedule/{token}/approve")
async def cadence_approve(
    request: Request,
    token: str,
    cadence_yaml: str = Form(...),
) -> Response:
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    row = db.get(token)
    if row is None:
        raise HTTPException(404, "session not found")

    # Safety net: a coding-intent phase with no question id never opens the
    # coding window. Attach a library question at launch time if missing.
    cadence_yaml, _cb_notes = backfill_coding_in_yaml(cadence_yaml, row["role"])
    if _cb_notes:
        logger.info("[coding] approve backfill (%s): %s", token, "; ".join(_cb_notes))

    ok, err = validate_cadence_yaml(cadence_yaml)
    if not ok:
        return templates.TemplateResponse(
            "cadence_review.html",
            {
                "request": request,
                "row": row,
                "active_blocker": False,
                "active": None,
                "error": f"Cadence invalid: {err}",
                "edited_yaml": cadence_yaml,
            },
            status_code=400,
        )

    # Chosen evaluation plugins must be validated/valid (all-unscored allowed).
    if (eval_err := _eval_plan_gate(token, cadence_yaml)) is not None:
        return templates.TemplateResponse(
            "cadence_review.html",
            {
                "request": request,
                "row": row,
                "active_blocker": False,
                "active": None,
                "error": eval_err,
                "edited_yaml": cadence_yaml,
            },
            status_code=400,
        )

    # Single-at-a-time check — LOCAL only.
    # CLOUD_MODE supports concurrent interviews per the in-process
    # `_token_sessions` registry; the LOCAL spawner launches one
    # orchestrator subprocess that would collide on Stream A's static
    # UI/WS ports (8090/9100), so the lock is kept there.
    if os.environ.get("CLOUD_MODE", "") != "1":
        active = db.has_active_session()
        if active is not None and active["token"] != token:
            # Check if its PID is dead — recover stale-ready rows.
            if active["pid"] and not spawner.is_pid_alive(int(active["pid"])):
                db.update(active["token"], status="cancelled", ended_at=db.now_iso())
            else:
                return templates.TemplateResponse(
                    "cadence_review.html",
                    {
                        "request": request,
                        "row": row,
                        "active_blocker": True,
                        "active": active,
                        "edited_yaml": cadence_yaml,
                        "error": (
                            f"Cannot start: an interview is already running for "
                            f"{active['candidate_name']!r}. End it first."
                        ),
                    },
                    status_code=409,
                )

    # Persist cadence + write to disk so live_main can load it.
    sessions.update_cadence(token, cadence_yaml)
    sessions.write_cadence_to_disk(token, cadence_yaml)

    # Spawn orchestrator. Status -> 'ready'; will flip to 'in_progress' when
    # the orchestrator's SESSION_STARTED event fires (live_main writes it back).
    try:
        pid = spawner.launch_orchestrator(token)
    except Exception as e:
        logger.exception("[admin] spawner failed")
        return templates.TemplateResponse(
            "cadence_review.html",
            {
                "request": request,
                "row": row,
                "active_blocker": False,
                "active": None,
                "error": f"Failed to launch orchestrator: {e}",
                "edited_yaml": cadence_yaml,
            },
            status_code=500,
        )

    db.update(
        token,
        status="ready",
        pid=pid,
        ws_port=9100,
        http_port=8090,
    )

    candidate_link = _candidate_link_base(request) + f"/app/candidate?token={token}"
    row = db.get(token)
    await _maybe_enqueue_invite(row, candidate_link)
    return templates.TemplateResponse(
        "cadence_approved.html",
        {
            "request": request,
            "row": row,
            "candidate_link": candidate_link,
        },
    )


class _ApproveBody(BaseModel):
    cadence_yaml: str


async def _approve_session(request: Request, token: str, row: dict, cadence_yaml: str) -> JSONResponse:
    """Approve ONE interview: backfill, validate, gate on the evaluation plan,
    persist, launch, and return its links.

    Extracted so the bulk approve (a role's whole batch) runs the identical
    checks. Handing out a candidate link is the moment those checks matter, so
    there must be exactly one implementation of them.
    """
    # Safety net: attach a library question to any coding-intent phase that's
    # missing one, so the coding window actually opens (the LLM often forgets).
    cadence_yaml, _cb_notes = backfill_coding_in_yaml(cadence_yaml, row["role"])
    if _cb_notes:
        logger.info("[coding] approve backfill (%s): %s", token, "; ".join(_cb_notes))

    ok, err = validate_cadence_yaml(cadence_yaml)
    if not ok:
        return JSONResponse({"ok": False, "error": f"Cadence invalid: {err}"}, status_code=400)

    # Chosen evaluation plugins must be validated/valid before a link is
    # generated (an all-unscored plan is allowed).
    if (eval_err := _eval_plan_gate(token, cadence_yaml)) is not None:
        return JSONResponse(
            {"ok": False, "error": eval_err, "needs_eval_validation": True},
            status_code=400,
        )

    # A ROLE CADENCE TEMPLATE is approved, not launched. It has no candidate, so
    # there is nobody to send a link to and nothing to spawn — generating one
    # would hand out a working interview link for a session that is only meant to
    # be a plan. Approving it means "a person reviewed this", which is what
    # unlocks creating the role's interviews.
    if row.get("is_template"):
        sessions.update_cadence(token, cadence_yaml)
        sessions.write_cadence_to_disk(token, cadence_yaml)
        db.update(token, status="ready")
        role = None
        try:
            from features.shortlist import role_store
            role = role_store.get_role_by_template_token(token)
        except Exception:
            logger.warning("[admin] template %s has no owning role", token)
        return JSONResponse({
            "ok": True,
            "is_template": True,
            "role_public_id": (role or {}).get("public_id", ""),
            "role_title": (role or {}).get("title", ""),
        })

    # Single-at-a-time guard — LOCAL only (see cadence_approve for rationale).
    if os.environ.get("CLOUD_MODE", "") != "1":
        active = db.has_active_session()
        if active is not None and active["token"] != token:
            if active["pid"] and not spawner.is_pid_alive(int(active["pid"])):
                db.update(active["token"], status="cancelled", ended_at=db.now_iso())
            else:
                return JSONResponse(
                    {
                        "ok": False,
                        "blocker": True,
                        "error": (
                            f"Cannot start: an interview is already running for "
                            f"{active['candidate_name']!r}. End it first."
                        ),
                    },
                    status_code=409,
                )

    sessions.update_cadence(token, cadence_yaml)
    sessions.write_cadence_to_disk(token, cadence_yaml)
    try:
        pid = spawner.launch_orchestrator(token)
    except Exception as e:
        logger.exception("[admin] (api) spawner failed")
        return JSONResponse(
            {"ok": False, "error": f"Failed to launch orchestrator: {e}"}, status_code=500,
        )
    db.update(token, status="ready", pid=pid, ws_port=9100, http_port=8090)

    base = _candidate_link_base(request)
    candidate_link = f"{base}/app/candidate?token={token}"
    await _maybe_enqueue_invite(row, candidate_link)
    return JSONResponse({
        "ok": True,
        "candidate_link": candidate_link,
        # When the interview came from a Shortlist role, the page sends the
        # admin back to that role rather than stranding them on a single link —
        # the role's own screen lists every candidate and every link.
        "role_public_id": row.get("role_public_id") or "",
        # So the UI can show "Emailed to x@y.com" vs "No email on file" —
        # None here means _maybe_enqueue_invite was a no-op (blank email).
        "candidate_email": row.get("candidate_email") or None,
    })


@app.post("/api/schedule/{token}/approve")
async def api_cadence_approve(
    request: Request, token: str, body: _ApproveBody,
) -> JSONResponse:
    """JSON twin of cadence_approve() — validate the cadence, persist it,
    spawn the orchestrator, and return the candidate link."""
    if auth.get_current_user(request) is None:
        return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)
    row = db.get(token)
    if row is None:
        return JSONResponse({"ok": False, "error": "session not found"}, status_code=404)

    return await _approve_session(request, token, row, body.cadence_yaml)


@app.post("/api/schedule/{token}/send-invite-email")
async def send_invite_email(request: Request, token: str) -> JSONResponse:
    """(Re)send the candidate their interview link by email, on demand.

    Approving already enqueues this once automatically (`_maybe_enqueue_invite`,
    called from `_approve_session`), off whatever email existed at that moment.
    This is for everything after that: the admin wants to confirm it actually
    went out, it bounced, or the candidate never saw it — "resend" is a verb an
    admin reaches for more than once, so it stays available for as long as the
    interview has a link."""
    if auth.get_current_user(request) is None:
        return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)
    row = db.get(token)
    if row is None:
        return JSONResponse({"ok": False, "error": "session not found"}, status_code=404)
    if row.get("status") != "ready":
        return JSONResponse(
            {"ok": False, "error": "this interview has no link yet — approve it first"},
            status_code=409,
        )
    email = (row.get("candidate_email") or "").strip()
    if not email:
        return JSONResponse({"ok": False, "error": "no candidate email on file"}, status_code=400)

    candidate_link = _candidate_link_base(request) + f"/app/candidate?token={token}"
    await _maybe_enqueue_invite(row, candidate_link)
    return JSONResponse({"ok": True, "email": email})


@app.post("/admin/schedule/{token}/reopen")
def reopen_for_edit(request: Request, token: str) -> Response:
    """Re-open an interview for editing.

    Allowed while status is `draft` or `ready` — i.e. the candidate has not
    yet started the interview. Locked once status is `in_progress` or
    `completed`, since editing an interview the candidate is mid-way
    through (or has finished) would corrupt the transcript / eval record.

    For `ready` rows we MUST kill the spawned orchestrator subprocess
    first; otherwise the next approve would collide on Stream A's
    8090/9100 ports and the single-active-session guard would block.
    After kill, status reverts to `draft` and pid/ports are cleared.
    For `draft`, this is a no-op redirect (the cadence page already
    allows full edits without spawning anything).
    """
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    row = db.get(token)
    if row is None:
        raise HTTPException(404, "session not found")

    status = row["status"]
    if status in ("in_progress", "completed"):
        # Lock: candidate has engaged with the interview. Edits would
        # corrupt the live session or its transcript.
        return RedirectResponse(
            url=(
                "/admin/dashboard?error="
                + "Cannot+edit:+candidate+has+already+started+this+interview."
            ),
            status_code=303,
        )

    # Kill orchestrator if one is running for this row. is_pid_alive uses
    # psutil so it's cross-platform. We do best-effort terminate — if it
    # fails (already gone, permission denied) we proceed anyway since the
    # row is being reset to draft.
    # CRITICAL (cloud): in CLOUD_MODE the orchestrator runs IN-PROCESS, so the
    # spawner stores the gunicorn WORKER's own pid as a tracking placeholder —
    # NOT a separate subprocess. psutil-terminating it here would kill the web
    # worker itself (→ 502 "can't handle this request" on the very edit click).
    # Only kill a real spawned subprocess, which exists only outside CLOUD_MODE.
    pid = row["pid"]
    cloud = os.environ.get("CLOUD_MODE", "") == "1"
    if status == "ready" and pid and not cloud:
        try:
            import psutil
            if psutil.pid_exists(int(pid)):
                p = psutil.Process(int(pid))
                # Kill the children first (the actual orchestrator process
                # tree under the cmd/wt wrapper), then the wrapper itself.
                for child in p.children(recursive=True):
                    try:
                        child.terminate()
                    except Exception:
                        pass
                _, alive = psutil.wait_procs(p.children(recursive=True), timeout=3)
                for child in alive:
                    try:
                        child.kill()
                    except Exception:
                        pass
                try:
                    p.terminate()
                    p.wait(timeout=3)
                except Exception:
                    try:
                        p.kill()
                    except Exception:
                        pass
                logger.info("[admin] reopen: killed orchestrator pid=%s for token=%s", pid, token)
        except Exception as e:
            logger.warning("[admin] reopen: failed to kill pid=%s (%s); proceeding anyway", pid, e)

    db.update(
        token,
        status="draft",
        pid=None,
        ws_port=None,
        http_port=None,
    )
    logger.info("[admin] reopened session token=%s for edit (was %s)", token, status)
    return RedirectResponse(
        url=f"/admin/schedule/{token}/cadence",
        status_code=303,
    )


# ── retired live-observer URL ─────────────────────────────────────────────


@app.get("/admin/sessions/{token}/live")
def session_live(request: Request, token: str) -> Response:
    """The live observer is retired — an interview is the AI and the candidate
    only. Old observer links (in emails, bookmarks) still resolve: they land on
    the interview's detail page instead of a 404."""
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    if db.get(token) is None:
        raise HTTPException(404, "session not found")
    return RedirectResponse(url=f"/app/sessions/{token}", status_code=307)


# ── session detail ──────────────────────────────────────────────────────


def _session_detail_payload(request: Request, token: str, row: dict) -> dict:
    """Build the full session-detail view-model from the shared event_viewer
    + evaluation_service helpers. Returns a JSON-serializable dict consumed by
    BOTH the Jinja template (session_detail) and the React SPA endpoint
    (api_session_detail) — single source of truth, no logic reimplemented in TS.
    """
    event_log = session_dir(token) / (row["event_log_path"] or "events.jsonl")
    # Stateless-gateway read-through: the transcript + evaluation.json are written
    # on the session shard / worker and mirrored to Blob. If this replica's local
    # disk doesn't have them, hydrate from Blob before rendering.
    if not event_log.is_file():
        try:
            from app import blob_store
            blob_store.download_session_artifacts(token)
        except Exception:
            pass
    events = event_viewer.annotate(event_log)
    summary = event_viewer.summarize(events)
    evaluation = load_evaluation(token)
    # Build phase-flow tree for the Interview Flow section. Empty list when
    # no events have been recorded yet — the template hides the section.
    phases = event_viewer.group_by_phase(events)
    totals = event_viewer.session_totals(phases)
    mermaid_src = event_viewer.mermaid_flowchart(phases)
    # Per-model cost rollup for the Summary tab. The numbers come from
    # cost_tracker — the same accumulator that's updated synchronously
    # at every cost-computation point (apply_llm_result for LLMs,
    # observe_stt / observe_tts for speech). Whatever ships to Langfuse
    # via cost_details lands in this rollup too, so the dashboard and
    # Langfuse session totals agree. Read order: sidecar JSON (written
    # at SESSION_ENDED) → live in-process snapshot → deterministic rebuild
    # from events.jsonl (passed in below so it isn't parsed twice) → empty.
    per_model = event_viewer.load_per_model_summary(
        session_dir(token), token, events=events,
    )
    # Setup-time cost rollup — cadence generation/revision + eval-plugin/
    # rubric generation, i.e. LLM calls that ran BEFORE (or independent of)
    # this live interview session. Kept in a SEPARATE sidecar from
    # `per_model` above on purpose (see `app/setup_cost_tracker.py`): those
    # calls run under the same token but must never merge into the live
    # session's own per-model cost table. Empty rows list (not an error) for
    # any interview scheduled before this feature shipped.
    from app import setup_cost_tracker
    setup_per_model = setup_cost_tracker.load(token)
    # Langfuse deep-links. Both None when LANGFUSE_PROJECT_ID is unset —
    # template hides links gracefully. Lazy import so a missing langfuse
    # SDK doesn't crash admin.
    try:
        from engine.brain.observability.langfuse_client import (
            project_base_url as _lf_project_base_url,
            session_url as _lf_session_url,
        )
        langfuse_url = _lf_session_url(token)
        langfuse_project_base = _lf_project_base_url()
    except Exception:  # pragma: no cover
        langfuse_url = None
        langfuse_project_base = None
    # Evaluation rubric context for the Performance tab: per-phase lens
    # lookup (weight / scored dims / quarantined), whether the displayed
    # evaluation was generated WITH the rubric, and whether the rubric has
    # been EDITED since (semantic fingerprint mismatch) — both cases offer
    # one-click regeneration. Best-effort — absent rubric hides the context.
    rubric_by_phase: dict = {}
    eval_used_rubric = bool(evaluation and evaluation.get("rubric_used"))
    rubric_changed = False
    try:
        import features.eval as rubric_mod

        if rubric_mod.is_enabled():
            _rubric = rubric_mod.load_rubric(token)
            if _rubric:
                rubric_by_phase = {
                    s.get("phase_id"): s for s in _rubric.get("sections", [])
                    if isinstance(s, dict)
                }
                if eval_used_rubric:
                    current_fp = rubric_mod.rubric_fingerprint(_rubric)
                    eval_fp = evaluation.get("rubric_fingerprint")
                    rubric_changed = bool(eval_fp) and eval_fp != current_fp
    except Exception:
        logger.warning("[admin] rubric load for session_detail failed", exc_info=True)

    # Plugin evaluation (v2): expose whether the feature is on, whether this
    # evaluation used a plan, and whether the saved plan changed since it was
    # generated (fingerprint mismatch) — mirrors the rubric_changed logic.
    eval_plugins_enabled = False
    plan_used = bool(evaluation and evaluation.get("plan_used"))
    plan_changed = False
    try:
        import features.eval.plugins as _plugins_mod

        eval_plugins_enabled = _plugins_mod.is_enabled()
        if eval_plugins_enabled and plan_used:
            from features.eval import plan as _plan_mod
            from features.eval import plan_storage as _plan_storage

            _plan = _plan_storage.load_plan(token)
            if _plan:
                eval_fp = evaluation.get("plan_fingerprint")
                plan_changed = bool(eval_fp) and eval_fp != _plan_mod.plan_fingerprint(_plan)
    except Exception:
        logger.warning("[admin] eval plan load for session_detail failed", exc_info=True)

    # S7: pre-build per-call / per-verifier / per-override Langfuse trace
    # URLs on the phase tree so the React SPA renders deep-links WITHOUT
    # re-deriving the `{project_base}/traces/{id}` shape in TS (single
    # source of truth — the Jinja template builds the identical URL inline).
    # Additive only: the existing `langfuse_trace_id` fields stay untouched
    # so anything already reading them keeps working. No-op (None) when the
    # project base is unset or a record carries no trace id.
    def _trace_url(trace_id):
        if not trace_id or not langfuse_project_base:
            return None
        return f"{langfuse_project_base}/traces/{trace_id}"

    for _p in phases:
        for _t in _p.get("turns", []):
            _v = _t.get("verifier")
            if _v is not None:
                _v["langfuse_trace_url"] = _trace_url(_v.get("langfuse_trace_id"))
            _po = _t.get("phase_override")
            if _po is not None:
                _po["langfuse_trace_url"] = _trace_url(_po.get("langfuse_trace_id"))
            for _c in _t.get("llm_calls", []):
                _c["langfuse_trace_url"] = _trace_url(_c.get("langfuse_trace_id"))

    # S5: pre-build the candidate deep-link. It is gated on status (only meaningful while the interview is joinable),
    # mirroring the Jinja template's `{% if row['status'] in ('ready',
    # 'in_progress') %}` guard — otherwise None so the SPA hides the button.
    base = _candidate_link_base(request)
    candidate_interview_link = (
        f"{base}/app/candidate?token={token}"
        if row.get("status") in ("ready", "in_progress")
        else None
    )

    return {
        "row": row,
        "events": events,
        "summary": summary,
        "evaluation": evaluation,
        "candidate_link_base": base,
        # S5: prebuilt links (additive — candidate_link_base kept for
        # backward compat with any consumer still concatenating it).
        "candidate_interview_link": candidate_interview_link,
        "langfuse_url": langfuse_url,
        "langfuse_project_base": langfuse_project_base,
        "phases": phases,
        "totals": totals,
        "mermaid_src": mermaid_src,
        "per_model": per_model,
        "setup_per_model": setup_per_model,
        # Per-question coding view-model for the Performance tab.
        # None when the session has no coding submissions — the
        # template skips the section.
        "coding_perf": build_coding_performance(evaluation, phases),
        "rubric_by_phase": rubric_by_phase,
        "eval_used_rubric": eval_used_rubric,
        "rubric_changed": rubric_changed,
        "eval_plugins_enabled": eval_plugins_enabled,
        "plan_used": plan_used,
        "plan_changed": plan_changed,
    }


@app.get("/admin/sessions/{token}")
def session_detail(request: Request, token: str) -> Response:
    # Session detail + evaluation is the React SPA now; it loads its data from
    # GET /api/sessions/{token}/detail (built by _session_detail_payload below).
    return RedirectResponse(url=f"/app/sessions/{token}", status_code=307)


@app.get("/api/sessions/{token}/detail")
def api_session_detail(request: Request, token: str) -> JSONResponse:
    """JSON twin of session_detail() for the React SPA — same view-model."""
    if auth.get_current_user(request) is None:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    row = db.get(token)
    if row is None:
        return JSONResponse({"error": "session not found"}, status_code=404)
    return JSONResponse(_session_detail_payload(request, token, row))


@app.post("/api/sessions/{token}/evaluate")
async def api_session_evaluate(request: Request, token: str) -> JSONResponse:
    """JSON twin of evaluation_regenerate() — (re)generate from scratch and
    return the fresh evaluation so the SPA can re-render in place."""
    if auth.get_current_user(request) is None:
        return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)
    row = db.get(token)
    if row is None:
        return JSONResponse({"ok": False, "error": "session not found"}, status_code=404)
    try:
        evaluation = await generate_evaluation(token)
    except ValueError as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    except Exception as e:
        logger.exception("[admin] (api) evaluation generate failed")
        return JSONResponse({"ok": False, "error": f"Evaluation failed: {e}"}, status_code=500)
    return JSONResponse({"ok": True, "evaluation": evaluation})


# ── events.jsonl direct download ────────────────────────────────────────


def _evaluation_export_doc(token: str, *, merge_review: bool = True) -> dict[str, Any]:
    """The exported evaluation document for one session.

    Reads the stored artefact (local session dir, blob when the dir is cold —
    the gateway serves results read-through) and, by default, JOINS it with this
    session's human review. Both the scorecard endpoint and the download call
    THIS, because they are required to be the same document; two readers that
    each did their own merging is exactly how they would stop being one.

    `merge_review=False` returns the model's own output untouched — what a
    reviewer's correction is recorded against."""
    import json as _json
    path = session_dir(token) / "evaluation_export.json"
    raw: bytes | None = path.read_bytes() if path.exists() else None
    if raw is None:
        try:
            from app import blob_store
            raw = blob_store.download_bytes(f"{token}/evaluation_export.json")
        except Exception:
            raw = None
    if not raw:
        raise HTTPException(
            404, "no evaluation export for this session — run the evaluation first")
    doc = _json.loads(raw)
    if not merge_review:
        return doc
    from app import review_store
    return review_store.merge_into(token, doc)


@app.get("/api/sessions/{token}/evaluation-view")
def session_evaluation_view(request: Request, token: str) -> JSONResponse:
    """What the admin evaluation UI renders from.

    Two blocks, and the split is the whole point:

      `export`   — the exported document, joined with any human review.
                   Byte-for-byte what
                   /admin/sessions/{token}/evaluation-export.json serves. Every
                   score, state, mark, rationale, itemised breakdown and
                   per-plugin section the UI shows comes from here, so the
                   screen and the downloadable file cannot drift apart. That is
                   the "one source of truth" this endpoint exists to give.

      `evidence` — in-portal presentation context the export deliberately does
                   NOT carry: the transcript turns, the AI's question text, the
                   question material (passage / clip / image) and difficulty.
                   That content is candidate personal data and is excluded from
                   the export by a recorded decision
                   (docs/eval-export-pii-decision.md). It is served here, to an
                   authenticated admin, and never written to a file that leaves
                   the portal.

    So the UI is driven by the export and merely DECORATES it with evidence it
    is entitled to show — rather than rendering from a second scoring path."""
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    row = db.get(token)
    if row is None:
        raise HTTPException(404, "session not found")

    # The export — read through the same function the download serves, so the
    # screen and the file are one document, human review included.
    export_doc = _evaluation_export_doc(token)

    # Evidence, rebuilt from the event log for THIS request only.
    evidence: dict[str, Any] = {}
    try:
        evidence = _evaluation_evidence(token, row)
    except Exception as e:      # the scores still render without decoration
        logger.warning("[eval-view] evidence unavailable for %s: %s", token, e)

    return JSONResponse({"ok": True, "export": export_doc, "evidence": evidence})


def _evaluation_evidence(token: str, row: dict) -> dict[str, Any]:
    """Per-segment transcript + question material, keyed by segment_id.

    Rebuilt from events.jsonl rather than stored, so it cannot outlive the
    session's own retention and there is no second copy of candidate speech
    sitting on disk."""
    import yaml as _yaml
    from features.eval.sectioner import build_segments
    from app.plugin_evaluation import _read_events

    sdir = session_dir(token)
    events = _read_events(sdir / (row.get("event_log_path") or "events.jsonl"))
    cadence = _yaml.safe_load(row.get("cadence_yaml") or "") or {}
    interview = build_segments(events, cadence=cadence, token=token)

    out: dict[str, Any] = {}
    for _phase, seg in interview.iter_segments():
        out[seg.segment_id] = {
            "kind": seg.kind,
            "question_text": seg.question_text,
            "difficulty": seg.difficulty,
            "turns": [
                {"speaker": t.speaker, "text": t.text, "event_index": t.event_index}
                for t in seg.turns
            ],
        }
    return out


# ── human review of the evaluation ──────────────────────────────────────


class _ReviewBody(BaseModel):
    """One reviewer's verdict on one section, as the scorecard posts it."""

    segment_id: str
    section: str
    items: dict[str, float] = {}
    marks_earned: Optional[float] = None
    state: Optional[str] = None
    reason_kind: str
    reason: str
    note: str = ""


@app.post("/api/sessions/{token}/review")
def session_evaluation_review(request: Request, token: str, body: _ReviewBody) -> JSONResponse:
    """Record a human correction to one section of the LLM's evaluation.

    The model's own numbers are never touched: the correction is stored in the
    review ledger and joined in on read, so `marks_earned` in the export keeps
    meaning "what the model said" and `review.final_marks_earned` is what counts.
    That split is what makes a regenerate safe (it rewrites the AI's values, not
    the human's) and what leaves every adjustment usable as a labelled example
    of where the model is wrong.

    Returns the merged document so the scorecard re-renders from the same source
    the download serves, rather than patching its own copy."""
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    if db.get(token) is None:
        raise HTTPException(404, "session not found")

    from app import review_store
    from features.eval.review import ReviewSubmission, records_from_submission

    # Freeze the AI values from the UNMERGED document — a correction is recorded
    # against what the model said, not against an earlier human's edit.
    ai_doc = _evaluation_export_doc(token, merge_review=False)
    section_doc = next(
        (x for x in (ai_doc.get("sections") or [])
         if x.get("segment_id") == body.segment_id and x.get("section") == body.section),
        None,
    )
    if section_doc is None:
        raise HTTPException(404, f"no section {body.section!r} on segment {body.segment_id!r}")

    try:
        sub = ReviewSubmission.model_validate(body.model_dump())
    except Exception as e:
        raise HTTPException(400, f"invalid review: {e}")

    reviewer = str(auth.get_current_user(request) or "")
    records = records_from_submission(
        token, sub, section_doc, reviewer=reviewer,
        generated_at=str(ai_doc.get("generated_at") or ""))
    review_store.save(records)
    return JSONResponse({"ok": True, "export": _evaluation_export_doc(token)})


@app.delete("/api/sessions/{token}/review")
def session_evaluation_review_withdraw(
    request: Request, token: str, segment_id: str, section: str,
) -> JSONResponse:
    """Retire one section's review — the scorecard falls back to the AI's own
    numbers. Not a delete: the rows stay, marked superseded, because "a human
    adjusted this and then withdrew it" is itself part of the record."""
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    if db.get(token) is None:
        raise HTTPException(404, "session not found")
    from app import review_store
    review_store.withdraw(token, segment_id, section)
    return JSONResponse({"ok": True, "export": _evaluation_export_doc(token)})


@app.get("/admin/sessions/{token}/evaluation-export.json")
def session_evaluation_export(request: Request, token: str, inline: int = 0) -> Response:
    """The machine-readable evaluation export for one session — ONE file for the
    whole evaluation, not a file per plugin.

    This is the document an outside consumer is meant to read: versioned, with
    every section's JSON schema travelling inside it, so it validates itself
    without fetching anything from us. It deliberately carries integer event
    pointers rather than transcript text — see docs/eval-export-pii-decision.md.

    Falls back to blob when the local session dir is cold (the gateway serves
    results read-through, same as the other artefacts). `?inline=1` renders it
    in the browser instead of downloading."""
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    if db.get(token) is None:
        raise HTTPException(404, "session not found")

    import json as _json
    body = _json.dumps(_evaluation_export_doc(token), indent=2).encode("utf-8")

    if inline:
        return Response(content=body, media_type="application/json")
    return Response(
        content=body,
        media_type="application/json",
        headers={
            "Content-Disposition":
                f'attachment; filename="evaluation-{token[:8]}.json"',
        },
    )


@app.get("/admin/sessions/{token}/events.jsonl")
def session_events_download(request: Request, token: str, inline: int = 0) -> Response:
    """Stream the raw events.jsonl for one session.

    Lightweight alternative to the full bundle zip when you just want the
    structured event log — handy for piping into jq / sharing with engineering
    without the resume/JD attached. Admin-auth gated.

    With `?inline=1` the response is served as `text/plain` without a
    Content-Disposition header, so browsers render it instead of downloading.
    Default (no query / `inline=0`) downloads as `events-<token>.jsonl`."""
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    row = db.get(token)
    if row is None:
        raise HTTPException(404, "session not found")
    log_path = session_dir(token) / (row["event_log_path"] or "events.jsonl")
    if not log_path.exists():
        raise HTTPException(404, "events.jsonl not present for this session")
    body = log_path.read_bytes()
    if inline:
        return Response(content=body, media_type="text/plain; charset=utf-8")
    filename = f"events-{token[:8]}.jsonl"
    return Response(
        content=body,
        media_type="application/x-ndjson",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
        },
    )


# ── session bundle download (debugging artifact) ────────────────────────


@app.get("/admin/sessions/{token}/download")
def session_download(request: Request, token: str) -> Response:
    """Stream a zip of the session directory for debugging.

    Includes: events.jsonl, cadence.yaml, resume, JD, evaluation.json, plus
    a generated `manifest.json` with session metadata + the Langfuse deep
    link so the zip is self-describing. Streamed to keep memory bounded —
    events.jsonl can be MBs on long interviews.
    """
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    row = db.get(token)
    if row is None:
        raise HTTPException(404, "session not found")
    sdir = session_dir(token)
    # Stateless-gateway read-through: hydrate artifacts from Blob if this replica
    # doesn't have them locally (they were written on the session shard / worker).
    if not (sdir / "events.jsonl").is_file():
        try:
            from app import blob_store
            blob_store.download_session_artifacts(token)
        except Exception:
            pass
    if not sdir.exists():
        raise HTTPException(404, "session directory missing")

    # Build manifest synchronously — small JSON, in-memory.
    import io
    import json
    import zipfile
    from datetime import datetime

    try:
        from engine.brain.observability.langfuse_client import session_url as _lf_session_url
        lf_session_url = _lf_session_url(token)
    except Exception:  # pragma: no cover
        lf_session_url = None

    manifest = {
        "token": token,
        "candidate_name": row["candidate_name"],
        "role": row["role"],
        "status": row["status"],
        "created_at": row["created_at"],
        "ended_at": row["ended_at"],
        "langfuse_session_url": lf_session_url,
        "bundled_at": datetime.utcnow().isoformat() + "Z",
        "bundled_by": "admin",
    }

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("manifest.json", json.dumps(manifest, indent=2))
        # Walk the session dir and add everything. Paths inside the zip
        # are rooted at the session directory (so unzipping gives a clean
        # `<token>/...` layout).
        for entry in sdir.rglob("*"):
            if entry.is_file():
                arcname = str(entry.relative_to(sdir.parent))
                try:
                    zf.write(entry, arcname=arcname)
                except OSError as e:
                    logger.warning(
                        "[admin] skip file in bundle %s: %s", entry, e,
                    )

    buf.seek(0)
    date_tag = datetime.utcnow().strftime("%Y%m%d")
    filename = f"interview-{token[:8]}-{date_tag}.zip"
    return Response(
        content=buf.getvalue(),
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
        },
    )


# ── performance evaluation ──────────────────────────────────────────────


@app.post("/admin/sessions/{token}/evaluate")
async def evaluation_regenerate(request: Request, token: str) -> Response:
    """Regenerate the candidate's evaluation from scratch. Overwrites any
    existing evaluation.json. Redirects back to the session detail page."""
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    row = db.get(token)
    if row is None:
        raise HTTPException(404, "session not found")
    try:
        await generate_evaluation(token)
    except Exception as e:
        logger.exception("[admin] evaluation regenerate failed")
        raise HTTPException(500, f"Evaluation failed: {e}")
    return RedirectResponse(
        url=f"/admin/sessions/{token}#performance",
        status_code=303,
    )


class _ReviseEvalBody(BaseModel):
    feedback: str


@app.post("/api/sessions/{token}/evaluation/revise")
async def evaluation_revise(
    request: Request, token: str, body: _ReviseEvalBody,
) -> JSONResponse:
    """Iterate the evaluation with admin feedback. Returns the revised
    evaluation dict so the page can re-render in place."""
    if auth.get_current_user(request) is None:
        return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)
    if not body.feedback.strip():
        return JSONResponse(
            {"ok": False, "error": "feedback is empty"}, status_code=400,
        )
    prior = load_evaluation(token)
    if prior is None:
        return JSONResponse(
            {"ok": False, "error": "no prior evaluation found — generate one first"},
            status_code=400,
        )
    try:
        revised = await generate_evaluation(
            token, feedback=body.feedback, prior=prior,
        )
    except ValueError as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    except Exception as e:
        logger.exception("[admin] evaluation revise failed")
        return JSONResponse(
            {"ok": False, "error": f"LLM error: {e}"}, status_code=500,
        )
    return JSONResponse({"ok": True, "evaluation": revised})


# ── archive / delete ─────────────────────────────────────────────────────


@app.post("/admin/sessions/{token}/archive")
def session_archive(request: Request, token: str) -> Response:
    """Soft-delete: mark a session as cancelled so it no longer blocks
    new schedules via `has_active_session()`. Files on disk + transcript
    + evaluation are preserved; the row stays in the dashboard with
    status='cancelled' (and an updated ended_at)."""
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    row = db.get(token)
    if row is None:
        raise HTTPException(404, "session not found")
    db.archive(token)
    logger.info(
        "[admin] archived session token=%s candidate=%r prev_status=%s",
        token, row["candidate_name"], row["status"],
    )
    return RedirectResponse(url="/admin/dashboard", status_code=303)


async def _end_live_session(token: str, reason: str) -> None:
    """If an in-process broadcaster is hosting an active session for this
    token (cloud mode only — `deploy.azure_app._token_sessions`), emit a
    `session_ended` control frame so a connected candidate sees a clean
    "Session ended" instead of a silent disconnect, then cancel the runner
    so the orphan reaper can clean up.

    No-op in local-dev (admin runs as its own process; the broadcaster
    lives in a separate per-session orchestrator subprocess, not in
    `_token_sessions`). Lazy import so admin/main.py stays usable without
    deploy/azure_app being importable.
    """
    try:
        from deploy.azure_app import (
            _token_sessions, _token_sessions_lock,
        )
    except Exception:
        return
    import asyncio as _asyncio
    async with _token_sessions_lock:
        handle = _token_sessions.pop(token, None)
    if handle is None:
        return
    try:
        handle.broadcaster.emit_control("session_ended", reason=reason)
        await _asyncio.sleep(0.1)  # let the frame land before stop()
    except Exception:
        pass
    if not handle.runner_task.done():
        handle.runner_task.cancel()
    try:
        await handle.broadcaster.stop()
    except Exception:
        pass


@app.post("/admin/sessions/{token}/delete")
async def session_delete(request: Request, token: str) -> Response:
    """Hard-delete: drop the SQLite row AND rm -rf the session_dir.
    Irreversible — the resume, cadence, events, evaluation are gone.
    Use Archive instead unless you really need the disk space back or
    you accidentally created a test session you want gone."""
    import shutil
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    row = db.get(token)
    if row is None:
        raise HTTPException(404, "session not found")
    # End any live session + tear down its broadcaster BEFORE rm -rf,
    # otherwise the runner_task might keep writing events.jsonl into a
    # path we just deleted.
    if row["status"] == "in_progress":
        await _end_live_session(token, reason="admin_delete")
    sdir = session_dir(token)
    db.delete(token)
    if sdir.is_dir():
        try:
            shutil.rmtree(sdir)
        except Exception as e:
            logger.warning("[admin] delete: rm -rf %s failed (row already gone): %s", sdir, e)
    logger.info(
        "[admin] deleted session token=%s candidate=%r dir=%s",
        token, row["candidate_name"], sdir,
    )
    return RedirectResponse(url="/admin/dashboard", status_code=303)


def _bulk_delete_tokens(tokens: list[str]) -> tuple[int, list[str]]:
    """Hard-delete N sessions: drop the SQLite row AND rm -rf the
    session_dir per token. Shared core for both the Jinja form route and
    the JSON API twin. Returns (deleted_count, skipped_tokens).

    A token is SKIPPED (not deleted) when it's unknown OR currently
    in_progress — a live interview is still writing events.jsonl, so we
    refuse to yank its dir out from under the orchestrator. Unknown tokens
    are silently dropped from the skipped list (nothing to delete) to match
    the original form route's behaviour."""
    import shutil
    deleted = 0
    skipped: list[str] = []
    for token in tokens:
        row = db.get(token)
        if row is None:
            continue
        if row["status"] == "in_progress":
            skipped.append(token)
            continue
        sdir = session_dir(token)
        try:
            db.delete(token)
        except Exception as e:
            logger.warning("[admin] bulk_delete: db.delete(%s) failed: %s", token, e)
            continue
        if sdir.is_dir():
            try:
                shutil.rmtree(sdir)
            except Exception as e:
                logger.warning("[admin] bulk_delete: rm -rf %s failed: %s", sdir, e)
        deleted += 1
    logger.info(
        "[admin] bulk_delete: deleted=%d skipped=%d (%r) of %d requested",
        deleted, len(skipped), skipped, len(tokens),
    )
    return deleted, skipped


@app.post("/admin/sessions/bulk_delete")
async def sessions_bulk_delete(request: Request) -> Response:
    """Hard-delete N sessions in one call. Body: form-encoded
    `tokens=<a>&tokens=<b>&...`. Same semantics as the single-token
    delete (SQLite row + rm -rf session_dir per token).
    Sessions currently in_progress are skipped — terminate them first.
    """
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    form = await request.form()
    tokens = [t for t in form.getlist("tokens") if t]
    _deleted, skipped = _bulk_delete_tokens(tokens)
    qs = f"?error=Skipped+{len(skipped)}+in-progress+sessions" if skipped else ""
    return RedirectResponse(url=f"/admin/dashboard{qs}", status_code=303)


class _BulkDeleteBody(BaseModel):
    tokens: list[str]


@app.post("/api/sessions/bulk_delete")
def api_sessions_bulk_delete(request: Request, body: _BulkDeleteBody) -> JSONResponse:
    """JSON twin of sessions_bulk_delete() for the React dashboard (D1).
    Accepts {tokens: string[]}, hard-deletes each (row + session_dir), and
    returns {ok, deleted, skipped} — `skipped` lists tokens that were
    in_progress and therefore left intact. Same auth + delete semantics as
    the form route; both share _bulk_delete_tokens()."""
    if auth.get_current_user(request) is None:
        return JSONResponse({"ok": False, "error": "unauthorized"}, status_code=401)
    tokens = [t for t in (body.tokens or []) if t]
    deleted, skipped = _bulk_delete_tokens(tokens)
    return JSONResponse({"ok": True, "deleted": deleted, "skipped": skipped})


# ── candidate redirect ──────────────────────────────────────────────────


@app.get("/candidate", response_class=HTMLResponse)
def candidate_join(request: Request, token: str) -> Response:
    row = db.get(token)
    if row is None:
        return templates.TemplateResponse(
            "candidate_notice.html",
            {
                "request": request,
                "title": "Link not recognized",
                "message": (
                    "This interview link is invalid. Please contact your "
                    "interviewer for a fresh link."
                ),
            },
            status_code=404,
        )
    status = row["status"]
    if status in ("completed", "cancelled"):
        return templates.TemplateResponse(
            "candidate_notice.html",
            {
                "request": request,
                "title": "This interview has ended",
                "message": (
                    "Thanks for stopping by. If you believe you should still "
                    "be able to join, please contact your interviewer."
                ),
            },
        )
    if status == "draft":
        return templates.TemplateResponse(
            "candidate_notice.html",
            {
                "request": request,
                "title": "Interview not yet started",
                "message": (
                    "Your interview link isn't active yet. Please contact "
                    "your interviewer."
                ),
            },
        )

    # status in ('ready', 'in_progress', 'launching') → redirect to lobby.
    #
    # Local mode: orchestrator runs its own static-UI server on
    #   row['http_port'] (default 8090) and WS on row['ws_port'] (default
    #   9100). We point the candidate at that secondary port.
    # Cloud mode (CLOUD_MODE=1): one container, one port. The candidate
    #   UI is served from the SAME host that's serving this admin page,
    #   under the path /candidate/ (or wherever the deploy mounts it).
    #   We use a relative URL so it works through any reverse proxy
    #   (App Gateway, Front Door) without leaking internal hostnames.
    qs_dict = {
        "token": token,
        "name": row["candidate_name"],
        "role": row["role"],
    }
    if os.environ.get("CLOUD_MODE", "") == "1":
        target = f"/candidate/?{urlencode(qs_dict)}"
    else:
        host = request.url.hostname or "localhost"
        qs_dict["ws"] = row["ws_port"] or 9100
        target = f"http://{host}:{row['http_port'] or 8090}/?{urlencode(qs_dict)}"
    return RedirectResponse(url=target, status_code=302)


# ── helpers ─────────────────────────────────────────────────────────────


def _candidate_link_base(request: Request) -> str:
    """The host[:port] the admin app is reachable on, used to build the
    candidate-facing link printed on the approval page.

    Local dev: scheme = http, port = 8000.
    Cloud (App Service, App Gateway, Front Door): scheme = https, port
    is implicit (443). We respect whatever the inbound request used so
    the link the TA copies works for the candidate without surprises."""
    scheme = request.url.scheme or "http"
    host = request.url.hostname or "localhost"
    port = request.url.port  # None for default port (80/443)
    if port and port not in (80, 443):
        return f"{scheme}://{host}:{port}"
    # Local-dev safety net: if there's no explicit port and we're not in
    # cloud, fall back to admin's well-known dev port.
    if not port and os.environ.get("CLOUD_MODE", "") != "1":
        return f"{scheme}://{host}:8000"
    return f"{scheme}://{host}"


async def _maybe_enqueue_invite(row: dict, candidate_link: str) -> None:
    """Enqueues the invite-email job if this schedule has a candidate email.

    Called right after a cadence approve mints candidate_link — silently a
    no-op (not an error) when no email was entered at schedule time, so
    approval never fails or blocks on this; the admin still has the
    copy-pasteable link either way. The actual send (and whether SMTP is
    even configured) happens async on the worker tier (app.jobs.jobs
    invite_dispatch) — this call just returns instantly."""
    email = (row.get("candidate_email") or "").strip()
    if not email:
        return
    from app.jobs import jobs as _jobs
    try:
        await _jobs.enqueue(
            _jobs.INVITE_DISPATCH,
            {
                "token": row["token"],
                "to": email,
                "candidate_name": row["candidate_name"],
                "role": row["role"],
                "link": candidate_link,
            },
            token=row["token"],
        )
    except Exception:
        # Best-effort — the candidate link itself is already minted and
        # returned to the admin, so a queue hiccup here shouldn't surface
        # as an approve failure. Logged for visibility.
        logger.exception("[admin] failed to enqueue invite_dispatch for token=%s", row["token"][:8])


# ── candidate session metadata (recording opt-in) ───────────────────────
# NOTE: in CLOUD_MODE the live `/session-info` is served by
# deploy/azure_app.py (registered first → it wins) for the old single-box
# monolith deploy; on the tiered deploy the candidate reaches this main.py
# route via the gateway. Both handlers must agree, so both read the same
# cadence.yaml-first / DB-fallback logic below.


def _interview_over(token: Optional[str], status: Optional[str]) -> bool:
    # session_info is a sync handler (it runs in a worker thread), and the
    # checkpoint store is async Redis — hop back onto the loop for the one case
    # that needs it. Every other status answers without touching Redis.
    if not token or status not in ("completed", "cancelled"):
        return False
    import anyio.from_thread
    from app.coordination import interview_checkpoint
    return anyio.from_thread.run(interview_checkpoint.interview_over, token, status)


@app.get("/session-info")
def session_info(token: Optional[str] = None) -> JSONResponse:
    """Pre-interview metadata for the candidate lobby: estimated duration + role
    (from the admin-approved cadence / session row) + record_enabled.

    The CANDIDATE reaches this via the gateway (which serves app.main routes), so
    this handler — not the session-tier one in deploy/azure_app.py — must carry
    duration_min + role; without them the lobby shows a generic "the role" /
    "~30 minutes". duration comes from total_duration_s (loader-validated); role
    from the session row the admin filled in at schedule time.

    record_enabled is read from the approved cadence.yaml's recording_enabled
    (stamped in deterministically at generation time — see
    app.cadence_service.apply_recording_flag), falling back to the DB row for
    tokens whose cadence hasn't been approved to disk yet. Missing on either
    → True, matching the mandatory camera+screen behavior every interview had
    before this flag existed."""
    duration_min: Optional[int] = None
    role = ""
    record_enabled = True
    modality = "voice"
    status: Optional[str] = None

    def _load_plan(p: Path):
        try:
            if p.exists():
                from engine.brain.cadence import load_cadence_yaml
                return load_cadence_yaml(p)
        except Exception as e:  # never break the lobby
            logger.debug("[session-info] cadence load failed for %s: %s", p, e)
        return None

    plan = _load_plan(session_dir(token) / "cadence.yaml") if token else None
    if plan is not None:
        duration_min = max(1, round(plan.total_duration_s / 60))
        record_enabled = bool(plan.recording_enabled)
        modality = "text" if not plan.timed else "voice"
    row = None
    if token:
        row = db.get(token)
        if row is not None:
            role = (row.get("role") or "").strip()
            modality = row.get("modality") or modality  # DB row is authoritative
            if plan is None:
                record_enabled = bool(row.get("record_enabled"))
            # Lets the candidate page recognize an already-finished interview
            # on LOAD and go straight to a Done screen — mirrors the identical
            # field added to deploy/azure_app.py's twin handler.
            status = row.get("status")
    if duration_min is None:
        default_path = Path(os.environ.get(
            "CADENCE_PATH", REPO_ROOT / "engine" / "brain" / "cadence" / "default.yaml"))
        default_plan = _load_plan(default_path)
        duration_min = max(1, round(default_plan.total_duration_s / 60)) if default_plan else None
    # LiveKit media (behind MEDIA_TRANSPORT=livekit). This is the handler the
    # candidate actually reaches in the tiered deploy, so it must carry the
    # room details too — without them the page stays on the WebSocket path.
    from engine.orchestrator.livekit.tokens import livekit_offer
    return JSONResponse({
        "duration_min": duration_min or 30, "role": role, "record_enabled": record_enabled,
        "modality": modality, "status": status,
        "interview_over": _interview_over(token, status),
        "livekit": livekit_offer(token, row),
    })


# ── Simli avatar session token (candidate-facing) ────────────────────────
# WHY this endpoint exists at all: simli-client mints its session by putting the
# RAW api key in an `x-simli-api-key` header (generateSimliSessionToken /
# generateIceServers). Doing that in the browser would ship our metered key to
# every candidate — readable in devtools, spendable by anyone. So the key stays
# here and the browser only ever receives a short-lived session token.
#
# Gated on a real interview token for the same reason: this endpoint spends
# money, so it must not be an open minting service.


@app.get("/api/simli/token")
async def simli_token(token: Optional[str] = None) -> JSONResponse:
    """Mint a Simli session token + ICE servers for the candidate's browser.

    Returns 503 (not 500) when unconfigured, so the client treats it as "Simli
    unavailable" and falls back to the minimal orb — the same degradation path
    as bootAvatar() returning null. An avatar is never worth failing a lobby."""
    api_key = (os.environ.get("SIMLI_API_KEY") or "").strip()
    face_id = (os.environ.get("SIMLI_FACE_ID") or "").strip()
    if not api_key or not face_id:
        return JSONResponse({"error": "simli_not_configured"}, status_code=503)

    if not token or db.get(token) is None:
        return JSONResponse({"error": "unknown_session"}, status_code=403)

    # maxIdleTime is the cost guard, not a nicety: Simli bills wall-clock
    # streaming minutes INCLUDING silence, and an interview is mostly the
    # candidate talking. A tab left open would bill until maxSessionLength.
    cfg = {
        "faceId": face_id,
        "handleSilence": True,
        "maxSessionLength": int(os.environ.get("SIMLI_MAX_SESSION_S", "3600")),
        "maxIdleTime": int(os.environ.get("SIMLI_MAX_IDLE_S", "300")),
    }
    # "fasttalk" | "artalk" — the only lever over how the face performs. There is
    # NO client-side expression/emotion API (checked the whole SDK), so the model
    # and the chosen face are the two things that decide how expressive it looks.
    # Unset → Simli's own default, so this cannot break an otherwise-working call.
    model = (os.environ.get("SIMLI_MODEL") or "").strip()
    if model:
        cfg["model"] = model
    headers = {"Content-Type": "application/json", "x-simli-api-key": api_key}
    try:
        import httpx
        async with httpx.AsyncClient(timeout=15.0) as client:
            tok = await client.post(
                "https://api.simli.ai/compose/token", json=cfg, headers=headers)
            if tok.status_code != 200:
                logger.warning("[simli] token mint failed: %s %s",
                               tok.status_code, tok.text[:200])
                return JSONResponse({"error": "simli_token_failed"}, status_code=503)
            session_token = (tok.json() or {}).get("session_token")
            # ICE is best-effort: simli-client falls back to a public STUN server
            # on its own. That has no TURN, so a candidate behind strict NAT would
            # fail to connect — worth fetching, not worth failing over.
            ice: list = []
            try:
                r = await client.get("https://api.simli.ai/compose/ice", headers=headers)
                if r.status_code == 200:
                    ice = r.json() or []
            except Exception as e:
                logger.debug("[simli] ice fetch failed (non-fatal): %s", e)
    except Exception as e:
        logger.warning("[simli] token mint error: %s", e)
        return JSONResponse({"error": "simli_unreachable"}, status_code=503)

    if not session_token:
        return JSONResponse({"error": "simli_token_empty"}, status_code=503)
    return JSONResponse({"session_token": session_token, "ice_servers": ice})


# ── interview recording (camera+mic / screen → blob) ─────────────────────


def _recording_blob(token: str, kind: str, part: int) -> str:
    # Part 0 keeps the original name, so an interview recorded in one go (and
    # every recording made before parts existed) is exactly where it always was.
    return f"{token}/recording/{kind}.webm" if part == 0 else f"{token}/recording/{kind}.part{part}.webm"


def _next_recording_part(token: str, kind: str) -> int:
    from app import blob_store
    part = 0
    while part < 50 and blob_store.blob_size(_recording_blob(token, kind, part)):
        part += 1
    return part


@app.post("/api/sessions/{token}/recording")
async def recording_upload(
    token: str,
    kind: str,
    seq: int = 0,
    part: str = "0",
    file: UploadFile = File(...),
) -> JSONResponse:
    """Candidate UI streams a recorded webm INCREMENTALLY: one ~1s MediaRecorder
    chunk per POST, appended (in order) to an append-blob at
    `<token>/recording/<kind>.webm`. seq=0 creates/overwrites the append blob
    (start of recording); seq>0 appends. Incremental = the recording survives
    the candidate closing the tab mid-interview (the old single-upload-at-end
    lost everything on disconnect). `kind` must be camera|screen.

    `part=new` on seq=0 starts the recording in the first FREE part and returns
    its number for the rest of the chunks. A page that starts recording again
    (a refresh, or a new device after a crash) would otherwise send seq=0 to the
    same name and overwrite everything recorded before it. Pages that don't send
    it (an old bundle) get the old behaviour, part 0.

    No admin gate: the candidate (not an admin) is the uploader, and the
    session token is the capability. We validate the session + kind below."""
    if kind not in ("camera", "screen"):
        return JSONResponse({"ok": False, "error": "kind must be camera|screen"}, status_code=400)
    if db.get(token) is None:
        return JSONResponse({"ok": False, "error": "session not found"}, status_code=404)
    if part == "new" and seq == 0:
        n = _next_recording_part(token, kind)
    else:
        try:
            n = max(0, int(part))
        except ValueError:
            return JSONResponse({"ok": False, "error": "part must be a number or 'new'"}, status_code=400)
    from app import blob_store
    try:
        data = await file.read()
        blob_store.append_chunk(_recording_blob(token, kind, n), data, create=(seq == 0))
    except Exception as e:  # pragma: no cover - best-effort mirror
        logger.warning("[recording] append failed for %s/%s part=%s seq=%s: %s", token, kind, n, seq, e)
    return JSONResponse({"ok": True, "part": n})


@app.get("/api/sessions/{token}/recording-parts")
def recording_parts(request: Request, token: str) -> JSONResponse:
    """Which parts exist per track, e.g. {"camera": [0, 1], "screen": [0]}. More
    than one part means the candidate refreshed (or changed device) mid-interview."""
    if auth.get_current_user(request) is None:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    from app import blob_store
    parts: dict[str, list[int]] = {"camera": [], "screen": []}
    from engine.orchestrator.livekit.egress import egress_part_names
    names = blob_store.list_blobs(f"{token}/recording/")
    for name in names:
        m = re.fullmatch(r".*/recording/(camera|screen)(?:\.part(\d+))?\.webm", name)
        if m:
            parts[m.group(1)].append(int(m.group(2) or 0))
    # Server recordings, one per runner (a handed-off interview has several),
    # addressed by their order: /recording/livekit?part=i. `livekit_parts` adds
    # each one's state (recording / processing / ready / failed), including a
    # part whose file never landed — `livekit` lists only the playable ones.
    from engine.orchestrator.livekit.egress import part_statuses
    livekit = list(range(len(egress_part_names(names))))
    return JSONResponse({**{k: sorted(v) for k, v in parts.items()}, "livekit": livekit,
                         "livekit_parts": part_statuses(names)})


@app.get("/api/sessions/{token}/recording/{kind}")
def recording_download(request: Request, token: str, kind: str, part: int = 0) -> Response:
    """Stream a previously-uploaded recording track back (admin-gated, for
    fraud review). 404 if blob is disabled or the track is missing.

    Supports HTTP Range so the browser's <video> can start playing before the
    whole file lands and can scrub/seek. Without this the old endpoint read the
    entire (multi-hundred-MB) webm into memory and returned it whole, so review
    playback was slow to start and couldn't seek."""
    if (redir := _require_user_or_redirect(request)) is not None:
        return redir
    if kind not in ("camera", "screen", "livekit"):
        raise HTTPException(400, "kind must be camera|screen|livekit")
    from app import blob_store

    # "livekit" = the server-side recording of both voices, written by LiveKit
    # egress (engine/orchestrator/livekit/egress.py), not uploaded by the page.
    if kind == "livekit":
        from engine.orchestrator.livekit.egress import egress_part_names
        names = egress_part_names(blob_store.list_blobs(f"{token}/recording/"))
        if not 0 <= part < len(names):
            raise HTTPException(404, "recording not available")
        blob_name, media_type = names[part], "audio/ogg"
    else:
        blob_name, media_type = _recording_blob(token, kind, max(0, part)), "video/webm"
    size = blob_store.blob_size(blob_name)
    if size is None:
        raise HTTPException(404, "recording not available")

    base_headers = {"Accept-Ranges": "bytes", "Cache-Control": "private, max-age=300"}

    # Parse a single-range "bytes=start-end" request. Anything we don't
    # understand falls through to a full 200 stream.
    range_header = request.headers.get("range") or request.headers.get("Range")
    start, end = 0, size - 1
    is_range = False
    if range_header and range_header.startswith("bytes="):
        spec = range_header[len("bytes="):].split(",")[0].strip()
        s, _, e = spec.partition("-")
        try:
            if s:
                start = int(s)
                end = int(e) if e else size - 1
            elif e:  # suffix range: bytes=-N → last N bytes
                start = max(0, size - int(e))
                end = size - 1
            if start > end or start >= size:
                raise ValueError("unsatisfiable")
            end = min(end, size - 1)
            is_range = True
        except ValueError:
            # Malformed/unsatisfiable range → 416 with the valid extent.
            return Response(
                status_code=416,
                headers={**base_headers, "Content-Range": f"bytes */{size}"},
            )

    length = end - start + 1
    chunks = blob_store.download_stream(blob_name, offset=start, length=length)
    if chunks is None:
        raise HTTPException(404, "recording not available")

    headers = {**base_headers, "Content-Length": str(length)}
    status = 200
    if is_range:
        headers["Content-Range"] = f"bytes {start}-{end}/{size}"
        status = 206
    return StreamingResponse(chunks, status_code=status, media_type=media_type, headers=headers)


# ── observer notes (read-only) ────────────────────────────────────────────
# The live observer is retired, so nothing creates notes any more. Notes taken
# during past interviews stay readable on those interviews' detail pages.


@app.get("/api/sessions/{token}/notes")
def observer_notes_list(request: Request, token: str) -> JSONResponse:
    """List the observer notes recorded for a past session, oldest first."""
    if auth.get_current_user(request) is None:
        return JSONResponse({"error": "unauthorized"}, status_code=401)
    from db.engine import session_scope
    from db.models import ObserverNote
    from sqlalchemy import select
    with session_scope() as s:
        rows = s.execute(
            select(ObserverNote)
            .where(ObserverNote.session_token == token)
            .order_by(ObserverNote.created_at.asc(), ObserverNote.id.asc())
        ).scalars().all()
        notes = [{
            "id": n.id,
            "session_token": n.session_token,
            "created_at": n.created_at,
            "author": n.author,
            "kind": n.kind,
            "text": n.text,
            "competency": n.competency,
            "score": n.score,
        } for n in rows]
    return JSONResponse({"notes": notes})


# ── React SPA (ui/web) served at /app, coexisting with the Jinja admin ────
# The built bundle (ui/web/dist) is produced by the Docker node stage (or
# `npm run build` locally). We serve its assets under /app/assets and return
# index.html for every other /app/* path so React Router owns client-side
# routing. Registered LAST and scoped to /app, so it never shadows /admin,
# /api, /candidate, or /admin/static. Absent dist (dev without a build) just
# means /app 404s — the legacy admin is unaffected.
_SPA_DIST = REPO_ROOT / "ui" / "web" / "dist"
_SPA_INDEX = _SPA_DIST / "index.html"


class _ImmutableAssets(StaticFiles):
    """Serve Vite's content-hashed bundles with a long, immutable cache.

    The filenames embed a content hash (index-<hash>.js), so a changed bundle is
    a new URL — caching the old one forever is safe AND desirable (zero revalidation
    round-trips). The SPA *shell* (index.html) is the opposite: it must NOT be
    cached (see _spa below), so it always picks up the latest bundle hash."""

    def file_response(self, *args: object, **kwargs: object) -> Response:
        resp = super().file_response(*args, **kwargs)  # type: ignore[arg-type]
        resp.headers["Cache-Control"] = "public, max-age=31536000, immutable"
        return resp


if _SPA_INDEX.is_file():
    _assets_dir = _SPA_DIST / "assets"
    if _assets_dir.is_dir():
        app.mount("/app/assets", _ImmutableAssets(directory=str(_assets_dir)), name="spa-assets")

    @app.get("/app", response_class=HTMLResponse)
    @app.get("/app/{full_path:path}", response_class=HTMLResponse)
    def _spa(full_path: str = "") -> Response:
        # Any non-asset /app path returns the SPA shell; React Router renders.
        # NEVER cache the shell — a stale index.html pins an old bundle hash, so
        # browsers would keep running old JS after a deploy (this is exactly why
        # deploys used to "not take"). no-cache forces
        # a revalidation every load; the hashed assets above stay immutable.
        return FileResponse(
            str(_SPA_INDEX),
            headers={"Cache-Control": "no-cache, must-revalidate", "Pragma": "no-cache"},
        )

    logger.info("[admin] serving React SPA at /app from %s", _SPA_DIST)
else:
    logger.info("[admin] SPA bundle not found at %s — /app disabled (run npm build)", _SPA_DIST)
