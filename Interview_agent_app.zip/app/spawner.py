"""Cross-platform orchestrator spawner.

Opens a NEW visible terminal window running:
    scripts/run_orchestrator.{bat,sh} --scheduled-token <uuid> --web \
        --web-no-open-browser --web-no-wait-for-ui

Stream A is assumed to already be running (boot once via run_app at startup).
The terminal stays open after the orchestrator exits so the operator can
scroll through logs.

Platform branches:
    win32   → Windows Terminal (wt.exe) if present, else cmd /c start
    darwin  → Terminal.app via osascript
    linux   → x-terminal-emulator / gnome-terminal / konsole / xterm
"""
from __future__ import annotations

import logging
import os
import shutil
import subprocess
import sys
from typing import Optional

from app.paths import REPO_ROOT

logger = logging.getLogger(__name__)


def _orchestrator_args(token: str) -> list[str]:
    """Args passed to live_main (after the bat/sh wrapper).

    NOTE: We DELIBERATELY DO NOT pass --web-no-wait-for-ui. That flag tells
    the orchestrator's WebLauncher to skip blocking on `start_signal`, which
    means InterviewSession boots immediately and the AI greets BEFORE the
    candidate has clicked Start. We want the opposite: the orchestrator
    process spawns at admin-approve time, sets up Stream A clients + WS +
    static server, and then BLOCKS on the candidate's Start button. The
    interview only begins when the candidate's browser sends
    `{"type":"start"}`.
    """
    return [
        "--scheduled-token", token,
        "--web",
        "--web-no-open-browser",
    ]


def launch_orchestrator(token: str) -> Optional[int]:
    """Spawn the orchestrator subprocess in a new visible terminal window.

    Returns the PID of the spawned helper process (terminal window), or None
    if no fallback worked. Stream A must already be running.

    CLOUD_MODE=1 short-circuits the spawn: there's no GUI / Terminal.app /
    gnome-terminal in a container, AND we don't run a per-session
    subprocess in the cloud. Instead, `deploy/azure_app.py`'s WebSocket
    handler attaches an in-process `InterviewSession` to the candidate's
    connection when it sees `?token=<token>` in the WS URL. We return
    `os.getpid()` so that `db.has_active_session()` + `is_pid_alive()`
    continue to behave (the FastAPI worker is always alive while the
    container is up, which is the right answer for "is the interview
    process available"). The actual lifecycle transitions
    (ready → in_progress → completed) are written to the DB by
    `_session_runner()` over in azure_app.py."""
    if os.environ.get("CLOUD_MODE", "") == "1":
        worker_pid = os.getpid()
        logger.info(
            "[spawner] CLOUD_MODE=1 — skipping subprocess spawn for token=%s; "
            "interview will attach in-process when candidate connects "
            "(reported pid=%d for DB tracking)",
            token,
            worker_pid,
        )
        return worker_pid

    title = f"Interview {token[:8]}"
    if sys.platform == "win32":
        return _launch_windows(token, title)
    if sys.platform == "darwin":
        return _launch_macos(token, title)
    return _launch_linux(token, title)


def _launch_windows(token: str, title: str) -> Optional[int]:
    bat = REPO_ROOT / "scripts" / "run_orchestrator.bat"
    if not bat.exists():
        raise RuntimeError(f"missing helper script: {bat}")
    inner_cmd = [str(bat), *_orchestrator_args(token)]

    # Prefer Windows Terminal (nicer scrollback). Fall back to cmd /c start.
    if shutil.which("wt.exe"):
        try:
            proc = subprocess.Popen(
                ["wt.exe", "-w", "0", "nt", "--title", title, "cmd", "/k", *inner_cmd],
                cwd=str(REPO_ROOT),
                creationflags=subprocess.CREATE_NEW_CONSOLE,  # type: ignore[attr-defined]
            )
            logger.info("[spawner] launched via wt.exe pid=%d token=%s", proc.pid, token)
            return proc.pid
        except Exception as e:
            logger.warning("[spawner] wt.exe launch failed (%s); falling back to cmd", e)

    # cmd /c start opens a new console window; cmd /k keeps it open after exit.
    quoted = " ".join(f'"{a}"' if " " in a else a for a in inner_cmd)
    proc = subprocess.Popen(
        ["cmd", "/c", "start", title, "cmd", "/k", quoted],
        cwd=str(REPO_ROOT),
    )
    logger.info("[spawner] launched via cmd /c start pid=%d token=%s", proc.pid, token)
    return proc.pid


def _launch_macos(token: str, title: str) -> Optional[int]:
    sh = REPO_ROOT / "scripts" / "run_orchestrator.sh"
    if not sh.exists():
        raise RuntimeError(f"missing helper script: {sh}")
    args = " ".join(_orchestrator_args(token))
    # The trailing `bash` keeps the Terminal window open after the
    # orchestrator exits so logs can be reviewed.
    inner = (
        f'cd {_shell_quote(str(REPO_ROOT))}; '
        f'bash {_shell_quote(str(sh))} {args}; '
        f'echo; echo "[interview ended — close this window when done]"; bash'
    )
    # Escape double-quotes for AppleScript string literal.
    inner_esc = inner.replace("\\", "\\\\").replace('"', '\\"')
    applescript = f'tell application "Terminal" to do script "{inner_esc}"'
    proc = subprocess.Popen(["osascript", "-e", applescript])
    logger.info("[spawner] launched via osascript pid=%d token=%s", proc.pid, token)
    return proc.pid


def _launch_linux(token: str, title: str) -> Optional[int]:
    sh = REPO_ROOT / "scripts" / "run_orchestrator.sh"
    if not sh.exists():
        raise RuntimeError(f"missing helper script: {sh}")
    args = " ".join(_orchestrator_args(token))
    inner = f"bash {_shell_quote(str(sh))} {args}; exec bash"

    for term in ("x-terminal-emulator", "gnome-terminal", "konsole", "xterm"):
        if shutil.which(term):
            try:
                if term == "gnome-terminal":
                    cmd = [term, "--title", title, "--", "bash", "-c", inner]
                elif term == "konsole":
                    cmd = [term, "-p", f"tabtitle={title}", "-e", "bash", "-c", inner]
                else:
                    cmd = [term, "-T", title, "-e", "bash", "-c", inner]
                proc = subprocess.Popen(cmd, cwd=str(REPO_ROOT))
                logger.info("[spawner] launched via %s pid=%d", term, proc.pid)
                return proc.pid
            except Exception as e:
                logger.warning("[spawner] %s launch failed: %s", term, e)
                continue

    # Last-resort: no terminal emulator. Run headless.
    logger.warning("[spawner] no terminal emulator found; running headless")
    proc = subprocess.Popen(["bash", "-c", inner], cwd=str(REPO_ROOT))
    return proc.pid


def _shell_quote(s: str) -> str:
    """Minimal shell quoting for paths."""
    if not s:
        return "''"
    if all(c.isalnum() or c in "_-/.:" for c in s):
        return s
    return "'" + s.replace("'", "'\\''") + "'"


def is_pid_alive(pid: int) -> bool:
    """Used by the stale-session sweeper."""
    try:
        import psutil
        return psutil.pid_exists(pid)
    except Exception:
        return False
