"""Annotated event-log reader for the session-detail page.

Reads `sessions/<token>/events.jsonl` written by the orchestrator's
`EventLog` (see stream_b_new/observability/event_log.py) and groups events
by display category so the template can color-code:

  - phase headers (PHASE_CHANGED)
  - barge-ins (AI_RESPONSE_BARGED_IN, TTS_CANCELLED, BARGE_IN_STRIKE_INCREMENT)
  - slow-LLM utterances (AI_UTTERANCE)
  - fast-LLM fillers (FILLER_DISPATCHED, FILLER_SPOKEN)
  - apologies (APOLOGY_DISPATCHED)
  - candidate speech (STT_FINAL)
  - anomalies (PROTECTED_RESPONSE_MODE_*, INTEGRITY_FLAGGED)
  - lifecycle bookends (SESSION_STARTED, SESSION_ENDED)
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable


# Order matters only for fallthroughs — first matching category wins.
_CATEGORY_MAP = {
    "phase_changed": ("phase", "Phase"),
    "ai_response_barged_in": ("bargein", "AI barged in"),
    "tts_cancelled": ("bargein", "TTS cancelled"),
    "barge_in_strike_increment": ("bargein", "Barge-in strike"),
    "ai_utterance": ("ai_slow", "AI"),
    "filler_dispatched": ("ai_fast", "AI filler"),
    "filler_spoken": ("ai_fast", "AI filler"),
    "apology_dispatched": ("ai_apology", "AI apology"),
    "stt_final": ("candidate", "Candidate"),
    "protected_response_mode_entered": ("anomaly", "Protected mode entered"),
    "protected_response_mode_exited": ("anomaly", "Protected mode exited"),
    "integrity_flagged": ("anomaly", "Integrity flagged"),
    "guardrail_triggered": ("guardrail", "Guardrail triggered"),
    "session_started": ("lifecycle", "Session started"),
    "session_ended": ("lifecycle", "Session ended"),
    # Coding feature — give TA a clear timeline of editor activity.
    "coding_phase_started": ("coding", "Coding phase started"),
    "coding_phase_ended": ("coding", "Coding phase ended"),
    "coding_code_submitted": ("coding", "Code submitted"),
    "coding_code_run": ("coding", "Code run"),
    "coding_code_run_result": ("coding", "Run result"),
    "coding_hint_delivered": ("coding", "Hint delivered"),
    "coding_anti_cheat": ("anomaly", "Anti-cheat signal"),
    "coding_force_talk_requested": ("coding", "Talk to AI"),
    "coding_code_edit": ("coding", "Code edit"),
    # Observer feature — make TA shadow activity visible in the timeline.
    "observer_hint_received": ("observer", "Hint to AI"),
    "observer_ptt": ("observer", "TA push-to-talk"),
    "interviewer_turn": ("interviewer", "Interviewer"),
}


def _extract_text(kind: str, payload: dict) -> str:
    """Best-effort surface text for the timeline row."""
    if kind in ("ai_utterance",):
        return payload.get("text") or ""
    if kind in ("filler_dispatched", "filler_spoken"):
        return payload.get("text") or payload.get("phrase") or ""
    if kind == "apology_dispatched":
        return payload.get("text") or payload.get("phrase") or ""
    if kind == "stt_final":
        return payload.get("text") or payload.get("transcript") or ""
    if kind == "phase_changed":
        # Director emits {from_phase, to_phase}. Older drafts emitted
        # {from, to} / {old_phase, new_phase}; we accept all three so log
        # files written by either version render correctly.
        old = (
            payload.get("from_phase")
            or payload.get("from")
            or payload.get("old_phase")
            or "?"
        )
        new = (
            payload.get("to_phase")
            or payload.get("to")
            or payload.get("new_phase")
            or "?"
        )
        return f"{old}  →  {new}"
    if kind in ("ai_response_barged_in", "tts_cancelled"):
        return payload.get("reason") or ""
    if kind == "barge_in_strike_increment":
        s = payload.get("strike") or payload.get("strike_count")
        return f"strike #{s}" if s is not None else ""
    if kind == "guardrail_triggered":
        # Show "<reason>: <truncated candidate text>" so the TA sees which
        # category fired and what the candidate actually said, without
        # opening the payload drawer.
        reason = payload.get("reason") or "?"
        text = payload.get("candidate_text") or ""
        return f"{reason}: {text}" if text else reason
    # ── Coding feature surface text ────────────────────────────────────
    if kind == "coding_phase_started":
        qid = payload.get("question_id") or "?"
        prompt = (payload.get("question_prompt") or "").strip()
        if prompt:
            # Truncate so the timeline row stays compact; full prompt is in
            # the payload drawer.
            short = prompt if len(prompt) <= 120 else prompt[:117] + "..."
            return f"{qid}: {short}"
        return qid
    if kind == "coding_phase_ended":
        return payload.get("reason") or ""
    if kind == "coding_code_submitted":
        results = payload.get("final_test_results") or []
        if isinstance(results, list) and results:
            passed = sum(
                1 for r in results
                if (r.get("pass") or r.get("passed"))
            )
            total = len(results)
            chars = len(payload.get("final_code") or "")
            runs = payload.get("runs_used") or 0
            return f"{passed}/{total} tests passed, {chars} chars, {runs} run(s)"
        return f"{len(payload.get('final_code') or '')} chars submitted"
    if kind == "coding_code_run_result":
        results = payload.get("test_results") or []
        if isinstance(results, list) and results:
            passed = sum(
                1 for r in results
                if (r.get("pass") or r.get("passed"))
            )
            total = len(results)
            rt = payload.get("runtime_ms")
            rt_str = f", {rt}ms" if rt else ""
            return f"{passed}/{total} passed{rt_str}"
        return ""
    if kind == "coding_hint_delivered":
        lvl = payload.get("hint_level")
        text = (payload.get("hint_text") or "").strip()
        prefix = f"level {lvl}: " if lvl is not None else ""
        short = text if len(text) <= 100 else text[:97] + "..."
        return prefix + short
    if kind == "coding_anti_cheat":
        return payload.get("reason") or ""
    return ""


def annotate(path: Path) -> list[dict]:
    """Read the JSONL and return a list of annotated rows. Unrecognized event
    kinds become `category='other'` so the template can collapse them."""
    if not path.exists():
        return []
    rows: list[dict] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            kind = obj.get("kind", "")
            cat, label = _CATEGORY_MAP.get(kind, ("other", kind))
            payload = obj.get("payload") or {}
            # Observer (Phase 2): stt_final events tagged with
            # speaker="interviewer" come from the SECONDARY STT (TA
            # push-to-talk). Re-categorise so the trace timeline shows
            # them as Interviewer rows in their own colour instead of
            # being misread as candidate speech.
            if kind == "stt_final" and payload.get("speaker") == "interviewer":
                cat, label = "interviewer", "Interviewer"
            # The director emits a QUEUED phase_changed pre-announcement before
            # the real applied transition (see group_by_phase). Label it distinctly
            # so the flat trace doesn't show two identical "Phase" rows per boundary.
            if kind == "phase_changed" and payload.get("queued") is True:
                label = "Phase (pending)"
            rows.append({
                # Position in the parsed (non-blank, valid-JSON) event stream.
                # Matches `event_index` produced by the evaluation sectioner
                # (features/eval/sectioner.py), which enumerates the same
                # `_read_events()`-style parsed list — so an evidence ref can
                # deep-link from a Performance-tab score to this trace row.
                "index": len(rows),
                "ts": obj.get("ts", ""),
                "kind": kind,
                "category": cat,
                "label": label,
                "text": _extract_text(kind, payload),
                "payload": payload,
            })
    return rows


def summarize(rows: Iterable[dict]) -> dict:
    """Top-of-page counters."""
    counts: dict[str, int] = {}
    for r in rows:
        counts[r["category"]] = counts.get(r["category"], 0) + 1
    return counts


# ── phase-flow aggregator ──────────────────────────────────────────────


# LLM pricing is now sourced exclusively from config/llm_models.yaml via
# stream_b_new.llm.pricing. The previous OpenRouter live-fetch + a stale
# _FALLBACK_PRICING dict have been removed; if a model isn't in the YAML,
# its cost displays as $0 with a warning logged by pricing.py once per id.
# Speech rates come from config/llm_models.yaml `speech:` (single source).
# Resolved lazily — the YAML is parsed once and cached by stream_b_new.llm.pricing.
def _stt_usd_per_audio_ms() -> float:
    from engine.brain.llm.pricing import stt_usd_per_audio_ms
    return stt_usd_per_audio_ms("azure-speech-stt")


def _tts_usd_per_char() -> float:
    from engine.brain.llm.pricing import tts_usd_per_char
    return tts_usd_per_char("azure-speech-tts-neural")


def _llm_cost_usd(
    model: str | None,
    tokens_in: int | None,
    tokens_out: int | None,
    *,
    cached: int = 0,
    cache_write: int = 0,
) -> float:
    """USD cost for one LLM call, sourced from config/llm_models.yaml via
    stream_b_new.llm.pricing. Bills cached tokens at the discounted rate
    declared in the YAML (e.g. OpenAI 0.5× input, DeepSeek 0.1×). Returns
    0.0 if the model isn't in the YAML (pricing.py logs once per id)."""
    if not model or tokens_in is None or tokens_out is None:
        return 0.0
    from engine.brain.llm.pricing import estimate_total_usd
    yaml_cost = estimate_total_usd(
        model,
        tokens_in=tokens_in, tokens_out=tokens_out,
        tokens_cached=cached, tokens_cache_write=cache_write,
    )
    return float(yaml_cost) if yaml_cost is not None else 0.0


def _parse_ts(ts: str) -> float:
    """Parse ISO-8601 ts (UTC) → epoch seconds. 0.0 on bad input."""
    if not ts:
        return 0.0
    try:
        # Python's fromisoformat handles "2026-05-25T12:47:47.052042+00:00"
        # natively in 3.11+. Fall through to 0 on anything else.
        from datetime import datetime
        return datetime.fromisoformat(ts).timestamp()
    except Exception:
        return 0.0


def _human_ms(ms: int | float | None) -> str:
    """Format a millisecond duration as a short human string."""
    if ms is None:
        return "—"
    ms = int(ms)
    if ms < 1000:
        return f"{ms}ms"
    if ms < 60_000:
        return f"{ms / 1000:.1f}s"
    m, s = divmod(ms // 1000, 60)
    return f"{m}m {s:02d}s"


def _human_usd(usd: float) -> str:
    """Format a USD amount for compact display in plain dollars.

    Always renders as $X.XXXX (or $0). No millicent / "m" suffix —
    operators didn't find it intuitive ("$3.38m" reads like 3.38 million,
    not 0.00338 dollars). For sub-cent values we widen to 6 decimal
    places so the value is visible.
    """
    if usd <= 0:
        return "$0"
    if usd < 0.0001:
        return f"${usd:.6f}"
    if usd < 0.01:
        return f"${usd:.5f}"
    if usd < 1:
        return f"${usd:.4f}"
    return f"${usd:.2f}"


def _error_label(payload: dict) -> str | None:
    """Pick out a human-friendly error class from a llm_call_failed payload.

    Returns None when the payload doesn't look like an error. Examples:
      - "Token limit" — when error mentions context length / max tokens
      - "Rate limit" — 429s
      - "Timeout" — verifier / phase_override timeouts
      - "Cancelled" — barged-in mid-stream
      - "Validation" — pydantic parsing failed
      - "Network" — connection errors
      - "LLM error" — fallback
    """
    reason = (payload.get("reason") or "").lower()
    err = (payload.get("error") or "").lower()
    if reason == "cancelled":
        return "Cancelled"
    if reason == "validation_or_error" and not err:
        return "Validation"
    if "context length" in err or "max_tokens" in err or "token limit" in err:
        return "Token limit"
    if "429" in err or "rate limit" in err or "too many" in err:
        return "Rate limit"
    if "timeout" in err or "timed out" in err or reason == "timeout":
        return "Timeout"
    if "connection" in err or "network" in err or "unreachable" in err:
        return "Network"
    if "validation" in reason or "validation" in err:
        return "Validation"
    if err:
        return "LLM error"
    return None


def group_by_phase(rows: list[dict]) -> list[dict]:
    """Aggregate the flat event list into a phase-flow tree.

    Output structure (one dict per phase, in chronological order):

        {
          "id":             str        # phase id
          "started_at_ms":  int        # ms since session start
          "ended_at_ms":    int        # ms since session start (or 'now')
          "duration_ms":    int
          "turn_count":     int        # # candidate STT finals heard
          "ai_turn_count":  int        # # AI utterances spoken
          "llm_calls":      int        # total fast+slow LLM calls
          "llm_tokens_in":  int
          "llm_tokens_out": int
          "stt_audio_ms":   int        # total audio recognised
          "tts_chars":      int        # total chars synthesised
          "cost_usd":       float      # llm + stt + tts combined
          "errors":         list[dict] # each {label, agent, ts, kind, payload}
          "turns":          list[dict] # one per candidate STT final (see below)
          "transition":     str | None # "advanced_now" | "end_now" | "timer" | None
        }

      where each turn is:
        {
          "ts":              str
          "candidate_text":  str
          "candidate_conf":  float | None
          "stt_uid":         str | None
          "verifier":        {intent, confidence, instruction, latency_ms,
                              langfuse_trace_id} | None
          "phase_override":  {override, reason, confidence, langfuse_trace_id} | None
          "ai_utterance":    str | None
          "ai_filler":       str | None
          "ai_apology":      str | None
          "llm_calls":       list[dict]  # raw llm_call_completed + _failed payloads
                                          # tagged with agent + trace_id + status
          "barge_ins":       list[dict]
          "errors":          list[dict]  # subset of llm_calls with status=error
        }

    The structure mirrors what a phase-flow UI naturally wants to render.
    All numbers are pre-formatted-friendly (raw ints; the template uses the
    `_human_*` helpers if it wants compact strings)."""
    if not rows:
        return []

    # Collapse durable-resume boundaries first: an interrupted phase's pre-crash
    # partial (and the phantom second session_started the fresh runner emits) is
    # replaced by the resumed run, so the timeline shows the interrupted phase
    # ONCE (resumed) instead of a phantom restart from the greeting. The
    # session_resumed marker is a no-op in the loop below (unknown kind → ignored);
    # the interruption stays auditable in the raw events.jsonl + Langfuse.
    from app.resume_collapse import collapse_resumed_events
    rows = collapse_resumed_events(rows)

    phases: list[dict] = []
    # Open phase = the one we're currently appending turns to.
    current: dict | None = None
    # Open turn within the current phase. Closed (sealed) when the AI's
    # response is complete (ai_utterance fires) OR when a new STT_FINAL
    # arrives (whichever comes first).
    open_turn: dict | None = None

    # First event ts → t0 anchor so per-phase durations can be relative.
    t0 = _parse_ts(rows[0]["ts"]) if rows else 0.0

    def _new_phase(phase_id: str, ts: str) -> dict:
        start_ms = int((_parse_ts(ts) - t0) * 1000) if ts else 0
        return {
            "id": phase_id,
            "started_at_ms": start_ms,
            "ended_at_ms": start_ms,
            "duration_ms": 0,
            "turn_count": 0,
            "ai_turn_count": 0,
            "llm_calls": 0,
            "llm_tokens_in": 0,
            "llm_tokens_out": 0,
            "llm_tokens_cached": 0,
            "llm_tokens_cache_write": 0,
            "stt_audio_ms": 0,
            "tts_chars": 0,
            "cost_usd": 0.0,
            "errors": [],
            "turns": [],
            "transition": None,
        }

    def _new_turn(ts: str, candidate_text: str, payload: dict) -> dict:
        return {
            "ts": ts,
            "candidate_text": candidate_text,
            "candidate_conf": payload.get("confidence"),
            "stt_uid": payload.get("uid"),
            "verifier": None,
            "phase_override": None,
            "ai_utterance": None,
            "ai_filler": None,
            "ai_apology": None,
            "llm_calls": [],
            "barge_ins": [],
            "errors": [],
        }

    # Track the most-recent llm_call_started per agent so when the matching
    # _completed / _failed arrives we can correlate the system_prompt +
    # user_messages (kept on _started) with tokens / output (on _completed).
    pending_starts: dict[str, dict] = {}

    def _seal_open_turn() -> None:
        nonlocal open_turn
        if open_turn is not None and current is not None:
            current["turns"].append(open_turn)
            current["turn_count"] += 1
        open_turn = None

    for row in rows:
        kind = row["kind"]
        ts = row["ts"]
        payload = row["payload"] or {}
        ts_epoch = _parse_ts(ts)
        ts_ms = int((ts_epoch - t0) * 1000) if ts_epoch else 0

        if kind == "session_started":
            initial_phase = (
                payload.get("initial_phase")
                or payload.get("phase")
                or "intro"
            )
            current = _new_phase(initial_phase, ts)
            phases.append(current)
            continue

        if kind == "phase_changed":
            # Ignore the QUEUED pre-announcement (queued=True). The director emits
            # phase_changed twice per transition — a queued one the instant the
            # phase clock expires (ungated, even mid-utterance) and the real
            # APPLIED one (reason="natural") once the candidate stops speaking
            # (director.py:746 vs 2264/2277/1841/1864). Bucketing on the queued
            # marker would file a candidate answer that finalizes between the two
            # into the NEXT phase. Switch buckets on the applied marker only.
            if payload.get("queued") is True:
                continue
            # Close out current phase
            if current is not None:
                _seal_open_turn()
                current["ended_at_ms"] = ts_ms
                current["duration_ms"] = ts_ms - current["started_at_ms"]
            new_phase = (
                payload.get("to_phase")
                or payload.get("to")
                or payload.get("new_phase")
                or "?"
            )
            current = _new_phase(new_phase, ts)
            phases.append(current)
            continue

        if current is None:
            # Events arriving before session_started — bootstrap a default
            # phase so we don't drop them.
            current = _new_phase("intro", ts)
            phases.append(current)

        # ── observer (TA) substitute AI turn ─────────────────────────
        # The observer's push-to-talk utterance is committed by the director
        # as an `interviewer_turn` event and behaves as the AI's own turn
        # (message_role="assistant"). Render it INLINE in the phase turn flow
        # as its own turn, labeled as observer-originated so reviewers can tell
        # a human takeover from the model. (Older sessions emitted this as an
        # `stt_final` tagged speaker="interviewer" — handled below for back-compat.)
        if kind == "interviewer_turn" or (
            kind == "stt_final" and payload.get("speaker") == "interviewer"
        ):
            text = (payload.get("text") or payload.get("transcript") or "").strip()
            if text:
                _seal_open_turn()
                obs_turn = _new_turn(ts, "", payload)
                obs_turn["ai_utterance"] = text   # it IS the AI's turn now
                obs_turn["observer"] = True        # label: Observer (TA)
                obs_turn["candidate_text"] = ""
                current["turns"].append(obs_turn)
                current["turn_count"] += 1
                current["ai_turn_count"] += 1
                # Keep the legacy side-list too (some callers may read it).
                current.setdefault("interviewer_turns", []).append({
                    "ts": ts,
                    "text": text,
                    "end_ms": int(payload.get("end_ms") or 0),
                    "confidence": float(payload.get("confidence") or 1.0),
                })
            continue

        # ── candidate STT final = new turn boundary ──────────────────
        if kind == "stt_final":
            _seal_open_turn()
            text = payload.get("text") or payload.get("transcript") or ""
            audio_ms = payload.get("audio_ms") or payload.get("end_ms") or 0
            current["stt_audio_ms"] += int(audio_ms or 0)
            current["cost_usd"] += (audio_ms or 0) * _stt_usd_per_audio_ms()
            open_turn = _new_turn(ts, text, payload)
            continue

        # ── LLM started: stash for correlation ────────────────────────
        if kind == "llm_call_started":
            agent = payload.get("agent") or "?"
            pending_starts[agent] = payload
            continue

        # ── LLM completed / failed: record on the open turn ───────────
        if kind in ("llm_call_completed", "llm_call_failed"):
            agent = payload.get("agent") or "?"
            started = pending_starts.pop(agent, {})
            tokens_in = payload.get("tokens_in") or 0
            tokens_out = payload.get("tokens_out") or 0
            tokens_cached = payload.get("tokens_in_cached") or 0
            tokens_cache_write = payload.get("tokens_in_cache_write") or 0
            tokens_reasoning = payload.get("tokens_out_reasoning") or 0
            model = payload.get("model") or started.get("model")
            # Provider's authoritative cost (OpenRouter via usage-include) wins
            # over the local estimator. Fall back to the YAML pricing when
            # absent. Both honour cached/cache_write rates so the cache
            # discount is reflected in the per-call cost we render.
            upstream_cost = payload.get("cost_usd")
            if upstream_cost is not None:
                usd = float(upstream_cost)
            else:
                usd = _llm_cost_usd(model, tokens_in, tokens_out,
                                    cached=tokens_cached,
                                    cache_write=tokens_cache_write)
            err_label = _error_label(payload) if kind == "llm_call_failed" else None
            call = {
                "agent": agent,
                "model": model,
                "kind": kind,
                "status": "error" if err_label else ("completed" if kind == "llm_call_completed" else "failed"),
                "error_label": err_label,
                "error_reason": payload.get("reason"),
                "error_message": payload.get("error"),
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                "tokens_in_cached": tokens_cached,
                "tokens_in_cache_write": tokens_cache_write,
                "tokens_out_reasoning": tokens_reasoning,
                "cost_usd": usd,
                "cost_source": "openrouter" if upstream_cost is not None else "yaml_estimate",
                "generation_id": payload.get("generation_id"),
                "latency_ms": payload.get("latency_ms"),
                "ttft_ms": payload.get("ttft_ms"),
                "system_prompt": started.get("system_prompt"),
                "user_messages": started.get("user_messages"),
                "response_text": payload.get("response_text"),
                "langfuse_trace_id": payload.get("langfuse_trace_id"),
                "ts": ts,
            }
            current["llm_calls"] += 1
            current["llm_tokens_in"] += tokens_in
            current["llm_tokens_out"] += tokens_out
            current["llm_tokens_cached"] += tokens_cached
            current["llm_tokens_cache_write"] += tokens_cache_write
            current["cost_usd"] += usd
            if open_turn is not None:
                open_turn["llm_calls"].append(call)
                if err_label is not None:
                    open_turn["errors"].append(call)
                    current["errors"].append(call)
            else:
                # No open turn (e.g. the AI's opening session_start dispatch
                # before any candidate has spoken). Attach to phase root via
                # a synthetic "opening" turn so the UI renders it.
                synth = _new_turn(ts, "(no candidate turn yet)", {})
                synth["llm_calls"].append(call)
                if err_label is not None:
                    synth["errors"].append(call)
                    current["errors"].append(call)
                open_turn = synth
            continue

        # ── verifier classifier (special LLM with extra metadata) ────
        if kind == "verifier_classified":
            v = {
                "intent": payload.get("intent"),
                "confidence": payload.get("confidence"),
                "instruction": payload.get("instruction"),
                # When intent="guardrail_triggered", `reason` carries the
                # sub-category (jailbreak_attempt / rubric_probe /
                # answer_extraction / harmful_content). None otherwise.
                "reason": payload.get("reason"),
                "latency_ms": payload.get("latency_ms"),
                "tokens_in": payload.get("tokens_in") or 0,
                "tokens_out": payload.get("tokens_out") or 0,
                "model": payload.get("model"),
                "langfuse_trace_id": payload.get("langfuse_trace_id"),
            }
            if open_turn is not None:
                open_turn["verifier"] = v
            continue

        if kind == "phase_override_decided":
            po = {
                "override": payload.get("override"),
                "raw_override": payload.get("raw_override"),
                "reason": payload.get("reason"),
                "confidence": payload.get("confidence"),
                "latency_ms": payload.get("latency_ms"),
                "model": payload.get("model"),
                "tokens_in": payload.get("tokens_in") or 0,
                "tokens_out": payload.get("tokens_out") or 0,
                "langfuse_trace_id": payload.get("langfuse_trace_id"),
            }
            if open_turn is not None:
                open_turn["phase_override"] = po
            # Mark phase transition direction
            ov = (payload.get("override") or "").lower()
            if ov in ("advance_now", "end_now"):
                current["transition"] = ov
            continue

        # ── AI utterances ─────────────────────────────────────────────
        if kind == "ai_utterance":
            text = payload.get("text") or ""
            if open_turn is not None:
                open_turn["ai_utterance"] = text
            current["ai_turn_count"] += 1
            continue

        # ── Coding feature: attach question + submission to the phase so
        #    the template can render a "View code" affordance. Each field
        #    is stamped on the phase dict; the template renders them only
        #    when present.
        if kind == "coding_phase_started":
            # Multi-question form: payload.questions is a list; legacy
            # has the question fields at top level. Build a list either
            # way so the template can iterate uniformly.
            qs = payload.get("questions")
            if isinstance(qs, list) and qs:
                current["coding_questions"] = [
                    {
                        "question_id": q.get("question_id") or "",
                        "question_prompt": q.get("question_prompt") or "",
                        "function_name": q.get("function_name") or "",
                        "starter_code": q.get("starter_code") or "",
                        "test_case_count": q.get("test_case_count")
                                            or len(q.get("test_cases") or []),
                        "test_cases": q.get("test_cases") or [],
                        "difficulty": q.get("difficulty") or "",
                    }
                    for q in qs
                ]
            else:
                current["coding_questions"] = [{
                    "question_id": payload.get("question_id") or "",
                    "question_prompt": payload.get("question_prompt") or "",
                    "function_name": payload.get("function_name") or "",
                    "starter_code": payload.get("starter_code") or "",
                    "test_case_count": payload.get("test_case_count") or 0,
                    "test_cases": payload.get("test_cases") or [],
                    "difficulty": payload.get("difficulty") or "",
                }]
            # Back-compat: keep `coding_question` (singular) pointing at
            # the first question so older templates / code paths still
            # work.
            current["coding_question"] = current["coding_questions"][0]
            continue
        if kind == "coding_code_submitted":
            results = payload.get("final_test_results") or []
            passed = sum(
                1 for r in results if (r.get("pass") or r.get("passed"))
            ) if isinstance(results, list) else 0
            total = len(results) if isinstance(results, list) else 0
            sub = {
                "question_id": payload.get("question_id") or "",
                "code": payload.get("final_code") or "",
                "runs_used": payload.get("runs_used") or 0,
                "auto_submitted": bool(payload.get("auto_submitted") or False),
                "test_results": results,
                "passed": passed,
                "total": total,
                "ts": ts,
            }
            current.setdefault("coding_submissions", []).append(sub)
            # Back-compat single field — last write wins as before so old
            # consumers that look at `coding_submission` keep working.
            current["coding_submission"] = sub
            continue
        if kind == "coding_hint_delivered":
            current.setdefault("coding_hints", []).append({
                "level": payload.get("hint_level"),
                "text": payload.get("hint_text") or "",
                "ts": ts,
            })
            continue
        if kind == "coding_anti_cheat":
            current.setdefault("coding_anti_cheat", []).append({
                "reason": payload.get("reason") or "",
                "metadata": payload.get("metadata") or {},
                "ts": ts,
            })
            continue

        if kind in ("filler_dispatched", "filler_spoken"):
            if open_turn is not None:
                open_turn["ai_filler"] = payload.get("text") or payload.get("phrase") or ""
            continue

        if kind == "apology_dispatched":
            if open_turn is not None:
                open_turn["ai_apology"] = payload.get("text") or payload.get("phrase") or ""
            continue

        # ── barge-ins ─────────────────────────────────────────────────
        if kind in ("ai_response_barged_in", "tts_cancelled", "barge_in_strike_increment"):
            if open_turn is not None:
                open_turn["barge_ins"].append({
                    "kind": kind,
                    "ts": ts,
                    "reason": payload.get("reason"),
                    "payload": payload,
                })
            continue

        # ── TTS: count chars of input text per chunk ──────────────────
        # `tts_speak_chunk_sent` carries the EXACT text submitted to
        # Azure. Sum len(text) so per-phase rollups in the Interview
        # Trace tab show the real char counts. The authoritative
        # per-session cost number comes from cost_tracker (see
        # load_per_model_summary), not this rollup.
        if kind == "tts_speak_chunk_sent":
            chunk_text = payload.get("text") or ""
            chars = len(chunk_text)
            current["tts_chars"] += chars
            current["cost_usd"] += chars * _tts_usd_per_char()
            continue

        if kind == "session_ended":
            _seal_open_turn()
            if current is not None:
                current["ended_at_ms"] = ts_ms
                current["duration_ms"] = ts_ms - current["started_at_ms"]
            continue

    # Final seal in case session_ended wasn't recorded.
    _seal_open_turn()
    if current is not None and current.get("duration_ms", 0) == 0:
        last_ts = _parse_ts(rows[-1]["ts"]) if rows else 0.0
        if last_ts:
            current["ended_at_ms"] = int((last_ts - t0) * 1000)
            current["duration_ms"] = (
                current["ended_at_ms"] - current["started_at_ms"]
            )

    # Compute pre-formatted display strings so the template stays slim.
    for p in phases:
        p["duration_human"] = _human_ms(p["duration_ms"])
        p["cost_human"] = _human_usd(p["cost_usd"])
        for t in p["turns"]:
            for c in t["llm_calls"]:
                c["latency_human"] = _human_ms(c.get("latency_ms"))
                c["ttft_human"] = _human_ms(c.get("ttft_ms"))
                c["cost_human"] = _human_usd(c.get("cost_usd") or 0.0)

    return phases


def session_totals(phases: list[dict]) -> dict:
    """Roll up cross-phase numbers for the page header."""
    total_duration_ms = sum(p["duration_ms"] for p in phases)
    return {
        "duration_ms": total_duration_ms,
        "duration_human": _human_ms(total_duration_ms),
        "phase_count": len(phases),
        "turn_count": sum(p["turn_count"] for p in phases),
        "ai_turn_count": sum(p["ai_turn_count"] for p in phases),
        "llm_calls": sum(p["llm_calls"] for p in phases),
        "llm_tokens_in": sum(p["llm_tokens_in"] for p in phases),
        "llm_tokens_out": sum(p["llm_tokens_out"] for p in phases),
        "cost_usd": sum(p["cost_usd"] for p in phases),
        "cost_human": _human_usd(sum(p["cost_usd"] for p in phases)),
        "error_count": sum(len(p["errors"]) for p in phases),
    }


def mermaid_flowchart(phases: list[dict]) -> str:
    """Render a Mermaid `flowchart LR` diagram of phase transitions with
    per-phase stats baked into the node labels.

    Returns the raw Mermaid source string. The template embeds this inside
    a `<pre class="mermaid">` block and lets Mermaid's client-side renderer
    do the layout."""
    if not phases:
        return "flowchart LR\n  empty[No events yet]"
    lines = ["flowchart LR"]
    # Node classes — color phases by health.
    lines.append("  classDef healthy fill:#0d80771a,stroke:#0d8077,color:#1a0010;")
    lines.append("  classDef warn    fill:#a162071a,stroke:#a16207,color:#1a0010;")
    lines.append("  classDef error   fill:#b91c1c14,stroke:#b91c1c,color:#1a0010;")
    for i, p in enumerate(phases):
        node_id = f"p{i}"
        # `<br/>` line breaks render fine in Mermaid node labels.
        label_lines = [
            f"<b>{_html_escape(p['id'])}</b>",
            f"{p['turn_count']} turns · {p['duration_human']}",
            f"{p['llm_calls']} LLM · {p['cost_human']}",
        ]
        if p["errors"]:
            label_lines.append(f"⚠ {len(p['errors'])} error(s)")
        label = "<br/>".join(label_lines)
        lines.append(f'  {node_id}["{label}"]')
        # Health colour: error if any errors, warn if transition was forced
        # (advance_now/end_now), otherwise healthy.
        if p["errors"]:
            lines.append(f"  class {node_id} error;")
        elif p.get("transition") in ("advance_now", "end_now"):
            lines.append(f"  class {node_id} warn;")
        else:
            lines.append(f"  class {node_id} healthy;")
    # Transitions
    for i in range(len(phases) - 1):
        tr = phases[i].get("transition")
        label = ""
        if tr == "advance_now":
            label = "|advance|"
        elif tr == "end_now":
            label = "|end|"
        lines.append(f"  p{i} -->{label} p{i + 1}")
    return "\n".join(lines)


def _html_escape(s: str) -> str:
    return (
        (s or "")
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


# ════════════════════════════════════════════════════════════════════════
#  Observability view-model
#
#  `compute_observability(phases, totals)` returns a structure ready for
#  the Langfuse dashboard panel in session_detail.html. The template
#  walks the structure directly without further Python logic. Everything
#  is computed from the per-call records produced by `group_by_phase` so
#  it stays in sync with the rest of the page.
# ════════════════════════════════════════════════════════════════════════


def _percentile(values: list[int | float], pct: float) -> int:
    """Nearest-rank percentile (no interpolation). Cheap + good enough for
    a UI summary; resists single outliers ruining the chart. Empty list →
    0 so the template can render a clean dash."""
    if not values:
        return 0
    s = sorted(values)
    k = max(0, min(len(s) - 1, int(round(pct / 100.0 * (len(s) - 1)))))
    return int(s[k])


def _flatten_calls(phases: list[dict]) -> list[dict]:
    """All LLM calls (incl. failed) across the session, in chronological
    order — flattened from the phase → turn → calls tree."""
    out: list[dict] = []
    for p in phases:
        # Phase-level calls live inside turns even for the synthetic
        # opening turn; nothing to dedupe.
        for t in p["turns"]:
            for c in t["llm_calls"]:
                # Attach phase + parent verifier/po info if useful.
                c = dict(c)
                c["phase_id"] = p["id"]
                out.append(c)
        # Verifier/phase_override are summarised on the turn, not as a
        # separate llm_call entry, so they're already present above via
        # the agent name on the call record.
    return out


def _agent_color(agent: str) -> str:
    """Map an agent name to one of the pill colour classes the template
    knows about (question / guardrail / verifier / filler / phase_override).
    Defensive — unknown agents get the generic accent."""
    a = (agent or "").lower()
    if "question" in a: return "question_agent"
    if "guardrail" in a: return "guardrail_agent"   # its own violet hue (--cat-guardrail)
    if "verif" in a:    return "verifier_agent"
    if "filler" in a:   return "filler_agent"
    if "phase" in a or "override" in a: return "phase_override_agent"
    if "apolog" in a:   return "filler_agent"     # share filler's amber
    return "question_agent"


# Stable color list for the per-phase dot, picked from the existing
# palette + neutrals. Cycles if there are more than five phases.
_PHASE_DOT_COLORS = [
    "#8b5cf6",          # violet (intro)
    "var(--accent)",    # magenta
    "#2b6478",          # teal-info (system design)
    "#a16207",          # amber (behavioural)
    "var(--teal)",      # teal (wrap-up)
    "#be185d",          # deep pink (extras)
]


# Tokens that would have been billed at the input rate, but were served
# from cache at the model's cache_read rate instead. Used for the savings
# headline. Falls back to "no savings reported" semantics when the
# pricing module doesn't know the model.
def _cache_savings_usd(model: str | None, tokens_cached: int) -> float:
    if not model or not tokens_cached:
        return 0.0
    try:
        from engine.brain.llm.pricing import model_metadata
        md = model_metadata(model)
        if md is None:
            return 0.0
        rates = md["pricing_usd_per_million"]
        input_rate = float(rates.get("input") or 0.0)
        cache_rate = rates.get("cache_read")
        cache_rate = float(cache_rate) if cache_rate is not None else input_rate
        delta_per_token = (input_rate - cache_rate) / 1_000_000
        return max(0.0, delta_per_token * tokens_cached)
    except Exception:
        return 0.0


# Provider lookup so the cost-by-model row can show a "groq" / "openrouter"
# chip next to the model id, matching the YAML registry.
def _model_provider(model: str | None) -> str:
    if not model:
        return ""
    try:
        from engine.brain.llm.pricing import model_metadata
        md = model_metadata(model)
        return (md or {}).get("provider") or ""
    except Exception:
        return ""


def _cost_breakdown_for_call(call: dict) -> dict[str, float]:
    """Per-call USD breakdown (input / output / cache_read / cache_write)
    using the YAML pricing module. Returns zeros when the model isn't
    registered or when the call already paid the OpenRouter cost (the
    caller still gets a breakdown for the chart, but the totals always
    use the per-call `cost_usd` for accuracy)."""
    model = call.get("model")
    if not model:
        return {"input": 0.0, "output": 0.0, "cache_read": 0.0, "cache_write": 0.0}
    try:
        from engine.brain.llm.pricing import compute_cost
        bd = compute_cost(
            model,
            tokens_in=call.get("tokens_in") or 0,
            tokens_out=call.get("tokens_out") or 0,
            tokens_cached=call.get("tokens_in_cached") or 0,
            tokens_cache_write=call.get("tokens_in_cache_write") or 0,
        )
        if bd is None:
            return {"input": 0.0, "output": 0.0, "cache_read": 0.0, "cache_write": 0.0}
        return {
            "input": bd.input, "output": bd.output,
            "cache_read": bd.cache_read, "cache_write": bd.cache_write,
        }
    except Exception:
        return {"input": 0.0, "output": 0.0, "cache_read": 0.0, "cache_write": 0.0}


_VERIFIER_INTENT_COLORS = {
    "answered":            "var(--teal)",
    "partial_answer":      "var(--accent)",
    "asked_to_repeat":     "var(--color-warn)",
    "asked_for_time":      "var(--color-warn)",
    "no_speech":           "var(--text-mute)",
    "off_topic":           "var(--color-danger)",
    "clarifying_question": "var(--color-info)",
    "not_applicable":      "var(--color-warn)",
    "wrap_up_complete":    "var(--accent-deep)",
    "guardrail_triggered": "var(--cat-guardrail)",
}


def compute_observability(phases: list[dict], totals: dict) -> dict:
    """Build the view-model for the session_detail.html "Observability"
    tab. Mirrors the structure documented in observability_mockup.html;
    the template walks it directly with Jinja `for`/`if`.

    All dollar amounts are floats in USD. Token counts are ints. Time is
    in ms for short durations and seconds for phase / session totals."""
    calls = _flatten_calls(phases)
    completed = [c for c in calls if c.get("status") != "error"]
    errored   = [c for c in calls if c.get("status") == "error"]

    # ── KPI strip ────────────────────────────────────────────────────
    ttfts = [int(c["ttft_ms"]) for c in calls if c.get("ttft_ms")]
    total_tokens_in     = sum(c.get("tokens_in") or 0 for c in calls)
    total_tokens_in_cac = sum(c.get("tokens_in_cached") or 0 for c in calls)
    total_tokens_cw     = sum(c.get("tokens_in_cache_write") or 0 for c in calls)
    cache_hit_ratio = (
        total_tokens_in_cac / total_tokens_in if total_tokens_in else 0.0
    )

    cancellations = [c for c in errored if c.get("error_reason") == "cancelled"]
    fallbacks     = [c for c in errored if c.get("error_reason") in
                     ("timeout", "validation_or_error", "fallback")]
    transport     = [c for c in errored if c.get("error_reason") == "transport_error"]

    by_agent_calls: dict[str, int] = {}
    for c in calls:
        a = c.get("agent") or "?"
        by_agent_calls[a] = by_agent_calls.get(a, 0) + 1

    # ── cache savings ────────────────────────────────────────────────
    cache_savings_usd = 0.0
    for c in calls:
        cache_savings_usd += _cache_savings_usd(c.get("model"),
                                                 c.get("tokens_in_cached") or 0)
    total_cost = float(totals.get("cost_usd") or 0.0)
    # The "saved" pct is savings ÷ (cost + savings) — i.e. fraction of
    # what we'd have paid without caching.
    cache_savings_pct = (
        100.0 * cache_savings_usd / (total_cost + cache_savings_usd)
        if (total_cost + cache_savings_usd) > 0 else 0.0
    )

    # ── cost by model ───────────────────────────────────────────────
    by_model: dict[str, dict] = {}
    for c in calls:
        m = c.get("model") or "?"
        e = by_model.setdefault(m, {
            "model": m, "provider": _model_provider(m),
            "calls": 0,
            "tokens_in": 0, "tokens_out": 0,
            "tokens_cached": 0, "tokens_cache_write": 0,
            "cost": {"input": 0.0, "output": 0.0,
                     "cache_read": 0.0, "cache_write": 0.0, "total": 0.0},
            "cache_savings_usd": 0.0,
        })
        e["calls"] += 1
        e["tokens_in"]      += c.get("tokens_in") or 0
        e["tokens_out"]     += c.get("tokens_out") or 0
        e["tokens_cached"]  += c.get("tokens_in_cached") or 0
        e["tokens_cache_write"] += c.get("tokens_in_cache_write") or 0
        bd = _cost_breakdown_for_call(c)
        for k in ("input", "output", "cache_read", "cache_write"):
            e["cost"][k] += bd[k]
        e["cost"]["total"] += float(c.get("cost_usd") or 0.0)
        e["cache_savings_usd"] += _cache_savings_usd(c.get("model"),
                                                       c.get("tokens_in_cached") or 0)
    # Compute percentages for the stacked-bar widths + savings pct.
    cost_by_model = []
    for m, e in sorted(by_model.items(), key=lambda kv: -kv[1]["cost"]["total"]):
        total = e["cost"]["total"] or 0.0
        if total > 0:
            pct = {k: 100.0 * (e["cost"][k] / total) for k in
                   ("input", "output", "cache_read", "cache_write")}
        else:
            pct = {"input": 0, "output": 0, "cache_read": 0, "cache_write": 0}
        savings = e["cache_savings_usd"]
        e["pct"] = pct
        e["cache_savings_pct"] = (
            100.0 * savings / (total + savings) if (total + savings) > 0 else 0.0
        )
        e["cost_human"] = _human_usd(total)
        cost_by_model.append(e)

    # ── latency by agent ────────────────────────────────────────────
    latency_by_agent: list[dict] = []
    for agent in sorted(by_agent_calls.keys()):
        calls_for_agent = [c for c in calls if c.get("agent") == agent]
        ttft_vals  = [int(c["ttft_ms"])    for c in calls_for_agent if c.get("ttft_ms")]
        total_vals = [int(c["latency_ms"]) for c in calls_for_agent if c.get("latency_ms")]
        latency_by_agent.append({
            "agent": agent,
            "color_class": _agent_color(agent),
            "calls": len(calls_for_agent),
            "ttft_p50_ms": _percentile(ttft_vals, 50),
            "ttft_p95_ms": _percentile(ttft_vals, 95),
            "total_p50_ms": _percentile(total_vals, 50),
            "total_p95_ms": _percentile(total_vals, 95),
        })

    # ── per-phase summary ───────────────────────────────────────────
    phase_summary = []
    for i, p in enumerate(phases):
        # Gather ttfts within this phase for p50.
        phase_ttfts = [
            int(c["ttft_ms"])
            for t in p["turns"] for c in t["llm_calls"]
            if c.get("ttft_ms")
        ]
        phase_summary.append({
            "id": p["id"],
            "name": p["id"].replace("_", " ").title(),
            "color": _PHASE_DOT_COLORS[i % len(_PHASE_DOT_COLORS)],
            "duration_human": _human_ms(p["duration_ms"]),
            "calls": p["llm_calls"],
            "ttft_p50_human": _human_ms(_percentile(phase_ttfts, 50)),
            "cost_usd": p["cost_usd"],
            "cost_human": _human_usd(p["cost_usd"]),
            "cache_hit_pct": (
                100.0 * p["llm_tokens_cached"] / p["llm_tokens_in"]
                if p["llm_tokens_in"] else 0.0
            ),
        })

    # ── verifier intent distribution ────────────────────────────────
    intent_counts: dict[str, int] = {}
    for p in phases:
        for t in p["turns"]:
            v = t.get("verifier") or {}
            i = v.get("intent")
            if i:
                intent_counts[i] = intent_counts.get(i, 0) + 1
    intents_total = sum(intent_counts.values()) or 1
    verifier_intents = []
    # Sort by count descending so the dominant intent leads.
    for intent, n in sorted(intent_counts.items(), key=lambda kv: -kv[1]):
        verifier_intents.append({
            "intent": intent,
            "count": n,
            "pct": round(100.0 * n / intents_total, 1),
            "color": _VERIFIER_INTENT_COLORS.get(intent, "var(--text-mute)"),
        })
    # Conic-gradient stop list for the donut, joined ready for CSS.
    donut_stops: list[str] = []
    cum = 0.0
    for it in verifier_intents:
        end = cum + it["pct"]
        donut_stops.append(f"{it['color']} {cum:.2f}% {end:.2f}%")
        cum = end

    # ── latency sparkline (polyline points, 0..480 x range) ─────────
    if calls:
        ttft_max = max(ttfts or [1])
        total_max = max((c.get("latency_ms") or 1) for c in calls)
        # 36 px tall, 4 px top/bottom padding.
        def _polyline(values: list[int | None], scale_max: int) -> str:
            pts = []
            if not values:
                return ""
            step = 480.0 / max(1, len(values) - 1)
            for i, v in enumerate(values):
                x = i * step
                y = 32.0 - (32.0 * (float(v or 0) / max(1, scale_max)))
                pts.append(f"{x:.1f},{y:.1f}")
            return " ".join(pts)
        spark_ttft  = _polyline([c.get("ttft_ms") for c in calls], ttft_max)
        spark_total = _polyline([c.get("latency_ms") for c in calls], total_max)
    else:
        spark_ttft = spark_total = ""

    # ── speech costs ────────────────────────────────────────────────
    stt_audio_ms = sum(p.get("stt_audio_ms") or 0 for p in phases)
    tts_chars    = sum(p.get("tts_chars") or 0 for p in phases)
    stt_cost = stt_audio_ms * _stt_usd_per_audio_ms()
    tts_cost = tts_chars * _tts_usd_per_char()
    speech_total = stt_cost + tts_cost
    duration_ms = totals.get("duration_ms") or 0
    total_with_speech = total_cost + speech_total
    usd_per_min = (
        total_with_speech / (duration_ms / 60_000.0) if duration_ms else 0.0
    )

    # ── call timeline (for the per-call table) ──────────────────────
    call_timeline = []
    for c in calls:
        call_timeline.append({
            "ts": (c.get("ts") or "")[11:19],
            "agent": c.get("agent") or "?",
            "agent_color": _agent_color(c.get("agent") or ""),
            "model": (c.get("model") or "").split("/", 1)[-1].split(":", 1)[0] or "—",
            "tokens_in": c.get("tokens_in") or 0,
            "tokens_out": c.get("tokens_out") or 0,
            "tokens_cached": c.get("tokens_in_cached") or 0,
            "cache_pct": (
                100.0 * (c.get("tokens_in_cached") or 0) / c["tokens_in"]
                if c.get("tokens_in") else 0.0
            ),
            "latency_ms": c.get("latency_ms"),
            "latency_human": c.get("latency_human") or _human_ms(c.get("latency_ms")),
            "ttft_ms": c.get("ttft_ms"),
            "ttft_human": _human_ms(c.get("ttft_ms")),
            "cost_human": c.get("cost_human") or _human_usd(c.get("cost_usd") or 0),
            "status": c.get("status") or "completed",
            "is_err": c.get("status") == "error",
            "langfuse_trace_id": c.get("langfuse_trace_id"),
            "generation_id": c.get("generation_id"),
        })

    return {
        "kpi": {
            "total_cost_usd": total_cost,
            "total_cost_human": _human_usd(total_cost),
            "calls": len(calls),
            "calls_by_agent": by_agent_calls,
            "ttft_avg_ms": int(sum(ttfts) / len(ttfts)) if ttfts else 0,
            "ttft_p50_ms": _percentile(ttfts, 50),
            "ttft_p95_ms": _percentile(ttfts, 95),
            "cache_hit_ratio": round(cache_hit_ratio, 3),
            "cache_hit_pct": round(100.0 * cache_hit_ratio, 1),
            "tokens_in_total": total_tokens_in,
            "tokens_in_cached_total": total_tokens_in_cac,
            "errors_count": len(errored),
        },
        "cache_savings": {
            "tokens_cached": total_tokens_in_cac,
            "savings_usd": cache_savings_usd,
            "savings_usd_human": _human_usd(cache_savings_usd),
            "savings_pct": round(cache_savings_pct, 1),
        },
        "reliability": {
            "errors": len(transport),
            "cancellations": len(cancellations),
            "fallbacks": len(fallbacks),
            "validation": sum(1 for c in errored if c.get("error_reason") == "validation_or_error"),
        },
        "cost_by_model": cost_by_model,
        "latency_by_agent": latency_by_agent,
        "phase_summary": phase_summary,
        "verifier_intents": verifier_intents,
        "verifier_intents_total": sum(it["count"] for it in verifier_intents),
        "donut_stops": ", ".join(donut_stops) if donut_stops else "var(--bg-alt) 0% 100%",
        "spark_ttft": spark_ttft,
        "spark_total": spark_total,
        "ttft_avg_human":  _human_ms(int(sum(ttfts) / len(ttfts)) if ttfts else 0),
        "total_avg_human": _human_ms(
            int(sum((c.get("latency_ms") or 0) for c in calls) / len(calls))
            if calls else 0
        ),
        "speech": {
            "stt_audio_ms": stt_audio_ms,
            "stt_audio_human": _human_ms(stt_audio_ms),
            "stt_cost_usd": stt_cost,
            "stt_cost_human": _human_usd(stt_cost),
            "tts_chars": tts_chars,
            "tts_cost_usd": tts_cost,
            "tts_cost_human": _human_usd(tts_cost),
            "speech_total_usd": speech_total,
            "speech_total_human": _human_usd(speech_total),
            "total_with_speech_human": _human_usd(total_with_speech),
            "usd_per_min": usd_per_min,
            "usd_per_min_human": _human_usd(usd_per_min),
            "duration_human": _human_ms(duration_ms),
        },
        "call_timeline": call_timeline,
        "has_any_calls": bool(calls),
    }


# ── Per-model cost rollup ─────────────────────────────────────────────────
#
# The dashboard Summary tab reads the per-model rollup from a small sidecar
# (`sessions/<token>/cost_summary.json`) that the observability tracker
# writes at SESSION_ENDED. The same numbers ship to Langfuse via
# `cost_details` — by construction the dashboard and Langfuse session
# totals agree on every row. For in-progress sessions where no sidecar
# exists yet, we fall back to the live in-process tracker snapshot.


def build_per_model_from_events(events: "list[dict] | None") -> dict | None:
    """Rebuild the per-model cost rollup straight from the event log.

    This is the DETERMINISTIC source of truth: every billable action leaves
    an event (`llm_call_completed` carries model + token counts,
    `stt_final` carries `audio_ms`, `tts_speak_chunk_sent` carries the text
    whose length is the billed char count). Unlike the in-process
    `cost_tracker` map + its sidecar, it can't be lost to a worker restart,
    a key mismatch, or a persist that ran while the map was empty — which is
    exactly why the Summary tab kept showing "no per-model cost recorded".

    Returns a snapshot-shaped dict (same keys as `cost_tracker.snapshot`) so
    `load_per_model_summary` can treat it interchangeably, or None when there
    are no billable events.
    """
    if not events:
        return None

    # model -> aggregated row (same shape as cost_tracker._empty_row()).
    agg: dict[str, dict] = {}

    def _row(model: str, kind: str) -> dict:
        r = agg.get(model)
        if r is None:
            r = {
                "model": model, "kind": kind, "calls": 0,
                "tokens_in": 0, "tokens_out": 0, "tokens_cached": 0,
                "tokens_cache_write": 0, "audio_ms": 0, "chars": 0,
                "cost_usd": 0.0,
            }
            agg[model] = r
        return r

    for ev in events:
        kind = ev.get("kind", "")
        payload = ev.get("payload") or {}

        if kind == "llm_call_completed":
            model = payload.get("model")
            if not model:
                continue
            tokens_in = int(payload.get("tokens_in") or 0)
            tokens_out = int(payload.get("tokens_out") or 0)
            tokens_cached = int(payload.get("tokens_in_cached") or 0)
            tokens_cache_write = int(payload.get("tokens_in_cache_write") or 0)
            upstream = payload.get("cost_usd")
            if upstream is not None:
                usd = float(upstream)
            else:
                usd = _llm_cost_usd(
                    model, tokens_in, tokens_out,
                    cached=tokens_cached, cache_write=tokens_cache_write,
                )
            r = _row(model, "llm")
            r["calls"] += 1
            r["tokens_in"] += tokens_in
            r["tokens_out"] += tokens_out
            r["tokens_cached"] += tokens_cached
            r["tokens_cache_write"] += tokens_cache_write
            r["cost_usd"] += usd

        elif kind == "stt_final":
            # Prefer the real billable duration (audio_ms); fall back to
            # end_ms only for pre-fix logs that didn't record audio_ms.
            audio_ms = int(payload.get("audio_ms") or payload.get("end_ms") or 0)
            if audio_ms <= 0:
                continue
            r = _row("azure-speech-stt", "stt")
            r["calls"] += 1
            r["audio_ms"] += audio_ms
            r["cost_usd"] += audio_ms * _stt_usd_per_audio_ms()

        elif kind == "tts_speak_chunk_sent":
            chars = len(payload.get("text") or "")
            if chars <= 0:
                continue
            r = _row("azure-speech-tts", "tts")
            r["calls"] += 1
            r["chars"] += chars
            r["cost_usd"] += chars * _tts_usd_per_char()

    rows = list(agg.values())
    if not rows:
        return None
    rows.sort(key=lambda r: -r["cost_usd"])
    return {
        "rows": rows,
        "total_cost_usd": sum(r["cost_usd"] for r in rows),
        "totals": {
            "tokens_in": sum(r["tokens_in"] for r in rows if r["kind"] == "llm"),
            "tokens_out": sum(r["tokens_out"] for r in rows if r["kind"] == "llm"),
            "tokens_cached": sum(r["tokens_cached"] for r in rows if r["kind"] == "llm"),
            "tokens_cache_write": sum(
                r["tokens_cache_write"] for r in rows if r["kind"] == "llm"
            ),
        },
    }


def load_per_model_summary(
    token_dir: "Path | None", token: str, events: "list[dict] | None" = None,
) -> dict:
    """Load the per-model cost rollup for a session.

    Read order:
      1. `sessions/<token>/cost_summary.json` (written at SESSION_ENDED).
      2. Live `cost_tracker.snapshot(token)` from in-process state — used
         when the session is still running.
      3. Rebuild from the event log (`events.jsonl`) — the deterministic
         source of truth. Used whenever 1 & 2 produce NO rows (e.g. the
         sidecar was persisted while the in-memory map was empty, or the
         worker restarted and lost the live map). `events` may be passed in
         by the caller to avoid re-parsing; otherwise it's read from
         `token_dir/events.jsonl`.
      4. Empty dict ({rows: [], total_cost_usd: 0}).

    Each row is decorated with a human-readable cost string for the
    template.

    Returns shape:
      {
        "rows": [ {model, kind, calls, tokens_in, tokens_out,
                   tokens_cached, tokens_cache_write, audio_ms, chars,
                   cost_usd, cost_human}, ...],
        "total_cost_usd": float,
        "total_cost_human": str,
        "totals": {"tokens_in": int, "tokens_out": int,
                   "tokens_cached": int, "tokens_cache_write": int},
        "source": "sidecar" | "live" | "events" | "empty",
      }
    """
    out: dict = {
        "rows": [],
        "total_cost_usd": 0.0,
        "total_cost_human": _human_usd(0.0),
        "totals": {
            "tokens_in": 0, "tokens_out": 0,
            "tokens_cached": 0, "tokens_cache_write": 0,
        },
        "source": "empty",
    }

    snap: dict | None = None
    source = "empty"
    # 1. Sidecar first — survives process restart.
    if token_dir is not None:
        try:
            from engine.brain.observability.cost_tracker import load_sidecar
            sidecar = load_sidecar(Path(token_dir) / "cost_summary.json")
            # A sidecar with NO rows is useless (it was persisted while the
            # in-memory map was empty) — don't let it short-circuit the
            # event-log rebuild below.
            if sidecar and sidecar.get("rows"):
                snap = sidecar
                source = "sidecar"
        except Exception:
            snap = None

    # 2. Live snapshot — for in-progress sessions or when sidecar missing.
    if snap is None:
        try:
            from engine.brain.observability.cost_tracker import snapshot
            live = snapshot(token)
            if live and live.get("rows"):
                snap = live
                source = "live"
        except Exception:
            snap = None

    # 3. Deterministic rebuild from the event log — always works as long as
    #    events.jsonl exists. This is what makes the Summary tab reliable.
    if snap is None:
        if events is None and token_dir is not None:
            try:
                events = annotate(Path(token_dir) / "events.jsonl")
            except Exception:
                events = None
        rebuilt = build_per_model_from_events(events)
        if rebuilt:
            snap = rebuilt
            source = "events"

    out["source"] = source
    if not snap:
        return out

    rows = list(snap.get("rows") or [])
    for r in rows:
        r["cost_human"] = _human_usd(float(r.get("cost_usd") or 0.0))
    out["rows"] = rows
    out["total_cost_usd"] = float(snap.get("total_cost_usd") or 0.0)
    out["total_cost_human"] = _human_usd(out["total_cost_usd"])
    totals = snap.get("totals") or {}
    out["totals"] = {
        "tokens_in": int(totals.get("tokens_in") or 0),
        "tokens_out": int(totals.get("tokens_out") or 0),
        "tokens_cached": int(totals.get("tokens_cached") or 0),
        "tokens_cache_write": int(totals.get("tokens_cache_write") or 0),
    }
    return out
