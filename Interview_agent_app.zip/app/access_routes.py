"""Access screens (`/api/access`): who may do what.

Each tab is one permission, so a person who can edit the role grid cannot
also manage people unless they hold that permission too. The development
sign-in is what puts a person on the cookie; this router does not sign anyone in.
"""
from __future__ import annotations

from contextlib import contextmanager

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from app import access_service as access
from app.rbac import require

router = APIRouter(prefix="/api/access", tags=["access"])


@contextmanager
def _as_http():
    try:
        yield
    except access.AccessError as e:
        raise HTTPException(status_code=e.status, detail=str(e)) from e


class _ActiveBody(BaseModel):
    is_active: bool


class _GrantBody(BaseModel):
    role: str
    team: str


class _TeamBody(BaseModel):
    name: str
    key: str = ""


class _TeamPatch(BaseModel):
    name: str | None = None
    is_active: bool | None = None


class _StepBody(BaseModel):
    name: str = ""
    role: str


class _ChainBody(BaseModel):
    steps: list[_StepBody] = Field(default_factory=list)


class _PermissionBody(BaseModel):
    permission: str
    enabled: bool


@router.get("/people", dependencies=[Depends(require("admin.users"))])
def people() -> JSONResponse:
    """The People tab: every person, and the roles and teams a grant can name."""
    with _as_http():
        return JSONResponse(access.list_people())


@router.patch("/people/{user_id}", dependencies=[Depends(require("admin.users"))])
def person_active(user_id: int, body: _ActiveBody) -> JSONResponse:
    """Turn a person on or off."""
    with _as_http():
        return JSONResponse(access.set_active(user_id, body.is_active))


@router.post("/people/{user_id}/grants")
def person_grant(
    user_id: int, body: _GrantBody, actor: int = Depends(require("admin.users")),
) -> JSONResponse:
    """Give a role on a team. The actor id is recorded on the grant."""
    with _as_http():
        return JSONResponse(access.add_grant(
            user_id, body.role, body.team, granted_by=actor,
        ))


@router.delete("/people/{user_id}/grants", dependencies=[Depends(require("admin.users"))])
def person_ungrant(user_id: int, role: str, team: str) -> JSONResponse:
    """Take one role on one team away."""
    with _as_http():
        return JSONResponse(access.remove_grant(user_id, role, team))


@router.get("/teams", dependencies=[Depends(require("admin.teams"))])
def teams() -> JSONResponse:
    """The Teams tab."""
    with _as_http():
        return JSONResponse(access.list_teams())


@router.post("/teams", dependencies=[Depends(require("admin.teams"))])
def team_create(body: _TeamBody) -> JSONResponse:
    """Create a team. A blank key is filled in from the name."""
    with _as_http():
        return JSONResponse(access.create_team(body.name, body.key))


@router.patch("/teams/{team_key}", dependencies=[Depends(require("admin.teams"))])
def team_update(team_key: str, body: _TeamPatch) -> JSONResponse:
    """Rename a team or turn it on or off."""
    with _as_http():
        return JSONResponse(access.update_team(team_key, name=body.name, is_active=body.is_active))


@router.delete("/teams/{team_key}", dependencies=[Depends(require("admin.teams"))])
def team_delete(team_key: str) -> JSONResponse:
    """Delete a team nothing still uses."""
    with _as_http():
        return JSONResponse(access.delete_team(team_key))


@router.get("/teams/{team_key}/chain", dependencies=[Depends(require("admin.teams"))])
def team_chain(team_key: str) -> JSONResponse:
    """The steps on one team, shown under that team."""
    with _as_http():
        return JSONResponse(access.get_chain(team_key))


@router.put("/teams/{team_key}/chain", dependencies=[Depends(require("admin.teams"))])
def team_chain_save(team_key: str, body: _ChainBody) -> JSONResponse:
    """Replace the chain. Pools already waiting keep the steps they started with."""
    with _as_http():
        return JSONResponse(access.save_chain(
            team_key, [step.model_dump() for step in body.steps],
        ))


@router.get("/roles", dependencies=[Depends(require("admin.permissions"))])
def roles() -> JSONResponse:
    """The Roles tab: the fixed grid."""
    with _as_http():
        return JSONResponse(access.role_grid())


@router.put("/roles/{role_key}", dependencies=[Depends(require("admin.permissions"))])
def role_cell(role_key: str, body: _PermissionBody) -> JSONResponse:
    """Tick or clear one permission on one role."""
    with _as_http():
        return JSONResponse(access.set_permission(role_key, body.permission, body.enabled))
