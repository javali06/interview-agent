"""Collapse durable-resume boundaries in an interview's events.jsonl.

When a runner is lost mid-interview and a fresh runner RESUMES from the durable
checkpoint (feature B), the append-only ``events.jsonl`` ends up with, for the
interrupted phase P:

    … completed earlier phases …
    phase_changed → P            # pre-crash entry into the interrupted phase
    <partial P turns>            # the abandoned attempt (crash happened here)
    <gap>
    session_started (resumed)    # phantom second start the fresh runner emits
    session_resumed {phase: P}   # the interruption-boundary marker
    <fresh P turns>              # the resumed run

Read verbatim that looks like the interview restarted from the greeting and
re-ran P from scratch. Per product decision (2026-07): the interrupted phase's
pre-crash partial is REPLACED by the resumed run, while completed earlier phases
are preserved. This helper produces that "logical" stream for the trace viewer
and the evaluator: for each ``session_resumed`` marker it drops everything
strictly between the pre-crash entry into that phase and the marker (the partial
turns + the phantom second ``session_started``), keeping the phase-boundary
marker, the resume marker itself, and the resumed run.

A **mid-phase** resume (Phase 4, ``session_resumed`` with ``mode="turn"``)
continues from a per-turn checkpoint instead: everything up to that checkpoint
is the real interview (the candidate is NOT asked again), so only what came
after it — the AI reply that was in flight when the runner was lost, and the
phantom second ``session_started`` — is dropped. The checkpoint is found by the
``seq`` its ``checkpoint_written`` event and the resume marker share.

The RAW ``events.jsonl`` is never modified — this is a read-time view only, so
the interruption stays fully auditable (and Langfuse keeps its WARNING span).
"""
from __future__ import annotations


def _to_phase(payload: dict) -> str | None:
    return (
        payload.get("to_phase")
        or payload.get("to")
        or payload.get("new_phase")
    )


def collapse_resumed_events(events: list[dict]) -> list[dict]:
    """Return ``events`` with each interrupted phase's pre-crash partial removed
    so the resumed run replaces it. Order-preserving; safe on lists with no
    resume (returns an equivalent list). Handles multiple/repeated resumes."""
    if not events:
        return events

    drop: set[int] = set()
    for i, e in enumerate(events):
        if e.get("kind") != "session_resumed":
            continue
        payload = e.get("payload") or {}
        phase = payload.get("phase_id")
        if not phase:
            continue
        if payload.get("mode") == "turn":
            seq = payload.get("checkpoint_seq")
            start = -1
            for j in range(i - 1, -1, -1):
                ej = events[j]
                if (ej.get("kind") == "checkpoint_written"
                        and (ej.get("payload") or {}).get("seq") == seq):
                    start = j
                    break
            for k in range(start + 1, i):
                # Without its checkpoint event, keep the answers (dropping the
                # whole phase would lose them) and drop only the phantom start.
                if start >= 0 or (events[k].get("kind") == "session_started"
                                  and (events[k].get("payload") or {}).get("resumed")):
                    drop.add(k)
            continue
        # Walk back to the pre-crash ENTRY into this phase: the most recent
        # phase_changed boundary (into `phase`), or the first session_started
        # if `phase` was the opening phase. Skip already-dropped indices so
        # repeated resumes of the same phase collapse onto the original entry.
        entry = -1
        for j in range(i - 1, -1, -1):
            if j in drop:
                continue
            ej = events[j]
            kj = ej.get("kind")
            if kj == "phase_changed":
                # Skip the QUEUED pre-announcement (queued=True). The director
                # emits a queued phase_changed the instant a phase clock expires
                # (ungated, even mid-utterance) before the real APPLIED marker
                # (director.py:2264/2277/1841/1864 vs :746). The entry into the
                # interrupted phase is the APPLIED marker, not a pre-announcement
                # for a different phase, so keep walking back past queued ones.
                if (ej.get("payload") or {}).get("queued") is True:
                    continue
                # Most recent phase boundary before the crash = the entry into
                # the interrupted phase. Keep it as the phase marker; drop what
                # follows. (If it names a different phase it's still the right
                # anchor — everything after it is the abandoned attempt.)
                entry = j
                break
            if kj == "session_started":
                # Skip the PHANTOM second start the fresh runner emits on resume
                # (tagged resumed=True) — it isn't a real phase entry; it's part
                # of the abandoned-attempt noise we want to drop. Only the
                # ORIGINAL session_started anchors (opening phase never had a
                # phase_changed).
                if (ej.get("payload") or {}).get("resumed"):
                    continue
                entry = j
                break
        # Drop (entry, i) exclusive: the partial turns + the phantom second
        # session_started. Keep the entry marker and the resume marker onward.
        for k in range(entry + 1, i):
            drop.add(k)

    if not drop:
        return events
    return [e for idx, e in enumerate(events) if idx not in drop]
