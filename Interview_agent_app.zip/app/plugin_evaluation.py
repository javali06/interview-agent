"""Plugin-based evaluation orchestrator (v2).

Flow:
  events.jsonl ─► sectioner ─► phase→segment tree
  cadence ──────► EvaluationPlan (load, else migrate from rubric / derive)
  per segment ──► the phase's plugin(s) score it (concurrently)
  code ─────────► aggregate marks → benchmark v2 + v1-compatible adapter
  write sessions/<token>/evaluation.json

LLMs (inside plugins + one synthesis call) judge; this module only orchestrates
and the aggregator does the arithmetic. Gated by EVAL_PLUGINS_ENABLED — see
features/eval/plugins/feature_flag.py.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Optional

import yaml as _yaml

from app import plugin_aggregate as agg
from app.evaluation_service import (
    EvaluationModel,
    _eval_path,
    _read_events,
    _resolve_llm,
)
from app.paths import session_dir
from features.eval import plan as plan_mod
from features.eval import plan_storage
from features.eval.plugins import get_plugin, is_enabled  # noqa: F401  (is_enabled re-exported)
from features.eval.plugins._llm import extract_json_object
from features.eval.plugins.base import EvalContext, SegmentEvaluation
from features.eval.sectioner import Segment, build_segments

logger = logging.getLogger("plugin_evaluation")

# Concurrency cap on in-flight plugin LLM calls.
_MAX_CONCURRENCY = 6


def _now_iso() -> str:
    from app import db as admin_db
    return admin_db.now_iso()


def _resume_summary(sdir, resume_path: Optional[str]) -> str:
    if not resume_path:
        return ""
    try:
        from engine.orchestrator.resume_parser import parse_resume
        return parse_resume(sdir / resume_path)[:6000]
    except Exception as e:
        logger.warning("[plugin_eval] resume parse failed: %s", e)
        return ""


def _ensure_plan(token: str, cadence: dict, *, role: str) -> dict:
    """Load the saved plan, else migrate from the rubric / derive from cadence,
    then persist it. Always returns a validated plan dict."""
    existing = plan_storage.load_plan(token)
    if existing is not None:
        return existing
    import features.eval as rubric_mod

    try:
        rubric = rubric_mod.load_rubric(token)
    except Exception:
        rubric = None
    plan = plan_mod.plan_from_rubric(rubric, cadence) if rubric else plan_mod.plan_from_cadence(cadence, role=role)
    return plan_storage.save_plan(token, plan.model_dump(mode="json"))


def _build_context(row, sdir, cadence: dict) -> EvalContext:
    # No LLM key → run deterministic (python) plugins only; llm_judge plugins
    # report assumptions_unmet rather than crashing the whole evaluation.
    try:
        api_key, base_url, model = _resolve_llm()
    except Exception as e:
        logger.warning("[plugin_eval] no LLM configured (%s) — deterministic plugins only", e)
        api_key, base_url, model = "", "", "(no-llm)"
    llm_complete = None
    score_llm_raw = None
    if api_key:
        from openai import AsyncOpenAI
        client = AsyncOpenAI(api_key=api_key, base_url=base_url)
        extra_body = {"provider": {"sort": "throughput"}} if "openrouter" in (base_url or "") else {}

        async def llm_complete(*, system: str, user: str) -> str:  # noqa: ANN001
            resp = await client.chat.completions.create(
                model=model,
                messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
                temperature=0.2,
                max_tokens=1500,
                response_format={"type": "json_object"},
                extra_body=extra_body,
            )
            return resp.choices[0].message.content or ""

        # Separate accessor for answer-scoring plugins: same client/credentials,
        # but a CALLER-SPECIFIED model (features.eval.plugins._llm.SCORING_LLM_MODEL,
        # never this function's `model`) at temperature=0 for reproducible scoring.
        async def score_llm_raw(scoring_model: str, prompt: str) -> str:  # noqa: ANN001
            resp = await client.chat.completions.create(
                model=scoring_model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0,
                max_tokens=1500,
                response_format={"type": "json_object"},
                extra_body=extra_body,
            )
            return resp.choices[0].message.content or ""

    seniority_bar = ""
    try:
        import features.eval as rubric_mod
        rub = rubric_mod.load_rubric(row["token"]) or {}
        seniority_bar = rub.get("seniority_bar") or ""
    except Exception:
        pass

    return EvalContext(
        role=row["role"] or "",
        jd_text=(row["jd_text"] or "").strip(),
        resume_summary=_resume_summary(sdir, row["resume_path"]),
        seniority_bar=seniority_bar,
        cadence=cadence,
        llm_complete=llm_complete,
        score_llm_raw=score_llm_raw,
    ), model


def _plan_index(plan: dict) -> dict[str, list[dict]]:
    """phase_id -> list of enabled plugin assignments. Skips not-scored ones:
    disabled, or with no plugin chosen (empty plugin_id)."""
    out: dict[str, list[dict]] = {}
    for ph in plan.get("phases", []):
        out[ph.get("phase_id")] = [
            a for a in (ph.get("plugins") or [])
            if a.get("enabled", True) and a.get("plugin_id")
        ]
    return out


async def _synthesize(ctx: EvalContext, v2: dict) -> dict:
    """One small LLM call for headline/summary/strengths/weaknesses; falls back
    to deterministic synthesis when no LLM or on parse failure."""
    if not ctx.has_llm:
        return agg.deterministic_synthesis(v2)
    lines = [f"- {p['name']}: {p['marks_earned']:g}/{p['marks_possible']:g} marks" for p in v2["phases"]]
    system = (
        "You are a hiring manager writing the executive summary of a scored "
        "interview. Return STRICT JSON only: "
        '{"headline":"<=14 words","summary":"<=120 words","strengths":[{"title":"<=6 words","detail":"1 sentence"}],'
        '"weaknesses":[{"title":"<=6 words","detail":"1 sentence"}]}. 3-5 strengths, 0-4 weaknesses.'
    )
    user = (
        f"Benchmark total: {v2['total']['marks_earned']:g}/{v2['total']['marks_possible']:g} "
        f"({v2['total']['pct']}%).\nPer-phase marks:\n" + "\n".join(lines) + "\n\nReturn the JSON now."
    )
    try:
        parsed = extract_json_object(await ctx.complete(system, user))
        if parsed and parsed.get("strengths"):
            return {
                "headline": str(parsed.get("headline") or "")[:120],
                "summary": str(parsed.get("summary") or ""),
                "strengths": parsed.get("strengths") or [],
                "weaknesses": parsed.get("weaknesses") or [],
            }
    except Exception as e:
        logger.warning("[plugin_eval] synthesis LLM failed: %s", e)
    return agg.deterministic_synthesis(v2)


async def generate_evaluation_v2(token: str, *, feedback: Optional[str] = None,
                                 prior: Optional[dict] = None) -> dict:
    """Generate (or re-run) the benchmark evaluation. Writes evaluation.json
    (v1-compatible top-level + the v2 benchmark under `benchmark`)."""
    from app import db as admin_db

    row = admin_db.get(token)
    if row is None:
        raise ValueError(f"session {token!r} not found in SQLite")

    sdir = session_dir(token)
    # The logical stream: an interrupted-and-resumed run counted once (the v1
    # transcript and the trace viewer read it the same way).
    from app.resume_collapse import collapse_resumed_events
    events = collapse_resumed_events(
        _read_events(sdir / (row["event_log_path"] or "events.jsonl")))
    cadence = _yaml.safe_load(row["cadence_yaml"] or "") or {}

    interview = build_segments(events, cadence=cadence, token=token)
    plan = _ensure_plan(token, cadence, role=row["role"] or "")
    plan_fp = plan_mod.plan_fingerprint(plan)
    assignments = _plan_index(plan)

    ctx, model = _build_context(row, sdir, cadence)

    # Build the task list: (phase, plugin assignment, segment) for each enabled
    # plugin × each non-warmup segment of that phase.
    sem = asyncio.Semaphore(_MAX_CONCURRENCY)

    async def _run(seg: Segment, plugin_id: str, config: dict) -> SegmentEvaluation:
        async with sem:
            return await get_plugin(plugin_id)().run(seg, config, ctx=ctx)

    phase_blocks_input: list[dict] = []
    all_evals: list[SegmentEvaluation] = []
    # (segment, evaluation) in interview order — the input to the machine-
    # readable export. Kept alongside `all_evals` because a plugin's
    # `export_section` needs the SEGMENT too (question_id lives there).
    export_pairs: list[tuple[Segment, SegmentEvaluation]] = []
    coding_quality: list[dict] = []

    for ph in interview.phases:
        plugins = assignments.get(ph.phase_id, [])
        if not plugins:
            continue  # ungraded phase (no plugin / not scored) — excluded from the report + totals
        segs = [s for s in ph.segments if s.kind != "warmup"]
        plugin_blocks = []
        for a in plugins:
            pid = a["plugin_id"]
            cfg = a.get("config") or {}
            evs = await asyncio.gather(*[_run(s, pid, cfg) for s in segs]) if segs else []
            pairs = list(zip(segs, evs))
            all_evals.extend(evs)
            export_pairs.extend(pairs)
            # coding_quality (back-compat for build_coding_performance)
            if pid == "coding":
                for seg, ev in pairs:
                    if ev.state == "scored":
                        r = ev.raw
                        coding_quality.append({
                            "phase_id": ph.phase_id, "question_id": seg.question_id,
                            "pass_rate": r.get("pass_rate"), "correctness": r.get("correctness"),
                            "readability": r.get("readability"), "idiomatic": r.get("idiomatic"),
                            "edge_cases": r.get("edge_cases"), "rationale": ev.rationale,
                            "runs_used": r.get("runs_used"), "hints_used": r.get("hints_used"),
                            "time_to_submit_s": 0.0, "anti_cheat_signals": r.get("anti_cheat_signals"),
                        })
            plugin_blocks.append((pid, get_plugin(pid).view_id, cfg, pairs))
        phase_blocks_input.append(
            agg.build_phase(
                ph.phase_id, ph.phase_id.replace("_", " ").title(), plugin_blocks,
                cadence=cadence, token=token,
            )
        )

    generated_at = _now_iso()
    v2 = agg.aggregate(
        phase_blocks_input, model=model, generated_at=generated_at,
        plan_fingerprint=plan_fp, coding_quality=coding_quality, all_evals=all_evals,
    )
    synthesis = await _synthesize(ctx, v2)
    data = agg.to_evaluation_model_v1(v2, synthesis=synthesis)

    # Validate the v1-compatible view so existing consumers stay safe.
    try:
        EvaluationModel.model_validate(data)
    except Exception as e:
        logger.warning("[plugin_eval] v1 adapter failed validation (persisting anyway): %s", e)

    sdir.mkdir(parents=True, exist_ok=True)
    _eval_path(token).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    _write_export(token, sdir, row, export_pairs, generated_at)
    logger.info(
        "[plugin_eval] wrote %s (benchmark %.1f/%.1f = %.0f%%)",
        _eval_path(token), v2["total"]["marks_earned"], v2["total"]["marks_possible"], v2["total"]["pct"],
    )
    return data


def _write_export(token: str, sdir, row: dict,
                  pairs: list[tuple[Segment, SegmentEvaluation]],
                  generated_at: str) -> None:
    """Write the machine-readable export next to evaluation.json.

    Deliberately a SEPARATE artefact rather than a key inside evaluation.json:
    that file is an internal shape that changes whenever the UI does, and the
    whole point of the export is a document that does not. Mirrored to blob so
    the gateway can serve it read-through like every other session artefact.

    Never fatal — a failure here must not lose a completed evaluation.
    """
    from features.eval.export import build_report

    try:
        report = build_report(
            pairs,
            session={
                "token": token,
                "role": row.get("role") or "",
                "candidate_name": row.get("candidate_name") or "",
                "modality": row.get("modality") or "voice",
            },
            generated_at=generated_at,
        )
        body = report.model_dump_json(indent=2)
        (sdir / "evaluation_export.json").write_text(body, encoding="utf-8")
        try:
            import io
            from app import blob_store
            blob_store.upload_fileobj(
                io.BytesIO(body.encode("utf-8")), f"{token}/evaluation_export.json")
        except Exception as e:      # blob is best-effort; the local copy is written
            logger.debug("[plugin_eval] export blob mirror failed: %s", e)
        logger.info(
            "[plugin_eval] wrote evaluation_export.json (%d sections, %.1f/%.1f)",
            len(report.sections), report.totals.marks_earned, report.totals.marks_possible,
        )
    except Exception as e:
        logger.warning("[plugin_eval] export build failed (evaluation kept): %s", e)


async def run_evaluation(token: str, *, feedback: Optional[str] = None,
                         prior: Optional[dict] = None) -> dict:
    """Dispatcher used by the orchestrator + admin routes: route to the v2
    plugin pipeline when EVAL_PLUGINS_ENABLED is set, else the v1 single-pass
    evaluator. Keeps the call sites flag-agnostic."""
    if is_enabled():
        return await generate_evaluation_v2(token, feedback=feedback, prior=prior)
    from app.evaluation_service import generate_evaluation as _v1
    return await _v1(token, feedback=feedback, prior=prior)
