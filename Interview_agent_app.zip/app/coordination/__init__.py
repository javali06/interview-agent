"""Coordination plane — the shared Redis memory that makes the stateful session
tier routable across replicas.

Three concerns, one Redis:
  registry   token -> owning session shard (replaces the _token_sessions dict)
  admission  cluster-wide counters + caps (Speech streams, LLM inflight, sessions)
  locks      single-winner token claim (no double-start)

See each module's docstring. Redis is a hard dependency here — there is no
in-process fallback (that was the single-replica trap).
"""
from __future__ import annotations

from app.coordination import admission, locks, registry
from app.coordination.client import close_redis, get_redis, ping, set_redis

__all__ = [
    "registry", "admission", "locks",
    "get_redis", "set_redis", "close_redis", "ping",
]
