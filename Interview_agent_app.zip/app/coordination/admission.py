"""Cluster-wide admission counters.

Each replica used to decide alone whether it could start an interview. At scale
that collectively blows shared external limits — the 5-concurrent-streams-per-key
Azure Speech cap and the LLM rate limits — producing 429s and wedged interviews.
These counters make admission a CLUSTER decision: a session may start only when a
Speech slot AND LLM headroom actually exist across the whole fleet.

Correctness note: ``INCR`` returns a distinct post-increment value to each
concurrent caller, so ``new = INCR(k); if new > cap: DECR(k)`` is race-free for
the cap check without a lock — two racers get values n and n+1 and at most one
sees ``<= cap``. Releases floor at zero (a double-release can't drive a counter
negative and permanently inflate headroom).

Counters (all under the ``adm:`` prefix):
  adm:active_sessions        live interviews across the fleet
  adm:speech:{key_id}        streams in flight per Azure Speech key (cap 5)
  adm:llm_inflight           slow+fast LLM calls in flight
  adm:shard:{shard}          sessions pinned to each shard (for least-loaded pick)
"""
from __future__ import annotations

import json
import logging
import os

from app.coordination.client import get_redis

logger = logging.getLogger("coordination.admission")

ACTIVE_SESSIONS = "adm:active_sessions"
LLM_INFLIGHT = "adm:llm_inflight"


def speech_key_counter(key_id: str) -> str:
    return f"adm:speech:{key_id}"


def shard_counter(shard: str) -> str:
    return f"adm:shard:{shard}"


# Caps are env-tunable with no redeploy. None = uncapped.
def _cap(env: str, default: int | None) -> int | None:
    raw = (os.environ.get(env) or "").strip()
    if not raw:
        return default
    return int(raw)


def max_active_sessions() -> int | None:
    return _cap("MAX_ACTIVE_SESSIONS", None)


def speech_streams_per_key() -> int:
    return _cap("SPEECH_STREAMS_PER_KEY", 5) or 5


def max_llm_inflight() -> int | None:
    return _cap("MAX_LLM_INFLIGHT", None)


def max_shard_sessions() -> int | None:
    """Per-shard live-session cap (env ``SHARD_MAX_SESSIONS``). None = uncapped
    (default — preserves today's behavior). Set it to the shard's CPU-bound
    comfort ceiling (~20-30 on 1-2 vCPU) so claim rejects an overloaded shard
    instead of silently piling every interview onto one gunicorn event loop."""
    return _cap("SHARD_MAX_SESSIONS", None)


# Floor-at-zero release so a stray double-decrement can't inflate headroom.
_RELEASE_LUA = """
local v = redis.call('decr', KEYS[1])
if v < 0 then redis.call('set', KEYS[1], 0); return 0 end
return v
"""


async def try_acquire(counter: str, cap: int | None) -> bool:
    """Atomically take one unit of ``counter`` if under ``cap``.

    Returns True on success (caller MUST later release). None cap = always ok.
    """
    r = get_redis()
    new = await r.incr(counter)
    if cap is not None and new > cap:
        await r.decr(counter)
        return False
    return True


async def release(counter: str) -> int:
    """Give one unit back; never goes below zero. Returns the new value."""
    return int(await get_redis().eval(_RELEASE_LUA, 1, counter))


async def value(counter: str) -> int:
    raw = await get_redis().get(counter)
    return int(raw) if raw else 0


async def least_loaded_shard(shards: list[str]) -> str:
    """Pick the shard currently running the fewest interviews. Used by the
    gateway to place a NEW token (reconnects follow the registry)."""
    if not shards:
        raise ValueError("no session shards configured")
    r = get_redis()
    counts = await r.mget([shard_counter(s) for s in shards])
    loads = [(int(c) if c else 0, s) for c, s in zip(counts, shards)]
    loads.sort()  # (load, shard) — fewest first, ties broken by shard name
    return loads[0][1]


# ── self-healing reconciliation ──────────────────────────────────────────────
#
# The counters above are plain INCR/DECR with no TTL. A session that ends WITHOUT
# the graceful release path (replica crash / redeploy / OOM / orphan evict where
# the in-process handle is gone) leaves its increments behind forever, so
# adm:active_sessions / adm:shard:* / adm:speech:* drift upward and eventually
# reject interviews the cluster has room for (and permanently eat the 5/key Azure
# Speech cap). The registry (reg:session:*) is the TTL-backed source of truth —
# a crashed session's entry expires on its own — so we periodically rebuild the
# counters from it and heal any leak.
#
# Race safety: a counter is corrected DOWN only when it's been above the
# registry-derived value across TWO consecutive passes with the SAME derived
# value. An in-flight claim INCRs a counter BEFORE writing its registry entry, so
# during that ~1s window the counter looks "over" — but that resolves within one
# pass, so the two-pass gate never mistakes it for a leak. Healing uses SET (to
# the derived truth), which is idempotent, so running the reconciler on every
# session replica is safe (no double-correction).

# counter -> the derived value we saw it exceeding on the PREVIOUS pass.
_RECON_PREV_OVER: dict[str, int] = {}


async def reconcile() -> dict[str, tuple[int, int]]:
    """One reconciliation pass. Returns {counter: (old, healed)} for anything
    corrected this pass. Safe to call periodically from every session replica."""
    r = get_redis()

    # 1. Derive ground truth from the live (TTL-backed) registry.
    active = 0
    shard_ct: dict[str, int] = {}
    speech_ct: dict[str, int] = {}
    async for key in r.scan_iter(match="reg:session:*", count=200):
        raw = await r.get(key)
        if not raw:
            continue
        try:
            d = json.loads(raw)
        except Exception:
            continue
        active += 1
        sh = d.get("shard")
        if sh:
            shard_ct[sh] = shard_ct.get(sh, 0) + 1
        sk = d.get("speech_key") or ""
        if sk:
            speech_ct[sk] = speech_ct.get(sk, 0) + 1

    # 2. Desired value for every EXISTING counter (so a fully-leaked shard/key
    #    counter — present in Redis but with zero live sessions — heals to 0).
    desired: dict[str, int] = {ACTIVE_SESSIONS: active}
    async for key in r.scan_iter(match="adm:shard:*", count=200):
        desired[key] = shard_ct.get(key[len("adm:shard:"):], 0)
    async for key in r.scan_iter(match="adm:speech:*", count=200):
        desired[key] = speech_ct.get(key[len("adm:speech:"):], 0)
    if active == 0:
        # No live sessions ⇒ no in-flight LLM calls; floor the transient counter.
        desired[LLM_INFLIGHT] = 0

    # 3. Heal, gated on a leak persisting two consecutive passes at the same
    #    derived value.
    healed: dict[str, tuple[int, int]] = {}
    for counter, want in desired.items():
        cur = await value(counter)
        if cur > want:
            if _RECON_PREV_OVER.get(counter) == want:
                await r.set(counter, want)
                healed[counter] = (cur, want)
                _RECON_PREV_OVER.pop(counter, None)
            else:
                _RECON_PREV_OVER[counter] = want  # first sighting — wait one pass
        else:
            _RECON_PREV_OVER.pop(counter, None)

    # Forget stale pending-leak flags for counters not examined this pass.
    for c in [c for c in _RECON_PREV_OVER if c not in desired]:
        _RECON_PREV_OVER.pop(c, None)

    if healed:
        logger.warning("[admission] reconciled leaked counters (counter: old->new): %s",
                       healed)
    return healed
