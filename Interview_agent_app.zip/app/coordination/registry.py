"""token → session-replica registry.

Replaces the in-process ``_token_sessions`` dict (deploy/azure_app.py) that made
the monolith single-replica. The dict lived inside ONE process's memory, so a
reconnect that hit a different replica could not find the running interview. Here the *routing pointer* lives in Redis instead — every replica and
the gateway can look up which session shard owns a token.

What is stored is deliberately tiny: the owning shard's id + internal FQDN + a
created-at stamp, under a TTL. It is NOT the interview. The live objects
(WebBroadcaster, brain, SessionState) stay in the owning replica's memory; this
just points at them. If Redis loses an entry the interview itself is unharmed —
the pointer is rebuilt on the next heartbeat, and the durable truth is Postgres +
events.jsonl. ("Redis points to the truth; Postgres is the truth.")

The TTL is the liveness signal: the owning replica refreshes it on a heartbeat
while the interview runs. If a replica dies, its entries expire and the token is
free to be re-claimed — this is the distributed replacement for the old
``_evict_session_orphans`` loop.

**Fenced lease.** Every claim takes the next number from a per-token counter
(the *fence*) and records it in the entry. Renewal and release are atomic and
act only on the caller's own entry, so a replica that was cut off and comes
back cannot renew, re-take, or delete an interview another replica has since
claimed. A missing entry (Redis lost it) may be restored by its owner — but
only if no newer claim happened since. Without this, two replicas could run the
same interview once the session tier has more than one replica.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass

from app.coordination.client import get_redis

# One key per live interview. Short prefix keeps Redis memory tiny.
_KEY = "reg:session:{token}"

# Default liveness TTL. The owning replica heartbeats well inside this; a missed
# few heartbeats (crash) lets the entry expire so the token can be re-claimed.
DEFAULT_TTL_S = 60

# Per-token claim counter. Outlives any interview by far; expires so finished
# tokens don't accumulate.
_FENCE_KEY = "reg:fence:{token}"
_FENCE_TTL_S = 7 * 24 * 3600

# Renew our own entry. 1 = renewed, 2 = restored after Redis lost it (no newer
# claim exists), 0 = lost: someone else holds it, or claimed after us.
_RENEW_LUA = """
local cur = redis.call('GET', KEYS[1])
if cur == ARGV[1] then
  redis.call('EXPIRE', KEYS[1], ARGV[2])
  return 1
end
if cur then return 0 end
local latest = tonumber(redis.call('GET', KEYS[2]) or '0')
if latest > tonumber(ARGV[3]) then return 0 end
redis.call('SET', KEYS[1], ARGV[1], 'EX', ARGV[2])
return 2
"""

# Delete only our own entry.
_RELEASE_LUA = """
if redis.call('GET', KEYS[1]) == ARGV[1] then
  return redis.call('DEL', KEYS[1])
end
return 0
"""

RENEWED, RESTORED, LOST = "renewed", "restored", "lost"


def _key(token: str) -> str:
    return _KEY.format(token=token)


def _fence_key(token: str) -> str:
    return _FENCE_KEY.format(token=token)


@dataclass
class SessionLocation:
    token: str
    shard: str            # logical shard id, e.g. "session-3"
    fqdn: str             # internal ACA address the gateway proxies to
    created_at: float
    # Azure Speech key_id this session leased (short stable hash), or "" for
    # Groq / none. Recorded here so the admission reconciler can rebuild the
    # per-key Speech counter from the live (TTL-backed) registry and heal leaks
    # left by sessions that ended without releasing (crash / redeploy / evict).
    speech_key: str = ""
    # This claim's serial (see "Fenced lease" above). 0 = an entry written
    # before fencing existed.
    fence: int = 0

    @classmethod
    def from_json(cls, token: str, raw: str) -> "SessionLocation":
        d = json.loads(raw)
        return cls(token=token, shard=d["shard"], fqdn=d["fqdn"],
                   created_at=d.get("created_at", 0.0),
                   speech_key=d.get("speech_key", ""),
                   fence=int(d.get("fence", 0)))

    def to_json(self) -> str:
        return json.dumps({"shard": self.shard, "fqdn": self.fqdn,
                           "created_at": self.created_at,
                           "speech_key": self.speech_key,
                           "fence": self.fence})


async def claim(token: str, shard: str, fqdn: str, *, speech_key: str = "",
                ttl_s: int = DEFAULT_TTL_S, now: float | None = None) -> SessionLocation:
    """Record that ``shard`` (reachable at ``fqdn``) owns this interview.

    Call this only AFTER winning the per-token lock (locks.session_lock), so two
    replicas never claim the same token. Overwrites any stale entry and takes a
    new fence, so the previous owner's renewals fail from now on. ``speech_key``
    is the leased Azure Speech key_id (for admission reconciliation).
    """
    r = get_redis()
    fence = int(await r.incr(_fence_key(token)))
    await r.expire(_fence_key(token), _FENCE_TTL_S)
    loc = SessionLocation(token=token, shard=shard, fqdn=fqdn,
                          created_at=now if now is not None else time.time(),
                          speech_key=speech_key, fence=fence)
    await r.set(_key(token), loc.to_json(), ex=ttl_s)
    return loc


async def get(token: str) -> SessionLocation | None:
    raw = await get_redis().get(_key(token))
    return SessionLocation.from_json(token, raw) if raw else None


async def renew(loc: SessionLocation, *, ttl_s: int = DEFAULT_TTL_S) -> str:
    """Refresh OUR lease: RENEWED, RESTORED (Redis had lost the entry and nobody
    claimed since), or LOST (another replica holds or has claimed it — stop
    working on this interview)."""
    n = await get_redis().eval(_RENEW_LUA, 2, _key(loc.token), _fence_key(loc.token),
                               loc.to_json(), ttl_s, loc.fence)
    return {1: RENEWED, 2: RESTORED}.get(int(n), LOST)


async def release(token: str, loc: SessionLocation | None = None) -> None:
    """Drop the pointer when the interview ends. With ``loc``, only if it is
    still ours — a replica that lost the interview must not delete the new
    owner's entry."""
    if loc is None:
        await get_redis().delete(_key(token))
        return
    await get_redis().eval(_RELEASE_LUA, 1, _key(token), loc.to_json())
