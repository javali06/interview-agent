"""Metrics for replicas Prometheus cannot reach (the session pool, the worker).

A pool replica has no ingress and the worker has none either, so neither can be
scraped. Instead each one PUBLISHES its own /metrics text to Redis every few
seconds, and the gateway (which Prometheus does reach) serves all of them merged
at ``/metrics/pushed``, each sample labelled with the replica it came from.

Redis is already a hard dependency of every tier, so this adds no new service.
A key expires a few intervals after its replica stops publishing, so a dead or
scaled-in replica drops out of the graphs on its own instead of freezing at its
last value.

The merged output is labelled ``instance`` (the replica) and ``tier``; the
Prometheus job for it sets ``honor_labels: true`` so those survive the scrape,
which makes a pool replica show up in the per-instance panels exactly like an
addressable shard does.
"""
from __future__ import annotations

import asyncio
import logging
import os
from typing import Awaitable, Callable

from app.coordination.client import get_redis

logger = logging.getLogger("coordination.metrics_push")

_KEY = "metrics:pushed:{replica}"
_PREFIX = "metrics:pushed:"


def interval_s() -> float:
    return float(os.environ.get("METRICS_PUSH_INTERVAL_S", "10"))


def ttl_s() -> int:
    # Three missed pushes and the replica is gone from the graphs.
    return max(5, int(interval_s() * 3))


async def publish(replica: str, tier: str, text: str) -> None:
    # The tier rides in the value (first line) so the reader needs one GET.
    await get_redis().set(_KEY.format(replica=replica), f"{tier}\n{text}", ex=ttl_s())


async def publish_loop(replica: str, tier: str, render: Callable[[], Awaitable[bytes]],
                       stop: asyncio.Event) -> None:
    """Publish this replica's metrics until ``stop``. Never raises: losing a
    metrics push must not touch the interviews running here."""
    while not stop.is_set():
        try:
            body = await render()
            await publish(replica, tier, body.decode("utf-8", "replace"))
        except Exception as e:
            logger.debug("[metrics-push] %s: %r", replica, e)
        try:
            await asyncio.wait_for(stop.wait(), timeout=interval_s())
        except asyncio.TimeoutError:
            pass


async def collect() -> dict[str, tuple[str, str]]:
    """{replica: (tier, exposition text)} for every replica publishing now."""
    r = get_redis()
    out: dict[str, tuple[str, str]] = {}
    keys = [k async for k in r.scan_iter(match=_PREFIX + "*", count=200)]
    if not keys:
        return out
    for key, val in zip(keys, await r.mget(keys)):
        if not val:
            continue  # expired between the scan and the read
        tier, _, text = val.partition("\n")
        out[key[len(_PREFIX):]] = (tier, text)
    return out


def merge(pushed: dict[str, tuple[str, str]], extra: str = "") -> bytes:
    """One valid exposition document out of many. Concatenating the texts would
    not be: every replica exports the same metric names, and a family's HELP/
    TYPE may appear only once. So each text is parsed and its samples regrouped
    under one family per name, with ``instance``/``tier`` added to every sample.
    ``extra`` (already-valid text with names of its own) is appended as is."""
    from prometheus_client.core import Metric
    from prometheus_client.exposition import generate_latest
    from prometheus_client.parser import text_string_to_metric_families
    from prometheus_client.samples import Sample

    families: dict[str, Metric] = {}
    for replica, (tier, text) in sorted(pushed.items()):
        try:
            parsed = list(text_string_to_metric_families(text))
        except Exception as e:  # one malformed replica must not blank the rest
            logger.warning("[metrics-push] unparseable metrics from %s: %r", replica, e)
            continue
        for fam in parsed:
            merged = families.get(fam.name)
            if merged is None:
                merged = families[fam.name] = Metric(fam.name, fam.documentation, fam.type)
            elif merged.type != fam.type:
                continue  # two replicas on different code disagree; keep the first
            for s in fam.samples:
                labels = {**s.labels, "instance": replica, "tier": tier}
                merged.samples.append(Sample(s.name, labels, s.value, s.timestamp, s.exemplar))

    class _Fixed:
        def collect(self):
            return list(families.values())

    body = generate_latest(_Fixed())  # type: ignore[arg-type]
    if extra:
        body += extra.encode() if isinstance(extra, str) else extra
    return body
