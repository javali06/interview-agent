"""Distributed locks — stop the same interview starting on two replicas.

When a candidate WebSocket lands, some replica must claim the token and start the
session. Without a lock, a fast reconnect racing the first connection could
have two replicas both decide "no one owns this yet" and each spin up a
brain — two interviews, one candidate. A short-lived ``SET NX PX`` lock makes
"claim this token" a single-winner operation across the fleet.

The lock is fenced by a random value and released with a compare-and-delete Lua
script, so a replica can only release ITS OWN lock — never one that already
expired and was re-acquired by someone else.
"""
from __future__ import annotations

import contextlib
import os
import uuid

from app.coordination.client import get_redis

# Only delete the lock if we still hold it (value matches our fence token).
_UNLOCK_LUA = """
if redis.call('get', KEYS[1]) == ARGV[1] then
    return redis.call('del', KEYS[1])
else
    return 0
end
"""


def session_lock_key(token: str) -> str:
    return f"lock:session:{token}"


async def acquire(key: str, *, ttl_ms: int = 10_000) -> str | None:
    """Try to take the lock. Returns a fence token on success (pass it back to
    ``release``), or None if someone else holds it."""
    fence = uuid.uuid4().hex
    ok = await get_redis().set(key, fence, nx=True, px=ttl_ms)
    return fence if ok else None


async def release(key: str, fence: str) -> bool:
    """Release only if we still hold it. Returns True if we actually deleted it."""
    if not fence:
        return False
    n = await get_redis().eval(_UNLOCK_LUA, 1, key, fence)
    return bool(n)


@contextlib.asynccontextmanager
async def session_lock(token: str, *, ttl_ms: int = 10_000):
    """`async with session_lock(token) as fence:` — fence is None if not acquired.

    Short TTL: this guards only the brief claim/start handshake, not the whole
    interview (that liveness is the registry TTL heartbeat). If a replica dies
    mid-claim the lock self-expires so the token isn't wedged.
    """
    key = session_lock_key(token)
    fence = await acquire(key, ttl_ms=ttl_ms)
    try:
        yield fence
    finally:
        if fence:
            await release(key, fence)
