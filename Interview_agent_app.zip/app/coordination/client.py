"""Redis connection for the coordination plane.

The coordination plane (registry + admission + locks + pub-sub) is what lets the
stateful session tier run more than one replica: it is the ONE shared,
sub-millisecond memory every replica reads and writes. Redis is therefore a
HARD dependency of the tiered deploy — there is no in-process fallback. A tier
that needs coordination but has no ``REDIS_URL`` refuses to start rather than
silently running as an island (which is exactly the single-replica trap we are
leaving behind).

Async client throughout: every caller lives on the session/gateway asyncio loop.
Values are text (``decode_responses=True``) — the registry stores small JSON
blobs and pub-sub carries JSON control messages; live audio never transits
Redis (it stays pinned to the owning replica).
"""
from __future__ import annotations

import os

from redis.asyncio import Redis

_client: Redis | None = None


def redis_url() -> str:
    url = (os.environ.get("REDIS_URL") or "").strip()
    if not url:
        raise RuntimeError(
            "REDIS_URL is not set. The coordination plane (session registry, "
            "admission, locks, pub-sub) requires Redis — the tiered deploy has "
            "no single-box fallback. Set REDIS_URL to your Azure Cache for Redis "
            "connection string (rediss://:<key>@<name>.redis.cache.windows.net:6380)."
        )
    return url


def get_redis() -> Redis:
    """Process-wide singleton async client. Built lazily so importing this
    package never opens a socket (safe for tooling / tests)."""
    global _client
    if _client is None:
        _client = Redis.from_url(redis_url(), decode_responses=True)
    return _client


def set_redis(client: Redis | None) -> None:
    """Inject a client (tests pass fakeredis.aioredis.FakeRedis). Passing None
    clears the singleton so the next get_redis() rebuilds from REDIS_URL."""
    global _client
    _client = client


async def ping() -> bool:
    """Liveness probe for /ready health checks."""
    try:
        return bool(await get_redis().ping())
    except Exception:
        return False


async def close_redis() -> None:
    global _client
    if _client is not None:
        try:
            await _client.aclose()
        except Exception:
            pass
        _client = None
