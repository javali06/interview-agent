"""Durable interview checkpoint — token → phase-boundary snapshot.

Why this exists: the interview "brain" (`InterviewSession`) lives ONLY in the
owning replica's process memory. If that runner is lost mid-interview — a
container/shard restart, a runner crash, or an orphan eviction — a reconnect
spawns a brand-new `InterviewSession`, which starts over at the cadence's first
phase (the greeting). To the candidate the interview appears to restart from
scratch on the same token.

This store keeps a tiny, durable snapshot in Redis so a fresh runner can RESUME
the current phase instead of re-greeting. Following the same philosophy as the
session registry ("Redis points to the truth; Postgres is the truth"), the blob
is deliberately small and TTL'd:

    {"v": 1, "phase_id": str, "turns": [<jsonable Turn>...],
     "resume_count": int, "ts": float}

The snapshot is written at each phase transition (state at phase-entry is just
one anchor turn + the ``<phase_changed>`` marker) and CLEARED only on a clean end
(natural wrap-up / browser-end / orphan-evict). It is NOT cleared on a crash —
its lingering presence is exactly what tells a fresh runner "this interview was
in progress and did not finish cleanly, resume it." The TTL is a backstop so a
truly abandoned key can't live forever.

Kept free of brain types on purpose: this layer stores/loads plain JSON-able
dicts. Turn (de)serialization lives in the brain
(``engine.brain.contracts.session_state``).
"""
from __future__ import annotations

import json
import logging
import os

from app.coordination.client import get_redis

logger = logging.getLogger(__name__)

# One key per interview. Short prefix keeps Redis memory tiny.
_KEY = "ckpt:interview:{token}"

# How long a checkpoint survives without being refreshed. Long enough to outlast
# the whole interview plus a generous reconnect window, so a resume works even if
# the candidate takes a while to come back. Cleared explicitly on clean end.
CHECKPOINT_TTL_S = int(os.environ.get("CHECKPOINT_TTL_S", str(2 * 60 * 60)))  # 2h


def _key(token: str) -> str:
    return _KEY.format(token=token)


async def save(token: str, payload: dict) -> None:
    """Write (overwrite) the checkpoint for ``token`` under a fresh TTL.

    Best-effort at the call site: callers wrap this so a Redis hiccup never
    breaks a live interview (a missed checkpoint only means that one phase can't
    be resumed, not that the interview fails)."""
    await get_redis().set(_key(token), json.dumps(payload), ex=CHECKPOINT_TTL_S)


async def load(token: str) -> dict | None:
    """Return the checkpoint blob for ``token``, or None if there is none.

    Returns None (not an error) on a malformed blob — a corrupt checkpoint
    should degrade to a fresh start, never crash bring-up."""
    raw = await get_redis().get(_key(token))
    if not raw:
        return None
    try:
        return json.loads(raw)
    except (ValueError, TypeError) as e:
        logger.warning("[checkpoint] token=%s malformed blob, ignoring: %s",
                       token[:8], e)
        return None


async def clear(token: str) -> None:
    """Drop the checkpoint on a clean end (wrap-up / browser-end / orphan-evict).

    Never call this on a crash path — the surviving key is what enables resume."""
    await get_redis().delete(_key(token))


async def interview_over(token: str, status: str | None) -> bool:
    """Is this interview finished for good, so a reopened link must be refused?

    ``cancelled`` always is. ``completed`` alone is NOT proof: the session
    runner's teardown writes it on EVERY exit, crashes included (so a crashed
    interview never sits ``in_progress`` forever). What separates "finished"
    from "crashed, resumable" is this checkpoint, cleared on a clean end and
    kept on a crash or eviction. ``completed`` + a checkpoint = resume it.
    """
    if status == "cancelled":
        return True
    if status != "completed":
        return False
    try:
        return await load(token) is None
    except Exception as e:
        # Can't tell. A resume needs this same Redis anyway, so refusing costs
        # nothing a working resume could have offered, and restarting a
        # finished interview is the bug this check exists to stop.
        logger.warning("[checkpoint] token=%s status check failed, treating "
                       "as over: %s", token[:8], e)
        return True
