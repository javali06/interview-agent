"""Text-tier HTTP service — the stateless request/response text interview.

Wraps the already-built, verified `TextTurnEngine` (engine/brain/text/) into a
small FastAPI `APIRouter` that turns a typed/chat interview into four stateless
HTTP calls. There is NOTHING in module memory between requests: every endpoint
builds a fresh engine + LLM clients + tracer from the signed state blob the
browser posts back (or from scratch for /start).

State model (user-directed — see engine/brain/text/state_codec.py header):
  - The BROWSER holds the live interview state between turns and re-posts it each
    turn as an HMAC-SIGNED blob. Redis stays cool: it is written ONLY at SYNC
    points (phase transition / explicit /save / end).
  - `pending_events` ride INSIDE the signed blob so no eval event is ever lost
    between syncs; they are flushed to the token's events.jsonl and cleared at
    sync points only.

Injectability (what makes this testable without Redis/blob): the state store and
the event sink are behind tiny protocols and resolved through module-level
factories the app (or a test) can override — see `configure()`.

Endpoints (mount under whatever prefix the app chooses):
  POST /text/{token}/start  -> {ai_text, phase, ended:false, state}
  POST /text/{token}/turn   -> {ai_text, phase, ended, transitioned, state}
  GET  /text/{token}/state  -> {state, transcript:[...]} | {started:false}
  POST /text/{token}/save   -> {ok:true, state}

The signed blob shape returned/accepted everywhere is
`{v, payload:{state, tracker, carry, pending_events}, sig}` (state_codec).
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from typing import Any, Callable, Optional, Protocol
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from engine.brain.cadence import question_types as qt
from engine.brain.contracts.session_state import CandidateProfile
from engine.brain.core.event_bus import EventBus
from engine.brain.observability import Tracer
from engine.brain.text.state_codec import sign_blob, verify_blob
from engine.brain.text.turn_engine import TextTurnEngine

logger = logging.getLogger(__name__)

router = APIRouter()

# Redis key + TTL for a synced blob. Only touched at sync points.
_STATE_KEY = "text:state:{token}"
_STATE_TTL_S = int(os.environ.get("TEXT_STATE_TTL_S", "7200"))


# ── injectable interfaces (Redis/blob in prod, in-memory fakes in tests) ─────
class StateStore(Protocol):
    """Durable get/set/delete by key. Only synced blobs live here."""

    async def get(self, key: str) -> Optional[dict]: ...
    async def set(self, key: str, value: dict, ttl_s: int) -> None: ...
    async def delete(self, key: str) -> None: ...


class EventSink(Protocol):
    """Flush a batch of already-jsonable event rows to the token's durable log."""

    async def append_events(self, token: str, events: list[dict]) -> None: ...


class RedisStateStore:
    """StateStore backed by the coordination-plane Redis (JSON-encoded values,
    TTL'd). Reuses app.coordination.client.get_redis so it shares the one shard
    client — but the router never imports it directly; it comes through the
    factory so tests can swap a dict."""

    async def get(self, key: str) -> Optional[dict]:
        import json
        from app.coordination.client import get_redis
        raw = await get_redis().get(key)
        return json.loads(raw) if raw else None

    async def set(self, key: str, value: dict, ttl_s: int) -> None:
        import json
        from app.coordination.client import get_redis
        await get_redis().set(key, json.dumps(value), ex=ttl_s)

    async def delete(self, key: str) -> None:
        from app.coordination.client import get_redis
        await get_redis().delete(key)


class BlobFileEventSink:
    """EventSink that appends event rows to sessions/{token}/events.jsonl, the
    SAME artifact a voice interview writes — so the eval pipeline reads a text
    interview identically. append_event_oneshot-style (open/append/close, no
    background thread): the rows are already full Tracer rows
    ({session_id, ts, kind, payload}) buffered off the engine's tracer."""

    async def append_events(self, token: str, events: list[dict]) -> None:
        if not events:
            return
        import json
        from app.paths import session_dir
        from engine.brain.observability.event_log import _json_fallback
        path = session_dir(token) / "events.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", buffering=1, encoding="utf-8") as fp:
            for row in events:
                fp.write(json.dumps(row, default=_json_fallback) + "\n")


# ── factory wiring — the app (or a test) overrides these ─────────────────────
_store_factory: Callable[[], StateStore] = RedisStateStore
_sink_factory: Callable[[], EventSink] = BlobFileEventSink


def configure(
    *,
    store_factory: Optional[Callable[[], StateStore]] = None,
    sink_factory: Optional[Callable[[], EventSink]] = None,
) -> None:
    """Override the store/sink factories (tests inject in-memory fakes; the app
    can inject a shared instance). Either arg may be omitted to keep its default."""
    global _store_factory, _sink_factory
    if store_factory is not None:
        _store_factory = store_factory
    if sink_factory is not None:
        _sink_factory = sink_factory


def get_store() -> StateStore:
    return _store_factory()


def get_sink() -> EventSink:
    return _sink_factory()


# ── HMAC secret (browser blob crosses a trust boundary) ──────────────────────
_DEV_SECRET = "dev-text-state-secret-change-me"


def _secret() -> str:
    s = os.environ.get("TEXT_STATE_SECRET") or os.environ.get("ADMIN_SECRET_KEY")
    if not s:
        logger.warning(
            "TEXT_STATE_SECRET/ADMIN_SECRET_KEY unset — using an INSECURE dev "
            "default for the text-state HMAC. Set one before any real deploy."
        )
        return _DEV_SECRET
    return s


# ── per-request construction (statelessness: nothing survives a request) ─────
def _session_uuid(token: str) -> uuid.UUID:
    """Stable session id for a token: the token itself when it's a UUID (so the
    events.jsonl / Langfuse session id == the interview token, as voice does),
    else a deterministic uuid5 so a resume keeps the SAME id across requests."""
    try:
        return uuid.UUID(str(token))
    except (ValueError, AttributeError, TypeError):
        return uuid.uuid5(uuid.NAMESPACE_URL, f"text-interview:{token}")


class _BufferingEventLog:
    """A JsonlEventLog-shaped sink that COLLECTS the tracer's rows in memory
    instead of writing a file. The Tracer only calls `.write(record)`; the rest
    of the interface is here for shape-compatibility. Its `.records` are the
    events emitted during THIS request — appended to the blob's pending_events
    and flushed to the durable sink at sync points."""

    def __init__(self) -> None:
        self.records: list[dict] = []

    def write(self, record: dict) -> None:
        self.records.append(record)

    def flush(self) -> None:  # pragma: no cover — nothing buffered off-thread
        pass

    def close(self) -> None:  # pragma: no cover
        pass

    @property
    def path(self):  # pragma: no cover — never touched (no file)
        return None


def _make_tracer(token: str) -> tuple[Tracer, _BufferingEventLog]:
    log = _BufferingEventLog()
    tracer = Tracer(session_id=_session_uuid(token), event_log=log, bus=EventBus())
    return tracer, log


def _provider_extra(order: list[str], base_url: str) -> dict:
    """OpenRouter provider-routing hint: lock to the listed providers with no
    fallbacks (mirrors interview_session) so the env order is authoritative."""
    if order and "openrouter" in base_url:
        return {"provider": {"order": list(order), "allow_fallbacks": False}}
    return {}


def _order(env_name: str) -> list[str]:
    return [p.strip() for p in os.environ.get(env_name, "").split(",") if p.strip()]


def _build_llms() -> tuple[Any, Any, str, str]:
    """Build the slow + fast LLMClients from env, exactly as the interview
    runner does: OpenRouter base + provider order when OPENROUTER_API_KEY is set,
    else Groq. Returns (slow_llm, fast_llm, slow_model, fast_model). fast may be
    the SAME client as slow when their routing is identical."""
    from engine.brain.llm import LLMClient

    or_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
    groq_key = os.environ.get("GROQ_API_KEY", "").strip()
    if or_key:
        base_url, api_key = "https://openrouter.ai/api/v1", or_key
    else:
        base_url, api_key = "https://api.groq.com/openai/v1", groq_key

    slow_model = os.environ.get("SLOW_MODEL", "openai/gpt-oss-120b")
    fast_model = os.environ.get("FAST_MODEL", "meta-llama/llama-3.1-8b-instruct")
    slow_extra = _provider_extra(_order("SLOW_PROVIDER_ORDER"), base_url)
    fast_extra = _provider_extra(_order("FAST_PROVIDER_ORDER"), base_url)

    slow = LLMClient(
        api_key=api_key, base_url=base_url,
        default_extra_body=slow_extra or None, tier="slow",
    )
    if fast_extra != slow_extra or fast_model != slow_model:
        fast = LLMClient(
            api_key=api_key, base_url=base_url,
            default_extra_body=fast_extra or None, tier="fast",
        )
    else:
        fast = slow
    return slow, fast, slow_model, fast_model


def _max_follow_ups() -> int:
    """`policy.max_follow_ups_per_question` — how many times a question may be
    re-asked before the engine gives up and moves on. Same precedence as the
    voice runner (system_config.yaml < MAX_FOLLOW_UPS_PER_QUESTION env), so one
    knob tunes both modalities. Read per engine build rather than cached at
    import: the file is tiny, this is once per turn (not a hot loop), and a
    config change then lands on the next turn instead of needing a restart.
    Falls back to 1 — the previous hardcoded value — if the config is
    unreadable, so a bad edit degrades to today's behaviour instead of 500ing
    the interview."""
    env = os.environ.get("MAX_FOLLOW_UPS_PER_QUESTION", "").strip()
    if env:
        try:
            return max(0, int(env))
        except ValueError:
            logger.warning("MAX_FOLLOW_UPS_PER_QUESTION=%r is not an int — ignoring", env)
    try:
        from engine.brain.config import load_system_config
        pol = (load_system_config().get("policy") or {})
        return max(0, int(pol.get("max_follow_ups_per_question", 1)))
    except Exception as e:  # missing/malformed config must never break a turn
        logger.warning("could not read max_follow_ups_per_question (%s) — using 1", e)
        return 1


def _load_plan(token: str):
    """Load + validate the token's cadence.yaml (synchronous parse — never the
    LLM generator). 404 if absent/unparseable."""
    from app.paths import session_dir
    from engine.brain.cadence import load_cadence_yaml
    p = session_dir(token) / "cadence.yaml"
    if not p.exists():
        raise HTTPException(status_code=404, detail="no cadence for this token")
    try:
        return load_cadence_yaml(p)
    except Exception as e:  # malformed YAML / schema violation
        raise HTTPException(status_code=404, detail=f"cadence load failed: {e}")


def _load_resume_summary(token: str) -> str:
    """Read the resume artifact the schedule-time worker precomputed for this
    token (sessions/{token}/resume/summary.txt → parsed.txt truncated → ""),
    mirroring deploy.azure_app._load_precomputed_resume's file sources. NEVER
    parses or calls the LLM."""
    from app.paths import session_dir
    rdir = session_dir(token) / "resume"
    cap = int(os.environ.get("RESUME_FALLBACK_CHARS", "4000"))
    for name, truncate in (("summary.txt", False), ("parsed.txt", True)):
        fp = rdir / name
        try:
            if fp.is_file():
                txt = fp.read_text(encoding="utf-8", errors="ignore").strip()
                if txt:
                    return txt[:cap] if truncate else txt
        except Exception:
            pass
    return ""


def _load_candidate(token: str) -> CandidateProfile:
    """Candidate profile from the same sources voice uses: db.get(token) for
    name/role + the precomputed resume summary file."""
    name = os.environ.get("DEFAULT_CANDIDATE_NAME", "Candidate")
    role = "Engineer"
    try:
        from app import db
        row = db.get(token)
        if row:
            name = (row.get("candidate_name") or name)
            role = (row.get("role") or role)
    except Exception as e:  # DB optional in some contexts — fail soft
        logger.debug("[text] db.get(%s) failed: %s", token, e)
    return CandidateProfile(
        name=name, role=role, resume_summary=_load_resume_summary(token),
    )


def _build_engine(token: str, restore: Optional[dict]) -> tuple[TextTurnEngine, _BufferingEventLog]:
    """Construct a FRESH engine per request. `restore=None` opens a new
    interview (emits SESSION_STARTED); a restore payload resumes without
    re-emitting it. Statelessness: this is the ONLY place an engine is made and
    it is discarded when the request returns."""
    plan = _load_plan(token)
    candidate = _load_candidate(token)
    tracer, log = _make_tracer(token)
    slow, fast, slow_model, fast_model = _build_llms()
    eng = TextTurnEngine(
        plan=plan, candidate=candidate, tracer=tracer,
        slow_llm=slow, fast_llm=fast,
        slow_model=slow_model, fast_model=fast_model,
        max_follow_ups=_max_follow_ups(), restore=restore,
    )
    return eng, log


def _signed(payload_core: dict, pending: list[dict]) -> dict:
    """Sign a full blob = {...engine.snapshot()..., pending_events:[...]}."""
    return sign_blob({**payload_core, "pending_events": list(pending)}, _secret())


async def _mark_started(token: str) -> None:
    """Flip the DB row ready → in_progress (with started_at) when a text interview
    begins — the stateless tier's equivalent of the voice lifecycle's
    SESSION_STARTED handler (engine.orchestrator.scheduled_session). Only advances
    from 'ready' so a resume/replay never resurrects a completed interview.
    Best-effort: never fails the candidate's /start."""
    try:
        import asyncio as _asyncio

        from app import db

        row = await _asyncio.to_thread(db.get, token)
        if row and row.get("status") == "ready":
            await _asyncio.to_thread(
                db.update, token, status="in_progress", started_at=db.now_iso()
            )
            logger.info("[text %s] → in_progress", token[:8])
    except Exception as e:
        logger.warning("[text %s] mark-started skipped: %s", token[:8], e)


async def _finalize_on_end(token: str) -> None:
    """On interview end: flip the DB row to 'completed' (with ended_at), mirror
    artifacts to Blob, and enqueue the eval-v2 job — the stateless tier's
    equivalent of the voice SESSION_ENDED lifecycle. The status flip is done in
    its OWN try so a missing queue/blob (local/dev/test) can't leave the row stuck
    at 'in_progress'. Each step is best-effort and never fails the candidate turn."""
    import asyncio as _asyncio

    # 1. DB status → completed (independent of blob/queue availability).
    try:
        from app import db

        await _asyncio.to_thread(
            db.update, token, status="completed", ended_at=db.now_iso()
        )
        logger.info("[text %s] → completed", token[:8])
    except Exception as e:
        logger.warning("[text %s] mark-completed skipped: %s", token[:8], e)

    # 2. Mirror artifacts + enqueue scoring (same eval-v2 job voice enqueues).
    try:
        from app import blob_store
        from app.jobs import jobs as _jobs

        await _asyncio.to_thread(blob_store.upload_session_artifacts, token)
        job_id = await _jobs.enqueue(_jobs.EVAL_V2, {"token": token}, token=token)
        logger.info("[text %s] eval_v2 enqueued job=%s", token[:8], (job_id or "")[:8])
    except Exception as e:  # queue/blob optional outside the cloud tiers
        logger.warning("[text %s] eval finalize skipped: %s", token[:8], e)


# Durable copy of the synced state, written on an explicit Save only. WHY: the
# Redis copy carries a TTL (_STATE_TTL_S, 2h by default), so a candidate who
# clicks "Save & finish later" and returns tomorrow would find Redis empty and
# fall back to whatever their browser still had — i.e. nothing at all on another
# device. Blob has no TTL, so a Save survives arbitrarily long. Ordinary
# phase-transition syncs stay Redis-only, which keeps blob writes rare.
_STATE_BLOB_NAME = "{token}/text_state.json"


def _mirror_state_to_blob(token: str, blob: dict) -> None:
    """Best-effort durable copy of a signed state blob. Never raises — losing
    the mirror must not fail the candidate's Save (Redis already has it)."""
    try:
        import io
        import json as _json
        from app import blob_store
        raw = _json.dumps(blob).encode("utf-8")
        blob_store.upload_fileobj(
            io.BytesIO(raw), _STATE_BLOB_NAME.format(token=token),
        )
    except Exception as e:  # pragma: no cover — optional outside the cloud tiers
        logger.warning("[text %s] state blob mirror failed: %s", token[:8], e)


def _load_state_from_blob(token: str) -> Optional[dict]:
    """The last Save's signed blob, or None. Used when the Redis copy expired."""
    try:
        import json as _json
        from app import blob_store
        raw = blob_store.download_bytes(_STATE_BLOB_NAME.format(token=token))
        if not raw:
            return None
        out = _json.loads(raw.decode("utf-8"))
        return out if isinstance(out, dict) else None
    except Exception as e:  # pragma: no cover
        logger.warning("[text %s] state blob read failed: %s", token[:8], e)
        return None


def _verified_or_401(signed: Any) -> dict:
    """Verify the posted blob; a None (tamper/corruption) is a hard refusal."""
    payload = verify_blob(signed, _secret())
    if payload is None:
        raise HTTPException(status_code=401, detail="state blob failed verification")
    return payload


def _question_for_current(eng: TextTurnEngine, token: str) -> Optional[dict]:
    """When the engine's CURRENT phase is a written-response phase, the config the
    client needs to render the question it is ON right now. Else None → the normal
    chat composer.

    A phase holds N written questions of one type, so this resolves the CURRENT
    pool question's own config over the phase defaults and reports where the
    candidate is (`question_id` / `question_index` / `question_total`) — the
    client keys its composer on `question_id` so each question starts with a clean
    textarea and its own countdown.

    The AI turn text is the prompt; the counter + countdown are client-enforced
    (that's what keeps this tier stateless). Type-specific MATERIAL travels here
    verbatim — the source passage, the asset URL — never through the LLM, so a
    translation's source text can't be paraphrased on the way to the candidate."""
    try:
        phase = eng.tracker.current_phase()
        phase_wr = getattr(phase, "written_response", None)
    except Exception:
        return None
    if phase_wr is None:
        return None

    # The question on the table (None once the pool is drained — the phase is
    # about to advance, so there is nothing to render).
    item = eng.tracker.peek_next_question()
    if item is None:
        return None
    wr = phase_wr.resolved_for(item.written_response)

    total = len(phase.question_pool)
    remaining = eng.tracker.questions_remaining()   # includes the current one
    out: dict = {
        "question_type": wr.question_type,
        "question_id": item.id,
        "question_index": max(1, total - remaining + 1),
        "question_total": total,
        # One shared counter for every type: count characters, or words for a
        # legacy essay phase authored before char limits existed.
        "limit_kind": wr.limit_kind,
        "limit": wr.limit_value,
        "time_limit_s": wr.time_limit_s,
    }
    if wr.source_text:
        out["source_text"] = wr.source_text
    for field in ("source_language", "target_language"):
        code = getattr(wr, field, None)
        if code:
            out[field] = code
            out[f"{field}_label"] = qt.language_label(code)
    asset = wr.asset_name
    if asset:
        out["asset_kind"] = "audio" if wr.audio_asset else "image"
        out["asset_url"] = (
            f"/api/sessions/{token}/phase-asset/{quote(asset)}"
        )
    return out


def _legacy_essay(question: Optional[dict]) -> Optional[dict]:
    """The pre-Add-Phase `essay` block ({word_limit, time_limit_s}) for a client
    still running the old cached bundle. Only word-limited (i.e. legacy-shaped)
    phases can be represented; anything newer returns None, so an old bundle
    falls back to the plain chat composer instead of rendering a wrong limit."""
    if not question or question.get("limit_kind") != "words":
        return None
    return {"word_limit": question["limit"], "time_limit_s": question.get("time_limit_s")}


# ── streaming (NDJSON: {delta} lines while the AI reply generates, then a final
#    {done, ...} line carrying the metadata + signed state blob) ────────────────
_SENTINEL = object()
_NDJSON = "application/x-ndjson"


def _nd(obj: dict) -> str:
    return json.dumps(obj) + "\n"


async def _pump(q: "asyncio.Queue") -> Any:
    """Yield batched {delta} NDJSON lines from the token queue until the sentinel.
    Batches whatever tokens are immediately available into one line so we don't
    emit one HTTP chunk per character."""
    while True:
        item = await q.get()
        if item is _SENTINEL:
            return
        buf = [item]
        while not q.empty():
            nxt = q.get_nowait()
            if nxt is _SENTINEL:
                q.put_nowait(_SENTINEL)  # re-queue so the outer await sees it
                break
            buf.append(nxt)
        yield _nd({"delta": "".join(buf)})


# ── request bodies ───────────────────────────────────────────────────────────
class TurnBody(BaseModel):
    answer: str
    state: dict


class DraftBody(BaseModel):
    """The candidate's UNSUBMITTED work on the written question they're on.

    Kept out of the engine snapshot on purpose: a snapshot describes turns that
    HAPPENED, and this hasn't been submitted yet. It rides alongside so an
    explicit Save can make it durable (Redis + Blob) without pretending a turn
    occurred. `remaining_s` is the frozen countdown, so resuming charges the
    candidate only the time they actually spent."""
    question_id: str
    text: str = ""
    remaining_s: int | None = None
    # Client wall-clock at capture. Only used to pick the fresher of the server
    # copy vs. the browser's localStorage copy on resume.
    ts: int | None = None


class SaveBody(BaseModel):
    state: dict
    draft: DraftBody | None = None


# ── endpoints ────────────────────────────────────────────────────────────────
@router.post("/text/{token}/start")
async def start(token: str):
    """Open a fresh text interview: load the (timed=false) cadence + candidate,
    build a fresh engine, produce the AI's opener, and return the first signed
    blob (carrying the just-emitted session_started + question_dispatched +
    ai_utterance as pending_events). No store write here."""
    # Gate BEFORE constructing the engine so a timed cadence never emits
    # session_started: a text interview is question-driven (untimed).
    if _load_plan(token).timed:
        raise HTTPException(
            status_code=400,
            detail="cadence is timed (voice); a text interview requires timed=false",
        )
    eng, log = _build_engine(token, restore=None)

    async def gen():
        q: asyncio.Queue = asyncio.Queue()
        holder: dict = {}

        async def _run():
            try:
                holder["report"] = await eng.open_turn(on_delta=lambda ch: q.put_nowait(ch))
            except Exception as e:  # noqa: BLE001
                holder["error"] = e
            finally:
                q.put_nowait(_SENTINEL)

        task = asyncio.create_task(_run())
        async for line in _pump(q):
            yield line
        await task
        if "error" in holder:
            logger.exception("[text %s] start failed", token[:8], exc_info=holder["error"])
            yield _nd({"error": "start failed"})
            return
        report = holder["report"]
        blob = _signed(eng.snapshot(), log.records)  # opener's events ride as pending
        await _mark_started(token)  # ready → in_progress (voice-lifecycle equivalent)
        question = _question_for_current(eng, token)
        yield _nd({
            "done": True, "ai_text": report["ai_text"], "phase": eng.phase,
            "ended": False, "question": question,
            "essay": _legacy_essay(question), "state": blob,
        })

    return StreamingResponse(gen(), media_type=_NDJSON)


@router.post("/text/{token}/turn")
async def turn(
    token: str,
    body: TurnBody,
    store: StateStore = Depends(get_store),
    sink: EventSink = Depends(get_sink),
):
    """One candidate turn. Verify → rehydrate → run_one_turn → accumulate events.
    SYNC (Redis write + event flush) happens ONLY on a phase transition or the
    end; a plain turn writes nothing (Redis stays cool) and just carries the
    grown pending_events back in the returned blob."""
    payload = _verified_or_401(body.state)
    prior_pending = list(payload.pop("pending_events", []) or [])
    eng, log = _build_engine(token, restore=payload)  # {state, tracker, carry}
    before_phase = eng.phase

    async def gen():
        q: asyncio.Queue = asyncio.Queue()
        holder: dict = {}

        async def _run():
            try:
                holder["report"] = await eng.run_one_turn(
                    body.answer, on_delta=lambda ch: q.put_nowait(ch),
                )
            except Exception as e:  # noqa: BLE001
                holder["error"] = e
            finally:
                q.put_nowait(_SENTINEL)

        task = asyncio.create_task(_run())
        async for line in _pump(q):
            yield line
        await task
        if "error" in holder:
            logger.exception("[text %s] turn failed", token[:8], exc_info=holder["error"])
            yield _nd({"error": "turn failed"})
            return

        report = holder["report"]
        after_phase = eng.phase
        ended = bool(report.get("ended"))
        transitioned = after_phase != before_phase
        pending = prior_pending + list(log.records)

        key = _STATE_KEY.format(token=token)
        if transitioned or ended:
            # SYNC point: durably persist the state AND flush every buffered event
            # to the token's events.jsonl, then CLEAR pending_events in the blob.
            blob = _signed(eng.snapshot(), [])
            await store.set(key, blob, _STATE_TTL_S)
            await sink.append_events(token, pending)
            if ended:
                # Events durable → kick off scoring (same eval-v2 job as voice).
                await _finalize_on_end(token)
        else:
            # Non-sync: no store write, no flush — the events ride in the blob.
            blob = _signed(eng.snapshot(), pending)

        question = _question_for_current(eng, token)
        yield _nd({
            "done": True, "ai_text": report["ai_text"], "phase": after_phase,
            "ended": ended, "transitioned": transitioned,
            "question": question, "essay": _legacy_essay(question), "state": blob,
        })

    return StreamingResponse(gen(), media_type=_NDJSON)


@router.get("/text/{token}/state")
async def get_state(token: str, store: StateStore = Depends(get_store)):
    """Resume: return the last SYNCED signed blob + a human transcript, or
    {started:false} if this token has never hit a sync point."""
    key = _STATE_KEY.format(token=token)
    blob = await store.get(key)
    if not blob:
        # Redis carries a TTL, so a "finish later" that spans more than
        # _STATE_TTL_S lands here. The last explicit Save was mirrored to Blob
        # with no expiry, so fall back to it rather than telling the candidate
        # their interview never started.
        blob = await asyncio.to_thread(_load_state_from_blob, token)
        if blob:
            logger.info("[text %s] resumed from the Blob mirror (Redis expired)",
                        token[:8])
            await store.set(key, blob, _STATE_TTL_S)   # re-warm the hot copy
    if not blob:
        return {"started": False}
    payload = verify_blob(blob, _secret()) or {}
    # Full display transcript (never trimmed) — carries the WHOLE conversation,
    # unlike state.turns (the LLM working set, trimmed at phase boundaries). This
    # is what the candidate reloads on resume, so it must be complete.
    transcript = payload.get("transcript") or []
    # Surface whether the interview already ended so a reopened finished link
    # shows a Done screen instead of offering to "resume" a completed interview.
    ended = bool((payload.get("carry") or {}).get("ended"))

    # The question the candidate is ON, so a reopened tab re-renders the
    # written-response panel instead of dropping them into the chat composer
    # (the panel is what /start and /turn return; without it here, resuming
    # mid-written-question loses the textarea, the limit and the countdown).
    # Best-effort: a resume must never 500 because the plan moved under us.
    question = None
    if not ended:
        try:
            eng, _ = _build_engine(token, restore=payload)
            question = _question_for_current(eng, token)
        except Exception as e:
            logger.warning("[text] /state could not resolve the current question: %s", e)
    return {
        "state": blob, "transcript": transcript, "ended": ended,
        "question": question, "essay": _legacy_essay(question),
        # The unsubmitted textarea contents + frozen countdown from the last
        # Save, so a resume on ANY device puts the candidate back where they
        # were. The client prefers whichever of this and its localStorage copy
        # is fresher (see `ts`).
        "draft": payload.get("draft") or None,
    }


@router.post("/text/{token}/save")
async def save(
    token: str,
    body: SaveBody,
    store: StateStore = Depends(get_store),
    sink: EventSink = Depends(get_sink),
):
    """Explicit sync: verify → fold in the in-progress draft → persist to Redis
    AND mirror to Blob → flush pending_events to events.jsonl → clear them →
    return the re-signed (now empty-pending) blob.

    The DRAFT is why this is the durable sync point. The client also autosaves it
    to localStorage every keystroke (instant, survives a refresh or crash on the
    same browser), but that is device-bound; folding it into the SIGNED payload
    here is what lets the candidate resume on another machine. It has to be
    merged server-side because the payload is HMAC-signed — a browser can't add a
    field to it without failing verification, which is exactly the property we
    want."""
    payload = _verified_or_401(body.state)
    pending = list(payload.pop("pending_events", []) or [])
    if body.draft is not None:
        payload["draft"] = body.draft.model_dump()
    else:
        # An explicit Save with no draft means "nothing typed" — drop any stale
        # one rather than resurrecting it on the next resume.
        payload.pop("draft", None)
    blob = _signed(payload, [])
    key = _STATE_KEY.format(token=token)
    await store.set(key, blob, _STATE_TTL_S)
    # Blob is the no-TTL copy; Redis is the hot one. Off-thread so a slow storage
    # account can't stall the request loop.
    await asyncio.to_thread(_mirror_state_to_blob, token, blob)
    await sink.append_events(token, pending)
    return {"ok": True, "state": blob}
