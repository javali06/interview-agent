"""Shared constants: values that more than one module must agree on.

Only values used across files belong here. A constant one module uses on its
own stays in that module, next to the code that gives it meaning.

No imports, on purpose: anything can import this without pulling in the web
app, the database or each other. `question_pools.py` relies on that — the
built-in pool tooling imports it standalone.
"""

# The team key meaning "every team". A real seeded row, not a NULL — see the
# note at the top of the RBAC models in db/models.py.
GLOBAL_TEAM = "*"


# ── Question pools ───────────────────────────────────────────────────────────

# The state a pool is in. Workflow states are DERIVED from the approval ledger,
# never stored (see app/approval_service.py). BUILTIN is a pool shipped in the
# image: read-only, with no workflow at all.
POOL_DRAFT = "draft"
POOL_PENDING = "pending"
POOL_PUBLISHED = "published"
POOL_BUILTIN = "builtin"

# Where a pool summary came from — QuestionPool.summary(source=...).
POOL_SOURCE_CUSTOM = "custom"
POOL_SOURCE_BUILTIN = "builtin"
POOL_SOURCE_DRAFT = "draft"

# Pool-level actions in the append-only `pool_approvals` ledger.
ACTION_SUBMITTED = "submitted"
ACTION_APPROVED = "approved"
ACTION_RETURNED = "returned"
ACTION_PUBLISHED = "published"
ACTION_WITHDRAWN = "withdrawn"

# Per-question verdicts in `pool_question_reviews`. Deliberately a separate
# vocabulary from the ledger actions above: a QUESTION is approved or rejected,
# a POOL is submitted/approved/returned, and conflating the two is how a status
# ends up describing the wrong grain.
QUESTION_APPROVED = "approved"
QUESTION_REJECTED = "rejected"
