"""Registry-aware WebSocket reverse-proxy (gateway → owning session shard).

Front Door sends every /ws/* socket to the gateway. The gateway can't run the
interview (it's stateless), so it forwards the socket to the ONE session shard
that owns the token:

  - token already in the registry → proxy to that shard's FQDN (a reconnect
    reaches the same live interview).
  - new candidate token           → place on the least-loaded shard; that shard
    claims the token on connect (session_lifecycle.claim), so the next lookup
    routes here too.

This is the practical ACA equivalent of "Front Door reads the registry" — the
registry read + proxy live in the gateway, which CAN reach a specific replica by
its shard FQDN over the internal network.
"""
from __future__ import annotations

import asyncio
import json
import logging
from urllib.parse import urlencode

import websockets
from fastapi import WebSocket

from app.coordination import admission, registry
from app.session_tier import identity

logger = logging.getLogger("gateway.ws_proxy")

async def resolve_target(token: str | None) -> str:
    """Return the internal FQDN of the shard that owns (or will own) `token`."""
    if token:
        loc = await registry.get(token)
        # A pool replica has no address (fqdn ""): its interviews are LiveKit
        # ones. A WebSocket for one means the page is falling back — place it on
        # an addressable shard, which takes over once the pool replica hands
        # the interview off.
        if loc is not None and loc.fqdn:
            return loc.fqdn
    # New candidate token (or missing) — place on the least-loaded shard.
    shard = await admission.least_loaded_shard(identity.all_shards())
    return identity.fqdn_for(shard)


async def proxy(client: WebSocket, session_id: str, token: str | None = None,
                client_id: str | None = None) -> None:
    await client.accept()
    target = await resolve_target(token)
    # client_id is how the shard tells a refresh (same tab) from the link opened
    # in a second tab — it must survive this hop.
    params = {k: v for k, v in (("token", token), ("client", client_id)) if v}
    q = f"?{urlencode(params)}" if params else ""
    uri = f"ws://{target}/ws/candidate/{session_id}{q}"

    try:
        # max_size=None: audio frames can be large; don't cap.
        async with websockets.connect(uri, max_size=None, open_timeout=10) as upstream:
            logger.info("[gw-proxy] candidate token=%s -> %s",
                        (token or "-")[:8], target)
            await _pump(client, upstream, token)
    except Exception as e:
        logger.warning("[gw-proxy] upstream %s failed: %s", uri, e)
        try:
            await client.close(code=1011)
        except Exception:
            pass


async def _pump(client: WebSocket, upstream, token: str | None = None) -> None:
    """Full-duplex relay between the client (FastAPI) and the shard (websockets)."""

    async def client_to_shard() -> None:
        try:
            while True:
                msg = await client.receive()
                if msg.get("type") == "websocket.disconnect":
                    break
                data = msg.get("bytes")
                if data is not None:
                    await upstream.send(data)
                    continue
                text = msg.get("text")
                if text is not None:
                    await upstream.send(text)
        except Exception:
            pass
        finally:
            try:
                await upstream.close()
            except Exception:
                pass

    async def shard_to_client() -> None:
        try:
            async for data in upstream:
                if isinstance(data, (bytes, bytearray)):
                    await client.send_bytes(bytes(data))
                else:
                    # Tripwire: an AI audio_start carries the interview token. If it
                    # doesn't match THIS connection's token, another interview's
                    # audio reached this socket — log it loudly (the browser also
                    # drops it). Relay is unchanged; this only observes.
                    if token and "audio_start" in data:
                        try:
                            _m = json.loads(data)
                            _sid = _m.get("session_id")
                            if (_m.get("type") == "audio_start" and _sid
                                    and _sid != token):
                                logger.warning(
                                    "[gw-proxy] AUDIO MISMATCH on token=%s: foreign "
                                    "session_id=%s reached this socket",
                                    token[:8], str(_sid)[:8],
                                )
                        except Exception:
                            pass
                    await client.send_text(data)
        except Exception:
            pass
        finally:
            try:
                await client.close()
            except Exception:
                pass

    await asyncio.gather(client_to_shard(), shard_to_client())
