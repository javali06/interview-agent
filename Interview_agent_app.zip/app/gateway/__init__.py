"""Gateway tier — the stateless front.

Serves the SPA + every request/response HTTP call (reusing app.main's routes),
and reverse-proxies /ws/* to the owning session shard via the Redis registry
(ws_proxy). Keeps nothing in local memory between requests, so it scales purely
on traffic.
"""
from __future__ import annotations

from app.gateway import ws_proxy

__all__ = ["ws_proxy"]
