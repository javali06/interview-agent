"""Best-effort mirror of per-interview artifacts to Azure Blob Storage.

The container disk (/home) is the working store; Blob is the durable copy so
artifacts survive container recycles. AUDIO IS INTENTIONALLY NOT UPLOADED — we
push the lightweight record per interview: events.jsonl, evaluation.json, and
the uploaded resume / JD, laid out under ``<token>/`` in the container.

Gated on BLOB_ENABLED + AZURE_STORAGE_CONNECTION_STRING (App Settings). Any
missing config or failure is logged and swallowed — Blob is a side mirror, never
on the interview's critical path.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)


def enabled() -> bool:
    return (
        os.environ.get("BLOB_ENABLED", "").strip().lower() in ("1", "true", "yes")
        and bool(os.environ.get("AZURE_STORAGE_CONNECTION_STRING", "").strip())
    )


_container = None


def _get_container():
    """Lazily build (and cache) the container client. Creates the container if
    it doesn't exist. Returns None if blob isn't configured / SDK missing."""
    global _container
    if _container is not None:
        return _container
    if not enabled():
        return None
    try:
        from azure.storage.blob import BlobServiceClient
        conn = os.environ["AZURE_STORAGE_CONNECTION_STRING"]
        name = os.environ.get("BLOB_CONTAINER", "sessions")
        cc = BlobServiceClient.from_connection_string(conn).get_container_client(name)
        try:
            cc.create_container()
        except Exception:
            pass  # already exists — fine
        _container = cc
        return cc
    except Exception as e:
        logger.warning("[blob] client init failed (uploads disabled this run): %s", e)
        return None


def _disk_fallback_path(blob_name: str) -> Path | None:
    """Local path under SESSIONS_DIR mirroring ``blob_name``. Used as a fallback
    when Blob is DISABLED (e.g. local dev with BLOB_ENABLED=0) so recordings and
    other artifacts still persist + play back. SESSIONS_DIR is a shared volume
    across tiers, so the gateway writes here and the admin download reads the
    same file. In cloud (blob enabled) this path is never taken."""
    try:
        from app.paths import SESSIONS_DIR
        return Path(SESSIONS_DIR) / blob_name
    except Exception:
        return None


def list_blobs(prefix: str) -> list[str]:
    """Every blob name under ``prefix`` (sorted). Mirrors the disk fallback so a
    BLOB_ENABLED=0 dev box behaves the same as cloud — otherwise a feature that
    LISTS what the user has saved (question pools) would silently show nothing
    locally while working in cloud. Best-effort: returns [] on any failure, so a
    storage hiccup degrades to "no saved items" rather than a 500."""
    cc = _get_container()
    if cc is not None:
        try:
            return sorted(b.name for b in cc.list_blobs(name_starts_with=prefix))
        except Exception as e:
            logger.warning("[blob] list %r failed: %s", prefix, e)
            return []
    # Blob disabled → enumerate the mirrored disk tree under SESSIONS_DIR.
    root = _disk_fallback_path("")
    if root is None:
        return []
    base = root / prefix
    try:
        if not base.is_dir():
            return []
        return sorted(
            str(f.relative_to(root)) for f in base.rglob("*") if f.is_file()
        )
    except Exception as e:
        logger.warning("[blob] disk list %r failed: %s", prefix, e)
        return []


def delete_blob(blob_name: str) -> bool:
    """Delete one blob (or its disk-fallback file). True when it's gone."""
    cc = _get_container()
    if cc is not None:
        try:
            cc.delete_blob(blob_name)
            return True
        except Exception as e:
            logger.warning("[blob] delete %r failed: %s", blob_name, e)
            return False
    p = _disk_fallback_path(blob_name)
    try:
        if p is not None and p.is_file():
            p.unlink()
        return True
    except Exception as e:
        logger.warning("[blob] disk delete %r failed: %s", blob_name, e)
        return False


def upload_file(local_path: str | Path, blob_name: str) -> bool:
    """Upload one file to ``blob_name`` (overwrites). Best-effort."""
    cc = _get_container()
    if cc is None:
        return False
    try:
        p = Path(local_path)
        if not p.is_file():
            return False
        with p.open("rb") as f:
            cc.upload_blob(name=blob_name, data=f, overwrite=True)
        logger.info("[blob] uploaded %s (%d bytes)", blob_name, p.stat().st_size)
        return True
    except Exception as e:
        logger.warning("[blob] upload failed for %s: %s", blob_name, e)
        return False


def upload_fileobj(fileobj, blob_name: str) -> bool:
    """Upload an open binary file-like object to ``blob_name`` (overwrites).

    Used by request handlers that receive a multipart upload (e.g. recording
    webm tracks, chat file shares, phase assets) and want to stream it straight
    to blob without staging on disk. Best-effort — returns False if the upload
    fails.

    Blob DISABLED → the same disk fallback append_chunk uses (the shared
    SESSIONS_DIR volume), so uploads a later request must read back — a phase's
    audio/image asset, for instance — still work locally / with BLOB_ENABLED=0.
    download_bytes/blob_size/download_stream already read that path."""
    cc = _get_container()
    if cc is None:
        p = _disk_fallback_path(blob_name)
        if p is None:
            return False
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            with p.open("wb") as out:
                while True:
                    chunk = fileobj.read(1 << 16)
                    if not chunk:
                        break
                    out.write(chunk)
            logger.info("[blob] disabled — wrote %s to disk fallback", blob_name)
            return True
        except Exception as e:
            logger.warning("[blob] disk-fallback write failed for %s: %s", blob_name, e)
            return False
    try:
        cc.upload_blob(name=blob_name, data=fileobj, overwrite=True)
        logger.info("[blob] uploaded %s (fileobj)", blob_name)
        return True
    except Exception as e:
        logger.warning("[blob] upload (fileobj) failed for %s: %s", blob_name, e)
        return False


def append_chunk(blob_name: str, data: bytes, create: bool = False) -> bool:
    """Append `data` to an append-blob (used to stream recording webm chunks
    incrementally). create=True (re)creates the append blob first — call it on
    the FIRST chunk of a recording. Concatenated MediaRecorder chunks form a
    valid webm, so appending them in order reconstructs the full track even if
    the candidate disconnects mid-interview. Best-effort."""
    cc = _get_container()
    if cc is None:
        # Disk fallback (blob disabled) — append to the shared sessions volume so
        # recordings still persist + play back locally. create=True truncates.
        p = _disk_fallback_path(blob_name)
        if p is None:
            return False
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            with p.open("wb" if create else "ab") as f:
                f.write(data or b"")
            return True
        except Exception as e:
            logger.warning("[blob] disk-append failed for %s: %s", blob_name, e)
            return False
    try:
        bc = cc.get_blob_client(blob_name)
        if create:
            bc.create_append_blob()  # overwrites any prior recording at this path
        if data:
            bc.append_block(data)
        return True
    except Exception as e:
        logger.warning("[blob] append failed for %s: %s", blob_name, e)
        return False


def download_bytes(blob_name: str) -> bytes | None:
    """Download ``blob_name`` and return its bytes, or None if blob is
    disabled / the blob is missing / the download fails. Best-effort — the
    caller turns None into a 404."""
    cc = _get_container()
    if cc is None:
        p = _disk_fallback_path(blob_name)  # disk fallback (blob disabled)
        try:
            return p.read_bytes() if p and p.is_file() else None
        except Exception:
            return None
    try:
        return cc.download_blob(blob_name).readall()
    except Exception as e:
        # Missing blob raises ResourceNotFoundError; treat any failure as
        # "not available" — log at debug since a missing recording is normal.
        logger.debug("[blob] download missing/failed for %s: %s", blob_name, e)
        return None


def blob_size(blob_name: str) -> int | None:
    """Return the byte size of ``blob_name``, or None if disabled / missing.
    Used to answer HTTP Range requests without downloading the blob first."""
    cc = _get_container()
    if cc is None:
        p = _disk_fallback_path(blob_name)  # disk fallback (blob disabled)
        try:
            return p.stat().st_size if p and p.is_file() else None
        except Exception:
            return None
    try:
        return cc.get_blob_client(blob_name).get_blob_properties().size
    except Exception as e:
        logger.debug("[blob] size missing/failed for %s: %s", blob_name, e)
        return None


def download_stream(blob_name: str, offset: int | None = None, length: int | None = None):
    """Stream ``blob_name`` (optionally a byte range) as an iterator of chunks,
    or None if blob is disabled / missing. Streaming keeps a large recording
    from being read fully into memory, and the offset/length let the download
    endpoint serve HTTP 206 range requests so the browser can scrub/seek."""
    cc = _get_container()
    if cc is None:
        p = _disk_fallback_path(blob_name)  # disk fallback (blob disabled)
        if p is None or not p.is_file():
            return None

        def _disk_chunks():
            with p.open("rb") as f:
                if offset:
                    f.seek(offset)
                remaining = length
                while True:
                    n = 1 << 16 if remaining is None else min(1 << 16, remaining)
                    if n <= 0:
                        break
                    b = f.read(n)
                    if not b:
                        break
                    yield b
                    if remaining is not None:
                        remaining -= len(b)
        return _disk_chunks()
    try:
        bc = cc.get_blob_client(blob_name)
        downloader = bc.download_blob(offset=offset, length=length, max_concurrency=1)
    except Exception as e:
        logger.debug("[blob] stream missing/failed for %s: %s", blob_name, e)
        return None
    return downloader.chunks()


def upload_session_artifacts(token: str) -> None:
    """Mirror a finished interview's artifacts to ``<token>/`` in the container.
    Called at session end (after evaluation.json is written). No-op if disabled."""
    if not enabled():
        return
    try:
        from app.paths import session_dir
        sdir = session_dir(token)
        for fname in ("events.jsonl", "evaluation.json", "cadence.yaml"):
            fp = sdir / fname
            if fp.is_file():
                upload_file(fp, f"{token}/{fname}")
        # Resume / JD live at the session-dir root with arbitrary names — mirror
        # any pdf/docx/txt/md that isn't one of the above.
        for fp in sdir.glob("*"):
            if fp.is_file() and fp.suffix.lower() in (".pdf", ".docx", ".txt", ".md"):
                upload_file(fp, f"{token}/{fp.name}")
    except Exception as e:
        logger.warning("[blob] session artifact mirror failed for %s: %s", token, e)


def download_session_artifacts(token: str) -> int:
    """Pull a session's blobs into the local session_dir (inverse of
    upload_session_artifacts). The worker tier runs on a DIFFERENT container from
    the session shard that wrote events.jsonl, so before it can score it must
    hydrate its local disk from Blob. Returns the number of files fetched; no-op
    (0) if Blob is disabled."""
    if not enabled():
        return 0
    try:
        from app.paths import session_dir
        sdir = session_dir(token)
        sdir.mkdir(parents=True, exist_ok=True)
        container = _get_container()
        n = 0
        for blob in container.list_blobs(name_starts_with=f"{token}/"):
            rel = blob.name[len(token) + 1:]
            if not rel:
                continue
            data = download_bytes(blob.name)
            if data is None:
                continue
            dest = sdir / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
            n += 1
        return n
    except Exception as e:
        logger.warning("[blob] session artifact download failed for %s: %s", token, e)
        return 0
