"""Modifying agent (2 of 3) — applies already-RESOLVED clauses, each with only
the slice of the cadence it needs.

There is exactly ONE call shape, deliberately: the PHASE call
(`revise_phase`), which carries only that one phase's JSON body. The candidate's
resume/JD rides along only when that phase's OWN instruction text mentions it
(see CONTEXT_TRIGGER_TERMS in app.cadence_service) — which is why the router is
told to extract instructions VERBATIM and not borrow topic words between clauses.

Every phase fires CONCURRENTLY (`apply`); the edits are independent at call time
and are merged deterministically afterwards (`merge_results`), never by an LLM.

**Total duration is not an LLM call at all.** It used to be a second "structure"
call that reordered/resized phases and was then corrected in code anyway — two
sources of truth for one number, and the LLM's half regularly returned a
self-consistent-but-wrong total. Now `apply` resolves the requested total from
the admin's own words (`resolve_total_target`) and reaches it with
`rescale_to_clean_minutes`, which also keeps phases on WHOLE MINUTES so a
15-minute interview reads 2/4/7/2 rather than 1:53/3:45/7:30/1:52. A phase the
admin gave an explicit duration is PINNED and never rescaled.

Public surface:
  ModifyingAgent.revise_phase(phase, instructions, context) → dict
  ModifyingAgent.apply(...) → ModifyResult
"""
from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass, field
from typing import Optional

from pydantic import ValidationError

from engine.brain.cadence.schema import PhaseDef
from engine.brain.prompts import load as load_prompt

from app.cadence_agents.base import CadenceLLM
from app.cadence_agents.phase_tools import (
    detect_and_apply_phase_mutations,
    extract_context_for_instruction,
    fmt_dur,
    parse_absolute_duration_target,
    rescale_to_clean_minutes,
    resolve_total_target,
)

logger = logging.getLogger(__name__)

PHASE_REVISE_SYSTEM_PROMPT = load_prompt("cadence_phase_revise")


@dataclass
class ModifyResult:
    """`data` ALWAYS carries the merge of whatever succeeded: a failed phase call
    simply keeps its original content. One clause failing therefore can't discard
    its siblings' successful edits — the same clause-independence the router
    relies on.

    `failed_phases` / `total_error` are what the caller reports to the admin.
    There is no whole-YAML retry to fall back to, so losing the partial result
    here would mean losing it entirely."""

    data: dict
    failed_phases: list[str] = field(default_factory=list)
    total_error: Optional[str] = None
    revised_by_id: dict = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        """Every requested unit landed. `data` is usable either way."""
        return not self.failed_phases and self.total_error is None


def merge_results(data: dict, phases: list[dict], revised_by_id: dict) -> dict:
    """Fold the per-phase results back into one cadence dict — deterministically,
    in code, never by an LLM. A phase with no revision is carried through
    untouched, and `total_duration_s` is always recomputed from the final phases;
    no LLM's own total is ever trusted."""
    new_phases = [revised_by_id.get(p["id"], p) for p in phases]

    out = dict(data)
    out["phases"] = new_phases
    out["total_duration_s"] = sum(
        int(p.get("duration_s") or 0) for p in new_phases if isinstance(p, dict)
    )
    return out


class ModifyingAgent:
    name = "cadence_modifying_agent"

    def __init__(self, llm: CadenceLLM) -> None:
        self._llm = llm

    # ── phase call ───────────────────────────────────────────────────────

    async def revise_phase(
        self, phase: dict, instructions: list[str], context: str = "",
    ) -> dict:
        """Scoped call for ONE phase. Returns the validated, revised phase as a
        dict. Raises ValueError after 3 failed attempts, feeding the exact
        schema error back each time."""
        instr_text = "\n".join(f"- {i}" for i in instructions)
        # Attach context ONLY if at least one instruction mentions it explicitly
        needs_context = bool(context and context.strip()) and any(
            extract_context_for_instruction(i) for i in instructions
        )

        last_error: Optional[str] = None
        for attempt in (1, 2, 3):
            user_msg = (
                f"CURRENT PHASE (JSON):\n{json.dumps(phase, ensure_ascii=False)}\n\n"
                f"INSTRUCTIONS FOR THIS PHASE:\n{instr_text}\n"
            )
            if needs_context:
                user_msg += (
                    "\nCANDIDATE CONTEXT (resume / job description) — use this to "
                    "ground any questions the instructions ask for (e.g. reference "
                    "the candidate's real projects/experience). Use it ONLY where "
                    "the instructions call for it:\n"
                    f"{context.strip()[:6000]}\n"
                )
            if last_error:
                user_msg += (
                    f"\nYour previous attempt was REJECTED:\n  {last_error}\n"
                    "Return corrected JSON for this phase only."
                )
            data = await self._llm.complete_json(
                system=PHASE_REVISE_SYSTEM_PROMPT, user=user_msg,
                stage="phase", temperature=0.1,
            )
            try:
                revised = PhaseDef.model_validate(data)
            except (ValueError, ValidationError) as e:
                last_error = str(e).splitlines()[0] if isinstance(e, ValueError) else str(e)
                logger.warning("[modifying_agent] phase '%s' attempt %d rejected: %s",
                               phase.get("id"), attempt, last_error)
                continue
            return revised.model_dump(mode="json")

        raise ValueError(f"phase '{phase.get('id')}': {last_error}")

    # ── fan-out ──────────────────────────────────────────────────────────

    async def apply(
        self, *, data: dict, phases: list[dict], phase_mapping: dict[str, list[str]],
        total_instructions: Optional[list[str]] = None, current_total: int = 0,
        context: str = "",
    ) -> ModifyResult:
        """Run every targeted phase CONCURRENTLY, merge, then settle the total.

        The phase edits are independent, so they all fire in one gather — none
        waits on another. The TOTAL is applied afterwards and in code, because it
        depends on the phase results (a phase given an explicit duration is
        pinned) and because arithmetic is not something to ask an LLM for."""
        phases_by_id = {p["id"]: p for p in phases}

        async def _run_phase(pid: str, instr: list[str]) -> tuple[str, Optional[dict], Optional[str]]:
            try:
                return pid, await self.revise_phase(phases_by_id[pid], instr, context), None
            except Exception as e:
                return pid, None, str(e)

        phase_results = await asyncio.gather(
            *[_run_phase(pid, instr) for pid, instr in phase_mapping.items()]
        )
        failed_phases = [pid for pid, _, err in phase_results if err]
        revised_by_id = {pid: rev for pid, rev, _ in phase_results if rev is not None}
        if failed_phases:
            logger.warning("[modifying_agent] partial apply — failed phases=%s", failed_phases)

        # Merged unconditionally: with no whole-YAML fallback, a sibling's failure
        # must not cost the admin the edits that DID work.
        merged = merge_results(data, phases, revised_by_id)

        total_error = self._apply_total(
            merged, total_instructions or [], phase_mapping, current_total,
        )
        return ModifyResult(merged, failed_phases, total_error, revised_by_id)

    @staticmethod
    def _apply_total(
        merged: dict, total_instructions: list[str],
        phase_mapping: dict[str, list[str]], current_total: int,
    ) -> Optional[str]:
        """Settle a whole-interview duration ask, in place, with zero LLM calls.

        Returns an admin-facing reason string when the ask can't be honoured (the
        explicit per-phase durations already overrun the requested total), else
        None. `current_total` is the total BEFORE this turn's edits, so a relative
        ask ("add 2 minutes") is measured from what the admin was looking at."""
        if not total_instructions:
            return None
        target = resolve_total_target(total_instructions, current_total)
        if target is None:
            # The router only forwards a whole-interview clause once a number is
            # pinnable, so this is a belt-and-braces guard, not a live path.
            return None

        # A phase the admin gave an EXPLICIT duration is pinned: "warm-up 5 min"
        # is more specific than "the interview is 15 min", so it survives the
        # rescale and the other phases absorb the difference.
        pinned = {
            pid for pid, instrs in phase_mapping.items()
            if parse_absolute_duration_target(instrs) is not None
        }
        current_phases = [p for p in merged.get("phases") or [] if isinstance(p, dict)]
        fixed = rescale_to_clean_minutes(current_phases, target, pinned)
        if fixed is None:
            pinned_sum = sum(
                int(p.get("duration_s") or 0) for p in current_phases if p.get("id") in pinned
            )
            logger.warning("[modifying_agent] total %ds unreachable (pinned=%s sum=%ds)",
                           target, sorted(pinned), pinned_sum)
            return (
                f"the phase lengths you asked for already add up to more than "
                f"{fmt_dur(target)}, so I left the total at {fmt_dur(current_total)}"
            )
        merged["phases"] = fixed
        merged["total_duration_s"] = sum(int(p.get("duration_s") or 0) for p in fixed)
        logger.info("[modifying_agent] total set to %ds in whole minutes (pinned=%s)",
                    target, sorted(pinned))
        return None
