"""Phase resolver — the one language question in an ADD ask: WHICH phase?

Only used for "add ..." clauses, and it exists because word matching could not
answer this. The editor used to decide "is this a coding phase?" with a substring
test, so `add a coding discussion` (an ordinary conversation phase it can create)
was answered with the coding-question picker refusal meant for `add a coding
phase`. Alias lists were the obvious next step and the wrong one: every phase
added to the catalog or the blacklist would need its own hand-maintained spellings,
and a near-miss still resolves to something confidently wrong ("coding discussion"
scores 0.95 against `coding_round`, because "round" is a stopword so the id's only
significant token is "coding").

So the match is made on MEANING, against the same thing a human would read: each
candidate phase's `intent`. Three candidate sets, and the answer may also be none
of them:

  in_plan    phases already in this interview  → "that's already here"
  available  phases we hold a real definition for (the catalog: this interview's
             saved plan, the built-in cadence, plus the code-discussion phase)
             → restored verbatim, never generated
  blocked    phases the editor must not create (config/phase_blacklist.json)
             → refused with that entry's own reason
  <none>     a genuinely new phase                → created, after asking what it
                                                     should cover and how long

What this agent deliberately does NOT do:

  - No arithmetic. Durations are parsed in code (`parse_absolute_duration_target`),
    because an exact number is never a model's job. It reports whether the admin
    named a duration only as a cross-check; the value used is always code's.
  - No phase bodies. For a restore the body comes from the catalog; for a create
    the content is authored later by the MODIFYING agent, which is already the
    agent that writes phase content and is already schema-validated with retries.

Fails CLOSED, not open: a failed call yields no resolution, and the caller asks the
admin which phase they meant. A wrong silent add is the outcome this whole layer
exists to prevent, so "I'm not sure" must never become "I picked one".

Public surface:
  PhaseResolverAgent.resolve(asks, in_plan, available, blocked) → {clause_id: dict}
"""
from __future__ import annotations

import json
import logging

from engine.brain.prompts import load as load_prompt

from app.cadence_agents.base import CadenceLLM

logger = logging.getLogger(__name__)

RESOLVER_SYSTEM_PROMPT = load_prompt("cadence_phase_resolver")


def _slim(phases: list[dict]) -> list[dict]:
    """{id, intent} only. The resolver matches on MEANING, so the intent is the
    payload; prompts, question pools and durations would only be noise."""
    out = []
    for p in phases:
        pid = str((p or {}).get("id") or "").strip()
        if not pid:
            continue
        out.append({"id": pid, "intent": (p.get("intent") or "").strip()})
    return out


class PhaseResolverAgent:
    name = "cadence_phase_resolver_agent"
    stage = "resolve"

    def __init__(self, llm: CadenceLLM) -> None:
        self._llm = llm

    async def resolve(
        self, *, asks: list[dict], in_plan: list[dict], available: list[dict],
        blocked: list[dict],
    ) -> dict:
        """Resolve every ADD ask in one call.

        `asks` is [{clause_id, text}]. Returns {clause_id: {phase_ids, new_name,
        covers}}. `phase_ids` is every candidate phase the ask names, in order —
        empty means a NEW phase, and more than one means the ask genuinely named
        several ("add the wrap-up and a coding phase"), which the caller must
        answer for BOTH rather than dropping one. A clause missing from the result
        is one the caller must ASK the admin about."""
        if not asks:
            return {}

        payload = {
            "asks": [
                {"id": a.get("clause_id", ""), "text": (a.get("text") or "").strip()}
                for a in asks
            ],
            "in_plan": _slim(in_plan),
            "available": _slim(available),
            "blocked": [
                {"id": b["id"], "intent": b.get("intent", "")} for b in blocked
            ],
        }
        try:
            obj = await self._llm.complete_json(
                system=RESOLVER_SYSTEM_PROMPT,
                user=json.dumps(payload, ensure_ascii=False),
                stage=self.stage, temperature=0.0,
            )
        except ValueError as e:
            logger.warning("[phase_resolver] call failed (%s) — every add ask will "
                           "be put back to the admin", str(e).splitlines()[0])
            return {}

        items = obj.get("resolutions")
        if not isinstance(items, list):
            logger.warning("[phase_resolver] no `resolutions` list — asking instead")
            return {}

        known_ids = {a.get("clause_id", "") for a in asks}
        # Only ids we actually offered may be returned. A hallucinated phase id is
        # the one failure mode that could add a phase nobody has a definition for,
        # so it is dropped to "unresolved" (→ the admin is asked) rather than tried.
        offered = ({p["id"] for p in payload["in_plan"]}
                   | {p["id"] for p in payload["available"]}
                   | {p["id"] for p in payload["blocked"]})

        out: dict[str, dict] = {}
        for it in items:
            if not isinstance(it, dict):
                continue
            cid = str(it.get("id") or "").strip()
            if cid not in known_ids:
                continue
            raw_ids = it.get("phase_ids")
            if isinstance(raw_ids, str):        # tolerate a bare string
                raw_ids = [raw_ids]
            ids, bogus = [], []
            for v in raw_ids or []:
                pid = str(v or "").strip()
                if not pid:
                    continue
                (ids if pid in offered else bogus).append(pid)
            if bogus:
                # A hallucinated id is the one failure that could add a phase
                # nobody holds a definition for. Drop the whole ask to
                # "unresolved" (→ the admin is asked) rather than acting on the
                # part that happened to be real.
                logger.warning("[phase_resolver] %s named unknown phase(s) %s — "
                               "asking instead", cid, bogus)
                continue
            out[cid] = {
                "phase_ids": ids,
                "new_name": str(it.get("new_name") or "").strip(),
                "covers": str(it.get("covers") or "").strip(),
            }
        logger.info("[phase_resolver] resolved %d/%d add ask(s): %s",
                    len(out), len(asks),
                    {c: (r["phase_ids"] or f"NEW:{r['new_name']}")
                     for c, r in out.items()})
        return out
