"""Router agent (1 of 3) — reads the admin's request, splits it into separate
instructions, and either names the phase each one changes or ASKS for what's
missing. This is also the agent that HOLDS THE CONVERSATION with the admin: the
questions the chat shows come from here.

Only TWO clause kinds, deliberately:

  "phase"     → this instruction changes ONE phase, and we know which.
                `phase_id` is an existing id, or the reserved "ALL" when the
                instruction changes the interview's TOTAL length.
  "ambiguous" → everything else. Carries a `question` grounded in the real phase
                list. A clause that could NEVER be done (scoring, adding or
                reordering phases, the AI's voice, …) is still "ambiguous" — it
                just carries `beyond_capability`, which turns the reply into a
                capability message instead of a question.

Why two: the earlier four-kind taxonomy (phase / structure / ambiguous /
out_of_scope) made the prompt long and gave the model two ways to be wrong —
it routed half-specified asks to `out_of_scope` (a dead end for something a
single question would have fixed) and invented `structure` work that then had to
be re-checked. Total-duration changes are now DETERMINISTIC CODE, not an LLM
call, so the router never has to reason about arithmetic at all.

Sees only {id, intent, duration_s} per phase — never phase bodies, never YAML.

Public surface:
  RouterAgent.route(feedback, clarifications, phases, total_duration_s) → RouterResult
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Optional

from engine.brain.prompts import load as load_prompt

from app.cadence_agents.base import CadenceLLM
from app.cadence_agents.phase_tools import (
    detect_structure_verb,
    fmt_dur,
    parse_absolute_duration_target,
    parse_relative_duration_delta,
)

logger = logging.getLogger(__name__)

# The reserved phase_id meaning "the interview as a whole". Not a phase; the
# orchestrator turns it into deterministic total-duration arithmetic.
ALL_PHASES = "ALL"

# What this editor can actually do. Surfaced verbatim whenever the router hits a
# capability boundary, so "I can't do that" always arrives with "here's what I
# can do" attached.
ROUTER_CAPABILITIES = (
    "change a phase's questions, prompts, or intent",
    "change one phase's duration",
    "change the interview's total duration",
    "remove, reorder, or add a phase",
)

ROUTER_SYSTEM_PROMPT = load_prompt("cadence_router")


def capability_message(reason: str, suggestion: str = "") -> str:
    """Admin-facing capability boundary. Templated in CODE, not by the LLM, so
    the wording is consistent and always lists what CAN be done — the router only
    supplies the specifics.

    `reason` arrives as either a VERB PHRASE ("set a candidate's score") or a
    whole SENTENCE ("Creating a new phase is not supported."), depending on the
    model. Prefixing "I can't" onto the latter produced "I can't Creating a new
    phase is not supported" in the chat, so the shape is detected rather than
    assumed."""
    caps = "; ".join(ROUTER_CAPABILITIES)
    reason = reason.strip()
    if not reason:
        head = "I can't do that from here."
    elif reason[0].isupper() and re.search(r"\b(is|are|isn't|aren't|can't|cannot)\b", reason):
        head = reason if reason.endswith((".", "!", "?")) else f"{reason}."
    else:
        head = f"I can't {reason.rstrip('.')} from here."
    out = f"{head} What I can do: {caps}."
    if suggestion.strip():
        out += f" {suggestion.strip().rstrip('.')}."
    return out


@dataclass
class RouterResult:
    """Every clause, pre-split by what the orchestrator does with it.

    `resolved` is dispatched to the MODIFYING agent immediately — it is NEVER
    held back waiting on `questions`. That's the point of splitting per clause:
    a half-clear request applies its clear half in the same turn.
    """

    resolved: list[dict] = field(default_factory=list)      # kind "phase" (id or ALL)
    questions: list[dict] = field(default_factory=list)     # clause_id, text, question, options
    out_of_scope: list[dict] = field(default_factory=list)  # clause_id, text, message

    @property
    def total(self) -> int:
        return len(self.resolved) + len(self.questions) + len(self.out_of_scope)

    @property
    def phase_mapping(self) -> dict[str, list[str]]:
        """{phase_id: [instruction, ...]} — one MODIFYING call per key.

        Skips clauses whose phase is still unresolved (`phase_id == ""`); those are
        settled by `phase_tools.plan_deterministic`, which is what actually feeds
        the modifier now."""
        out: dict[str, list[str]] = {}
        for c in self.resolved:
            pid = c.get("phase_id") or ""
            if pid and pid != ALL_PHASES:
                out.setdefault(pid, []).append(c["text"])
        return out

    @property
    def total_instructions(self) -> list[str]:
        """Whole-interview instructions. Handled by arithmetic, never by an LLM."""
        return [c["text"] for c in self.resolved if c.get("phase_id") == ALL_PHASES]


def detect_duration_conflicts(clauses: list[dict]) -> list[dict]:
    """Deterministic contradiction check — NOT an LLM job. Two clauses asking for
    two DIFFERENT absolute durations on the same scope can't both be honoured,
    and an LLM asked to both NOTICE and RESOLVE a contradiction will usually just
    silently pick one. Returns replacement clauses (demoted to "ambiguous", with
    both literal values already in the question)."""
    by_scope: dict[str, list[tuple[dict, int]]] = {}
    for c in clauses:
        # An UNRESOLVED phase ("") is not a scope — two clauses both awaiting
        # deterministic resolution would otherwise look like two asks on one phase
        # and "15 min total / 2:30 warm-up" would self-destruct into a question.
        # Real conflicts on a resolved scope are caught in `plan_deterministic`.
        if c["kind"] != "phase" or not (c.get("phase_id") or ""):
            continue
        target = parse_absolute_duration_target([c["text"]])
        if target is not None:
            by_scope.setdefault(c["phase_id"], []).append((c, target))

    conflicted: list[dict] = []
    for scope, entries in by_scope.items():
        distinct = sorted({t for _, t in entries})
        if len(distinct) < 2:
            continue
        what = "the whole interview" if scope == ALL_PHASES else scope
        for clause, _ in entries:
            conflicted.append({
                **clause,
                "kind": "ambiguous",
                "reason": f"two different durations were asked for {what}",
                "question": (
                    f"You asked for two different lengths for {what} — "
                    f"{' and '.join(fmt_dur(d) for d in distinct)}. Which one should I use?"
                ),
                "options": [fmt_dur(d) for d in distinct],
            })
    return conflicted


class RouterAgent:
    name = "cadence_router_agent"
    stage = "route"

    def __init__(self, llm: CadenceLLM) -> None:
        self._llm = llm

    async def route(
        self, *, feedback: str, clarifications: list[dict], phases: list[dict],
        total_duration_s: int,
    ) -> RouterResult:
        """One small LLM call: split the admin's request into tagged clauses.

        `clarifications` are prior ambiguous clauses now carrying the admin's
        `answer`; they're re-classified in the SAME call as any new `feedback`, so
        a turn costs exactly one router call whether the admin is asking something
        new, answering a question, or both.

        Raises ValueError on a call/parse failure — the orchestrator refuses the
        turn rather than guessing."""
        payload = {
            "phases": [
                {
                    "id": p.get("id"),
                    "intent": (p.get("intent") or "").strip(),
                    "duration_s": int(p.get("duration_s") or 0),
                }
                for p in phases
            ],
            "total_duration_s": int(total_duration_s),
            "feedback": (feedback or "").strip(),
            "clarifications": [
                {
                    "text": str(c.get("text") or ""),
                    "question": str(c.get("question") or ""),
                    "answer": str(c.get("answer") or ""),
                }
                for c in clarifications
                if str(c.get("answer") or "").strip()
            ],
        }
        obj = await self._llm.complete_json(
            system=ROUTER_SYSTEM_PROMPT,
            user=json.dumps(payload, ensure_ascii=False),
            stage=self.stage,
        )

        raw_clauses = obj.get("clauses")
        if not isinstance(raw_clauses, list):
            raise ValueError("router returned no clause list")

        valid_ids = {p.get("id") for p in phases}
        clauses = [
            c for c in (
                self._normalize(c, i, valid_ids, int(total_duration_s))
                for i, c in enumerate(raw_clauses)
            ) if c is not None
        ]
        if not clauses:
            raise ValueError("router produced no usable clauses")

        # Contradictions are caught BEFORE anything is applied.
        for conflicted in detect_duration_conflicts(clauses):
            clauses = [conflicted if c["clause_id"] == conflicted["clause_id"] else c for c in clauses]

        result = RouterResult(
            resolved=[c for c in clauses if c["kind"] == "phase"],
            questions=[
                {"clause_id": c["clause_id"], "text": c["text"], "question": c["question"],
                 "options": c.get("options") or []}
                for c in clauses if c["kind"] == "ambiguous" and not c.get("beyond_capability")
            ],
            out_of_scope=[
                {"clause_id": c["clause_id"], "text": c["text"], "message": c["message"]}
                for c in clauses if c["kind"] == "ambiguous" and c.get("beyond_capability")
            ],
        )
        logger.info(
            "[router_agent] %d clause(s): phase=%d ambiguous=%d beyond_capability=%d",
            result.total, len(result.resolved), len(result.questions), len(result.out_of_scope),
        )
        return result

    @staticmethod
    def _normalize(
        c: object, index: int, valid_ids: set, current_total: int,
    ) -> Optional[dict]:
        """Coerce one raw router clause into a trusted shape.

        Deliberately PERMISSIVE about the phase reference. The router's `phase_id`
        is a HINT now, not a verdict: `phase_tools.plan_deterministic` re-resolves
        every clause against the real phase list (separator-insensitively, with a
        tie check) and asks the admin itself when it can't. Rejecting an unknown id
        here used to throw away a perfectly resolvable ask — "remove the wrapup
        phase" is unambiguous to code even when the router guesses the id wrong.

        A clause whose SHAPE we can't read at all is still demoted to "ambiguous"
        rather than dropped: silently losing part of a request is the one outcome
        worse than asking."""
        if not isinstance(c, dict):
            return None
        text = str(c.get("text") or "").strip()
        if not text:
            return None
        kind = str(c.get("kind") or "").strip().lower()
        clause = {"clause_id": f"c{index + 1}", "text": text, "kind": kind}

        def ask(reason: str, question: str, options: Optional[list] = None) -> dict:
            clause.update(kind="ambiguous", reason=reason, question=question,
                          options=options or [])
            return clause

        if kind == "phase":
            pid = str(c.get("phase_id") or "").strip()
            # ALL and real ids pass through as-is; anything else is kept as a hint
            # (empty string) for the deterministic resolver to work out from `text`.
            clause["phase_id"] = pid if (pid == ALL_PHASES or pid in valid_ids) else ""
            return clause

        if kind == "ambiguous":
            # Two things the model is not allowed to have the last word on, because
            # code can settle both and a wrong verdict here costs the admin their
            # edit. Both are handed to `plan_deterministic` as an untagged clause.
            # A RELATIVE duration is just as much "a number the admin gave" as an
            # absolute one, so both block an ambiguity verdict. Counting only
            # absolutes left "add 2 minutes to the warm-up" as a question.
            has_duration = (parse_absolute_duration_target([text]) is not None
                            or parse_relative_duration_delta([text]) is not None)
            structure = detect_structure_verb(text)

            def take_back(why: str) -> dict:
                logger.info("[router_agent] overriding %s on %r", why, text)
                clause["kind"] = "phase"
                clause["phase_id"] = ""
                clause.pop("beyond_capability", None)
                return clause

            if c.get("beyond_capability"):
                # A DURATION ask is never "create a phase" — "make hr round 3 min"
                # means the admin used a name we don't have, which is a question,
                # not a refusal. And structure verbs are things this editor does;
                # `plan_structure_op` owns both the doing and the refusing (its
                # refusal for a coding phase points at the picker, which a generic
                # capability message can't).
                if has_duration or structure:
                    return take_back("beyond_capability")
                clause["beyond_capability"] = True
                clause["message"] = capability_message(
                    str(c.get("reason") or "").strip(),
                    str(c.get("suggestion") or "").strip(),
                )
                return clause

            # An explicit duration is never a reason to ask (HARD RULE 1), and any
            # structure verb belongs to the deterministic layer — including "add",
            # which now CREATES a phase (asking for its duration itself) rather
            # than being a dead end. Leaving an "add" here made the router answer
            # "did you mean <some existing phase>?" for a phase the admin was
            # asking us to create.
            if has_duration or structure is not None:
                return take_back("an ambiguous verdict")

            opts = c.get("options")
            return ask(
                str(c.get("reason") or "").strip(),
                (str(c.get("question") or "").strip()
                 or f'Could you give me more detail on "{text}"?'),
                ([str(o).strip() for o in opts if str(o).strip()][:4]
                 if isinstance(opts, list) else []),
            )

        return ask(
            "couldn't classify this request",
            f'Could you rephrase "{text}"? I\'m not sure which part of the plan it changes.',
        )
