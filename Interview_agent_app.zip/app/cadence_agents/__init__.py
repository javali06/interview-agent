"""The three agents behind "Revise & Verify Cadence with AI".

ROUTER → MODIFYING → VALIDATING. Each sees only the slice of the cadence it
needs, and that is the whole point: **the raw cadence YAML is never sent to an
LLM by any path**. There is no full-cadence fallback agent — when the machinery
can't run (unreadable cadence, router failure) the orchestrator
(`app.cadence_service.revise_cadence_conversational`) refuses the turn and says
why, rather than handing the whole plan to a model that would then be free to
rewrite phases the admin never mentioned.

  1. RouterAgent     — SPLITS the admin's request into independent clauses and tags
                       each `phase` or `ambiguous`. Its `phase_id` is a HINT, not a
                       verdict: code re-resolves every reference, and takes back any
                       clause the model refused or queried that carries an explicit
                       duration or a structure verb. Sees {id, intent, duration_s} only.
  1b. phase_tools    — the DETERMINISTIC pre-pass (`plan_deterministic`), and the
                       reason most turns cost fewer LLM calls than clauses. Structure
                       (remove/reorder) is a list operation; durations are arithmetic.
                       Neither goes near a model. Only what genuinely needs judgement
                       reaches the modifier; anything doubtful becomes a grounded
                       question instead of a silent wrong edit.
  2. ModifyingAgent  — applies the CONTENT clauses concurrently: one call per targeted
                       phase, carrying that phase's JSON only. Returns the merge of
                       whatever succeeded, so one failed clause can't discard its
                       siblings' edits.
  3. ValidatingAgent — verifies the patched result AND authors what the admin is told:
                       one line per INSTRUCTION, never a diff of the whole plan. Numbers
                       re-pinned/reconciled in code, structure by set membership, content
                       in ONE batched call on its OWN model handle (the model that made
                       the edit does not grade it). Fails open.

Prompts live in `config/prompts.yaml` (`cadence_router`, `cadence_phase_revise`,
`cadence_validator`), matching the brain agents.
"""
from app.cadence_agents.base import CadenceLLM, build_extra_body, parse_llm_json
from app.cadence_agents.phase_tools import (
    CODE_DISCUSSION_ID,
    CONFIDENT_REF,
    PLAUSIBLE_REF,
    ClauseOutcome,
    DeterministicPlan,
    StructureOp,
    apply_structure_op,
    ask_which_phase,
    blacklist_entry,
    derive_phase_id,
    find_code_discussion,
    detect_and_apply_phase_mutations,
    detect_structure_verb,
    extract_context_for_instruction,
    find_best_phase_match,
    find_phase_refs,
    fmt_dur,
    has_coding_round,
    is_time_change_ask,
    is_whole_interview_scope,
    load_phase_blacklist,
    parse_absolute_duration_target,
    parse_relative_duration_delta,
    plan_deterministic,
    plan_structure_op,
    reads_as_confirmation,
    reads_as_decline,
    reconcile_total_with_pins,
    rescale_to_clean_minutes,
    rescale_to_exact_total,
    resolve_phase_ref,
    resolve_total_target,
)
from app.cadence_agents.modifying_agent import (
    PHASE_REVISE_SYSTEM_PROMPT,
    ModifyingAgent,
    ModifyResult,
    merge_results,
)
from app.cadence_agents.phase_resolver_agent import (
    RESOLVER_SYSTEM_PROMPT,
    PhaseResolverAgent,
)
from app.cadence_agents.router_agent import (
    ALL_PHASES,
    ROUTER_CAPABILITIES,
    ROUTER_SYSTEM_PROMPT,
    RouterAgent,
    RouterResult,
    capability_message,
    detect_duration_conflicts,
)
from app.cadence_agents.validating_agent import (
    VALIDATOR_SYSTEM_PROMPT,
    ValidatingAgent,
    ValidationReport,
    phase_content_view,
)

__all__ = [
    # plumbing
    "CadenceLLM",
    "build_extra_body",
    "parse_llm_json",
    # phase tools — duration arithmetic
    "fmt_dur",
    "parse_absolute_duration_target",
    "parse_relative_duration_delta",
    "resolve_total_target",
    "rescale_to_exact_total",
    "rescale_to_clean_minutes",
    "reconcile_total_with_pins",
    "is_whole_interview_scope",
    "is_time_change_ask",
    # phase tools — reference resolution
    "CONFIDENT_REF",
    "PLAUSIBLE_REF",
    "resolve_phase_ref",
    "ask_which_phase",
    "find_phase_refs",
    "find_best_phase_match",
    "extract_context_for_instruction",
    # phase tools — structure ops + the deterministic pre-pass
    "StructureOp",
    "detect_structure_verb",
    "plan_structure_op",
    "apply_structure_op",
    "detect_and_apply_phase_mutations",
    "ClauseOutcome",
    "DeterministicPlan",
    "plan_deterministic",
    # phase tools — what may/may not be created
    "CODE_DISCUSSION_ID",
    "load_phase_blacklist",
    "blacklist_entry",
    "find_code_discussion",
    "has_coding_round",
    "reads_as_confirmation",
    "reads_as_decline",
    "derive_phase_id",
    # 1. router
    "RouterAgent",
    "RouterResult",
    "ALL_PHASES",
    "ROUTER_CAPABILITIES",
    "ROUTER_SYSTEM_PROMPT",
    "capability_message",
    "detect_duration_conflicts",
    # 1c. phase resolver (ADD asks only)
    "PhaseResolverAgent",
    "RESOLVER_SYSTEM_PROMPT",
    # 2. modifying
    "ModifyingAgent",
    "ModifyResult",
    "merge_results",
    "PHASE_REVISE_SYSTEM_PROMPT",
    # 3. validating
    "ValidatingAgent",
    "ValidationReport",
    "VALIDATOR_SYSTEM_PROMPT",
    "phase_content_view",
]
