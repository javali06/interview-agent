"""Deterministic tools for the cadence editor — the work no LLM should be doing.

Three families, all pure code, all shared by the three agents:

  1. DURATION ARITHMETIC. Minutes→seconds, hitting an EXACT requested total, and
     redistributing rounding slack. "Approximately 15 minutes" is a bug when the
     schema validates `total_duration_s == Σ phase duration_s`.

  2. PHASE REFERENCE RESOLUTION (`resolve_phase_ref`). Which phase does "the
     wrapup round" mean? Separator-insensitive, so every human spelling of a
     phase name lands on the same id — and a genuine tie returns *no* match so
     the caller asks instead of coin-flipping.

  3. STRUCTURE OPS (`plan_structure_op` / `apply_structure_op`). Remove, reorder,
     and the refusal-with-a-reason for "add". Structure is a list operation; it
     never goes near a model.

WHY 2 and 3 live here rather than in a prompt: a content editor that can only
rewrite a phase's questions was being handed "remove the wrap-up phase", so it
reported "wrap_up: questions updated" for a phase the admin asked to delete.
Deterministic tools can't make that class of mistake.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# Matches a single explicit duration mention ("10 minutes", "600 sec", "1.5 hrs", "2min30sec").
# Longest alternatives first so "minute" is consumed whole rather than
# matching the "min" branch and leaving "ute" dangling.
# Uses negative lookahead (?![a-z]) instead of \b to allow compound durations like "2min30sec"
# (a word boundary fails when the next char is a digit, but we want "2min" to match even if
# followed by "30sec").
DURATION_UNIT_RE = re.compile(
    r"(\d+(?:\.\d+)?)\s*(hours?|hrs?|minutes?|mins?|seconds?|secs?)(?![a-z])", re.IGNORECASE,
)
DURATION_UNIT_SECONDS = {
    "hour": 3600, "hr": 3600, "minute": 60, "min": 60, "second": 1, "sec": 1,
}
# If any of these appear alongside the number, the ask is a RELATIVE delta
# ("add 2 more minutes", "shorten by 3 min") rather than an absolute target
# ("make it 10 minutes") — deterministic correction only applies to the
# latter, so a relative ask is left to the LLM exactly as before (no change
# in behavior, no new risk).
RELATIVE_DURATION_MARKERS = (
    "by ", " more", " less", " extra", " additional", " add ", " increase",
    " decrease", " reduce", " cut ", " trim ",
)

# "...TO 30 seconds" is an ABSOLUTE target that happens to carry a direction verb.
# "...BY 30 seconds" is a delta. The PREPOSITION decides, not the verb: reading the
# verb alone made "reduce the warm-up to 30 seconds" a relative ask, so the phase
# was set to (something − 30) instead of to 30.
# A DIGIT is required after "to" so "add 30 seconds to the warm-up" stays relative.
_ABSOLUTE_TO_RE = re.compile(
    r"\bto\s+(?:about\s+|around\s+|roughly\s+|approximately\s+|exactly\s+|just\s+)?\d"
)


def fmt_dur(seconds: int) -> str:
    """m:ss, for admin-facing change summaries ("0:30 → 5:00")."""
    s = max(0, int(seconds))
    return f"{s // 60}:{s % 60:02d}"


def parse_absolute_duration_target(instructions: list[str]) -> Optional[int]:
    """Best-effort deterministic parse of an explicit ABSOLUTE total-duration
    target (e.g. "make the interview 10 minutes", "set total to 600s", "2min30sec")
    from the admin's own structure instructions. Returns seconds, or None if the
    ask isn't an unambiguous single absolute number — in that case the
    caller falls back to trusting the LLM's own arithmetic exactly as
    before. Deliberately conservative: no relative-delta wording, or we don't touch it."""
    text = " ".join(instructions).lower()
    # An explicit "to <number>" outranks a direction verb — see _ABSOLUTE_TO_RE.
    if not _ABSOLUTE_TO_RE.search(text) and any(
        marker in f" {text} " for marker in RELATIVE_DURATION_MARKERS
    ):
        return None
    matches = list(DURATION_UNIT_RE.finditer(text))
    if not matches:
        return None
    # Check if matches are consecutive (compound duration like "2min30sec") or separate
    # (ambiguous like "5 minutes then 8 minutes"). Consecutive = no word chars between them.
    if len(matches) > 1:
        for i in range(len(matches) - 1):
            end_of_first = matches[i].end()
            start_of_second = matches[i + 1].start()
            between = text[end_of_first:start_of_second]
            # If there's anything between matches except whitespace and digits, it's separate
            # (e.g., "then", "or", "and" in "5 minutes then 8 minutes")
            if between and not (between.isspace() or between.isdigit()):
                return None  # Ambiguous: two separate duration mentions
    # Sum all duration components: "2min30sec" → 120 + 30 = 150
    total = 0
    for m in matches:
        value, unit = m.group(1), m.group(2).lower().rstrip("s")
        total += round(float(value) * DURATION_UNIT_SECONDS[unit])
    return total if total > 0 else None


# Direction words for a RELATIVE total change. Kept separate from
# RELATIVE_DURATION_MARKERS (which only detects THAT an ask is relative) because
# applying one needs the SIGN too.
_LENGTHEN_WORDS = ("add", "more", "extra", "additional", "increase", "longer", "lengthen", "extend")
_SHORTEN_WORDS = ("less", "reduce", "decrease", "cut", "trim", "shorter", "shorten", "drop")


def parse_relative_duration_delta(instructions: list[str]) -> Optional[int]:
    """Deterministic parse of a RELATIVE duration change ("add 2 minutes",
    "shorten it by 3 min") into a signed seconds delta.

    Exists so a relative total ask stays code arithmetic instead of becoming the
    one duration case an LLM still does by hand. Deliberately strict: exactly one
    number and exactly one unambiguous direction, or None — a mixed or
    directionless ask is something to ASK the admin about, not to guess."""
    text = " ".join(instructions).lower()
    # Direction is read from the ORIGINAL text — "less" is a direction word, so
    # it must be seen before the filler-word strip below can remove it.
    padded = f" {text} "
    up = any(f" {w}" in padded for w in _LENGTHEN_WORDS)
    down = any(f" {w}" in padded for w in _SHORTEN_WORDS)
    if up == down:   # neither, or contradictory ("add less time")
        return None
    # "add 2 more minutes" is natural phrasing, but DURATION_UNIT_RE wants the
    # unit adjacent to the number. Drop the fillers that sit between them.
    compact = re.sub(r"\b(?:more|extra|additional|fewer|less)\s+", "", text)
    matches = list(DURATION_UNIT_RE.finditer(compact))
    if len(matches) != 1:
        return None
    value, unit = matches[0].group(1), matches[0].group(2).lower().rstrip("s")
    magnitude = round(float(value) * DURATION_UNIT_SECONDS[unit])
    return magnitude if up else -magnitude


def rescale_to_exact_total(phases: list[dict], target_total: int) -> list[dict]:
    """Deterministically rescale `phases` ({"id","duration_s"}) so they sum to
    EXACTLY `target_total`, preserving each phase's relative share of the
    CURRENT sum via largest-remainder rounding (never off by a few seconds
    the way naive float rounding would be). Every phase stays >= 1s. This is
    the code-side guarantee that backs the LLM's own (sometimes imprecise)
    proportional-scaling arithmetic — the LLM decides survival/order/relative
    weight, this function guarantees the exact number."""
    current_total = sum(p["duration_s"] for p in phases)
    n = len(phases)
    if current_total <= 0 or target_total <= 0 or n == 0:
        return phases
    raw = [p["duration_s"] * target_total / current_total for p in phases]
    floors = [max(1, int(r)) for r in raw]
    remainder = target_total - sum(floors)
    # Largest-remainder method: hand out (or claw back) the rounding slack
    # to the phases whose floored value lost (or gained) the most.
    order = sorted(range(n), key=lambda i: raw[i] - int(raw[i]), reverse=True)
    i = 0
    while remainder > 0:
        floors[order[i % n]] += 1
        remainder -= 1
        i += 1
    while remainder < 0 and any(f > 1 for f in floors):
        idx = order[i % n]
        if floors[idx] > 1:
            floors[idx] -= 1
            remainder += 1
        i += 1
    return [{"id": p["id"], "duration_s": floors[j]} for j, p in enumerate(phases)]


def resolve_total_target(instructions: list[str], current_total: int) -> Optional[int]:
    """The requested new TOTAL in seconds, from the admin's own words — absolute
    ("make it 15 minutes") or relative ("add 2 minutes") — or None when neither
    parses unambiguously, in which case the caller ASKS instead of guessing.

    This is the whole of what used to be an LLM "structure" call."""
    absolute = parse_absolute_duration_target(instructions)
    if absolute is not None:
        return absolute
    delta = parse_relative_duration_delta(instructions)
    if delta is not None and current_total + delta > 0:
        return current_total + delta
    return None


def rescale_to_clean_minutes(
    phases: list[dict], target_total: int, pinned_ids: Optional[set] = None,
) -> Optional[list[dict]]:
    """Hit `target_total` EXACTLY while keeping every phase a WHOLE NUMBER OF
    MINUTES, and leaving phases in `pinned_ids` at their current value.

    WHY this exists rather than just calling `rescale_to_exact_total`: an admin
    who says "make the whole interview 15 minutes" means a plan a human would
    have written — 2 / 4 / 7 / 2 min. Proportional rescaling at SECOND
    granularity is mathematically correct and reads terribly: 1:53 / 3:45 /
    7:30 / 1:52. So the unit of allocation here is the MINUTE; seconds only
    survive where the admin explicitly asked for them.

    A phase is allowed to be non-round in exactly two cases:
      - it's PINNED (the admin said "make the warm-up 15 seconds" — honour it
        literally), or
      - the pins leave a non-minute remainder, in which case the odd seconds are
        parked on the single longest flexible phase, where they read least oddly.

    Falls back to second-level rescaling when whole minutes are impossible (the
    target can't give every flexible phase at least 1 minute). Returns None when
    the target can't be met at all — the caller asks the admin rather than
    silently dropping one of two conflicting asks.
    """
    pinned_ids = pinned_ids or set()
    target_total = int(target_total)
    flex = [p for p in phases if p.get("id") not in pinned_ids]
    pinned_sum = sum(int(p.get("duration_s") or 0) for p in phases if p.get("id") in pinned_ids)
    remaining = target_total - pinned_sum

    if not flex:
        # Everything is pinned: the only honest answer is whether it already adds up.
        return [dict(p) for p in phases] if remaining == 0 else None
    if remaining < len(flex):
        return None

    flex_seconds = [
        {"id": p["id"], "duration_s": max(1, int(p.get("duration_s") or 0))} for p in flex
    ]
    if remaining < 60 * len(flex):
        # Too tight for a minute each — second-level is the honest answer here.
        alloc = rescale_to_exact_total(flex_seconds, remaining)
    else:
        whole_minutes, odd_s = divmod(remaining, 60)
        # Same largest-remainder maths as rescale_to_exact_total, but the UNIT is
        # a minute — which is the entire point.
        in_minutes = rescale_to_exact_total(flex_seconds, whole_minutes)
        alloc = [{"id": m["id"], "duration_s": m["duration_s"] * 60} for m in in_minutes]
        if odd_s:
            longest = max(range(len(alloc)), key=lambda i: alloc[i]["duration_s"])
            alloc[longest]["duration_s"] += odd_s

    new_by_id = {a["id"]: a["duration_s"] for a in alloc}
    out = []
    for p in phases:
        q = dict(p)
        if p.get("id") in new_by_id:
            q["duration_s"] = new_by_id[p["id"]]
        out.append(q)
    if sum(int(p.get("duration_s") or 0) for p in out) != target_total:
        return None
    return out


def reconcile_total_with_pins(
    phases: list[dict], target_total: int, pinned_ids: set,
) -> Optional[list[dict]]:
    """Make `phases` sum to EXACTLY `target_total` while leaving every phase in
    `pinned_ids` at its current duration.

    This is the fix for the one merge conflict concurrent clauses can't avoid:
    "make warm-up 5 minutes AND make the whole interview 15 minutes" — the
    phase's own explicit 5:00 correctly overrides its proportional share, which
    shifts the recomputed total off the 15:00 target. Both asks ARE satisfiable:
    honour the pin, absorb the difference across the phases the admin said
    nothing about. Returns None when that's impossible (no flexible phases left,
    or the pins alone already exceed the target), in which case the caller asks
    the admin instead of silently picking a winner.

    Delegates to `rescale_to_clean_minutes` so a reconciled plan reads as cleanly
    as a freshly-scaled one."""
    return rescale_to_clean_minutes(phases, target_total, pinned_ids)


# ══════════════════════════════════════════════════════════════════════════════
# Phase reference resolution — deterministic, zero LLM
# ══════════════════════════════════════════════════════════════════════════════
#
# WHY this is code and not a prompt: "remove the wrapup phase" must resolve to
# `wrap_up` every single time. The old implementation compared the WHOLE
# instruction against a phase id with difflib and gated at 0.7 — "remove the
# wrapup phase" vs "wrap_up" scores 0.65, so the removal was silently dropped
# and the clause fell through to the content editor, which "updated questions"
# on a phase the admin asked to delete. A separator-insensitive match is exact,
# explainable, and can't drift with a model.

# Words that carry no phase-identifying signal, so they neither help a match nor
# count against one. "round"/"phase"/"section" are how humans SAY phase, not part
# of any phase's name.
_REF_STOPWORDS = frozenset({
    "the", "a", "an", "this", "that", "phase", "round", "section", "part", "stage",
    "step", "block", "segment", "make", "set", "change", "update", "to", "of", "for",
    "and", "or", "it", "its", "be", "is", "please", "can", "you", "i", "we", "want",
    "remove", "delete", "drop", "eliminate", "rid", "get", "add", "move", "swap",
    "reorder", "before", "after", "first", "last", "more", "less", "min", "mins",
    "minute", "minutes", "sec", "secs", "second", "seconds", "interview", "whole",
})


def _squash(text: str) -> str:
    """Collapse to bare alphanumerics: "Wrap-Up " / "wrap up" / "wrap_up" → "wrapup".

    This single normalisation is what makes every human spelling of a phase name
    hit the same phase id."""
    return re.sub(r"[^a-z0-9]+", "", (text or "").lower())


def _tokens(text: str) -> list[str]:
    return [t for t in re.split(r"[^a-z0-9]+", (text or "").lower()) if t]


def _signif(text: str) -> list[str]:
    """Tokens that actually identify a phase (stopwords stripped)."""
    return [t for t in _tokens(text) if t not in _REF_STOPWORDS]


def _ref_pattern(phase_id: str) -> Optional[re.Pattern]:
    """A regex matching any human spelling of `phase_id` — "technical_questions"
    matches "technical questions", "technical-questions", "technicalquestions"."""
    toks = _tokens(phase_id)
    if not toks:
        return None
    return re.compile(r"[^a-z0-9]*".join(re.escape(t) for t in toks))


# A NAME match is acted on; anything weaker is a guess that gets confirmed.
# WHY the split: "make the system architecture round more engaging" resolves to
# technical_questions only because that phase's INTENT mentions architecture —
# a reasonable inference, but not something to silently rewrite a phase on. The
# admin asked for exactly this behaviour: "there is no system architecture, you
# mean technical round?"
CONFIDENT_REF = 0.9      # the phase's own name is in the text
PLAUSIBLE_REF = 0.45     # worth naming as a guess in the question


def resolve_phase_ref(
    text: str, phases: list[dict],
) -> tuple[Optional[str], float, list[str]]:
    """Which phase does `text` refer to?

    Returns (confident_id, score, ranked_ids). `confident_id` is set ONLY when the
    phase's own NAME is in the text (score >= CONFIDENT_REF) and nothing else comes
    close — otherwise it is None and `ranked_ids` carries the best guesses, best
    first, for the caller to ASK about.

    Ladder (id evidence always outranks intent evidence, because an id is what the
    admin was shown):
      1.00  separator-insensitive id appears in the text  ("wrapup" → wrap_up)
      0.95  every significant id token appears, any order ("questions technical")
      0.85+ close typo on the squashed id                 ("warumup" → warm_up)
      0.50+ SOME id tokens appear                         ("technical round")
      0.45+ overlap with the phase's INTENT wording       ("system architecture")
    """
    squashed_text = _squash(text)
    text_signif = set(_signif(text))
    scores: dict[str, float] = {}

    def bump(pid: str, score: float) -> None:
        if score > scores.get(pid, 0.0):
            scores[pid] = score

    for p in phases:
        pid = p.get("id") or ""
        if not pid:
            continue
        id_squashed = _squash(pid)
        id_tokens = [t for t in _tokens(pid) if t not in _REF_STOPWORDS] or _tokens(pid)

        # 1. the id itself, any spelling. Guarded at 4 chars so a short id can't
        #    hit on an unrelated substring ("coding" inside "decoding").
        if len(id_squashed) >= 4 and id_squashed in squashed_text:
            bump(pid, 1.0)
            continue

        # 2/3. how much of the id's own vocabulary is present.
        if id_tokens:
            hits = sum(1 for t in id_tokens if t in text_signif)
            if hits == len(id_tokens):
                bump(pid, 0.95)
                continue
            if hits:
                bump(pid, 0.5 + 0.4 * (hits / len(id_tokens)))

        # 4. the admin described the phase by its PURPOSE ("system architecture"
        #    → the phase whose intent talks about architecture) rather than name.
        intent_signif = set(_signif(p.get("intent") or ""))
        if intent_signif and text_signif:
            shared = text_signif & intent_signif
            if shared:
                bump(pid, 0.45 + 0.3 * (len(shared) / len(text_signif)))

        # 5. typo tolerance on the NAME — "warumup" is warm_up misspelt, and the
        #    admin should not have to retype it. Gated tight (0.85) so genuinely
        #    different names ("wrapup" vs "warmup", ratio ~0.67) never collide.
        if id_squashed:
            import difflib
            for window in _signif(text):
                ratio = difflib.SequenceMatcher(None, window, id_squashed).ratio()
                if ratio >= 0.85:
                    bump(pid, 0.85 + 0.14 * ratio)

    if not scores:
        return None, 0.0, [str(p.get("id")) for p in phases if p.get("id")]

    ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
    ranked_ids = [pid for pid, _ in ranked]
    best_id, best_score = ranked[0]
    # A near-tie is NOT a match — "the technical one" against two technical
    # phases must ask, not coin-flip.
    if len(ranked) > 1 and best_score - ranked[1][1] < 0.06:
        return None, best_score, ranked_ids[:3]
    if best_score < CONFIDENT_REF:
        return None, best_score, ranked_ids[:3]
    return best_id, best_score, ranked_ids[1:3]


def find_best_phase_match(text: str, phases: list[dict]) -> tuple[Optional[str], float]:
    """Back-compat wrapper over `resolve_phase_ref`."""
    pid, score, _ = resolve_phase_ref(text, phases)
    return pid, score


def find_phase_refs(text: str, phases: list[dict]) -> list[tuple[int, str]]:
    """Every phase named in `text`, as (position, phase_id) in reading order.

    Reorder instructions are positional ("move X before Y"), so the ORDER the
    names appear in is the signal — which means we need positions, not a set."""
    found: list[tuple[int, str]] = []
    low = (text or "").lower()
    for p in phases:
        pid = p.get("id") or ""
        pat = _ref_pattern(pid)
        if not pat:
            continue
        m = pat.search(low)
        if m:
            found.append((m.start(), pid))
    return sorted(found)


# Phrases that scope a duration ask to the INTERVIEW rather than to one phase.
_WHOLE_INTERVIEW_MARKERS = (
    "whole interview", "entire interview", "full interview", "overall interview",
    "the interview", "whole thing", "total duration", "total interview",
    "total time", "total length", "overall duration", "overall length",
    "interview total", "interview duration", "interview length", "end to end",
)


def is_whole_interview_scope(text: str) -> bool:
    """True when a duration ask targets the interview as a whole. Deterministic,
    so an explicit "make the whole interview 15 min" is NEVER downgraded to a
    question the admin has already answered."""
    low = " ".join(_tokens(text))
    if any(" ".join(_tokens(m)) in low for m in _WHOLE_INTERVIEW_MARKERS):
        return True
    # "make it 15 minutes total" / "15 min overall"
    return bool(re.search(r"\b(total|overall|altogether|in all)\b", low))


def extract_context_for_instruction(text: str) -> bool:
    """Check if THIS instruction mentions resume/project/experience — context-trigger words.

    Return True ONLY if context should be attached to this instruction."""
    trigger_terms = ("project", "resume", "experience", "skills", "work", "background",
                     "portfolio", "example", "candidate's")
    return any(t in text.lower() for t in trigger_terms)


# ══════════════════════════════════════════════════════════════════════════════
# Structure ops (remove / reorder / add) — deterministic, zero LLM
# ══════════════════════════════════════════════════════════════════════════════
#
# Structure is a LIST OPERATION, not a language task. Handing "remove the wrap-up
# phase" to a content editor that can only rewrite a phase's questions is what
# produced "wrap_up: questions updated" for a phase the admin asked to delete.
# These ops run in code, before any LLM sees the turn, and each one reports what
# it did in the admin's own terms.

_REMOVE_VERBS = ("remove", "delete", "drop", "eliminate", "get rid of", "take out",
                 "exclude", "skip", "cut out", "without")
_ADD_VERBS = ("add", "insert", "include", "put back", "bring back", "re-add", "readd",
              "restore", "append", "create")
_REORDER_VERBS = ("move", "swap", "reorder", "re-order", "rearrange", "shift", "put")


# ── Phases the editor must not create, as DATA ────────────────────────────────
# Each entry carries an `intent` (what the phase IS) and a `reason` (what the
# admin is told). There are deliberately NO alias/keyword lists: which phase an
# admin means is matched on MEANING by the phase RESOLVER
# (`phase_resolver_agent.py`), because word matching cannot tell "add a coding
# phase" (needs question ids → the picker) from "add a coding discussion" (an
# ordinary conversation phase), and every phase added here would otherwise need
# its own hand-maintained spellings. See config/phase_blacklist.json.
_BLACKLIST_PATH = Path(__file__).resolve().parents[2] / "config" / "phase_blacklist.json"


@lru_cache(maxsize=1)
def load_phase_blacklist() -> tuple[dict, ...]:
    """[{id, intent, reason}, ...] of phases the editor refuses to create.

    Cached — it's read-only config. A missing or malformed file yields an EMPTY
    blacklist and a warning, never an exception: losing the coding-picker pointer
    degrades one refusal's wording, while raising here would break every edit."""
    try:
        raw = json.loads(_BLACKLIST_PATH.read_text(encoding="utf-8"))
        entries = []
        for e in raw.get("blocked") or []:
            pid = str(e.get("id") or "").strip()
            reason = str(e.get("reason") or "").strip()
            if not pid or not reason:
                continue
            entries.append({"id": pid, "intent": str(e.get("intent") or "").strip(),
                            "reason": reason})
        return tuple(entries)
    except Exception as e:
        logger.warning("[phase_tools] no usable phase blacklist at %s (%s) — "
                       "nothing is blocked from creation", _BLACKLIST_PATH, e)
        return ()


def blacklist_entry(phase_id: str) -> Optional[dict]:
    """The blocked-phase entry for an id the RESOLVER returned, or None."""
    for entry in load_phase_blacklist():
        if entry["id"] == phase_id:
            return entry
    return None


# The code-review phase: a conversation about code the candidate already wrote, so
# unlike the coding round it needs nothing from the picker. Its body is NOT defined
# here — it already exists (`cadence_service.CODE_DISCUSSION_PHASE`) and arrives
# through the phase CATALOG, so adding it restores a real definition rather than
# generating one. The id is named because ONE rule keys off it: a review with no
# coding round to review gets confirmed rather than assumed.
CODE_DISCUSSION_ID = "code_discussion"


def has_coding_round(phases: list[dict]) -> bool:
    """Is there a real coding EXERCISE (not a discussion) in the plan?

    Keyed on `coding_question_ids`, which is what actually makes a phase open the
    code editor — an id containing "coding" is not enough (`code_discussion` is a
    conversation)."""
    return any(
        (p or {}).get("coding_question_ids") or (p or {}).get("coding_question_id")
        for p in phases
    )


def _is_coding_phase(phase_id: str, body: dict) -> bool:
    """A coding EXERCISE phase — never restorable/creatable here (needs question
    ids from the picker). `code_discussion` is deliberately NOT one of these."""
    if (phase_id or "").lower() == CODE_DISCUSSION_ID:
        return False
    if "coding" in (phase_id or "").lower():
        return True
    return bool((body or {}).get("coding_question_ids") or (body or {}).get("coding_question_id"))


def _pretty(phase_id: str) -> str:
    """`wrap_up` → "wrap-up", for admin-facing sentences."""
    return (phase_id or "").replace("_", "-")


# Words that are part of HOW the admin asked, never part of the phase's name.
# Broader than _REF_STOPWORDS on purpose: this is naming a new phase, so anything
# procedural has to come out or we'd end up with an id like `add_a_new_round`.
_NAMING_NOISE = frozenset({
    "add", "insert", "include", "create", "new", "another", "also", "please",
    "can", "could", "you", "i", "we", "want", "need", "like", "lets", "let",
    "us", "the", "a", "an", "some", "phase", "round", "section", "stage", "step",
    "part", "segment", "block", "for", "of", "to", "on", "about", "and", "with",
    "it", "its", "this", "that", "make", "set", "min", "mins", "minute",
    "minutes", "sec", "secs", "second", "seconds", "long", "duration", "cover",
    "covering", "focus", "focused", "should", "would", "interview", "candidate",
})

# Affirmatives that mean "yes, do it anyway". Deterministic because the QUESTION
# offers this as a clickable option, so the text comes back predictably — but
# typed answers are covered too.
_AFFIRMATIVE_RE = re.compile(
    r"\b(yes|yeah|yep|yup|sure|ok|okay|please\s+do|go\s+ahead|do\s+it|"
    r"create\s+it|add\s+it|on\s+its\s+own|without|anyway|standalone|alone)\b",
    re.IGNORECASE,
)
_NEGATIVE_RE = re.compile(
    r"\b(no|nope|don'?t|do\s+not|cancel|never\s?mind|nevermind|leave\s+it|"
    r"i'?ll\s+add|from\s+the\s+picker|use\s+the\s+picker)\b",
    re.IGNORECASE,
)


def reads_as_confirmation(text: str) -> bool:
    """Did the admin say yes to a yes/no question we asked?

    A NEGATIVE wins over an affirmative, because the clarification text replays
    the original ask alongside the answer — "add a code discussion" + "no, I'll
    add a coding phase from the picker" contains add-ish words either way, and
    reading that as consent would create the very thing they declined."""
    if _NEGATIVE_RE.search(text or ""):
        return False
    return bool(_AFFIRMATIVE_RE.search(text or ""))


def reads_as_decline(text: str) -> bool:
    """Did the admin say NO to a yes/no question we asked?

    Distinct from `not reads_as_confirmation(...)`, which is also true for a first
    ask that contains no answer at all. Without this the decline re-ran the same
    question forever — the admin clicks "no" and is asked again."""
    return bool(_NEGATIVE_RE.search(text or ""))


# Ids that mean "the phase where we review the candidate's code". Mirrors
# `cadence_service._CODE_DISCUSSION_IDS`; suffixed variants exist because
# `append_coding_phase` uniquifies on collision (code_discussion_2).
_CODE_DISCUSSION_IDS = ("code_discussion", "coding_review", "code_review")


def find_code_discussion(phases: list[dict]) -> Optional[str]:
    """The id of the code-review phase already in `phases`, or None."""
    for p in phases:
        pid = str((p or {}).get("id") or "").lower()
        if any(pid == d or pid.startswith(d + "_") for d in _CODE_DISCUSSION_IDS):
            return str(p.get("id"))
    return None


def derive_phase_id(text: str, existing: set) -> Optional[str]:
    """A snake_case phase id from the admin's own words, unique against `existing`.

    "add a system design round" → `system_design`. Returns None when nothing
    name-like survives (e.g. "add a phase"), because a phase we can't even name
    is one to ask about rather than create."""
    words = [w for w in _tokens(text) if w not in _NAMING_NOISE and not w.isdigit()]
    if not words:
        return None
    base = "_".join(words[:3])          # 3 words is plenty for a phase name
    if not re.match(r"^[a-z][a-z0-9_]*$", base):
        base = re.sub(r"[^a-z0-9_]", "", base)
        if not base or not base[0].isalpha():
            return None
    if base not in existing:
        return base
    n = 2
    while f"{base}_{n}" in existing:
        n += 1
    return f"{base}_{n}"


def _insert_before_wrap_up(phases: list[dict], new_phase: dict) -> list[dict]:
    """Put a new phase in before any closing phase, so wrap-up stays last.

    Mirrors `cadence_service._insert_idx_before_wrap_up` — a new round belongs in
    the body of the interview, never after the goodbye."""
    out = list(phases)
    for i, p in enumerate(out):
        pid = (p.get("id") or "").lower()
        if pid.startswith("wrap_up") or pid.startswith("wrapup") or pid.startswith("closing"):
            out.insert(i, new_phase)
            return out
    return out + [new_phase]


@dataclass
class StructureOp:
    """One deterministic structural edit, already resolved against the real plan.

    `ok=False` means we understood the VERB but not the target (or the target is
    something we refuse) — the orchestrator turns that into a question or a
    capability message instead of a silent no-op, which is exactly what used to
    go wrong."""

    kind: str                       # "remove" | "reorder" | "add" | "create"
    ok: bool
    phase_id: Optional[str] = None
    message: str = ""               # admin-facing outcome, on success
    question: str = ""              # admin-facing question, when ok=False
    options: list[str] = field(default_factory=list)
    beyond_capability: bool = False
    # For "add"/"create": the phase body to insert. An add carries a real
    # definition (from the catalog, or a canonical builder) or it doesn't happen —
    # that is the line between putting a phase back and inventing one. For
    # "create" this is a SKELETON whose content the modifying agent then authors.
    phase_def: Optional[dict] = None
    # A part of the SAME clause that we applied but could not fully honour, e.g.
    # "add wrapup phase and coding phase" — the wrap-up lands, the coding half is
    # reported instead of being silently dropped with the rest of the clause.
    extra_refusal: str = ""
    # "create" only: what the admin said this phase should cover, passed to the
    # modifying agent as the authoring brief. Empty means "work from the name".
    brief: str = ""


# Positional words that mean an instruction is about ORDER, not membership.
_POSITIONAL_RE = re.compile(r"\b(before|after|first|last|start|beginning|end)\b")

# Structure verbs, for stripping before a DURATION parse. Several of them
# ("add", "drop", "cut") double as relative-duration markers, so leaving them in
# makes "add the wrap-up phase and make it 3 minutes" look like a relative ask.
_STRUCTURE_VERB_RE = re.compile(
    r"\b(add|insert|include|re-?add|restore|append|create|bring|put|back|move|swap"
    r"|switch|reorder|re-order|rearrange|shift|remove|delete|drop|eliminate)\b",
    re.IGNORECASE,
)


def _strip_structure_verbs(text: str) -> str:
    return _STRUCTURE_VERB_RE.sub(" ", text or "")


# An add/insert verb followed straight by a NUMBER is adding TIME, not a phase:
# "add 2 minutes", "add another 30 seconds". Contrast "add the wrap up phase and
# make it 3 minutes", where the verb is followed by the phase it names.
# WHY this matters: "add" alone made the STRUCTURE step claim the clause before the
# duration step ever ran, so "add 2 minutes to the warm up" answered "the warm-up
# phase is already in this plan" and added no time at all.
_ADDS_TIME_RE = re.compile(
    r"\b(?:add|insert|append|include|increase|extend|lengthen|reduce|cut|trim|shorten)"
    r"(?:\s+(?:by|another|an?\s+extra|extra|about|around))?\s+\d",
    re.IGNORECASE,
)


def is_time_change_ask(text: str) -> bool:
    """True when the ask changes a DURATION rather than the phase list.

    Requires both a time-verb-then-number shape AND a parseable duration, so
    "add 2 questions about caching" (a content ask) is not mistaken for one."""
    if not _ADDS_TIME_RE.search(text or ""):
        return False
    return (parse_absolute_duration_target([text]) is not None
            or parse_relative_duration_delta([text]) is not None)


def detect_structure_verb(text: str) -> Optional[str]:
    """"remove" | "add" | "reorder" | None — which list operation was asked for.

    Returns None for a DURATION ask, even one worded with an add/remove verb — see
    `is_time_change_ask`. Structure means the phase LIST; time is arithmetic."""
    if is_time_change_ask(text):
        return None
    low = f" {' '.join(_tokens(text))} "
    # Remove is checked first: "remove the coding phase and add the wrap-up back"
    # is two clauses, and the router splits them; within ONE clause the remove
    # verb is the operative one.
    if any(f" {' '.join(_tokens(v))} " in low for v in _REMOVE_VERBS):
        return "remove"
    if any(f" {' '.join(_tokens(v))} " in low for v in _ADD_VERBS):
        return "add"
    # SPLIT phrasal verbs — "put the wrap-up BACK", "bring wrap_up BACK". The
    # contiguous check above can't see these because the phase name sits between
    # the two words, and "put" alone would otherwise read as a reorder.
    # A positional word means they really do mean order ("put warm-up back FIRST").
    if (re.search(r"\bback\b", low) and re.search(r"\b(put|bring|get|have|restore)\b", low)
            and not _POSITIONAL_RE.search(low)):
        return "add"
    if any(f" {' '.join(_tokens(v))} " in low for v in _REORDER_VERBS):
        return "reorder"
    return None


# Only a close NAME match is worth confirming as a restore. Intent overlap scores
# 0.45-0.75, which is how "add a system design round" used to come back as "did
# you mean resume-deep-dive?" — a baffling guess. Above this bar it's a typo on a
# real name ("add the warumup back"); below it, the admin wants a NEW phase.
_ADD_GUESS_REF = 0.85


def _plan_add(
    text: str, phases: list[dict], catalog: dict,
    resolution: Optional[dict] = None,
) -> StructureOp:
    """Act on an ADD ask that the RESOLVER has already placed.

    `resolution` is {phase_ids, new_name, covers} from `PhaseResolverAgent` — the
    one language judgement in an add ("which phase do they mean?"), made on the
    candidate phases' INTENTS rather than their spellings. Everything from here is
    deterministic: which branch each phase falls into, the arithmetic, and the
    insert.

    `phase_ids` may name SEVERAL phases, because one clause legitimately can ("add
    the wrap-up and a coding phase" reliably arrives merged). Each is answered:
    the first actionable one is applied and a blocked one still gets its refusal,
    so no half of the ask is dropped.

    No resolution means we could not place the ask, so the admin is ASKED. This
    fails CLOSED on purpose — a wrong silent add is the failure this layer exists
    to prevent, and guessing here is what produced "did you mean resume-deep-dive?"
    for "add a system design round".

      resolved to a phase in the plan  → say it's already there
      resolved to a BLOCKED phase      → refuse with that entry's own reason
      resolved to an available phase   → restore the real body
      resolved to nothing (a new phase)→ CREATE, once we know duration + coverage
    """
    present = {p.get("id") for p in phases}
    # Only MISSING phases can be added back. A coding EXERCISE is never restorable —
    # it needs question ids only the picker can attach.
    restorable = {
        pid: body for pid, body in catalog.items()
        if pid not in present and not _is_coding_phase(pid, body)
    }

    if not resolution:
        known = [_pretty(p) for p in sorted(restorable)]
        tail = (" I can add these back: " + ", ".join(known) + ".") if known else ""
        return StructureOp(
            kind="add", ok=False,
            question=(f'I\'m not sure which phase "{text.strip()}" means.{tail} '
                      "Could you name it, or say what it should cover?"),
            options=known[:4],
        )

    ids = [i for i in (resolution.get("phase_ids") or []) if i]
    # Partition by what CAN be done with each, keeping the admin's mention order.
    wanted_restorable = [i for i in ids if i in restorable]
    wanted_present = [i for i in ids if i in present]

    # Two different ways a named phase can be un-addable, both answered the same:
    #   - it's on the blacklist (config/phase_blacklist.json), or
    #   - we hold a definition for it but it's a coding EXERCISE, so it was kept
    #     out of `restorable` — restoring it without question ids would produce a
    #     coding phase that never opens an editor.
    def _refusal_for(pid: str) -> str:
        entry = blacklist_entry(pid)
        if entry:
            return entry["reason"]
        if pid in catalog and _is_coding_phase(pid, catalog[pid]):
            # Reuse the blacklist's wording for the coding round — one sentence,
            # maintained in one place, whichever coding phase was named.
            coding = next((e for e in load_phase_blacklist()
                           if _is_coding_phase(e["id"], {})), None)
            if coding:
                return coding["reason"]
            return ("I can't add a coding phase from here — it needs coding "
                    "questions attached. Use the coding-question picker at the top "
                    "of this page.")
        return ""

    # A blocked phase named alongside a doable one is reported WITH it rather than
    # replacing it — refusing the whole clause is what silently lost the wrap-up
    # from "add wrapup phase and coding phase".
    refusals = [r for r in (_refusal_for(i) for i in ids if i not in present) if r]
    blocked = {"reason": refusals[0]} if refusals else None

    # ── nothing actionable, and it's already here ───────────────────────────
    if wanted_present and not wanted_restorable:
        if blocked:
            return StructureOp(kind="add", ok=False, beyond_capability=True,
                               question=blocked["reason"])
        pid = wanted_present[0]
        # "add two questions about caching to the technical round" is an add whose
        # object is CONTENT, not a phase — the phase is where it goes. Answering
        # "that phase is already in this plan" is a dead end for a perfectly
        # doable ask, so it's handed to the content editor instead. The signal is
        # the resolver's `covers`: it names what to add, and is empty when the ask
        # was only about membership ("add the wrap-up phase" when it's present).
        if (resolution.get("covers") or "").strip():
            return StructureOp(kind="content", ok=True, phase_id=pid)
        return StructureOp(
            kind="add", ok=False,
            question=f"The {_pretty(pid)} phase is already in this plan — "
                     "did you mean to change it instead?",
            options=[f"leave {_pretty(pid)} as it is"],
        )

    # ── a phase we hold a real definition for ───────────────────────────────
    if wanted_restorable:
        pid = wanted_restorable[0]
        body = dict(restorable[pid])
        # A code REVIEW with no coding round to review would prompt the candidate
        # to walk through a submission that never happened. That is worth one
        # question rather than an assumption.
        if pid == CODE_DISCUSSION_ID and not has_coding_round(phases):
            if reads_as_decline(text):
                # They chose the picker. Saying so ENDS the exchange — re-asking
                # the same question is how this looped before.
                return StructureOp(
                    kind="add", ok=False, beyond_capability=True,
                    question=(
                        "Left the code discussion out. Add a coding phase with the "
                        "coding-question picker at the top of this page and I'll add "
                        "the discussion alongside it."
                    ),
                )
            if not reads_as_confirmation(text):
                return StructureOp(
                    kind="add", ok=False,
                    question=(
                        "There's no coding phase in this plan for a code discussion "
                        "to review. You can add one with the coding-question picker "
                        "at the top of this page — or shall I still add the "
                        "code-discussion phase?"
                    ),
                    options=["yes, add the code discussion",
                             "no, I'll add a coding phase from the picker"],
                )
        # "back" only when it really was removed from THIS plan. The code
        # discussion is offered from the catalog to every plan, so "added back"
        # would claim a history the interview never had.
        back = "" if pid == CODE_DISCUSSION_ID else " back"
        return StructureOp(
            kind="add", ok=True, phase_id=pid, phase_def=body,
            message=f"Added the {_pretty(pid)} phase{back}",
            extra_refusal=blocked["reason"] if blocked else "",
        )

    # ── only blocked phases were named ──────────────────────────────────────
    if blocked:
        return StructureOp(kind="add", ok=False, beyond_capability=True,
                           question=blocked["reason"])

    # ── a genuinely NEW phase ────────────────────────────────────────────────
    new_id = derive_phase_id(
        resolution.get("new_name") or text, set(present) | set(catalog),
    )
    if new_id is None:
        return StructureOp(
            kind="create", ok=False,
            question=("What should the new phase be called, and what should it "
                      f'cover? I couldn\'t work out a name from "{text.strip()}".'),
        )

    # Two things are needed, and NEITHER is invented:
    #   duration — parsed in CODE (an exact number is never a model's job), and it
    #              changes the interview's length, so it can't be defaulted.
    #   coverage — what the phase is actually for. Without it the content would be
    #              authored from a bare name, which is guessing at the admin's
    #              intent. The resolver reports it; it is deliberately not filled
    #              in from the phase name.
    duration = parse_absolute_duration_target([_strip_structure_verbs(text)])
    covers = (resolution.get("covers") or "").strip()
    if duration is None or not covers:
        # No clickable options here on purpose: a duration chip answers only half
        # the question, and accepting it would create the phase with its content
        # authored from nothing but the name.
        if duration is None and not covers:
            need = ("How long should it be, and what should it cover?")
        elif duration is None:
            need = "How long should it be?"
        else:
            need = f"It's set to {fmt_dur(duration)} — what should it cover?"
        return StructureOp(
            kind="create", ok=False, phase_id=new_id,
            question=f"I can add a {_pretty(new_id)} phase. {need}",
        )

    pretty = _pretty(new_id).replace("-", " ")
    return StructureOp(
        kind="create", ok=True, phase_id=new_id,
        phase_def={
            "id": new_id,
            "duration_s": duration,
            # Placeholders only — the MODIFYING agent authors both from `brief`.
            # Schema-valid on their own, so an LLM failure leaves a usable phase
            # rather than a plan that will not load.
            "intent": f"Assess the candidate on {pretty}.",
            "question_mode": "generic",
            "generic_prompts": [f"Explore the candidate's experience with {pretty}."],
        },
        brief=covers,
        message=f"Added a new {_pretty(new_id)} phase, set to {fmt_dur(duration)}",
    )


def plan_structure_op(
    text: str, phases: list[dict], catalog: Optional[dict] = None,
    resolution: Optional[dict] = None,
) -> Optional[StructureOp]:
    """Read one instruction as a structure op. None means "not a structure ask".

    `catalog` is {phase_id: phase_dict} of phases that are KNOWN — the saved plan
    plus the built-in default cadence. It is what makes "add the wrap-up back"
    work without inventing anything: a removed phase is RESTORED from its real
    definition, while a name that appears in no catalog is still refused."""
    kind = detect_structure_verb(text)
    if kind is None:
        return None

    if kind == "add":
        return _plan_add(text, phases, catalog or {}, resolution)

    refs = find_phase_refs(text, phases)

    refs = find_phase_refs(text, phases)
    pid, score, candidates = resolve_phase_ref(text, phases)

    if kind == "remove":
        target = pid or (refs[0][1] if len(refs) == 1 else None)
        if target is None:
            q, opts = ask_which_phase(text, phases, candidates, score,
                                      what="the phase you want removed")
            return StructureOp(kind="remove", ok=False, question=q, options=opts)
        if len(phases) <= 1:
            return StructureOp(
                kind="remove", ok=False, beyond_capability=True,
                question=(
                    f"I can't remove {_pretty(target)} — it's the only phase left, and an "
                    "interview needs at least one."
                ),
            )
        return StructureOp(kind="remove", ok=True, phase_id=target,
                           message=f"Removed the {_pretty(target)} phase")

    # ── reorder ───────────────────────────────────────────────────────────
    low = " ".join(_tokens(text))
    if len(refs) >= 2:
        a, b = refs[0][1], refs[1][1]
        if "swap" in low or "switch" in low:
            return StructureOp(kind="reorder", ok=True, phase_id=a,
                               message=f"Swapped {_pretty(a)} and {_pretty(b)}")
        if "before" in low:
            return StructureOp(kind="reorder", ok=True, phase_id=a,
                               message=f"Moved {_pretty(a)} before {_pretty(b)}")
        if "after" in low:
            return StructureOp(kind="reorder", ok=True, phase_id=a,
                               message=f"Moved {_pretty(a)} after {_pretty(b)}")
        return StructureOp(
            kind="reorder", ok=False,
            question=(
                f"Should {_pretty(a)} go before or after {_pretty(b)}?"
            ),
            options=[f"{_pretty(a)} before {_pretty(b)}", f"{_pretty(a)} after {_pretty(b)}"],
        )
    if len(refs) == 1 and _POSITIONAL_RE.search(low):
        target = refs[0][1]
        where = "first" if re.search(r"\b(first|start|beginning)\b", low) else "last"
        return StructureOp(kind="reorder", ok=True, phase_id=target,
                           message=f"Moved {_pretty(target)} to the {where} position")
    return StructureOp(
        kind="reorder", ok=False,
        question=f'Which phases should move, and where? (for "{text.strip()}")',
        options=[str(p.get("id")) for p in phases if p.get("id")][:4],
    )


def apply_structure_op(
    op: StructureOp, text: str, phases: list[dict],
    catalog: Optional[dict] = None,
) -> Optional[list[dict]]:
    """Execute a resolved op against `phases`. Returns the new list, or None if
    it can't be executed (caller then reports it rather than pretending)."""
    if not op.ok or not op.phase_id:
        return None

    if op.kind == "add":
        if not op.phase_def:
            return None                      # nothing real to insert
        restored = dict(op.phase_def, id=op.phase_id)
        return _insert_by_catalog_order(restored, text, phases, catalog or {})

    if op.kind == "create":
        if not op.phase_def:
            return None
        fresh = dict(op.phase_def, id=op.phase_id)
        # An explicit "before/after X" (or first/last) still wins; a brand-new
        # phase has no catalog position to fall back on, so it lands in the body
        # of the interview rather than after the goodbye.
        low = " ".join(_tokens(text))
        if find_phase_refs(text, phases) and ("before" in low or "after" in low):
            return _insert_by_catalog_order(fresh, text, phases, catalog or {})
        if re.search(r"\b(first|start|beginning)\b", low):
            return [fresh] + list(phases)
        if re.search(r"\b(last|end)\b", low):
            return list(phases) + [fresh]
        return _insert_before_wrap_up(phases, fresh)

    ids = [p.get("id") for p in phases]
    if op.phase_id not in ids:
        return None

    if op.kind == "remove":
        return [p for p in phases if p.get("id") != op.phase_id]

    low = " ".join(_tokens(text))
    refs = find_phase_refs(text, phases)

    if len(refs) >= 2:
        a, b = refs[0][1], refs[1][1]
        if a == b:
            return None
        if "swap" in low or "switch" in low:
            out = list(phases)
            ia = next(i for i, p in enumerate(out) if p.get("id") == a)
            ib = next(i for i, p in enumerate(out) if p.get("id") == b)
            out[ia], out[ib] = out[ib], out[ia]
            return out
        if "before" in low or "after" in low:
            moving = next(p for p in phases if p.get("id") == a)
            rest = [p for p in phases if p.get("id") != a]
            tgt = next(i for i, p in enumerate(rest) if p.get("id") == b)
            rest.insert(tgt if "before" in low else tgt + 1, moving)
            return rest
        return None

    if len(refs) == 1 and _POSITIONAL_RE.search(low):
        moving = next(p for p in phases if p.get("id") == op.phase_id)
        rest = [p for p in phases if p.get("id") != op.phase_id]
        if re.search(r"\b(first|start|beginning)\b", low):
            return [moving] + rest
        return rest + [moving]
    return None


def _insert_by_catalog_order(
    restored: dict, text: str, phases: list[dict], catalog: dict,
) -> list[dict]:
    """Put a restored phase back where it belongs.

    "before/after X" wins when the admin said it. Otherwise the CATALOG's own
    ordering decides, which is why "add the wrap-up back" lands at the end rather
    than wherever the list happened to be shortest — wrap_up is last in the
    catalog, so it goes last."""
    low = " ".join(_tokens(text))
    refs = [pid for _pos, pid in find_phase_refs(text, phases)]
    if refs and ("before" in low or "after" in low):
        anchor = refs[0]
        out = list(phases)
        idx = next(i for i, p in enumerate(out) if p.get("id") == anchor)
        out.insert(idx if "before" in low else idx + 1, restored)
        return out
    if re.search(r"\b(first|start|beginning)\b", low):
        return [restored] + list(phases)
    if re.search(r"\b(last|end)\b", low):
        return list(phases) + [restored]

    order = list(catalog)
    if restored.get("id") not in order:
        return list(phases) + [restored]
    home = order.index(restored["id"])
    out = list(phases)
    for i, p in enumerate(out):
        pid = p.get("id")
        if pid in order and order.index(pid) > home:
            out.insert(i, restored)
            return out
    return out + [restored]


def detect_and_apply_phase_mutations(
    instructions: list[str], phases: list[dict],
) -> tuple[list[dict], list[str]]:
    """Back-compat shim: apply every structure op we can, return
    (new_phases, instructions_we_could_not_apply).

    Prefer `plan_structure_op` + `apply_structure_op` in new code — they also
    carry the admin-facing message and question, which this shape throws away."""
    result = list(phases)
    remaining: list[str] = []
    for inst in instructions:
        op = plan_structure_op(inst, result)
        if op is None:
            remaining.append(inst)
            continue
        applied = apply_structure_op(op, inst, result) if op.ok else None
        if applied is None:
            remaining.append(inst)
        else:
            result = applied
    return result, remaining


# ══════════════════════════════════════════════════════════════════════════════
# The deterministic pre-pass — decides what the LLM is even needed for
# ══════════════════════════════════════════════════════════════════════════════


def ask_which_phase(
    text: str, phases: list[dict], ranked: list[str], score: float, what: str = "",
) -> tuple[str, list[str]]:
    """A GROUNDED "which phase?" question, plus its clickable options.

    When there's a plausible guess the question NAMES it — "there's no HR round;
    did you mean warm-up?" is answerable in one click, where a bare "which phase?"
    makes the admin do the mapping the system already did. This is the shape the
    admin asked for after seeing the editor reject "hr round" outright."""
    all_ids = [str(p.get("id")) for p in phases if p.get("id")]
    subject = what or f'"{text.strip()}"'
    if ranked and score >= PLAUSIBLE_REF:
        guess = _pretty(ranked[0])
        others = [_pretty(r) for r in ranked[1:3]]
        tail = f", or {' or '.join(others)}" if others else ""
        return (
            f"There's no phase by that name in this plan. For {subject}, "
            f"did you mean the {guess} phase{tail}?"
        ), [_pretty(r) for r in ranked[:3]] or all_ids[:4]
    return (
        f"Which phase should {subject} apply to? This plan has: "
        + ", ".join(_pretty(i) for i in all_ids) + "."
    ), [_pretty(i) for i in all_ids[:4]]


@dataclass
class ClauseOutcome:
    """What happened to ONE of the admin's instructions. This is the unit the chat
    renders, which is why it is per-INSTRUCTION and not per-phase: the admin asked
    four things and wants four answers, not a diff of every phase in the plan."""

    clause_id: str
    text: str
    status: str                 # "applied" | "asked" | "refused" | "failed"
    message: str = ""           # admin-facing sentence
    phase_id: Optional[str] = None


@dataclass
class DeterministicPlan:
    """Everything code settled before any LLM ran."""

    phases: list[dict] = field(default_factory=list)
    total_target: Optional[int] = None
    # {phase_id: seconds} — explicit per-phase durations, applied in code and
    # PINNED so a whole-interview rescale can't overwrite them.
    phase_targets: dict = field(default_factory=dict)
    outcomes: list[ClauseOutcome] = field(default_factory=list)
    # Clauses that genuinely need judgement — the only thing the modifier sees.
    content_clauses: list[dict] = field(default_factory=list)
    # Clauses code understood the shape of but not the target.
    questions: list[dict] = field(default_factory=list)
    refusals: list[dict] = field(default_factory=list)


def plan_deterministic(
    clauses: list[dict], phases: list[dict], current_total: int,
    all_phases_token: str = "ALL", catalog: Optional[dict] = None,
    add_resolutions: Optional[dict] = None,
) -> DeterministicPlan:
    """Settle every clause code can settle; hand the rest back for the LLM.

    Order matters: STRUCTURE first (a removed phase must not then be content-
    edited), then DURATIONS (which need the surviving phase list), and only what
    is left over is a content ask.

    A clause is claimed here ONLY when the resolution is unambiguous. Anything
    doubtful becomes a question — the failure we are engineering against is a
    silent wrong edit, not an extra question."""
    plan = DeterministicPlan(phases=[dict(p) for p in phases])

    for c in clauses:
        cid, text = c.get("clause_id", ""), (c.get("text") or "").strip()
        if not text:
            continue
        scope = c.get("phase_id") or ""

        # ── 1. structure ──────────────────────────────────────────────────
        op = plan_structure_op(text, plan.phases, catalog,
                               (add_resolutions or {}).get(cid))
        if op is not None and op.kind == "content" and op.ok and op.phase_id:
            # An "add" whose object turned out to be CONTENT, not a phase. Falls
            # through to the content editor with the phase already resolved.
            plan.content_clauses.append({**c, "phase_id": op.phase_id, "text": text})
            continue
        if op is not None:
            if not op.ok:
                if op.beyond_capability:
                    plan.refusals.append({"clause_id": cid, "text": text, "message": op.question})
                    plan.outcomes.append(ClauseOutcome(cid, text, "refused", op.question))
                else:
                    plan.questions.append({"clause_id": cid, "text": text,
                                           "question": op.question, "options": op.options})
                    plan.outcomes.append(ClauseOutcome(cid, text, "asked", op.question))
                continue
            applied = apply_structure_op(op, text, plan.phases, catalog)
            if applied is None:
                q = f'I couldn\'t work out how to reorder for "{text}". Which phase goes where?'
                plan.questions.append({"clause_id": cid, "text": text, "question": q,
                                       "options": [str(p.get("id")) for p in plan.phases][:4]})
                plan.outcomes.append(ClauseOutcome(cid, text, "asked", q))
                continue
            plan.phases = applied
            plan.phase_targets.pop(op.phase_id or "", None)
            message = op.message

            if op.kind == "create" and op.phase_id:
                # The skeleton is schema-valid but generic. Hand the phase to the
                # MODIFYING agent to author its intent + prompts — the one part of
                # creating a phase that genuinely needs judgement. Its duration is
                # PINNED first so that content pass can't move a number the admin
                # gave explicitly.
                plan.phase_targets[op.phase_id] = int(
                    (op.phase_def or {}).get("duration_s") or 0
                )
                plan.content_clauses.append({
                    "clause_id": cid, "phase_id": op.phase_id,
                    "text": (
                        "This is a NEW phase that was just added to the plan with "
                        "placeholder content. Write its `intent` and "
                        "`generic_prompts` so it delivers what the admin asked for: "
                        f"\"{op.brief or text}\". Keep the id and duration_s exactly "
                        "as they are."
                    ),
                })
                plan.outcomes.append(
                    ClauseOutcome(cid, text, "applied", message, op.phase_id)
                )
                continue

            # One clause can carry BOTH a structure op and a duration — "add the
            # wrap-up phase and make it 3 minutes". Consuming the clause on the
            # structure op alone silently dropped the number, which is the exact
            # class of quiet failure this layer exists to prevent. Only honoured
            # when the duration provably belongs to the phase we just touched.
            # The structure VERB has to come out first: "add" is also a relative
            # duration marker ("add 2 minutes"), so "add the wrap-up phase and
            # make it 3 minutes" parsed as relative and returned nothing.
            also = parse_absolute_duration_target([_strip_structure_verbs(text)])
            if also is not None and op.kind in ("add", "reorder") and op.phase_id:
                same, _sc, _r = resolve_phase_ref(text, plan.phases)
                if same == op.phase_id:
                    plan.phase_targets[op.phase_id] = also
                    for p in plan.phases:
                        if p.get("id") == op.phase_id:
                            p["duration_s"] = also
                    message = f"{message}, set to {fmt_dur(also)}"

            plan.outcomes.append(ClauseOutcome(cid, text, "applied", message, op.phase_id))
            if op.extra_refusal:
                plan.refusals.append({"clause_id": cid, "text": text,
                                      "message": op.extra_refusal})
                plan.outcomes.append(
                    ClauseOutcome(cid, text, "refused", op.extra_refusal)
                )
            continue

        # ── 2. duration ───────────────────────────────────────────────────
        # SCOPE IS RESOLVED BEFORE THE NUMBER, and that order is the fix for a real
        # defect: a RELATIVE ask ("reduce it by 30 seconds") has to be measured
        # against whatever it targets. This used to compute `current_total + delta`
        # up front — the INTERVIEW's total — and then assign that number to a
        # PHASE, so "reduce the warm-up by 30 seconds" on a 7:30 interview set the
        # warm-up to 7:00 and made the interview LONGER.
        absolute = parse_absolute_duration_target([text])
        delta = parse_relative_duration_delta([text]) if absolute is None else None
        if absolute is not None or delta is not None:
            whole = scope == all_phases_token or is_whole_interview_scope(text)

            # What the admin literally asked for, for any question we have to ask
            # before we know the base to apply it to.
            asked_for = (
                f"the {fmt_dur(absolute)} you asked for" if absolute is not None
                else f"the {fmt_dur(abs(delta))} you asked to "
                     f"{'add' if delta > 0 else 'take off'}"
            )

            if whole:
                target = absolute if absolute is not None else current_total + delta
                if target <= 0:
                    q = (f"Taking {fmt_dur(abs(delta))} off would leave the interview "
                         f"at or below zero (it's {fmt_dur(current_total)}). "
                         "How long should it be?")
                    plan.questions.append({"clause_id": cid, "text": text,
                                           "question": q, "options": []})
                    plan.outcomes.append(ClauseOutcome(cid, text, "asked", q))
                    continue
                if plan.total_target is not None and plan.total_target != target:
                    # Two different totals in one turn can't both hold, and an LLM
                    # asked to both NOTICE and RESOLVE that would just pick one.
                    q = (
                        f"You asked for two different interview lengths — "
                        f"{fmt_dur(plan.total_target)} and {fmt_dur(target)}. "
                        "Which should I use?"
                    )
                    plan.questions.append({
                        "clause_id": cid, "text": text, "question": q,
                        "options": [fmt_dur(plan.total_target), fmt_dur(target)],
                    })
                    plan.outcomes.append(ClauseOutcome(cid, text, "asked", q))
                    continue
                plan.total_target = target
                plan.outcomes.append(ClauseOutcome(
                    cid, text, "applied",
                    f"Set the whole interview to {fmt_dur(target)}",
                ))
                continue

            pid = scope if scope in {p.get("id") for p in plan.phases} else None
            if pid is None:
                pid, _score, candidates = resolve_phase_ref(text, plan.phases)
                if pid is None:
                    q, opts = ask_which_phase(
                        text, plan.phases, candidates, _score, what=asked_for,
                    )
                    plan.questions.append({
                        "clause_id": cid, "text": text, "question": q,
                        "options": opts[:3] + ["the whole interview"],
                    })
                    plan.outcomes.append(ClauseOutcome(cid, text, "asked", q))
                    continue

            # THE base for a relative ask: this phase's own current length.
            current = next(
                (int(p.get("duration_s") or 0) for p in plan.phases
                 if p.get("id") == pid), 0,
            )
            target = absolute if absolute is not None else current + delta
            if target <= 0:
                q = (f"The {_pretty(pid)} phase is {fmt_dur(current)}, so taking "
                     f"{fmt_dur(abs(delta))} off would leave it at or below zero. "
                     "How long should it be?")
                plan.questions.append({"clause_id": cid, "text": text,
                                       "question": q, "options": []})
                plan.outcomes.append(ClauseOutcome(cid, text, "asked", q))
                continue

            prior = plan.phase_targets.get(pid)
            if prior is not None and prior != target:
                q = (
                    f"You asked for two different lengths for the {_pretty(pid)} phase — "
                    f"{fmt_dur(prior)} and {fmt_dur(target)}. Which should I use?"
                )
                plan.questions.append({
                    "clause_id": cid, "text": text, "question": q,
                    "options": [fmt_dur(prior), fmt_dur(target)],
                })
                plan.outcomes.append(ClauseOutcome(cid, text, "asked", q))
                continue
            plan.phase_targets[pid] = target
            for p in plan.phases:
                if p.get("id") == pid:
                    p["duration_s"] = target
            plan.outcomes.append(ClauseOutcome(
                cid, text, "applied",
                f"Set the {_pretty(pid)} phase to {fmt_dur(target)}", pid,
            ))
            continue

        # ── 3. everything else is a real content ask ──────────────────────
        pid = scope if scope in {p.get("id") for p in plan.phases} else None
        if pid is None and scope != all_phases_token:
            pid, _score, candidates = resolve_phase_ref(text, plan.phases)
            if pid is None:
                q, opts = ask_which_phase(text, plan.phases, candidates, _score)
                plan.questions.append({
                    "clause_id": cid, "text": text, "question": q, "options": opts,
                })
                plan.outcomes.append(ClauseOutcome(cid, text, "asked", q))
                continue
        if pid is None:
            # An ALL-scoped clause with no number and no structure verb is not
            # something we can execute — ask rather than rewrite every phase.
            q = f'"{text}" — which phase did you want that on?'
            plan.questions.append({
                "clause_id": cid, "text": text, "question": q,
                "options": [str(p.get("id")) for p in plan.phases][:4],
            })
            plan.outcomes.append(ClauseOutcome(cid, text, "asked", q))
            continue
        plan.content_clauses.append({**c, "phase_id": pid, "text": text})

    return plan
