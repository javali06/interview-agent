"""Shared LLM plumbing for the three cadence-editor agents.

Each agent gets a `CadenceLLM` — the admin-path equivalent of the brain's
`LLMClient`. It owns the one thing all three agents do identically: make a
traced, JSON-returning chat completion and parse the result. Cost/tracing goes
through `setup_cost_tracker.trace_call` so every call lands in the interview's
"cost for setting up interview" table instead of the live interview's, and
appears in Langfuse under the interview's session id.

Deliberately NOT importing `app.cadence_service`: that module imports these
agents, so the dependency runs one way only (cadence_service → cadence_agents).
The caller resolves the provider/model and hands the built client in.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any, Optional

import yaml

logger = logging.getLogger(__name__)


def parse_llm_json(payload: str) -> dict:
    """Parse an LLM payload that is *meant* to be JSON but may arrive fenced or
    (rarely) as YAML. Strips ``` fences, tries JSON, then YAML. Returns the
    parsed mapping. Raises ValueError if neither parses to a dict."""
    text = payload.strip()
    m = re.search(r"```(?:json|ya?ml)?\s*(.*?)```", text, re.DOTALL)
    if m:
        text = m.group(1).strip()
    data = None
    try:
        data = json.loads(text)
    except Exception:
        try:
            data = yaml.safe_load(text)
        except yaml.YAMLError as ye:
            raise ValueError(f"output was neither valid JSON nor YAML: {ye}")
    if not isinstance(data, dict):
        raise ValueError("top-level output must be an object with `total_duration_s` and `phases`.")
    return data


def build_extra_body(base_url: str) -> dict:
    """OpenRouter tuning: cap hidden chain-of-thought (cadence editing is
    structured editing, not reasoning) and route by THROUGHPUT to the fast
    serving providers (Groq/Cerebras-class) instead of the cheapest. Ignored
    off-OpenRouter."""
    if "openrouter" in (base_url or ""):
        return {"reasoning": {"effort": "low"}, "provider": {"sort": "throughput"}}
    return {}


@dataclass
class CadenceLLM:
    """One traced LLM endpoint, shared by all three cadence agents.

    `purpose` is the setup-cost bucket every call is billed to; `stage` is
    appended per call so the Langfuse breakdown stays legible (router vs phase
    vs structure vs validate) while the cost table stays a single row per model.
    """

    client: Any
    model: str
    extra_body: dict = field(default_factory=dict)
    token: Optional[str] = None
    purpose: str = "revise_cadence_with_ai"

    async def complete_json(
        self, *, system: str, user: str, stage: str, temperature: float = 0.0,
    ) -> dict:
        """One traced completion, parsed as JSON. Retries ONCE without
        `response_format` because some providers/models reject it outright —
        without that fallback a provider swap silently breaks every agent.
        Raises ValueError on a call or parse failure; each agent decides what
        that means for its own path."""
        from app.setup_cost_tracker import trace_call

        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        try:
            with trace_call(
                token=self.token, purpose=self.purpose, model=self.model, input_data=messages,
            ) as finish:
                try:
                    resp = await self.client.chat.completions.create(
                        model=self.model, messages=messages, temperature=temperature,
                        response_format={"type": "json_object"}, extra_body=self.extra_body,
                    )
                except Exception:
                    resp = await self.client.chat.completions.create(
                        model=self.model, messages=messages, temperature=temperature,
                        extra_body=self.extra_body,
                    )
                finish(resp)
        except Exception as e:
            raise ValueError(f"{stage} call failed: {str(e).splitlines()[0]}") from e
        return parse_llm_json((resp.choices[0].message.content or "").strip())
