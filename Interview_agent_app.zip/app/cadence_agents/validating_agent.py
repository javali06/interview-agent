"""Validating agent (3 of 3) — the only agent that decides what the admin is told.

It answers one question per instruction: *did the thing you asked for actually
happen, and how do I say that in a sentence you'd recognise?* Both halves matter.
The editor used to derive its chat lines from a raw before/after phase diff,
which produced "resume_deep_dive: questions updated" for phases nobody mentioned
(schema defaults alone were enough to make every phase look edited) — the admin
could not tell which of their four asks had landed.

Split strictly by what each check needs:

  - NUMBERS (a phase's duration, the total) are checked and REPAIRED
    deterministically. An LLM is never asked to verify arithmetic, and both cases
    have an exact code fix: a phase given an explicit duration is re-pinned to it,
    and a total knocked off-target by those pins is reconciled by absorbing the
    difference across the phases the admin said nothing about
    (`reconcile_total_with_pins`, which keeps the result on whole minutes).

  - STRUCTURE (removed / reordered) is verified by looking at the phase list. It
    is a list operation, so "is it gone?" is a set membership test, not judgement.

  - CONTENT ("ask about their projects", "make it friendlier") is the only thing
    that needs judgement, so it costs ONE batched call carrying just the
    before/after of the phases actually touched — never the cadence YAML.

The content call runs on its OWN model handle (see `_build_cadence_llm(role=...)`)
so the model that made the edit is not the model grading it.

Whatever it can't repair comes back as `phase_shortfalls` — which the orchestrator
re-dispatches to the MODIFYING agent as a targeted re-instruction (bounded
retries) — and as an outcome the admin sees, rather than being silently accepted.

Public surface:
  ValidatingAgent.validate(...) → ValidationReport
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Optional

from engine.brain.prompts import load as load_prompt

from app.cadence_agents.base import CadenceLLM
from app.cadence_agents.phase_tools import (
    ClauseOutcome,
    fmt_dur,
    reconcile_total_with_pins,
)
from app.cadence_agents.router_agent import ALL_PHASES

logger = logging.getLogger(__name__)

VALIDATOR_SYSTEM_PROMPT = load_prompt("cadence_validator")

# The content-only slice of a phase. Duration is excluded on purpose — it's
# verified deterministically, and showing it to the content validator invites it
# to comment on timing it wasn't asked about.
_CONTENT_KEYS = ("id", "intent", "question_mode", "generic_prompts", "question_pool",
                 "coding_question_ids")


def _name_phase(summary: str, phase_id: str) -> str:
    """Guarantee the line says WHICH phase changed.

    Load-bearing for trust, not cosmetics: an instruction that never named a phase
    ("make the system architecture round more engaging") is routed by INTENT, so
    the admin's only way to catch a mis-targeted edit is the line telling them
    where it landed. Asked of the prompt too, enforced here because a prompt is a
    request and this is a requirement."""
    pretty = (phase_id or "").replace("_", "-")
    squashed = re.sub(r"[^a-z0-9]+", "", (summary or "").lower())
    if not pretty or re.sub(r"[^a-z0-9]+", "", pretty.lower()) in squashed:
        return summary
    return f"{pretty[:1].upper()}{pretty[1:]}: {summary[:1].lower()}{summary[1:]}"


def phase_content_view(phase: dict) -> dict:
    """The comparable content of a phase.

    Keys absent and keys present-but-empty are collapsed to the SAME view. This
    is load-bearing: `before` comes from raw YAML while `after` has been through
    pydantic, which injects `question_pool: []`, `coding_question_ids: []` and
    friends. Without this normalisation every phase in the plan compares unequal
    and reads as "questions updated"."""
    out = {}
    for k in _CONTENT_KEYS:
        v = phase.get(k)
        if v is None or v == [] or v == "":
            continue
        out[k] = v
    return out


@dataclass
class ValidationReport:
    data: dict
    # {phase_id: [instruction, ...]} — re-dispatch these to the MODIFYING agent.
    phase_shortfalls: dict = field(default_factory=dict)
    # One line per instruction, in the admin's terms. This IS the chat transcript.
    outcomes: list[ClauseOutcome] = field(default_factory=list)
    # [{clause_id, text, why}] — the subset that didn't land, for the warning rail.
    notes: list[dict] = field(default_factory=list)

    @property
    def satisfied(self) -> bool:
        return not self.phase_shortfalls


class ValidatingAgent:
    name = "cadence_validating_agent"

    def __init__(self, llm: CadenceLLM) -> None:
        self._llm = llm

    async def validate(
        self, *, content_clauses: list[dict], before_by_id: dict, after_data: dict,
        phase_targets: Optional[dict] = None, total_target: Optional[int] = None,
        prior_outcomes: Optional[list[ClauseOutcome]] = None,
    ) -> ValidationReport:
        """Verify the patched cadence against what was asked.

        `phase_targets` / `total_target` are what the deterministic pre-pass
        settled; re-asserting them here is the guarantee that a content edit
        couldn't have moved a number the admin pinned."""
        phase_targets = dict(phase_targets or {})
        outcomes: list[ClauseOutcome] = list(prior_outcomes or [])
        notes: list[dict] = []

        after_phases = [p for p in after_data.get("phases") or [] if isinstance(p, dict)]
        after_by_id = {p["id"]: p for p in after_phases if p.get("id")}

        # ── deterministic: re-pin every explicit per-phase duration ─────────
        for pid, target in phase_targets.items():
            if pid not in after_by_id:
                continue
            actual = int(after_by_id[pid].get("duration_s") or 0)
            if actual != target:
                after_by_id[pid]["duration_s"] = target
                logger.info("[validating_agent] re-pinned '%s' duration %ds → %ds",
                            pid, actual, target)

        rebuilt = [after_by_id.get(p["id"], p) for p in after_phases]

        # ── deterministic: the total, reconciled against those pins ─────────
        if total_target is not None:
            actual_total = sum(int(p.get("duration_s") or 0) for p in rebuilt)
            if actual_total != total_target:
                fixed = reconcile_total_with_pins(rebuilt, total_target, set(phase_targets))
                if fixed is not None:
                    logger.info("[validating_agent] reconciled total to %ds (pinned=%s)",
                                total_target, sorted(phase_targets))
                    rebuilt = fixed
                else:
                    # Both asks can't hold. Keep the more specific one (the
                    # per-phase pins) and say so plainly rather than picking
                    # silently.
                    kept = sum(int(p.get("duration_s") or 0) for p in rebuilt)
                    why = (
                        f"the per-phase lengths you asked for already add up to "
                        f"{fmt_dur(kept)}, so I kept those instead of forcing "
                        f"{fmt_dur(total_target)}"
                    )
                    notes.append({"clause_id": "total", "text": "total duration", "why": why})
                    outcomes = [
                        ClauseOutcome(o.clause_id, o.text, "failed", why, o.phase_id)
                        if o.message.startswith("Set the whole interview") else o
                        for o in outcomes
                    ]

        out_data = dict(after_data)
        out_data["phases"] = rebuilt
        out_data["total_duration_s"] = sum(int(p.get("duration_s") or 0) for p in rebuilt)
        surviving = {p.get("id") for p in rebuilt}

        # ── structure: membership is a set test, not judgement ─────────────
        for o in outcomes:
            if o.status == "applied" and o.message.startswith("Removed the") and o.phase_id:
                if o.phase_id in surviving:
                    o.status = "failed"
                    o.message = f"I could not remove the {o.phase_id} phase"
                    notes.append({"clause_id": o.clause_id, "text": o.text,
                                  "why": f"'{o.phase_id}' is still in the plan"})

        # ── LLM: every content ask, in ONE batched call ─────────────────────
        phase_shortfalls: dict[str, list[str]] = {}
        checkable = [
            c for c in content_clauses
            if c.get("phase_id") not in (None, ALL_PHASES)
            and c["phase_id"] in before_by_id and c["phase_id"] in after_by_id
        ]
        verdicts = await self._check_content(checkable, before_by_id, after_by_id) if checkable else {}

        for c in checkable:
            cid, pid, text = c.get("clause_id", ""), c["phase_id"], c["text"]
            v = verdicts.get(cid)
            if v is None:
                # No verdict — the validator was unavailable, or answered without
                # mentioning this clause. FAIL OPEN: never raise a shortfall we
                # couldn't actually verify, because a shortfall costs a retry and a
                # retry can degrade an edit that was fine. Describe it from the
                # diff, and stay silent when there's nothing to describe rather
                # than inventing either a success or a failure.
                if phase_content_view(before_by_id[pid]) != phase_content_view(after_by_id[pid]):
                    outcomes.append(ClauseOutcome(
                        cid, text, "applied",
                        f"Updated the {pid.replace('_', '-')} phase", pid,
                    ))
                else:
                    logger.info("[validating_agent] no verdict for %s and no diff on "
                                "'%s' — reporting nothing", cid, pid)
                continue
            if v["satisfied"]:
                outcomes.append(ClauseOutcome(cid, text, "applied", _name_phase(v["summary"], pid), pid))
            else:
                phase_shortfalls.setdefault(pid, []).append(text)
                outcomes.append(ClauseOutcome(cid, text, "failed", v["why"], pid))
                notes.append({"clause_id": cid, "text": text, "why": v["why"]})

        return ValidationReport(
            data=out_data, phase_shortfalls=phase_shortfalls,
            outcomes=outcomes, notes=notes,
        )

    async def _check_content(
        self, clauses: list[dict], before_by_id: dict, after_by_id: dict,
    ) -> dict:
        """The single batched call: for each content instruction, did the PATCHED
        cadence satisfy it, and how would you describe what changed?

        Returns {clause_id: {"satisfied": bool, "summary": str, "why": str}}.
        Any failure returns {} — a broken validator must never block edits the
        MODIFYING agent already applied and schema-validated."""
        touched = sorted({c["phase_id"] for c in clauses})
        payload = {
            "instructions": [
                {"id": c["clause_id"], "phase_id": c["phase_id"], "instruction": c["text"]}
                for c in clauses
            ],
            "before": [phase_content_view(before_by_id[pid]) for pid in touched],
            "after": [phase_content_view(after_by_id[pid]) for pid in touched],
        }
        try:
            obj = await self._llm.complete_json(
                system=VALIDATOR_SYSTEM_PROMPT,
                user=json.dumps(payload, ensure_ascii=False),
                stage="validate",
            )
        except ValueError as e:
            logger.warning("[validating_agent] content check failed (%s) — trusting the edits",
                           str(e).splitlines()[0])
            return {}

        items = obj.get("verdicts")
        if not isinstance(items, list):
            logger.warning("[validating_agent] no `verdicts` list in response — trusting the edits")
            return {}

        # Keyed by clause_id, so a verdict is matched by IDENTITY rather than by
        # re-matching instruction text — which is what used to make a slightly
        # reworded verdict unusable and get it silently discarded.
        known = {c["clause_id"] for c in clauses}
        out: dict[str, dict] = {}
        for it in items:
            if not isinstance(it, dict):
                continue
            cid = str(it.get("id") or "").strip()
            if cid not in known:
                continue   # a verdict for an instruction we didn't send
            satisfied = bool(it.get("satisfied"))
            summary = str(it.get("summary") or "").strip()
            why = str(it.get("why") or "").strip()
            out[cid] = {
                "satisfied": satisfied,
                "summary": summary or "Applied that change",
                "why": why or "the change doesn't appear in the plan",
            }
        return out
