"""Access administration: people, teams, the role grid, and approval chains.

Sign-in is someone else's job. These functions only change what a person who
is already in `app_users` is allowed to do. The development chooser is enough
to call them; Microsoft sign-in is not required.

The rules that are easy to get wrong live here, not in the route:
- an author and a checker are never the same person on the same team
- the last active Platform Admin cannot be switched off or un-granted
- the admin role keeps the Access permissions, or nobody could fix a mistake
- a team's chain is replaced in full; a cycle already in progress keeps the
  steps it opened with, because those were copied onto the submission
"""
from __future__ import annotations

import logging
import re
from typing import Optional

from sqlalchemy import delete, func, select
from sqlalchemy.orm import aliased

from app.constants import GLOBAL_TEAM
from app.rbac import ADMIN_PERMISSIONS, PERMISSION_LABELS, validate_permission
from db.engine import session_scope
from db.models import (
    AppApprovalStep,
    AppRole,
    AppRolePermission,
    AppTeam,
    AppUser,
    AppUserRole,
)

logger = logging.getLogger(__name__)

_AUTHOR = "pool_author"
_CHECKER = "pool_checker"
_ADMIN = "admin"
_KEY = re.compile(r"^[a-z][a-z0-9_]{0,62}$")


class AccessError(Exception):
    """A refusal the route turns into an HTTP error. `status` is the code."""

    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def _slug(name: str) -> str:
    """A team key from a display name: "Backend Engineering" -> "backend_engineering"."""
    return re.sub(r"[^a-z0-9]+", "_", (name or "").strip().lower()).strip("_")[:63]


def _iso(value) -> Optional[str]:
    return value.isoformat() if value is not None else None


def _role_team(s, role_key: str, team_key: str, *, must_be_active: bool) -> tuple[AppRole, AppTeam]:
    role = s.execute(select(AppRole).where(AppRole.key == role_key)).scalar_one_or_none()
    team = s.execute(select(AppTeam).where(AppTeam.key == team_key)).scalar_one_or_none()
    if role is None:
        raise AccessError(f"No role {role_key}.", 404)
    if team is None:
        raise AccessError(f"No team {team_key}.", 404)
    # Adding a grant onto a team that was switched off would leave a row the
    # person cannot use. Taking a grant away must still work.
    if must_be_active and not team.is_active:
        raise AccessError(f"{team.name} is inactive.", 409)
    return role, team


def _holds(s, user_id: int) -> list[tuple[str, str]]:
    rows = s.execute(
        select(AppRole.key, AppTeam.key)
        .join(AppUserRole, AppUserRole.role_id == AppRole.id)
        .join(AppTeam, AppTeam.id == AppUserRole.team_id)
        .where(AppUserRole.user_id == user_id)
    ).all()
    return [(role_key, team_key) for role_key, team_key in rows]


def _same_team_conflict(holds: list[tuple[str, str]], role_key: str, team_key: str) -> Optional[str]:
    """Author and checker on one team, including a checker grant that covers every team."""
    authors = {team for role, team in holds if role == _AUTHOR}
    checkers = {team for role, team in holds if role == _CHECKER}
    if role_key == _AUTHOR and (team_key in checkers or GLOBAL_TEAM in checkers):
        return "A person is not both author and checker on the same team."
    if role_key == _CHECKER and team_key == GLOBAL_TEAM and authors:
        return "A checker for every team would also check a team they write for."
    if role_key == _CHECKER and team_key in authors:
        return "A person is not both author and checker on the same team."
    return None


def _active_admin_ids(s) -> set[int]:
    rows = s.execute(
        select(AppUser.id)
        .join(AppUserRole, AppUserRole.user_id == AppUser.id)
        .join(AppRole, AppRole.id == AppUserRole.role_id)
        .where(AppRole.key == _ADMIN, AppUser.is_active.is_(True))
    ).scalars().all()
    return set(rows)


def _refuse_last_admin(s, user_id: int) -> None:
    admins = _active_admin_ids(s)
    if user_id in admins and len(admins) == 1:
        raise AccessError("Someone has to be able to assign roles.", 409)


def _user(s, user_id: int) -> AppUser:
    user = s.get(AppUser, user_id)
    if user is None:
        raise AccessError("No such person.", 404)
    return user


def _team(s, team_key: str) -> AppTeam:
    team = s.execute(select(AppTeam).where(AppTeam.key == team_key)).scalar_one_or_none()
    if team is None:
        raise AccessError("No such team.", 404)
    return team


def _grant_row(
    role_key: str, role_name: str, team_key: str, team_name: str,
    granted_at, granted_by_name: Optional[str],
) -> dict:
    return {
        "role": role_key,
        "role_name": role_name,
        "team": team_key,
        "team_name": team_name,
        "granted_at": _iso(granted_at),
        "granted_by_name": granted_by_name or None,
    }


def _people_payload(s) -> dict:
    users = s.execute(select(AppUser).order_by(AppUser.display_name, AppUser.email)).scalars().all()
    granter = aliased(AppUser)
    grant_rows = s.execute(
        select(
            AppUserRole.user_id, AppRole.key, AppRole.name, AppTeam.key, AppTeam.name,
            AppUserRole.granted_at, granter.display_name,
        )
        .join(AppRole, AppRole.id == AppUserRole.role_id)
        .join(AppTeam, AppTeam.id == AppUserRole.team_id)
        .outerjoin(granter, granter.id == AppUserRole.granted_by)
        .order_by(AppRole.name, AppTeam.key)
    ).all()
    by_user: dict[int, list[dict]] = {}
    for user_id, role_key, role_name, team_key, team_name, granted_at, granter_name in grant_rows:
        by_user.setdefault(user_id, []).append(
            _grant_row(role_key, role_name, team_key, team_name, granted_at, granter_name)
        )
    roles = s.execute(select(AppRole).order_by(AppRole.name)).scalars().all()
    teams = s.execute(
        select(AppTeam).where(AppTeam.is_active.is_(True)).order_by(AppTeam.is_system.desc(), AppTeam.name)
    ).scalars().all()
    return {
        "people": [
            {
                "id": user.id,
                "email": user.email,
                "display_name": user.display_name,
                "is_active": user.is_active,
                "last_login_at": _iso(user.last_login_at),
                "grants": by_user.get(user.id, []),
            }
            for user in users
        ],
        "roles": [
            {"key": role.key, "name": role.name, "scope": role.scope_kind}
            for role in roles
        ],
        "teams": [{"key": team.key, "name": team.name} for team in teams],
    }


def list_people() -> dict:
    """Everyone, plus the roles and teams the grant form offers."""
    with session_scope() as s:
        return _people_payload(s)


def set_active(user_id: int, is_active: bool) -> dict:
    """Turn a person on or off. Off takes effect on their next request."""
    with session_scope() as s:
        user = _user(s, user_id)
        if user.is_active and not is_active:
            _refuse_last_admin(s, user_id)
        user.is_active = bool(is_active)
        return _people_payload(s)


def add_grant(user_id: int, role_key: str, team_key: str, *, granted_by: Optional[int]) -> dict:
    """Give this person this role on this team, or refuse with the reason."""
    with session_scope() as s:
        user = _user(s, user_id)
        role, team = _role_team(s, role_key, team_key, must_be_active=True)
        if role.scope_kind == "global" and team.key != GLOBAL_TEAM:
            raise AccessError(f"{role.name} is granted for every team, not one team.")
        if role.key == _AUTHOR and team.key == GLOBAL_TEAM:
            raise AccessError("An author is granted on one team.")
        holds = _holds(s, user.id)
        if (role.key, team.key) in holds:
            raise AccessError("They already hold that role on that team.", 409)
        conflict = _same_team_conflict(holds, role.key, team.key)
        if conflict:
            raise AccessError(conflict, 409)
        s.add(AppUserRole(
            user_id=user.id, role_id=role.id, team_id=team.id, granted_by=granted_by,
        ))
        s.flush()
        return _people_payload(s)


def remove_grant(user_id: int, role_key: str, team_key: str) -> dict:
    """Take one grant away. Refuses to remove the last Platform Admin."""
    with session_scope() as s:
        user = _user(s, user_id)
        role, team = _role_team(s, role_key, team_key, must_be_active=False)
        row = s.get(AppUserRole, (user.id, role.id, team.id))
        if row is None:
            raise AccessError("They do not hold that role on that team.", 404)
        if role.key == _ADMIN:
            _refuse_last_admin(s, user.id)
        s.delete(row)
        return _people_payload(s)


def _pool_counts() -> dict[str, int]:
    """How many pool files name each team. A storage miss shows zero, not a dead page."""
    try:
        from app import question_pools as qp

        ids: dict[str, set[str]] = {}
        for item in [*qp.list_pools(), *qp.list_drafts()]:
            team = item.get("team") or GLOBAL_TEAM
            ids.setdefault(team, set()).add(str(item.get("pool_id") or ""))
        return {team: len(pool_ids) for team, pool_ids in ids.items()}
    except Exception:
        logger.exception("[access] pool counts unavailable")
        return {}


def _team_counts(s) -> tuple[dict[str, int], dict[str, int]]:
    people = dict(s.execute(
        select(AppTeam.key, func.count(func.distinct(AppUserRole.user_id)))
        .join(AppUserRole, AppUserRole.team_id == AppTeam.id)
        .group_by(AppTeam.key)
    ).all())
    steps = dict(s.execute(
        select(AppTeam.key, func.count(AppApprovalStep.id))
        .join(AppApprovalStep, AppApprovalStep.team_id == AppTeam.id)
        .group_by(AppTeam.key)
    ).all())
    return people, steps


def _team_dict(team: AppTeam, people: int, pools: int, steps: int) -> dict:
    return {
        "key": team.key,
        "name": team.name,
        "is_system": team.is_system,
        "is_active": team.is_active,
        "people": people,
        "pools": pools,
        "steps": steps,
    }


def list_teams() -> dict:
    """Every team, with how many people, pools and chain steps use it."""
    pools = _pool_counts()
    with session_scope() as s:
        people, steps = _team_counts(s)
        teams = s.execute(select(AppTeam).order_by(AppTeam.is_system.desc(), AppTeam.name)).scalars().all()
        return {
            "teams": [
                _team_dict(team, people.get(team.key, 0), pools.get(team.key, 0), steps.get(team.key, 0))
                for team in teams
            ]
        }


def create_team(name: str, key: str = "") -> dict:
    """Add a team. The key is taken from the name when the caller leaves it blank."""
    name = (name or "").strip()
    if not name:
        raise AccessError("A team needs a name.")
    chosen = (key or "").strip().lower() or _slug(name)
    if chosen == GLOBAL_TEAM or not _KEY.match(chosen):
        raise AccessError("The team key must start with a letter and use only letters, numbers and underscores.")
    with session_scope() as s:
        taken = s.execute(select(AppTeam).where(AppTeam.key == chosen)).scalar_one_or_none()
        if taken is not None:
            raise AccessError(f"A team with key {chosen} already exists.", 409)
        s.add(AppTeam(key=chosen, name=name, is_system=False, is_active=True))
        s.flush()
    return list_teams()


def update_team(team_key: str, *, name: Optional[str] = None, is_active: Optional[bool] = None) -> dict:
    """Rename a team or turn it on or off. The every-team row is fixed. The key never changes."""
    with session_scope() as s:
        team = _team(s, team_key)
        if team.is_system:
            raise AccessError("Every team is built in and cannot be changed.", 409)
        if name is not None:
            cleaned = name.strip()
            if not cleaned:
                raise AccessError("A team needs a name.")
            team.name = cleaned
        if is_active is not None:
            team.is_active = bool(is_active)
    return list_teams()


def delete_team(team_key: str) -> dict:
    """Delete a team nothing points at. In use, or the every-team row, is refused."""
    with session_scope() as s:
        team = _team(s, team_key)
        if team.is_system:
            raise AccessError("Every team is built in and cannot be deleted.", 409)
        people, steps = _team_counts(s)
        pools = _pool_counts()
        if people.get(team.key, 0) or steps.get(team.key, 0) or pools.get(team.key, 0):
            raise AccessError("This team is in use. Deactivate it instead.", 409)
        s.delete(team)
    return list_teams()


def _chain(s, team: AppTeam) -> list[dict]:
    rows = s.execute(
        select(AppApprovalStep, AppRole.key, AppRole.name)
        .join(AppRole, AppRole.id == AppApprovalStep.approver_role_id)
        .where(AppApprovalStep.team_id == team.id)
        .order_by(AppApprovalStep.step_no)
    ).all()
    return [
        {"step_no": step.step_no, "name": step.name, "role": role_key, "role_name": role_name}
        for step, role_key, role_name in rows
    ]


def _can_review(s, role: AppRole) -> bool:
    """A step may name only a role that is allowed to review a pool."""
    return s.get(AppRolePermission, (role.id, "pools.approve")) is not None


def _signer_count(s, role_id: int, team_id: int, star_id: int) -> int:
    """Active people who hold this role on this team or on every team.

    A grant on a team that is switched off does not count: that person cannot
    sign until the team is turned back on.
    """
    return s.execute(
        select(func.count(func.distinct(AppUser.id)))
        .join(AppUserRole, AppUserRole.user_id == AppUser.id)
        .join(AppTeam, AppTeam.id == AppUserRole.team_id)
        .where(
            AppUser.is_active.is_(True),
            AppTeam.is_active.is_(True),
            AppUserRole.role_id == role_id,
            AppUserRole.team_id.in_([team_id, star_id]),
        )
    ).scalar_one()


def get_chain(team_key: str) -> dict:
    """One team's chain, and the roles a step may name."""
    with session_scope() as s:
        return get_chain_in(s, _team(s, team_key))


def save_chain(team_key: str, steps: list[dict]) -> dict:
    """Replace this team's steps. Numbered 1..n in the order given.

    An empty chain on a normal team means "use the every-team chain". The
    every-team chain itself cannot be emptied, because it is the fallback.
    """
    if team_key == GLOBAL_TEAM and not steps:
        raise AccessError("The every-team chain is the fallback. It needs at least one step.", 409)
    with session_scope() as s:
        team = _team(s, team_key)
        star_id = s.execute(select(AppTeam.id).where(AppTeam.key == GLOBAL_TEAM)).scalar_one()
        built: list[tuple[int, str, AppRole]] = []
        for index, step in enumerate(steps, start=1):
            role_key = (step.get("role") or "").strip()
            role = s.execute(select(AppRole).where(AppRole.key == role_key)).scalar_one_or_none()
            if role is None:
                raise AccessError(f"No role {role_key}.", 400)
            if not _can_review(s, role):
                raise AccessError(
                    f"{role.name} cannot review a pool. Choose a role that can.",
                    400,
                )
            name = (step.get("name") or "").strip() or role.name
            built.append((index, name, role))
        s.execute(delete(AppApprovalStep).where(AppApprovalStep.team_id == team.id))
        warnings: list[str] = []
        for index, name, role in built:
            s.add(AppApprovalStep(
                team_id=team.id, step_no=index, approver_role_id=role.id, name=name,
            ))
            if _signer_count(s, role.id, team.id, star_id) == 0:
                warnings.append(f"Nobody can sign step {index} ({name}) yet.")
        s.flush()
        return {**get_chain_in(s, team), "warnings": warnings}


def get_chain_in(s, team: AppTeam) -> dict:
    roles = s.execute(select(AppRole).order_by(AppRole.name)).scalars().all()
    # The dropdown only offers roles that can review. A step already saved
    # under some other role still comes back on `chain`, so it can be seen
    # and changed.
    return {
        "key": team.key,
        "name": team.name,
        "is_system": team.is_system,
        "chain": _chain(s, team),
        "roles": [
            {"key": role.key, "name": role.name}
            for role in roles
            if _can_review(s, role)
        ],
    }


def role_grid() -> dict:
    """The four roles against the fixed permission list."""
    with session_scope() as s:
        roles = s.execute(select(AppRole).order_by(AppRole.name)).scalars().all()
        rows = s.execute(
            select(AppRole.key, AppRolePermission.permission)
            .join(AppRolePermission, AppRolePermission.role_id == AppRole.id)
        ).all()
    held: dict[str, list[str]] = {}
    for role_key, permission in rows:
        held.setdefault(role_key, []).append(permission)
    return {
        "permissions": [
            {"key": key, "group": group, "label": label}
            for key, (group, label) in PERMISSION_LABELS.items()
        ],
        "roles": [
            {
                "key": role.key,
                "name": role.name,
                "permissions": sorted(held.get(role.key, [])),
            }
            for role in roles
        ],
        "locked": {_ADMIN: list(ADMIN_PERMISSIONS)},
    }


def set_permission(role_key: str, permission: str, enabled: bool) -> dict:
    """Tick or clear one cell. A permission that is not in the vocabulary is refused."""
    try:
        permission = validate_permission(permission)
    except ValueError as e:
        raise AccessError(str(e), 400) from e
    with session_scope() as s:
        role = s.execute(select(AppRole).where(AppRole.key == role_key)).scalar_one_or_none()
        if role is None:
            raise AccessError("No such role.", 404)
        if role.key == _ADMIN and permission in ADMIN_PERMISSIONS and not enabled:
            raise AccessError(
                "The admin role keeps the access permissions, or nobody could assign roles.",
                409,
            )
        existing = s.get(AppRolePermission, (role.id, permission))
        if enabled and existing is None:
            s.add(AppRolePermission(role_id=role.id, permission=permission))
        elif not enabled and existing is not None:
            s.delete(existing)
    return role_grid()
