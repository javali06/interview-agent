"""Benchmark aggregation for the plugin evaluation pipeline (v2).

Pure functions, NO LLM and NO I/O: take per-segment plugin verdicts and sum
them into per-phase totals and a grand total ("score as high as possible").
Also derives a v1-compatible `EvaluationModel` view so the existing Performance
tab + revise loop keep working during rollout.

Numbers are computed here; plugins (LLMs) only produce the per-segment marks.
Non-`scored` segments (not_observed / insufficient_evidence / assumptions_unmet
/ error) are excluded from totals — never counted as 0.
"""
from __future__ import annotations

from collections import Counter
from typing import Any, Iterable, Optional

from app.evaluation_service import band_for_score
from features.eval.plugins.base import SegmentEvaluation
from features.eval.schema import CANONICAL_DIMS
from features.eval.sectioner import Segment

# canonical dim -> the 4 fixed v1 dimension keys (EvaluationModel)
_V1_DIM_MAP = {
    "communication_clarity": "communication_clarity",
    "technical_depth": "technical_depth",
    "problem_solving_process": "problem_solving",
    "role_fit": "role_fit",
}


def _phase_by_id(cadence: Any, phase_id: str) -> Optional[dict]:
    phases = cadence.get("phases") if isinstance(cadence, dict) else getattr(cadence, "phases", None)
    for p in phases or []:
        pid = p.get("id") if isinstance(p, dict) else getattr(p, "id", None)
        if pid == phase_id:
            return p if isinstance(p, dict) else None
    return None


def _written_response_of(holder: Optional[dict]) -> dict:
    if not isinstance(holder, dict):
        return {}
    wr = holder.get("written_response")
    return wr if isinstance(wr, dict) else {}


def _is_blank(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return not value.strip()
    if isinstance(value, list):
        return not any(isinstance(v, str) and v.strip() for v in value)
    return False


def _resolve_question_material(cadence: Any, phase_id: str, question_id: Optional[str]) -> dict:
    """The question's `written_response` config — question-level values layered
    over the phase-level defaults (mirrors WrittenResponse.resolved_for) — for
    display purposes ONLY (the Scorecard evidence section). Returns {} for a
    phase with no written_response block (i.e. not one of the four written-
    response question types), so ordinary conversational/coding phases are
    completely unaffected.

    Deliberately independent of features.eval.plugins._ground_truth (which the
    three scoring plugins use for their own ground_truth lookup) — this module
    is pure aggregation/display, not scoring, and the two must never share a
    code path."""
    phase = _phase_by_id(cadence, phase_id) if cadence is not None else None
    if phase is None:
        return {}
    phase_wr = _written_response_of(phase)
    if not phase_wr:
        return {}
    merged = dict(phase_wr)
    pool = phase.get("question_pool") or []
    question = next(
        (q for q in pool if isinstance(q, dict) and q.get("id") == question_id), None,
    )
    for k, v in _written_response_of(question).items():
        if not _is_blank(v):
            merged[k] = v
    return merged


def _seg_result_dict(
    segment: Segment, ev: SegmentEvaluation, *, cadence: Any = None, token: Optional[str] = None,
) -> dict[str, Any]:
    # The actual multi-party transcript this segment was scored on — the AI
    # question, the candidate's answer + follow-ups, verifier notes, etc. This
    # IS the evidence shown in the UI (readable content, not bare event ids).
    # `cited` flags the specific turns the plugin pointed at (evidence_refs).
    cited = set(ev.evidence_refs or [])
    evidence = [
        {"speaker": t.speaker, "text": t.text, "event_index": t.event_index,
         "cited": t.event_index in cited}
        for t in segment.turns
    ]

    # Written-response question material (comprehensive / transcription /
    # translation / image_description ONLY — {} for every other phase type, so
    # this never affects a regular conversational/coding segment's evidence).
    material = _resolve_question_material(cadence, segment.phase_id, segment.question_id)
    question_type = material.get("question_type")
    source_text = material.get("source_text")
    audio_asset = material.get("audio_asset")
    image_asset = material.get("image_asset")

    def _asset_url(name: Optional[str]) -> Optional[str]:
        if not name or not token:
            return None
        from urllib.parse import quote
        return f"/api/sessions/{token}/phase-asset/{quote(str(name))}"

    return {
        "segment_id": segment.segment_id,
        "kind": segment.kind,
        "question_id": segment.question_id,
        "question_text": segment.question_text,
        "difficulty": segment.difficulty,
        "state": ev.state,
        "marks_earned": ev.marks_earned,
        "marks_possible": ev.marks_possible,
        "rationale": ev.rationale,
        "breakdown": [b.model_dump() for b in ev.breakdown],
        "sub_scores": ev.sub_scores,
        "grading": ev.view_payload,        # plugin-specific decision the view renders
        "evidence": evidence,              # the transcript content (the real evidence)
        "evidence_refs": ev.evidence_refs,  # event indices (for deep-link/highlight)
        # Question material for the four written-response types — the actual
        # content the candidate was asked to work from, distinct from the AI's
        # (LLM-paraphrased) spoken/typed dispatch line already in `evidence`.
        # question_type is None for every other phase (the discriminator the UI
        # uses to leave non-written-response evidence exactly as before).
        "question_type": question_type,
        "source_text": source_text if not _is_blank(source_text) else None,
        "audio_url": _asset_url(audio_asset),
        "image_url": _asset_url(image_asset),
    }


def _summary(seg_dicts: list[dict]) -> dict[str, Any]:
    scored = [s for s in seg_dicts if s["state"] == "scored"]
    diffs = Counter(s["difficulty"] for s in seg_dicts if s.get("difficulty"))
    return {
        "total_questions": len(seg_dicts),
        "scored_count": len(scored),
        "marks_earned": round(sum(s["marks_earned"] for s in scored), 2),
        "marks_possible": round(sum(s["marks_possible"] for s in scored), 2),
        "difficulty_counts": dict(diffs) if diffs else {},
    }


def build_phase(
    phase_id: str, name: str,
    plugin_blocks: list[tuple[str, str, dict, list[tuple[Segment, SegmentEvaluation]]]],
    *, cadence: Any = None, token: Optional[str] = None,
) -> dict[str, Any]:
    """plugin_blocks: list of (plugin_id, view_id, config_used, [(segment, eval)...]).

    `cadence`/`token` are for the written-response question-material lookup
    (Scorecard evidence display) only — never used for scoring."""
    results = []
    pe = pp = 0.0
    for plugin_id, view_id, config_used, pairs in plugin_blocks:
        seg_dicts = [_seg_result_dict(seg, ev, cadence=cadence, token=token) for seg, ev in pairs]
        summ = _summary(seg_dicts)
        pe += summ["marks_earned"]
        pp += summ["marks_possible"]
        results.append({
            "plugin_id": plugin_id,
            "view_id": view_id,
            "config_used": config_used,
            "summary": summ,
            "segments": seg_dicts,
        })
    return {
        "phase_id": phase_id,
        "name": name,
        "marks_earned": round(pe, 2),
        "marks_possible": round(pp, 2),
        "results": results,
    }


def _dimensions(all_evals: Iterable[SegmentEvaluation]) -> dict[str, dict]:
    acc: dict[str, list[float]] = {}
    for ev in all_evals:
        if ev.state != "scored":
            continue
        for dim, val in (ev.sub_scores or {}).items():
            if dim in CANONICAL_DIMS:
                acc.setdefault(dim, []).append(float(val))
    return {d: {"score": round(sum(v) / len(v), 1), "count": len(v)} for d, v in acc.items() if v}


def aggregate(phases: list[dict], *, model: str, generated_at: str,
              plan_fingerprint: str, coding_quality: list[dict] | None = None,
              all_evals: Iterable[SegmentEvaluation] = ()) -> dict[str, Any]:
    """Assemble the benchmark v2 evaluation dict from per-phase blocks."""
    earned = round(sum(p["marks_earned"] for p in phases), 2)
    possible = round(sum(p["marks_possible"] for p in phases), 2)
    pct = round(100.0 * earned / possible, 1) if possible > 0 else 0.0
    return {
        "schema": "v2",
        "model": model,
        "generated_at": generated_at,
        "plan_used": True,
        "plan_fingerprint": plan_fingerprint,
        "total": {"marks_earned": earned, "marks_possible": possible, "pct": pct},
        "phases": phases,
        "dimensions": _dimensions(all_evals),
        "coding_quality": coding_quality or [],
    }


# ── v1-compatible adapter (keeps the existing Performance tab working) ────────


def _phase_score_0_10(phase: dict) -> int:
    poss = phase["marks_possible"]
    if poss <= 0:
        return 0
    return int(round(10.0 * phase["marks_earned"] / poss))


def deterministic_synthesis(v2: dict) -> dict[str, Any]:
    """Headline/summary/strengths/weaknesses without an LLM — from the
    phase scores. Always yields ≥1 strength so EvaluationModel validates."""
    scored_phases = [p for p in v2["phases"] if p["marks_possible"] > 0]
    ranked = sorted(scored_phases, key=lambda p: (p["marks_earned"] / p["marks_possible"]), reverse=True)
    score = int(round(v2["total"]["pct"]))
    band = band_for_score(score)
    strengths = [{"title": p["name"], "detail": f"Scored {p['marks_earned']:g}/{p['marks_possible']:g} marks."}
                 for p in ranked[:3]] or [{"title": "Completed interview", "detail": "Candidate participated across phases."}]
    weaknesses = [{"title": p["name"], "detail": f"Lower marks: {p['marks_earned']:g}/{p['marks_possible']:g}."}
                  for p in reversed(ranked[-2:])] if len(ranked) > 1 else []
    return {
        "headline": f"Benchmark score {v2['total']['marks_earned']:g}/{v2['total']['marks_possible']:g} ({band}).",
        "summary": f"Aggregated {len(scored_phases)} scored phase(s) for a benchmark of "
                   f"{v2['total']['marks_earned']:g}/{v2['total']['marks_possible']:g} marks ({score}%).",
        "strengths": strengths,
        "weaknesses": weaknesses,
    }


def to_evaluation_model_v1(v2: dict, *, synthesis: dict | None = None) -> dict[str, Any]:
    """Derive the legacy EvaluationModel shape from the benchmark v2 dict so
    un-migrated consumers (current Performance tab, revise loop) keep working.

    Numbers are normalized to the old 0-100 / 0-10 scales for display only —
    the benchmark marks under `benchmark` remain the source of truth."""
    syn = synthesis or deterministic_synthesis(v2)
    score = int(round(v2["total"]["pct"]))
    dims_v2 = v2.get("dimensions", {})
    dimensions = {}
    for canon, v1key in _V1_DIM_MAP.items():
        d = dims_v2.get(canon)
        dimensions[v1key] = {
            "score": int(round(d["score"])) if d else score // 10,
            "rationale": "" if d else "no per-segment signal for this dimension",
        }

    phases_v1 = []
    for p in v2["phases"]:
        # per-question rows (specific phases): flatten scored question segments
        questions = []
        for r in p["results"]:
            for s in r["segments"]:
                if s["kind"] == "question" and s.get("question_id"):
                    questions.append({
                        "id": s["question_id"],
                        "text": s.get("question_text") or s["question_id"],
                        "score": int(round(10.0 * s["marks_earned"] / s["marks_possible"])) if s["marks_possible"] else 0,
                        "rationale": (s.get("rationale") or "")[:200],
                    })
        phases_v1.append({
            "id": p["phase_id"],
            "name": p["name"],
            "score": _phase_score_0_10(p),
            "summary": f"{p['marks_earned']:g}/{p['marks_possible']:g} marks.",
            "questions": questions,
        })

    return {
        "generated_at": v2["generated_at"],
        "model": v2["model"],
        "overall": {
            "score": score,
            "band": band_for_score(score),
            "headline": syn["headline"],
            "summary": syn["summary"],
        },
        "dimensions": dimensions,
        "phases": phases_v1,
        "strengths": syn["strengths"] or [{"title": "Completed interview", "detail": "Candidate participated."}],
        "weaknesses": syn.get("weaknesses", []),
        # extra fields (pydantic ignores; persisted) — back-compat + v2 source
        "coding_quality": v2.get("coding_quality", []),
        "plan_used": True,
        "plan_fingerprint": v2.get("plan_fingerprint"),
        "benchmark": v2,
    }
