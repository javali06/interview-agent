"""Authorisation: what a signed-in person may do (authentication is app/auth.py).

- Grants are read from the database, so changing a role is data, not a deploy.
- A grant is (person, role, team); team `*` means every team. A check with a
  team passes for that team or `*`; a check with no team passes on any grant.
- Fail closed: unknown permission, missing or inactive user -> False.

Design notes: docs/question-pool-maker-checker.md.
"""
from __future__ import annotations

import logging
from typing import Callable, Iterable, Optional, Union

from fastapi import HTTPException, Request, status
from sqlalchemy import select

from app.constants import GLOBAL_TEAM
from db.engine import session_scope
from db.models import AppRole, AppRolePermission, AppTeam, AppUser, AppUserRole

logger = logging.getLogger(__name__)

# ── the closed vocabulary ────────────────────────────────────────────────
# Fixed in code so a typo cannot invent a permission that silently grants nothing.

POOL_PERMISSIONS = (
    "pools.view",      # see the list, open a pool, export it, read its history
    "pools.edit",      # create / edit / duplicate / delete a draft, upload material
    "pools.submit",    # send a draft into the approval chain; withdraw your own
    "pools.approve",   # sign your step, or return it with a comment
    "pools.publish",   # force-publish, SKIPPING the chain — break-glass
)

# What HR holds (HR has no pools.* permission at all).
INTERVIEW_PERMISSIONS = (
    "interviews.view",
    "interviews.schedule",
    "interviews.cancel",
)

ADMIN_PERMISSIONS = (
    "admin.users",        # add people, grant and remove roles
    "admin.teams",        # create teams, configure their approval chains
    "admin.permissions",  # edit the grid itself
)

# Group + plain label for the Access role grid. One row per permission, so the
# screen cannot drift from the vocabulary above.
PERMISSION_LABELS: dict[str, tuple[str, str]] = {
    "pools.view": ("Pools", "See pools"),
    "pools.edit": ("Pools", "Edit drafts"),
    "pools.submit": ("Pools", "Submit for review"),
    "pools.approve": ("Pools", "Review pools"),
    "pools.publish": ("Pools", "Force-publish"),
    "interviews.view": ("Interviews", "See interviews"),
    "interviews.schedule": ("Interviews", "Schedule interviews"),
    "interviews.cancel": ("Interviews", "Cancel interviews"),
    "admin.users": ("Access", "Manage people"),
    "admin.teams": ("Access", "Manage teams"),
    "admin.permissions": ("Access", "Edit the role grid"),
}

ALL_PERMISSIONS: tuple[str, ...] = (
    *POOL_PERMISSIONS,
    *INTERVIEW_PERMISSIONS,
    *ADMIN_PERMISSIONS,
)

_PERMISSION_SET = frozenset(ALL_PERMISSIONS)


def is_valid_permission(permission: str) -> bool:
    """True if `permission` is in the fixed vocabulary; lets callers check without raising."""
    return permission in _PERMISSION_SET


def validate_permission(permission: str) -> str:
    """Return `permission` or raise ValueError, so a typo fails loudly instead of granting nothing."""
    if permission not in _PERMISSION_SET:
        raise ValueError(
            f"unknown permission {permission!r}; must be one of "
            f"{', '.join(ALL_PERMISSIONS)}"
        )
    return permission


# ── reading a person's grants ────────────────────────────────────────────


def grants_for(user_id: int) -> dict[str, set[str]]:
    """Load all of a person's grants as {permission: {team_key}} in one query ({} if inactive).

    A grant on a team that has been turned off is kept, but it does not count
    until that team is turned back on. The `*` team cannot be turned off.
    """
    if not user_id:
        return {}
    out: dict[str, set[str]] = {}
    with session_scope() as s:
        user = s.get(AppUser, user_id)
        if user is None or not user.is_active:
            return {}
        rows = s.execute(
            select(AppRolePermission.permission, AppTeam.key)
            .join(AppUserRole, AppUserRole.role_id == AppRolePermission.role_id)
            .join(AppTeam, AppTeam.id == AppUserRole.team_id)
            .where(
                AppUserRole.user_id == user_id,
                AppTeam.is_active.is_(True),
            )
        ).all()
    for permission, team_key in rows:
        out.setdefault(permission, set()).add(team_key)
    return out


def has_permission(
    user_id: Optional[int],
    permission: str,
    team: Optional[str] = None,
) -> bool:
    """True if the person holds `permission` for `team` or `*` (any team when None); unknown -> False."""
    if not user_id or permission not in _PERMISSION_SET:
        return False
    teams = grants_for(user_id).get(permission)
    if not teams:
        return False
    if team is None:
        return True
    return team in teams or GLOBAL_TEAM in teams


def ensure_permission(
    user_id: Optional[int],
    permission: str,
    team: Optional[str] = None,
    detail: Union[str, Callable[[], str], None] = None,
) -> None:
    """Raise 403 with `detail` (a string, or a callable built only on refusal) unless allowed."""
    if has_permission(user_id, permission, team):
        return
    if callable(detail):
        detail = detail()
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail=detail or f"missing permission: {permission}",
    )


def permitted_teams(user_id: Optional[int], permission: str) -> set[str]:
    """Team keys this person holds `permission` for (`*` = every team); used to name their teams."""
    if not user_id or permission not in _PERMISSION_SET:
        return set()
    return grants_for(user_id).get(permission, set())


# ── the request-time check ───────────────────────────────────────────────


def current_user_id(request: Request) -> Optional[int]:
    """The signed-in person's `app_users.id` from the cookie, or None (legacy login has no id)."""
    from app import auth

    return auth.get_current_user_id(request)


def _signed_in(request: Request) -> int:
    """The signed-in user id, or 401, so the SPA can tell "log in" apart from "not allowed"."""
    user_id = current_user_id(request)
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="sign-in required"
        )
    return user_id


def require(permission: str, team_param: Optional[str] = None):
    """Route guard `Depends(require(perm, team_param))`: returns the user id, else 401/403."""
    validate_permission(permission)

    def _dep(request: Request) -> int:
        """Per-request check: signed in, then the permission for the team named in the path or query."""
        user_id = _signed_in(request)
        team = None
        if team_param:
            team = request.path_params.get(team_param) or request.query_params.get(
                team_param
            )
        ensure_permission(user_id, permission, team)
        return user_id

    return _dep


def interview_permission(method: str, path: str) -> Optional[str]:
    """The interview permission an admin path needs, or None when this path is not one.

    Candidate uploads and phase assets stay out: the session token is their
    credential, and those callers are not signed in. A cookie with no person
    is not decided here — the middleware skips this when there is no user id,
    so the old shared-login cookie keeps reaching the routes it already did.
    """
    method = method.upper()
    path = path.split("?", 1)[0]
    if method == "POST" and path.startswith("/api/sessions/"):
        rest = path[len("/api/sessions/"):]
        token, _, tail = rest.partition("/")
        if token and tail == "recording":
            return None
    if method == "GET" and "/phase-asset/" in path:
        return None

    if (
        path == "/api/sessions"
        or path.startswith("/api/sessions/")
        or path.startswith("/admin/sessions")
        or path == "/admin/dashboard"
        or path.startswith("/admin/dashboard/")
    ):
        base = path.rstrip("/")
        # DELETE /api/sessions/{token} is the interview itself. A review note
        # lives one segment deeper and is part of reading the interview.
        if base.endswith(("/archive", "/delete", "/bulk_delete")) or (
            method == "DELETE" and base.count("/") == 3 and base.startswith("/api/sessions/")
        ):
            return "interviews.cancel"
        return "interviews.view"

    if path.startswith((
        "/api/schedule", "/admin/schedule",
        "/api/cadence", "/api/rubric", "/admin/coding",
    )):
        return "interviews.schedule"
    if path.startswith("/api/eval/"):
        return "interviews.view" if method == "GET" else "interviews.schedule"
    if path.startswith("/api/roles") or path.startswith("/api/shortlist"):
        return "interviews.view" if method == "GET" else "interviews.schedule"
    return None


def require_any(permissions: Iterable[str]):
    """Route guard passing if the person holds ANY of `permissions`, for screens several roles share."""
    perms = [validate_permission(p) for p in permissions]

    def _dep(request: Request) -> int:
        """Per-request check: signed in and holding at least one of the permissions."""
        user_id = _signed_in(request)
        if not any(has_permission(user_id, p) for p in perms):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"missing one of: {', '.join(perms)}",
            )
        return user_id

    return _dep


# ── lookups the routes and the seed both need ────────────────────────────


def user_by_email(email: str) -> Optional[dict]:
    """Find a person by email as a plain dict (not a detached ORM object), or None."""
    key = (email or "").strip().lower()
    if not key:
        return None
    with session_scope() as s:
        row = s.execute(select(AppUser).where(AppUser.email == key)).scalar_one_or_none()
        if row is None:
            return None
        return {
            "id": row.id,
            "email": row.email,
            "display_name": row.display_name,
            "is_active": row.is_active,
        }


def describe_user(user_id: int) -> Optional[dict]:
    """A person's identity, roles and permissions; what `/api/me` returns and the menu is built from."""
    with session_scope() as s:
        user = s.get(AppUser, user_id)
        if user is None:
            return None
        rows = s.execute(
            select(AppRole.key, AppRole.name, AppTeam.key, AppTeam.name)
            .join(AppUserRole, AppUserRole.role_id == AppRole.id)
            .join(AppTeam, AppTeam.id == AppUserRole.team_id)
            .where(AppUserRole.user_id == user_id)
        ).all()
    grants = grants_for(user_id)
    return {
        "id": user_id,
        "email": user.email,
        "display_name": user.display_name,
        "is_active": user.is_active,
        "roles": [
            {
                "role": role_key,
                "role_name": role_name,
                "team": team_key,
                "team_name": team_name,
            }
            for role_key, role_name, team_key, team_name in rows
        ],
        "permissions": {p: sorted(t) for p, t in sorted(grants.items())},
    }
