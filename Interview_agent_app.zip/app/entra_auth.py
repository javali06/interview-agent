"""Sign in with a Centific work account (Microsoft Entra ID).

Everything that talks to Microsoft lives here, so the three routes in
`app/main.py` stay thin.

THE ONE IDEA. Microsoft answers "who is this person"; it does NOT decide what
they may do. Identity arrives here; authorisation stays in `app/rbac.py`,
backed by the grants an administrator owns. Driving roles from Microsoft
security groups was considered and rejected: every role change would become an
IT ticket, which is the opposite of why the permission grid is data.

So the whole flow converges on `auth.issue_cookie(email, user_id)` — the same
cookie every permission check reads. Nothing downstream changes: no route, no
permission check, no React component.

OFF BY DEFAULT. `is_configured()` is False without the three secrets, and the
routes then 404. A deploy that has not been given
credentials behaves as it does today.
"""
from __future__ import annotations

import logging
import os
import secrets
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

# Delegated Microsoft Graph scopes. Sign-in only: confirm who is signing in and
# read THEIR OWN name and email. Deliberately no Mail.*, Files.* or Directory.*
# — the token this app receives cannot reach anyone's mail, files or the staff
# directory, which is what makes the IT request a small one.
SCOPES = ["User.Read"]

# Where the short-lived state/nonce pair is parked between /auth/login and
# /auth/callback. Separate from the session cookie: it is pre-authentication,
# lives for one round trip, and must not outlive it.
FLOW_COOKIE = "entra_flow"
FLOW_MAX_AGE_S = 600          # 10 minutes to complete a sign-in


@dataclass(frozen=True)
class EntraSettings:
    tenant_id: str
    client_id: str
    client_secret: str
    redirect_uri: str

    @property
    def authority(self) -> str:
        # The TENANT's authority, not /common — Microsoft then refuses an
        # account from any other organisation before the request reaches us,
        # rather than leaving us to reject it afterwards.
        return f"https://login.microsoftonline.com/{self.tenant_id}"


def settings() -> Optional[EntraSettings]:
    """The configured app registration, or None when any part is missing."""
    tenant = (os.environ.get("ENTRA_TENANT_ID") or "").strip()
    client = (os.environ.get("ENTRA_CLIENT_ID") or "").strip()
    secret = (os.environ.get("ENTRA_CLIENT_SECRET") or "").strip()
    redirect = (os.environ.get("ENTRA_REDIRECT_URI") or "").strip()
    if not (tenant and client and secret and redirect):
        return None
    return EntraSettings(tenant, client, secret, redirect)


def is_configured() -> bool:
    """Whether Microsoft sign-in can be offered at all.

    Also the switch the SPA reads: no credentials, no button, and the routes
    404 — so a box without an app registration is unchanged.
    """
    if (os.environ.get("ENTRA_ENABLED") or "").strip().lower() in {"0", "false", "no"}:
        return False
    return settings() is not None


def _client(cfg: EntraSettings):
    """A confidential client — one that can keep a secret, i.e. our server.

    Built per request rather than cached: MSAL's token cache is for calling
    Graph repeatedly on a user's behalf, which we never do. We ask who someone
    is, once, and then issue our own session.
    """
    import msal

    return msal.ConfidentialClientApplication(
        client_id=cfg.client_id,
        client_credential=cfg.client_secret,
        authority=cfg.authority,
    )


# ── the outbound half ────────────────────────────────────────────────────


def start_login(cfg: EntraSettings) -> tuple[str, str]:
    """Build the Microsoft sign-in URL. Returns (url, flow_token).

    `flow_token` is the state+nonce pair the caller must park in a cookie and
    hand back to `finish_login`. Both are random and both are load-bearing:

      state — proves the person arriving at /auth/callback is finishing the
              sign-in WE started. Without it someone can hand your browser a
              completed login as THEM, and you would carry on in their account
              without noticing.
      nonce — travels inside the identity token Microsoft returns, proving the
              token was minted for THIS sign-in rather than replayed from an
              older one.
    """
    state = secrets.token_urlsafe(24)
    nonce = secrets.token_urlsafe(24)
    url = _client(cfg).get_authorization_request_url(
        scopes=SCOPES,
        state=state,
        nonce=nonce,
        redirect_uri=cfg.redirect_uri,
        prompt="select_account",
    )
    return url, f"{state}.{nonce}"


# ── the inbound half ─────────────────────────────────────────────────────


class EntraError(Exception):
    """Sign-in could not be completed. The message is safe to show a person."""


def finish_login(cfg: EntraSettings, code: str, state: str, flow_token: str) -> dict:
    """Trade the one-time code for the person's identity.

    Returns {oid, email, name}. Raises EntraError with a readable message on
    anything that does not add up — the caller shows it rather than a 500.

    The code arrived through the BROWSER, where anyone might see it, so it is
    deliberately worthless by itself: this exchange happens server to server
    and is authenticated by the client secret, which never leaves our side.
    """
    expected_state, _, nonce = (flow_token or "").partition(".")
    if not expected_state or not nonce:
        raise EntraError("That sign-in took too long. Please try again.")
    if not secrets.compare_digest(state or "", expected_state):
        # Either a stale tab, or a sign-in this app never started.
        raise EntraError("That sign-in could not be verified. Please try again.")

    result = _client(cfg).acquire_token_by_authorization_code(
        code=code,
        scopes=SCOPES,
        redirect_uri=cfg.redirect_uri,
        nonce=nonce,                 # MSAL checks it against the id_token
    )
    if "error" in result:
        # Microsoft's own description is written for a developer, so it goes to
        # the log; the person gets something they can act on.
        logger.warning(
            "[entra] token exchange failed: %s — %s",
            result.get("error"), result.get("error_description", "")[:300],
        )
        raise EntraError("Microsoft could not complete that sign-in. Please try again.")

    claims = result.get("id_token_claims") or {}
    oid = (claims.get("oid") or "").strip()
    if not oid:
        raise EntraError("Microsoft did not return an account identifier.")
    # Belt and braces: the authority is already tenant-scoped, so Microsoft
    # refuses outsiders before this point. Checked anyway because "only our
    # organisation" is the property the whole design leans on.
    if cfg.tenant_id and (claims.get("tid") or "") != cfg.tenant_id:
        raise EntraError("That account is not part of this organisation.")

    email = (
        claims.get("preferred_username")
        or claims.get("email")
        or claims.get("upn")
        or ""
    ).strip().lower()
    return {"oid": oid, "email": email, "name": (claims.get("name") or "").strip()}


# ── matching the person to an account ────────────────────────────────────


def find_or_create_user(oid: str, email: str, name: str) -> Optional[dict]:
    """The person's `app_users` row, creating it on a first-ever sign-in.

    Matched on `entra_oid` FIRST, email only as a one-time fallback. People
    change surnames and therefore email addresses; the oid never changes. Match
    on email forever and a marriage silently creates a second account holding
    none of the person's roles.

    A brand-new employee is created with NO grants: signed in, and able to do
    nothing until an administrator gives them a role. Authenticated is not
    authorised — the separation this whole module exists to keep.

    Returns None for a deactivated account, which the caller turns into a
    refusal rather than a session.
    """
    from sqlalchemy import select

    from db.engine import session_scope
    from db.models import AppUser

    email = (email or "").strip().lower()
    with session_scope() as s:
        row = s.execute(
            select(AppUser).where(AppUser.entra_oid == oid)
        ).scalar_one_or_none()

        if row is None and email:
            # First sign-in for someone seeded by email (the whole team is, in
            # app/rbac_seed.py). Stamp the oid on so every later sign-in
            # matches on the stable field instead.
            row = s.execute(
                select(AppUser).where(AppUser.email == email)
            ).scalar_one_or_none()
            if row is not None:
                row.entra_oid = oid
                logger.info("[entra] linked %s to its Entra account", email)

        if row is None:
            row = AppUser(
                entra_oid=oid,
                email=email,
                display_name=name or email,
                is_active=True,
            )
            s.add(row)
            s.flush()
            logger.info(
                "[entra] created %s on first sign-in — no roles granted yet", email
            )

        if not row.is_active:
            logger.info("[entra] refused %s — account is deactivated", email)
            return None

        # Keep the display name current; people get married, and Microsoft is
        # the authority on what someone is called.
        if name and row.display_name != name:
            row.display_name = name
        row.last_login_at = datetime.now(timezone.utc)
        return {"id": row.id, "email": row.email, "display_name": row.display_name}
