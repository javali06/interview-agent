// mic-worklet.js — AudioWorkletProcessor that captures float32 mic audio,
// downsamples to 16kHz, converts to PCM16, and posts 20ms frames (640 bytes)
// to the main thread. Loaded via audioCtx.audioWorklet.addModule("mic-worklet.js").

class MicCaptureProcessor extends AudioWorkletProcessor {
  constructor(options) {
    super();
    // The browser typically delivers audio at 48000 Hz. We need 16000 Hz
    // PCM16 mono frames of 20 ms = 320 samples = 640 bytes.
    this._inRate    = sampleRate;       // global in AudioWorkletGlobalScope
    this._outRate   = 16000;
    this._outFrameSamples = 320;
    this._ratio     = this._inRate / this._outRate;

    // Polyphase-style accumulator: we drift a fractional cursor through the
    // input buffer and grab nearest samples. Good enough for speech STT;
    // not hi-fi quality but Whisper doesn't care about anti-aliasing.
    this._inBuf     = new Float32Array(0);  // tail of pending input samples
    this._outBuf    = new Int16Array(this._outFrameSamples);
    this._outIdx    = 0;
    this._cursor    = 0;                    // fractional read position in inBuf

    // For mic-level metering: send RMS to main thread every ~50ms.
    this._meterFrames = 0;
    this._meterAcc    = 0;
    this._meterCount  = 0;
  }

  // Each process() call gives us ~128 samples of input.
  process(inputs, outputs, parameters) {
    const input = inputs[0];
    if (!input || input.length === 0) return true;
    const channelData = input[0];
    if (!channelData) return true;

    // Track meter on raw input
    for (let i = 0; i < channelData.length; i++) {
      const s = channelData[i];
      this._meterAcc += s * s;
      this._meterCount++;
    }
    this._meterFrames++;
    // Every ~50ms (about 6 process() calls at 48kHz/128 samples), send RMS.
    if (this._meterFrames >= 6) {
      const rms = this._meterCount > 0 ? Math.sqrt(this._meterAcc / this._meterCount) : 0;
      this.port.postMessage({ type: "meter", rms });
      this._meterFrames = 0;
      this._meterAcc = 0;
      this._meterCount = 0;
    }

    // Append new input to pending buffer
    const merged = new Float32Array(this._inBuf.length + channelData.length);
    merged.set(this._inBuf, 0);
    merged.set(channelData, this._inBuf.length);
    this._inBuf = merged;

    // Pull output samples until we run out of input
    while (true) {
      const next = this._cursor + this._ratio;
      if (next >= this._inBuf.length) break;

      // Nearest-neighbour sample at fractional cursor
      const idx = Math.floor(this._cursor);
      const s = this._inBuf[idx] || 0;
      // Clamp and convert to PCM16
      const clamped = Math.max(-1, Math.min(1, s));
      this._outBuf[this._outIdx++] = (clamped < 0 ? clamped * 0x8000 : clamped * 0x7fff) | 0;

      if (this._outIdx >= this._outFrameSamples) {
        // Send a full 20ms PCM16 frame to the main thread
        this.port.postMessage(
          { type: "pcm", buffer: this._outBuf.buffer.slice(0) },
          [/* no transferables — we slice() to copy */]
        );
        this._outIdx = 0;
      }
      this._cursor = next;
    }

    // Trim consumed samples from the head of the input buffer
    const consumed = Math.floor(this._cursor);
    if (consumed > 0) {
      this._inBuf = this._inBuf.slice(consumed);
      this._cursor -= consumed;
    }

    return true;
  }
}

registerProcessor("mic-capture", MicCaptureProcessor);
