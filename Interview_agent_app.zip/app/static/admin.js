// admin.js — small vanilla helpers for the admin pages.
// (no framework, no build step — matches the candidate UI's stack)

(function () {
  // ── cadence YAML → beautiful preview ──────────────────────────────
  // Used on both /admin/schedule/<token>/cadence (live mirror of the
  // editable textarea) and /admin/sessions/<token> Cadence tab (one-shot
  // render of the approved YAML). Parses with js-yaml from CDN.
  const escapeHtml = (s) => String(s == null ? "" : s).replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])
  );
  const fmtDuration = (s) => {
    s = Math.max(0, Math.round(Number(s) || 0));
    if (s < 60) return s + "s";
    const m = Math.floor(s / 60);
    const r = s % 60;
    return r === 0 ? m + "m" : m + "m " + r + "s";
  };

  function buildCadenceHtml(cad) {
    if (!cad || typeof cad !== "object") {
      return '<div class="cad-error">Cadence YAML is empty.</div>';
    }
    if (!Array.isArray(cad.phases) || cad.phases.length === 0) {
      return '<div class="cad-error">Cadence is missing a non-empty <code>phases</code> list.</div>';
    }

    const phases = cad.phases;
    const sum = phases.reduce((a, p) => a + (Number(p.duration_s) || 0), 0);
    const total = Number(cad.total_duration_s) || sum;
    const totalQs = phases.reduce(
      (a, p) => a + (Array.isArray(p.question_pool) ? p.question_pool.length : 0),
      0
    );
    const colorOf = (i) => (i % 6) + 1;

    let html = "";

    // Summary strip
    html += '<header class="cad-summary">';
    html += `<div class="cad-summary-stat"><span class="cad-stat-num">${escapeHtml(fmtDuration(total))}</span><span class="cad-stat-label">total</span></div>`;
    html += `<div class="cad-summary-stat"><span class="cad-stat-num">${phases.length}</span><span class="cad-stat-label">phase${phases.length === 1 ? "" : "s"}</span></div>`;
    if (totalQs > 0) {
      html += `<div class="cad-summary-stat"><span class="cad-stat-num">${totalQs}</span><span class="cad-stat-label">pool question${totalQs === 1 ? "" : "s"}</span></div>`;
    }
    if (cad.total_duration_s != null && Number(cad.total_duration_s) !== sum) {
      html += `<div class="cad-summary-stat cad-summary-warn"><span class="cad-stat-num">⚠ total ≠ Σ phases</span><span class="cad-stat-label">declared ${escapeHtml(fmtDuration(cad.total_duration_s))} · actual ${escapeHtml(fmtDuration(sum))}</span></div>`;
    }
    html += "</header>";

    // Proportional timeline
    html += '<div class="cad-timeline">';
    phases.forEach((p, i) => {
      const dur = Number(p.duration_s) || 0;
      const flex = Math.max(dur, 1);
      const c = colorOf(i);
      html += `<div class="cad-timeline-seg cad-seg-${c}" style="flex:${flex}" title="${escapeHtml(p.id || "")} · ${escapeHtml(fmtDuration(dur))}">`;
      html += `<span class="cad-timeline-label">${escapeHtml(p.id || "")}</span>`;
      html += `<span class="cad-timeline-sub">${escapeHtml(fmtDuration(dur))}</span>`;
      html += "</div>";
    });
    html += "</div>";

    // Phase cards
    html += '<ol class="cad-phase-stack">';
    phases.forEach((p, i) => {
      const c = colorOf(i);
      const dur = Number(p.duration_s) || 0;
      // Multi-question form: `coding_question_ids: [q1, q2, ...]`
      // Legacy form: `coding_question_id: q1`
      const codingIds = Array.isArray(p.coding_question_ids) && p.coding_question_ids.length
        ? p.coding_question_ids
        : (p.coding_question_id ? [p.coding_question_id] : []);
      const isCoding = codingIds.length > 0;
      const mode = isCoding ? "coding" : (p.question_mode || "generic");

      html += `<li class="cad-phase cad-phase-c${c}">`;
      html += '<header class="cad-phase-head">';
      html += `<span class="cad-phase-num">${i + 1}</span>`;
      html += `<h3 class="cad-phase-id">${escapeHtml(p.id || "(unnamed)")}</h3>`;
      html += `<span class="cad-phase-dur">${escapeHtml(fmtDuration(dur))}</span>`;
      html += `<span class="cad-phase-mode cad-mode-${escapeHtml(mode)}">${escapeHtml(mode)}</span>`;
      html += "</header>";

      if (p.intent) {
        html += `<p class="cad-phase-intent">${escapeHtml(p.intent)}</p>`;
      }

      if (isCoding) {
        // duration_s is the single source of truth for the editor countdown
        // and the phase deadline. Legacy coding_time_budget_s is ignored.
        const overrides = p.coding_question_time_overrides || {};
        html += '<div class="cad-coding-meta">';
        html += `<span class="cad-kv"><span class="cad-kv-k">questions</span><span class="cad-kv-v">${codingIds.length}</span></span>`;
        if (dur) {
          html += `<span class="cad-kv"><span class="cad-kv-k">time budget</span><span class="cad-kv-v">${escapeHtml(fmtDuration(dur))}</span></span>`;
        }
        html += `<button type="button" class="cad-coding-change" data-action="change-coding-question" data-phase-id="${escapeHtml(p.id || "")}" data-qids="${escapeHtml(codingIds.join(","))}">Change questions</button>`;
        html += "</div>";
        // One async preview per question in this phase.
        codingIds.forEach((qid) => {
          const ov = overrides[qid];
          const ovAttr = ov ? ` data-override-s="${ov}"` : "";
          html += `<div class="cad-coding-preview" data-qid="${escapeHtml(qid)}"${ovAttr}>`;
          html += '<span class="cad-coding-preview-loading">Loading question…</span>';
          html += "</div>";
        });
      }

      if (Array.isArray(p.generic_prompts) && p.generic_prompts.length) {
        html += '<div class="cad-phase-body">';
        html += `<h4 class="cad-section-h">Prompts <span class="cad-section-count">${p.generic_prompts.length}</span></h4>`;
        html += '<ul class="cad-prompts">';
        p.generic_prompts.forEach((t) => {
          html += `<li>${escapeHtml(String(t))}</li>`;
        });
        html += "</ul>";
        html += "</div>";
      }

      if (Array.isArray(p.question_pool) && p.question_pool.length) {
        html += '<div class="cad-phase-body">';
        html += `<h4 class="cad-section-h">Question pool <span class="cad-section-count">${p.question_pool.length}</span></h4>`;
        html += '<ol class="cad-pool">';
        p.question_pool.forEach((q) => {
          html += '<li class="cad-q">';
          if (q && (q.id || q.topic)) {
            html += '<div class="cad-q-head">';
            if (q.id) html += `<span class="cad-q-id">${escapeHtml(q.id)}</span>`;
            if (q.topic) html += `<span class="cad-q-topic">${escapeHtml(q.topic)}</span>`;
            html += "</div>";
          }
          if (q && q.text) {
            html += `<p class="cad-q-text">${escapeHtml(q.text)}</p>`;
          }
          // Coverage tags (current model) — concepts a complete answer must
          // address. Fall back to legacy follow_ups for un-migrated cadences.
          if (q && Array.isArray(q.coverage_tags) && q.coverage_tags.length) {
            html += '<details class="cad-q-followups">';
            html += `<summary>${q.coverage_tags.length} coverage tag${q.coverage_tags.length === 1 ? "" : "s"}</summary>`;
            html += "<ul>";
            q.coverage_tags.forEach((t) => {
              html += `<li>${escapeHtml(String(t))}</li>`;
            });
            html += "</ul>";
            html += "</details>";
          } else if (q && Array.isArray(q.follow_ups) && q.follow_ups.length) {
            html += '<details class="cad-q-followups">';
            html += `<summary>${q.follow_ups.length} follow-up${q.follow_ups.length === 1 ? "" : "s"}</summary>`;
            html += "<ul>";
            q.follow_ups.forEach((f) => {
              html += `<li>${escapeHtml(String(f))}</li>`;
            });
            html += "</ul>";
            html += "</details>";
          }
          html += "</li>";
        });
        html += "</ol>";
        html += "</div>";
      }

      html += "</li>";
    });
    html += "</ol>";

    return html;
  }

  function renderCadence(yamlText, container) {
    if (!container) return;
    if (typeof window.jsyaml === "undefined") {
      container.innerHTML =
        '<div class="cad-error">js-yaml not loaded — preview unavailable.</div>';
      return;
    }
    let cad;
    try {
      cad = window.jsyaml.load(yamlText);
    } catch (e) {
      container.innerHTML =
        '<div class="cad-error">YAML parse error:\n' + escapeHtml(String(e && e.message || e)) + "</div>";
      return;
    }
    container.innerHTML = buildCadenceHtml(cad);
    // Coding phases: async-fetch the picked question's prompt + starter
    // code from the admin API so admin can review without opening
    // library.yaml. One fetch per unique question id on this page.
    hydrateCodingPreviews(container).catch((err) => {
      console.warn("[coding-preview] hydrate failed:", err);
    });
  }

  // ── Coding question library cache (per-tab) ──────────────────────────
  const _codingQuestionCache = new Map();
  async function fetchCodingQuestion(qid) {
    if (!qid) return null;
    if (_codingQuestionCache.has(qid)) return _codingQuestionCache.get(qid);
    try {
      const r = await fetch(`/admin/coding/question/${encodeURIComponent(qid)}`, {
        credentials: "same-origin",
      });
      if (!r.ok) return null;
      const data = await r.json();
      if (!data.ok) return null;
      _codingQuestionCache.set(qid, data.question);
      return data.question;
    } catch (e) {
      return null;
    }
  }

  async function hydrateCodingPreviews(scope) {
    const placeholders = scope.querySelectorAll(".cad-coding-preview");
    for (const el of placeholders) {
      const qid = el.dataset.qid;
      const q = await fetchCodingQuestion(qid);
      if (!q) {
        el.innerHTML = `<span class="cad-coding-preview-err">Could not load <code>${escapeHtml(qid)}</code> — not in library?</span>`;
        continue;
      }
      const promptShort = (q.prompt || "").length > 240
        ? q.prompt.slice(0, 237) + "…" : (q.prompt || "");
      let html = "";
      html += '<div class="cad-coding-preview-body">';
      html += `<p class="cad-coding-preview-prompt">${escapeHtml(promptShort)}</p>`;
      html += '<div class="cad-coding-preview-meta">';
      html += `<span class="cad-kv"><span class="cad-kv-k">difficulty</span><span class="cad-kv-v">${escapeHtml(q.difficulty || "?")}</span></span>`;
      if (Array.isArray(q.topic) && q.topic.length) {
        html += `<span class="cad-kv"><span class="cad-kv-k">topics</span><span class="cad-kv-v">${escapeHtml(q.topic.join(", "))}</span></span>`;
      }
      html += `<span class="cad-kv"><span class="cad-kv-k">tests</span><span class="cad-kv-v">${q.test_case_count}</span></span>`;
      html += `<span class="cad-kv"><span class="cad-kv-k">hints</span><span class="cad-kv-v">${q.hint_count}</span></span>`;
      html += "</div>";
      html += '<details class="cad-coding-preview-starter">';
      html += '<summary>Starter code</summary>';
      html += `<pre><code>${escapeHtml(q.starter_code || "(empty)")}</code></pre>`;
      html += "</details>";
      html += "</div>";
      el.innerHTML = html;
    }
  }

  // ── Coding question picker modal ──────────────────────────────────
  // Self-contained: fetches /admin/coding/questions, renders a filterable
  // list, and on select either inserts a new coding_q1 + code_discussion
  // pair OR replaces the question on an existing coding phase.

  const codingPicker = (() => {
    let allQuestions = [];
    let mode = "add"; // "add" | "change"
    let changeContext = null; // {phase_id, qids} when mode==="change"
    // Multi-select: qids the admin has selected to insert in this open
    // session of the modal. Cleared on open. Time override values live
    // alongside: {qid → seconds-int} (or omitted if using the library default).
    const selectedQids = new Set();
    const timeOverrides = new Map();

    function modal() { return document.getElementById("coding_picker_modal"); }
    function results() { return document.getElementById("coding_picker_results"); }
    function searchEl() { return document.getElementById("coding_picker_search"); }
    function diffEl() { return document.getElementById("coding_picker_difficulty"); }
    function topicEl() { return document.getElementById("coding_picker_topic"); }
    function roleEl() { return document.getElementById("coding_picker_role"); }
    function countEl() { return document.getElementById("coding_picker_count"); }
    function titleEl() { return document.getElementById("coding_picker_title"); }

    async function loadQuestions() {
      try {
        const r = await fetch("/admin/coding/questions", { credentials: "same-origin" });
        const data = await r.json();
        if (!data.ok) throw new Error(data.error || "load failed");
        allQuestions = data.questions || [];
      } catch (e) {
        results().innerHTML = `<div class="cad-error">Couldn't load library: ${escapeHtml(String(e))}</div>`;
        allQuestions = [];
        return;
      }
      // Populate filter dropdowns from observed data
      const topics = new Set(), roles = new Set();
      allQuestions.forEach((q) => {
        (q.topic || []).forEach((t) => topics.add(t));
        (q.role_fit || []).forEach((r2) => roles.add(r2));
      });
      const buildOpts = (sel, vals, allLabel) => {
        sel.innerHTML = `<option value="">${allLabel}</option>` +
          [...vals].sort().map((v) => `<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`).join("");
      };
      buildOpts(topicEl(), topics, "All topics");
      buildOpts(roleEl(), roles, "All roles");
      render();
    }

    function render() {
      const q = (searchEl().value || "").toLowerCase();
      const d = diffEl().value;
      const t = topicEl().value;
      const r2 = roleEl().value;
      const filtered = allQuestions.filter((it) => {
        if (d && it.difficulty !== d) return false;
        if (t && !(it.topic || []).includes(t)) return false;
        if (r2 && !(it.role_fit || []).includes(r2)) return false;
        if (q) {
          const hay = (it.id + " " + (it.title || "") + " " + (it.prompt || "")).toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      });
      countEl().textContent = `${filtered.length} of ${allQuestions.length}`;
      if (!filtered.length) {
        results().innerHTML = '<div class="coding-picker-empty">No questions match these filters.</div>';
        return;
      }
      const defaultTimeFor = (d) => ({ easy: 600, medium: 1200, hard: 1800 }[d] || 600);
      let html = "";
      filtered.forEach((it) => {
        const promptShort = (it.prompt || "").length > 200
          ? it.prompt.slice(0, 197) + "…" : (it.prompt || "");
        const isSel = selectedQids.has(it.id);
        const override = timeOverrides.get(it.id);
        const defT = defaultTimeFor(it.difficulty);
        const tVal = override !== undefined ? Math.round(override / 60) : Math.round(defT / 60);
        html += `<article class="coding-picker-card ${isSel ? "coding-picker-card-selected" : ""}" data-qid="${escapeHtml(it.id)}">`;
        html += '<header>';
        html += `<label class="coding-picker-toggle"><input type="checkbox" class="coding-picker-checkbox" data-qid="${escapeHtml(it.id)}" ${isSel ? "checked" : ""}> <span class="visually-hidden">select</span></label>`;
        html += `<code class="coding-picker-id">${escapeHtml(it.id)}</code>`;
        html += `<span class="coding-picker-diff coding-picker-diff-${escapeHtml(it.difficulty || "easy")}">${escapeHtml(it.difficulty || "easy")}</span>`;
        if (Array.isArray(it.topic) && it.topic.length) {
          html += `<span class="coding-picker-topics">${escapeHtml(it.topic.join(", "))}</span>`;
        }
        html += '</header>';
        if (it.title && it.title !== it.id) {
          html += `<h4 class="coding-picker-title">${escapeHtml(it.title)}</h4>`;
        }
        html += `<p class="coding-picker-prompt">${escapeHtml(promptShort)}</p>`;
        html += '<footer>';
        html += `<span class="muted">${it.test_case_count} tests · ${it.hint_count} hints</span>`;
        // Per-question time (default by difficulty; admin can override)
        html += `<label class="coding-picker-time"><span class="muted">time</span> <input type="number" class="coding-picker-time-input" data-qid="${escapeHtml(it.id)}" min="1" max="120" value="${tVal}"> <span class="muted">min</span></label>`;
        html += '</footer>';
        html += "</article>";
      });
      results().innerHTML = html;
      updateInsertButton();
    }

    function updateInsertButton() {
      const btn = document.getElementById("coding_picker_insert");
      const count = selectedQids.size;
      if (btn) {
        const label = mode === "change"
          ? (count ? `Replace with ${count} question${count > 1 ? "s" : ""}` : "Pick a question")
          : (count ? `Insert ${count} question${count > 1 ? "s" : ""}` : "Pick at least one");
        btn.textContent = label;
        btn.disabled = count === 0;
      }
    }

    function open({ mode: m, phase_id, qids }) {
      mode = m;
      // qids may be a single string (legacy) or comma-separated list.
      const qidArr = Array.isArray(qids)
        ? qids
        : (qids ? String(qids).split(",").map(s => s.trim()).filter(Boolean) : []);
      changeContext = m === "change" ? { phase_id, qids: qidArr } : null;
      // Reset selections on each open
      selectedQids.clear();
      timeOverrides.clear();
      if (m === "change") {
        qidArr.forEach(q => selectedQids.add(q));
      }
      titleEl().textContent = m === "change"
        ? "Change coding questions"
        : "Pick coding question(s) — select one or more";
      modal().hidden = false;
      if (!allQuestions.length) {
        loadQuestions();
      } else {
        render();
      }
    }

    function close() { modal().hidden = true; }

    function applySelection() {
      const ta = document.getElementById("cadence_yaml");
      const previewEl = document.getElementById("cadence_preview");
      if (!ta) return alert("Cadence editor not found.");
      if (selectedQids.size === 0) {
        return alert("Pick at least one question first.");
      }
      let cad;
      try {
        cad = window.jsyaml.load(ta.value || "") || {};
      } catch (e) {
        alert("Cadence YAML is malformed; fix it first.\n" + e.message);
        return;
      }
      cad.phases = cad.phases || [];
      const chosen = Array.from(selectedQids);
      // Build the per-question time-override map (only entries that differ
      // from the library default — keeps YAML compact).
      const defaultTimeFor = (d) => ({ easy: 600, medium: 1200, hard: 1800 }[d] || 600);
      const overrides = {};
      chosen.forEach((qid) => {
        const q = allQuestions.find((it) => it.id === qid);
        const def = defaultTimeFor((q && q.difficulty) || "easy");
        const ov = timeOverrides.get(qid);
        if (ov !== undefined && ov !== def) overrides[qid] = ov;
      });
      // Total phase duration = sum of per-question times + small buffer
      const totalSecs = chosen.reduce((acc, qid) => {
        const q = allQuestions.find((it) => it.id === qid);
        const def = defaultTimeFor((q && q.difficulty) || "easy");
        return acc + (timeOverrides.get(qid) ?? def);
      }, 0);
      if (mode === "change" && changeContext) {
        const ph = cad.phases.find((p) => p && p.id === changeContext.phase_id);
        if (ph) {
          ph.coding_question_ids = chosen;
          delete ph.coding_question_id;  // drop legacy field if present
          if (Object.keys(overrides).length) {
            ph.coding_question_time_overrides = overrides;
          } else {
            delete ph.coding_question_time_overrides;
          }
          ph.duration_s = totalSecs;
        }
      } else {
        // Insert a new coding phase + paired code_discussion. The coding
        // phase carries the full list of question ids.
        const idx = pickInsertIndex(cad.phases);
        const newId = uniquePhaseId(cad.phases, "coding_round");
        const discId = uniquePhaseId(cad.phases, "code_discussion");
        const codingPhase = {
          id: newId,
          duration_s: totalSecs,
          intent: chosen.length > 1
            ? "Candidate solves multiple Python questions; AI observes silently."
            : "Candidate solves one Python question; AI observes silently.",
          question_mode: "generic",
          generic_prompts: [
            chosen.length > 1
              ? "Briefly tell the candidate we're going to do a short coding round with multiple questions. Each question has its own timer; they can work on them in any order. Let them begin when ready."
              : "Briefly tell the candidate we're going to do a short coding exercise. The question is on screen; they can ask if anything's unclear; otherwise let them begin.",
          ],
          coding_question_ids: chosen,
        };
        if (Object.keys(overrides).length) {
          codingPhase.coding_question_time_overrides = overrides;
        }
        const discussionPhase = {
          id: discId,
          duration_s: 60 * Math.max(1, chosen.length),  // ~1 min per question discussed
          intent: "Walk through the candidate's solution(s) and approach.",
          question_mode: "generic",
          generic_prompts: [
            "Ask the candidate to explain their approach, complexity, and edge cases they considered.",
          ],
        };
        cad.phases.splice(idx, 0, codingPhase, discussionPhase);
      }
      // Recompute total_duration_s if present
      const sum = cad.phases.reduce((acc, p) => acc + (Number(p.duration_s) || 0), 0);
      if (cad.total_duration_s !== undefined) cad.total_duration_s = sum;
      ta.value = window.jsyaml.dump(cad, { lineWidth: 100, noRefs: true });
      if (previewEl && typeof renderCadence === "function") {
        renderCadence(ta.value, previewEl);
      }
      close();
    }

    function pickInsertIndex(phases) {
      const ids = phases.map((p) => p && p.id);
      const after = ids.indexOf("resume_deep_dive");
      if (after >= 0) return after + 1;
      const w = ids.indexOf("warm_up");
      if (w >= 0) return w + 1;
      return Math.min(1, phases.length);
    }

    function uniquePhaseId(phases, base) {
      const ids = new Set(phases.map((p) => p && p.id));
      if (!ids.has(base)) return base;
      let i = 2;
      while (ids.has(`${base}${i}`)) i += 1;
      return `${base}${i}`;
    }

    // Event wiring
    document.addEventListener("click", (e) => {
      const target = e.target;
      if (!(target instanceof Element)) return;
      if (target.id === "btn_add_coding_phase") {
        e.preventDefault();
        open({ mode: "add" });
        return;
      }
      if (target.dataset && target.dataset.action === "change-coding-question") {
        e.preventDefault();
        // data-qids = comma-separated list (new) OR data-qid = single (legacy)
        const qids = target.dataset.qids || target.dataset.qid || "";
        open({ mode: "change", phase_id: target.dataset.phaseId, qids });
        return;
      }
      if (target.classList && (target.classList.contains("coding-picker-close")
          || target.classList.contains("coding-picker-cancel"))) {
        close();
        return;
      }
      if (target.id === "coding_picker_insert") {
        e.preventDefault();
        applySelection();
        return;
      }
      // Click outside dialog closes the modal
      const m = modal();
      if (m && !m.hidden && target === m) {
        close();
      }
    });

    // Checkbox toggle per question card
    document.addEventListener("change", (e) => {
      const target = e.target;
      if (!(target instanceof Element)) return;
      if (target.classList && target.classList.contains("coding-picker-checkbox")) {
        const qid = target.dataset.qid;
        if (target.checked) selectedQids.add(qid);
        else { selectedQids.delete(qid); timeOverrides.delete(qid); }
        // Toggle selected class on the card so the chrome reflects state
        const card = target.closest(".coding-picker-card");
        if (card) card.classList.toggle("coding-picker-card-selected", target.checked);
        updateInsertButton();
      }
    });

    // Per-question time input (admin override). Stored as seconds.
    document.addEventListener("input", (e) => {
      const target = e.target;
      if (!(target instanceof Element)) return;
      if (target.classList && target.classList.contains("coding-picker-time-input")) {
        const qid = target.dataset.qid;
        const mins = parseInt(target.value, 10);
        if (isNaN(mins) || mins < 1) return;
        timeOverrides.set(qid, mins * 60);
      }
    });

    // Filter inputs
    document.addEventListener("input", (e) => {
      const id = e.target && e.target.id;
      if (id === "coding_picker_search" || id === "coding_picker_difficulty"
          || id === "coding_picker_topic" || id === "coding_picker_role") {
        if (allQuestions.length) render();
      }
    });
    document.addEventListener("change", (e) => {
      const id = e.target && e.target.id;
      if (id === "coding_picker_difficulty" || id === "coding_picker_topic"
          || id === "coding_picker_role") {
        if (allQuestions.length) render();
      }
    });

    return { open, close };
  })();

  // ── copy candidate link buttons ───────────────────────────────────
  document.querySelectorAll(".copy-link").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const link = btn.dataset.link;
      try {
        await navigator.clipboard.writeText(link);
        const orig = btn.textContent;
        btn.textContent = "Copied ✓";
        setTimeout(() => { btn.textContent = orig; }, 1500);
      } catch (e) {
        // Fallback: select an input if one is nearby
        const input = document.getElementById("candidate_link");
        if (input) {
          input.focus();
          input.select();
        } else {
          alert(link);
        }
      }
    });
  });

  // ── schedule form: show selected filenames + handle drag-drop ────
  document.querySelectorAll(".drop-zone").forEach((zone) => {
    const input = zone.querySelector('input[type="file"]');
    const filenameEl = zone.querySelector(".drop-filename");
    if (!input || !filenameEl) return;
    const showName = () => {
      filenameEl.textContent = (input.files && input.files[0]) ? input.files[0].name : "";
    };
    input.addEventListener("change", showName);
    ["dragover", "dragenter"].forEach((ev) => {
      zone.addEventListener(ev, (e) => {
        e.preventDefault();
        e.stopPropagation();
        zone.classList.add("is-drag");
      });
    });
    ["dragleave"].forEach((ev) => {
      zone.addEventListener(ev, (e) => {
        e.preventDefault();
        zone.classList.remove("is-drag");
      });
    });
    zone.addEventListener("drop", (e) => {
      e.preventDefault();
      e.stopPropagation();
      zone.classList.remove("is-drag");
      const files = e.dataTransfer && e.dataTransfer.files;
      if (files && files.length > 0) {
        // Use a DataTransfer object to assign files programmatically — this
        // is the only cross-browser way to set <input type="file">.files.
        const dt = new DataTransfer();
        dt.items.add(files[0]);
        input.files = dt.files;
        showName();
      }
    });
  });

  // ── cadence Validate button ───────────────────────────────────────
  const btnValidate = document.getElementById("btn_validate");
  const yamlEl = document.getElementById("cadence_yaml");
  const resultEl = document.getElementById("validate_result");
  if (btnValidate && yamlEl && resultEl) {
    btnValidate.addEventListener("click", async () => {
      resultEl.className = "validate-result";
      resultEl.textContent = "Validating…";
      try {
        const r = await fetch("/api/cadence/validate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ yaml: yamlEl.value }),
        });
        const data = await r.json();
        if (data.ok) {
          resultEl.className = "validate-result ok";
          resultEl.textContent = "✓ valid";
        } else {
          resultEl.className = "validate-result err";
          resultEl.textContent = data.error || "invalid";
        }
      } catch (e) {
        resultEl.className = "validate-result err";
        resultEl.textContent = "Validation request failed: " + e;
      }
    });
  }

  // ── cadence Revise button (LLM-assisted iteration) ──────────────
  const btnRevise = document.getElementById("btn_revise");
  const feedbackEl = document.getElementById("cadence_feedback");
  const reviseStatus = document.getElementById("revise_status");
  if (btnRevise && feedbackEl && yamlEl) {
    btnRevise.addEventListener("click", async () => {
      const feedback = feedbackEl.value.trim();
      if (!feedback) {
        reviseStatus.textContent = "Enter feedback first.";
        reviseStatus.className = "feedback-status err";
        return;
      }
      btnRevise.disabled = true;
      reviseStatus.textContent = "Asking the AI to revise…";
      reviseStatus.className = "feedback-status";
      try {
        const r = await fetch("/api/cadence/revise", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ yaml: yamlEl.value, feedback }),
        });
        const data = await r.json();
        if (data.ok) {
          yamlEl.value = data.yaml;
          // Auto-clear the feedback so the admin can iterate again.
          feedbackEl.value = "";
          reviseStatus.textContent = "✓ revised — review the YAML, then validate or approve.";
          reviseStatus.className = "feedback-status ok";
          // Clear any prior validate-result since the YAML is now different.
          if (resultEl) { resultEl.textContent = ""; resultEl.className = "validate-result"; }
        } else {
          reviseStatus.textContent = data.error || "revise failed";
          reviseStatus.className = "feedback-status err";
        }
      } catch (e) {
        reviseStatus.textContent = "Request failed: " + e;
        reviseStatus.className = "feedback-status err";
      } finally {
        btnRevise.disabled = false;
      }
    });
  }

  // ── cadence customizer (pool-driven phase edit) ─────────────────
  const customizer = document.querySelector("[data-customizer]");
  if (customizer && yamlEl) {
    const token = customizer.dataset.token;
    const phaseSel = document.getElementById("cust_phase");
    const customWrap = document.getElementById("cust_custom_name_wrap");
    const customName = document.getElementById("cust_custom_name");
    const anchorSel = document.getElementById("cust_anchor");
    const poolSel = document.getElementById("cust_pool");
    const countEl = document.getElementById("cust_count");
    const btn = document.getElementById("btn_customize");
    const statusEl = document.getElementById("customize_status");
    const topicGroups = customizer.querySelectorAll("[data-pool]");

    const syncOther = () => {
      const isOther = phaseSel.value === "__other__";
      customWrap.hidden = !isOther;
      if (isOther && anchorSel && phaseSel.options.length > 1) {
        // Default anchor = the phase that was previously selected (last
        // non-__other__ option). Operator can change it.
      }
    };
    phaseSel.addEventListener("change", syncOther);
    syncOther();

    // Show only the topic chip set that matches the active pool file.
    // Topics differ per pool, so the template emits one [data-pool] block
    // per pool and we toggle visibility here. Defaults are pre-checked
    // on render (Jinja); switching pools doesn't reset selections — the
    // operator can switch pools to compare without losing their picks.
    const syncTopics = () => {
      const active = poolSel && poolSel.value;
      topicGroups.forEach(g => { g.hidden = g.dataset.pool !== active; });
    };
    if (poolSel) {
      poolSel.addEventListener("change", syncTopics);
      syncTopics();
    }

    const collectTopics = () => {
      const active = poolSel && poolSel.value;
      const group = customizer.querySelector(`[data-pool="${active}"]`);
      if (!group) return null;
      const picked = Array.from(group.querySelectorAll('input[type="checkbox"]:checked'))
                          .map(c => c.value);
      // Empty selection falls back to the defaults the template advertises
      // in its hint text — keeps the operator from accidentally requesting
      // "everything in the pool" when they meant "I didn't care, pick for me".
      if (picked.length === 0) return "transformers, rag, deep_learning";
      return picked.join(", ");
    };

    if (btn) {
      btn.addEventListener("click", async () => {
        const difficulty = (document.querySelector('input[name="cust_difficulty"]:checked') || {}).value;
        const count = parseInt(countEl.value, 10);
        if (!difficulty) { statusEl.textContent = "Pick a difficulty."; statusEl.className = "feedback-status err"; return; }
        if (!count || count < 1) { statusEl.textContent = "Count must be ≥ 1."; statusEl.className = "feedback-status err"; return; }
        if (!poolSel || !poolSel.value || poolSel.disabled) {
          statusEl.textContent = "No pool file selected."; statusEl.className = "feedback-status err"; return;
        }
        const isOther = phaseSel.value === "__other__";
        if (isOther && !customName.value.trim()) {
          statusEl.textContent = "Enter a custom phase name."; statusEl.className = "feedback-status err"; return;
        }

        const body = {
          yaml: yamlEl.value,
          difficulty,
          phase: phaseSel.value,
          custom_phase_name: isOther ? customName.value.trim() : null,
          anchor_phase: isOther && anchorSel ? anchorSel.value : null,
          pool_file: poolSel.value,
          count,
          topics: collectTopics(),
        };

        btn.disabled = true;
        statusEl.textContent = "Applying…";
        statusEl.className = "feedback-status";
        try {
          const r = await fetch(`/api/cadence/${token}/customize`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          });
          const data = await r.json();
          if (data.ok) {
            yamlEl.value = data.yaml;
            const warns = (data.warnings || []).join("; ");
            statusEl.textContent = warns
              ? `✓ applied — note: ${warns}`
              : "✓ applied — review the YAML, then validate or approve.";
            statusEl.className = "feedback-status ok";
            if (resultEl) { resultEl.textContent = ""; resultEl.className = "validate-result"; }
          } else {
            statusEl.textContent = data.error || "customize failed";
            statusEl.className = "feedback-status err";
          }
        } catch (e) {
          statusEl.textContent = "Request failed: " + e;
          statusEl.className = "feedback-status err";
        } finally {
          btn.disabled = false;
        }
      });
    }
  }

  // ── dynamic-difficulty enabler (adaptive phase) ────────────────
  const adaptiver = document.querySelector("[data-adaptive]");
  if (adaptiver && yamlEl) {
    const token = adaptiver.dataset.token;
    const phaseSel = document.getElementById("adapt_phase");
    const customWrap = document.getElementById("adapt_custom_name_wrap");
    const customName = document.getElementById("adapt_custom_name");
    const anchorSel = document.getElementById("adapt_anchor");
    const poolSel = document.getElementById("adapt_pool");
    const btn = document.getElementById("btn_adaptive");
    const statusEl = document.getElementById("adaptive_status");
    const previewEl = document.getElementById("cadence_preview");

    const syncOther = () => { customWrap.hidden = phaseSel.value !== "__other__"; };
    phaseSel.addEventListener("change", syncOther);
    syncOther();

    if (btn) {
      btn.addEventListener("click", async () => {
        if (!poolSel || !poolSel.value || poolSel.disabled) {
          statusEl.textContent = "No pool file selected."; statusEl.className = "feedback-status err"; return;
        }
        const isOther = phaseSel.value === "__other__";
        if (isOther && !customName.value.trim()) {
          statusEl.textContent = "Enter a custom phase name."; statusEl.className = "feedback-status err"; return;
        }
        const startDifficulty = (document.querySelector('input[name="adapt_start"]:checked') || {}).value || "easy";

        const body = {
          yaml: yamlEl.value,
          phase: phaseSel.value,
          custom_phase_name: isOther ? customName.value.trim() : null,
          anchor_phase: isOther && anchorSel ? anchorSel.value : null,
          pool_file: poolSel.value,
          start_difficulty: startDifficulty,
        };

        btn.disabled = true;
        statusEl.textContent = "Enabling…";
        statusEl.className = "feedback-status";
        try {
          const r = await fetch(`/api/cadence/${token}/customize_adaptive`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
          });
          const data = await r.json();
          if (data.ok) {
            yamlEl.value = data.yaml;
            // Refresh the preview (the textarea's input listener is debounced).
            if (previewEl && typeof renderCadence === "function") {
              renderCadence(yamlEl.value, previewEl);
            } else {
              yamlEl.dispatchEvent(new Event("input"));
            }
            const warns = (data.warnings || []).join("; ");
            statusEl.textContent = warns
              ? `✓ enabled — ${warns}`
              : "✓ dynamic difficulty enabled — review the YAML, then validate or approve.";
            statusEl.className = "feedback-status ok";
            if (resultEl) { resultEl.textContent = ""; resultEl.className = "validate-result"; }
          } else {
            statusEl.textContent = data.error || "enable failed";
            statusEl.className = "feedback-status err";
          }
        } catch (e) {
          statusEl.textContent = "Request failed: " + e;
          statusEl.className = "feedback-status err";
        } finally {
          btn.disabled = false;
        }
      });
    }
  }

  // ── performance dashboard: revise-with-feedback ──────────────────
  // POST the admin's feedback to the session's revise endpoint; on success
  // reload the page so the server re-renders the dashboard with the new
  // evaluation. (Re-rendering server-side is simpler than rebuilding all
  // the score bars / band styling client-side from the response JSON.)
  const btnReviseEval = document.getElementById("btn_revise_eval");
  const feedbackEvalEl = document.getElementById("eval_feedback");
  const reviseEvalStatus = document.getElementById("revise_eval_status");
  if (btnReviseEval && feedbackEvalEl) {
    btnReviseEval.addEventListener("click", async () => {
      const feedback = feedbackEvalEl.value.trim();
      if (!feedback) {
        reviseEvalStatus.textContent = "Type feedback first.";
        reviseEvalStatus.className = "feedback-status err";
        return;
      }
      const token = btnReviseEval.dataset.token;
      btnReviseEval.disabled = true;
      reviseEvalStatus.textContent = "Asking the AI to revise…";
      reviseEvalStatus.className = "feedback-status";
      try {
        const r = await fetch(`/api/sessions/${token}/evaluation/revise`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ feedback }),
        });
        const data = await r.json();
        if (data.ok) {
          reviseEvalStatus.textContent = "✓ revised — reloading…";
          reviseEvalStatus.className = "feedback-status ok";
          setTimeout(() => { window.location.reload(); }, 400);
        } else {
          reviseEvalStatus.textContent = data.error || "revise failed";
          reviseEvalStatus.className = "feedback-status err";
          btnReviseEval.disabled = false;
        }
      } catch (e) {
        reviseEvalStatus.textContent = "Request failed: " + e;
        reviseEvalStatus.className = "feedback-status err";
        btnReviseEval.disabled = false;
      }
    });
  }

  // ── session explorer: sidebar tabs + prompt drawer ────────────────
  const sx = document.querySelector(".sx");
  if (sx) {
    const navItems = Array.from(sx.querySelectorAll(".sx-nav-item"));
    const panels = Array.from(sx.querySelectorAll(".sx-panel"));
    const titleEl = sx.querySelector("[data-tab-title]");
    const validTabs = panels.map((p) => p.dataset.panel);
    const defaultTab = sx.dataset.defaultTab || (validTabs[0] || "summary");

    const activateTab = (tab, { updateHash = true } = {}) => {
      if (!validTabs.includes(tab)) tab = defaultTab;
      navItems.forEach((b) => b.classList.toggle("is-active", b.dataset.tab === tab));
      panels.forEach((p) => p.classList.toggle("is-active", p.dataset.panel === tab));
      const active = panels.find((p) => p.dataset.panel === tab);
      if (active && titleEl) titleEl.textContent = active.dataset.title || tab;
      // Scroll the content area back to the top on tab change.
      const body = sx.querySelector(".sx-body");
      if (body) body.scrollTop = 0;
      if (updateHash) {
        try { history.replaceState(null, "", "#" + tab); } catch (e) { location.hash = tab; }
      }
      // Let the page know (Mermaid renders lazily on first Flow view).
      document.dispatchEvent(new CustomEvent("sx:tab", { detail: tab }));
    };

    navItems.forEach((btn) => {
      btn.addEventListener("click", () => activateTab(btn.dataset.tab));
    });
    // "Jump to tab" buttons (e.g. Summary → Performance).
    sx.querySelectorAll("[data-jump]").forEach((btn) => {
      btn.addEventListener("click", () => activateTab(btn.dataset.jump));
    });
    // React to back/forward hash changes.
    window.addEventListener("hashchange", () => {
      const tab = (location.hash || "").replace(/^#/, "");
      if (validTabs.includes(tab)) activateTab(tab, { updateHash: false });
    });

    // Initial tab: URL hash if valid, else default.
    const initial = (location.hash || "").replace(/^#/, "");
    activateTab(validTabs.includes(initial) ? initial : defaultTab, { updateHash: false });

    // ── prompt drawer ──────────────────────────────────────────────
    // Bug fixes vs the previous implementation:
    //   1. `[data-prompt]` buttons are inside `<details>` elements that
    //      render content lazily. forEach-attached listeners only fire on
    //      buttons that existed at DOMContentLoaded; rows added later
    //      (or inside unopened <details>) silently did nothing on click.
    //      → use delegated click on document.
    //   2. The `hidden` attribute on .sx-drawer is overridden by the
    //      .sx-drawer { display: flex } rule, so `drawer.hidden = false`
    //      didn't actually unhide; the drawer was relying on the
    //      transform alone. We now force a reflow before adding
    //      `.is-open` so the transition always fires.
    //   3. If the matching <template id="…-data"> is missing (very old
    //      sessions, truncated event logs) the previous code silently
    //      returned. We now show a clear "Prompt not captured" message
    //      so the user knows the click registered.
    const drawer = sx.querySelector(".sx-drawer");
    const backdrop = sx.querySelector(".sx-drawer-backdrop");
    const drawerBody = sx.querySelector("[data-drawer-body]");
    const drawerTitle = sx.querySelector("[data-drawer-title]");

    const openDrawer = (promptId, agent, model) => {
      if (!drawer || !drawerBody) return;
      const tpl = document.getElementById(promptId + "-data");
      drawerBody.innerHTML = "";
      if (tpl) {
        drawerBody.appendChild(tpl.content.cloneNode(true));
      } else {
        drawerBody.innerHTML =
          '<div class="pv-section"><div class="pv-h">Prompt not captured</div>'
          + '<pre class="pv-pre muted">No template found for "' + promptId + '-data".\n'
          + "This can happen for very old sessions or when the event log was truncated.</pre></div>";
      }
      if (drawerTitle) {
        drawerTitle.textContent = model ? `${agent} · ${model}` : (agent || "LLM call");
      }
      drawer.hidden = false;
      if (backdrop) backdrop.hidden = false;
      // Force reflow so the .is-open class change is animated rather than
      // applied instantly together with the unhide.
      drawer.getBoundingClientRect();
      drawer.classList.add("is-open");
      drawer.setAttribute("aria-hidden", "false");
      if (backdrop) backdrop.classList.add("is-open");
    };

    const closeDrawer = () => {
      if (!drawer) return;
      drawer.classList.remove("is-open");
      drawer.setAttribute("aria-hidden", "true");
      if (backdrop) backdrop.classList.remove("is-open");
      // Hide after the transition so it's not focusable/while sliding out.
      setTimeout(() => {
        drawer.hidden = true;
        if (backdrop) backdrop.hidden = true;
        if (drawerBody) drawerBody.innerHTML = "";
      }, 280);
    };

    // Delegated click — works for any [data-prompt] anywhere in the page,
    // including those rendered inside collapsed <details> or added later.
    document.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-prompt]");
      if (btn) {
        openDrawer(
          btn.dataset.prompt,
          btn.dataset.agent || "",
          btn.dataset.model || ""
        );
        return;
      }
      if (e.target.closest("[data-drawer-close]")) closeDrawer();
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && drawer && !drawer.hidden) closeDrawer();
    });
  }

  // ── cadence-review: preview + edit-toggle wiring ────────────────
  // The textarea (#cadence_yaml) is the source of truth. The preview
  // re-renders on: page load, every textarea input (debounced), and
  // after any of the three mutating actions succeeds (Revise / Customize
  // — Validate doesn't change content, so no re-render needed there).
  const previewEl = document.getElementById("cadence_preview");
  if (previewEl && yamlEl) {
    renderCadence(yamlEl.value, previewEl);

    let inputTimer = null;
    yamlEl.addEventListener("input", () => {
      clearTimeout(inputTimer);
      inputTimer = setTimeout(() => renderCadence(yamlEl.value, previewEl), 250);
    });

    // Hook the existing Revise success path. The original handler updates
    // yamlEl.value then exits; we wrap a small "after value changed"
    // observer via a MutationObserver-style poll on the existing buttons'
    // status text — simpler though: just observe yamlEl.value changes
    // by re-checking on the same buttons' click after a microtask.
    // Cleanest: trigger an 'input' event after the upstream handlers run.
    const reRenderAfter = (btn) => {
      if (!btn) return;
      btn.addEventListener("click", () => {
        // The original handler is async; poll briefly for a value change.
        const before = yamlEl.value;
        let tries = 0;
        const tick = () => {
          if (yamlEl.value !== before || tries++ > 60) {
            renderCadence(yamlEl.value, previewEl);
            return;
          }
          setTimeout(tick, 200);
        };
        setTimeout(tick, 200);
      });
    };
    reRenderAfter(document.getElementById("btn_revise"));
    reRenderAfter(document.getElementById("btn_customize"));

    // Edit-mode toggle.
    const editBtn = document.getElementById("btn_edit_toggle");
    const editSection = document.getElementById("cadence_edit_section");
    if (editBtn && editSection) {
      editBtn.addEventListener("click", () => {
        const opening = editSection.hidden;
        editSection.hidden = !opening;
        editBtn.classList.toggle("is-active", opening);
        editBtn.textContent = opening ? "✓ Done editing" : "✎ Edit raw YAML";
        if (opening) {
          // Smooth scroll the editor into view + focus the textarea so the
          // operator can start typing immediately.
          editSection.scrollIntoView({ behavior: "smooth", block: "start" });
          setTimeout(() => yamlEl.focus({ preventScroll: true }), 250);
        } else {
          // Re-render once on close in case the operator typed something
          // during the last debounce window.
          renderCadence(yamlEl.value, previewEl);
        }
      });
    }
  }

  // ── session-detail Cadence tab: one-shot read-only render ────────
  const sessPreviewEl = document.getElementById("cadence_session_preview");
  const sessYamlSrc = document.getElementById("cad_session_yaml_src");
  if (sessPreviewEl && sessYamlSrc) {
    renderCadence(sessYamlSrc.textContent || "", sessPreviewEl);
  }

  // ── evaluation rubric panel (cadence-review page) ─────────────────
  // The rubric mirrors the cadence pattern: pretty view + raw-JSON edit
  // toggle. Source of truth while editing is the JSON textarea; the view
  // offers inline quick-edits (weight / dimensions / purpose) that PUT
  // immediately on Save. The panel watches the cadence textarea's phase
  // ids and flags the rubric out-of-sync when they drift.
  const rubricRoot = document.getElementById("rubric_root");
  if (rubricRoot && yamlEl) {
    const token = rubricRoot.dataset.token;
    const viewEl = document.getElementById("rubric_view");
    const editSec = document.getElementById("rubric_edit_section");
    const jsonTa = document.getElementById("rubric_json");
    const editBtn = document.getElementById("btn_rubric_edit");
    const regenBtn = document.getElementById("btn_rubric_regen");
    const syncWarn = document.getElementById("rubric_sync_warn");
    const syncRegenBtn = document.getElementById("btn_rubric_sync_regen");
    const srcBadge = document.getElementById("rubric_source_badge");
    const saveBtn = document.getElementById("btn_rubric_save");
    const saveStatus = document.getElementById("rubric_save_status");
    const valResult = document.getElementById("rubric_validate_result");

    let rubric = null; // current rubric object (mirrors server)
    let dims = {};     // canonical dims {name: definition}
    let dirty = false; // inline edits not yet saved

    const SOURCE_LABEL = { derived: "AI-derived", heuristic: "heuristic", ta_edited: "TA-edited" };

    function setBadge() {
      if (!srcBadge) return;
      if (!rubric) { srcBadge.hidden = true; return; }
      srcBadge.hidden = false;
      srcBadge.textContent = (SOURCE_LABEL[rubric.source] || rubric.source) + (dirty ? " · unsaved" : "");
      srcBadge.classList.toggle("rubric-badge-dirty", dirty);
    }

    function markDirty() {
      dirty = true;
      setBadge();
      const bar = viewEl.querySelector(".rubric-savebar");
      if (bar) bar.hidden = false;
    }

    // Mirrors buildCadenceHtml's visual vocabulary exactly — same summary
    // strip, proportional timeline (driven by weight instead of duration),
    // and cad-phase cards — so the two columns read as one design.
    function buildRubricHtml(r) {
      const sections = r.sections || [];
      const scored = sections.filter((s) => Number(s.weight) > 0);
      const totalW = scored.reduce((a, s) => a + Number(s.weight || 0), 0);

      let html = "";

      // Summary strip (mirrors .cad-summary).
      html += '<header class="cad-summary">';
      html += `<div class="cad-summary-stat"><span class="cad-stat-num">${sections.length}</span><span class="cad-stat-label">section${sections.length === 1 ? "" : "s"}</span></div>`;
      html += `<div class="cad-summary-stat"><span class="cad-stat-num">${scored.length}</span><span class="cad-stat-label">scored</span></div>`;
      html += `<div class="cad-summary-stat"><span class="cad-stat-num">${escapeHtml(String(totalW))}</span><span class="cad-stat-label">total weight</span></div>`;
      html += "</header>";

      // Weight timeline (mirrors .cad-timeline; quarantined = thin + dim).
      html += '<div class="cad-timeline">';
      sections.forEach((s, i) => {
        const c = (i % 6) + 1;
        const w = Number(s.weight) || 0;
        const flex = Math.max(w, 0.25);
        const dim = w === 0 ? " rubric-seg-quarantined" : "";
        html += `<div class="cad-timeline-seg cad-seg-${c}${dim}" style="flex:${flex}" title="${escapeHtml(s.phase_id)} · weight ${w}">`;
        html += `<span class="cad-timeline-label">${escapeHtml(s.phase_id)}</span>`;
        html += `<span class="cad-timeline-sub">${w === 0 ? "not scored" : "w " + escapeHtml(String(w))}</span>`;
        html += "</div>";
      });
      html += "</div>";

      // Seniority bar (typography mirrors .cad-section-h).
      html += '<div class="rubric-bar-line"><span class="cad-section-h rubric-bar-k">Seniority bar</span>';
      html += `<span class="rubric-bar-v">${escapeHtml(r.seniority_bar || "")}</span></div>`;

      // Section cards (mirrors .cad-phase-stack / .cad-phase).
      html += '<ol class="cad-phase-stack">';
      sections.forEach((s, i) => {
        const c = (i % 6) + 1;
        const quarantined = !(Number(s.weight) > 0);
        html += `<li class="cad-phase cad-phase-c${c} rubric-sec${quarantined ? " rubric-sec-quarantined" : ""}" data-idx="${i}">`;
        html += '<header class="cad-phase-head">';
        html += `<span class="cad-phase-num">${i + 1}</span>`;
        html += `<h3 class="cad-phase-id">${escapeHtml(s.phase_id)}</h3>`;
        html += `<label class="rubric-weight cad-phase-dur"><span>weight</span><input type="number" class="rubric-weight-input" data-idx="${i}" min="0" max="2" step="0.5" value="${Number(s.weight) || 0}"></label>`;
        html += quarantined
          ? '<span class="cad-phase-mode rubric-mode-quarantined" title="Weight 0 — shown but never scored">not scored</span>'
          : '<span class="cad-phase-mode rubric-mode-scored">scored</span>';
        html += "</header>";
        html += `<input type="text" class="rubric-purpose-input" data-idx="${i}" value="${escapeHtml(s.purpose || "")}" title="What hiring question does this section answer?">`;

        // Dimension chips — canonical set, toggle on click (max 3 active).
        html += '<div class="cad-phase-body">';
        html += `<h4 class="cad-section-h">Scores <span class="cad-section-count">${(s.score_dimensions || []).length}</span></h4>`;
        html += '<div class="rubric-dims">';
        Object.keys(dims).forEach((d) => {
          const on = (s.score_dimensions || []).includes(d);
          html += `<button type="button" class="rubric-dim-chip${on ? " is-on" : ""}" data-idx="${i}" data-dim="${escapeHtml(d)}" title="${escapeHtml(dims[d] || "")}">${escapeHtml(d.replace(/_/g, " "))}</button>`;
        });
        html += "</div>";
        html += "</div>";

        if (Array.isArray(s.ignore_dimensions) && s.ignore_dimensions.length) {
          html += `<details class="cad-q-followups rubric-details"><summary>${s.ignore_dimensions.length} deliberately ignored</summary><ul>`;
          s.ignore_dimensions.forEach((g) => { html += `<li>${escapeHtml(String(g))}</li>`; });
          html += "</ul></details>";
        }
        if (Array.isArray(s.anchors) && s.anchors.length) {
          // Same scale everywhere: each anchor level maps to a /10 score
          // band — the Performance tab shows "7/10 · solid" using this map.
          const BAND = { below_bar: "0–2", approaching: "3–4", mixed: "5–6", solid: "7–8", exceptional: "9–10" };
          html += `<details class="cad-q-followups rubric-details"><summary>${s.anchors.length} anchor levels</summary><ul>`;
          s.anchors.forEach((a) => {
            const hire = a.level === "solid" ? ' <span class="rubric-hirebar">← hire bar</span>' : "";
            const band = BAND[a.level] ? ` <span class="rubric-band">${BAND[a.level]}/10</span>` : "";
            html += `<li><strong>${escapeHtml(a.level)}</strong>${band}${hire} — ${escapeHtml(a.description)}</li>`;
          });
          html += "</ul></details>";
        }
        html += "</li>";
      });
      html += "</ol>";
      html += '<div class="rubric-savebar" hidden><button type="button" class="primary-btn rubric-save-inline">Save rubric changes</button><span class="feedback-status"></span></div>';
      return html;
    }

    function render() {
      if (!rubric) return;
      viewEl.innerHTML = buildRubricHtml(rubric);
      setBadge();
      if (jsonTa) jsonTa.value = JSON.stringify(rubric, null, 2);
      checkSync();
    }

    function showLoading(msg) {
      viewEl.innerHTML = `<div class="rubric-loading">${escapeHtml(msg)}</div>`;
    }

    function showError(msg) {
      viewEl.innerHTML = `<div class="cad-error">${escapeHtml(msg)}</div>`;
    }

    async function apiGet() {
      const r = await fetch(`/api/rubric/${encodeURIComponent(token)}`, { credentials: "same-origin" });
      if (r.status === 404) return null;
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || "rubric fetch failed");
      dims = data.dims || dims;
      return data.rubric;
    }

    async function apiGenerate() {
      const r = await fetch(`/api/rubric/${encodeURIComponent(token)}/generate`, {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ yaml: yamlEl.value }),
      });
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || "rubric generation failed");
      dims = data.dims || dims;
      return data.rubric;
    }

    async function apiPut(obj) {
      const r = await fetch(`/api/rubric/${encodeURIComponent(token)}`, {
        method: "PUT",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rubric: obj }),
      });
      const data = await r.json();
      if (!data.ok) throw new Error(data.error || "rubric save failed");
      return data.rubric;
    }

    function cadencePhaseIds() {
      try {
        const cad = window.jsyaml ? window.jsyaml.load(yamlEl.value) : null;
        if (!cad || !Array.isArray(cad.phases)) return null;
        return cad.phases.map((p) => String((p && p.id) || ""));
      } catch (e) {
        return null; // YAML mid-edit — don't flag sync on parse errors
      }
    }

    function checkSync() {
      if (!rubric || !syncWarn) return;
      const ids = cadencePhaseIds();
      if (!ids) { syncWarn.hidden = true; return; }
      const rids = (rubric.sections || []).map((s) => s.phase_id);
      syncWarn.hidden = JSON.stringify(ids) === JSON.stringify(rids);
    }

    async function regenerate(btn) {
      const original = btn ? btn.textContent : "";
      if (btn) { btn.disabled = true; btn.textContent = "Generating…"; }
      showLoading("Deriving rubric from the cadence…");
      try {
        rubric = await apiGenerate();
        dirty = false;
        render();
      } catch (e) {
        showError("Rubric generation failed: " + (e && e.message || e));
      } finally {
        if (btn) { btn.disabled = false; btn.textContent = original; }
      }
    }

    async function saveInline(statusEl) {
      try {
        if (statusEl) statusEl.textContent = "Saving…";
        rubric = await apiPut(rubric);
        dirty = false;
        render();
      } catch (e) {
        if (statusEl) statusEl.textContent = "✗ " + (e && e.message || e);
      }
    }

    // Inline quick-edits (event delegation on the view).
    viewEl.addEventListener("input", (e) => {
      const w = e.target.closest(".rubric-weight-input");
      if (w && rubric) {
        const s = rubric.sections[Number(w.dataset.idx)];
        if (s) { s.weight = Math.max(0, Math.min(2, Number(w.value) || 0)); markDirty(); }
        return;
      }
      const p = e.target.closest(".rubric-purpose-input");
      if (p && rubric) {
        const s = rubric.sections[Number(p.dataset.idx)];
        if (s) { s.purpose = p.value; markDirty(); }
      }
    });
    viewEl.addEventListener("click", (e) => {
      const chip = e.target.closest(".rubric-dim-chip");
      if (chip && rubric) {
        const s = rubric.sections[Number(chip.dataset.idx)];
        const d = chip.dataset.dim;
        if (!s) return;
        s.score_dimensions = s.score_dimensions || [];
        const at = s.score_dimensions.indexOf(d);
        if (at >= 0) s.score_dimensions.splice(at, 1);
        else if (s.score_dimensions.length < 3) s.score_dimensions.push(d);
        else return; // max 3 dims per section
        chip.classList.toggle("is-on", at < 0 && s.score_dimensions.includes(d));
        markDirty();
        return;
      }
      const save = e.target.closest(".rubric-save-inline");
      if (save) saveInline(save.nextElementSibling);
    });

    // Raw-JSON edit toggle (mirrors the cadence Edit raw YAML pattern).
    if (editBtn && editSec && jsonTa) {
      editBtn.addEventListener("click", () => {
        const opening = editSec.hidden;
        editSec.hidden = !opening;
        editBtn.classList.toggle("is-active", opening);
        editBtn.textContent = opening ? "✓ Close editor" : "✎ Edit";
        if (opening && rubric) jsonTa.value = JSON.stringify(rubric, null, 2);
      });
    }
    if (saveBtn && jsonTa) {
      saveBtn.addEventListener("click", async () => {
        let parsed;
        try {
          parsed = JSON.parse(jsonTa.value);
        } catch (e) {
          if (valResult) { valResult.textContent = "✗ JSON parse error: " + e.message; valResult.className = "validate-result validate-bad"; }
          return;
        }
        try {
          if (saveStatus) saveStatus.textContent = "Saving…";
          rubric = await apiPut(parsed);
          dirty = false;
          if (valResult) { valResult.textContent = "✓ saved"; valResult.className = "validate-result validate-ok"; }
          if (saveStatus) saveStatus.textContent = "";
          render();
        } catch (e) {
          if (valResult) { valResult.textContent = "✗ " + (e && e.message || e); valResult.className = "validate-result validate-bad"; }
          if (saveStatus) saveStatus.textContent = "";
        }
      });
    }

    if (regenBtn) regenBtn.addEventListener("click", () => regenerate(regenBtn));
    if (syncRegenBtn) syncRegenBtn.addEventListener("click", () => regenerate(syncRegenBtn));

    // Out-of-sync watcher: cheap phase-id comparison. Typed edits get an
    // immediate (debounced) check; the interval catches programmatic
    // textarea updates (Revise / Customize set .value directly, which
    // fires no input event). Note: background tabs throttle the interval
    // to ~1/min — fine, the TA is looking at the tab when it matters.
    let syncTimer = null;
    yamlEl.addEventListener("input", () => {
      clearTimeout(syncTimer);
      syncTimer = setTimeout(checkSync, 300);
    });
    setInterval(checkSync, 1500);

    // Initial load: GET; on 404 auto-generate — "once cadence is set up,
    // the rubric is created and shown".
    (async () => {
      showLoading("Loading rubric…");
      try {
        const existing = await apiGet();
        if (existing) {
          rubric = existing;
          render();
        } else {
          await regenerate(regenBtn);
        }
      } catch (e) {
        showError("Rubric unavailable: " + (e && e.message || e));
      }
    })();
  }
})();
