"""Scheduled-interview session store.

Migrated from raw sqlite3 onto the shared SQLAlchemy layer (``db/``) so the
whole product runs on ONE database — local SQLite by default, Postgres when
``DATABASE_URL`` is set. The public function surface is UNCHANGED
(init_db / get / list_recent / has_active_session / insert / update / archive
/ delete / now_iso / DB_PATH), and reads still return dict-like rows that
support ``row["col"]`` access, so the ~40 call sites need no edits.

Concurrency: the admin web process and the orchestrator subprocess both go
through this module. On SQLite the shared engine sets WAL (see db/engine.py),
matching the old raw-sqlite3 behaviour; on Postgres the server handles it.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import delete as _delete
from sqlalchemy import func
from sqlalchemy import insert as _insert
from sqlalchemy import select
from sqlalchemy import update as _update

from app.paths import DB_PATH, ensure_dirs  # DB_PATH kept for back-compat (admin logs it)
from db.engine import create_all, get_engine
from db.models import InterviewSession

# The Core table backing the dynamic insert(dict)/update(**fields) helpers.
_T = InterviewSession.__table__

__all__ = [
    "DB_PATH", "init_db", "now_iso", "get", "list_recent",
    "has_active_session", "count_active", "insert", "update", "archive", "delete",
]


def init_db() -> None:
    """Create the DB + all shared tables if missing. Idempotent.

    create_all() makes only MISSING tables, so an existing sessions.db keeps
    its data and simply gains the shortlist/roles tables alongside."""
    ensure_dirs()
    create_all()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _one(row) -> Optional[dict]:
    return dict(row) if row is not None else None


def get(token: str) -> Optional[dict]:
    with get_engine().connect() as c:
        row = c.execute(select(_T).where(_T.c.token == token)).mappings().first()
        return _one(row)


def list_recent(limit: int = 50) -> list[dict]:
    """Recent INTERVIEWS. Excludes role cadence templates: they are session rows
    so they can reuse the cadence editor, but they are never run and must not
    read as somebody's scheduled interview."""
    with get_engine().connect() as c:
        rows = c.execute(
            select(_T).where(_T.c.is_template.is_(False))
            .order_by(_T.c.created_at.desc()).limit(limit)
        ).mappings().all()
        return [dict(r) for r in rows]


def has_active_session() -> Optional[dict]:
    """Row of any session currently 'ready' or 'in_progress', else None.
    The single-at-a-time guard calls this before spawning."""
    with get_engine().connect() as c:
        row = c.execute(
            select(_T)
            .where(_T.c.status.in_(("ready", "in_progress")), _T.c.is_template.is_(False))
            .order_by(_T.c.created_at.desc())
            .limit(1)
        ).mappings().first()
        return _one(row)


def count_active() -> int:
    """How many interviews are live RIGHT NOW (status='in_progress').

    The scaled system runs many concurrently, so this is a live gauge for the
    dashboard — not the old single-at-a-time exclusivity check (has_active_session)."""
    with get_engine().connect() as c:
        return int(c.execute(
            select(func.count()).select_from(_T)
            .where(_T.c.status == "in_progress", _T.c.is_template.is_(False))
        ).scalar_one())


def count_scheduled() -> int:
    """How many interviews are scheduled but NOT yet started (status='ready').

    A scheduled interview has a candidate link but hasn't been claimed by any
    shard yet, so it's cluster-wide (not shard-pinned) — the dashboard plots it
    alongside the per-shard running count as "waiting to start" backlog."""
    with get_engine().connect() as c:
        return int(c.execute(
            select(func.count()).select_from(_T)
            .where(_T.c.status == "ready", _T.c.is_template.is_(False))
        ).scalar_one())


def insert(row: dict) -> None:
    with get_engine().begin() as c:
        c.execute(_insert(_T).values(**row))


def update(token: str, **fields) -> None:
    if not fields:
        return
    with get_engine().begin() as c:
        c.execute(_update(_T).where(_T.c.token == token).values(**fields))


def archive(token: str) -> None:
    """Soft-delete: reuse the 'cancelled' status (excluded by
    has_active_session) so an archived row stops blocking new schedules while
    its transcript/evaluation stay viewable; stamp ended_at for the UI."""
    with get_engine().begin() as c:
        c.execute(
            _update(_T).where(_T.c.token == token).values(
                status="cancelled", ended_at=now_iso()
            )
        )


def delete(token: str) -> None:
    """Hard-delete the row. Does NOT touch the on-disk session_dir — the
    caller rmtree's that separately if desired."""
    with get_engine().begin() as c:
        c.execute(_delete(_T).where(_T.c.token == token))
