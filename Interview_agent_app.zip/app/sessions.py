"""Session lifecycle service — bridges the form, DB, and filesystem.

Pure functions over the SQLite row + `sessions/<token>/` directory. No
FastAPI types in here; the route layer handles requests/responses.
"""
from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from fastapi import UploadFile

from app import db
from app.paths import session_dir

# Cadence generation now runs on the worker tier (app/jobs); create_draft /
# update_draft enqueue a job instead of calling generate_cadence_yaml inline.

logger = logging.getLogger(__name__)


@dataclass
class ScheduleForm:
    candidate_name: str
    role: str
    jd_text: Optional[str]
    jd_upload: Optional[UploadFile]
    resume_upload: UploadFile
    cadence_requirements_text: Optional[str]
    cadence_requirements_upload: Optional[UploadFile]
    # Record candidate camera+mic / screen to blob for fraud review. Default
    # on; the admin can opt out at schedule time. Immutable after creation —
    # update_draft ignores this field on edits (see its docstring).
    record_enabled: bool = True
    # Interview modality: "voice" (live spoken, today's default) or "text"
    # (typed/chat, question-driven & untimed). Admin-set at schedule time and
    # immutable after creation, like record_enabled. Drives cadence timing
    # (stamped via cadence_service.apply_modality_flag) and which tier runs it.
    modality: str = "voice"
    # A cadence authored ONCE for the whole role and applied verbatim to every
    # candidate (the Shortlist's "set up interviews" flow). When set, create_draft
    # uses it as-is: no LLM call, no cadence_gen job, no per-candidate variation.
    # That last part is the point — candidates answering different interviews
    # aren't comparable, which is what the Shortlist's ranking depends on.
    cadence_yaml: str = ""
    # Mint a ROLE CADENCE TEMPLATE rather than an interview — see
    # InterviewSession.is_template in db/models.py.
    is_template: bool = False
    # The Shortlist role this interview belongs to, when created from one.
    role_public_id: str = ""
    candidate_public_id: str = ""
    # Candidate's email — optional. When present, the approve step enqueues an
    # automated invite email (app/jobs invite_dispatch); when blank, the admin
    # just copy-pastes the candidate link as before. Mutable on every edit,
    # unlike record_enabled/modality (immutable after creation) — this is
    # contact info, not an interview setting. For interviews created FROM a
    # Shortlist candidate, features/shortlist/role_routes.py passes that
    # candidate's own resolved email in here at creation time.
    candidate_email: str = ""


async def _save_upload(upload: UploadFile, dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open("wb") as f:
        while True:
            chunk = await upload.read(64 * 1024)
            if not chunk:
                break
            f.write(chunk)
    return dest


def _safe_filename(name: Optional[str], default: str) -> str:
    if not name:
        return default
    safe = "".join(c for c in name if c.isalnum() or c in "._- ").strip()
    return safe or default


async def _enqueue_cadence_gen(token: str) -> None:
    """Put a cadence-generation job on the worker queue. Lazy import keeps the
    queue/jobs deps out of import time for callers that never schedule."""
    from app.jobs import jobs as _jobs
    await _jobs.enqueue(_jobs.CADENCE_GEN, {"token": token}, token=token)


async def _enqueue_resume_summary(token: str) -> None:
    """Precompute the resume summary on the worker (parse + LLM-summarize) so the
    interview never pays that ~20s+ LLM call on the candidate's start path. Fires
    for EVERY schedule that has a resume — independent of cadence-gen (which skips
    the no-JD case). The interview runner reads sessions.resume_summary; if it's
    empty (job not finished / not enqueued) it falls back to on-the-fly."""
    from app.jobs import jobs as _jobs
    await _jobs.enqueue(_jobs.RESUME_SUMMARY, {"token": token}, token=token)


async def create_draft(form: ScheduleForm) -> tuple[str, str]:
    """Persist uploaded files + generate cadence YAML via slow LLM.

    Creates a session row with status='draft' (no orchestrator spawned yet).
    Returns (token, cadence_yaml). Caller redirects to the cadence review page.
    """
    token = str(uuid.uuid4())
    sdir = session_dir(token)
    sdir.mkdir(parents=True, exist_ok=True)

    # ── persist uploads ──
    resume_fname = _safe_filename(form.resume_upload.filename, "resume")
    resume_path = await _save_upload(form.resume_upload, sdir / resume_fname)

    jd_path: Optional[Path] = None
    if form.jd_upload and form.jd_upload.filename:
        jd_fname = _safe_filename(form.jd_upload.filename, "jd")
        jd_path = await _save_upload(form.jd_upload, sdir / jd_fname)

    cr_path: Optional[Path] = None
    if form.cadence_requirements_upload and form.cadence_requirements_upload.filename:
        cr_fname = _safe_filename(form.cadence_requirements_upload.filename, "cadence_requirements")
        cr_path = await _save_upload(form.cadence_requirements_upload, sdir / cr_fname)

    # ── derive cadence-input text (the LLM sees this combined) ──
    cadence_req_text = (form.cadence_requirements_text or "").strip()
    if cr_path is not None and not cadence_req_text:
        try:
            cadence_req_text = cr_path.read_text(encoding="utf-8", errors="ignore")
        except Exception as e:
            logger.warning("[sessions] could not read cadence req file as text: %s", e)

    jd_text = (form.jd_text or "").strip()
    if jd_path is not None and not jd_text:
        # Only auto-read text files; PDFs/DOCX use attachments path inside
        # the cadence loader if we wanted, but here we keep it simple.
        if jd_path.suffix.lower() in (".txt", ".md"):
            try:
                jd_text = jd_path.read_text(encoding="utf-8", errors="ignore")
            except Exception:
                pass

    # ── cadence ──
    # No cadence input (no requirements text/file AND no JD text) → use the
    # default.yaml INLINE: instant, no tokens, predictable. Resume alone isn't
    # enough signal to bother generating.
    #
    # With input → the ~10s slow-LLM generation runs on the WORKER tier: insert a
    # 'generating' draft, enqueue a cadence_gen job, and return immediately so
    # bulk/creates don't block the request path. The cadence review screen polls
    # until the worker flips the row to 'draft'.
    modality = form.modality if form.modality in ("voice", "text") else "voice"
    # A role-level cadence wins over generating one: it was authored and approved
    # by a person for every candidate in this role, so regenerating per candidate
    # would both cost an LLM call and silently reintroduce the variation the
    # role template exists to remove.
    preset_yaml = (form.cadence_yaml or "").strip()
    # A cadence TEMPLATE never waits on the LLM. It is the screen the admin is
    # about to edit, so it must open with a working plan they can change — not a
    # blank one being generated somewhere else, which renders as a YAML parse
    # error for the seconds the worker is running. They tailor it in place with
    # the tools already on that page (question pools, add-a-phase, Revise with
    # AI), which is both faster and more predictable than a generated guess.
    needs_llm = bool(cadence_req_text or jd_text) and not preset_yaml and not form.is_template
    if preset_yaml:
        cadence_yaml = preset_yaml
        status = "draft"
    elif needs_llm:
        cadence_yaml = ""
        status = "generating"
    else:
        # No cadence input → built-in default. For text that's the untimed,
        # pool-backed default_text.yaml (so a text interview always runs); for
        # voice it's the wall-clock default.yaml.
        from engine.brain.cadence.schema import default_yaml_path_for
        default_path = default_yaml_path_for(modality)
        logger.info("[sessions] no cadence input — using %s", default_path.name)
        cadence_yaml = default_path.read_text(encoding="utf-8")
        status = "draft"

    # Recording is admin-set and immutable after creation — stamp it onto the
    # cadence deterministically (never left to the LLM) so the candidate lobby
    # can read it like everything else it consumes from cadence.yaml. No-op
    # when cadence_yaml is still blank (needs_llm branch); the cadence_gen job
    # stamps it once generation finishes.
    from app.cadence_service import apply_recording_flag, apply_modality_flag
    cadence_yaml = apply_recording_flag(cadence_yaml, bool(form.record_enabled))
    # Modality is admin-set and immutable — stamp the timing model (timed:
    # false for text) onto the cadence deterministically, like recording. No-op
    # when cadence_yaml is still blank (needs_llm branch); the cadence_gen job
    # re-stamps it once generation finishes. (`modality` resolved above.)
    cadence_yaml = apply_modality_flag(cadence_yaml, modality)

    # ── insert row ──
    db.insert({
        "token": token,
        "candidate_name": form.candidate_name,
        "role": form.role,
        "candidate_email": form.candidate_email.strip() or None,
        "jd_path": str(jd_path.relative_to(sdir)) if jd_path else None,
        "jd_text": jd_text or None,
        "resume_path": str(resume_path.relative_to(sdir)),
        "cadence_requirements_path": str(cr_path.relative_to(sdir)) if cr_path else None,
        "cadence_requirements_text": cadence_req_text or None,
        "cadence_yaml": cadence_yaml,
        "status": status,
        "pid": None,
        "ws_port": None,
        "http_port": None,
        "created_at": db.now_iso(),
        "started_at": None,
        "ended_at": None,
        "event_log_path": "events.jsonl",
        "record_enabled": bool(form.record_enabled),
        "modality": modality,
        "is_template": bool(form.is_template),
        "role_public_id": (form.role_public_id or None),
        "candidate_public_id": (form.candidate_public_id or None),
    })
    if needs_llm:
        await _enqueue_cadence_gen(token)
    # Precompute the resume summary async (a resume is always uploaded on create),
    # so the interview start path never makes the resume LLM call.
    # A template has no candidate — its resume is a placeholder, so there is
    # nothing to summarise and the job would be a wasted LLM call.
    if resume_path and not form.is_template:
        await _enqueue_resume_summary(token)
    return token, cadence_yaml


def update_cadence(token: str, cadence_yaml: str) -> None:
    db.update(token, cadence_yaml=cadence_yaml)


def write_cadence_to_disk(token: str, cadence_yaml: str) -> None:
    sdir = session_dir(token)
    sdir.mkdir(parents=True, exist_ok=True)
    (sdir / "cadence.yaml").write_text(cadence_yaml, encoding="utf-8")


async def update_draft(
    token: str,
    form: ScheduleForm,
    *,
    regenerate_cadence: bool,
) -> None:
    """Mutate an existing draft/ready row from the schedule form.

    File semantics: a newly uploaded file replaces the old one; if a slot
    is left empty (no upload), the existing file on disk + path in the
    row are preserved. Text fields are always overwritten.

    Cadence semantics: only regenerated when the caller asks for it.
    Most edits (typo in name, role tweak, JD update) shouldn't blow away
    cadence customizations the user already made on the review page —
    the checkbox lets them opt in when they actually want a fresh plan.
    """
    row = db.get(token)
    if row is None:
        raise ValueError(f"session not found: {token}")

    sdir = session_dir(token)
    sdir.mkdir(parents=True, exist_ok=True)

    # ── file replacements (only when a new upload is provided) ──
    resume_path: Path
    resume_replaced = bool(form.resume_upload and form.resume_upload.filename)
    if resume_replaced:
        resume_fname = _safe_filename(form.resume_upload.filename, "resume")
        resume_path = await _save_upload(form.resume_upload, sdir / resume_fname)
    else:
        resume_path = sdir / row["resume_path"]  # keep existing

    jd_path: Optional[Path]
    if form.jd_upload and form.jd_upload.filename:
        jd_fname = _safe_filename(form.jd_upload.filename, "jd")
        jd_path = await _save_upload(form.jd_upload, sdir / jd_fname)
    elif row["jd_path"]:
        jd_path = sdir / row["jd_path"]
    else:
        jd_path = None

    cr_path: Optional[Path]
    if form.cadence_requirements_upload and form.cadence_requirements_upload.filename:
        cr_fname = _safe_filename(form.cadence_requirements_upload.filename, "cadence_requirements")
        cr_path = await _save_upload(form.cadence_requirements_upload, sdir / cr_fname)
    elif row["cadence_requirements_path"]:
        cr_path = sdir / row["cadence_requirements_path"]
    else:
        cr_path = None

    # ── text fields: prefer the form value; fall back to file contents
    # so a JD typed in once still survives if the user re-opens the form. ──
    cadence_req_text = (form.cadence_requirements_text or "").strip()
    if not cadence_req_text and cr_path is not None:
        try:
            cadence_req_text = cr_path.read_text(encoding="utf-8", errors="ignore")
        except Exception as e:
            logger.warning("[sessions] could not read cadence req file as text: %s", e)

    jd_text = (form.jd_text or "").strip()
    if not jd_text and jd_path is not None and jd_path.suffix.lower() in (".txt", ".md"):
        try:
            jd_text = jd_path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            pass

    # ── cadence: regenerate only when the operator explicitly asked. ──
    cadence_yaml = row["cadence_yaml"]
    new_status: Optional[str] = None
    if regenerate_cadence:
        if not cadence_req_text and not jd_text:
            from engine.brain.cadence.schema import default_yaml_path_for
            from app.cadence_service import apply_recording_flag, apply_modality_flag
            _mod = row.get("modality") or "voice"
            cadence_yaml = default_yaml_path_for(_mod).read_text(encoding="utf-8")
            # Preserve the ORIGINAL (immutable) recording + modality settings —
            # read from the persisted row, never from this form submission.
            cadence_yaml = apply_recording_flag(cadence_yaml, bool(row.get("record_enabled")))
            cadence_yaml = apply_modality_flag(cadence_yaml, row.get("modality") or "voice")
            logger.info("[sessions] regenerate requested but no inputs — using default.yaml")
        else:
            # Regeneration (~10s LLM) runs on the worker tier: blank the cadence,
            # mark 'generating', enqueue below; the review screen polls until ready.
            cadence_yaml = ""
            new_status = "generating"

    db.update(
        token,
        candidate_name=form.candidate_name,
        role=form.role,
        candidate_email=form.candidate_email.strip() or None,
        jd_path=str(jd_path.relative_to(sdir)) if jd_path else None,
        jd_text=jd_text or None,
        resume_path=str(resume_path.relative_to(sdir)),
        cadence_requirements_path=str(cr_path.relative_to(sdir)) if cr_path else None,
        cadence_requirements_text=cadence_req_text or None,
        cadence_yaml=cadence_yaml,
        # record_enabled is intentionally NOT written here — it's set once at
        # creation and immutable after that (form.record_enabled is ignored on
        # every edit, including unrelated field changes and re-approvals).
        **({"status": new_status} if new_status else {}),
    )
    if new_status == "generating":
        await _enqueue_cadence_gen(token)
    # Re-summarize only when the resume file actually changed.
    if resume_replaced:
        await _enqueue_resume_summary(token)
