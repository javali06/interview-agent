"""Performance-evaluation pipeline.

After a session ends, this module:
  1. Reads the cadence + full transcript from the session's events.jsonl
  2. Asks the slow LLM to score the candidate against the cadence
  3. Validates the LLM output against a strict schema
  4. Writes the result to `sessions/<token>/evaluation.json`

The admin session-detail page reads evaluation.json and renders the
performance dashboard. A "Revise with feedback" loop lets the admin
iterate the evaluation (same pattern as the cadence editor).

Triggered:
  - automatically by orchestrator_new.live_main after SESSION_ENDED
  - manually via POST /admin/sessions/<token>/evaluate (regenerate)
  - iteratively via POST /api/evaluation/revise (feedback loop)
"""
from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import BaseModel, Field, ValidationError, conlist

from app.cadence_service import _resolve_llm
from app.paths import session_dir

logger = logging.getLogger(__name__)


# ── public schema (used by the template + the LLM prompt) ─────────────


class _DimensionScore(BaseModel):
    score: int = Field(..., ge=0, le=10)
    rationale: str


class _QuestionScore(BaseModel):
    id: str
    text: str
    score: int = Field(..., ge=0, le=10)
    rationale: str


class _PhaseScore(BaseModel):
    id: str
    name: str
    score: int = Field(..., ge=0, le=10)
    summary: str
    questions: list[_QuestionScore] = Field(default_factory=list)


class _Highlight(BaseModel):
    title: str
    detail: str


class _Overall(BaseModel):
    score: int = Field(..., ge=0, le=100)
    band: str  # "poor" | "avg" | "good" | "excellent"
    headline: str
    summary: str


class EvaluationModel(BaseModel):
    """Top-level evaluation JSON. Both the generate and revise paths
    produce / accept this shape."""

    generated_at: str
    model: str
    overall: _Overall
    dimensions: dict[str, _DimensionScore]
    phases: conlist(_PhaseScore, min_length=1)  # type: ignore[valid-type]
    strengths: conlist(_Highlight, min_length=1)  # type: ignore[valid-type]
    weaknesses: list[_Highlight] = Field(default_factory=list)


# ── band mapping ──────────────────────────────────────────────────────


_BANDS = [
    (0, 40, "poor"),
    (41, 60, "avg"),
    (61, 80, "good"),
    (81, 100, "excellent"),
]


def band_for_score(score: int) -> str:
    for lo, hi, name in _BANDS:
        if lo <= score <= hi:
            return name
    return "avg"


# ── transcript assembly ───────────────────────────────────────────────


def _read_events(path: Path) -> list[dict]:
    if not path.exists():
        return []
    out: list[dict] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return out


def _assemble_transcript(events: list[dict]) -> str:
    """Build a chronological 'AI: …' / 'Candidate: …' / 'Phase →' transcript
    suitable for the slow LLM to read in one pass.

    Includes:
      - ai_utterance
      - stt_final  (candidate speech)
      - phase_changed (as a section marker)
      - session_started / session_ended (bookends)
      - coding_phase_started / coding_code_submitted / coding_hint_delivered
        (so the LLM sees what the candidate did during silent coding phases —
        otherwise it would see an empty phase and score 0/10).
    """
    # Collapse durable-resume boundaries first: replace each interrupted phase's
    # pre-crash partial with the resumed run so the evaluator scores the RIGHT
    # thing (not a phantom restart from the greeting). See app/resume_collapse.
    from app.resume_collapse import collapse_resumed_events
    events = collapse_resumed_events(events)

    lines: list[str] = []
    for e in events:
        kind = e.get("kind", "")
        payload = e.get("payload") or {}
        if kind == "session_started":
            lines.append("[session started]")
        elif kind == "session_resumed":
            lines.append("")
            lines.append(
                "[interview resumed after a brief technical interruption — the "
                "abandoned partial attempt at this phase was discarded; scoring "
                "continues from here]"
            )
        elif kind == "session_ended":
            lines.append("[session ended]")
        elif kind == "phase_changed":
            # Ignore the QUEUED pre-announcement (queued=True). The director emits
            # phase_changed twice per transition — a queued one the instant the
            # phase clock expires (ungated, even mid-utterance) and the real
            # APPLIED one (reason="natural") once the candidate stops speaking
            # (director.py:746 vs 2264/2277/1841/1864). A candidate's answer to the
            # OLD phase finalizes between the two; heading on the queued marker
            # would render that answer under the NEW phase for the eval LLM. Only
            # emit the section heading on the applied marker.
            if payload.get("queued") is True:
                continue
            # Director emits {from_phase, to_phase}; older drafts emitted
            # {from, to} / {old_phase, new_phase}. Read from_phase/to_phase
            # FIRST — reading the legacy keys only meant every marker rendered
            # as "? → ?" and the eval LLM could not see phase boundaries.
            old = (
                payload.get("from_phase")
                or payload.get("from")
                or payload.get("old_phase")
                or "?"
            )
            new = (
                payload.get("to_phase")
                or payload.get("to")
                or payload.get("new_phase")
                or "?"
            )
            lines.append("")
            lines.append(f"── phase: {old} → {new} ──")
        elif kind == "ai_utterance":
            text = (payload.get("text") or "").strip()
            if text:
                lines.append(f"AI: {text}")
        elif kind == "interviewer_turn":
            # Observer (TA) push-to-talk: committed as a substitute AI turn.
            # Label explicitly so the eval LLM credits the follow-up to the
            # human interviewer, not the candidate or the model.
            text = (payload.get("text") or payload.get("transcript") or "").strip()
            if text:
                lines.append(f"Interviewer (TA): {text}")
        elif kind == "stt_final":
            text = (payload.get("text") or payload.get("transcript") or "").strip()
            if text:
                # Back-compat: older sessions emitted observer PTT as an
                # stt_final tagged speaker="interviewer" (now an
                # interviewer_turn event, handled above).
                if payload.get("speaker") == "interviewer":
                    lines.append(f"Interviewer (TA): {text}")
                else:
                    lines.append(f"Candidate: {text}")
        elif kind == "coding_phase_started":
            qid = payload.get("question_id") or "?"
            prompt = (payload.get("question_prompt") or "").strip()
            lines.append(f"[coding question: {qid}]")
            if prompt:
                lines.append(f"  question: {prompt}")
        elif kind == "coding_hint_delivered":
            lvl = payload.get("hint_level")
            txt = (payload.get("hint_text") or "").strip()
            if txt:
                lines.append(f"[hint {lvl}: {txt[:200]}]")
        elif kind == "coding_code_submitted":
            code = (payload.get("final_code") or "").rstrip()
            results = payload.get("final_test_results") or []
            passed = sum(
                1 for r in results if (r.get("pass") or r.get("passed"))
            ) if isinstance(results, list) else 0
            total = len(results) if isinstance(results, list) else 0
            runs = payload.get("runs_used") or 0
            lines.append("")
            lines.append(
                f"[candidate submitted code — {passed}/{total} tests passed, "
                f"{runs} run(s)]"
            )
            if code:
                lines.append("```python")
                # Cap at 4000 chars to avoid blowing the LLM's context on
                # pathological submissions.
                cap = 4000
                if len(code) > cap:
                    lines.append(code[:cap])
                    lines.append(f"... (truncated, {len(code) - cap} more chars)")
                else:
                    lines.append(code)
                lines.append("```")
    return "\n".join(lines)


# ── coding submission scoring ─────────────────────────────────────────


def _overwrite_coding_phase_scores(data: dict, coding_scores: list[dict]) -> None:
    # The eval LLM scores each phase from the transcript. Coding phases
    # have no speech transcript (AI is silent, candidate types) so the LLM
    # consistently undervalues them — typically 2/10 with "did not present
    # any code". Replace those phase scores with the composite from
    # `coding_quality`. With multi-question phases multiple submissions
    # map to the same phase, so we AVERAGE composites and concatenate
    # rationales.
    if not coding_scores:
        return
    # Group submissions by phase_id
    by_phase: dict[str, list[dict]] = {}
    for cs in coding_scores:
        phase_id = cs.get("phase_id")
        if not phase_id:
            continue
        by_phase.setdefault(phase_id, []).append(cs)

    def _one_composite(cs: dict) -> int:
        # Composite = avg of available numeric dimensions, scaled 0–10.
        # Falls back to pass_rate-only when LLM-judge fields are absent.
        dims = [
            float(cs.get(k))
            for k in ("correctness", "readability", "idiomatic", "edge_cases")
            if isinstance(cs.get(k), (int, float))
        ]
        if dims:
            return max(0, min(10, int(round(sum(dims) / len(dims)))))
        pass_rate = float(cs.get("pass_rate") or 0.0)
        return max(0, min(10, int(round(pass_rate * 10))))

    composite_by_phase: dict[str, tuple[int, str]] = {}
    for phase_id, subs in by_phase.items():
        per_q = [_one_composite(s) for s in subs]
        avg = int(round(sum(per_q) / len(per_q))) if per_q else 0
        if len(subs) == 1:
            cs = subs[0]
            pass_rate = float(cs.get("pass_rate") or 0.0)
            rationale = cs.get("rationale") or (
                f"Submitted code, {int(round(pass_rate * 100))}% of tests passed "
                f"({cs.get('runs_used', 0)} run(s), {cs.get('hints_used', 0)} hints used). "
                "Scored on code quality (correctness/readability/idiomatic/edge_cases) "
                "rather than transcript."
            )
        else:
            # Multi-question: short per-question line + the average.
            parts = []
            for s in subs:
                qid = s.get("question_id") or "?"
                comp = _one_composite(s)
                pr = int(round(float(s.get("pass_rate") or 0.0) * 100))
                parts.append(f"{qid}: {comp}/10 ({pr}% tests)")
            rationale = (
                f"Avg {avg}/10 across {len(subs)} questions. "
                + " | ".join(parts)
            )
        composite_by_phase[phase_id] = (avg, rationale[:300])

    phases = data.get("phases") or []
    for p in phases:
        pid = p.get("id")
        if pid in composite_by_phase:
            composite, rationale = composite_by_phase[pid]
            p["score"] = composite
            p["summary"] = rationale


def _score_coding_submissions(events: list[dict]) -> list[dict]:
    # Walk events.jsonl for coding_code_submitted; for each, look up the
    # question prompt + call coding.evaluate_submission. Per-phase: counts
    # hints used (coding_hint_delivered) and anti-cheat signals
    # (coding_anti_cheat). Returns a list of dicts ready for JSON.
    try:
        from features.coding import evaluate_submission as _eval_sub
        from features.coding import get_question as _get_q
    except Exception as ie:
        logger.info("[evaluation] coding module not importable: %s", ie)
        return []

    # Index hints + anti-cheat signals by phase_id so we can attribute them
    # to the matching submission.
    hints_by_phase: dict[str, int] = {}
    anti_cheat_by_phase: dict[str, list] = {}
    phase_start_by_phase: dict[str, int] = {}
    submissions: list[dict] = []

    for e in events:
        kind = e.get("kind", "")
        p = e.get("payload") or {}
        if kind == "coding_phase_started":
            ph = p.get("phase_id") or ""
            if ph:
                phase_start_by_phase[ph] = int(e.get("ts_ms") or 0)
        elif kind == "coding_hint_delivered":
            ph = p.get("phase_id") or ""
            if ph:
                hints_by_phase[ph] = hints_by_phase.get(ph, 0) + 1
        elif kind == "coding_anti_cheat":
            ph = p.get("phase_id") or ""
            if ph:
                anti_cheat_by_phase.setdefault(ph, []).append({
                    "reason": p.get("reason", ""),
                    "ts_ms": int(e.get("ts_ms") or 0),
                    "metadata": p.get("metadata") or {},
                })
        elif kind == "coding_code_submitted":
            ph = p.get("phase_id") or ""
            submissions.append({
                "phase_id": ph,
                "question_id": p.get("question_id") or "",  # multi-question form
                "final_code": p.get("final_code") or "",
                "final_test_results": p.get("final_test_results") or [],
                "runs_used": int(p.get("runs_used") or 0),
                "auto_submitted": bool(p.get("auto_submitted") or False),
                "ts_ms": int(e.get("ts_ms") or 0),
            })

    # Build a phase_id → questions[] map from coding_phase_started events
    # (multi-question form has a `questions` list; legacy has the question
    # fields at the top level).
    phase_qs: dict[str, list[dict]] = {}
    for ev in events:
        if ev.get("kind") != "coding_phase_started":
            continue
        pl = ev.get("payload") or {}
        ph_id = pl.get("phase_id") or ""
        if not ph_id:
            continue
        qs = pl.get("questions")
        if isinstance(qs, list) and qs:
            phase_qs[ph_id] = qs
        else:
            phase_qs[ph_id] = [{
                "question_id": pl.get("question_id") or "",
                "question_prompt": pl.get("question_prompt") or "",
            }]

    out: list[dict] = []
    for sub in submissions:
        ph = sub["phase_id"]
        qid: str = sub.get("question_id") or ""  # multi-question form
        q_prompt: str = ""
        # If the WS payload carried question_id (new form), match it against
        # the phase's question list. Otherwise fall back to the first
        # question on the phase.
        try:
            phase_questions = phase_qs.get(ph) or []
            match = next(
                (q for q in phase_questions if (q.get("question_id") or "") == qid),
                None,
            )
            if match is None and phase_questions:
                match = phase_questions[0]
                qid = match.get("question_id") or qid
            if match:
                q_prompt = match.get("question_prompt") or ""
            if qid and not q_prompt:
                q_prompt = _get_q(qid).prompt
        except Exception as qe:
            logger.warning("[evaluation] question lookup failed for %s: %s", ph, qe)

        time_to_submit_s = 0.0
        if ph in phase_start_by_phase and sub["ts_ms"]:
            delta_ms = sub["ts_ms"] - phase_start_by_phase[ph]
            if delta_ms > 0:
                time_to_submit_s = delta_ms / 1000.0

        try:
            score = _eval_sub(
                question_id=qid,
                final_code=sub["final_code"],
                test_results=sub["final_test_results"],
                runs_used=sub["runs_used"],
                time_to_submit_s=time_to_submit_s,
                hints_used=hints_by_phase.get(ph, 0),
                anti_cheat_signals=anti_cheat_by_phase.get(ph),
                use_llm_judge=True,
                question_prompt=q_prompt,
            )
        except Exception as se:
            logger.warning("[evaluation] evaluate_submission failed for %s: %s", ph, se)
            continue

        out.append({
            "phase_id": ph,
            "question_id": qid,
            "pass_rate": round(score.pass_rate, 3),
            "correctness": score.correctness,
            "readability": score.readability,
            "idiomatic": score.idiomatic,
            "edge_cases": score.edge_cases,
            "rationale": score.rationale or "",
            "runs_used": score.runs_used,
            "hints_used": score.hints_used,
            "time_to_submit_s": round(score.time_to_submit_s, 1),
            "anti_cheat_signals": score.anti_cheat_signals or [],
        })

    return out


# ── prompt ────────────────────────────────────────────────────────────


_SYSTEM_PROMPT = """\
You are a senior hiring manager scoring a voice-conducted technical
interview. You will receive:
  1. the interview cadence (phase structure + questions)
  2. the full transcript (AI questions + candidate answers, in order)
  3. the candidate's name, role, and resume summary
  4. (optional) JD text

Produce a STRICT JSON object that scores the candidate. Output ONLY the
JSON — no markdown fences, no preamble, no explanation. The JSON will be
parsed and pydantic-validated; malformed output is rejected.

SCHEMA:
{
  "generated_at":  string (ISO 8601 UTC timestamp),
  "model":         string (your model id, copy from the user prompt),
  "overall": {
    "score":    int 0..100,
    "band":     one of "poor" (0-40), "avg" (41-60), "good" (61-80), "excellent" (81-100),
    "headline": one short punchy sentence (≤14 words),
    "summary":  1-2 paragraph executive assessment (≤120 words total)
  },
  "dimensions": {
    "communication_clarity": { "score": int 0..10, "rationale": "≤30 words" },
    "technical_depth":       { "score": int 0..10, "rationale": "≤30 words" },
    "problem_solving":       { "score": int 0..10, "rationale": "≤30 words" },
    "role_fit":              { "score": int 0..10, "rationale": "≤30 words" }
  },
  "phases": [
    {
      "id":      snake_case phase id from the cadence,
      "name":    pretty name (Title Case, e.g. "Project Architecture"),
      "score":   int 0..10,
      "summary": one sentence on how the candidate did in this phase,
      "questions": []  // for generic-mode phases
                       // For specific-mode phases, list per-question scores:
                       // [{ "id": pool id, "text": question text,
                       //    "score": int 0..10, "rationale": "≤30 words" }, ...]
    },
    ...
  ],
  "strengths":  [{"title": "≤6 words", "detail": "1 sentence"}, ...]  // 3-5 items
  "weaknesses": [{"title": "≤6 words", "detail": "1 sentence"}, ...]  // 2-4 items, may be empty if candidate was excellent
}

HARD CONSTRAINTS:
  - Output JSON only. No code fences, no leading text.
  - "band" MUST match "score": poor 0-40, avg 41-60, good 61-80, excellent 81-100.
  - phases array: ONE entry per cadence phase, IN ORDER, ids must match the
    cadence YAML exactly (warm_up, project_architecture, etc.).
  - For specific-mode phases (e.g. genai_basics with a question_pool):
    include one entry in `questions` for EACH question that was actually
    presented to the candidate. Question ids and texts must match the
    cadence pool exactly.
  - Be HONEST and EVIDENCE-BASED. Cite the candidate's words when relevant
    in the rationale. Don't be generous — if a candidate dodged or answered
    shallowly WHAT WAS ACTUALLY ASKED, reflect that in the score.
  - SCORE ONLY WHAT WAS ASKED. Judge each answer against the question as
    phrased, plus any follow-ups the interviewer ACTUALLY DELIVERED in the
    transcript — never against an ideal-answer checklist. Candidates do not
    volunteer specifics nobody asked for:
      * No deduction for missing metrics/numbers unless the question (or a
        delivered follow-up) explicitly asked for outcomes or measurements.
      * No deduction for unmentioned aspects (scalability, component
        interaction, tradeoffs) the question never named.
      * Mathematical formalism (formulas, derivations, exact notation) is
        NEVER required in a spoken answer unless explicitly requested —
        conceptual correctness at the role's level is the bar.
    If a detail you wanted is absent because nobody probed for it, write
    "not probed: <detail>" in the rationale — that is feedback on question
    design for the next round, NOT a candidate deduction.
  - The candidate is being scored, not the AI interviewer. Issues caused by
    the AI (cut off questions, ambiguous prompts, missing follow-ups) must
    NOT lower the candidate's score.
  - If an entire phase had no candidate input (e.g. interview ended early),
    score it 0 and note "no response" in summary — a no-data marker, not
    evidence of weakness. Don't fabricate.
"""


def _user_prompt(
    *,
    candidate_name: str,
    role: str,
    resume_summary: str,
    jd_text: str,
    cadence_yaml: str,
    transcript: str,
    model: str,
    feedback: Optional[str] = None,
    prior_evaluation_json: Optional[str] = None,
    rubric_json: Optional[str] = None,
) -> str:
    parts = [
        f"MODEL ID (copy verbatim into generated `model` field): {model}",
        f"GENERATED_AT (copy verbatim into `generated_at`): {datetime.now(timezone.utc).isoformat()}",
        "",
        f"CANDIDATE: {candidate_name}",
        f"ROLE: {role}",
        f"RESUME SUMMARY:\n{resume_summary or '(none provided)'}",
    ]
    if jd_text:
        parts.append(f"\nJD:\n{jd_text}")
    parts.append("\nCADENCE YAML:")
    parts.append(f"```yaml\n{cadence_yaml}\n```")
    if rubric_json:
        parts.append(
            "\nEVALUATION RUBRIC (TA-approved, per-phase lenses — FOLLOW IT):\n"
            "For each phase: judge ONLY its score_dimensions, respect its "
            "ignore_dimensions, and calibrate to the stated anchors and "
            "seniority_bar. Phases with weight 0 are quarantined — describe "
            "them in their phase summary but give them NO influence on the "
            "overall score or the cross-cutting dimensions."
        )
        parts.append(f"```json\n{rubric_json}\n```")
    parts.append("\nFULL TRANSCRIPT (chronological):")
    parts.append(f"```\n{transcript}\n```")
    if feedback and prior_evaluation_json:
        parts.append("\nADMIN FEEDBACK on the prior evaluation (revise accordingly):")
        parts.append(feedback.strip())
        parts.append("\nPRIOR EVALUATION (revise this; keep good parts, fix what the feedback flags):")
        parts.append(f"```json\n{prior_evaluation_json}\n```")
    parts.append("\nReturn the evaluation JSON now.")
    return "\n".join(parts)


# ── core entrypoints ──────────────────────────────────────────────────


_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL)


def _strip_fences(text: str) -> str:
    m = _FENCE_RE.search(text)
    return m.group(1).strip() if m else text.strip()


def _normalize_band(payload: dict) -> dict:
    """Enforce the band ↔ score mapping client-side as a safety net in
    case the LLM produced a mismatched band."""
    try:
        score = int(payload["overall"]["score"])
        payload["overall"]["band"] = band_for_score(score)
    except (KeyError, TypeError, ValueError):
        pass
    return payload


def _eval_path(token: str) -> Path:
    return session_dir(token) / "evaluation.json"


def build_coding_performance(
    evaluation: Optional[dict], phases: list[dict],
) -> Optional[dict]:
    """Compose a per-question coding view-model for the Performance tab.

    Joins two sources:
      - `evaluation['coding_quality']` — LLM-judge dims (correctness,
        readability, idiomatic, edge_cases) + pass_rate per submission.
      - `phases[*]['coding_submissions']` — per-test pass/fail verdicts
        plus the actual submitted code (from events.jsonl, via
        event_viewer.group_by_phase).

    Returned shape (None when no coding submissions exist at all so the
    template can skip the section cleanly):

        {
          "phases": [
            {
              "id": str, "name": str,
              "submitted_count": int, "expected_count": int,
              "auto_count": int, "missing_count": int,
              "passed_tests": int, "total_tests": int,
              "questions": [
                {
                  "question_id": str,
                  "prompt": str | None,           # short snippet only
                  "submitted": bool,
                  "auto_submitted": bool,
                  "passed": int, "total": int,
                  "pass_rate_pct": int,           # 0..100
                  "composite_score": int,         # 0..10
                  "correctness": int|None,
                  "readability": int|None,
                  "idiomatic": int|None,
                  "edge_cases": int|None,
                  "rationale": str,
                  "runs_used": int,
                  "hints_used": int,
                  "time_to_submit_s": float,
                  "test_results": list[dict],     # raw per-test verdicts
                  "code": str,
                },
                ...
              ],
            },
            ...
          ],
          "overall": {
            "total_submitted": int,
            "total_expected": int,
            "total_passed_tests": int,
            "total_tests": int,
            "avg_composite": int,                # 0..10
          },
        }
    """
    scores: list[dict] = []
    if evaluation:
        scores = list(evaluation.get("coding_quality") or [])

    # Index scores by (phase_id, question_id) so we can attach the
    # LLM-judge dims to each submitted question.
    by_key: dict[tuple[str, str], dict] = {}
    for s in scores:
        by_key[(s.get("phase_id") or "", s.get("question_id") or "")] = s

    def _composite(s: dict) -> int:
        dims = [
            float(s[k]) for k in ("correctness", "readability",
                                   "idiomatic", "edge_cases")
            if isinstance(s.get(k), (int, float))
        ]
        if dims:
            return max(0, min(10, int(round(sum(dims) / len(dims)))))
        pr = float(s.get("pass_rate") or 0.0)
        return max(0, min(10, int(round(pr * 10))))

    out_phases: list[dict] = []
    total_submitted = 0
    total_expected = 0
    total_passed = 0
    total_tests = 0
    composites: list[int] = []

    for ph in phases:
        questions = ph.get("coding_questions") or []
        submissions = ph.get("coding_submissions") or []
        if not questions and not submissions:
            continue

        # Submission lookup by question_id; positional fallback below for
        # legacy submissions that didn't carry question_id.
        sub_by_qid: dict[str, dict] = {}
        for sub in submissions:
            qid = sub.get("question_id") or ""
            if qid:
                sub_by_qid[qid] = sub

        out_questions: list[dict] = []
        phase_passed = 0
        phase_total = 0
        auto_count = 0
        sub_count = 0
        for idx, q in enumerate(questions):
            qid = q.get("question_id") or ""
            sub = sub_by_qid.get(qid)
            if sub is None and idx < len(submissions):
                # Positional fallback for legacy single-question form.
                candidate = submissions[idx]
                if not candidate.get("question_id"):
                    sub = candidate
            score = by_key.get((ph["id"], qid)) if qid else None
            passed = int(sub.get("passed") if sub else 0)
            total = int(sub.get("total") if sub else 0)
            phase_passed += passed
            phase_total += total
            submitted = sub is not None
            if submitted:
                sub_count += 1
                if sub.get("auto_submitted"):
                    auto_count += 1
            composite = _composite(score) if score else None
            if composite is not None:
                composites.append(composite)
            prompt = (q.get("question_prompt") or "").strip()
            if len(prompt) > 240:
                prompt = prompt[:237] + "…"
            out_questions.append({
                "question_id": qid,
                "prompt": prompt or None,
                "submitted": submitted,
                "auto_submitted": bool(sub.get("auto_submitted")) if sub else False,
                "passed": passed,
                "total": total,
                "pass_rate_pct": int(round(100.0 * passed / total)) if total else 0,
                "composite_score": composite if composite is not None else 0,
                "has_score": composite is not None,
                "correctness": (score or {}).get("correctness"),
                "readability": (score or {}).get("readability"),
                "idiomatic": (score or {}).get("idiomatic"),
                "edge_cases": (score or {}).get("edge_cases"),
                "rationale": (score or {}).get("rationale") or "",
                "runs_used": int(sub.get("runs_used")) if sub else 0,
                "hints_used": int((score or {}).get("hints_used") or 0),
                "time_to_submit_s": float((score or {}).get("time_to_submit_s") or 0.0),
                "test_results": sub.get("test_results") if sub else [],
                "code": sub.get("code") if sub else "",
            })

        total_submitted += sub_count
        total_expected += len(questions)
        total_passed += phase_passed
        total_tests += phase_total
        out_phases.append({
            "id": ph["id"],
            "name": ph["id"].replace("_", " ").title(),
            "submitted_count": sub_count,
            "expected_count": len(questions),
            "missing_count": max(0, len(questions) - sub_count),
            "auto_count": auto_count,
            "passed_tests": phase_passed,
            "total_tests": phase_total,
            "questions": out_questions,
        })

    if not out_phases:
        return None

    avg = int(round(sum(composites) / len(composites))) if composites else 0
    return {
        "phases": out_phases,
        "overall": {
            "total_submitted": total_submitted,
            "total_expected": total_expected,
            "total_passed_tests": total_passed,
            "total_tests": total_tests,
            "avg_composite": avg,
        },
    }


def load_evaluation(token: str) -> Optional[dict]:
    """Read evaluation.json from disk if present. Returns None if missing."""
    p = _eval_path(token)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        logger.warning("[evaluation] couldn't parse %s: %s", p, e)
        return None


async def generate_evaluation(
    token: str,
    *,
    feedback: Optional[str] = None,
    prior: Optional[dict] = None,
) -> dict:
    """Generate (or revise) a performance evaluation for the given session.

    Writes `sessions/<token>/evaluation.json` and returns the parsed dict.
    Raises RuntimeError / ValueError on validation failure after one retry.
    """
    from app import db as admin_db
    from openai import AsyncOpenAI

    row = admin_db.get(token)
    if row is None:
        raise ValueError(f"session {token!r} not found in SQLite")

    sdir = session_dir(token)
    event_log_path = sdir / (row["event_log_path"] or "events.jsonl")
    events = _read_events(event_log_path)
    transcript = _assemble_transcript(events)

    cadence_yaml = row["cadence_yaml"] or ""

    # Resume + JD: pull from session dir + DB.
    resume_summary = ""
    if row["resume_path"]:
        # The orchestrator already parsed the resume into the LLM's system
        # prompt at session time, but we don't have that text directly here.
        # Re-parse for the evaluator. Defensive — if it fails, proceed empty.
        try:
            from engine.orchestrator.resume_parser import parse_resume
            resume_summary = parse_resume(sdir / row["resume_path"])[:6000]
        except Exception as e:
            logger.warning("[evaluation] resume parse failed: %s", e)

    jd_text = (row["jd_text"] or "").strip()

    # TA-approved evaluation rubric (cadence-driven lenses). Best-effort:
    # absent or disabled -> the prompt simply omits the rubric block.
    rubric_json: Optional[str] = None
    rubric_fp: Optional[str] = None
    try:
        import features.eval as rubric_mod

        if rubric_mod.is_enabled():
            current_rubric = rubric_mod.load_rubric(token)
            if current_rubric:
                rubric_json = json.dumps(current_rubric, indent=2)
                rubric_fp = rubric_mod.rubric_fingerprint(current_rubric)
    except Exception as e:
        logger.warning("[evaluation] rubric load failed (ignored): %s", e)

    api_key, base_url, model = _resolve_llm()
    client = AsyncOpenAI(api_key=api_key, base_url=base_url)

    prior_json: Optional[str] = None
    if prior is not None and feedback:
        prior_json = json.dumps(prior, indent=2)

    # OpenRouter tuning for this one-shot batch call: route by THROUGHPUT
    # to fast serving providers (Groq/Cerebras-class) — default routing has
    # landed on slow providers for gpt-oss-120b. Ignored off-OpenRouter.
    extra_body = (
        {"provider": {"sort": "throughput"}}
        if "openrouter" in (base_url or "") else {}
    )

    last_error: Optional[str] = None
    for attempt in (1, 2):
        try:
            resp = await client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": _SYSTEM_PROMPT},
                    {"role": "user", "content": _user_prompt(
                        candidate_name=row["candidate_name"],
                        role=row["role"],
                        resume_summary=resume_summary,
                        jd_text=jd_text,
                        cadence_yaml=cadence_yaml,
                        transcript=transcript,
                        model=model,
                        feedback=feedback,
                        prior_evaluation_json=prior_json,
                        rubric_json=rubric_json,
                    )},
                ],
                temperature=0.2,
                max_tokens=4000,
                response_format={"type": "json_object"},
                extra_body=extra_body,
            )
        except Exception as e:
            raise RuntimeError(f"LLM call failed during evaluation: {e}") from e

        raw = (resp.choices[0].message.content or "").strip()
        body = _strip_fences(raw)
        try:
            data = json.loads(body)
        except json.JSONDecodeError as e:
            last_error = f"JSON parse error: {e}"
            logger.warning("[evaluation] attempt %d JSON parse failed: %s", attempt, e)
            continue

        data = _normalize_band(data)
        try:
            EvaluationModel.model_validate(data)
        except ValidationError as e:
            last_error = str(e)
            logger.warning("[evaluation] attempt %d schema invalid:\n%s", attempt, e)
            continue

        # Coding submissions: orthogonal to transcript-based scoring. Walk
        # events for coding_code_submitted, call coding.evaluate_submission
        # for each, attach under `coding_quality` (extra field — pydantic
        # ignores; persisted to disk). Best-effort; if coding lib missing
        # or LLM-judge fails, skips silently.
        try:
            coding_scores = _score_coding_submissions(events)
            if coding_scores:
                data["coding_quality"] = coding_scores
                # Replace the LLM's transcript-based score for each coding
                # phase with the deterministic+LLM-judge composite. The
                # transcript LLM sees no candidate speech during the silent
                # coding phase and tends to score it ~2/10 ("did not present
                # any code") even when a working submission was made.
                _overwrite_coding_phase_scores(data, coding_scores)
                logger.info(
                    "[evaluation] attached %d coding submission score(s)",
                    len(coding_scores),
                )
        except Exception as ce:
            logger.warning("[evaluation] coding scoring skipped: %s", ce)

        # Stamp whether the TA-approved rubric guided this evaluation AND
        # which version of it (semantic fingerprint), so the Performance
        # tab can flag evaluations generated before the rubric existed OR
        # under an older rubric (extra fields — pydantic ignores; persisted).
        data["rubric_used"] = rubric_json is not None
        if rubric_fp is not None:
            data["rubric_fingerprint"] = rubric_fp

        sdir.mkdir(parents=True, exist_ok=True)
        _eval_path(token).write_text(json.dumps(data, indent=2), encoding="utf-8")
        logger.info(
            "[evaluation] wrote %s (score=%d band=%s on attempt %d)",
            _eval_path(token), data["overall"]["score"], data["overall"]["band"], attempt,
        )
        return data

    raise ValueError(
        f"Failed to produce a valid evaluation after 2 attempts. "
        f"Last error: {last_error}"
    )
