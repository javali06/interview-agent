"""Cadence preview + validation for the admin UI.

Wraps the existing `stream_b_new.cadence.load_cadence` and `CadencePlan`
schema — no reimplementation. The only added value here is assembling a
single description blob from the form inputs (role + JD + resume +
cadence requirements) since the loader accepts ONE description file.

Per user decision: resume + JD + role + cadence_requirements are ALL fed
into the cadence-generation LLM call. None of those four go into the slow
LLM's runtime system prompt — only the parsed YAML drives the interview.
(Resume is also passed into the slow LLM separately via SessionConfig,
but that's the existing live_main path and is unchanged here.)
"""
from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Optional

import yaml
from pydantic import ValidationError

from app.cadence_agents import (
    ALL_PHASES,
    CadenceLLM,
    ModifyingAgent,
    PhaseResolverAgent,
    RouterAgent,
    ValidatingAgent,
    build_extra_body,
    detect_structure_verb,
    fmt_dur,
    load_phase_blacklist,
    plan_deterministic,
)
from app.paths import REPO_ROOT
from engine.brain.cadence import question_types as _qt
from engine.brain.cadence.loader import load_cadence
from engine.brain.cadence.schema import CadencePlan
from engine.orchestrator.resume_parser import parse_resume

logger = logging.getLogger(__name__)


# Trigger words that mean the admin's instruction references the candidate's
# resume / the job description. Shared by the top-level "should we even load
# resume/JD text" gate (app/main.py) and the per-phase context gate in
# ModifyingAgent.revise_phase (which attaches context only to a phase call whose
# OWN instructions mention one of these — keeps each scoped LLM call lean).
CONTEXT_TRIGGER_TERMS = (
    "resume", "résumé", "resumé", "cv", "jd", "job description", "job-description",
    "project", "experience", "background", "skill", "candidate", "worked on",
    "tech stack", "portfolio", "profile",
)


# provider → (base_url, env-var-name-that-holds-the-key). Mirrors
# stream_b_new.config._PROVIDER_DEFAULTS so the admin path and the interview
# runtime agree on endpoints.
_PROVIDER_ENDPOINTS = {
    "groq":       ("https://api.groq.com/openai/v1", "GROQ_API_KEY"),
    "openrouter": ("https://openrouter.ai/api/v1",   "OPENROUTER_API_KEY"),
    "openai":     ("https://api.openai.com/v1",      "OPENAI_API_KEY"),
}


def _env_or_dotenv(name: str) -> str:
    """Read `name` from the environment, falling back to a direct .env parse.

    admin.main calls load_dotenv() so os.environ normally has these already;
    the .env fallback keeps this working when cadence_service is exercised
    outside the web app (scripts/tests). Keys are secrets — they live in .env /
    App Settings, never in system_config.yaml."""
    val = (os.environ.get(name) or "").strip()
    if val:
        return val
    env_file = REPO_ROOT / ".env"
    if env_file.is_file():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith(f"{name}="):
                return line.split("=", 1)[1].strip()
    return ""


# Cadence generation + evaluation reuse the slow LLM. The slow LLM's
# provider + model come from config/system_config.yaml (`llm.slow`), the same
# single source of truth the interview runtime reads — so editing that file
# locally "just works" here too. Environment variables (SLOW_PROVIDER /
# SLOW_MODEL) OVERRIDE the config, matching the project's documented precedence
# (system_config.yaml < env override) so Azure App Settings still win on the
# webapp. API keys are always sourced from env / .env (never system_config).
def _resolve_llm() -> tuple[str, str, str]:
    """Returns (api_key, base_url, model). Raises if no key is set.

    Resolution:
      1. Base provider + model from `llm.slow` in system_config.yaml.
      2. SLOW_PROVIDER / SLOW_MODEL env vars override the base (App Settings).
      3. If the resolved provider is known and its key is set → use it.
         A trailing ":nitro" / ":free" variant suffix is stripped (the
         fastest-provider routing trick only matters for the realtime
         interview, not these one-shot batch calls).
      4. Legacy fallback: Groq with openai/gpt-oss-120b if GROQ_API_KEY is
         present, else OpenRouter with deepseek-v3.2 if OPENROUTER_API_KEY is.
    """
    # 1. system_config.yaml base.
    cfg_provider = ""
    cfg_model = ""
    try:
        from engine.brain.config import load_system_config
        slow = (load_system_config().get("llm") or {}).get("slow") or {}
        cfg_provider = (slow.get("provider") or "").strip().lower()
        cfg_model = (slow.get("model") or "").strip()
    except Exception as e:  # missing / malformed config → fall through to legacy
        logger.warning("[cadence_service] could not read system_config: %s", e)

    # 2. env override (precedence: system_config.yaml < env override).
    provider = (os.environ.get("SLOW_PROVIDER") or cfg_provider).strip().lower()
    model = (os.environ.get("SLOW_MODEL") or cfg_model).strip()

    # 3. resolve from the provider map.
    if provider in _PROVIDER_ENDPOINTS and model:
        base_url, key_env = _PROVIDER_ENDPOINTS[provider]
        key = _env_or_dotenv(key_env)
        if key:
            return key, base_url, model.split(":", 1)[0]
        logger.warning(
            "[cadence_service] provider '%s' selected but %s is not set — "
            "falling back", provider, key_env,
        )

    # 4. Legacy fallback (unchanged behaviour).
    groq = _env_or_dotenv("GROQ_API_KEY")
    if groq:
        return groq, "https://api.groq.com/openai/v1", "openai/gpt-oss-120b"
    openrouter = _env_or_dotenv("OPENROUTER_API_KEY")
    if openrouter:
        return openrouter, "https://openrouter.ai/api/v1", "deepseek/deepseek-v3.2"

    raise RuntimeError(
        "No LLM key found. Set GROQ_API_KEY (preferred) or OPENROUTER_API_KEY "
        "in .env to enable cadence generation."
    )


def _resume_snippet(resume_path: Optional[Path]) -> str:
    """Extract resume text via the same `attachments`-based parser the
    orchestrator uses. Truncate to ~6000 chars so we stay well under the
    cadence-generation prompt budget."""
    if resume_path is None or not resume_path.exists():
        return "(no resume provided)"
    try:
        text = parse_resume(resume_path)
    except Exception as e:
        logger.warning("[cadence_service] resume parse failed: %s", e)
        return f"(resume parse failed: {e})"
    return text[:6000]


def assemble_description(
    *,
    role: str,
    jd_text: Optional[str],
    cadence_requirements_text: Optional[str],
    resume_path: Optional[Path],
    work_dir: Path,
) -> Path:
    """Build the combined description file the cadence loader expects.
    Returns the path of the written .md file under `work_dir`."""
    parts: list[str] = []
    parts.append(f"# Role\n{role.strip()}\n")
    if cadence_requirements_text and cadence_requirements_text.strip():
        parts.append("# Cadence requirements\n" + cadence_requirements_text.strip() + "\n")
    if jd_text and jd_text.strip():
        parts.append("# Job description\n" + jd_text.strip() + "\n")
    resume_text = _resume_snippet(resume_path)
    parts.append("# Candidate resume\n" + resume_text + "\n")

    work_dir.mkdir(parents=True, exist_ok=True)
    out = work_dir / "_cadence_input.md"
    out.write_text("\n".join(parts), encoding="utf-8")
    return out


# Signals that a phase is *meant* to be a coding exercise even when the LLM
# forgot to attach a `coding_question_id`. The coding window only opens when a
# phase carries a non-empty coding_question_ids, so a coding-intent phase with
# no question is inert (announces coding, shows nothing) — the exact failure
# we backfill against.
_CODING_SIGNALS = (
    "coding exercise", "coding round", "coding question", "question is on screen",
    "solves one python", "python question", "write code", "live coding",
    "on-screen", "on screen", "code editor",
)


def _is_intended_coding_phase(phase: dict) -> bool:
    if phase.get("coding_question_ids") or phase.get("coding_question_id"):
        return False  # already a real coding phase
    pid = str(phase.get("id") or "").lower()
    if pid == "coding" or pid.startswith("coding") or "coding" in pid:
        return True
    blob = " ".join([
        str(phase.get("intent") or ""),
        " ".join(str(p) for p in (phase.get("generic_prompts") or [])),
    ]).lower()
    return any(s in blob for s in _CODING_SIGNALS)


def _pick_coding_qid(role: str) -> Optional[str]:
    """Pick a library question id appropriate to the role's seniority."""
    try:
        from features.coding.questions.loader import load_library
        lib = list(load_library().values())  # load_library() -> dict[id, Question]
    except Exception as e:
        logger.warning("[cadence_service] coding library unavailable for backfill: %s", e)
        return None
    if not lib:
        return None
    r = (role or "").lower()
    want = "medium" if any(k in r for k in ("senior", "lead", "staff", "principal")) else "easy"
    pool = [q for q in lib if getattr(q, "difficulty", "") == want] or lib
    ids = {q.id for q in pool}
    # Prefer a few broadly-applicable questions when present, else first in pool.
    for pref in ("two_sum", "running_sum", "anagram_check", "max_subarray_sum", "binary_search"):
        if pref in ids:
            return pref
    return pool[0].id


def backfill_coding_questions(data: dict, role: str = "") -> tuple[dict, list[str]]:
    """If a phase is clearly meant to be a coding exercise but has no question
    attached, inject a sensible library question so the coding panel actually
    opens. Mutates + returns `data` plus human-readable notes. Idempotent."""
    notes: list[str] = []
    for ph in (data.get("phases") or []):
        if isinstance(ph, dict) and _is_intended_coding_phase(ph):
            qid = _pick_coding_qid(role)
            if qid:
                ph["coding_question_ids"] = [qid]
                ph.pop("coding_question_id", None)
                notes.append(f"phase '{ph.get('id')}' had no coding question — attached '{qid}'")
    return data, notes


def _insert_idx_before_wrap_up(phases: list) -> int:
    """Return the index at which a new phase should be inserted so that any
    `wrap_up`-style closing phase stays last. Heuristic: scan from the end
    and find the last contiguous block of phases whose id is wrap_up /
    wrap-up / closing / goodbye / conclusion / sign_off; insert before that
    block. If no such phase exists, insert at the end (len).
    """
    if not phases:
        return 0
    closing_ids = {"wrap_up", "wrap-up", "closing", "goodbye", "conclusion",
                   "sign_off", "signoff", "end", "outro"}
    idx = len(phases)
    while idx > 0:
        pid = str(phases[idx - 1].get("id") or "").lower() if isinstance(phases[idx - 1], dict) else ""
        if pid in closing_ids:
            idx -= 1
            continue
        break
    return idx


def append_coding_phase(cadence_yaml: str, role: str = "") -> str:
    """Insert a coding-exercise phase followed by a `code_discussion` review
    phase, BEFORE the `wrap_up` phase (so wrap_up stays last). Returns the
    new YAML. Mirrors demo1-final's coding/example_cadence.yaml structure:
    warm_up → … → coding_round → code_discussion → wrap_up.

    The review phase ('code_discussion') prompts the AI to ask the candidate
    to walk through their solution + edge cases. Shows up as a separate
    segment on the Gantt timeline. Phase ids are uniquified with numeric
    suffixes if collisions exist."""
    data = yaml.safe_load(cadence_yaml)
    if not isinstance(data, dict):
        raise ValueError("cadence YAML must parse to a mapping")
    phases = data.get("phases")
    if not isinstance(phases, list):
        phases = []
        data["phases"] = phases

    existing_ids = {str(p.get("id")) for p in phases if isinstance(p, dict)}

    def _unique(base: str) -> str:
        if base not in existing_ids:
            existing_ids.add(base)
            return base
        n = 2
        while f"{base}_{n}" in existing_ids:
            n += 1
        out = f"{base}_{n}"
        existing_ids.add(out)
        return out

    coding_id = _unique("coding_round")
    review_id = _unique("code_discussion")

    coding_secs = 600   # 10 min — default coding budget
    review_secs = 120   # 2 min — quick walk-through of approach + edges

    # Write FULLY-POPULATED phases so the raw YAML editor shows complete
    # blocks. question_mode stays "generic" — coding-ness is signalled by a
    # non-empty coding_question_ids, not by question_mode.
    coding_phase = {
        "id": coding_id,
        "duration_s": coding_secs,
        "intent": "Live coding exercise — assess hands-on problem solving.",
        "question_mode": "generic",
        "generic_prompts": [
            "Briefly tell the candidate we're going to do a short coding "
            "exercise. The question is on the screen — they can ask if "
            "anything is unclear; otherwise let them begin."
        ],
        "coding_question_ids": [],
    }
    review_phase = dict(CODE_DISCUSSION_PHASE, id=review_id, duration_s=review_secs)

    # Insert both phases right before any wrap_up / closing phases so
    # wrap_up STAYS LAST.
    idx = _insert_idx_before_wrap_up(phases)
    phases[idx:idx] = [coding_phase, review_phase]

    # Bump total_duration_s. If absent or invalid, recompute from phase sum.
    total = data.get("total_duration_s")
    if isinstance(total, (int, float)):
        data["total_duration_s"] = int(total) + coding_secs + review_secs
    else:
        data["total_duration_s"] = sum(
            int(p.get("duration_s") or 0) for p in phases if isinstance(p, dict)
        )

    # Fill coding_question_ids from the library (only the coding_round phase
    # qualifies — code_discussion has no coding_question_ids field, so the
    # backfiller leaves it alone).
    data, _notes = backfill_coding_questions(data, role)
    appended = next(
        (p for p in data["phases"] if isinstance(p, dict) and p.get("id") == coding_id),
        None,
    )
    if appended is not None and not appended.get("coding_question_ids"):
        logger.warning(
            "[cadence_service] append_coding_phase: no library question matched "
            "role=%r — phase '%s' appended with empty coding_question_ids",
            role, coding_id,
        )
    return yaml.safe_dump(data, sort_keys=False)


def set_coding_phase(
    cadence_yaml: str,
    role: str,
    question_ids: list[str],
    time_overrides: dict[str, int] | None = None,
    inline_questions: dict[str, dict] | None = None,
) -> str:
    """Replace the existing coding phase's question_ids + time_overrides, OR
    append a new coding phase if none exists. Returns the new YAML.

    Behaviour:
      - If a phase with non-empty coding_question_ids exists, UPDATE it.
      - Otherwise call append_coding_phase to create one, THEN update its ids.
      - Empty question_ids list is an error — caller must use
        remove_coding_phase to remove a phase.
    """
    if not question_ids:
        raise ValueError("question_ids cannot be empty; use remove_coding_phase")
    data = yaml.safe_load(cadence_yaml)
    if not isinstance(data, dict):
        raise ValueError("cadence YAML must parse to a mapping")
    phases = data.get("phases") or []
    coding = next(
        (p for p in phases if isinstance(p, dict) and (p.get("coding_question_ids") or [])),
        None,
    )
    if coding is None:
        # No existing coding phase — synthesise one via append_coding_phase,
        # then locate it and overwrite ids.
        cadence_yaml = append_coding_phase(cadence_yaml, role)
        data = yaml.safe_load(cadence_yaml)
        phases = data["phases"]
        coding = next(p for p in phases if (p.get("coding_question_ids") or []))
    coding["coding_question_ids"] = list(question_ids)
    # Definitions pulled from an admin-authored pool are COPIED into the
    # cadence, keyed by the same id. A pool is a template: once applied, editing
    # or deleting it must not be able to change an interview that may already
    # have been approved and sent. Ids not present here still resolve from the
    # built-in library, so a library-only phase is byte-identical to before.
    inline_clean = {
        qid: defn for qid, defn in (inline_questions or {}).items()
        if qid in set(question_ids)
    }
    if inline_clean:
        coding["coding_questions_inline"] = inline_clean
    else:
        coding.pop("coding_questions_inline", None)
    overrides_clean: dict[str, int] = {}
    if time_overrides:
        # Drop entries whose key isn't in question_ids (schema rejects them).
        overrides_clean = {
            q: int(s) for q, s in time_overrides.items() if q in question_ids
        }
        coding["coding_question_time_overrides"] = overrides_clean
    else:
        coding.pop("coding_question_time_overrides", None)

    # Recompute the coding phase budget = Σ per-question time (override if the
    # operator set one, else the library default). The Gantt + the director's
    # phase deadline both read duration_s, so without this the phase stays at
    # its 10-min append-default no matter how many questions / minutes are set.
    def _q_secs(qid: str) -> int:
        if qid in overrides_clean:
            return overrides_clean[qid]
        try:
            from features.coding.questions.loader import resolve_question
            return int(resolve_question(qid, inline_clean).time_budget_s)
        except Exception:
            return 600
    coding_secs = sum(_q_secs(q) for q in question_ids)
    if coding_secs > 0:
        coding["duration_s"] = coding_secs

    # Keep total_duration_s honest (the schema requires Σ phase durations ==
    # total_duration_s, and the Gantt's total falls back to this field).
    data["total_duration_s"] = sum(
        int(p.get("duration_s") or 0) for p in phases if isinstance(p, dict)
    )
    return yaml.safe_dump(data, sort_keys=False)


# The one definition of the code-review phase. Lives here because this is where
# it has always been built (`append_coding_phase` pairs it with the coding round);
# the chat editor reaches it through the phase CATALOG rather than building its
# own, so "add a code discussion" and the picker produce the same phase.
CODE_DISCUSSION_PHASE = {
    "id": "code_discussion",
    "duration_s": 120,          # 2 min — quick walk-through of approach + edges
    "intent": "Review the candidate's coding solution — approach, "
              "complexity, edge cases.",
    "question_mode": "generic",
    "generic_prompts": [
        "Now that they've submitted, ask the candidate to walk you "
        "through their approach, the time/space complexity, and any "
        "edge cases they considered or missed.",
    ],
}

_CODE_DISCUSSION_IDS = ("code_discussion", "coding_review", "code_review")


def _is_code_discussion(phase: dict) -> bool:
    """A discussion/review phase paired with the coding round. Identified by
    id (code_discussion / coding_review / code_review) so that
    remove_coding_phase yanks both phases together."""
    pid = str(phase.get("id") or "").lower()
    return any(pid == d or pid.startswith(d + "_") for d in _CODE_DISCUSSION_IDS)


def remove_coding_phase(cadence_yaml: str) -> str:
    """Drop ALL coding phases AND their paired code_discussion/review phases
    from the cadence. Bumps total_duration_s down by the sum of the
    durations removed. No-op if no coding phase is present."""
    data = yaml.safe_load(cadence_yaml)
    if not isinstance(data, dict):
        raise ValueError("cadence YAML must parse to a mapping")
    phases = data.get("phases") or []

    def _is_coding(p: object) -> bool:
        return isinstance(p, dict) and bool(p.get("coding_question_ids") or [])

    def _drop(p: object) -> bool:
        return _is_coding(p) or (isinstance(p, dict) and _is_code_discussion(p))

    keep = [p for p in phases if not _drop(p)]
    removed_secs = sum(
        int(p.get("duration_s") or 0)
        for p in phases
        if _drop(p) and isinstance(p, dict)
    )
    data["phases"] = keep
    total = data.get("total_duration_s")
    if isinstance(total, (int, float)) and removed_secs > 0:
        data["total_duration_s"] = max(1, int(total) - removed_secs)
    return yaml.safe_dump(data, sort_keys=False)


def apply_recording_flag(cadence_yaml: str, recording_enabled: bool) -> str:
    """Stamp the interview's immutable recording setting onto the cadence YAML —
    deterministically, never LLM-authored — so the candidate lobby can read it
    like everything else it consumes from cadence.yaml. Defensive: on any parse
    error or a blank/pending yaml string, returns the input untouched so this
    can never break cadence generation."""
    try:
        data = yaml.safe_load(cadence_yaml)
        if not isinstance(data, dict):
            return cadence_yaml
        data["recording_enabled"] = bool(recording_enabled)
        return yaml.safe_dump(data, sort_keys=False)
    except Exception as e:
        logger.warning("[cadence_service] apply_recording_flag skipped: %s", e)
        return cadence_yaml


def apply_modality_flag(cadence_yaml: str, modality: str) -> str:
    """Stamp the interview's timing model onto the cadence YAML from the
    admin-set modality — deterministically, never LLM-authored, mirroring
    apply_recording_flag. A "text" interview is question-driven and untimed
    (``timed: false``), so the CadenceTracker advances phases on question-pool
    exhaustion rather than the wall clock; anything else stays ``timed: true``
    (today's voice behavior). Defensive: a blank/pending or unparseable yaml is
    returned untouched so this can never break cadence generation.

    NOTE: an untimed plan only advances if its phases are pool-backed
    (question_mode="specific"); ensuring that is the job of text cadence
    generation / the editor, not this stamp."""
    try:
        data = yaml.safe_load(cadence_yaml)
        if not isinstance(data, dict):
            return cadence_yaml
        data["timed"] = (modality != "text")
        return yaml.safe_dump(data, sort_keys=False)
    except Exception as e:
        logger.warning("[cadence_service] apply_modality_flag skipped: %s", e)
        return cadence_yaml


# ── Visual Scenario Analysis phase ──────────────────────────────────────────
# See engine/brain/cadence/schema.py (ScenarioMedia/ScenarioItem/
# PhaseDef.scenario_items) for the data model. Voice/video only — never valid
# in a text (untimed) cadence; enforced by CadencePlan._check_video_only_phases.


def _insert_idx_before_coding_or_wrap_up(phases: list) -> int:
    """Where a Visual Scenario Analysis phase belongs by default: between
    warm-up and wrap-up, and BEFORE the coding round when one exists (so the
    interview's two hands-on, screen-driven rounds don't interleave — the
    candidate finishes looking at scenarios before they start writing code).
    Falls back to `_insert_idx_before_wrap_up` when there's no coding phase."""
    for i, p in enumerate(phases):
        if isinstance(p, dict) and (p.get("coding_question_ids") or p.get("coding_question_id")):
            return i
    return _insert_idx_before_wrap_up(phases)


def append_scenario_analysis_phase(
    cadence_yaml: str,
    items: list[dict],
    name: str = "Visual Scenario Analysis",
    duration_s: Optional[int] = None,
) -> str:
    """Insert a Visual Scenario Analysis phase — an ordered list of media +
    question + coverage-tag items (see `schema.ScenarioItem`) — between
    warm_up and wrap_up, before any coding round. Returns the new YAML.

    `items` must already be dicts shaped like `ScenarioItem` with their media
    already uploaded (`POST /api/cadence/{token}/phase-asset?kind=image|video|
    audio`) — this function never fabricates a media reference, it only
    places what the caller supplies. `question_mode` stays "generic": the
    phase's own `scenario_items` is what marks its kind (mirrors
    `append_coding_phase`'s `coding_question_ids`), so the slow LLM only needs
    banter to introduce/wrap the phase — the schema auto-fills that banter
    when the caller leaves `generic_prompts` unset.

    Mirrors `append_coding_phase`'s id-uniquifying + total-duration bookkeeping.
    Duration defaults to 3 minutes per item when not given (a rough per-item
    budget for showing the media + one spoken answer + follow-ups).

    Returns the new YAML VALIDATED through the schema (`_validated_dump`) —
    unlike `append_coding_phase`/`remove_coding_phase`, which dump unvalidated
    and rely on the caller's own eventual full-plan validation. Scenario items
    carry an item's whole shape (media/question/tags/max_followups) in one
    call, so validating here is what catches a malformed item immediately
    rather than at whatever later point re-validates the plan — and it's the
    one path that enforces the voice/video-only rule
    (`CadencePlan._check_video_only_phases`) for a brand-new phase."""
    data = yaml.safe_load(cadence_yaml)
    if not isinstance(data, dict):
        raise ValueError("cadence YAML must parse to a mapping")
    phases = data.get("phases")
    if not isinstance(phases, list):
        phases = []
        data["phases"] = phases
    if not items:
        raise ValueError("a Visual Scenario Analysis phase needs at least one item")

    # A cadence holds AT MOST ONE scenario_analysis phase — it's a single
    # container for many items, not one phase per item batch (mirrors how a
    # cadence has at most one coding phase). Reject here, defense in depth —
    # the admin UI's own "Add phases" menu already routes to the edit path
    # when one exists (CadenceReview.tsx), so this should only ever fire on
    # a stale bundle, a direct API call, or a race between two admin tabs.
    if any(isinstance(p, dict) and p.get("scenario_items") for p in phases):
        raise ValueError(
            "A Visual Scenario Analysis phase already exists. Open it and "
            "add questions there."
        )

    existing_ids = {str(p.get("id")) for p in phases if isinstance(p, dict)}

    def _unique(base: str) -> str:
        if base not in existing_ids:
            existing_ids.add(base)
            return base
        n = 2
        while f"{base}_{n}" in existing_ids:
            n += 1
        out = f"{base}_{n}"
        existing_ids.add(out)
        return out

    phase_id = _unique("scenario_analysis")
    secs = int(duration_s) if duration_s and duration_s > 0 else 180 * len(items)

    phase = {
        "id": phase_id,
        "duration_s": secs,
        "intent": f"{name} — assess the candidate's judgment on a visual scenario.",
        "question_mode": "generic",
        "scenario_items": items,
    }
    idx = _insert_idx_before_coding_or_wrap_up(phases)
    phases[idx:idx] = [phase]

    total = data.get("total_duration_s")
    if isinstance(total, (int, float)):
        data["total_duration_s"] = int(total) + secs
    else:
        data["total_duration_s"] = sum(
            int(p.get("duration_s") or 0) for p in phases if isinstance(p, dict)
        )
    return _validated_dump(data)


def update_scenario_analysis_phase(
    cadence_yaml: str,
    phase_id: str,
    *,
    items: list[dict],
    duration_s: Optional[int] = None,
    intent: str = "",
    generic_prompts: Optional[list[str]] = None,
) -> str:
    """Replace an EXISTING Visual Scenario Analysis phase's items (add / edit /
    remove / reorder — the caller sends the full ordered list either way) in
    place, keeping its position AND its `id` — mirrors `update_written_phase`
    for the same reason (the eval plan / events.jsonl reference a phase by
    id). `duration_s`/`intent`/`generic_prompts` are optional partial updates;
    the phase's NAME as shown in the admin UI is not a stored field (it lives
    only in `intent`/the id chosen at creation), so there is nothing else to
    rename here. `total_duration_s` is recomputed from all phases afterward,
    same as `set_coding_phase`. Returns the new YAML, validated."""
    data, phases = _load_phases(cadence_yaml)
    idx = next(
        (i for i, p in enumerate(phases)
         if isinstance(p, dict) and str(p.get("id")) == phase_id),
        None,
    )
    if idx is None:
        raise ValueError(f"no phase '{phase_id}' in this cadence")
    current = phases[idx]
    if not current.get("scenario_items"):
        raise ValueError(
            f"phase '{phase_id}' is not a Visual Scenario Analysis phase"
        )
    if not items:
        raise ValueError("a Visual Scenario Analysis phase needs at least one item")

    current["scenario_items"] = items
    if duration_s is not None and duration_s > 0:
        current["duration_s"] = int(duration_s)
    if intent.strip():
        current["intent"] = intent.strip()
    if generic_prompts is not None:
        current["generic_prompts"] = generic_prompts

    data["total_duration_s"] = sum(
        int(p.get("duration_s") or 0) for p in phases if isinstance(p, dict)
    )
    return _validated_dump(data)


def remove_scenario_analysis_phase(cadence_yaml: str, phase_id: str) -> str:
    """Remove ONE Visual Scenario Analysis phase by id, keeping
    total_duration_s bookkeeping consistent — mirrors `remove_coding_phase`'s
    arithmetic (subtract the removed phase's own duration; recompute from the
    phase sum if the stored total looks stale). Media cleanup is explicitly
    OUT of scope here — see the module note above `phase_asset_upload` in
    app/main.py: image_description has the same pre-existing gap (an
    orphaned blob), and this does not add a new one."""
    data, phases = _load_phases(cadence_yaml)
    target = next(
        (p for p in phases if isinstance(p, dict) and str(p.get("id")) == phase_id),
        None,
    )
    if target is None:
        raise ValueError(f"no phase '{phase_id}' in this cadence")
    if not target.get("scenario_items"):
        raise ValueError(
            f"phase '{phase_id}' is not a Visual Scenario Analysis phase"
        )
    removed_secs = int(target.get("duration_s") or 0)
    remaining = [p for p in phases if p is not target]
    data["phases"] = remaining
    total = data.get("total_duration_s")
    if isinstance(total, (int, float)) and removed_secs > 0:
        data["total_duration_s"] = max(1, int(total) - removed_secs)
    else:
        data["total_duration_s"] = sum(
            int(p.get("duration_s") or 0) for p in remaining if isinstance(p, dict)
        )
    return _validated_dump(data)


def _phase_slug(name: str, fallback: str) -> str:
    """A schema-valid snake_case phase id from an admin-typed name."""
    import re
    s = re.sub(r"[^a-z0-9_]+", "_", (name or "").strip().lower())
    s = re.sub(r"_+", "_", s).strip("_")
    if not s or not s[0].isalpha():
        s = fallback
    return s[:40]


def _written_question_dict(
    *,
    spec,
    question: dict,
    question_id: str,
    languages: dict,
    label: str,
) -> tuple[dict, dict]:
    """One authored question → (pool_item, per_question_written_config).

    Validates against the type's QUESTION-scoped fields (its material AND its
    language pair) plus the limits, and synthesizes the instruction from that
    question's own languages when the type allows — or requires — a blank prompt.
    `languages` are the phase-level pair, used only as a FALLBACK for a question
    that doesn't carry its own (which is how a cadence authored before the pair
    moved per-question keeps working). `label` names the question in error
    messages ("Question 2") so an admin editing a list knows which card is
    wrong."""
    cfg: dict = {}
    for field in _qt.question_fields(spec.id):
        raw = question.get(field.name)
        if field.kind == "string_list":
            items = raw if isinstance(raw, list) else ([] if raw is None else [raw])
            cleaned = [str(v).strip() for v in items if str(v).strip()]
            if not cleaned:
                if field.required:
                    raise ValueError(f"{label}: {spec.label} needs {field.label.lower()}")
                continue
            cfg[field.name] = cleaned
            continue
        value = str(raw).strip() if raw is not None else ""
        if not value:
            # Phase-level default for a question that didn't set its own.
            value = str(languages.get(field.name) or "").strip()
        if not value:
            if field.required:
                raise ValueError(f"{label}: {spec.label} needs {field.label.lower()}")
            continue
        cfg[field.name] = value

    # The instruction is built from THIS question's pair, so mixing pairs across
    # a phase produces the right sentence on each one.
    synthesized = _qt.default_prompt(
        spec.id,
        cfg.get("source_language", "") or languages.get("source_language", ""),
        cfg.get("target_language", "") or languages.get("target_language", ""),
    )
    prompt = str(question.get("prompt") or "").strip()
    if spec.prompt_hidden:
        # The admin never authors this type's instruction — always synthesize, so
        # an edit can't leave a stale sentence naming the previous language pair.
        prompt = synthesized
    if not prompt:
        if spec.prompt_required:
            raise ValueError(f"{label}: {spec.label} needs: {spec.prompt_label.lower()}")
        prompt = synthesized
    if not prompt:  # a type with an optional/hidden prompt must have a default
        raise ValueError(f"{label}: {spec.label} needs: {spec.prompt_label.lower()}")

    char_limit = question.get("char_limit")
    word_limit = question.get("word_limit")
    if (char_limit is None) == (word_limit is None):
        raise ValueError(f"{label}: pass exactly one of char_limit / word_limit")
    if char_limit is not None:
        char_limit = int(char_limit)
        if char_limit <= 0:
            raise ValueError(f"{label}: char_limit must be > 0")
        cfg["char_limit"] = char_limit
    else:
        word_limit = int(word_limit)
        if word_limit <= 0:
            raise ValueError(f"{label}: word_limit must be > 0")
        cfg["word_limit"] = word_limit

    time_limit_s = question.get("time_limit_s")
    if time_limit_s is not None:
        time_limit_s = int(time_limit_s)
        if time_limit_s <= 0:
            raise ValueError(
                f"{label}: time_limit_s must be > 0 (or omit it for an untimed response)"
            )
        cfg["time_limit_s"] = time_limit_s

    pool_item = {
        "id": question_id,
        "text": prompt,
        "topic": spec.id,
        # one-shot: no verifier probe, so no coverage tags — scored by the
        # phase's rubric plugin post-interview.
        "coverage_tags": [],
        "written_response": cfg,
    }
    return pool_item, cfg


def build_written_phase(
    *,
    question_type: str,
    questions: list[dict],
    phase_id: str,
    existing_question_ids: set[str] | None = None,
    avoid_new_ids: set[str] | None = None,
    phase_defaults: dict | None = None,
    fallback_languages: dict | None = None,
) -> dict:
    """The phase dict for a written-response phase with N questions of ONE type.

    Phase level carries only the type; the material AND the language pair are
    per question (question_types' FieldSpec.scope), so one phase can mix pairs.
    `fallback_languages` is the pair an OLDER phase carried at phase level — used
    only for questions that don't supply their own, which is what keeps a cadence
    authored before the move working. Every question
    keeps its own id when the caller supplies one, so editing a phase does not
    renumber ids the events.jsonl / eval segments already reference.

    `avoid_new_ids` are ids a NEW question must not take (the phase's ids before
    an edit): a deleted question's id is never recycled, so an id in an existing
    events.jsonl / eval segment can't come to mean a different question.

    `phase_defaults` is for the LEGACY single-question shape only: limits written
    at phase level with no per-question block, byte-identical to what
    append_essay_phase produced before."""
    spec = _qt.spec_for(question_type)   # raises on an unknown type
    if not questions:
        raise ValueError(f"{spec.label} phase needs at least one question")

    wr: dict = {"question_type": question_type}
    languages: dict = {k: v for k, v in (fallback_languages or {}).items() if v}
    for field in _qt.phase_fields(question_type):
        # Phase-scoped values (the language pair) are authored ONCE; callers merge
        # them into every question dict, so the first non-empty one is it.
        value = str((phase_defaults or {}).get(field.name) or "").strip()
        if not value:
            for q in questions:
                candidate = str(q.get(field.name) or "").strip()
                if candidate:
                    value = candidate
                    break
        if not value:
            if field.required:
                raise ValueError(f"{spec.label} needs {field.label.lower()}")
            continue
        wr[field.name] = value
        languages[field.name] = value

    # Ids in TWO passes: echoed ids are reserved first so they always survive an
    # edit (they're referenced by events.jsonl / eval segments), then the new
    # questions take the first free `<phase>_qN`.
    used_ids = set(existing_question_ids or set())
    ids: list[str | None] = []
    for question in questions:
        echoed = str(question.get("id") or "").strip()
        if echoed and echoed not in used_ids:
            used_ids.add(echoed)
            ids.append(echoed)
        else:
            ids.append(None)   # dropped duplicate / brand-new question
    taken = used_ids | set(avoid_new_ids or set())
    counter = 1
    for i, assigned in enumerate(ids):
        if assigned is not None:
            continue
        while f"{phase_id}_q{counter}" in taken:
            counter += 1
        ids[i] = f"{phase_id}_q{counter}"
        used_ids.add(ids[i])
        taken.add(ids[i])

    pool: list[dict] = []
    for i, question in enumerate(questions, start=1):
        qid = ids[i - 1]
        item, _ = _written_question_dict(
            spec=spec, question=question, question_id=qid,
            languages=languages, label=f"Question {i}",
        )
        pool.append(item)

    if phase_defaults:
        # Legacy shape: limits at phase level, questions carry no own block.
        for key in ("char_limit", "word_limit", "time_limit_s"):
            if phase_defaults.get(key) is not None:
                wr[key] = int(phase_defaults[key])
        for item in pool:
            item.pop("written_response", None)

    return {
        "id": phase_id,
        "duration_s": 1,   # dummy — an untimed text interview ignores it
        "intent": spec.intent,
        # The mode NAMES the task. Mechanically identical to "specific" (both
        # pool-backed — see PhaseDef.uses_question_pool), but stating the type
        # here is what lets every downstream reader — the verifier's phase
        # descriptor, the eval sectioner, the admin UI — know it is grading a
        # translation rather than a spoken answer, without re-deriving it from
        # a side-channel.
        "question_mode": question_type,
        "question_pool": pool,
        "written_response": wr,
    }


def _merge_target(phases: list, phase_id: str, question_type: str) -> dict | None:
    """The existing phase a duplicate add should fold INTO, or None to create one.

    Adding the same phase again means "more questions of that kind" — the admin
    picked the same type, so the modal seeded the same name, so it derives the
    same id. The id is the phase's identity (the evaluation plan and
    events.jsonl key off it), so folding in beats creating a near-identical
    `<id>_2` the admin then has to reconcile. A same-id phase of a DIFFERENT
    type — or one that isn't a written-response phase at all — is NOT a merge
    target: a phase holds N questions of ONE type, so the caller uniquifies the
    id exactly as before."""
    for p in phases:
        if not isinstance(p, dict) or str(p.get("id")) != phase_id:
            continue
        wr = p.get("written_response")
        if not isinstance(wr, dict):
            return None
        current = str(wr.get("question_type") or _qt.DEFAULT_QUESTION_TYPE)
        return p if current == question_type else None
    return None


def _append_questions_to_phase(
    phase: dict, *, spec, questions: list[dict], langs: dict, taken_ids: set[str],
) -> int:
    """Append authored questions to an EXISTING written-response phase's pool,
    leaving every question already there untouched (ids included — they're
    referenced by events.jsonl and the eval segments). Returns how many landed."""
    wr = phase.get("written_response") or {}
    phase_id = str(phase.get("id"))

    # Fallback values for a question that doesn't carry its own: whatever the
    # phase still holds at phase level (an older cadence), else the caller's.
    # No conflict check any more — the language pair is per QUESTION now, so
    # adding an en→fr question to a phase whose others are en→es is legitimate.
    fallbacks: dict = {}
    for field in _qt.spec_for(spec.id).fields:
        value = str(wr.get(field.name) or langs.get(field.name) or "").strip()
        if value:
            fallbacks[field.name] = value

    # Bring a phase authored while every written phase said "specific" onto the
    # named mode — the block already says which type it is, so this only makes
    # the two agree (the schema now requires that).
    phase["question_mode"] = spec.id

    pool = phase.get("question_pool")
    if not isinstance(pool, list):
        pool = []
        phase["question_pool"] = pool

    base = len(pool)
    counter = 1
    for i, question in enumerate(questions, start=1):
        while f"{phase_id}_q{counter}" in taken_ids:
            counter += 1
        qid = f"{phase_id}_q{counter}"
        taken_ids.add(qid)
        item, _ = _written_question_dict(
            spec=spec, question=question, question_id=qid,
            languages=fallbacks, label=f"Question {base + i}",
        )
        pool.append(item)
    return len(questions)


def _load_phases(cadence_yaml: str) -> tuple[dict, list]:
    data = yaml.safe_load(cadence_yaml)
    if not isinstance(data, dict):
        raise ValueError("cadence YAML must parse to a mapping")
    phases = data.get("phases")
    if not isinstance(phases, list):
        phases = []
        data["phases"] = phases
    return data, phases


def _validated_dump(data: dict) -> str:
    """Serialize + validate the whole plan (raises on anything the schema
    rejects, so a bad edit can never reach the interview)."""
    revised = yaml.safe_dump(data, sort_keys=False)
    from engine.brain.cadence.schema import CadencePlan
    CadencePlan.model_validate(yaml.safe_load(revised))
    return revised


def append_written_phase(
    cadence_yaml: str,
    *,
    question_type: str = _qt.DEFAULT_QUESTION_TYPE,
    questions: list[dict] | None = None,
    name: str = "",
    source_language: str = "",
    target_language: str = "",
    # LEGACY single-question kwargs (a cached SPA bundle still posts these):
    prompt: str = "",
    char_limit: int | None = None,
    word_limit: int | None = None,
    time_limit_s: int | None = None,
    config: dict | None = None,
    outcome: dict | None = None,
) -> str:
    """Insert a WRITTEN-RESPONSE phase BEFORE wrap_up — the TEXT counterpart to
    append_coding_phase. `questions` is the list of written questions in the
    phase, each with its own prompt, material, character limit and countdown; the
    question type + language pair are phase-level. The candidate answers them one
    at a time (each submission closes that question, no verifier follow-up) and
    the phase ends when the pool is exhausted. Returns the new YAML, validated
    through the schema. Intended for untimed (text) cadences.

    The flat `prompt`/`char_limit`/`word_limit`/`time_limit_s`/`config` kwargs are
    the pre-multi-question call shape, accepted so an older caller (or a cached
    SPA bundle) still works; they build a single question. `word_limit` keeps the
    LEGACY phase-level shape so an essay phase is written exactly as before.

    `outcome` is an optional out-param dict (the `report` idiom used elsewhere in
    the codebase) describing what happened: `{"created": phase_id}` for a new
    phase, or `{"merged_into": phase_id, "added": n}` when the questions were
    folded into an existing phase of the same type — see _merge_target."""
    spec = _qt.spec_for(question_type)
    cfg_in = dict(config or {})
    langs = {
        "source_language": (source_language or cfg_in.get("source_language") or "").strip(),
        "target_language": (target_language or cfg_in.get("target_language") or "").strip(),
    }

    legacy_defaults: dict | None = None
    if questions is None:
        # Flat (single-question) call → one question from the legacy kwargs. Note
        # `questions is None`, not falsy: an explicit empty list is an authoring
        # error ("a phase needs at least one question"), not a legacy call.
        question = {k: v for k, v in cfg_in.items()}
        question.update({"prompt": prompt, "char_limit": char_limit, "word_limit": word_limit,
                         "time_limit_s": time_limit_s})
        questions = [question]
        if word_limit is not None:
            legacy_defaults = {"word_limit": word_limit, "time_limit_s": time_limit_s,
                               **{k: v for k, v in langs.items() if v}}

    data, phases = _load_phases(cadence_yaml)
    phase_id = _phase_slug(name, spec.slug)

    # Same type, same name → the admin is adding MORE questions of that kind, so
    # they belong in the phase that already exists rather than in a second,
    # near-identical one.
    target = _merge_target(phases, phase_id, question_type)
    if target is not None:
        added = _append_questions_to_phase(
            target, spec=spec, questions=list(questions),
            langs=langs, taken_ids=_all_question_ids(phases),
        )
        if outcome is not None:
            outcome.update({"merged_into": phase_id, "added": added})
        return _validated_dump(data)

    existing_ids = {str(p.get("id")) for p in phases if isinstance(p, dict)}
    if phase_id in existing_ids:
        n = 2
        while f"{phase_id}_{n}" in existing_ids:
            n += 1
        phase_id = f"{phase_id}_{n}"

    written_phase = build_written_phase(
        question_type=question_type,
        questions=list(questions),
        fallback_languages=langs,
        phase_id=phase_id,
        existing_question_ids=_all_question_ids(phases),
        phase_defaults=legacy_defaults,
    )

    idx = _insert_idx_before_wrap_up(phases)
    phases[idx:idx] = [written_phase]

    total = data.get("total_duration_s")
    if isinstance(total, (int, float)):
        data["total_duration_s"] = int(total) + 1
    if outcome is not None:
        outcome.update({"created": phase_id, "added": len(questions)})
    return _validated_dump(data)


def update_written_phase(
    cadence_yaml: str,
    phase_id: str,
    *,
    question_type: str = "",
    questions: list[dict],
    source_language: str = "",
    target_language: str = "",
) -> str:
    """Replace an EXISTING written-response phase's questions (add / edit /
    delete) in place, keeping its position AND its `id` — the id is what the
    evaluation plan, events.jsonl and eval segments reference, so a rename must
    not orphan them. Question ids the caller echoes back are preserved for the
    same reason; new questions get fresh ones. Returns the new YAML, validated."""
    data, phases = _load_phases(cadence_yaml)
    idx = next(
        (i for i, p in enumerate(phases)
         if isinstance(p, dict) and str(p.get("id")) == phase_id),
        None,
    )
    if idx is None:
        raise ValueError(f"no phase '{phase_id}' in this cadence")
    current = phases[idx]
    current_wr = current.get("written_response")
    if not isinstance(current_wr, dict):
        raise ValueError(f"phase '{phase_id}' is not a written-response phase")

    qtype = (question_type or current_wr.get("question_type")
             or _qt.DEFAULT_QUESTION_TYPE)
    langs = {
        "source_language": (source_language or current_wr.get("source_language") or "").strip(),
        "target_language": (target_language or current_wr.get("target_language") or "").strip(),
    }
    # Ids in use elsewhere in the plan — this phase's own are free to be reused.
    other_ids = _all_question_ids([p for i, p in enumerate(phases) if i != idx])

    phases[idx] = build_written_phase(
        question_type=qtype,
        questions=list(questions),
        fallback_languages=langs,
        phase_id=phase_id,
        existing_question_ids=other_ids,
        avoid_new_ids=_all_question_ids([current]),
    )
    return _validated_dump(data)


def _all_question_ids(phases: list) -> set[str]:
    """Every question id already used in the plan (ids must be unique per phase;
    we keep them unique plan-wide so an eval/event reference is unambiguous)."""
    out: set[str] = set()
    for p in phases:
        if not isinstance(p, dict):
            continue
        for q in p.get("question_pool") or []:
            if isinstance(q, dict) and q.get("id"):
                out.add(str(q["id"]))
    return out


def append_essay_phase(
    cadence_yaml: str,
    prompt: str,
    word_limit: int,
    time_limit_s: int | None = None,
    name: str = "",
) -> str:
    """LEGACY shim for the pre-Add-Phase essay call (word-limited comprehensive
    written response). Kept so an older caller — including a cached SPA bundle
    hitting /add_essay_phase — behaves exactly as before."""
    return append_written_phase(
        cadence_yaml,
        question_type=_qt.DEFAULT_QUESTION_TYPE,
        prompt=prompt,
        word_limit=word_limit,
        time_limit_s=time_limit_s,
        name=name,
    )


def backfill_coding_in_yaml(cadence_yaml: str, role: str = "") -> tuple[str, list[str]]:
    """YAML-string wrapper around backfill_coding_questions. Returns the
    (possibly unchanged) YAML + notes. On any parse error, returns the input
    untouched so this can be called defensively in the approve path."""
    try:
        data = yaml.safe_load(cadence_yaml)
        if not isinstance(data, dict):
            return cadence_yaml, []
        data, notes = backfill_coding_questions(data, role)
        if not notes:
            return cadence_yaml, []
        return yaml.safe_dump(data, sort_keys=False), notes
    except Exception as e:
        logger.warning("[cadence_service] backfill_coding_in_yaml skipped: %s", e)
        return cadence_yaml, []


async def generate_cadence_yaml(
    *,
    role: str,
    candidate_name: str,
    jd_text: Optional[str],
    cadence_requirements_text: Optional[str],
    resume_path: Optional[Path],
    work_dir: Path,
    token: Optional[str] = None,
) -> str:
    """Run the slow LLM to convert (role + JD + resume + cadence_requirements)
    into a validated cadence YAML string. Raises RuntimeError on failure.

    `token` (the schedule token) is optional — passed through so this call's
    cost/Langfuse trace is attributed to the right interview's "cost for
    setting up interview" table."""
    desc_path = assemble_description(
        role=role,
        jd_text=jd_text,
        cadence_requirements_text=cadence_requirements_text,
        resume_path=resume_path,
        work_dir=work_dir,
    )
    api_key, base_url, model = _resolve_llm()
    plan = await load_cadence(
        cadence_path=None,
        cadence_description_path=desc_path,
        role=role,
        candidate_name=candidate_name,
        api_key=api_key,
        base_url=base_url,
        model=model,
        token=token,
    )
    # Safety net: the LLM frequently creates a "coding" phase + intro prompt but
    # forgets coding_question_id → the coding window never opens. Attach one.
    data = plan.model_dump(mode="json")
    data, notes = backfill_coding_questions(data, role)
    if notes:
        logger.info("[cadence_service] coding backfill (generate): %s", "; ".join(notes))
        plan = CadencePlan.model_validate(data)
    return yaml.safe_dump(plan.model_dump(mode="json"), sort_keys=False)


def humanize_cadence_error(raw: Optional[str]) -> str:
    """Turn a raw pydantic / CadencePlan validation error into a short, friendly
    message that's safe to show in the UI (no schema/type/URL noise).

    Raw pydantic v2 errors look like:
        "1 validation error for CadencePlan\\n  Value error, total_duration_s=240
         does not match the sum of phase durations (510) [type=value_error,
         input_value={...}, input_type=dict]\\n    For further information visit
         https://errors.pydantic.dev/2.13/v/value_error"
    — which is unreadable in a toast. We map the common cases to clear guidance
    and, for anything else, strip the pydantic noise down to the human part.
    """
    if not raw:
        return "The interview plan is invalid. Please review it and try again."
    text = str(raw)

    # ── common, specific cases → actionable guidance ────────────────────────
    if "does not match the sum of phase durations" in text:
        return ("The plan's total time doesn't match the sum of its phase "
                "durations. Adjust the phase durations (or the total) so they "
                "add up, then try again.")
    if "phase ids must be unique" in text:
        return "Two phases share the same id — rename one so every phase id is unique."
    if "question_mode='specific'" in text and "question_pool is empty" in text:
        return ("A phase is set to 'specific' but has no questions — add "
                "questions to it or switch it to 'generic'.")
    if "question_mode='generic'" in text and "generic_prompts is empty" in text:
        return ("A 'generic' phase has no prompts — add at least one prompt or "
                "switch it to 'specific'.")
    if "YAML parse error" in text or "top-level YAML must be" in text:
        return ("The cadence couldn't be parsed — check the YAML for indentation "
                "or formatting mistakes.")

    # ── generic cleanup: strip pydantic's [type=...]/URL/header noise ───────
    cleaned = re.split(r"\s*\[type=", text)[0]                       # drop [type=... input_value=...]
    cleaned = re.sub(r"For further information visit https?://\S+", "", cleaned)
    cleaned = re.sub(r"^\s*\d+ validation errors? for \w+", "", cleaned)  # drop the header line
    cleaned = cleaned.replace("Value error,", " ").strip()
    cleaned = re.sub(r"\s+", " ", cleaned).strip(" :\n\t")
    if not cleaned:
        return "The interview plan is invalid. Please review it and try again."
    if len(cleaned) > 220:
        cleaned = cleaned[:220].rstrip() + "…"
    return f"Couldn't apply the change — {cleaned}"


def validate_cadence_yaml(text: str) -> tuple[bool, Optional[str]]:
    """Parse + pydantic-validate. Returns (ok, error_message). The error is
    HUMANIZED (safe to show in the UI); the raw detail is logged, not surfaced."""
    try:
        data = yaml.safe_load(text)
    except yaml.YAMLError as e:
        logger.warning("[cadence_service] YAML parse error: %s", e)
        return False, "The cadence couldn't be parsed — check the YAML for indentation or formatting mistakes."
    if not isinstance(data, dict):
        return False, "The cadence must be a mapping with `total_duration_s` and `phases`."
    try:
        CadencePlan.model_validate(data)
    except ValidationError as e:
        logger.warning("[cadence_service] cadence validation failed: %s", str(e).replace("\n", " "))
        return False, humanize_cadence_error(str(e))
    return True, None


# ══════════════════════════════════════════════════════════════════════════
# Conversational multi-agent revise: ROUTER → MODIFYING → VALIDATING
# ══════════════════════════════════════════════════════════════════════════
#
# The three agents live in `app/cadence_agents/` (one file each, prompts in
# config/prompts.yaml). This module owns only the ORCHESTRATION: build the
# shared LLM handle, run router → modifying → validating, and shape the admin
# response.
#
# There is NO full-YAML fallback. The raw cadence is never sent to an LLM: if
# the cadence can't be read or the router can't classify the ask, the turn is
# REFUSED with a message saying why (`ok: False`) — because the fallback's only
# trick was to guess at the whole plan from the same input that just failed,
# which risks rewriting phases the admin never mentioned. Failures below that
# line are per-clause and survivable: a failed unit keeps its original content,
# its siblings still apply, and the VALIDATING agent repairs, retries, or
# reports it.
#
#   1. RouterAgent     — splits the request into independent clauses tagged just
#                        `phase` or `ambiguous`, and holds the CONVERSATION: an
#                        ambiguous clause becomes a QUESTION grounded in the real
#                        phase list, and the turn ends for THAT clause only. Only
#                        a clause no answer could ever rescue becomes a capability
#                        note.
#   2. ModifyingAgent  — applies the RESOLVED clauses concurrently, each call
#                        scoped to ONE phase's JSON. Never the whole cadence.
#   3. ValidatingAgent — re-checks the PATCHED cadence against the admin's own
#                        words in ONE batched call. Numbers deterministically in
#                        code (with exact repairs); content in that single call.
#                        Shortfalls go BACK to the MODIFYING agent as targeted
#                        re-instructions, up to VALIDATE_RETRY_MAX times.
#
# There is no LLM "structure" call either. A whole-interview duration ask is
# arithmetic (`resolve_total_target` + `rescale_to_clean_minutes`), and keeping it
# in code is what makes "make it 15 minutes" land on 2/4/7/2 instead of
# 1:53/3:45/7:30/1:52 — proportional rescaling at second granularity is correct
# and reads terribly. Phases the admin gave an explicit duration are pinned.
#
# Clause independence is the point: a half-clear request applies its clear half
# in the SAME turn while asking about the rest — resolved work never waits on
# ambiguous work. The clarification loop is admin-driven and therefore
# UNBOUNDED by design (every round needs a human reply, so it cannot run away);
# it ends when an answer makes the clause routable.

# Validator → Modifying retry budget per turn. Beyond this the shortfall is
# reported to the admin instead of re-tried forever.
VALIDATE_RETRY_MAX = 2


def _build_cadence_llm(token: Optional[str] = None, *, role: str = "edit") -> CadenceLLM:
    """An LLM handle for the cadence agents.

    `role="validate"` returns a SEPARATE handle so the model that made an edit is
    not the model that grades it. `CADENCE_VALIDATOR_MODEL` (optionally with
    `CADENCE_VALIDATOR_PROVIDER`) picks that model; unset, validation runs on the
    same model as the edit — still an independent call with an independent prompt,
    just not an independent model."""
    from openai import AsyncOpenAI

    api_key, base_url, model = _resolve_llm()

    if role == "validate":
        override = (os.environ.get("CADENCE_VALIDATOR_MODEL") or "").strip()
        if override:
            provider = (os.environ.get("CADENCE_VALIDATOR_PROVIDER") or "").strip().lower()
            if provider in _PROVIDER_ENDPOINTS:
                v_base, key_env = _PROVIDER_ENDPOINTS[provider]
                v_key = _env_or_dotenv(key_env)
                if v_key:
                    api_key, base_url = v_key, v_base
                else:
                    logger.warning(
                        "[cadence_service] CADENCE_VALIDATOR_PROVIDER=%s but %s is "
                        "not set — validating on the edit provider", provider, key_env,
                    )
            model = override.split(":", 1)[0]
            logger.info("[cadence_service] validator model=%s", model)

    return CadenceLLM(
        client=AsyncOpenAI(api_key=api_key, base_url=base_url),
        model=model,
        extra_body=build_extra_body(base_url or ""),
        token=token,
    )


def _phase_catalog(token: Optional[str], current: list[dict]) -> dict:
    """{phase_id: phase_dict} of every phase we could legitimately put BACK.

    Needed because a removed phase is gone from the working YAML — "add the
    wrap-up back" has nothing to restore from unless we keep a record of what it
    was. Two sources, most specific first, so restoring never means inventing:

      1. the SAVED plan for this interview (has any generated/custom phases)
      2. the built-in default cadence (the standard warm_up → wrap_up set)

    Phases currently in the working plan are excluded by the caller, not here —
    this is the full catalog, and `plan_structure_op` decides what's restorable.
    """
    catalog: dict = {}

    # ORDER matters as much as content: the catalog's sequence is what decides
    # where a restored phase lands. So the SAVED plan goes in first — it's this
    # interview's real running order — and the built-in only fills gaps
    # (`setdefault`), which keeps a generated phase from being reordered by it.
    if token:
        try:
            from app import db
            row = db.get(token) or {}
            saved = yaml.safe_load(row.get("cadence_yaml") or "") or {}
            for p in saved.get("phases") or []:
                if isinstance(p, dict) and p.get("id"):
                    catalog[p["id"]] = p
        except Exception as e:
            logger.info("[cadence_service] no saved cadence to restore from (%s)", e)

    try:
        from engine.brain.cadence.schema import _DEFAULT_YAML_PATH
        built_in = yaml.safe_load(_DEFAULT_YAML_PATH.read_text(encoding="utf-8")) or {}
        for p in built_in.get("phases") or []:
            if isinstance(p, dict) and p.get("id"):
                catalog.setdefault(p["id"], p)
    except Exception as e:
        logger.warning("[cadence_service] could not read the default cadence: %s", e)

    # The code-review phase is always available to add, even on a plan that never
    # had one — it's a plain conversation phase (no coding_question_ids), so the
    # editor can add it outright. Offered via the catalog rather than built in the
    # editor so there stays exactly ONE definition of it.
    catalog.setdefault(CODE_DISCUSSION_PHASE["id"], dict(CODE_DISCUSSION_PHASE))

    # The working copy is the freshest truth for a phase that's still present —
    # which is what makes remove-then-re-add work inside ONE conversation. Value
    # is overwritten; position in the catalog is not.
    for p in current:
        if isinstance(p, dict) and p.get("id"):
            catalog[p["id"]] = p

    # Catalog ORDER is what decides where a restored phase lands, so it has to
    # encode two rules the sources don't:
    #   - a closing phase stays LAST (else a restore lands after the goodbye)
    #   - the code discussion sits right AFTER the coding round it reviews
    def _is_closer(pid: str) -> bool:
        return pid.lower().startswith(("wrap_up", "wrapup", "closing"))

    def _is_coding_exercise(body: dict) -> bool:
        return bool((body or {}).get("coding_question_ids")
                    or (body or {}).get("coding_question_id"))

    disc_id = CODE_DISCUSSION_PHASE["id"]
    body = catalog.get(disc_id)
    ordered: dict = {}
    for pid, pbody in catalog.items():
        if pid == disc_id or _is_closer(pid):
            continue
        ordered[pid] = pbody
        if body is not None and _is_coding_exercise(pbody):
            ordered[disc_id] = body      # directly after the coding round
    if body is not None:
        ordered.setdefault(disc_id, body)
    for pid, pbody in catalog.items():
        if _is_closer(pid):
            ordered[pid] = pbody
    catalog = ordered

    logger.info("[cadence_service] phase catalog order: %s", list(catalog))
    return catalog


async def _resolve_add_asks(
    llm: CadenceLLM, clauses: list[dict], *, phases: list[dict], catalog: dict,
) -> dict:
    """Resolve every ADD clause to a phase (or to "a new one"), by MEANING.

    Returns {clause_id: {phase_id, new_name, covers}}. A clause absent from the
    result is one the deterministic layer will ASK the admin about — costing one
    question, never a wrong add.

    Skipped entirely when the turn contains no add, so an ordinary edit still
    costs exactly the calls it did before."""
    asks = [
        {"clause_id": c.get("clause_id", ""), "text": c.get("text") or ""}
        for c in clauses
        if detect_structure_verb(c.get("text") or "") == "add"
    ]
    if not asks:
        return {}

    present = {p.get("id") for p in phases}
    available = [
        dict(body, id=pid) for pid, body in catalog.items() if pid not in present
    ]
    try:
        return await PhaseResolverAgent(llm).resolve(
            asks=asks, in_plan=phases, available=available,
            blocked=list(load_phase_blacklist()),
        )
    except Exception as e:
        # Never fatal: with no resolution every add becomes a question, which is
        # the same safe outcome as an ambiguous one.
        logger.warning("[cadence_service] phase resolver unavailable (%s) — "
                       "add asks will be put back to the admin", e)
        return {}


def _total_change_line(before_total: int, after_total: int, outcomes: list) -> str:
    """The one plan-level line the per-instruction outcomes can't carry.

    A total can move as a CONSEQUENCE of something the admin asked (removing a
    phase, or pinning one phase's length) without being asked for directly, and
    that's worth a line. Suppressed when an outcome already states the new total,
    so the admin never reads the same fact twice."""
    if before_total == after_total:
        return ""
    if any(o.status == "applied" and o.message.startswith("Set the whole interview")
           for o in outcomes):
        return ""
    return f"Interview is now {fmt_dur(after_total)} (was {fmt_dur(before_total)})"


async def revise_cadence_conversational(
    *, current_yaml: str, feedback: str = "", clarifications: Optional[list[dict]] = None,
    context: str = "", token: Optional[str] = None,
) -> dict:
    """Conversational multi-agent revise — the entry point behind
    POST /api/cadence/revise.

    Returns a dict, not a YAML string, because a single turn can legitimately
    end in a MIX of outcomes: some clauses applied, some awaiting an answer,
    some declined as out of scope, some attempted-but-not-landed.

    `clarifications` are questions asked on a PREVIOUS turn, now carrying the
    admin's `answer`; they're re-routed alongside any new `feedback` in ONE
    router call, so a turn costs one router call whether the admin is asking
    something new, answering, or both.

    Response:
      {ok, yaml, changed, applied: [str], questions: [...], out_of_scope: [...],
       notes: [...]}

    `ok: False` means the turn could not be PROCESSED at all (the cadence isn't
    readable, or the router call itself failed) — the only thing to show is
    `error`. Everything else is `ok: True` and described by the four lists; a
    clause that failed to apply is a `note`, not an error, so it can travel
    alongside the clauses that did apply."""
    clarifications = [c for c in (clarifications or []) if isinstance(c, dict)]
    answered = [c for c in clarifications if str(c.get("answer") or "").strip()]
    if not (feedback or "").strip() and not answered:
        raise ValueError("feedback is empty — nothing to revise")

    def _fail(error: str) -> dict:
        """Turn refused. The cadence is returned untouched — we never hand back
        a plan we couldn't build honestly, and we never rewrite the whole YAML to
        paper over it."""
        logger.warning("[cadence_service] conversational revise refused: %s", error)
        return {
            "ok": False, "error": error, "yaml": current_yaml, "changed": False,
            "applied": [], "questions": [], "out_of_scope": [], "notes": [],
        }

    try:
        data = yaml.safe_load(current_yaml)
    except yaml.YAMLError as e:
        return _fail(
            "This cadence isn't valid YAML, so there's nothing to edit safely: "
            f"{str(e).splitlines()[0]}. Fix it in the editor below (or regenerate "
            "the plan) and try again."
        )
    if not isinstance(data, dict) or not isinstance(data.get("phases"), list):
        return _fail(
            "This cadence has no `phases` list, so there are no phases to edit. "
            "Fix it in the editor below (or regenerate the plan) and try again."
        )

    if not data["phases"]:
        return _fail(
            "This cadence has no phases, so there's nothing to edit. Add a phase "
            "(or regenerate the plan) and try again."
        )
    phases = [p for p in data["phases"] if isinstance(p, dict) and p.get("id")]
    if not phases:
        return _fail(
            "Every phase in this cadence is missing an `id`, so there's nothing "
            "to target. Fix it in the editor below and try again."
        )
    # Normalise the BEFORE plan through the SAME schema the AFTER plan goes
    # through. Without this, `before` is raw YAML and `after` is a pydantic dump
    # that injects `question_pool: []`, `coding_question_ids: []` and friends — so
    # every phase compares unequal and the admin is told all four phases changed
    # when they only asked about one.
    try:
        normalized = CadencePlan.model_validate(data).model_dump(mode="json")
        phases = [p for p in normalized.get("phases") or [] if isinstance(p, dict) and p.get("id")]
        data = normalized
    except ValidationError as e:
        # Not fatal: an unnormalisable plan can still be edited, the change
        # summary is just derived from the raw shape.
        logger.info("[cadence_service] before-plan not schema-clean (%s) — "
                    "diffing against raw YAML", str(e).splitlines()[0])

    before_by_id = {p["id"]: p for p in phases}
    current_total = int(data.get("total_duration_s") or sum(int(p.get("duration_s") or 0) for p in phases))

    llm = _build_cadence_llm(token)

    # ── 1. ROUTER ────────────────────────────────────────────────────────
    try:
        route = await RouterAgent(llm).route(
            feedback=feedback, clarifications=answered, phases=phases,
            total_duration_s=current_total,
        )
    except ValueError as e:
        # Can't classify the ask → can't scope any edit. Retrying is the admin's
        # call; guessing at the whole plan instead is exactly what we removed.
        return _fail(f"Couldn't work out what to change ({e}). Try rephrasing, or try again.")

    # ── 1b. PHASE RESOLVER — only for ADD asks ───────────────────────────
    # "Which phase do they mean?" is the one genuinely LINGUISTIC question in an
    # add, and the only one code was measurably bad at: a coding DISCUSSION scores
    # 0.95 against `coding_round` by string overlap, so it was refused with the
    # coding-picker message. Matching is done on the candidate phases' INTENTS
    # instead, which also means a phase added to the catalog or the blacklist
    # needs no spellings maintained anywhere.
    #
    # It runs HERE, not inside `plan_deterministic`, so that function stays sync
    # and LLM-free: it receives the resolution as data and every consequence of it
    # (branch, arithmetic, insert) is still deterministic.
    catalog = _phase_catalog(token, phases)
    add_resolutions = await _resolve_add_asks(
        llm, route.resolved, phases=phases, catalog=catalog,
    )

    # ── 2. DETERMINISTIC PRE-PASS ────────────────────────────────────────
    # Structure (remove/reorder) and durations are LIST and ARITHMETIC operations.
    # They are settled here, in code, before any model sees the turn — that is the
    # fix for "remove the wrapup phase" being handed to a content editor that can
    # only rewrite questions, and for an explicit "15 min" coming back as a
    # question the admin had already answered.
    det = plan_deterministic(
        route.resolved, phases, current_total, ALL_PHASES,
        catalog=catalog, add_resolutions=add_resolutions,
    )
    data["phases"] = det.phases
    phases = det.phases
    questions = route.questions + det.questions
    out_of_scope = route.out_of_scope + det.refusals

    logger.info(
        "[cadence_service] deterministic: %d applied, %d content, %d asked, %d refused",
        sum(1 for o in det.outcomes if o.status == "applied"),
        len(det.content_clauses), len(det.questions), len(det.refusals),
    )

    if not det.content_clauses and det.total_target is None and not any(
        o.status == "applied" for o in det.outcomes
    ):
        # Nothing executable this turn — the cadence is untouched and the admin
        # gets the questions / capability notes. This is the LOOP, not an error.
        return {
            "ok": True, "yaml": current_yaml, "changed": False, "applied": [],
            "questions": questions, "out_of_scope": out_of_scope, "notes": [],
        }

    # ── 2b. MODIFYING — content asks only ────────────────────────────────
    modifier = ModifyingAgent(llm)
    content_mapping: dict[str, list[str]] = {}
    for c in det.content_clauses:
        content_mapping.setdefault(c["phase_id"], []).append(c["text"])

    result = await modifier.apply(
        data=data, phases=phases, phase_mapping=content_mapping,
        total_instructions=[], current_total=current_total, context=context,
    )
    # A failed unit needs no special handling here: `merged` already holds the
    # siblings that worked, and the VALIDATING agent is the safety net for the
    # rest — it re-checks the clause against the before/after either way, so a
    # failed call is repaired in code (durations), retried (content), or reported
    # as a note. That makes a transient provider blip self-healing instead of an
    # excuse to rewrite the whole plan.
    merged = result.data
    # Durations were pinned by the deterministic pass and must survive the content
    # edit; the total is reached by the validator's reconcile, which respects pins.
    for p in merged.get("phases") or []:
        if isinstance(p, dict) and p.get("id") in det.phase_targets:
            p["duration_s"] = det.phase_targets[p["id"]]

    # ── 3. VALIDATING (+ targeted retry back to the MODIFYING agent) ──────
    # Its own model handle: the model that made the edit does not grade it.
    validator = ValidatingAgent(_build_cadence_llm(token, role="validate"))
    notes: list[dict] = []
    outcomes = list(det.outcomes)
    for attempt in range(VALIDATE_RETRY_MAX + 1):
        report = await validator.validate(
            content_clauses=det.content_clauses, before_by_id=before_by_id,
            after_data=merged, phase_targets=det.phase_targets,
            total_target=det.total_target, prior_outcomes=det.outcomes,
        )
        merged, notes, outcomes = report.data, report.notes, report.outcomes
        if report.satisfied or attempt == VALIDATE_RETRY_MAX:
            if not report.satisfied:
                logger.warning("[cadence_service] validator gave up after %d retries: %s",
                               VALIDATE_RETRY_MAX, sorted(report.phase_shortfalls))
            break

        logger.info("[cadence_service] validator retry %d/%d for phase(s)=%s",
                    attempt + 1, VALIDATE_RETRY_MAX, sorted(report.phase_shortfalls))
        retry_phases = [p for p in merged["phases"] if isinstance(p, dict) and p.get("id")]
        retry_ids = {p["id"] for p in retry_phases}
        retry_mapping = {
            pid: [f"{i} (this was NOT applied on the previous attempt — apply it now)" for i in instrs]
            for pid, instrs in report.phase_shortfalls.items()
            if pid in retry_ids
        }
        if not retry_mapping:
            break
        # Content-only retry: no total_instructions, so the duration the
        # deterministic pass already settled is never re-litigated.
        retried = await modifier.apply(
            data=merged, phases=retry_phases, phase_mapping=retry_mapping,
            current_total=int(merged.get("total_duration_s") or 0), context=context,
        )
        if not retried.ok:
            logger.warning("[cadence_service] validator retry partially failed (phases=%s)",
                           retried.failed_phases)
        # Whatever the retry DID fix is kept; the next validate pass re-checks
        # the rest, and the loop is bounded, so a broken retry costs accuracy in
        # the notes at worst — never the edits that already landed.
        merged = retried.data

    try:
        plan = CadencePlan.model_validate(merged)
    except ValidationError as e:
        # The scoped edits combined into a plan the schema rejects. We won't hand
        # back something invalid, and we won't rewrite the whole cadence to hide
        # it — so nothing changes and the admin is told exactly that. Questions
        # from the router are still valid and still worth answering, so the turn
        # is `ok` with a note, not an error.
        logger.error("[cadence_service] merged plan failed validation: %s", str(e).splitlines()[0])
        return {
            "ok": True, "yaml": current_yaml, "changed": False, "applied": [],
            "questions": questions, "out_of_scope": out_of_scope,
            "notes": [{
                "clause_id": (route.resolved[0].get("clause_id", "") if route.resolved else ""),
                "text": " / ".join(c["text"] for c in route.resolved),
                "why": (
                    "applying this produced an invalid plan ("
                    f"{humanize_cadence_error(str(e))}), so I left the cadence unchanged"
                ),
            }],
        }

    out_yaml = yaml.safe_dump(plan.model_dump(mode="json"), sort_keys=False)
    final = plan.model_dump(mode="json")

    # The chat lines are the VALIDATED per-instruction outcomes — one line per
    # thing the admin asked, in their terms. Deliberately NOT a before/after diff
    # of the whole plan: that reported every phase whose schema defaults shifted
    # and left the admin unable to tell which of their asks had landed.
    applied = [o.message for o in outcomes if o.status == "applied" and o.message]
    total_line = _total_change_line(
        current_total, int(final.get("total_duration_s") or 0), outcomes,
    )
    if total_line:
        applied.append(total_line)
    if not applied:
        applied = ["No change was needed"]

    logger.info("[cadence_service] conversational revise applied=%d questions=%d notes=%d",
                len(applied), len(questions), len(notes))
    return {
        "ok": True, "yaml": out_yaml,
        "changed": out_yaml.strip() != (current_yaml or "").strip(),
        "applied": applied, "questions": questions,
        "out_of_scope": out_of_scope, "notes": notes,
    }
