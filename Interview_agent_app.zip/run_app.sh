#!/usr/bin/env bash
# run_app.sh — single entry point for Mac/Linux.
#
# Boots Stream A in a separate Terminal window (Mac) or background process
# (Linux), waits for /healthz, then runs the admin web server (uvicorn :8000)
# in the foreground. Opens the browser to the admin login page.
set -euo pipefail
cd "$(dirname "$0")"
ROOT="$(pwd)"

if [[ ! -x "$ROOT/.venv/bin/python" ]]; then
    echo "ERROR: $ROOT/.venv/bin/python not found. Set up the venv first:" >&2
    echo "    uv venv .venv" >&2
    echo "    uv pip install -e ." >&2
    exit 2
fi

if [[ ! -f "$ROOT/.env" ]]; then
    echo "ERROR: .env not found. Copy .env.example to .env and fill in keys." >&2
    exit 2
fi

# 1. Kill stale processes on Stream A ports + admin port
for port in 8000 8010 8011 8012; do
    pids=$(lsof -ti tcp:$port 2>/dev/null || true)
    if [[ -n "$pids" ]]; then
        kill -9 $pids 2>/dev/null || true
    fi
done

# 2. Boot Stream A in a separate window (Mac) or background (Linux)
echo "Booting Stream A in a separate window..."
if [[ "$OSTYPE" == "darwin"* ]]; then
    osascript -e "tell application \"Terminal\" to do script \"cd $ROOT && bash scripts/run_stream_a_only.sh\"" >/dev/null
else
    # Linux: try a terminal emulator, else background
    if command -v gnome-terminal >/dev/null; then
        gnome-terminal --title="Stream A" -- bash -c "cd $ROOT && bash scripts/run_stream_a_only.sh; exec bash" &
    elif command -v x-terminal-emulator >/dev/null; then
        x-terminal-emulator -T "Stream A" -e bash -c "cd $ROOT && bash scripts/run_stream_a_only.sh; exec bash" &
    elif command -v konsole >/dev/null; then
        konsole -p tabtitle="Stream A" -e bash -c "cd $ROOT && bash scripts/run_stream_a_only.sh; exec bash" &
    elif command -v xterm >/dev/null; then
        xterm -T "Stream A" -e bash -c "cd $ROOT && bash scripts/run_stream_a_only.sh; exec bash" &
    else
        echo "(no terminal emulator found; running Stream A headless — logs in /tmp/stream_a.log)"
        bash scripts/run_stream_a_only.sh > /tmp/stream_a.log 2>&1 &
    fi
fi

# 3. Wait for Stream A /healthz
echo "Waiting for Stream A to come up..."
START_TS=$(date +%s)
DEADLINE=$((START_TS + 900))
while :; do
    if curl -sf http://127.0.0.1:8010/healthz >/dev/null \
        && curl -sf http://127.0.0.1:8011/healthz >/dev/null \
        && curl -sf http://127.0.0.1:8012/healthz >/dev/null; then
        break
    fi
    NOW=$(date +%s)
    if (( NOW > DEADLINE )); then
        echo "ERROR: Stream A did not come up in 15 min. Check the Stream A window." >&2
        exit 3
    fi
    ELAPSED=$((NOW - START_TS))
    if (( ELAPSED > 30 && ELAPSED % 15 == 0 )); then
        echo "  [+${ELAPSED}s] still waiting on Stream A healthz..."
    fi
    sleep 2
done
echo "Stream A ready."

# 4. Open browser to admin login (delayed so uvicorn has time to bind)
if [[ "$OSTYPE" == "darwin"* ]]; then
    ( sleep 2 && open http://localhost:8000/admin/login ) &
else
    ( sleep 2 && xdg-open http://localhost:8000/admin/login 2>/dev/null ) &
fi

echo ""
echo "============================================================"
echo "  ADMIN APP STARTING on http://localhost:8000"
echo "  Sign in via the browser tab that just opened."
echo ""
echo "  This window: admin server logs."
echo "  Other window: Stream A (STT/VAD/TTS) logs."
echo "  Per-interview windows: opened when admin approves a cadence."
echo "============================================================"
echo ""

exec "$ROOT/.venv/bin/python" -m uvicorn app.main:app --host 0.0.0.0 --port 8000
