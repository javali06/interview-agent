# The Cadence Editor — "Revise & Verify Cadence with AI"

**What this is.** A TA types a plain-English request like *"remove the wrap-up phase and make
the whole interview 15 minutes and warm-up 2min30sec"*, and the interview plan changes to match
— or the system asks a question instead of guessing. This document explains the whole thing in
simple terms: the agents, the tools, the flow, what it handles, and where it deliberately
refuses.

**One sentence version:** an LLM reads the request and splits it into separate instructions
(`RouterAgent`); a second decides *which phase* an "add" refers to (`PhaseResolverAgent`); plain
code does everything it can do exactly — removing phases, all arithmetic (`phase_tools`); a third
rewrites phase content (`ModifyingAgent`); and a fourth, on a *different* model, checks the result
and writes what the TA sees (`ValidatingAgent`).

**Four agents, one code layer** — §2 names each one and traces all four through a single request
("add a system design round"), which is the shortest way to see who decides what.

---

## 1. The mental model

### What a cadence is

A cadence is the interview plan: an ordered list of phases, each with a time budget and the
questions to ask. It lives as YAML.

```yaml
total_duration_s: 900              # must EXACTLY equal the sum of the phases
phases:
  - id: warm_up                    # snake_case, unique
    duration_s: 150
    intent: Put the candidate at ease.
    question_mode: generic         # AI improvises from generic_prompts
    generic_prompts: ["Greet the candidate."]
  - id: technical_questions
    duration_s: 750
    intent: Gauge depth on AI fundamentals.
    question_mode: specific        # AI is handed exact questions from question_pool
    question_pool:
      - {id: q1, text: "Explain attention."}
```

Two rules the schema enforces (`engine/brain/cadence/schema.py`), and the reason arithmetic is
never left to a model:

- `total_duration_s` must equal the sum of every phase's `duration_s` — exactly, to the second.
- Phase ids must be unique, and exactly one of `generic_prompts` / `question_pool` is set,
  matching `question_mode`.

If a plan breaks either rule it is rejected outright and the TA's cadence is left untouched.
"Approximately 15 minutes" is not a rounding wobble here — it's a plan that won't load.

### The core design rule

> **Never ask a model to do something code can do exactly. Never let a model silently guess
> when code isn't sure.**

Everything below follows from that one rule. Removing a phase is a list operation. Converting
"15 min" to 900 seconds is arithmetic. Neither needs an LLM, and both used to break when an LLM
did them.

The converse matters just as much, and cost us a bug: **don't ask code to do something only
meaning can settle.** Deciding whether "add a coding discussion" means the live coding exercise
or the review conversation is not string matching — those two asks share nearly every word. That
one belongs to **`PhaseResolverAgent`** (§2), which exists for exactly this.

So there are three LLM jobs and everything else is code:

| The LLM job | Whose | Why code can't do it |
|---|---|---|
| Split a messy sentence into instructions | `RouterAgent` | Sentence boundaries aren't punctuation |
| Decide **which phase** an "add" means | `PhaseResolverAgent` | "coding round" vs "coding discussion" share every word |
| Rewrite a phase's questions/intent | `ModifyingAgent` | "make it friendlier" has no algorithm |
| *(and to check the last one)* | `ValidatingAgent` | judging whether wording satisfies an ask |

---

## 2. The agents

**Four LLM agents and one code layer.** Every agent is identified below by the name you'll
actually grep for — the class, the file, the `name` it traces under in Langfuse, the `stage`
label on each call, and the prompt key in `config/prompts.yaml`.

| Step | Agent class | File | Traces as (`name`) | `stage` | Prompt key |
|---|---|---|---|---|---|
| 1 | **`RouterAgent`** | `router_agent.py` | `cadence_router_agent` | `route` | `cadence_router` |
| 1b | **`PhaseResolverAgent`** | `phase_resolver_agent.py` | `cadence_phase_resolver_agent` | `resolve` | `cadence_phase_resolver` |
| — | *(no agent)* **`phase_tools`** | `phase_tools.py` | — *(never calls an LLM)* | — | — |
| 2 | **`ModifyingAgent`** | `modifying_agent.py` | `cadence_modifying_agent` | `phase` | `cadence_phase_revise` |
| 3 | **`ValidatingAgent`** | `validating_agent.py` | `cadence_validating_agent` | `validate` | `cadence_validator` |

`PhaseResolverAgent` is the newest of the four and the only one that runs **conditionally** — it
fires solely for clauses whose verb is `add`. The other three are on the path of every turn that
gets that far.

What each one is allowed to see. This is the containment rule of the whole design: **the raw
cadence YAML is never sent to an LLM by any path.**

| Agent | Sees | Never sees |
|---|---|---|
| `RouterAgent` | `{id, intent, duration_s}` per phase + the total | phase bodies, prompts, question pools |
| `PhaseResolverAgent` | `{id, intent}` of candidate phases, in three sets | durations, bodies, the plan itself |
| `ModifyingAgent` | ONE phase's JSON, one call per phase | the other phases, the total |
| `ValidatingAgent` | before/after of *touched* phases, content keys only | untouched phases, durations |

And what each one is allowed to *decide*:

| Agent | Decides | Explicitly does NOT decide |
|---|---|---|
| `RouterAgent` | how many instructions, and a **hint** at each one's target | any number; any edit |
| `PhaseResolverAgent` | **which phase** an add refers to (by meaning) | any number; any phase body; where it goes |
| `phase_tools` | every structural op, every number, every insert position | anything requiring judgement about wording |
| `ModifyingAgent` | a phase's `intent` / prompts / questions | its `id` or `duration_s` |
| `ValidatingAgent` | whether a content ask landed, and the TA-facing wording | arithmetic (checked in code), structure (set membership) |

### How they fit together

```
   TA's message
        │
        ▼
  ┌───────────────────┐   1 call        splits the message into independent clauses;
  │  RouterAgent      │───────────────► its phase_id is a HINT, not a verdict
  └─────────┬─────────┘
            │  clauses
            ▼
      any clause an "add"? ──── no ──────────────────────────┐
            │ yes                                            │
            ▼                                                │
  ┌───────────────────┐   1 call        WHICH phase is this? matched on the
  │ PhaseResolverAgent│───────────────► candidates' `intent`, never their spelling
  └─────────┬─────────┘                 → phase_ids[] · new_name · covers
            │                                                │
            └────────────────────┬───────────────────────────┘
                                 ▼
  ┌──────────────────────────────────────────────────────────────────────┐
  │  phase_tools.plan_deterministic()          ZERO LLM calls            │
  │  structure → durations → whatever is genuinely a content ask         │
  │  Produces per clause: applied · asked · refused · (pass to Modifying)│
  └──────────────────────────────┬───────────────────────────────────────┘
                                 │  content asks only
                                 ▼
  ┌───────────────────┐   1 call PER PHASE, concurrent
  │  ModifyingAgent   │───────────────► rewrites that one phase's content
  └─────────┬─────────┘
            ▼
  ┌───────────────────┐   1 batched call, on its OWN model handle
  │  ValidatingAgent  │───────────────► did each ask land? + writes what the TA reads
  └─────────┬─────────┘
            │  shortfall? ──► back to ModifyingAgent (max VALIDATE_RETRY_MAX = 2)
            ▼
      schema gate → YAML  ·  or nothing ships at all
```

### All four agents on one request — "add a system design round"

This is the flow that exercises every agent, including the conditional one. Starting plan:
`warm_up 2:30 · resume_deep_dive 6:30 · technical_questions 6:00` — total **15:00**.

```
════ TURN 1 ════  TA: "add a system design round"
    │
    ├─► RouterAgent ─────────────────────────────────── 1 LLM call
    │     sees {id, intent, duration_s} for the 3 phases + total 900
    │     returns 1 clause:
    │        {kind:"phase", text:"add a system design round", phase_id:""}
    │                                                    ▲ EMPTY by rule 2 —
    │                                                      an ADD is never the
    │                                                      router's call to make
    │
    ├─► PhaseResolverAgent ──────────────────────────── 1 LLM call  ◀ fires: verb is "add"
    │     sees three candidate sets, each phase as {id, intent}:
    │        in_plan   warm_up · resume_deep_dive · technical_questions
    │        available code_discussion · wrap_up          (the catalog, §3.5)
    │        blocked   coding_round                       (§3.7)
    │     none of them IS a system-design round, so:
    │        phase_ids: []          ← ⇒ this is a NEW phase
    │        new_name:  "system_design"
    │        covers:    ""          ← they named a phase and nothing else
    │
    ├─► phase_tools.plan_deterministic() ────────────── 0 LLM calls
    │     verb is "add" → structure step → _plan_add() with that resolution
    │     phase_ids empty  → the CREATE branch
    │     duration?  parse_absolute_duration_target("add a system design round") → None
    │     coverage?  covers == ""                                                → missing
    │     BOTH missing ⇒ outcome = "asked".  Nothing is written to the plan.
    │
    ├─► ModifyingAgent   ── skipped, there is no content ask
    ├─► ValidatingAgent  ── skipped, nothing was applied
    │
    └─◄ "I can add a system-design phase. How long should it be, and what
         should it cover?"                 options: []   ← no chips, on purpose
         plan unchanged — still 15:00                    (2 LLM calls this turn)


════ TURN 2 ════  TA: "10 minutes, focus on scalability trade-offs and caching"
    │
    │   The browser replays the still-open question WITH the answer:
    │     clarifications: [{clause_id:"c1",
    │                       text:    "add a system design round",   ← the ORIGINAL ask
    │                       question:"I can add a system-design phase. How long…",
    │                       answer:  "10 minutes, focus on scalability trade-offs…"}]
    │
    ├─► RouterAgent ─────────────────────────────────── 1 LLM call
    │     re-reads the (question, answer) pair and emits ONE clause whose text is
    │        "add a system design round — 10 minutes, focus on scalability
    │         trade-offs and caching"
    │        ▲ prompt rule 6: original + answer. The verb "add" MUST survive, or
    │          every step below stops recognising this as an add at all.
    │
    ├─► PhaseResolverAgent ──────────────────────────── 1 LLM call
    │        phase_ids: []
    │        new_name:  "system_design"
    │        covers:    "scalability trade-offs and caching"   ← now present
    │
    ├─► phase_tools.plan_deterministic() ────────────── 0 LLM calls
    │     duration = 600s  (code parses "10 minutes" — never the model)
    │     coverage present ⇒ CREATE:
    │        · derive id      → "system_design"  (uniquified, pattern-checked)
    │        · insert SKELETON before wrap_up    (schema-valid on its own)
    │        · PIN duration_s = 600              (content pass cannot move it)
    │        · emit a content clause carrying the coverage brief
    │
    ├─► ModifyingAgent ──────────────────────────────── 1 LLM call (this phase only)
    │     input:  the skeleton phase JSON + "…deliver what the admin asked for:
    │             'scalability trade-offs and caching'"
    │     output: real `intent` + `generic_prompts`
    │
    ├─► ValidatingAgent ─────────────────────────────── 1 batched LLM call (own model)
    │     code: re-pin 600s · recompute total 900 → 1500
    │     LLM:  did the content ask land? → yes
    │     authors the TA-facing lines
    │
    └─◄ ✓ Added a new system-design phase, set to 10:00
        ✓ Interview is now 25:00 (was 15:00)                (4 LLM calls this turn)
```

The phase that lands — real output, not illustrative:

```yaml
- id: system_design
  duration_s: 600
  intent: Assess the candidate's understanding of scalability trade-offs and caching.
  question_mode: generic
  generic_prompts:
    - Discuss how the candidate evaluates scalability trade-offs in system design.
    - Explore the candidate's experience with implementing caching strategies and
      their impact on performance.
```

Read the division of labour off that trace: the **Router** decided it was one instruction,
the **Resolver** decided it wasn't any phase we already know, **code** decided the id, the
position, the number and the total, and the **Modifying** agent wrote the only thing that
needed writing. No model touched a number; no code tried to judge what "system design" means.

### Agent 1 — `RouterAgent`: a splitter, nothing more

`app/cadence_agents/router_agent.py` · prompt `cadence_router` · traces as
`cadence_router_agent`, stage `route`.

The Router turns one message into a list of instructions ("clauses"), each tagged one of **two**
kinds:

- **`phase`** — it can name what this changes (a phase id, or `ALL` for the whole interview).
- **`ambiguous`** — it genuinely cannot tell which phase, so a question is needed.

```
Input:  "remove the wrapup phase and make whole interview 15min and warumup 2min30sec"

Output: [
  {kind: "phase", text: "remove the wrapup phase",     phase_id: ""},
  {kind: "phase", text: "make whole interview 15min",   phase_id: "ALL"},
  {kind: "phase", text: "warumup 2min30sec",            phase_id: ""},
]
```

**Its `phase_id` is a HINT, not a verdict.** If the Router names a phase that doesn't exist, the
id is blanked and the tools layer re-resolves it from the text. This matters: `"remove the
wrapup phase"` is unambiguous to code even when the Router labels it with a made-up id — and
rejecting it used to throw away a perfectly executable request.

Code also **takes clauses back** from the Router when it over-reaches. Two hard overrides:

- Clause carries an explicit duration (`"15min"`) but the Router marked it ambiguous or
  impossible → **taken back.** A number the TA already gave is never a reason to ask.
- Clause carries a structure verb (`remove` / `move` / `swap`) but the Router called it
  impossible → **taken back.** The editor does those.

The Router does **no arithmetic** and edits **nothing**.

### Agent 1b — `PhaseResolverAgent`: which phase does an "add" mean?

`app/cadence_agents/phase_resolver_agent.py` · class **`PhaseResolverAgent`** · prompt
`cadence_phase_resolver` · traces as `cadence_phase_resolver_agent`, stage `resolve` ·
entry point `PhaseResolverAgent.resolve(asks, in_plan, available, blocked)`.

**The newest agent, and the only conditional one.** It runs *only* for clauses whose verb is
`add` (`cadence_service._resolve_add_asks` filters on `detect_structure_verb(text) == "add"`),
so an ordinary edit costs exactly the calls it always did. It answers exactly one question —
*which phase is this?* — by reading each candidate phase's **`intent`**, i.e. what the phase
*is*, and matching on meaning rather than spelling.

```
ask:       "add a coding discussion"
candidates in_plan   [warm_up "Put the candidate at ease.", …]
           available [code_discussion "Review the candidate's coding solution — approach,
                                       complexity, edge cases.", …]
           blocked   [coding_round "A live coding exercise where the candidate writes and
                                    runs real code…"]
answer:    {phase_ids: ["code_discussion"], new_name: "", covers: ""}
```

Four possible answers, and each leads somewhere different:

| Answer | Meaning | What happens |
|---|---|---|
| an id from **in_plan** | already in this interview | "that's already here" — or a **content** edit, see below |
| an id from **available** | we hold a real definition (the catalog, §3.5) | restored verbatim |
| an id from **blocked** | exists, but not addable from chat | refused with **that entry's own reason** |
| `phase_ids: []` | none of them — a genuinely new phase | created, after asking what it should cover and how long |

**`phase_ids` is a LIST, not one id.** One clause legitimately names several — *"add the wrap-up
and a coding phase"* reliably arrives merged — and answering only the first silently loses the
other half. Both are answered: the wrap-up is restored **and** the coding half gets its refusal.

**`covers`** is what the TA said the phase should be *about* ("scalability trade-offs"), and is
deliberately **empty** when they only named a phase. Empty is a useful answer: it's what tells
code to ask. It is never filled in from the phase name — that would be inventing the TA's intent.

What the Resolver does **not** do:

- **No arithmetic.** Durations are parsed in code. An exact number is never a model's job.
- **No phase bodies.** A restore takes the catalog's body; a create has its content authored later
  by the Modifying agent, which already does exactly that job with schema validation and retries.

**Fails CLOSED.** A failed call, a malformed reply, or an invented phase id all yield *no*
resolution, and the TA is asked which phase they meant. A wrong silent add is the failure this
whole layer exists to prevent, so "I'm not sure" must never become "I picked one".

Why an LLM here at all, in a system built on "don't let a model do what code can": code was
measurably **bad** at this one. `"add a coding discussion"` scores **0.95** against `coding_round`
by string overlap — `"round"` is a stopword, so that id's only significant token is `"coding"`,
which the text contains. So the discussion ask was answered with the coding-picker refusal and
nothing was added. Alias lists were the obvious next step and the wrong one: every phase added to
the catalog or blacklist would need its own hand-maintained spellings, and a near-miss still lands
somewhere confidently wrong.

### The tools layer — `phase_tools.plan_deterministic()` (zero LLM calls)

`plan_deterministic()` is the single decision point. It runs before any editing model sees the
turn, in this order:

```
1. STRUCTURE   remove / reorder / move / restore → applied in code, or refused with a reason
2. DURATIONS   phase durations and the total     → applied in code, or a question
3. LEFTOVERS   real content asks                 → the ONLY thing the Modifying agent gets
```

Order matters: a removed phase must not then be content-edited.

For each clause it produces one of four outcomes — `applied`, `asked`, `refused`, or passed on
as content. Anything doubtful becomes a **question**, never a silent edit.

**One clause can produce two outcomes.** Two cases, both found by testing rather than reasoning:

- *Structure **+** duration* — `"add the wrap up phase and make it 3 minutes"`. Consuming the
  clause on the structure op alone silently dropped the number. The duration is applied too (and
  pinned), and the line reads `Added the wrap-up phase back, set to 3:00`. The structure verb has
  to be **stripped before the duration parse**, because `"add"` is itself a relative-duration
  marker (`"add 2 minutes"`) — with it left in, the clause parsed as relative and returned nothing.
- *Doable **+** refused* — `"add wrapup phase and coding phase"`. The router merges this into ONE
  clause (measured: 5/5 runs), and refusing the whole thing on the coding half lost the wrap-up.
  Now the wrap-up is restored **and** the coding half comes back as its own refusal
  (`StructureOp.extra_refusal`).

### Agent 2 — `ModifyingAgent`: content only, one phase per call

`app/cadence_agents/modifying_agent.py` · prompt `cadence_phase_revise` · traces as
`cadence_modifying_agent`, stage `phase`.

Gets only the clauses that need judgement. One concurrent LLM call **per phase**, carrying that
phase's JSON and nothing else.

```
Input to the call:  {"id": "warm_up", "duration_s": 150, "intent": "...",
                     "question_mode": "generic", "generic_prompts": ["Greet the candidate."]}
Instruction:        "make it friendlier"
Output:             the same phase, with generic_prompts rewritten
```

- Calls fire **concurrently** (`asyncio.gather`) — they're independent.
- Results merge **in code**, never by a model.
- One failed call **cannot** discard its siblings' edits: the merge always carries whatever
  succeeded.
- The result is schema-checked per phase, with the exact error fed back on retry (3 attempts).

The candidate's **resume/JD is attached only when that phase's own instruction mentions it**
("project", "resume", "experience"…). This is why the Router is told to extract text verbatim:
a stray "resume" borrowed from a *different* instruction would send the wrong context to the
wrong phase.

### Agent 3 — `ValidatingAgent`: checks the work, and owns the chat

`app/cadence_agents/validating_agent.py` · prompt `cadence_validator` · traces as
`cadence_validating_agent`, stage `validate`.

Runs **after** everything is patched, and does two things.

**(a) Verifies**, split by what each check actually needs:

| What | How | Why |
|---|---|---|
| Durations, total | **code** — re-pin each explicit duration, reconcile the total | Never ask a model to check arithmetic; both have exact fixes |
| Removed / reordered | **code** — set membership on the phase list | "Is it gone?" is a membership test, not judgement |
| Content | **one batched LLM call** for all content asks | Only this needs judgement |

**(b) Writes what the TA reads** — one line per *instruction*:

```
✓ Removed the wrap-up phase
✓ Set the whole interview to 15:00
✓ Set the warm-up phase to 2:30
```

Three things asked, three lines back. Not a diff of the whole plan.

Two safety properties:

- **Its own model.** `CADENCE_VALIDATOR_MODEL` (+ optional `CADENCE_VALIDATOR_PROVIDER`) makes
  it a *different* model from the one that made the edit, so nothing grades its own homework.
  Unset, it's still an independent call with an independent prompt.
- **Fails open.** No verdict → no shortfall raised, ever. A broken validator must not burn
  retries or invent a failure it couldn't actually verify.

Every applied line is **guaranteed to name its phase** (`_name_phase`, enforced in code, not
just requested in the prompt). When an instruction never named a phase — *"make the system
architecture round more engaging"* — that line is the TA's only way to see where the edit
landed.

---

## 3. The tools (all in `phase_tools.py`, all pure code)

### Family 1 — Duration arithmetic

| Tool | Does | Example |
|---|---|---|
| `parse_absolute_duration_target` | Reads an explicit target | `"2min30sec"` → `150` |
| `parse_relative_duration_delta` | Reads a signed change | `"add 2 minutes"` → `+120` |
| `is_time_change_ask` | Is this about TIME or about the phase list? | `"add 2 minutes"` → time; `"add a coding phase"` → not |
| `resolve_total_target` | Either of the above, against the current total | `"trim by 3 min"` → `current − 180` |
| `rescale_to_clean_minutes` | Hits a target on **whole minutes** | 15 min → `2/4/7/2`, not `1:53/3:45/7:30/1:52` |
| `rescale_to_exact_total` | Hits a target to the second | largest-remainder rounding |
| `reconcile_total_with_pins` | Honours a pinned phase, others absorb the difference | see below |
| `is_whole_interview_scope` | Is this about the interview or one phase? | `"15 minutes total"` → interview |

**Why whole minutes:** a TA who says "make it 15 minutes" means a plan a human would have
written. Second-level proportional scaling is mathematically right and reads terribly. So the
unit of allocation is the **minute**; seconds survive only where explicitly asked for, or as a
remainder parked on the longest flexible phase.

**Compound durations** (`"2min30sec"` = 150s) work because the unit regex ends in a negative
lookahead `(?![a-z])` rather than a word boundary `\b`. After `2min` the next character is the
digit `3` — no word boundary exists there, so `\b` silently failed to match and `"2min30sec"`
was read as `30`. Two *separate* mentions (`"5 min then 8 min"`) are rejected as ambiguous
instead of summed.

**"to" vs "by" — the preposition decides, not the verb.** Both of these carry the verb *reduce*,
and they mean completely different things:

| Ask | Reading | Result on a 4:00 warm-up |
|---|---|---|
| "reduce the warm-up **to** 30 seconds" | ABSOLUTE target | `0:30` |
| "reduce the warm-up **by** 30 seconds" | relative delta | `3:30` |

Reading the *verb* alone made both relative, which is how "to 30 seconds" produced a 7-minute
phase (§11, round 3). `"to"` must be followed by a **digit** to count — so "add 30 seconds **to**
the warm-up" stays relative, because there the "to" points at a phase.

**Scope is resolved BEFORE the number.** A relative ask has to be measured against *whatever it
targets*: `"reduce it by 30 seconds"` means the phase's own length when it's aimed at a phase, and
the interview's total when it's aimed at the interview. Computing the number first — against the
total — and only then discovering it was a phase ask is precisely the bug in §11 round 3.

**Adding TIME is not adding a PHASE.** `"add 2 minutes to the warm-up"` and `"add a coding
phase"` share a verb and nothing else. `is_time_change_ask` requires a time verb *directly
followed by a number* **and** a parseable duration — so "add 2 **questions** about caching" (a
content ask) is not mistaken for either.

### Family 2 — Which phase did they mean?

`resolve_phase_ref(text, phases) → (confident_id, score, ranked_guesses)`

Everything is compared **separator-insensitively** via `_squash` — `"wrapup"`, `"wrap up"`,
`"Wrap-Up"` and `"wrap_up"` all collapse to `wrapup`, so every human spelling lands on the same
phase. Scores form a ladder:

| Score | Evidence | Example |
|---|---|---|
| 1.00 | The phase's name is in the text, any spelling | `"the wrapup phase"` → `wrap_up` |
| 0.95 | Every word of the name is present, any order | `"questions technical"` |
| 0.85+ | Close typo on the name | `"warumup"` → `warm_up` |
| 0.50+ | *Some* words of the name | `"technical round"` |
| 0.45+ | Overlaps the phase's **intent**, not its name | `"system architecture"` → `technical_questions` |

Two gates decide whether that's *acted on*:

- **`CONFIDENT_REF = 0.9`** — below this it's a guess, so the system asks and names the guess.
- **Near-tie (< 0.06 apart) → no match.** "The technical one" against two technical phases must
  ask, not coin-flip.

Id evidence always beats intent evidence, because the id is what the TA was shown.

**This is not used to resolve an ADD.** Those go to the Resolver (§2), because scoring says
`"coding discussion"` *is* `coding_round` with 0.95 confidence and it is emphatically not. String
similarity answers "did they misspell a name I know?"; only meaning answers "which of these two
similar-sounding phases did they want?"

### Family 3 — Structure ops

`plan_structure_op` reads the instruction; `apply_structure_op` performs the list edit.

| Verb | Handled | Result |
|---|---|---|
| remove / delete / drop / get rid of | ✅ code | phase dropped; refuses if it's the last one left |
| move X before/after Y, swap X and Y, put X first/last | ✅ code | list reordered |
| add **back** a phase that was removed | ✅ code | **restored from the catalog** (§3.5) with its real body |
| add a **code discussion** | ✅ code | restored from its real definition; **confirms first** if there's no coding round to review |
| add / create a **new** phase | ✅ code + 1 content call | created, after asking **duration + what it covers** (§3.6) |
| add a phase on the **blacklist** | ❌ refused, with that entry's own reason | e.g. a coding round → "use the coding-question picker at the top" |
| add **time** ("add 2 minutes to the warm-up") | ✅ code | not a structure op at all — it's arithmetic (§3.1) |

Split phrasal verbs are handled: `"put the wrap-up back"` is an *add*, not a reorder, because
`"put back"` never appears contiguously. A positional word flips it back to reorder
(`"put warm-up back first"`).

Reorder parsing uses `find_phase_refs`, which returns phases **with their positions** in the
sentence — because "move X before Y" is positional, so a set of names isn't enough.

A refusal never swallows the rest of its clause: `StructureOp.extra_refusal` lets one clause
apply what it can and report what it can't.

### Family 3.5 — The phase catalog (how "add it back" works)

Removing a phase deletes it from the working YAML, so *"add the wrap-up back"* has nothing to
restore from — inventing a replacement would be exactly the "generate a new phase" the editor
refuses. So the orchestrator builds a **catalog** of phases it could legitimately put back
(`_phase_catalog` in `cadence_service.py`), from three sources:

| Priority | Source | Why |
|---|---|---|
| 1 | The **working plan** at the start of the turn | Makes remove-then-re-add work inside ONE message |
| 2 | The **saved plan** for this interview (DB `cadence_yaml`) | Has the generated/custom phases, with this interview's real durations |
| 3 | The **built-in default cadence** (`engine/brain/cadence/default.yaml`) | The standard `warm_up → wrap_up` set |

The catalog's **order** comes from the saved plan first (it's the real running order), with the
built-in only filling gaps — otherwise a restored `wrap_up` would land ahead of generated phases
just because it sits earlier in the built-in file.

Restoring is therefore never generating: a phase comes back with the exact `intent`,
`question_mode`, prompts and duration it actually had. A name in **no** catalog is refused, and a
**coding** phase is never restorable (it needs question ids → the picker).

Where it lands: `"before/after X"` wins if said, then `first`/`last`, otherwise the catalog's own
position — which is why `wrap_up` goes back at the end and `warm_up` at the front.

### Family 3.6 — Creating a NEW phase

A phase in no catalog *can* be created. It's the one path that needs the TA to answer
something first, because two things genuinely cannot be inferred:

| Needed | Why it can't be defaulted | Who supplies it |
|---|---|---|
| **duration** | It changes the interview's length, and the schema demands `total == Σ phases` exactly | parsed in **code** from the TA's words |
| **coverage** | Authoring questions from a bare name is guessing at what the TA wanted | the **Resolver**'s `covers` |

Both must be present before anything is written. If either is missing the turn ends in a
**question** and the plan is untouched.

#### The conversation

The full two-turn trace — every agent, every decision, with the real generated YAML — is in
**§2, "All four agents on one request"**. It isn't repeated here; what follows is the rules that
trace is an instance of.

#### If only one of the two arrives

The question **narrows** rather than repeating itself, so the TA is never asked for
something they already said:

| They said | Response |
|---|---|
| "add a system design round" | "How long should it be, and what should it cover?" |
| "…for 10 minutes" | "It's set to 10:00 — what should it cover?" |
| "…covering scalability trade-offs" | "How long should it be?" |
| "…for 10 minutes covering scalability trade-offs" | created immediately, one turn |

#### Why no duration chips

They existed and were removed. A `[10 minutes]` button answers only *half* the
question, and clicking it would create the phase with its content authored from
nothing but its name — which is exactly the "don't invent the TA's intent" line this
editor holds everywhere else. A free-text answer can carry both halves at once; a chip
structurally cannot.

#### Why the clarification must carry the original verb

Router prompt **rule 6** requires the clause text on a clarification turn to be
`"<original instruction> — <answer>"`, not the answer alone. This is not cosmetic.

Everything downstream keys off the **verb**: `detect_structure_verb` decides the clause
is a structure ask, and `_resolve_add_asks` only calls the Resolver for clauses whose
verb is `add`. The answer by itself — *"10 minutes, focus on scalability trade-offs"* —
contains no `"add"`, because a human answering "how long and what should it cover?" has
no reason to repeat it. Without rule 6 the second turn was read as an ambiguous
**duration** ask against an existing phase, and the reply was *"did you mean the
technical-questions phase?"* — the create flow was unreachable in two turns and only
worked if the TA happened to say everything in one message. Pinned by
`test_regression_a_clarification_keeps_the_ORIGINAL_verb_in_its_text`.

#### How it's built, and what each layer contributes

```
code   derive the id from the TA's own words   "add a system design round" → system_design
       (uniquified against existing ids, checked against ^[a-z][a-z0-9_]*$)
code   insert a schema-valid SKELETON          before wrap_up, unless they said
                                               before/after/first/last
code   PIN the duration                        so the content pass can't move it
LLM    author `intent` + `generic_prompts`     the Modifying agent, from `covers`
code   re-pin + recompute the total            the interview grows by the new phase
```

The skeleton is valid on its own, so a failed content call leaves a **usable phase**
rather than a plan that won't load. A new phase never lands after the goodbye.

### Family 3.7 — The blacklist (phases the editor won't create)

`config/phase_blacklist.json`. Data, not code — adding a blocked phase is one entry, with no
matching logic to touch:

```json
{ "blocked": [ {
    "id": "coding_round",
    "intent": "A live coding exercise where the candidate writes and runs real code…",
    "reason": "I can't add a coding phase from here — it needs coding questions attached.
               Use the coding-question picker at the top of this page…" } ] }
```

`intent` is what the **Resolver** matches on; `reason` is shown to the TA verbatim, so it's written
as a pointer to what they *should* do rather than a bare refusal.

**There are deliberately no aliases.** Keyword lists were tried and rejected: they cannot separate
`coding round` from `coding discussion`, and every new entry would need its own spellings
maintained by hand. A phase is also un-addable when we hold a definition for it but it's a coding
**exercise** (it needs question ids) — that gets the same reason, so the wording lives in one place.

### Family 4 — Conversation

`ask_which_phase` builds a **grounded** question. When there's a plausible guess it names it:

> "There's no phase by that name in this plan. For *"make the system architecture round more
> engaging"*, did you mean the technical-questions phase?"

With no guess at all it lists the real phases:

> "Which phase should the 3:00 you asked for apply to? This plan has: warm-up,
> resume-deep-dive, technical-questions, wrap-up."

A bare "which phase?" makes the TA do mapping the system already did.

---

## 4. The full pipeline

### 4a. A turn with no "add" — the Resolver is skipped

```
                 TA types:  "remove the wrapup phase and make whole interview
                             15min and warumup 2min30sec"
                                          │
                                          ▼
                          POST /api/cadence/revise {yaml, feedback, clarifications}
                                          │
    ┌─────────────────────────────────────▼─────────────────────────────────────┐
    │ 0. EXTRACT — parse YAML, then normalise it through CadencePlan            │
    │    (so "before" and "after" have the SAME shape; see §5)                  │
    └─────────────────────────────────────┬─────────────────────────────────────┘
                                          ▼
    ┌───────────────────────────────────────────────────────────────────────────┐
    │ 1. ROUTER              ◀── 1 LLM call, phase metadata only ───────────────│
    │    Splits into 3 clauses. Code then TAKES BACK any clause it wrongly      │
    │    marked ambiguous/impossible that has a duration or structure verb.     │
    └─────────────────────────────────────┬─────────────────────────────────────┘
                                          ▼
    ┌───────────────────────────────────────────────────────────────────────────┐
    │ 1b. RESOLVER   ◀── 1 LLM call, ONLY if a clause says "add" ───────────────│
    │    Which phase does each add mean? Matched on phase INTENTS. Skipped       │
    │    entirely here — no clause adds anything.                               │
    └─────────────────────────────────────┬─────────────────────────────────────┘
                                          ▼
    ┌───────────────────────────────────────────────────────────────────────────┐
    │ 2. DETERMINISTIC PRE-PASS  ◀── ZERO LLM calls ────────────────────────────│
    │                                                                           │
    │  structure → "remove the wrapup phase"  → wrap_up dropped      ✓ applied  │
    │  duration  → "make whole interview 15min" → total_target = 900  ✓ applied  │
    │  duration  → "warumup 2min30sec"  (typo!) → warm_up pinned 150  ✓ applied  │
    │              (scope FIRST, then the number — a relative ask is measured    │
    │               against the phase it targets, not the interview)             │
    │  leftover  → (none this turn)             → nothing for the LLM           │
    └─────────────────────────────────────┬─────────────────────────────────────┘
                                          ▼
    ┌───────────────────────────────────────────────────────────────────────────┐
    │ 3. MODIFYING  ◀── 1 LLM call PER content phase, concurrent ───────────────│
    │    Skipped entirely when there are no content asks. Pinned durations are  │
    │    re-asserted afterwards so a content edit can't move a number.          │
    └─────────────────────────────────────┬─────────────────────────────────────┘
                                          ▼
    ┌───────────────────────────────────────────────────────────────────────────┐
    │ 4. VALIDATING  ◀── 1 batched LLM call, on its OWN model ──────────────────│
    │    numbers re-pinned (code) · total reconciled (code)                     │
    │    removal verified by set membership (code) · content judged (LLM)       │
    │    → authors one line per instruction                                     │
    └─────────────────────────────────────┬─────────────────────────────────────┘
                                          │  not satisfied? ──► retry step 3
                                          │  (max VALIDATE_RETRY_MAX = 2, then a note)
                                          ▼
    ┌───────────────────────────────────────────────────────────────────────────┐
    │ 5. PATCH — CadencePlan.model_validate → dump → YAML                       │
    │    Invalid? ship NOTHING, keep the old cadence, explain why.              │
    └─────────────────────────────────────┬─────────────────────────────────────┘
                                          ▼
        {ok, yaml, changed, applied[], questions[], out_of_scope[], notes[]}
```

### 4b. A turn that ADDS a phase — every branch the Resolver can pick

§2 walks ONE add end to end. This is the complete branch map: the Resolver's answer is what
selects between four very differently-worded outcomes, all produced by the same code path.

```
   TA: "add a coding phase" / "add a coding discussion" / "add the wrap-up back"
       / "add a system design round"
                         │
                         ▼
    ┌──────────────────────────────────────────────────────────────────────────┐
    │ 1. ROUTER                                                                │
    │    kind="phase", phase_id="" — rule 2: an ADD always leaves the id EMPTY, │
    │    because the router is not the thing that decides which phase it is.    │
    └────────────────────────────────┬─────────────────────────────────────────┘
                                     ▼
    ┌──────────────────────────────────────────────────────────────────────────┐
    │ 1b. RESOLVER  ◀── the ONE language question: which phase is this?         │
    │                                                                          │
    │   sees three candidate sets, each phase as {id, intent}:                  │
    │     in_plan    what this interview already has                            │
    │     available  what we hold a real definition for   (catalog, §3.5)       │
    │     blocked    what must not be created from chat   (§3.7)                │
    │                                                                          │
    │   returns  phase_ids[]  ·  new_name  ·  covers                            │
    └────────────────────────────────┬─────────────────────────────────────────┘
                                     ▼
         ┌───────────────┬───────────────┬───────────────┬──────────────────┐
         ▼               ▼               ▼               ▼                  ▼
    in_plan id      available id     blocked id      phase_ids: []      (nothing)
         │               │               │               │                  │
   covers empty?    restore the      refuse with     duration AND        FAIL CLOSED
    │         │      real body       that entry's     coverage known?     → ask which
    │         │      verbatim        own `reason`      │          │          phase they
    ▼         ▼          │               │            ▼          ▼          meant
 "already   CONTENT      │               │        CREATE      ASK for
  in this    edit  ──────┼───────────────┼────────  it        what's
  plan"    (→ modifier)  │               │                    missing
                         ▼               ▼
                  "Added the X       "…use the coding-question
                   phase back"        picker at the top…"
                                     
    (a clause naming SEVERAL phases answers for each: the wrap-up is restored AND
     the coding half comes back refused — never one at the expense of the other)
                                     │
                                     ▼
    ┌──────────────────────────────────────────────────────────────────────────┐
    │ 2. DETERMINISTIC PRE-PASS — everything from here is code:                 │
    │    which branch · the id · the insert position · the arithmetic · the     │
    │    total. The model chose the phase; it does not touch a number.          │
    └──────────────────────────────────────────────────────────────────────────┘
```

Two properties worth stating plainly, because they're what make this safe:

- **The Resolver only ever picks a phase.** It never writes a duration, a prompt, or a
  phase body. So the worst a bad resolution can do is target the wrong phase — which
  the applied line always names, so the TA sees it.
- **No resolution ⇒ no edit.** A dead provider, a malformed reply, or an invented phase
  id all land on the same branch: ask. There is no path from "unsure" to "wrote
  something".

### How many LLM calls, really

| Kind of request | Router | Resolver | Modifying | Validating | Total |
|---|---|---|---|---|---|
| "remove the wrap-up phase" | 1 | – | 0 | 0 | **1** |
| "make the whole interview 15 minutes" | 1 | – | 0 | 0 | **1** |
| "reduce the warm-up to 30 seconds" | 1 | – | 0 | 0 | **1** |
| The 3-part example above | 1 | – | 0 | 0 | **1** |
| "add a coding phase" *(refused)* | 1 | 1 | 0 | 0 | **2** |
| "add the wrap-up back" | 1 | 1 | 0 | 0 | **2** |
| "add a system design round, 10 min, covering X" | 1 | 1 | 1 | 1 | **4** |
| "make the warm-up friendlier" | 1 | – | 1 | 1 | **3** |
| "make warm-up friendlier and wrap-up briefer" | 1 | – | 2 (concurrent) | 1 (batched) | **4** |

Structure and arithmetic cost **nothing** — that's the point. The Resolver runs **only** when a
clause says "add", so an ordinary edit costs exactly what it did before. And the Validating call is
batched: two content edits still cost one check, not two.

---

## 5. Cadence extraction and patching

### Extraction (in)

```
YAML text ──► yaml.safe_load ──► CadencePlan.model_validate ──► .model_dump()
                                                                      │
                                                       this normalised dict is "BEFORE"
```

Normalising the input through the same schema as the output is **load-bearing, not tidiness**.
Pydantic injects defaults (`question_pool: []`, `coding_question_ids: []`,
`adaptive_difficulty: false`). Comparing raw YAML against a pydantic dump made **every phase
compare unequal**, so a one-phase edit was reported as four phases changed. Belt and braces:
`phase_content_view` also treats an absent key and an empty value as identical.

If the input can't be normalised the turn still proceeds — the diff just uses the raw shape.

### Patching (out)

Patching is layered, and each layer is narrower than the last:

```
1. structure   phases removed / reordered / restored   (code)
2. durations   explicit per-phase values written     (code)
3. content     per-phase LLM results merged by id    (code merge, LLM content)
4. re-pin      explicit durations re-asserted        (code — content can't move a number)
5. reconcile   total hit exactly, honouring pins     (code)
6. validate    CadencePlan.model_validate            (schema — all or nothing)
7. serialise   yaml.safe_dump
```

**Step 5 is the interesting one.** "Make warm-up 2:30 **and** the whole interview 15 minutes"
looks contradictory but isn't. The pin (2:30) is more specific than the total, so it holds, and
the phases the TA said *nothing* about absorb the difference:

```
asked:   warm_up = 2:30 (pinned) · whole interview = 15:00
result:  warm_up 150  +  resume_deep_dive 390  +  technical_questions 360  =  900 ✓
```

Both asks satisfied. When the pins *alone* already exceed the target, the more specific ask
(the pins) wins and the TA is told plainly — rather than one ask being dropped silently.

> Note the result isn't all whole minutes. Correct: the 2:30 pin leaves a 30-second remainder,
> which parks on the longest flexible phase. Whole minutes hold only when nothing forces a
> fraction.

---

## 6. What it handles — worked examples

### Applied with no LLM editing at all

| Request | Result |
|---|---|
| "remove the wrapup phase" | `Removed the wrap-up phase` |
| "delete technical questions" | `Removed the technical-questions phase` |
| "move wrap up before technical questions" | `Moved wrap-up before technical-questions` |
| "swap warm up and wrap up" | `Swapped warm-up and wrap-up` |
| "put warmup first" | `Moved warm-up to the first position` |
| "make whole interview 15min" | `Set the whole interview to 15:00` |
| "warumup 2min30sec" *(typo)* | `Set the warm-up phase to 2:30` |
| "make it 10 minutes total" | `Set the whole interview to 10:00` |
| "reduce the warm-up **to** 30 seconds" | `Set the warm-up phase to 0:30` — an absolute target |
| "reduce the warm-up **by** 30 seconds" *(from 4:00)* | `Set the warm-up phase to 3:30` — a delta off **that phase** |
| "add 2 minutes to the warm-up" | `Set the warm-up phase to 6:00` — time, not a phase |
| "add 2 minutes to the whole interview" | `Set the whole interview to …` — delta off the total |
| "can you add wrapup phase" *(after removing it)* | `Added the wrap-up phase back` — restored, not invented |
| "put the wrap-up back" | same; split phrasal verb handled |
| "add the wrap up phase and make it 3 minutes" | `Added the wrap-up phase back, set to 3:00` |
| "add a coding discussion" *(with a coding round present)* | `Added the code-discussion phase`, placed **after** the round it reviews |

### Applied with a content call

| Request | Result |
|---|---|
| "make the warm up friendlier" | `Warm-up now opens with a friendlier greeting.` |
| "ask about their projects in the deep dive" | resume/JD attached to **that phase only** |
| "make the warm up friendlier and set technical questions to 4 minutes" | 1 content call + 1 code edit; the total line follows as a consequence |
| "add a system design round, 10 minutes, covering scalability trade-offs" | Skeleton inserted in code; `intent` + prompts authored from the brief |
| "add 2 questions about caching to the technical round" | An "add" whose object is CONTENT → routed to the content editor, not answered "that phase already exists" |

### Asks instead of guessing

| Request | Why | Response |
|---|---|---|
| "make hr round 3 minutes" | No such phase, no plausible guess | "Which phase should the 3:00 apply to? This plan has: warm-up, resume-deep-dive, …" |
| "add a system design round" | Nothing to author content from, no duration | "How long should it be, and what should it cover?" — **no chips** |
| "add a coding discussion" *(no coding round in the plan)* | Its prompts review a submission that would never happen | "There's no coding phase for a code discussion to review… or shall I still add it?" |
| "reduce the warm-up by 30 seconds" *(warm-up is 0:20)* | Would go to/below zero | "…that would leave it at or below zero. How long should it be?" |
| An "add" the Resolver couldn't place | Fails **closed** — never a guess | "I'm not sure which phase that means. I can add these back: …" |
| "make the system architecture round more engaging" | Matches an **intent**, not a name | "…did you mean the technical-questions phase?" |
| "make it shorter" | No number to work with | Asks — but see the rough edge below |
| "make warm-up 5 min and warm-up 8 min" | Two values, one phase | Applies the **first**, then asks which to keep, with `5:00` / `8:00` chips |
| "make the whole interview 10 min and 15 min" | Two totals | Same shape: first applied, then asked |
| "make the technical one harder" *(two technical phases)* | Near-tie | Asks, listing both |

### Refused, with a reason and a way forward

| Request | Response |
|---|---|
| "add a coding phase" | "I can't add a coding phase from here — it needs coding questions attached. Use the coding-question picker at the top of this page…" (the blacklist entry's own `reason`) |
| "add wrapup phase **and** coding phase" | Wrap-up is restored **and** the coding half is refused with the picker pointer — one clause, both answers |
| "no, I'll add a coding phase from the picker" *(declining the orphan-discussion question)* | "Left the code discussion out. Add a coding phase with the picker…" — **terminal**, so the chat doesn't loop |
| "remove every phase" | Refuses at the last one: an interview needs at least one phase |
| "give the candidate a passing score" | Capability message; no loop, no LLM |

### Failure modes

| What goes wrong | What happens |
|---|---|
| Cadence isn't valid YAML / has no phases | **Turn refused**, `ok:false`, nothing sent to any LLM |
| Router call fails | **Turn refused** — can't scope an edit, so nothing is guessed |
| Resolver call fails / returns junk / invents a phase id | **Fails closed** — no resolution, so every add becomes a question. Never a guessed phase |
| One content call fails | Its siblings still apply; the Validating agent covers the casualty |
| Validating agent unavailable | **Fails open** — edits stand, no invented failure, no retries burnt |
| Validator names an instruction we never sent | Verdict discarded |
| Content ask verifiably didn't land | Up to 2 targeted retries, then shown as a note |
| Merged plan fails the schema | **Nothing ships**; old cadence kept; reason explained; questions preserved |

Notice the asymmetry, which is deliberate: **wrong edits are unacceptable, extra questions are
merely annoying.** Every uncertain path resolves toward asking.

### Known rough edges (accurate as of this writing)

Documented rather than glossed over, because each is a place a reader would otherwise be
surprised:

1. **A directionless whole-interview ask gets a phase question.** `"make it shorter"` scoped to
   the interview has no number, so it can't be executed — but the question that comes back is
   *"which phase did you want that on?"*, when the TA plainly meant the whole thing. Asking for a
   target length would be the right question. Harmless (nothing is edited) but confusing.
2. **A same-scope duration conflict applies the first value before asking.** The plan is left
   holding `5:00` while the chat asks whether you meant `5:00` or `8:00`. Answering settles it,
   and nothing is lost — but the intermediate state is a value the TA never confirmed.
3. **An intent-only match applies rather than confirming.** `resolve_phase_ref` deliberately
   refuses to act below `CONFIDENT_REF`, but when the *Router* names the phase itself (which it
   can, since it sees intents) the pre-pass takes that id. The mitigation is that the applied line
   always names the phase, so a mis-target is visible and correctable. Forcing a confirmation
   whenever the text doesn't literally name a phase would re-ask on the clarification-answer path
   (`"make it friendlier"` names nothing) and loop.
4. **A restored phase keeps its catalog duration.** With a token that's the saved plan's real
   value; without one it falls back to the built-in default, so a 30-second `wrap_up` can land in
   a 60-minute plan. Scaling it would mean inventing a number, so it isn't done — the TA can set
   it in the same breath (`"add the wrap up phase and make it 3 minutes"`).
5. **The Resolver costs one LLM call on every "add", including ones it will refuse.** "add a
   coding phase" is two calls (Router + Resolver) where it used to be one. The alternative was
   keyword matching, which is the thing that broke — the call is the price of getting
   `coding discussion` vs `coding round` right.
6. **An "add …" that adds content is detected from `covers` being non-empty.** "add 2 questions
   about caching to the technical round" is routed to the content editor because the Resolver
   reported a topic. A vaguer one — "add more prompts to the warm-up" — reports no topic, so it
   still comes back as "that phase is already in this plan; did you mean to change it?". Nothing
   wrong is written, but the TA has to rephrase.

---

## 7. The conversation loop

The server is **stateless**. The browser replays answered questions each turn, so one Router
call handles a new request, an answer, or both.

```
Turn 1   TA: "make the hr round 3 minutes"
         ← question: "Which phase? [warm-up] [resume-deep-dive] [technical-questions]"

Turn 2   TA clicks [warm-up]  →  clarifications: [{text: "...", answer: "warm-up"}]
         ← ✓ Set the warm-up phase to 3:00
```

The create flow is the same machinery with a free-text answer instead of a chip:

```
Turn 1   TA: "add a system design round"
         ← "I can add a system-design phase. How long should it be, and what
            should it cover?"                                     options: []

Turn 2   TA types: "10 minutes, focus on scalability trade-offs and caching"
         →  clarifications: [{clause_id: "c1",
                              text:   "add a system design round",   ← the ORIGINAL
                              answer: "10 minutes, focus on scalability…"}]
         ← ✓ Added a new system-design phase, set to 10:00
           ✓ Interview is now 25:00 (was 15:00)
```

**The `text` field is what makes turn 2 work.** The server is stateless, so the only
memory of "this was an ADD" is the clause text the Router reconstructs from the
original + the answer (§3.6, rule 6). Send the answer alone and the verb is gone with
it.

- **Unbounded rounds.** Every round needs a human reply, so it can't run away.
- **Resolved work never waits.** One message can apply an edit, ask a question, and decline an
  ask — all in the same response.
- **A question never blocks the plan.** While one clause waits on an answer the others
  are already applied — and the pending one leaves the cadence untouched, so an
  unanswered question is never a half-written phase.

UI: `ReviseVerifyChat` in `ui/web/src/pages/CadenceReview.tsx` — grows with the conversation
then scrolls internally, auto-scroll that doesn't yank a TA who has scrolled up to read, and
option chips that are pre-filled replies tagged with their `clause_id` so the right question
gets answered when several are open.

---

## 8. Setup-cost tracking (why these calls don't pollute interview costs)

Editing a cadence happens **before** the interview. Its LLM costs must not land in the live
interview's cost table, or "what did this interview cost to run?" becomes unanswerable.

Every cadence-editor call goes through `setup_cost_tracker.trace_call`, which traces to Langfuse
(under `session_id = token`), computes cost from the pricing YAML, and writes to a **separate
sidecar**, `sessions/{token}/setup_cost_summary.json`. It deliberately does *not* call
`apply_llm_result`, which would leak into the live `cost_tracker`.

Purpose tags rolling up into "Cost for setting up interview":

| Purpose | Fired when |
|---|---|
| `generate_cadence` | Plan generated from JD/requirements (worker job, at schedule time) |
| `revise_cadence_with_ai` | **This editor** — every Router / Modifying / Validating call |
| `generate_eval_plugin` | Evaluation plugin plan generated |
| `generate_rubric` | Legacy v1 rubric generated |

The admin UI shows two tables: **"Cost by model"** (live interview only) and **"Cost for setting
up interview"** (this sidecar).

---

## 9. Where everything lives

| File | Role |
|---|---|
| `app/cadence_service.py` | Orchestration only: `revise_cadence_conversational`, `_build_cadence_llm(role=)`, `_phase_catalog`, `VALIDATE_RETRY_MAX = 2` |
| `app/cadence_agents/router_agent.py` | Agent 1 + `capability_message` + `detect_duration_conflicts` |
| `app/cadence_agents/phase_resolver_agent.py` | Agent 1b — which phase an "add" means, matched on intents |
| `app/cadence_agents/phase_tools.py` | **All deterministic tools** + `plan_deterministic` |
| `app/cadence_agents/modifying_agent.py` | Agent 2 + `merge_results` |
| `app/cadence_agents/validating_agent.py` | Agent 3 + `phase_content_view` + `_name_phase` |
| `app/cadence_agents/base.py` | `CadenceLLM.complete_json` — traced, JSON-parsed, retries without `response_format` for providers that reject it |
| `config/prompts.yaml` | `cadence_router`, `cadence_phase_resolver`, `cadence_phase_revise`, `cadence_validator` |
| `config/phase_blacklist.json` | Phases the editor won't create, each with an `intent` + a `reason` (§3.7) |
| `ui/web/src/pages/CadenceReview.tsx` | `ReviseVerifyChat` |
| `tests/test_cadence_agents.py` | 141 tests, no network |
| `engine/brain/cadence/schema.py` | `CadencePlan` / `PhaseDef` — the final gate |

**Env vars:** `CADENCE_VALIDATOR_MODEL` (+ optional `CADENCE_VALIDATOR_PROVIDER`) run the
Validating agent on a different model. Unset, validation is still an independent call on the
same model.

---

## 10. Testing

`tests/test_cadence_agents.py` — **141 tests, no network** (`openai.AsyncOpenAI` is faked and
responses are dispatched by which system prompt was used). Coverage:

- **Tools as pure functions** — duration parsing (compound, ambiguous, **to-vs-by**, time-vs-phase),
  **relative asks measured against the right base**, whole-minute rescaling, pin reconciliation,
  phase-ref resolution across spellings and typos, near-tie refusal, structure ops, conflict
  detection, and catalog restore (right body, right position, any spelling, split phrasal verbs,
  coding never restorable).
- **Resolver** — each of its four answers routed correctly, a multi-id clause answered for BOTH
  halves, an invented phase id dropped, a malformed reply and a dead provider both failing closed.
- **Creating a phase** — asks for duration AND coverage (and **no** chips), narrows when only one
  arrives, id derived from the TA's words with collisions suffixed, skeleton schema-valid, never
  lands after wrap-up, brief carried to the modifier.
- **The two-turn create flow** — a clarification's clause text must keep the ORIGINAL verb, or
  the second turn stops being an "add" at all and the feature is unreachable (§11 round 4).
- **Router** — splitting, ambiguity, capability messages, hint-blanking, clarification replay,
  the code overrides that take clauses back, call failure.
- **Modifying** — per-phase scoping, context gating, concurrency, silent-drop rejection, one
  failure not discarding siblings.
- **Validating** — deterministic repairs, pin reconciliation, unsatisfiable-total note, removal
  verification, content shortfall, hallucinated-verdict discard, fail-open.
- **Orchestrator** — mixed-outcome turns, pure-clarification turns, answer resolution, retry cap.
- **Refusal proofs** — on router failure, every call is asserted to have used the Router's
  metadata-only prompt (so the cadence provably went nowhere); on an unreadable cadence, **no**
  LLM call happens at all.
- **Regression tests** pinning every defect in §11, so none can silently return.

**Live checks** (these need a real model — the fakes can't tell you the prompt still works):

- The Resolver's whole point: `add a coding phase` → the picker refusal, `add a coding discussion`
  → the discussion phase added. Both, in the same run.
- `add the wrap up and a coding phase` → wrap-up added **and** coding refused.
- `covers` stays **empty** for `add a system design round` and is filled for `…covering caching`.

Manual checks worth running after any change here — one per round in §11:

1. `remove the wrapup phase and make whole interview 15min and warumup 2min30sec`
   → exactly three lines, and a 900-second plan.
2. `can you add wrapup phase and coding phase` (with the wrap-up already removed)
   → wrap-up restored at the END, plus the coding-picker refusal.
3. `reduce the time of warm up to 30 seconds` on a multi-minute interview
   → `Set the warm-up phase to 0:30`, and the interview gets SHORTER.
4. `add a system design round` and then, **as a separate message**, `10 minutes, focus on
   scalability trade-offs` → the phase is created with real prompts and the total grows.
   Doing it in ONE message must also work — but only the two-message form catches round 4.

---

## 11. Why it's built this way — the defects that shaped it

Four live sessions produced every design decision above. Worth reading before changing anything,
because most of these look like over-engineering until you know what they're preventing.

### Round 1 — one request, four independent bugs

> **"remove the wrapup phase and make whole interview 15min and warumup 2min30sec"**
> — all three asks silently failed, and all four phases were reported as edited.

**1. The removal was dropped.** Phase matching tried `"wrap_up"` → `"wrap up"` (with a space),
which isn't in `"the wrapup phase"`. A difflib fallback scored the *whole instruction* against
the id → 0.65, under a 0.7 gate. No match → the clause fell through to the content editor, which
can only rewrite questions — so it reported `wrap_up: questions updated` for a phase the TA
asked to **delete**.
→ *Fixed by:* separator-insensitive `_squash` matching, and structure ops that never reach a
content editor.

**2. The explicit "15min" became a question.** The Router asked "…exactly 15 minutes (900
seconds)?" — it had already *parsed* 900 and asked anyway. So no total was ever applied; the
total was just recomputed as the sum of phases (4:00 → 6:00).
→ *Fixed by:* code takes the clause back whenever an explicit duration is present. A number the
TA already gave is never a reason to ask.

**3. All four phases reported "questions updated".** The change summary compared **raw YAML**
against a **pydantic dump**; injected defaults made every phase compare unequal. The TA couldn't
tell which of their asks had landed.
→ *Fixed by:* normalising the input through the same schema, and reporting one line per
*instruction* instead of a plan-wide diff.

**4. The validator barely validated.** It only LLM-checked *content* clauses — structure and
duration never reached it — and it shared the editing model's handle, grading its own homework.
→ *Fixed by:* verifying all three clause kinds (each by the appropriate means) on its own model
handle, and having it author the TA-facing lines.

### Round 2 — "I dropped the wrap-up, now add it back"

Removal worked; re-adding hit *"I can't create a brand-new phase"*.

**5. There was nothing to restore from.** Removing a phase deletes it from the working YAML, so
honouring the ask would have meant inventing an `intent`, prompts and a duration — the exact thing
the editor refuses to do. Refusing was *correct* given the information available; the missing piece
was a record of what the phase had been.
→ *Fixed by:* the phase catalog (§3.5). Restoring from a real definition is not generating.

Three more silent losses surfaced while testing that fix — same family as rounds 1 and 2, each one
work quietly discarded:

**6. `"put the wrap-up back"` read as a REORDER.** `"put back"` is in the add-verb list, but the
phase name sits between the two words so it never matched contiguously — leaving `"put"` to match
the reorder list.
→ *Fixed by:* recognising split phrasal verbs (`back` + put/bring/get/restore), unless a positional
word means order really was meant (`"put warm-up back first"`).

**7. `"add … and make it 3 minutes"` dropped the number.** `" add "` is a *relative*-duration
marker, so the structure verb made the whole clause parse as relative and return nothing.
→ *Fixed by:* stripping structure verbs before the duration parse, and letting one clause carry
both a structure op and a duration.

**8. `"add wrapup phase and coding phase"` lost the wrap-up entirely.** The coding check refused
the whole clause. This was *measured, not assumed*: the router merges that sentence into one clause
in 5/5 runs, so it wasn't flakiness to wait out.
→ *Fixed by:* testing for coding only when no restorable phase is named, plus `extra_refusal` so
one clause can both apply and refuse.

### Round 3 — "reduce the warm-up to 30 seconds" made the interview LONGER

Three consecutive asks in one live session, every one wrong, and the arithmetic gives the bug away:

| Ask | Interview total | warm-up became | which is |
|---|---|---|---|
| "reduce the time of phase by 30 seconds" | 4:30 (270s) | **4:00** (240s) | 270 − 30 |
| "reduce the time of warm up to 30 seconds" | 7:30 (450s) | **7:00** (420s) | 450 − 30 |
| "reduce the time of warmup to 30 seconds only" | 10:00 (600s) | **9:30** (570s) | 600 − 30 |

Every result is `interview_total − 30`, written onto the **phase**. Two independent bugs stacked:

**9. The delta was measured against the wrong thing.** The number was resolved ONCE at the top of
the duration step — `resolve_total_target(text, current_total)`, where `current_total` is the
*interview's* total — and only *afterwards* did the code work out that the clause targeted a phase.
So a phase-scoped relative ask got the interview's arithmetic. Asking to *shorten* a phase made the
interview *grow*, because the phase was being set to nearly the whole interview's length.
→ *Fixed by:* resolving **scope before the number**. A relative ask is measured against what it
targets — the phase's own length, or the total when it's a whole-interview ask.

**10. "reduce … TO 30 seconds" was read as a delta.** `" reduce"` is in
`RELATIVE_DURATION_MARKERS`, so any clause containing it was relative — regardless of the
preposition. But *to* names a target and *by* names a delta; the verb only supplies direction.
→ *Fixed by:* an explicit `to <digit>` outranking the direction verb. `"to"` must be followed by a
number, so "add 30 seconds **to** the warm-up" stays relative.

A third, found while fixing those two and **pre-existing on `HEAD`** — worse there, and never
reported because the wording made it look like a different feature's problem:

**11. Adding TIME was treated as adding a PHASE.** `detect_structure_verb` saw `"add"` and handed
the clause to the structure step before the duration step ever ran. On `HEAD`:
`"add 2 minutes to the warm up"` → *"The warm-up phase is already in this plan — did you mean to
change it instead?"*, and `"add 2 minutes to the whole interview"` → *"I can't create a brand-new
phase from here."* Neither added any time.
→ *Fixed by:* `is_time_change_ask` — a time verb **directly followed by a number** plus a parseable
duration means arithmetic, not membership. "add 2 **questions** about caching" is neither, so it
still reaches the content editor.

### Round 4 — the two-turn create flow was unreachable

Found by tracing the create flow end to end *as a conversation* rather than as a single
message — which is how a TA will actually use it.

**12. A clarification answer arrived without its verb.** Asking `"add a system design
round"` correctly produced *"How long should it be, and what should it cover?"*. Then
answering *"10 minutes, focus on scalability trade-offs and caching"* — in a separate
message, as the question invites — produced *"There's no phase by that name in this
plan. For the 10:00 you asked for, did you mean the technical-questions phase?"*

The plan never changed, so nothing was corrupted; the feature was simply **unreachable**
unless the TA happened to put everything in one message. Root cause: the Router's rule 5
says a clause's `text` must be the admin's own words for that instruction, so on the
clarification turn it emitted the *answer alone*. But the answer contains no `"add"` —
and `detect_structure_verb` / `_resolve_add_asks` both key off that verb, so turn 2 was
classified as a duration ask on an existing phase. The Resolver never ran.
→ *Fixed by:* Router prompt **rule 6** — a clarification's text is
`"<original> — <answer>"`. Verified 3/3 live runs create the phase (600s, total
15:00 → 25:00) and pinned by a regression test on the consequence, not the prompt text.

*Also observed while verifying, and worth recording as a positive:* one run hit a
transient provider error inside the Resolver. The turn came back as a question and the
plan was untouched — the fail-closed path behaving exactly as designed, on a failure
nobody staged.

### The lesson encoded throughout

Most of these eleven are the same mistake in a different costume: a model trusted with something
code could do exactly, or given the last word on something it got wrong — and in the worst cases
the result was *silent*, so the TA believed an edit had landed when it hadn't.

Rounds 2 and 3 added the mirror image, and it's the one worth remembering because it cuts against
the instinct the earlier rounds build: **code overreaching into work that needs meaning.** Two
cases, both of which shipped confidently wrong answers rather than asking:

- `"coding discussion"` scoring 0.95 against `coding_round` — string similarity cannot separate two
  phases that share a vocabulary. That needed the model (§2).
- `"reduce X to 30s"` vs `"reduce X by 30s"` — the rule was written around the *verb* when the
  *preposition* is what carries the meaning.

So the rule is sharper than "prefer code". It's: **give each decision to whichever of the two can
actually settle it, and when neither is sure, ask.** Corollaries, each bought with a bug:

- A clause must never be consumed by the one part of it you understood. Handle half a request and
  you must say so about the other half (`extra_refusal`, `phase_ids` as a list).
- Resolve the **scope** of a number before computing it. A delta is meaningless until you know what
  it's a delta *of*.
- A question that can be answered "no" needs a terminal branch, or the chat loops forever.
- **Test the multi-turn shape, not just the one-shot.** Round 4 passed every single-message
  test and was still unusable, because a stateless server's only memory of a request is
  what it reconstructs into the clause text. If a feature asks a question, the answer path
  is a separate feature and needs its own test.
