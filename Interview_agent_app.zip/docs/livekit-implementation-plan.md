# LiveKit / WebRTC Implementation Plan — execution checklist

**Status:** ready to start · Step A needs nothing from you · **Date:** 2026-09-17
**Owner:** (you) · **Branch:** TBD (start clean — see §0)

**Read with:** [media-server-scaling-plan.md](media-server-scaling-plan.md) (the locked Phase 1–4
design + the client/brain change tables) and
[system-architecture-and-scaling.md](system-architecture-and-scaling.md) (why we're doing this —
§4.1 transport, §2.3 the "Reconnecting" root cause).

This doc is the **execution procedure**: what you must supply, what I build, in what order, and
how we prove each step didn't break anything. It deliberately does not re-explain the design.

---

## 1. What this changes, in one picture

```mermaid
flowchart LR
    subgraph NOW["TODAY — one WebSocket over TCP"]
        B1["Browser"] -->|"mic PCM16 256 kbps<br/>+ TTS PCM + JSON control<br/>+ base64 JPEG — ALL in one pipe"| G1["Gateway WS proxy"]
        G1 --> S1["Session shard<br/>WebBroadcaster"]
        B1 -.->|"MediaRecorder 3s chunks<br/>(no retry, loses last ~3s)"| R1[("Blob")]
    end

    subgraph NEXT["AFTER — media on WebRTC, control stays on WS"]
        B2["Browser"] -->|"mic track (Opus ~24 kbps)"| LK["LiveKit SFU"]
        LK -->|"decoded PCM"| S2["Session shard<br/>LiveKitAudioSource/Sink"]
        B2 -->|"thin control WS:<br/>captions, phases, coding"| S2
        LK --> EG["Egress — server-side<br/>recording"] --> R2[("Blob")]
    end
```

**Fixes:** TCP head-of-line stalls · "Reconnecting" storms · ~10× less candidate uplink ·
refresh-resume via ICE restart · server-side recording (kills the 3 s loss + the no-retry hole +
makes cross-session audio bleed impossible by construction).

**Does NOT fix** (separate, cheaper work — do these first):

| Symptom | Actual cause | Where |
|---|---|---|
| AI talks over the candidate | 1.5 s silence timer, no semantic endpointing | P1 |
| Refresh restarts the interview | checkpoint feature written but **never deployed** | P1 |
| Coding submit takes 15–20 s | one missing dispatch rule in the turn policy | P0 |

---

## 2. WHAT I NEED FROM YOU

### 2.1 Credentials — one set, three values

Create a **LiveKit Cloud** project at [cloud.livekit.io](https://cloud.livekit.io) (free tier is
enough; no card needed for audio-only testing). It yields:

| Value | Shape | Sensitive? |
|---|---|---|
| `LIVEKIT_URL` | `wss://<project>.livekit.cloud` | no |
| `LIVEKIT_API_KEY` | short public id | no |
| `LIVEKIT_API_SECRET` | long secret string | **YES** |

**Where they go — two places:**

1. **Local `.env`** — confirmed there are no `LIVEKIT*` vars there today. Put all three in
   yourself (same as `Azure_Acesstoken`); I read from `.env`, never from chat.
2. **ACA secrets** — on **both** the gateway and session tiers:
   - secret `livekit-api-secret` = `<LIVEKIT_API_SECRET>` (like `storage-conn`)
   - env `LIVEKIT_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET` (secretRef)
   - env `MEDIA_TRANSPORT=ws`  ← **leave on `ws`**; this is the rollback lever

> **Not needed for Step A.** The token endpoint returns `503` when LiveKit is unconfigured, so
> Step A builds, tests and ships with none of the above.

### 2.2 Three decisions

| # | Decision | Recommendation | Why it matters |
|---|---|---|---|
| 1 | Cloud or self-host? | **Cloud first** | Same SDK both ways → moving to self-hosted later is config, not a rewrite. Self-host only pays off past ~150 concurrent. |
| 2 | Which region? | Match your Azure region | Keeps the extra network hop short. |
| 3 | **Compliance** — see below | needs a real answer | Can block Step B. |

### 2.3 The compliance gate (the one that can actually stop this)

With LiveKit **Cloud**, candidate audio **leaves Azure** and transits a third party. Today every
byte stays inside your tenancy.

Candidate voice is arguably biometric-adjacent and hiring is a regulated context, so this needs a
genuine review — not a shrug. **If the review fails, the answer is not "skip WebRTC"** — it is
"self-host LiveKit on AKS from day one": the same agent code, a much larger first step.

Get this answered **before Step B**, not after.

### 2.4 What only you can do

| Task | Why I can't |
|---|---|
| Create the LiveKit project | needs your account |
| Deploy to ACA + flip `MEDIA_TRANSPORT` | your PowerShell/ADO flow; I build + verify locally |
| **The parity gate (Step D)** | it is a *listening* test — "does barge-in feel right", "is the farewell cut off". Both prior regressions (v10, v20) passed every automated check. |

### 2.5 What I do NOT need

- No Azure credentials — I can't deploy regardless.
- No SDK work from you: `livekit==1.1.8` is already in the image (came in for AEC). I add
  `livekit-api` for token minting + Egress.

---

## 3. Why this is a weeks-not-quarters job

The brain is already transport-agnostic. Director, VAD, STT, TTS, turn-taking and the latency
orchestrator touch audio through exactly **seven methods**
([engine/brain/contracts/audio.py](../engine/brain/contracts/audio.py)):

```python
class AudioSource(Protocol):   # frames() · start() · stop()
class AudioSink(Protocol):     # play() · flush() · stop() · bytes_buffered() + sample_rate_hz
```

So the migration is: **write two classes satisfying those seven methods, swap two lines.**
Swap point — [deploy/azure_app.py:1637](../deploy/azure_app.py#L1637):

```python
source = BrowserMicAudioSource(broadcaster.mic_queue)
sink   = BrowserSpeakerAudioSink(broadcaster)
```

Everything below it — including `InterviewSession(...)` at :1738 — is untouched.

**The control WebSocket does not go away.** It keeps carrying captions, phase changes and coding
events; it simply stops carrying audio and video. Candidate ends up with two connections.

---

## 4. Step sequence

Each step is independently shippable. The flag (`MEDIA_TRANSPORT=ws|livekit`) means both paths
coexist in one binary and rollback is an env var, not a redeploy.

| Step | What | Needs creds? | Status |
|---|---|---|---|
| **0** | Land the in-flight branch; create a clean one | no | ☐ |
| **A** | `/livekit-token` endpoint + `livekit-api` dep | **no** | ☐ |
| **B** | `LiveKitAudioSource` / `LiveKitAudioSink` behind the flag | yes | ☐ |
| **C** | Client publishes/subscribes behind the same flag | yes | ☐ |
| **D** | **Parity gate** — go/no-go | yes | ☐ |
| ~~E~~ | ~~Observer audio → room track~~ — **dropped: the observer feature was removed** | — | n/a |
| **F** | Egress recording → Blob; delete MediaRecorder | yes | ☐ |
| **G** | Delete the raw-PCM WS branch + tag mux | yes | ☐ |

### Step 0 — clean slate (do first)

The working tree currently carries **18 modified files** from the question-pool work. Land or
stash that before starting — you do not want a transport migration tangled with unrelated changes
when something needs bisecting.

### Step A — token endpoint (zero behavior change)

`GET /livekit-token` mints a room JWT. Room name = the interview token (which is already the
session id, the Langfuse session id, the blob folder and the events.jsonl key — one value ties
everything together). Candidate authenticated by session token.
Returns `503` when LiveKit is unconfigured, so a default deploy is unaffected.

Also: `MEDIA_TRANSPORT` + `livekit_url` added to `/session-info`, and `livekit-api>=1.0` to
requirements.

*This was written once and reverted at your request — it is a re-apply, and it is dead code until
the flag flips.*

### Step B — brain side, behind the flag

```python
if os.getenv("MEDIA_TRANSPORT") == "livekit":
    room   = await connect_room(token)
    source = LiveKitAudioSource(room, f"candidate-{token}")
    sink   = LiveKitAudioSink(room)
else:
    source = BrowserMicAudioSource(broadcaster.mic_queue)   # unchanged
    sink   = BrowserSpeakerAudioSink(broadcaster)
```

The source subscribes to the candidate's track and re-chunks to exactly 640-byte frames; the sink
publishes the AI's PCM. **Request 16 kHz from the SDK** rather than resampling by hand — hand-rolled
resampling is precisely where the current audio-rate drift bug came from.

### Step C — client side, same flag

Hundreds of lines of worklet plumbing, PCM queueing and AudioBuffer scheduling collapse to:

```ts
await room.connect(livekitUrl, jwt);
await room.localParticipant.setMicrophoneEnabled(true);
room.on(RoomEvent.TrackSubscribed, (t) => t.kind === Track.Kind.Audio && t.attach());
```

Keep the worklet **for mic metering only**. Mute becomes `micTrack.mute()`.

### Steps E–G

**E.** ~~Observer audio becomes a room track.~~ Dropped — the live observer was removed, so a
room has exactly two participants: the candidate and the AI agent.
**F.** Server-side **Egress** records straight to Blob → deletes browser `MediaRecorder`, the
≤3 s loss, the no-retry upload hole, and the audio-bleed class of bug.
**G.** Only after the flag has been default-on and validated: delete the raw-PCM WS branch.

---

## 5. The three hard parts

### 5.1 Playout ack — HIGHEST RISK

Today the browser sends `audio_playback_finished` per utterance; the server uses it to ground the
silence timer **and** the wrap-up teardown. A WebRTC track is continuous — no per-utterance
boundary exists.

**Approach:** on the `audio_end` control message, wait for the remote track's playout to catch up,
then send **the byte-identical same message**. That keeps
[audio_sink.py](../engine/orchestrator/web/audio_sink.py) and all wrap-up logic untouched.

> This caused the v10 and v20 "farewell cut off" regressions. It gets its own dedicated parity
> test, and it is the single thing most likely to go wrong.

### 5.2 Sample rate 48k ↔ 16k

WebRTC is 48 kHz; the brain is 16 kHz end-to-end. The Python SDK accepts a target rate on
`AudioStream`/`AudioSource` — **confirm against the pinned SDK version**, do not assume. Verify
against the existing drift diagnostics in
[audio_source.py:157,177-184](../engine/orchestrator/web/audio_source.py#L157).

### 5.3 Barge-in latency

The jitter buffer may add a short tail. Stop publishing on the VAD `speech_start` we already
receive, and mute the track. **Verify perceived cutoff in a live test**, not from logs.

---

## 6. Parity gate (Step D) — do not skip

Run a real candidate session on the flag, and check:

- [ ] VAD / STT timing unchanged — compare `interview_stt_partial_lag_ms` p50/p95 before vs after
- [ ] Barge-in *feels* the same — interrupt a question mid-sentence and listen
- [ ] **Wrap-up farewell is not cut off** ← regressed twice before
- [ ] Captions stay in sync with audio
- [ ] Recording still complete end-to-end
- [ ] Reconnect: kill Wi-Fi 5 s, confirm it resumes without a full reconnect

Then **canary one real interview** before any wider rollout.

---

## 7. Rollback

`MEDIA_TRANSPORT=livekit → ws` — an environment variable change, no redeploy. Keep it that way
until Step G deletes the old path.

---

## 8. Cost

Audio-only testing ≈ **$0** on the free tier. Opus ≈ 16–32 kbps per track → roughly 50–150 MB
relayed per 30-minute interview; dozens of tests stay inside the free allowance.

Cost becomes real only with video tracks + Egress later. **Re-check
[livekit.io/pricing](https://livekit.io/pricing) at that point** rather than trusting a number
quoted here.

---

## 9. Sequencing note

This is the **third** priority, not the first. From
[system-architecture-and-scaling.md §6](system-architecture-and-scaling.md):

1. **P0** — config one-liners (preroll, coding-submit rule, registry TTL, keepalive): days.
2. **P1** — deploy the checkpoint feature, un-gate STT, semantic endpointing: weeks.
3. **P2** — this.

P0/P1 fix the symptoms candidates actually complained about. LiveKit is the structural fix
underneath — necessary, but it does not make the AI stop talking over people.

---

## 10. Status log

Keep this current as steps land.

| Date | Step | Note |
|---|---|---|
| 2026-09-17 | — | Plan written. Verified: `livekit==1.1.8` present, `livekit-api` absent, no `LIVEKIT*` in `.env`, Workstream-A token code confirmed reverted. |
