"""Builds docs/rbac-authentication-reference.pdf.

Companion to docs/question-pool-maker-checker-reference.pdf. That PDF keeps the
pool workflow. This one keeps sign-in, roles, the menu, and the Access screens.

Run (needs reportlab + the Arial/Consolas TTFs; FONT_DIR defaults to C:\\Windows\\Fonts):
  podman run --rm -v "${PWD}:/w" -v "C:\\Windows\\Fonts:/fonts:ro" -w /w -e FONT_DIR=/fonts \
    python:3.12-slim sh -c "pip install -q reportlab && python docs/_build_rbac_reference_pdf.py"
"""
from __future__ import annotations

import os

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate, CondPageBreak, Frame, NextPageTemplate, PageBreak, PageTemplate, Paragraph,
    Spacer, Table, TableStyle,
)
from reportlab.platypus.tableofcontents import TableOfContents

OUT = os.environ.get("OUT") or os.path.join(os.path.dirname(__file__),
                                             "rbac-authentication-reference.pdf")
FONT_DIR = os.environ.get("FONT_DIR", r"C:\Windows\Fonts")

for name, file in [("Arial", "arial.ttf"), ("Arial-Bold", "arialbd.ttf"),
                   ("Arial-Italic", "ariali.ttf"), ("Arial-BoldItalic", "arialbi.ttf"),
                   ("Mono", "consola.ttf"), ("Mono-Bold", "consolab.ttf")]:
    pdfmetrics.registerFont(TTFont(name, os.path.join(FONT_DIR, file)))
pdfmetrics.registerFontFamily("Arial", normal="Arial", bold="Arial-Bold",
                              italic="Arial-Italic", boldItalic="Arial-BoldItalic")
pdfmetrics.registerFontFamily("Mono", normal="Mono", bold="Mono-Bold",
                              italic="Mono", boldItalic="Mono-Bold")

INK = colors.HexColor("#1d2433")
MUTED = colors.HexColor("#5b6475")
ACCENT = colors.HexColor("#2f5fb3")
ACCENT_SOFT = colors.HexColor("#e8eef9")
LINE = colors.HexColor("#c9d1de")
ROW_ALT = colors.HexColor("#f5f7fb")

BASE = dict(fontName="Arial", textColor=INK)
S = {
    "title": ParagraphStyle("title", fontName="Arial-Bold", fontSize=26, leading=31, textColor=INK),
    "subtitle": ParagraphStyle("subtitle", fontName="Arial", fontSize=13, leading=18, textColor=MUTED),
    "h1": ParagraphStyle("h1", fontName="Arial-Bold", fontSize=17, leading=22, textColor=ACCENT,
                         spaceBefore=6, spaceAfter=8),
    "h2": ParagraphStyle("h2", fontName="Arial-Bold", fontSize=12.5, leading=16, textColor=INK,
                         spaceBefore=10, spaceAfter=5),
    "body": ParagraphStyle("body", fontSize=9.5, leading=13.5, spaceAfter=5, **BASE),
    "bullet": ParagraphStyle("bullet", fontSize=9.5, leading=13.5, leftIndent=14, bulletIndent=4,
                             spaceAfter=2, **BASE),
    "cell": ParagraphStyle("cell", fontSize=8, leading=10.3, **BASE),
    "cellb": ParagraphStyle("cellb", fontName="Arial-Bold", fontSize=8, leading=10.3, textColor=INK),
    "head": ParagraphStyle("head", fontName="Arial-Bold", fontSize=8, leading=10.3, textColor=colors.white),
    "code": ParagraphStyle("code", fontName="Mono", fontSize=7.8, leading=10, textColor=INK,
                           backColor=colors.HexColor("#f2f4f8"), borderPadding=(5, 6, 5, 6),
                           leftIndent=4, rightIndent=4, spaceBefore=3, spaceAfter=8),
    "callout": ParagraphStyle("callout", fontSize=9.3, leading=13.3, textColor=INK, fontName="Arial",
                              backColor=ACCENT_SOFT, borderPadding=(7, 8, 7, 8), leftIndent=4,
                              rightIndent=4, spaceBefore=8, spaceAfter=10),
    "caption": ParagraphStyle("caption", fontSize=8, leading=10.5, textColor=MUTED,
                              fontName="Arial-Italic", alignment=TA_CENTER, spaceAfter=8),
    "toc1": ParagraphStyle("toc1", fontName="Arial-Bold", fontSize=10, leading=15, textColor=INK),
    "toc2": ParagraphStyle("toc2", fontName="Arial", fontSize=9, leading=12.5, leftIndent=14, textColor=MUTED),
}


def C(text: str) -> str:
    return f'<font name="Mono" size="8.3">{text}</font>'


def P(text: str, style: str = "body") -> Paragraph:
    return Paragraph(text, S[style])


def bullets(items: list[str]) -> list[Paragraph]:
    return [Paragraph(t, S["bullet"], bulletText="•") for t in items]


def code(text: str) -> Paragraph:
    esc = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return Paragraph(esc.replace("\n", "<br/>").replace("  ", "&nbsp;&nbsp;"), S["code"])


def table(rows: list[list], widths: list[float], bold_first: bool = False, head: bool = True) -> Table:
    data = []
    for r, row in enumerate(rows):
        out = []
        for c, cell in enumerate(row):
            if isinstance(cell, str):
                style = "head" if (head and r == 0) else ("cellb" if (bold_first and c == 0) else "cell")
                cell = Paragraph(cell, S[style])
            out.append(cell)
        data.append(out)
    t = Table(data, colWidths=widths, repeatRows=1 if head else 0)
    cmds = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.4, LINE),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    if head:
        cmds.append(("BACKGROUND", (0, 0), (-1, 0), ACCENT))
    for r in range(1 if head else 0, len(data)):
        if r % 2 == 0:
            cmds.append(("BACKGROUND", (0, r), (-1, r), ROW_ALT))
    t.setStyle(TableStyle(cmds))
    return t


PAGE_W, PAGE_H = A4
MARGIN = 18 * mm
TEXT_W = PAGE_W - 2 * MARGIN


class Doc(BaseDocTemplate):
    def __init__(self, path: str):
        super().__init__(path, pagesize=A4, title="Authentication and RBAC Reference",
                         author="Interview Agent team", leftMargin=MARGIN, rightMargin=MARGIN,
                         topMargin=MARGIN, bottomMargin=MARGIN)
        frame = Frame(MARGIN, MARGIN, TEXT_W, PAGE_H - 2 * MARGIN, id="p")
        self.addPageTemplates([
            PageTemplate("cover", [frame], onPage=lambda c, d: None, pagesize=A4),
            PageTemplate("portrait", [frame], onPage=self._chrome, pagesize=A4),
        ])

    def _chrome(self, canvas, doc):
        w, h = canvas._pagesize
        canvas.saveState()
        canvas.setStrokeColor(LINE)
        canvas.setLineWidth(0.5)
        canvas.line(MARGIN, h - MARGIN + 6, w - MARGIN, h - MARGIN + 6)
        canvas.setFont("Arial", 7.5)
        canvas.setFillColor(MUTED)
        canvas.drawString(MARGIN, h - MARGIN + 9, "Authentication & RBAC — technical reference")
        canvas.drawRightString(w - MARGIN, MARGIN - 12, f"Page {doc.page}")
        canvas.drawString(MARGIN, MARGIN - 12, "Interview Agent · 22 Oct 2026")
        canvas.restoreState()

    def afterFlowable(self, flowable):
        if isinstance(flowable, Paragraph) and flowable.style.name in ("h1", "h2"):
            level = 0 if flowable.style.name == "h1" else 1
            key = f"h{self.seq.nextf('heading')}"
            self.canv.bookmarkPage(key)
            self.notify("TOCEntry", (level, flowable.getPlainText(), self.page, key))


def H1(t: str) -> list:
    return [CondPageBreak(55 * mm), P(t, "h1")]


def H2(t: str) -> Paragraph:
    return P(t, "h2")


def build() -> list:
    s: list = []
    W = TEXT_W

    s += [Spacer(1, 48 * mm), P("Authentication &amp; RBAC", "title"), Spacer(1, 6),
          P("Technical reference — sign-in, roles, the menu, the Access screens, "
            "the API and the tables.", "subtitle"), Spacer(1, 14 * mm)]
    s.append(table([
        ["Item", "Value"],
        ["Repository", "Interview_agent_app"],
        ["Companion", "question-pool-maker-checker-reference.pdf — the pool workflow, ledger and pool routes"],
        ["Working notes", "docs/rbac-authentication-current.md — the decisions this reference follows"],
        ["Audience", "Developers, reviewers and admins who change who can do what"],
        ["Status", "Access screens built and checked locally. Microsoft sign-in is not built. Not deployed to Azure."],
    ], [36 * mm, W - 36 * mm], bold_first=True))
    s.append(Spacer(1, 8))
    s.append(P("The pool PDF already explains the permissions a pool route checks. This PDF does not repeat the "
               "approval ledger, the draft/published split, or the per-question review. Change a pool rule there. "
               "Change who may sign in, or what a role opens, here.", "callout"))
    s += [NextPageTemplate("portrait"), PageBreak()]

    toc = TableOfContents()
    toc.levelStyles = [S["toc1"], S["toc2"]]
    s += [Paragraph("Contents", ParagraphStyle("toch", parent=S["h1"])), toc, PageBreak()]

    s += H1("1. The three questions")
    s.append(P("Every request is answered in this order. The browser uses the answers to draw the menu. The server "
               "repeats the permission check. The server's answer is the one that counts."))
    s.append(table([
        ["Question", "Answer today", "Where"],
        ["Are you signed in?", "A valid admin_session cookie, 12 hours, httpOnly.", "app/auth.py"],
        ["Who are you?", "app_users.id inside that cookie. The shared admin login has no id.", "issue_cookie, current_user_id"],
        ["What may you do?", "The permissions of your roles, each scoped to a team or to every team.", "app/rbac.py"],
        ["May this pool go live?", "Not this document. Maker-checker answers that.", "The pool reference"],
    ], [38 * mm, 78 * mm, W - 116 * mm], bold_first=True))
    s.append(Spacer(1, 6))
    s.append(P("A grant is one row: this person holds this role on this team. A role is a bundle of permissions. "
               f"Team {C('*')} means every team. Hiding a button is convenience. A hidden button does not stop a direct call."))

    s += H1("2. How someone signs in")
    s.append(P("There are two doors. They set the same cookie. They do not grant the same rights. Microsoft Entra is "
               "not connected. When it is, it will answer who the person is, and these tables will keep answering "
               "what they may do."))
    s.append(H2("2.1 The three ways in"))
    s.append(table([
        ["Way in", "Request", "Password", "Cookie carries", "Menu"],
        ["Shared admin", "POST /api/login with ADMIN_USERNAME (default admin)",
         "ADMIN_PASSWORD_HASH. If that is empty, centific123.",
         "The username only. No app_users id.",
         "Interview pages. Not Access. Pool APIs refuse it."],
        ["Email of a seeded person", "POST /api/login with that email",
         "The same admin password. Nothing is stored on the person.",
         "The email and the app_users id.",
         "That person's role. Only while DEV_LOGIN_ENABLED is on."],
        ["Click a development account", "POST /api/dev/login with the email",
         "None.",
         "The email and the app_users id.",
         "That person's role. Only while DEV_LOGIN_ENABLED is on."],
    ], [32 * mm, 36 * mm, 34 * mm, 32 * mm, W - 134 * mm], bold_first=True))
    s.append(Spacer(1, 6))
    s += bullets([
        f"{C('GET /api/dev/accounts')} and {C('POST /api/dev/login')} return 404 unless {C('DEV_LOGIN_ENABLED')} is "
        f"{C('1')}, {C('true')} or {C('yes')}. The click list is then absent.",
        "The click list has no password. Do not leave the switch on for a URL other people can open. Local testing is what it is for.",
        "Typing the email still needs the admin password, and it uses the same switch. With the switch off, an email is refused.",
        f"The cookie is signed with {C('ADMIN_SECRET_KEY')}. It expires after 12 hours.",
    ])
    s.append(H2("2.2 What the browser does next"))
    s.append(P(f"{C('GET /api/me/permissions')} is what the shell reads. {C('GET /api/me')} only says whether a cookie "
               "is valid. The decision on the console is:"))
    s.append(table([
        ["Signed-in state", "Screen"],
        ["Cookie missing or expired", "Sign in."],
        ["A real person with is_active false", "A card: this account is turned off. Sign out. No menu."],
        ["A real person with no roles", "A card: your account does not have access yet. Ask a platform administrator. Sign out. No menu."],
        ["The shared admin login (legacy)", "The interview pages. Access stays hidden, because that login is not a person in the role tables."],
        ["A person with one or more roles", "The menu items their permissions allow."],
    ], [62 * mm, W - 62 * mm], bold_first=True))

    s += H1("3. Permissions, roles and teams")
    s.append(H2("3.1 The eleven permissions"))
    s.append(P(f"A closed list in {C('app/rbac.py')}. {C('validate_permission')} rejects any other name, so a typo "
               "cannot create a permission that grants nothing. The Access role grid reads {C('PERMISSION_LABELS')}, "
               "so the screen and the list cannot drift."))
    s.append(table([
        ["Permission", "Plain label", "What it opens"],
        ["pools.view", "See pools", "Question pools."],
        ["pools.edit", "Edit drafts", "New pool, and Edit on a pool of that team."],
        ["pools.submit", "Submit for review", "Submit and withdraw. Enforced on the pool routes."],
        ["pools.approve", "Review pools", "Approvals and the per-question review."],
        ["pools.publish", "Force-publish", "Publish without review, and delete a published pool."],
        ["interviews.view", "See interviews", "Dashboard, Shortlist, and a session page. The page is hidden. The interview API still only checks the cookie."],
        ["interviews.schedule", "Schedule interviews", "New interview and the cadence page. Same limit: the page is hidden, the API is not yet checked."],
        ["interviews.cancel", "Cancel interviews", "Defined for HR. No separate menu item."],
        ["admin.users", "Manage people", "Access → People."],
        ["admin.teams", "Manage teams", "Access → Teams, including that team's approval chain."],
        ["admin.permissions", "Edit the role grid", "Access → Roles."],
    ], [40 * mm, 36 * mm, W - 76 * mm], bold_first=True))
    s.append(H2("3.2 The four roles"))
    s.append(P("These are the only roles. A candidate, an observer, and a hiring manager are not roles in this table. "
               "One person can hold two grants. An author on one team may be the checker on another. The same person "
               "is not both author and checker on the same team."))
    s.append(table([
        ["Role", "Key", "Scope", "Permissions", "Menu"],
        ["Platform Admin", "admin", "Every team only", "All eleven", "Shortlist, Dashboard, New interview, Question pools, Access"],
        ["Question Author", "pool_author", "One team. Not *", "pools.view, pools.edit, pools.submit", "Question pools, with New pool"],
        ["Question Checker", "pool_checker", "One team, or *", "pools.view, pools.approve", "Question pools, with Approvals. No New pool."],
        ["HR / Recruiter", "hr", "Every team only", "The three interview permissions. No pools.", "Shortlist, Dashboard, New interview"],
    ], [30 * mm, 26 * mm, 28 * mm, 42 * mm, W - 126 * mm], bold_first=True))
    s.append(Spacer(1, 6))
    s.append(P(f"<b>Teams.</b> {C('*')} is a real row, named Every team. It cannot be renamed, switched off, or deleted. "
               f"{C('backend')} and {C('qa')} are examples for testing. Replace them before a production release. "
               "A team that still has people, pools, or chain steps cannot be deleted. Switch it off instead. "
               "A new grant cannot be added on a team that is off. Removing a grant from that team still works."))
    s.append(H2("3.3 The seeded test accounts"))
    s.append(P("Created at startup by the seed, and only if the row is missing. They are test accounts, not the "
               "production user list. There is no password column on them."))
    s.append(table([
        ["Email", "Grant"],
        ["ayush.kothiyal@centific.com", "Platform Admin · every team"],
        ["sathwik.badda@centific.com", "Platform Admin · every team"],
        ["md.azhar@centific.com", "Question Author · Backend Engineering"],
        ["puchalapalli.harika@centific.com", "Question Checker · Backend Engineering"],
        ["sai.kambampati@centific.com", "Question Checker · every team"],
        ["hasini.gandhe@centific.com", "Question Author · Quality Assurance"],
        ["javali.manda@centific.com", "HR / Recruiter · every team"],
    ], [78 * mm, W - 78 * mm], bold_first=True))

    s += H1("4. What each person sees")
    s.append(P(f"One list, {C('ui/web/src/lib/workspace.ts')}, feeds the sidebar, the Welcome cards, and the page "
               "guard. A new workspace page is one entry there. Child pages (a pool review, one role's interviews) "
               "name the same permission on their own route, so typing the address is checked the same way as the menu."))
    s.append(table([
        ["Page", "Needs"],
        ["Welcome cards", "The same permissions as the sidebar. New interview is sidebar only."],
        ["Shortlist, a role, Dashboard, a session", "interviews.view"],
        ["Set up a role's interviews, New interview, cadence", "interviews.schedule"],
        ["Question pools", "pools.view"],
        ["New pool", "pools.edit"],
        ["Approvals and review", "pools.approve"],
        ["Access", "Any of admin.users, admin.teams, admin.permissions. Each tab still checks its own permission."],
        ["Observer live view", "Not guarded. An author following an observer link is not blocked."],
        ["A page the role cannot open", "\"You don't have access to this page\", inside the menu they do have."],
    ], [70 * mm, W - 70 * mm], bold_first=True))
    s.append(Spacer(1, 6))
    s.append(P("A person who is an author on one team and a checker on another sees one Question pools item, both "
               "New pool and Approvals, and two lines under their name. Edit and Approve on a card still follow that pool's team."))

    s += H1("5. The Access screens")
    s.append(P("Signed in as a Platform Admin, open Access. There is no button to type in a new person. A person "
               "appears when the seed creates them, or later when Microsoft sign-in creates the row. The admin's job "
               "is to give that person a role."))
    s.append(H2("5.1 People"))
    s.append(P("Search, and filter All / No role / Active / Inactive. Select a person. Turn them on or off. Add a "
               "role and a team. Remove one grant. The team dropdown only offers combinations that role allows: "
               "admin and HR only Every team, an author never Every team, a checker either. The server refuses the "
               "other combinations anyway."))
    s.append(H2("5.2 Teams"))
    s.append(P("Create from a name. The key is optional and is taken from the name when left blank. Rename, switch "
               "off, or delete. Under the selected team, edit the approval chain: name, role, order. Save replaces "
               "that team's steps. An empty chain on a normal team means use the Every team chain. The Every team "
               "chain itself cannot be emptied. A pool already waiting keeps the steps it was submitted with."))
    s.append(H2("5.3 Roles"))
    s.append(P("A grid. Rows are the eleven permissions, grouped as Pools, Interviews and Access. Columns are the "
               "four roles. One tick changes that role for everyone who holds it. The three Access permissions stay "
               "ticked on Platform Admin and cannot be cleared, or nobody could assign roles afterwards."))

    s += H1("6. Access API")
    s.append(P(f"Prefix {C('/api/access')}, mounted in {C('app/main.py')} behind the signed-in cookie, and each route "
               f"behind {C('require(...)')}. The service raises {C('AccessError')}. The route turns that into the HTTP status."))
    s.append(table([
        ["Method and path", "Permission", "Does"],
        ["GET /people", "admin.users", "People, plus the roles and teams the grant form offers."],
        ["PATCH /people/{id}", "admin.users", "Body {is_active}. Turn a person on or off."],
        ["POST /people/{id}/grants", "admin.users", "Body {role, team}. The signed-in admin is stored as granted_by."],
        ["DELETE /people/{id}/grants?role=&team=", "admin.users", "Take one grant away."],
        ["GET /teams", "admin.teams", "Teams, with counts of people, pools and chain steps."],
        ["POST /teams", "admin.teams", "Body {name, key}. A blank key is filled from the name."],
        ["PATCH /teams/{key}", "admin.teams", "Body {name, is_active}. The key never changes."],
        ["DELETE /teams/{key}", "admin.teams", "Delete a team nothing still uses."],
        ["GET /teams/{key}/chain", "admin.teams", "The steps, and the roles a step may name."],
        ["PUT /teams/{key}/chain", "admin.teams", "Body {steps: [{name, role}]}. Replaces the chain. Returns warnings."],
        ["GET /roles", "admin.permissions", "The grid."],
        ["PUT /roles/{role_key}", "admin.permissions", "Body {permission, enabled}. One cell."],
    ], [58 * mm, 32 * mm, W - 90 * mm], bold_first=True))
    s.append(H2("6.1 Refusals"))
    s.append(P("All of these live in app/access_service.py. The screen may hide the button. The service is what refuses."))
    s.append(table([
        ["HTTP", "When"],
        ["400", "Unknown permission. Team key that is not letters, numbers and underscores. A team with no name. A chain step naming a role that does not exist."],
        ["404", "No such person, role, team, or grant."],
        ["409", "Already holds that grant. Author and checker on the same team, including a checker grant on every team while they author any team. Admin or HR on one team. Author on every team. Last active Platform Admin turned off or un-granted. Access permissions cleared from the admin role. Every team renamed, switched off, or deleted. A team deleted while people, pools or steps still use it. The every-team chain emptied. A new grant on a team that is off."],
    ], [16 * mm, W - 16 * mm], bold_first=True))
    s.append(Spacer(1, 6))
    s.append(P("Saving a chain warns, and still saves, when nobody active can sign a step. The warning is returned "
               "with the chain. It is not an error."))

    s += H1("7. Tables")
    s.append(P("Six tables describe access. They are created with the rest of the schema. The three workflow tables "
               f"({C('pool_approvals')}, {C('pool_question_reviews')}, {C('audit_log')}) stay in the maker-checker "
               "reference. The pool itself is a file, not a table."))
    s.append(table([
        ["Table", "What one row is"],
        ["app_users", "A person. id is what the cookie carries. email is unique. entra_oid is empty until Microsoft sign-in. is_active false means no permissions. There is no password column."],
        ["app_teams", "A team. key is what the code uses (*, backend, qa). is_system is true only for *."],
        ["app_roles", "A role. key is admin, pool_author, pool_checker or hr. scope_kind is global or team."],
        ["app_user_roles", "One grant. Primary key (user_id, role_id, team_id). granted_by is the admin, or empty when the seed wrote it."],
        ["app_role_permissions", "One ticked cell. Primary key (role_id, permission). The seed writes these only when the table is empty, so an admin's later edit is not put back."],
        ["app_approval_steps", "One step of one team's chain. Unique (team_id, step_no). A team with no rows uses the * chain."],
    ], [40 * mm, W - 40 * mm], bold_first=True))
    s.append(Spacer(1, 6))
    s.append(P(f"{C('*')} is a real team row, not a null. A primary key cannot hold null, and a null would let the "
               "same grant be stored twice."))

    s += H1("8. Files")
    s.append(P("Each file has one job. The name column is the function, the value, or the screen piece. A leading "
               "underscore is a helper used only inside that file."))
    nw = [52 * mm, W - 52 * mm]

    s.append(H2("app/rbac.py — the permission check"))
    s.append(P("Knows nothing about pools or HTTP status codes, except the FastAPI guards at the bottom. Every other "
               "file asks this one whether a person may do something."))
    s.append(table([
        ["Name", "What it does"],
        ["POOL_ / INTERVIEW_ / ADMIN_PERMISSIONS", "The eleven names, in three groups."],
        ["ALL_PERMISSIONS", "Those three groups joined. The closed vocabulary."],
        ["PERMISSION_LABELS", "Group and plain label for each permission. The Roles tab renders this, so the screen cannot invent a column."],
        ["is_valid_permission / validate_permission", "Is this name in the list? validate_permission raises if it is not."],
        ["grants_for(user_id)", "One query. Returns {permission: {team keys}}. An inactive person, or an unknown id, returns nothing."],
        ["has_permission(user, perm, team)", "The yes or no. A team matches that team or *. No team means the person holds it anywhere. Fails closed."],
        ["ensure_permission(...)", "Same check, and raises 403 with a readable message. Pool routes use it after they have loaded the pool and know its team."],
        ["permitted_teams(user, perm)", "The teams a person holds that permission for. Used to tell them which teams they can pick."],
        ["current_user_id(request)", "The app_users.id from the cookie, or nothing."],
        ["require(perm)", "FastAPI dependency. 401 when nobody is signed in. 403 when they lack the permission."],
        ["require_any(perms)", "Passes if the person holds any one of the named permissions. The Access routes do not use it. Each tab calls require for its own permission. The page guard does the same \"any one of these\" check in the browser."],
        ["user_by_email(email)", "The person as a plain dict, or nothing. Email is matched in lower case."],
        ["describe_user(user_id)", "Identity, roles (with the team name) and permissions. This is the body of GET /api/me/permissions."],
        ["dev_login_enabled()", "True only when DEV_LOGIN_ENABLED is 1, true or yes."],
    ], nw, bold_first=True))

    s.append(H2("app/rbac_seed.py — the starting policy"))
    s.append(P("Data, not behaviour. It runs at startup and only adds rows that are missing. It never deletes a grant "
               "and it writes the permission grid only when that table is empty, so an admin's later edit is kept."))
    s.append(table([
        ["Name", "What it does"],
        ["TEAMS", "* (Every team, system), backend, qa. The last two are examples."],
        ["ROLES", "The four roles, each with scope_kind global or team."],
        ["ROLE_PERMISSIONS", "Which of the eleven permissions each role starts with."],
        ["DEFAULT_CHAIN", "One step on *, named Review, signed by a Question Checker."],
        ["SEED_USERS", "The seven test accounts and their grants. No passwords."],
        ["seed_rbac()", "Creates the missing teams, roles, grid rows, chain step and accounts. Returns how many of each it added."],
        ["_ids_by_key", "Finds or creates a team or role by its key, and returns {key: id} so the grants can link to them."],
        ["seed_users_summary()", "The active accounts the development chooser lists."],
        ["ensure_user(email, name)", "Finds or creates a person by email. Microsoft sign-in will call this. Nothing calls it from a screen today."],
    ], nw, bold_first=True))

    s.append(H2("app/access_service.py — the Access rules"))
    s.append(P("No HTTP. The routes call these functions. A refusal is an AccessError with a status. Section 6.1 is this file."))
    s.append(table([
        ["Name", "What it does"],
        ["AccessError", "message and HTTP status. The route turns it into the response."],
        ["list_people / set_active / add_grant / remove_grant", "The People tab. Each one returns the whole list again after the change."],
        ["list_teams / create_team / update_team / delete_team", "The Teams tab. create_team builds the key from the name when the caller leaves it blank."],
        ["get_chain / save_chain", "Read or replace one team's steps. save_chain warns when nobody active can sign a step, and still saves."],
        ["role_grid / set_permission", "The Roles tab. set_permission refuses an unknown permission and refuses to clear an Access permission from Platform Admin."],
        ["_same_team_conflict", "Author and checker on one team, including a checker grant on every team while the person authors any team."],
        ["_refuse_last_admin", "The last active Platform Admin cannot be switched off or lose that grant."],
        ["_role_team", "Loads the role and the team. A new grant requires an active team. Removing a grant does not."],
        ["_user / _team", "Load one person or one team, or 404."],
        ["_pool_counts / _team_counts", "How many pools, people and steps use a team. A storage miss shows zero pools rather than breaking the page."],
        ["_slug", "\"Backend Engineering\" becomes backend_engineering."],
        ["get_chain_in", "The chain payload. get_chain and save_chain both use it, so the two responses cannot drift."],
    ], nw, bold_first=True))

    s.append(H2("app/access_routes.py — the HTTP layer"))
    s.append(P(f"Prefix {C('/api/access')}. {C('_as_http')} catches AccessError and raises the HTTP status. It does not "
               "repeat a rule from the service. One function per row of section 6:"))
    s.append(table([
        ["Function", "Route"],
        ["people / person_active / person_grant / person_ungrant", "GET and PATCH /people, POST and DELETE /people/{id}/grants"],
        ["teams / team_create / team_update / team_delete", "GET, POST, PATCH, DELETE /teams"],
        ["team_chain / team_chain_save", "GET and PUT /teams/{key}/chain"],
        ["roles / role_cell", "GET /roles and PUT /roles/{role_key}"],
    ], nw, bold_first=True))

    s.append(H2("app/auth.py — the cookie"))
    s.append(table([
        ["Name", "What it does"],
        ["COOKIE_NAME / COOKIE_MAX_AGE_S", "admin_session, 12 hours."],
        ["verify_password", "Checks the typed password against ADMIN_PASSWORD_HASH. If no hash is set, the only accepted password is centific123."],
        ["issue_cookie(username, user_id)", "Signs the cookie. user_id is optional. The shared admin login omits it, so that session has no role."],
        ["get_current_user / get_current_user_id", "The username, and the app_users id if the cookie has one."],
        ["require_login", "401 when the cookie is missing. Used by pages that only ask whether anyone is signed in."],
    ], nw, bold_first=True))

    s.append(H2("app/main.py — where sign-in and Access are mounted"))
    s.append(P("This file is the whole admin app. Only these pieces belong to RBAC."))
    s.append(table([
        ["Name", "What it does"],
        ["_named_session_cookie", "Writes last_login_at and returns a cookie that carries the person's id."],
        ["_session_response", "The JSON body plus the Set-Cookie header. Both sign-in doors use it."],
        ["api_login", "The form. The admin username gets a cookie with no id. An email, while development sign-in is on, and with the admin password, gets that person's cookie."],
        ["api_dev_accounts / api_dev_login", "The click list. 404 when the switch is off. The click needs no password."],
        ["api_me / api_me_permissions", "Is the cookie valid, and who is this person with which roles."],
        ["include of the access router", "Mounts /api/access behind the signed-in check. Each route adds its own permission."],
        ["seed_rbac() on startup", "Makes sure the teams, roles and test accounts exist."],
    ], nw, bold_first=True))

    s.append(H2("db/models.py — the six tables"))
    s.append(P("The classes are the tables in section 7. There is no business rule in them."))
    s.append(table([
        ["Class", "Table"],
        ["AppUser", "app_users. No password column. entra_oid stays empty until Microsoft sign-in."],
        ["AppTeam", "app_teams."],
        ["AppRole", "app_roles."],
        ["AppUserRole", "app_user_roles. The grant. Three-part primary key."],
        ["AppRolePermission", "app_role_permissions. One ticked cell."],
        ["AppApprovalStep", "app_approval_steps. One step of one team's chain."],
    ], nw, bold_first=True))

    s.append(H2("ui/web/src/lib/auth.ts — who is signed in"))
    s.append(table([
        ["Name", "What it does"],
        ["usePermissions()", "Loads GET /api/me/permissions. The shell, the menu and the guards all read this. A request still in flight is not treated as a refusal."],
        ["can(me, perm, team)", "The browser's copy of has_permission. Convenience only."],
        ["teamsFor(me, perm)", "Teams to offer in a picker."],
        ["roleLine(role)", "\"Question Author · Backend Engineering\", or \"· every team\" when the team is *."],
        ["useLogin / useDevLogin / useDevAccounts / useLogout", "The form, the click list, and sign out. Each one reloads the signed-in person afterwards."],
    ], nw, bold_first=True))

    s.append(H2("ui/web/src/lib/workspace.ts — the one menu"))
    s.append(table([
        ["Name", "What it does"],
        ["WORKSPACE", "Shortlist, Dashboard, New interview, Question pools, Access. Each names the permission that shows it, and the Welcome card if it has one."],
        ["allowed(me, anyOf)", "May this person open a page that asks for any of these permissions? The shared admin login is allowed through every page except Access."],
        ["visibleWorkspace(me)", "The menu items allowed() keeps. The sidebar and the Welcome page both call it."],
    ], nw, bold_first=True))

    s.append(H2("ui/web/src/lib/access.ts — the Access page's calls"))
    s.append(P("One hook per route in section 6. A save reloads that tab and the signed-in menu, so an admin who edits "
               "their own role sees the new menu without signing out. useSaveChain also keeps the warning the server just returned."))

    s.append(H2("ui/web/src/pages/Access.tsx — the three tabs"))
    s.append(table([
        ["Name", "What it does"],
        ["Access", "Shows only the tabs this admin is allowed to open."],
        ["PeopleTab", "Search, filter, turn on or off, add a grant, remove a grant. The team dropdown follows the role. The last admin's Turn off and Remove are disabled, with the same sentence the server uses."],
        ["TeamsTab", "Create, rename, switch off, delete. Shows \"in use\" from the people, pool and step counts."],
        ["ChainEditor", "The steps under the selected team. Add, remove, reorder, save."],
        ["RolesTab", "The checkbox grid. Locked Access cells on Platform Admin cannot be cleared."],
        ["teamsFor", "Which teams the dropdown offers. The server still refuses a combination this hides."],
    ], nw, bold_first=True))

    s.append(H2("The other screens"))
    s.append(table([
        ["File", "What it does"],
        ["pages/Login.tsx", "Username or email, and the admin password. Below that, the clickable development accounts, rendered only when GET /api/dev/accounts returns them."],
        ["pages/Home.tsx", "Welcome cards taken from WORKSPACE. If the role has none: \"No workspace is assigned to this role.\""],
        ["components/Guard.tsx", "Wraps a route. While permissions are loading it waits. If allowed() says no, it shows the no-access card instead of the page."],
        ["components/AccountGate.tsx", "The no-role card, the turned-off card, and the no-access card."],
        ["App.tsx", "GatedLayout chooses login, turned off, no role, or the shell. Each route names its permission. /sessions/:token/live, the observer, is the route left open."],
        ["lib/api.ts", "getJSON, postJSON, patchJSON, putJSON, deleteJSON. Access uses all five. A non-2xx response becomes ApiError, which the page shows as the server's message."],
    ], nw, bold_first=True))

    s.append(H2("Tests"))
    s.append(table([
        ["File", "What it pins"],
        ["tests/test_rbac.py", "Fail closed. A legacy cookie has no id. Development sign-in is off unless the switch is on. Clicking a name signs in as that person. Typing the email with the admin password does too, and is refused when the switch is off."],
        ["tests/test_access_admin.py", "HR cannot open Access. Author and checker on the same team is refused, including checker on every team. The other team is allowed. The last admin cannot be removed or switched off. A global role cannot be granted on one team. A team in use, and *, cannot be deleted. A new unused team can. The every-team chain cannot be emptied. The admin role cannot lose admin.users. An unknown permission is 400."],
    ], nw, bold_first=True))

    s += H1("9. Operating it")
    s.append(H2("9.1 Run locally"))
    s.append(P("The containers serve an image, not the files on disk. Rebuild the base and the gateway after a change "
               "to this feature, from the repo folder:"))
    s.append(code("podman build -f deploy/Dockerfile.base -t interview-agent-base:local .\n"
                  "podman build -f deploy/Dockerfile.gateway --build-arg BASE_IMAGE=interview-agent-base:local "
                  "-t interview-agent-gateway:local .\n"
                  "podman compose -f deploy/local/docker-compose.yml up -d --force-recreate gateway"))
    s.append(P(f"Open {C('http://localhost:8080/app/')} . {C('DEV_LOGIN_ENABLED=1')} in {C('deploy/local/.env')} shows "
               "the seven accounts. The password for the form is the admin password. On this local setup that is "
               f"{C('centific123')}."))
    s.append(H2("9.2 Tests"))
    s.append(code("python -m pytest tests/test_rbac.py tests/test_access_admin.py -q"))
    s.append(H2("9.3 Not done"))
    s += bullets([
        "Microsoft sign-in. A company member will appear in People with no role until an admin assigns one. The no-role card is already the page they will see.",
        "Interview, shortlist and cadence APIs do not yet call require(interviews.*). The pages are hidden. A direct call from a signed-in cookie still runs.",
        "No email when a pool is waiting for a checker. The checker finds it by opening Approvals.",
        "The development click list must stay off on any shared or Azure URL.",
    ])
    return s


def main() -> None:
    doc = Doc(OUT)
    doc.multiBuild(build())
    print(f"wrote {OUT}")


if __name__ == "__main__":
    main()
