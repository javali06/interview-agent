"""Builds docs/question-pool-maker-checker-reference.pdf.

Run (needs reportlab + the Arial/Consolas TTFs; FONT_DIR defaults to C:\\Windows\\Fonts):
  podman run --rm -v "${PWD}:/w" -v "C:\\Windows\\Fonts:/fonts:ro" -w /w -e FONT_DIR=/fonts \
    python:3.12-slim sh -c "pip install -q reportlab && python docs/_build_maker_checker_pdf.py"
"""
from __future__ import annotations

import math
import os

from reportlab.graphics.shapes import Drawing, Line, Polygon, Rect, String
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    BaseDocTemplate, CondPageBreak, Frame, KeepTogether, NextPageTemplate, PageBreak,
    PageTemplate, Paragraph, Spacer, Table, TableStyle,
)
from reportlab.platypus.tableofcontents import TableOfContents

OUT = os.environ.get("OUT") or os.path.join(os.path.dirname(__file__),
                                             "question-pool-maker-checker-reference.pdf")
FONT_DIR = os.environ.get("FONT_DIR", r"C:\Windows\Fonts")

# ── fonts & palette ──────────────────────────────────────────────────────

for name, file in [("Arial", "arial.ttf"), ("Arial-Bold", "arialbd.ttf"),
                   ("Arial-Italic", "ariali.ttf"), ("Arial-BoldItalic", "arialbi.ttf"),
                   ("Mono", "consola.ttf"), ("Mono-Bold", "consolab.ttf")]:
    pdfmetrics.registerFont(TTFont(name, os.path.join(FONT_DIR, file)))
pdfmetrics.registerFontFamily("Arial", normal="Arial", bold="Arial-Bold",
                              italic="Arial-Italic", boldItalic="Arial-BoldItalic")
pdfmetrics.registerFontFamily("Mono", normal="Mono", bold="Mono-Bold",
                              italic="Mono", boldItalic="Mono-Bold")

INK = colors.HexColor("#1d2433")
MUTED = colors.HexColor("#5b6475")
ACCENT = colors.HexColor("#2f5fb3")
ACCENT_SOFT = colors.HexColor("#e8eef9")
LINE = colors.HexColor("#c9d1de")
ROW_ALT = colors.HexColor("#f5f7fb")
OK = colors.HexColor("#2f8a57")
WARN = colors.HexColor("#b86a12")
BAD = colors.HexColor("#b3363f")
KEY = colors.HexColor("#9a5a00")

# ── styles ───────────────────────────────────────────────────────────────

BASE = dict(fontName="Arial", textColor=INK)
S = {
    "title": ParagraphStyle("title", fontName="Arial-Bold", fontSize=26, leading=31, textColor=INK),
    "subtitle": ParagraphStyle("subtitle", fontName="Arial", fontSize=13, leading=18, textColor=MUTED),
    "h1": ParagraphStyle("h1", fontName="Arial-Bold", fontSize=17, leading=22, textColor=ACCENT,
                         spaceBefore=6, spaceAfter=8),
    "h2": ParagraphStyle("h2", fontName="Arial-Bold", fontSize=12.5, leading=16, textColor=INK,
                         spaceBefore=10, spaceAfter=5),
    "h3": ParagraphStyle("h3", fontName="Arial-Bold", fontSize=10.5, leading=14, textColor=INK,
                         spaceBefore=6, spaceAfter=3),
    "body": ParagraphStyle("body", fontSize=9.5, leading=13.5, spaceAfter=5, **BASE),
    "bullet": ParagraphStyle("bullet", fontSize=9.5, leading=13.5, leftIndent=14, bulletIndent=4,
                             spaceAfter=2, **BASE),
    "small": ParagraphStyle("small", fontSize=8, leading=10.5, textColor=MUTED, fontName="Arial"),
    "cell": ParagraphStyle("cell", fontSize=8, leading=10.3, **BASE),
    "cellb": ParagraphStyle("cellb", fontName="Arial-Bold", fontSize=8, leading=10.3, textColor=INK),
    "head": ParagraphStyle("head", fontName="Arial-Bold", fontSize=8, leading=10.3,
                           textColor=colors.white),
    "code": ParagraphStyle("code", fontName="Mono", fontSize=7.8, leading=10, textColor=INK,
                           backColor=colors.HexColor("#f2f4f8"), borderPadding=(5, 6, 5, 6),
                           leftIndent=4, rightIndent=4, spaceBefore=3, spaceAfter=8),
    "callout": ParagraphStyle("callout", fontSize=9.3, leading=13.3, textColor=INK, fontName="Arial",
                              backColor=ACCENT_SOFT, borderPadding=(7, 8, 7, 8), leftIndent=4,
                              rightIndent=4, spaceBefore=12, spaceAfter=12),
    "caption": ParagraphStyle("caption", fontSize=8, leading=10.5, textColor=MUTED,
                              fontName="Arial-Italic", alignment=TA_CENTER, spaceAfter=8),
    "toc1": ParagraphStyle("toc1", fontName="Arial-Bold", fontSize=10, leading=15, textColor=INK),
    "toc2": ParagraphStyle("toc2", fontName="Arial", fontSize=9, leading=12.5, leftIndent=14,
                           textColor=MUTED),
}


def C(text: str) -> str:
    """Inline code."""
    return f'<font name="Mono" size="8.3">{text}</font>'


def P(text: str, style: str = "body") -> Paragraph:
    return Paragraph(text, S[style])


def bullets(items: list[str]) -> list[Paragraph]:
    return [Paragraph(t, S["bullet"], bulletText="•") for t in items]


def code(text: str) -> Paragraph:
    esc = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return Paragraph(esc.replace("\n", "<br/>").replace("  ", "&nbsp;&nbsp;"), S["code"])


def table(rows: list[list], widths: list[float], bold_first: bool = False,
          head: bool = True) -> Table:
    """A wrapped, zebra-striped table; strings become Paragraphs."""
    data = []
    for r, row in enumerate(rows):
        out = []
        for c, cell in enumerate(row):
            if isinstance(cell, str):
                style = "head" if (head and r == 0) else ("cellb" if (bold_first and c == 0) else "cell")
                cell = Paragraph(cell, S[style])
            out.append(cell)
        data.append(out)
    t = Table(data, colWidths=widths, repeatRows=1 if head else 0)
    cmds = [
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.4, LINE),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    if head:
        cmds.append(("BACKGROUND", (0, 0), (-1, 0), ACCENT))
    for r in range(1 if head else 0, len(data)):
        if r % 2 == 0:
            cmds.append(("BACKGROUND", (0, r), (-1, r), ROW_ALT))
    t.setStyle(TableStyle(cmds))
    return t


# ── document scaffolding ─────────────────────────────────────────────────

PAGE_W, PAGE_H = A4
MARGIN = 18 * mm
TEXT_W = PAGE_W - 2 * MARGIN
LAND_W, LAND_H = landscape(A4)


class Doc(BaseDocTemplate):
    def __init__(self, path: str):
        super().__init__(path, pagesize=A4, title="Question Pools: Maker-Checker & RBAC Reference",
                         author="Interview Agent team", leftMargin=MARGIN, rightMargin=MARGIN,
                         topMargin=MARGIN, bottomMargin=MARGIN)
        portrait = Frame(MARGIN, MARGIN, TEXT_W, PAGE_H - 2 * MARGIN, id="p")
        land = Frame(MARGIN, MARGIN, LAND_W - 2 * MARGIN, LAND_H - 2 * MARGIN, id="l")
        self.addPageTemplates([
            PageTemplate("cover", [portrait], onPage=lambda c, d: None, pagesize=A4),
            PageTemplate("portrait", [portrait], onPage=self._chrome, pagesize=A4),
            PageTemplate("landscape", [land], onPage=self._chrome, pagesize=landscape(A4)),
        ])

    def _chrome(self, canvas, doc):
        w, h = canvas._pagesize
        canvas.saveState()
        canvas.setStrokeColor(LINE)
        canvas.setLineWidth(0.5)
        canvas.line(MARGIN, h - MARGIN + 6, w - MARGIN, h - MARGIN + 6)
        canvas.setFont("Arial", 7.5)
        canvas.setFillColor(MUTED)
        canvas.drawString(MARGIN, h - MARGIN + 9, "Question Pools · Maker-Checker & RBAC — technical reference")
        canvas.drawRightString(w - MARGIN, MARGIN - 12, f"Page {doc.page}")
        canvas.drawString(MARGIN, MARGIN - 12, "Interview Agent · branch feature/text-interview-mode · 12 Oct 2026")
        canvas.restoreState()

    def afterFlowable(self, flowable):
        if isinstance(flowable, Paragraph) and flowable.style.name in ("h1", "h2"):
            level = 0 if flowable.style.name == "h1" else 1
            text = flowable.getPlainText()
            key = f"h{self.seq.nextf('heading')}"
            self.canv.bookmarkPage(key)
            self.notify("TOCEntry", (level, text, self.page, key))


def H1(t: str) -> list:
    return [CondPageBreak(60 * mm), P(t, "h1")]


def H2(t: str) -> Paragraph:
    return P(t, "h2")


# ── diagrams ─────────────────────────────────────────────────────────────


def box(d: Drawing, x, y, w, h, title, lines=(), fill=colors.white, head=ACCENT, title_size=8.5):
    d.add(Rect(x, y, w, h, fillColor=fill, strokeColor=head, strokeWidth=0.9, rx=4, ry=4))
    d.add(Rect(x, y + h - 16, w, 16, fillColor=head, strokeColor=head, rx=4, ry=4))
    d.add(Rect(x, y + h - 16, w, 6, fillColor=head, strokeColor=head))
    d.add(String(x + w / 2, y + h - 11.5, title, fontName="Arial-Bold", fontSize=title_size,
                 fillColor=colors.white, textAnchor="middle"))
    for i, ln in enumerate(lines):
        d.add(String(x + 6, y + h - 28 - i * 10, ln, fontName="Arial", fontSize=7.2, fillColor=INK))


def arrow(d: Drawing, x1, y1, x2, y2, label="", color=INK, dash=None, lx=0, ly=0, size=7):
    d.add(Line(x1, y1, x2, y2, strokeColor=color, strokeWidth=0.9, strokeDashArray=dash))
    ang = math.atan2(y2 - y1, x2 - x1)
    a1, a2 = ang + math.radians(155), ang - math.radians(155)
    d.add(Polygon([x2, y2, x2 + 6 * math.cos(a1), y2 + 6 * math.sin(a1),
                   x2 + 6 * math.cos(a2), y2 + 6 * math.sin(a2)],
                  fillColor=color, strokeColor=color, strokeWidth=0.5))
    if label:
        d.add(String((x1 + x2) / 2 + lx, (y1 + y2) / 2 + ly, label, fontName="Arial",
                     fontSize=size, fillColor=MUTED, textAnchor="middle"))


def architecture() -> Drawing:
    W, H = TEXT_W, 330
    d = Drawing(W, H)
    cw = (W - 30) / 3
    # browser
    box(d, 0, 268, W, 58, "Browser — React SPA (ui/web/src)", [
        "pages/QuestionPools.tsx (list)   ·   pages/QuestionPoolEditor.tsx (author)   ·   pages/PoolApprovals.tsx (queue)",
        "pages/PoolReview.tsx (checker, per question)   ·   components/PoolWorkflow.tsx (state + actions)",
        "lib/questionPools.ts (API client)   ·   lib/auth.ts (usePermissions / can)",
    ], fill=ACCENT_SOFT)
    arrow(d, W / 2, 268, W / 2, 238, "HTTPS + session cookie (carries app_users.id)", lx=95, ly=2)
    box(d, 0, 178, W, 60, "HTTP layer — app/question_pool_routes.py  (mounted at /api/question-pools in app/main.py)", [
        "Every route: signed in (401) + require(permission) (403). Team-scoped checks via ensure_permission(user, perm, team).",
        "Translates ApprovalError -> HTTP status; decides draft visibility; validates request bodies.",
        "Never decides workflow rules itself — it calls the three modules below.",
    ])
    for i, (t, ls, col) in enumerate([
        ("app/rbac.py", ["WHO may do what", "grants_for / has_permission", "ensure_permission / require",
                         "policy: app/rbac_seed.py"], ACCENT),
        ("app/approval_service.py", ["WHAT is allowed, and when", "submit · approve · review · return",
                                     "withdraw · force_publish", "state DERIVED from the ledger"], OK),
        ("app/question_pools.py", ["WHERE the questions live", "pool + question models",
                                   "draft vs published files", "stage_draft / stage_approved"], WARN),
    ]):
        x = i * (cw + 15)
        arrow(d, x + cw / 2, 178, x + cw / 2, 158)
        box(d, x, 88, cw, 70, t, ls, head=col, title_size=7.6)
    # stores
    box(d, 0, 0, 2 * cw + 15, 66, "Database (Postgres in cloud, SQLite locally) — db/models.py", [
        "RBAC: app_users · app_teams · app_roles · app_user_roles",
        "         app_role_permissions · app_approval_steps",
        "Workflow: pool_approvals (append-only ledger) · pool_question_reviews · audit_log",
    ], head=MUTED)
    box(d, 2 * (cw + 15), 0, cw, 66, "Azure Blob (or local disk)", [
        "question_pool_drafts/<id>.yaml",
        "question_pools/<id>.yaml   (LIVE)",
        "question_pool_assets/<name>",
    ], head=MUTED, title_size=7.6)
    arrow(d, cw / 2, 88, cw / 2, 66)
    arrow(d, cw + 15 + cw / 2, 88, cw + 15 + cw / 2, 66)
    arrow(d, 2 * (cw + 15) + cw / 2, 88, 2 * (cw + 15) + cw / 2, 66)
    return d


def er_diagram() -> Drawing:
    W, H = LAND_W - 2 * MARGIN, 470
    d = Drawing(W, H)
    rh, hh, bw = 10.5, 15, 205
    xs = [0, (W - bw) / 2, W - bw]

    def tbl(x, top, name, cols, w=bw, head=ACCENT):
        h = hh + rh * len(cols) + 4
        y = top - h
        d.add(Rect(x, y, w, h, fillColor=colors.white, strokeColor=head, strokeWidth=0.9))
        d.add(Rect(x, top - hh, w, hh, fillColor=head, strokeColor=head))
        d.add(String(x + 6, top - hh + 4.2, name, fontName="Arial-Bold", fontSize=8.5, fillColor=colors.white))
        for i, (c, t, k) in enumerate(cols):
            cy = top - hh - rh * (i + 1) + 2.5
            d.add(String(x + 5, cy, k, fontName="Arial-Bold", fontSize=6.3, fillColor=KEY))
            d.add(String(x + 33, cy, c, fontName="Mono", fontSize=7, fillColor=INK))
            d.add(String(x + w - 5, cy, t, fontName="Arial", fontSize=6.5, fillColor=MUTED, textAnchor="end"))
        return {"x": x, "y": y, "w": w, "h": h, "top": top}

    def rel(child, parent, dash=None, label="", lx=0, ly=0, color=INK):
        (x1, y1), (x2, y2) = child, parent
        d.add(Line(x1, y1, x2, y2, strokeColor=color, strokeWidth=0.8, strokeDashArray=dash))
        L = math.hypot(x2 - x1, y2 - y1) or 1
        ux, uy = (x2 - x1) / L, (y2 - y1) / L
        px, py = -uy, ux
        if not dash:
            # crow's foot (many) at the child end
            bx, by = x1 + ux * 9, y1 + uy * 9
            for s in (-1, 0, 1):
                d.add(Line(bx, by, x1 + px * 4.5 * s, y1 + py * 4.5 * s, strokeColor=color, strokeWidth=0.8))
            # double bar (exactly one) at the parent end
            for off in (5, 8):
                cx, cy = x2 - ux * off, y2 - uy * off
                d.add(Line(cx - px * 4, cy - py * 4, cx + px * 4, cy + py * 4, strokeColor=color, strokeWidth=0.8))
        if label:
            d.add(String((x1 + x2) / 2 + lx, (y1 + y2) / 2 + ly, label, fontName="Arial-Italic",
                         fontSize=6.5, fillColor=MUTED, textAnchor="middle"))

    top1, top2, top3 = 468, 362, 262
    teams = tbl(xs[0], top1, "app_teams", [("id", "int", "PK"), ("key", "str(64)", "UQ"), ("name", "str(255)", ""),
                                            ("is_system", "bool", ""), ("is_active", "bool", ""), ("created_at", "timestamptz", "")])
    steps = tbl(xs[1], top1, "app_approval_steps", [("id", "int", "PK"), ("team_id", "int", "FK"), ("step_no", "int", ""),
                                                     ("approver_role_id", "int", "FK"), ("name", "str(255)", ""), ("is_active", "bool", "")])
    roles = tbl(xs[2], top1, "app_roles", [("id", "int", "PK"), ("key", "str(64)", "UQ"), ("name", "str(255)", ""),
                                            ("description", "text", ""), ("is_system", "bool", ""), ("scope_kind", "str(16)", "")])
    ur = tbl(xs[1], top2, "app_user_roles  (the grant)", [("user_id", "int", "PK FK"), ("role_id", "int", "PK FK"),
                                                         ("team_id", "int", "PK FK"), ("granted_by", "int?", "FK"),
                                                         ("granted_at", "timestamptz", "")])
    rp = tbl(xs[2] + 70, top2, "app_role_permissions", [("role_id", "int", "PK FK"), ("permission", "str(64)", "PK")], w=bw - 70)
    pa = tbl(xs[0], top3, "pool_approvals  (ledger)", [
        ("id", "int", "PK"), ("pool_id", "str(80)", "IDX"), ("team_id", "int", "FK"), ("cycle_id", "str(36)", "IDX"),
        ("action", "str(16)", ""), ("step_no", "int?", ""), ("chain_snapshot", "json?", ""),
        ("actor_user_id", "int", "FK"), ("comment", "text", ""), ("created_at", "timestamptz", "IDX")], head=OK)
    users = tbl(xs[1], top3, "app_users", [("id", "int", "PK"), ("entra_oid", "str(64)?", "UQ"), ("email", "str(320)", "UQ"),
                                            ("display_name", "str(255)", ""), ("is_active", "bool", ""),
                                            ("created_at", "timestamptz", ""), ("last_login_at", "timestamptz?", "")])
    audit = tbl(xs[2], top3, "audit_log", [("id", "int", "PK"), ("actor_user_id", "int?", "FK"), ("action", "str(64)", "IDX"),
                                            ("target_type", "str(32)", ""), ("target_id", "str(80)", ""),
                                            ("detail", "json?", ""), ("created_at", "timestamptz", "IDX")], head=MUTED)
    rv = tbl(xs[1], 140, "pool_question_reviews", [("id", "int", "PK"), ("pool_id", "str(80)", "IDX"), ("cycle_id", "str(36)", "IDX"),
                                                   ("question_id", "str(80)", ""), ("verdict", "str(16)", ""), ("comment", "text", ""),
                                                   ("actor_user_id", "int", "FK"), ("created_at", "timestamptz", "IDX")], head=OK)

    def mid_y(b):
        return b["y"] + b["h"] / 2

    rel((steps["x"], mid_y(steps)), (teams["x"] + bw, mid_y(teams)), label="team_id", ly=4)
    rel((steps["x"] + bw, mid_y(steps)), (roles["x"], mid_y(roles)), label="approver_role_id", ly=4)
    rel((ur["x"], ur["top"] - 30), (teams["x"] + 175, teams["y"]), label="team_id", lx=-14, ly=4)
    rel((ur["x"] + bw, ur["top"] - 30), (roles["x"] + 40, roles["y"]), label="role_id", lx=14, ly=4)
    rel((rp["x"] + 85, rp["top"]), (rp["x"] + 85, roles["y"]), label="role_id", lx=20)
    rel((ur["x"] + 70, ur["y"]), (ur["x"] + 70, users["top"]), label="user_id", lx=-20)
    rel((ur["x"] + 170, ur["y"]), (ur["x"] + 170, users["top"]), dash=None, label="granted_by", lx=26)
    rel((pa["x"] + 40, pa["top"]), (pa["x"] + 40, teams["y"]), label="team_id", lx=-20)
    rel((pa["x"] + bw, pa["top"] - 95), (users["x"], users["top"] - 50), label="actor_user_id", ly=5)
    rel((audit["x"], audit["top"] - 50), (users["x"] + bw, users["top"] - 50), label="actor_user_id", ly=5)
    rel((rv["x"] + 120, rv["top"]), (rv["x"] + 120, users["y"]), label="actor_user_id", lx=34)
    rel((rv["x"], rv["top"] - 40), (pa["x"] + 200, pa["y"]), dash=[3, 2], color=OK,
        label="logical: same pool_id + cycle_id", lx=-48, ly=-2)

    # blob note
    bx, by, bwid, bh = xs[0], 4, bw, 70
    d.add(Rect(bx, by, bwid, bh, fillColor=colors.HexColor("#fff8ec"), strokeColor=WARN,
               strokeWidth=0.9, strokeDashArray=[3, 2]))
    for i, ln in enumerate(["NOT A TABLE — Blob files keyed by pool_id",
                            "question_pool_drafts/<pool_id>.yaml   (draft)",
                            "question_pools/<pool_id>.yaml          (live)",
                            "pool_id is a plain string, never an FK:",
                            "the pool itself is a YAML document."]):
        d.add(String(bx + 6, by + bh - 12 - i * 11, ln, fontName="Arial-Bold" if i == 0 else "Arial",
                     fontSize=7.2, fillColor=INK))
    rel((pa["x"] + 120, pa["y"]), (pa["x"] + 120, by + bh), dash=[3, 2], color=WARN, label="pool_id", lx=18)

    # legend
    lx0, ly0 = xs[2], 120
    d.add(Rect(lx0, 4, bw, 118, fillColor=ROW_ALT, strokeColor=LINE))
    d.add(String(lx0 + 8, ly0 - 12, "Legend", fontName="Arial-Bold", fontSize=8.5, fillColor=INK))
    rel((lx0 + 12, ly0 - 30), (lx0 + 62, ly0 - 30))
    d.add(String(lx0 + 70, ly0 - 32.5, "foreign key: many (foot) -> one (bars)", fontName="Arial", fontSize=7, fillColor=INK))
    d.add(Line(lx0 + 12, ly0 - 46, lx0 + 62, ly0 - 46, strokeColor=OK, strokeDashArray=[3, 2]))
    d.add(String(lx0 + 70, ly0 - 48.5, "logical link, no DB constraint", fontName="Arial", fontSize=7, fillColor=INK))
    for i, (k, t) in enumerate([("PK", "primary key (PK FK = composite key part)"), ("FK", "foreign key"),
                                ("UQ", "unique"), ("IDX", "indexed"), ("?", "nullable (after the type)")]):
        d.add(String(lx0 + 12, ly0 - 64 - i * 10.5, k, fontName="Arial-Bold", fontSize=7, fillColor=KEY))
        d.add(String(lx0 + 34, ly0 - 64 - i * 10.5, t, fontName="Arial", fontSize=7, fillColor=INK))
    k = 0.84
    d.scale(k, k)
    d.width, d.height = W * k, H * k
    d.hAlign = "CENTER"
    return d


def state_diagram() -> Drawing:
    W, H = TEXT_W, 215
    d = Drawing(W, H)

    def state(x, y, label, sub, col):
        d.add(Rect(x, y, 104, 46, rx=10, ry=10, fillColor=colors.white, strokeColor=col, strokeWidth=1.6))
        d.add(String(x + 52, y + 27, label, fontName="Arial-Bold", fontSize=11, fillColor=col, textAnchor="middle"))
        d.add(String(x + 52, y + 13, sub, fontName="Arial", fontSize=6.8, fillColor=MUTED, textAnchor="middle"))

    dx, px, ux = 0, W / 2 - 52, W - 104
    y = 95
    state(dx, y, "draft", "no interview can see it", MUTED)
    state(px, y, "pending", "waiting for checker(s)", WARN)
    state(ux, y, "published", "live: interviews use it", OK)
    arrow(d, dx + 104, y + 34, px, y + 34, "submit (pools.submit)", ly=6)
    arrow(d, px, y + 12, dx + 104, y + 12, "return / withdraw /", ly=-12)
    d.add(String((dx + 104 + px) / 2, y - 9, "review with a rejection", fontName="Arial", fontSize=7,
                 fillColor=MUTED, textAnchor="middle"))
    arrow(d, px + 104, y + 23, ux, y + 23, "final step approved", ly=6)
    # self loop on pending
    d.add(Line(px + 40, y + 46, px + 40, y + 74, strokeColor=INK, strokeWidth=0.9))
    d.add(Line(px + 40, y + 74, px + 80, y + 74, strokeColor=INK, strokeWidth=0.9))
    arrow(d, px + 80, y + 74, px + 80, y + 46)
    d.add(String(px + 60, y + 80, "approve an earlier step (chain has more steps)", fontName="Arial",
                 fontSize=7, fillColor=MUTED, textAnchor="middle"))
    # force publish draft -> published (under)
    d.add(Line(dx + 30, y, dx + 30, y - 50, strokeColor=BAD, strokeWidth=0.9, strokeDashArray=[4, 2]))
    d.add(Line(dx + 30, y - 50, ux + 74, y - 50, strokeColor=BAD, strokeWidth=0.9, strokeDashArray=[4, 2]))
    arrow(d, ux + 74, y - 50, ux + 74, y, color=BAD, dash=[4, 2])
    d.add(String(W / 2, y - 62, "force publish  (admin: pools.publish) — skips the chain, recorded as an override",
                 fontName="Arial", fontSize=7.3, fillColor=BAD, textAnchor="middle"))
    # published + edited -> submit again
    d.add(Line(ux + 52, y + 46, ux + 52, y + 104, strokeColor=INK, strokeWidth=0.9))
    d.add(Line(ux + 52, y + 104, px + 90, y + 104, strokeColor=INK, strokeWidth=0.9))
    arrow(d, px + 90, y + 104, px + 90, y + 46)
    d.add(String((ux + px) / 2 + 80, y + 109, "author edits (a draft appears behind the live pool), then submits",
                 fontName="Arial", fontSize=7, fillColor=MUTED, textAnchor="middle"))
    d.add(String(W / 2, 12, "A partial review does both: the approved questions go live AND the pool returns to draft "
                 "with only the rejected ones.", fontName="Arial-Italic", fontSize=7.5, fillColor=INK, textAnchor="middle"))
    return d


# ── content ──────────────────────────────────────────────────────────────


def build() -> list:
    s: list = []
    W = TEXT_W

    # cover
    s += [Spacer(1, 55 * mm), P("Question Pools", "subtitle"),
          P("Maker-Checker &amp; Access Control (RBAC)", "title"), Spacer(1, 6),
          P("Technical reference — design, database tables and ER diagram, workflow rules, "
            "API, files and day-to-day operation.", "subtitle"), Spacer(1, 16 * mm)]
    s.append(table([
        ["Item", "Value"],
        ["Repository", "Interview_agent_app"],
        ["Branch", "feature/text-interview-mode (base commit 69cb7ff) + the uncommitted fixes of 12 Oct 2026"],
        ["Feature commits", "136aa13 (RBAC + maker-checker), 4877edd (per-question review, read-only editor, built-ins)"],
        ["Audience", "Developers, reviewers, QA and admins who use or change the pool workflow"],
        ["Status", "Pool workflow built and tested locally. Not deployed to Azure."],
        ["Access screens", "People, Teams and Roles are documented in rbac-authentication-reference.pdf (22 Oct 2026). This PDF keeps only the pool rules."],
    ], [40 * mm, W - 40 * mm], bold_first=True))
    s += [NextPageTemplate("portrait"), PageBreak()]

    toc = TableOfContents()
    toc.levelStyles = [S["toc1"], S["toc2"]]
    s += [Paragraph("Contents", ParagraphStyle("toch", parent=S["h1"])), toc, PageBreak()]

    # 1
    s += H1("1. What this feature is")
    s.append(P(
        "A <b>question pool</b> is a named set of questions (spoken, coding, scenario, or written-response) that an "
        "interview phase draws from. Because a pool decides what real candidates are asked, a change to it should not "
        "go live on one person's word. The <b>maker-checker</b> workflow enforces that: an <b>author</b> (maker) writes "
        "or edits a pool, a <b>different</b> person — a <b>checker</b> on the same team — reviews it, and only then is it "
        "published to interviews. <b>RBAC</b> (role-based access control) is the layer that decides who is an author, "
        "who is a checker, and for which team."))
    s.append(P("The design rests on three guarantees. Each is enforced by structure, not by people remembering a rule:", "body"))
    s += bullets([
        "<b>An unapproved question can never reach a candidate.</b> Drafts and published pools are stored under two "
        f"different blob prefixes ({C('question_pool_drafts/')} and {C('question_pools/')}). Interviews read only the "
        "published prefix. There is no permission check to forget — the draft is simply not where interviews look.",
        "<b>Nobody approves their own work, and checkers are scoped to teams.</b> The submitter and every named author "
        "are refused as approvers; a checker for one team cannot sign another team's pool; one person cannot sign two "
        "steps of the same cycle.",
        "<b>Every decision is recorded and cannot be rewritten.</b> The approval ledger is append-only. A pool's state "
        "(draft / pending / published) is <i>derived</i> from that ledger every time, never stored, so the status shown "
        "and the history can never disagree.",
    ])
    s.append(P(
        "<b>One-paragraph flow.</b> An author saves a pool — it is stored as a draft. They press <i>Submit for "
        "approval</i>; a review <i>cycle</i> opens with the team's approval <i>chain</i> frozen onto it. A checker opens "
        "the review screen and approves or rejects each question (rejections need a reason). If everything is approved "
        "and this was the last step, the draft becomes the live pool. If some questions are rejected, the approved ones "
        "go live and the rejected ones go back to the author as the new draft, each with the checker's comment.",
        "callout"))

    s.append(H2("1.1 Glossary"))
    s.append(table([
        ["Term", "Meaning"],
        ["Maker / author", f"Someone holding {C('pools.edit')} (+ {C('pools.submit')}) for a team. Writes drafts and submits them."],
        ["Checker", f"Someone holding {C('pools.approve')} for a team. Approves or returns submitted pools."],
        ["Team", f"The scope of a grant and of a pool (e.g. {C('backend')}, {C('qa')}). The special team {C('*')} means every team."],
        ["Role", f"A named bundle of permissions: {C('admin')}, {C('pool_author')}, {C('pool_checker')}, {C('hr')}."],
        ["Permission", f"One action from a fixed list in {C('app/rbac.py')}, e.g. {C('pools.approve')}."],
        ["Grant", "A row saying: this person holds this role for this team."],
        ["Approval chain", "The ordered steps a team's pools must pass. Default: one step, role pool_checker."],
        ["Cycle", "One round from submit to a decision (published / returned / withdrawn). Has a UUID cycle_id."],
        ["Ledger", "The append-only pool_approvals table: one row per thing that happened to a pool."],
        ["Draft", "The work-in-progress copy of a pool (blob prefix question_pool_drafts/)."],
        ["Published / live", "The copy interviews use (blob prefix question_pools/)."],
        ["Built-in pool", "A pool shipped inside the image (questions_pool/*.yaml). Read-only, no workflow; use Duplicate to edit."],
        ["Verdict", "A checker's approved/rejected decision on one question (pool_question_reviews)."],
        ["Force publish", "Break-glass: publish a draft immediately, skipping the chain. Admin-only and recorded as such."],
    ], [32 * mm, W - 32 * mm], bold_first=True))

    # 2
    s += H1("2. Architecture")
    s.append(P("Four layers, each with one job. The HTTP layer never decides a workflow rule; the workflow layer never "
               "touches HTTP or blob storage directly (publishing is a callback it is given)."))
    s.append(architecture())
    s.append(P("Figure 1 — layers and where each piece of state lives.", "caption"))
    s.append(table([
        ["Layer", "File", "Responsibility", "Deliberately does NOT"],
        ["Access control", "app/rbac.py", "Read a person's grants; answer “may X do P for team T?”; FastAPI guards.",
         "Know about pools or workflow."],
        ["Policy (seed)", "app/rbac_seed.py", "The teams, roles, role→permission grid, default chain, dev accounts.",
         "Remove anything (it only adds what is missing)."],
        ["Workflow", "app/approval_service.py", "Transitions, refusals, deriving state from the ledger, the checker's queue.",
         "Know HTTP or blob paths (publish is a callback)."],
        ["Storage", "app/question_pools.py", "Pool/question models + validation; draft vs published files; publishing.",
         "Know who is signed in or what the workflow state is."],
        ["HTTP", "app/question_pool_routes.py", "Routes, permission gates, draft visibility, error mapping.",
         "Re-implement any rule from the layers above."],
        ["Shared values", "app/constants.py", "State/action/verdict strings and GLOBAL_TEAM = \"*\".", "Import anything."],
        ["Tables", "db/models.py", "SQLAlchemy models for the 9 tables in section 4.", "Hold business logic."],
    ], [24 * mm, 36 * mm, 64 * mm, W - 124 * mm], bold_first=True))

    # 3
    s += H1("3. Access control (RBAC)")
    s.append(P(
        "This section is only what the pool workflow needs: the permissions a route checks, the seeded roles, and "
        "who may see a draft. Sign-in, the menu, the no-role page, and the Access screens (People, Teams, the "
        "approval chain, the role grid) are in <b>rbac-authentication-reference.pdf</b>."
    ))
    s.append(H2("3.1 How a permission check works"))
    s += bullets([
        "A person's <b>grants</b> are rows of (person, role, team). A role carries a set of <b>permissions</b>. So a "
        "person holds permission P for team T if one of their grants has a role that includes P, on team T or team "
        f"{C('*')}.",
        f"{C('grants_for(user_id)')} loads everything in <b>one query</b> as {C('{permission: {team keys}}')}. "
        "It is read from the database on every request, so revoking a role takes effect on the next request.",
        f"{C('has_permission(user, perm, team)')}: with a team, passes for that team or {C('*')}; with no team, passes "
        "if the person holds the permission anywhere.",
        "It <b>fails closed</b>: an unknown permission, an unknown or inactive user, or no grant → refused.",
        f"Routes use {C('Depends(require(\"pools.view\"))')} (401 if not signed in, 403 if not allowed) and, where "
        f"the team is only known after loading the pool, {C('ensure_permission(user, perm, team, message)')}.",
    ])
    s.append(H2("3.2 The permission vocabulary"))
    s.append(P(f"A closed list in {C('app/rbac.py')}. Anything else is rejected with a ValueError, so a typo can never "
               "create a permission that silently grants nothing."))
    s.append(table([
        ["Permission", "Allows", "Checked by"],
        ["pools.view", "See the pool list, open a pool, export it, preview assets, read question kinds.", "All read routes"],
        ["pools.edit", "Create, edit, duplicate a draft; delete a draft; upload media. Team-scoped.", "POST/PUT pool, duplicate, assets, delete draft"],
        ["pools.submit", "Send a draft into the approval chain; withdraw your own submission.", "submit, withdraw"],
        ["pools.approve", "Sign your step, review per question, or return with a comment.", "approve, review, return, queue"],
        ["pools.publish", "Force-publish skipping the chain (break-glass); delete a published pool. Team-scoped.", "publish, delete published"],
        ["interviews.view / .schedule / .cancel", "Hide Dashboard, Shortlist and New interview. The interview APIs still only check that someone is signed in.", "The menu and the page guard. Not the interview routes."],
        ["admin.users / .teams / .permissions", "The Access screens: people, teams and the role grid.", "Every /api/access route. See the RBAC reference."],
    ], [42 * mm, 88 * mm, W - 130 * mm], bold_first=True))
    s.append(H2("3.3 Roles, teams and the default chain (seeded)"))
    s.append(table([
        ["Role key", "Name", "scope_kind", "Permissions"],
        ["admin", "Platform Admin", "global", "All 11 permissions"],
        ["pool_author", "Question Author", "team", "pools.view, pools.edit, pools.submit"],
        ["pool_checker", "Question Checker", "team", "pools.view, pools.approve"],
        ["hr", "HR / Recruiter", "global", "interviews.view, interviews.schedule, interviews.cancel — no pools.* at all"],
    ], [26 * mm, 32 * mm, 20 * mm, W - 78 * mm], bold_first=True))
    s.append(Spacer(1, 6))
    s.append(P(f"<b>Teams:</b> {C('*')} (\"All teams\", is_system), {C('backend')} (Backend Engineering), {C('qa')} "
               f"(Quality Assurance). <b>Default chain:</b> team {C('*')}, step 1, role {C('pool_checker')}, name "
               "\"Review\". A team with no chain of its own uses the * chain — so one approval is the default, and a "
               "second level is one extra row (section 10.4)."))
    s.append(H2("3.4 Seeded accounts"))
    s.append(table([
        ["Email", "Grant (role @ team)", "Why it exists"],
        ["ayush.kothiyal@centific.com", "admin @ *", "Can do everything, including force publish."],
        ["sathwik.badda@centific.com", "admin @ *", "Second admin."],
        ["md.azhar@centific.com", "pool_author @ backend", "Writes backend pools; refused on QA pools."],
        ["puchalapalli.harika@centific.com", "pool_checker @ backend", "Approves backend; must be refused on QA pools."],
        ["sai.kambampati@centific.com", "pool_checker @ *", "Central reviewer: may check every team."],
        ["hasini.gandhe@centific.com", "pool_author @ qa", "Writes QA pools."],
        ["javali.manda@centific.com", "hr @ *", "Proves HR is refused on every pools route."],
    ], [58 * mm, 40 * mm, W - 98 * mm]))
    s.append(H2("3.5 Signing in"))
    s += bullets([
        f"The session cookie carries the person's {C('app_users.id')}; {C('rbac.current_user_id(request)')} reads it.",
        f"Until Microsoft Entra sign-in lands, a named person signs in through development sign-in, which is off unless "
        f"{C('DEV_LOGIN_ENABLED=1')}. Clicking a name calls {C('POST /api/dev/login')} and needs no password. Typing "
        "that person's email into the normal form uses the shared admin password. Keep the switch off on any shared URL. "
        "The full description is in the RBAC reference.",
        "The old shared admin login (username + password) has <b>no user id</b>, so it holds no pool permissions: "
        "pool routes answer 401 \"sign-in required\" to it.",
        f"{C('GET /api/me/permissions')} returns the person, their roles and {C('{permission: [teams]}')}; the SPA "
        "builds menus and buttons from it. Hiding a button is convenience — the server re-checks everything.",
    ])
    s.append(H2("3.6 Who may see a draft"))
    s.append(P(f"{C('pools.view')} alone is <b>not</b> enough to see another team's unpublished work. A draft (and its "
               f"review screen, history and return comments) is visible only to people holding {C('pools.edit')} or "
               f"{C('pools.approve')} for the pool's team (or {C('*')}). Everyone else with {C('pools.view')} sees only "
               "the published version."))

    # 4 database
    s += [NextPageTemplate("landscape"), PageBreak()]
    s.append(P("4. Database", "h1"))
    s.append(P("Nine tables. Six describe access (who may do what); three record what happened. "
               "The pool itself is <b>not</b> a table — it is a YAML document in blob storage, referenced by "
               f"{C('pool_id')}.", "body"))
    s.append(er_diagram())
    s.append(P("Figure 2 — entity-relationship diagram (db/models.py).", "caption"))
    s += [NextPageTemplate("portrait"), PageBreak()]

    s.append(H2("4.1 Table by table"))
    tw = [34 * mm, 25 * mm, 17 * mm, W - 76 * mm]

    def tdef(name, purpose, cols):
        return KeepTogether([P(f"<font name='Mono'>{name}</font>", "h3"), P(purpose),
                             table([["Column", "Type", "Key / null", "Meaning"]] + cols, tw)])

    s.append(tdef("app_teams", "A scope for grants and for pools. Seeded with * plus the real teams.", [
        ["id", "integer", "PK", "Surrogate key."],
        ["key", "varchar(64)", "unique, idx", "Stable identifier used everywhere in code and the API: *, backend, qa."],
        ["name", "varchar(255)", "", "Display name (\"All teams\", \"Backend Engineering\")."],
        ["is_system", "boolean", "", "True only for *, so a future admin UI can refuse to delete it."],
        ["is_active", "boolean", "", "Soft off-switch for a team."],
        ["created_at", "timestamptz", "", "Set by the database."],
    ]))
    s.append(tdef("app_users", "One row per person who may sign in.", [
        ["id", "integer", "PK", "What the session cookie carries and every permission check reads."],
        ["entra_oid", "varchar(64)", "unique, NULL", "Microsoft Entra object id, stamped on at first Entra sign-in. NULL today."],
        ["email", "varchar(320)", "unique, idx", "Lower-cased. Also what author / self-approval checks compare."],
        ["display_name", "varchar(255)", "", "Shown in the UI."],
        ["is_active", "boolean", "", "False → the person holds no permissions at all (fail closed)."],
        ["created_at", "timestamptz", "", ""],
        ["last_login_at", "timestamptz", "NULL", "Updated on dev sign-in."],
    ]))
    s.append(tdef("app_roles", "A persona — what a PERSON may do. (Not the same as the job-opening `roles` table.)", [
        ["id", "integer", "PK", ""],
        ["key", "varchar(64)", "unique, idx", "admin | pool_author | pool_checker | hr."],
        ["name", "varchar(255)", "", "Display name."],
        ["description", "text", "", "What the role is for."],
        ["is_system", "boolean", "", "True for admin, so the role that fixes mistakes cannot be deleted."],
        ["scope_kind", "varchar(16)", "", "\"global\" or \"team\": whether granting it per team is meaningful."],
    ]))
    s.append(tdef("app_user_roles", "The grant: this person holds this role for this team. Composite primary key.", [
        ["user_id", "integer", "PK, FK→app_users", "Who."],
        ["role_id", "integer", "PK, FK→app_roles", "Which role."],
        ["team_id", "integer", "PK, FK→app_teams", "For which team. The * team means every team."],
        ["granted_by", "integer", "FK→app_users, NULL", "Who granted it (NULL = seed)."],
        ["granted_at", "timestamptz", "", ""],
    ]))
    s.append(tdef("app_role_permissions", "The role→permission grid, as rows. Changing what a role may do is data, not a deploy.", [
        ["role_id", "integer", "PK, FK→app_roles", ""],
        ["permission", "varchar(64)", "PK", "Must be one of the closed vocabulary in app/rbac.py."],
    ]))
    s.append(tdef("app_approval_steps", "One step of a team's approval chain. Unique (team_id, step_no).", [
        ["id", "integer", "PK", ""],
        ["team_id", "integer", "FK→app_teams, idx", "Whose chain. A team with no rows uses the * chain."],
        ["step_no", "integer", "unique per team", "Order of the step: 1, 2, …"],
        ["approver_role_id", "integer", "FK→app_roles", "The role a signer must hold (for the pool's team or *)."],
        ["name", "varchar(255)", "", "Shown as \"Waiting for <name>\"."],
        ["is_active", "boolean", "", "Inactive steps are ignored when a cycle opens."],
    ]))
    s.append(tdef("pool_approvals", "The maker-checker LEDGER. Append-only: rows are never updated or deleted. "
                  "A pool's state is derived from these rows.", [
        ["id", "integer", "PK", "Also the tie-breaker for ordering rows written in the same instant."],
        ["pool_id", "varchar(80)", "idx", "The pool's id (its blob file name). Not an FK — the pool is a file."],
        ["team_id", "integer", "FK→app_teams", "The pool's team at the time of the row."],
        ["cycle_id", "varchar(36)", "idx", "UUID of the submit-to-decision round the row belongs to."],
        ["action", "varchar(16)", "", "submitted | approved | returned | published | withdrawn."],
        ["step_no", "integer", "NULL", "The step signed (approved rows) or completed (published rows)."],
        ["chain_snapshot", "json", "NULL", "Only on submitted rows: {steps:[{step_no, role, name}], author_emails:[…]}."],
        ["actor_user_id", "integer", "FK→app_users", "Who did it."],
        ["comment", "text", "", "Reason for a return, note on an approval, or the force-publish reason."],
        ["created_at", "timestamptz", "idx", "When."],
    ]))
    s.append(tdef("pool_question_reviews", "One checker's verdict on one question in one cycle. Append-only; the latest "
                  "row per (cycle, question) wins, so changing your mind keeps the history.", [
        ["id", "integer", "PK", ""],
        ["pool_id", "varchar(80)", "idx", "Same id as pool_approvals.pool_id."],
        ["cycle_id", "varchar(36)", "idx", "The cycle the verdict belongs to (links logically to pool_approvals)."],
        ["question_id", "varchar(80)", "", "The question's id inside the pool YAML."],
        ["verdict", "varchar(16)", "", "approved | rejected."],
        ["comment", "text", "", "Required for a rejection — the author reads it next to the question."],
        ["actor_user_id", "integer", "FK→app_users", "The checker."],
        ["created_at", "timestamptz", "idx", ""],
    ]))
    s.append(tdef("audit_log", "Consequential acts, append-only. The pool workflow writes publishes here.", [
        ["id", "integer", "PK", ""],
        ["actor_user_id", "integer", "FK→app_users, NULL", "NULL means the system did it."],
        ["action", "varchar(64)", "idx", "pool.published or pool.force_published (from this feature)."],
        ["target_type", "varchar(32)", "", "\"pool\"."],
        ["target_id", "varchar(80)", "", "The pool id."],
        ["detail", "json", "NULL", "{cycle_id, steps} for a publish; {bypassed_chain: true, comment} for a force publish."],
        ["created_at", "timestamptz", "idx", ""],
    ]))

    s.append(H2("4.2 Indexes and constraints"))
    s.append(table([
        ["Table", "Index / constraint", "Why"],
        ["app_teams, app_roles", "unique(key)", "Code addresses teams and roles by key."],
        ["app_users", "unique(email), unique(entra_oid)", "One account per person; Entra id once it exists."],
        ["app_user_roles", "PK(user_id, role_id, team_id)", "The same grant cannot exist twice."],
        ["app_role_permissions", "PK(role_id, permission)", "A role holds a permission once."],
        ["app_approval_steps", "uq_step_per_team (team_id, step_no)", "A chain cannot have two step 1s."],
        ["pool_approvals", "idx_pool_approvals_pool_cycle (pool_id, cycle_id)", "Loading one pool's ledger / one cycle."],
        ["pool_question_reviews", "idx_pool_q_reviews_cycle (pool_id, cycle_id, question_id)", "Latest verdict per question."],
    ], [36 * mm, 66 * mm, W - 102 * mm], bold_first=True))

    s.append(H2("4.3 Design decisions worth knowing"))
    s += bullets([
        f"<b>\"All teams\" is a real row, not NULL.</b> A composite primary key cannot hold NULL, and UNIQUE treats NULLs "
        "as distinct — so NULL-as-global would silently allow duplicate grants. A real * row keeps keys and FKs clean.",
        "<b>State is derived, never stored.</b> There is no status column to drift from the history.",
        "<b>The chain is frozen at submit</b> (chain_snapshot). If an admin deletes a step mid-cycle, the pending cycle is "
        "still judged against the steps it was submitted with — otherwise deleting the pending step would publish "
        "a pool nobody finished approving.",
        "<b>The authors are frozen at submit</b> (author_emails), so someone who edited the pool cannot approve it.",
        "<b>cycle_id groups a round.</b> Approvals from an earlier, returned cycle never count toward a new submission.",
        "<b>Verdicts are a separate table</b> because their grain is the question, not the pool; the pool's state is "
        "still computed from one place.",
    ])

    s.append(H2("4.4 What the ledger looks like"))
    s.append(P("A backend pool, single-step chain: submitted by Azhar, partially approved by Harika (one question "
               "rejected), fixed and resubmitted, then approved."))
    s.append(table([
        ["id", "cycle", "action", "step", "actor", "comment"],
        ["1", "c1", "submitted", "—", "md.azhar", "chain_snapshot = {steps:[{1, pool_checker, Review}], author_emails:[md.azhar…]}"],
        ["2", "c1", "approved", "1", "harika", "Approved 2 questions."],
        ["3", "c1", "published", "1", "harika", "(the 2 approved questions are merged into the live pool)"],
        ["4", "c1", "returned", "—", "harika", "Published 2 approved; 1 need work. q3: Name the trade-off."],
        ["5", "c2", "submitted", "—", "md.azhar", "new cycle, fresh chain_snapshot"],
        ["6", "c2", "approved", "1", "harika", "Approved all 1 questions."],
        ["7", "c2", "published", "1", "harika", ""],
    ], [9 * mm, 12 * mm, 20 * mm, 11 * mm, 20 * mm, W - 72 * mm]))
    s.append(P("After row 4 the state is <b>draft</b> (the last closing action of cycle c1 is a return) even though "
               "content was published in that cycle; after row 7 it is <b>published</b>.", "small"))

    # 5 storage
    s += H1("5. Pool storage (blob)")
    s.append(table([
        ["Location", "Holds", "Written by", "Read by"],
        ["question_pool_drafts/<id>.yaml", "The draft (work in progress)", "create / edit / duplicate; a partial review rewrites it",
         "Authors and checkers of that team"],
        ["question_pools/<id>.yaml", "The published (live) pool", "Only publishing: approve, review, force publish",
         "Everyone with pools.view; interviews (for-phase)"],
        ["question_pool_assets/<name>", "Uploaded image / audio / video", "POST /assets", "Editor preview"],
        ["<token>/phase_assets/<name>", "A copy of an asset inside one interview", "for-phase (copies on apply)",
         "The candidate's interview"],
    ], [44 * mm, 36 * mm, 50 * mm, W - 130 * mm]))
    s.append(Spacer(1, 4))
    s.append(P(f"Blob is used when {C('BLOB_ENABLED=1')}; otherwise the same paths live on local disk under "
               f"{C('SESSIONS_DIR')}. Pool ids are a slug of the name plus a random suffix, and must match "
               f"{C('[a-z0-9_-]')} — {C('_path()')} refuses anything else, so an id can never address a file outside "
               "its prefix."))
    s.append(H2("5.1 The pool document"))
    s.append(table([
        ["Field", "Meaning"],
        ["pool_name, description", "Shown in lists and pickers."],
        ["pool_id, updated_at", "Metadata added on save."],
        ["pool_kind", "Legacy pool-level default (each question carries its own kind)."],
        ["team", "Owning team key; empty means * (every team). Decides whose chain reviews it."],
        ["created_by, updated_by", "Author emails. Both are frozen into the cycle at submit and barred from approving."],
        ["questions[]", "id, kind, text, topic, difficulty, coverage_tags, plus one kind-specific block: "
                        "written_response | coding | scenario."],
    ], [40 * mm, W - 40 * mm], bold_first=True))
    s.append(P("Question kinds: <b>spoken</b> (asked aloud), <b>coding</b> (live editor + test cases), <b>scenario</b> "
               "(show media, ask about it), and the written-response types from the question-type registry "
               "(comprehensive, transcription, translation, image description)."))
    s.append(H2("5.2 How publishing writes the files"))
    s += bullets([
        f"{C('stage_draft(pool_id)')} — whole-pool approval: copies the draft over the live pool. Used by Approve, "
        "force publish, and a review where <b>every</b> question is approved. Deletions by the author take effect.",
        f"{C('stage_approved(pool_id, ids)')} — partial approval: merges only the approved questions into the live pool "
        "<b>by id</b>. A rejected edit therefore leaves the previously published version of that question live — "
        "candidates keep getting the last reviewed wording, never nothing.",
        "Both run <b>inside</b> the approval transaction (a storage failure rolls the approval back) and only write the "
        "live file. The draft change (delete it, or rewrite it to the rejected questions) is returned as a cleanup "
        "and run <b>after</b> the ledger commits — so if the commit fails, the draft is intact and the action can be retried.",
        f"{C('publish_draft')} / {C('publish_approved')} are the same thing plus the cleanup at once, for callers "
        "outside a transaction (tests, scripts).",
    ])

    # 6 workflow
    s += H1("6. The workflow")
    s.append(state_diagram())
    s.append(P("Figure 3 — workflow states and transitions.", "caption"))
    s.append(H2("6.1 How the state is derived"))
    s.append(P(f"{C('_derive(rows)')} reads one pool's ledger (oldest first) and applies these rules in order:"))
    s.append(table([
        ["#", "Rule", "Result"],
        ["1", "No rows at all", "draft"],
        ["2", "No submitted row, but a published row (only ever force-published)", "published"],
        ["3", "The latest submitted row opens the current cycle. A force-publish recorded after it, in another cycle", "published"],
        ["4", "In the current cycle, the LAST closing action is published", "published"],
        ["5", "In the current cycle, the last closing action is returned or withdrawn", "draft (last_comment = latest return)"],
        ["6", "Otherwise", "pending; next_step = first unsigned step of the frozen chain"],
    ], [8 * mm, W - 58 * mm, 50 * mm]))
    s.append(P("Two different questions are answered separately in the UI: the <b>file state</b> (is there a draft "
               f"file? is there a published file? → {C('state')}, {C('has_draft')}) and the <b>workflow state</b> above "
               f"({C('workflow')}). A live pool with an edit behind it is file state \"published\" + has_draft, and can be "
               "submitted again."))

    s.append(H2("6.2 Every action"))
    s.append(table([
        ["Action (route)", "Who", "Preconditions", "Writes"],
        ["Save — POST / PUT /api/question-pools[/{id}]", "pools.edit on the pool's current team (and the new team, if moving it)",
         "Not pending (edit → 409)", "Draft file only. Live pool untouched."],
        ["Submit — POST /{id}/submit", "pools.submit on the draft's team", "A draft exists; not already pending; team has a chain",
         "submitted row with chain_snapshot (steps + author emails)."],
        ["Approve — POST /{id}/approve", "pools.approve; holds the step's role for the team",
         "Pending; not an author/submitter; has not signed this cycle", "approved row. If it completes the chain: live file, published row, audit pool.published; draft deleted after commit."],
        ["Review — POST /{id}/review", "Same as Approve if any question is approved; wrong-team check if all rejected",
         "Pending; a verdict for EVERY question; a comment on every rejection", "Verdict rows + the outcome rows in 6.3, in ONE transaction."],
        ["Return — POST /{id}/return", "pools.approve for the team", "Pending; comment required", "returned row; cycle closes; author edits and resubmits."],
        ["Withdraw — POST /{id}/withdraw", "The submitter only", "Pending", "withdrawn row; back to draft."],
        ["Force publish — POST /{id}/publish", "pools.publish on the draft's team (admin)", "A draft exists",
         "Live file, published row (with reason), audit pool.force_published {bypassed_chain: true}."],
        ["Delete — DELETE /{id}", "pools.edit (draft) / pools.publish (published) on the team", "Not pending", "Removes the file(s)."],
    ], [37 * mm, 40 * mm, 45 * mm, W - 122 * mm]))

    s.append(H2("6.3 Per-question review outcomes"))
    s.append(P("The outcome is derived from the verdicts — the checker never picks it separately, so it cannot be forgotten."))
    s.append(table([
        ["Verdicts", "This is the LAST step", "An EARLIER step of a longer chain"],
        ["All approved", "approved + published rows; draft replaces live (same as Approve)", "approved row; still pending for the next step"],
        ["Some approved, some rejected", "approved + published + returned rows; approved questions merged into live by id; draft = rejected ones",
         "approved + returned rows; nothing goes live; the whole pool returns"],
        ["All rejected", "returned row; nothing goes live", "returned row; nothing goes live"],
    ], [34 * mm, (W - 34 * mm) / 2, (W - 34 * mm) / 2], bold_first=True))
    s.append(P("Every refusal (self-approval, wrong team, signing twice) runs <b>before</b> anything is written, so a "
               "refused review leaves no live content and no stray verdicts behind.", "callout"))

    s.append(H2("6.4 Refusals"))
    s.append(table([
        ["code", "HTTP", "When"],
        ["self_approval", "403", "The actor submitted the pool, or is one of its frozen author emails."],
        ["wrong_team", "403", "The actor does not hold the step's role for the pool's team (or *)."],
        ["already_signed", "403", "The actor already signed an earlier step of this cycle."],
        ["not_submitter", "403", "Withdraw by anyone other than the submitter."],
        ["(route) 403", "403", "Missing permission for the team; another team's review/history; moving a pool to a team you cannot author for."],
        ["not_pending", "409", "Approve / review / return / withdraw on a pool that is not waiting for approval."],
        ["already_pending", "409", "Submit while a cycle is already open."],
        ["no_chain", "409", "Submit when no approval steps are configured."],
        ["no_step", "409", "A pending pool with no step left (should not happen; an admin must check its chain)."],
        ["(route) 409", "409", "Editing or deleting a pending pool; publish failing because the draft vanished."],
        ["comment_required", "400", "A return with no reason, or a rejected question with no comment."],
        ["no_verdicts", "400", "A review with no verdicts."],
        ["invalid_verdict", "400", "A verdict that is neither approved nor rejected. Nothing is written."],
        ["(route) 400", "400", "A review missing a verdict for some question, or naming a question not in the pool."],
        ["unknown_team", "400", "Submit / force publish naming a team that does not exist."],
        ["(route) 404", "404", "No such pool; no draft to submit or publish."],
        ["(route) 401", "401", "Not signed in (or signed in with the legacy shared login, which has no user id)."],
    ], [30 * mm, 13 * mm, W - 43 * mm], bold_first=True))

    # 7 API
    s += H1("7. API reference")
    s.append(P(f"All routes are under {C('/api/question-pools')}, mounted in {C('app/main.py')} behind the signed-in check."))
    s.append(table([
        ["Method + path", "Permission", "Purpose"],
        ["GET /kinds", "pools.view", "Question kinds + their fields, so the editor renders from data."],
        ["POST /assets?kind=", "pools.edit", "Upload media; returns the stored name."],
        ["GET /assets/{name}", "pools.view", "Asset bytes for preview."],
        ["GET ''", "pools.view", "List: built-ins + published + drafts you may see, with state, workflow, has_draft, steps."],
        ["POST ''", "pools.edit (team)", "Create a pool as a draft."],
        ["GET /{id}", "pools.view", "Open a pool: your visible draft, else published, else a built-in."],
        ["PUT /{id}", "pools.edit (current + new team)", "Save edits to the draft. 409 while pending."],
        ["DELETE /{id}", "edit / publish (team)", "Delete draft and/or published copy. 409 while pending."],
        ["POST /duplicate", "pools.edit (team)", "Copy a custom or built-in pool into a new draft."],
        ["GET /{id}/for-phase?token=&kind=", "pools.view", "PUBLISHED questions for an interview phase (copies media into it)."],
        ["GET /{id}/export", "pools.view", "Published pool as YAML (built-in file shape)."],
        ["GET /approvals/queue", "pools.approve", "Pools whose next step you are allowed to sign."],
        ["GET /{id}/review", "pools.view + team visibility", "Review screen data: questions, status, verdicts so far."],
        ["POST /{id}/review", "pools.approve", "Per-question verdicts (\"Approve all\" uses this too)."],
        ["GET /{id}/history", "pools.view + team visibility", "Ledger rows + current status."],
        ["POST /{id}/submit", "pools.submit (team)", "Open a review cycle."],
        ["POST /{id}/approve", "pools.approve", "Sign the next step of the whole pool."],
        ["POST /{id}/return", "pools.approve", "Return with a required comment."],
        ["POST /{id}/withdraw", "pools.submit", "Submitter withdraws."],
        ["POST /{id}/publish", "pools.publish (team)", "Force publish (break-glass)."],
    ], [52 * mm, 44 * mm, W - 96 * mm]))
    s.append(Spacer(1, 4))
    s.append(P(f"Related routes in {C('app/main.py')}: {C('GET /api/me/permissions')} (who am I, what may I do), "
               f"{C('GET /api/dev/accounts')} and {C('POST /api/dev/login')} (dev sign-in, 404 unless enabled)."))
    s.append(P("Request bodies", "h3"))
    s.append(code('PUT /api/question-pools/{id}\n'
                  '{ "pool_name": "Sharding", "description": "", "pool_kind": "spoken", "team": "backend",\n'
                  '  "questions": [ { "id": "q1", "kind": "spoken", "text": "...", "topic": "databases",\n'
                  '                   "difficulty": "medium", "coverage_tags": ["partition key"] } ] }\n\n'
                  'POST /api/question-pools/{id}/review\n'
                  '{ "verdicts": [ { "question_id": "q1", "verdict": "approved", "comment": "" },\n'
                  '                { "question_id": "q2", "verdict": "rejected", "comment": "Name the trade-off." } ] }\n\n'
                  'POST /api/question-pools/{id}/submit | approve | return | publish\n'
                  '{ "comment": "optional, required for return" }'))

    # 8 frontend
    s += H1("8. Frontend")
    s.append(table([
        ["File", "What it does"],
        ["pages/QuestionPools.tsx", "The list. A card per pool with the state pill and the workflow bar (Submit, Approve, Return, Withdraw, Publish without review)."],
        ["pages/QuestionPoolEditor.tsx", "Create / edit. The whole form sits in ONE <fieldset disabled> when you may not edit, so read-only cannot be partial. Shows each checker comment against its question. Edit rights follow the pool's saved team."],
        ["pages/PoolApprovals.tsx", "The checker's queue (GET /approvals/queue); primary action is \"Review N questions\"."],
        ["pages/PoolReview.tsx", "Per-question Approve / Reject, Approve all, a sticky counter, required rejection comments. Nothing is sent until \"Submit review\"."],
        ["components/PoolWorkflow.tsx", "State pill, action buttons, history. Buttons depend on BOTH the pool's state and your permission — which is why the same pool shows different actions to different people."],
        ["lib/questionPools.ts", "Typed API client (listPools, getPool, updatePool, submitPool, approvePool, reviewPool, poolReview, poolHistory, …) and labels."],
        ["lib/auth.ts", "usePermissions() (GET /api/me/permissions), can(me, perm, team), teamsFor(me, perm)."],
        ["App.tsx", "Routes: /question-pools, /question-pools/approvals, /question-pools/:poolId/review, /question-pools/:poolId."],
    ], [44 * mm, W - 44 * mm], bold_first=True))
    s.append(H2("8.1 What each person sees"))
    s.append(table([
        ["Person", "Pool list", "Editor", "Approvals / review"],
        ["Author (backend)", "Backend drafts + all published pools; Submit on their drafts", "Editable for backend pools; read-only for others", "No access (no pools.approve)"],
        ["Checker (backend)", "Backend drafts + published; Approve / Return on pending backend pools", "Read-only", "Queue of backend pools; review screen"],
        ["Central checker (*)", "Every team's drafts", "Read-only", "Every team's pending pools"],
        ["Admin", "Everything; \"Publish without review\" where a draft exists", "Editable", "Everything"],
        ["HR", "No pools page (403 on every route)", "—", "—"],
    ], [30 * mm, 52 * mm, 45 * mm, W - 127 * mm], bold_first=True))

    # 9 files
    s += H1("9. File-by-file reference")
    fw = [46 * mm, W - 46 * mm]
    s.append(H2("app/rbac.py — who may do what"))
    s.append(table([
        ["Name", "What it does and why"],
        ["POOL_ / INTERVIEW_ / ADMIN_ / ALL_PERMISSIONS", "The closed vocabulary; nothing outside it can be granted."],
        ["is_valid_permission / validate_permission", "Check (or raise on) a permission name, so a typo fails loudly."],
        ["grants_for(user_id)", "All of a person's grants as {permission: {team}} in one query; {} if inactive."],
        ["has_permission(user, perm, team)", "The core yes/no. Team or * passes; no team = anywhere; fails closed."],
        ["ensure_permission(user, perm, team, detail)", "Raise a 403 with a readable message unless allowed (used by routes after loading a pool)."],
        ["permitted_teams(user, perm)", "Teams a person holds a permission for — used to tell them which teams they CAN pick."],
        ["current_user_id / _signed_in", "Read the user id from the cookie; 401 if missing."],
        ["require(perm, team_param) / require_any(perms)", "FastAPI route guards."],
        ["user_by_email / describe_user", "Look up a person; build the /api/me/permissions payload."],
        ["dev_login_enabled()", "True only when DEV_LOGIN_ENABLED is set."],
    ], fw, bold_first=True))
    s.append(H2("app/rbac_seed.py — the policy"))
    s.append(table([
        ["Name", "What it does and why"],
        ["TEAMS, ROLES, ROLE_PERMISSIONS, DEFAULT_CHAIN, SEED_USERS", "The policy as data (section 3)."],
        ["seed_rbac()", "Runs at startup; adds whatever is missing. The grid is written only when the table is EMPTY, and nothing is ever removed."],
        ["_ids_by_key", "Create missing team/role rows matched on key; return {key: id}."],
        ["seed_users_summary()", "Accounts listed by the dev sign-in chooser."],
        ["ensure_user(email)", "Find or create a person by email (for future sign-in)."],
    ], fw, bold_first=True))
    s.append(H2("app/approval_service.py — the workflow"))
    s.append(table([
        ["Name", "What it does and why"],
        ["ApprovalError(message, code, status)", "Every refusal; the routes turn it into the HTTP status."],
        ["submit / approve / review / return_pool / withdraw / force_publish", "The transitions (section 6.2)."],
        ["pool_status / pool_states", "Current state of one pool / many pools in one query."],
        ["history / question_reviews / queue_for", "Ledger rows for the history panel; latest verdict per question (falls back to the last reviewed cycle so the author sees feedback after a return); a checker's to-do list."],
        ["_derive", "Computes the state from ledger rows (section 6.1)."],
        ["_pending", "Locks the pool and loads rows/status/next step, refusing unless pending."],
        ["_lock", "Postgres advisory lock per pool, so two checkers acting at once take turns."],
        ["_completes_chain / _publish / _after_commit", "Does this signature finish the chain? Run the publish + record it; run the draft cleanup after commit."],
        ["_refuse_unless_can_sign (+ _self_approval, _wrong_team, _signing_twice)", "All signing checks in one place, used by approve, review and the queue — so they cannot disagree."],
        ["_chain_rows / _team / _ledger / _opened / _record / _audit", "Lookups and the two writers (ledger row, audit row)."],
    ], fw, bold_first=True))
    s.append(H2("app/question_pools.py — the pool document and storage"))
    s.append(table([
        ["Name", "What it does and why"],
        ["QuestionPool, PoolQuestion, CodingBlock, ScenarioBlock, CodingTestCase", "Pydantic models; validators normalise and refuse bad input per kind."],
        ["save_draft / load_draft / has_draft / delete_draft / list_drafts", "Draft prefix."],
        ["save_pool / load_pool / delete_pool / list_pools", "Published prefix. load_pool is what interviews use."],
        ["load_editable", "Draft if there is one, else published — what authors and checkers work on."],
        ["stage_draft / stage_approved (+ publish_draft / publish_approved)", "Publishing (section 5.2)."],
        ["store_asset / load_asset / copy_asset_to_session", "Media upload, preview, and copying into an interview."],
        ["_path / _save / _load / _delete / _list", "Shared storage helpers; _path refuses unsafe ids."],
    ], fw, bold_first=True))
    s.append(H2("app/question_pool_routes.py — the HTTP layer"))
    s.append(table([
        ["Name", "What it does and why"],
        ["_as_http", "Maps ApprovalError (and, where asked, ValueError → 409) to HTTP responses."],
        ["_draft_visibility / _may_see_draft / _visible_editable", "The draft-visibility rule (3.6); 403 for another team's review or history."],
        ["_team_of / _team_refusal / _actor_email / _stamp_new / _saved_draft", "Small shared helpers: a pool's team (blank = *), a refusal naming your teams, author stamping, the saved response."],
        ["_validated / _first_error", "Body → QuestionPool, with a readable 400."],
        ["route functions", "One per row of section 7."],
    ], fw, bold_first=True))
    s.append(H2("Other files"))
    s.append(table([
        ["File", "Role"],
        ["app/constants.py", "POOL_DRAFT / PENDING / PUBLISHED / BUILTIN, POOL_SOURCE_*, ACTION_*, QUESTION_APPROVED / REJECTED, GLOBAL_TEAM. No imports."],
        ["app/main.py", "Mounts the router behind the signed-in check, runs seed_rbac() on startup, /api/me/permissions, dev sign-in."],
        ["db/models.py", "The nine tables (section 4)."],
        ["tests/test_rbac.py", "Permission checks, fail-closed behaviour, grants."],
        ["tests/test_pool_approvals.py", "Storage split, chain, refusals, two-step chains, force publish, queue, HTTP round trips, team scoping."],
        ["tests/test_pool_question_review.py", "Per-question review: partial publish, rejected edits keep live wording, refusals before writes, history."],
        ["tests/test_question_pools.py", "Pool model validation and storage for every question kind."],
    ], fw, bold_first=True))
    s.append(P(f"Note: {C('.gitignore')} ignores the {C('tests')} folder, so new test files need {C('git add -f')}.", "small"))

    # 10 operations
    s += H1("10. Operating it")
    s.append(H2("10.1 Run locally"))
    s.append(P("The tiered stack runs from pre-built images, so rebuild after a code change (Windows PowerShell):"))
    s.append(code('podman build -f deploy/Dockerfile.base -t interview-agent-base:local .\n'
                  'foreach ($t in "gateway","worker","session","text") {\n'
                  '  podman build -f "deploy/Dockerfile.$t" --build-arg BASE_IMAGE=interview-agent-base:local -t "interview-agent-${t}:local" .\n'
                  '}\n'
                  'podman compose -f deploy/local/docker-compose.yml up -d\n'
                  '# open http://localhost:8080/app  ->  Question pools'))
    s.append(P(f"macOS / Linux: {C('CONTAINER_CMD=podman bash deploy/build_tiers.sh local')} then the same compose command. "
               f"Add {C('DEV_LOGIN_ENABLED=1')} to {C('deploy/local/.env')} to sign in as the seeded accounts."))
    s.append(H2("10.2 Run the tests"))
    s.append(code('podman run --rm -v "${PWD}:/app:ro" -w /app localhost/interview-agent-base:local sh -c \\\n'
                  '  "pip install -q pytest pytest-asyncio && python -m pytest tests/test_pool_approvals.py \\\n'
                  '   tests/test_pool_question_review.py tests/test_question_pools.py tests/test_rbac.py -q"'))
    s.append(H2("10.3 Change who may do what"))
    s.append(P("Use the <b>Access</b> screen, signed in as a Platform Admin: People for grants, Teams for the approval "
               "chain, Roles for the permission grid. The routes and the refusals are in the RBAC reference. The seed "
               "still only <b>adds</b> rows, and it writes the grid only into an empty table, so editing "
               f"{C('app/rbac_seed.py')} does not change a database that already has those rows. The SQL below still works:"))
    s.append(code("-- give someone the checker role for the qa team\n"
                  "INSERT INTO app_user_roles (user_id, role_id, team_id)\n"
                  "SELECT u.id, r.id, t.id FROM app_users u, app_roles r, app_teams t\n"
                  " WHERE u.email = 'someone@centific.com' AND r.key = 'pool_checker' AND t.key = 'qa';\n\n"
                  "-- revoke it\n"
                  "DELETE FROM app_user_roles WHERE user_id = (SELECT id FROM app_users WHERE email = 'someone@centific.com')\n"
                  "  AND role_id = (SELECT id FROM app_roles WHERE key = 'pool_checker')\n"
                  "  AND team_id = (SELECT id FROM app_teams WHERE key = 'qa');\n\n"
                  "-- switch an account off entirely (holds no permissions afterwards)\n"
                  "UPDATE app_users SET is_active = false WHERE email = 'someone@centific.com';"))
    s.append(H2("10.4 Add a second approval level for a team"))
    s.append(code("INSERT INTO app_approval_steps (team_id, step_no, approver_role_id, name, is_active)\n"
                  "SELECT t.id, 1, r.id, 'Team lead', true FROM app_teams t, app_roles r\n"
                  " WHERE t.key = 'backend' AND r.key = 'pool_checker';\n"
                  "INSERT INTO app_approval_steps (team_id, step_no, approver_role_id, name, is_active)\n"
                  "SELECT t.id, 2, r.id, 'Governance', true FROM app_teams t, app_roles r\n"
                  " WHERE t.key = 'backend' AND r.key = 'pool_checker';"))
    s.append(P("The same change is the approval chain under that team on the Access screen. Once a team has its own rows "
               "it stops using the * chain. Cycles already pending keep the chain they were submitted with; new "
               "submissions use the new one. The two steps must be signed by two different people."))
    s.append(H2("10.5 Troubleshooting"))
    s.append(table([
        ["Symptom", "Likely cause"],
        ["401 \"sign-in required\" on every pool route", "Signed in with the legacy shared admin login (no user id). Use dev sign-in / an app_users account."],
        ["403 on a pool you can see", "Your grant is for a different team; the message names the teams you hold."],
        ["Submit button missing", "No draft behind the pool, it is already pending, or you lack pools.submit for its team."],
        ["Approve missing for a checker", "You submitted or authored it, already signed this cycle, or hold the role for another team."],
        ["409 when saving", "The pool is pending — withdraw it first."],
        ["Another team's draft not listed", "By design: drafts are visible to that team's authors and checkers only."],
        ["Code change not visible locally", "Images were not rebuilt (compose uses image:, not build:)."],
    ], [62 * mm, W - 62 * mm], bold_first=True))

    # 11 changes
    s += H1("11. Changes in this round (12 Oct 2026)")
    s.append(H2("11.1 Clean-up (no behaviour change)"))
    s += bullets([
        "app/constants.py created: every state / action / verdict string and GLOBAL_TEAM in one place.",
        "Repeated code turned into shared helpers (team lookup, ledger writers, storage helpers, permission checks, error mapping).",
        "One-line docstrings on every function in the five backend files; comments trimmed to the ones that state a rule.",
    ])
    s.append(H2("11.2 Bugs fixed (each pinned by a test that fails on the old code)"))
    s.append(table([
        ["Severity", "Bug", "Fix"],
        ["Critical", "A partial review published the approved questions BEFORE any refusal ran — an author or a wrong-team checker could put content live; the ledger showed only \"returned\".",
         "Review is one transaction; every signing check runs first; approved/published/returned rows + audit are recorded."],
        ["High", "An author could move another team's pool into their own chain by naming their team on save (the editor even did it automatically for all-teams pools).",
         "Save checks the pool's current team and the new team; the editor no longer auto-fills the team on existing pools."],
        ["High", "\"Approve all\" on the review screen and \"Approve\" in the queue published different results (deleted questions stayed live).",
         "When every question is approved, both publish the draft as-is."],
        ["Medium", "Anyone with pools.view could read another team's draft, verdicts and comments via review/history.", "403 unless you may see that team's drafts."],
        ["Medium", "Verdicts were saved before the refusal check.", "Saved in the same transaction, after the checks."],
        ["Medium", "Force publish was not team-scoped.", "Needs pools.publish on the pool's team."],
        ["Medium", "A force publish after a return read as \"draft\" while live.", "State derivation recognises a later force publish."],
        ["Medium", "Two checkers at once could both sign; a failed commit left a pending pool with no draft.", "Per-pool lock (Postgres); draft cleanup only after commit."],
        ["Medium", "A partial review on step 1 of a 2-step chain published immediately.", "Nothing goes live until the last step."],
        ["UI", "Submit / force-publish shown for pools with no draft (old pools, built-ins).", "Driven by the real file state; no workflow bar on built-ins."],
    ], [17 * mm, 85 * mm, W - 102 * mm]))
    s.append(H2("11.3 Known limitations / not done"))
    s += bullets([
        "Access screens for people, teams, chains and the role grid are built. They are documented in rbac-authentication-reference.pdf, not here.",
        "Interview pages are hidden by role. The interview APIs still only check that someone is signed in.",
        "No notifications: a checker finds work only by opening the queue.",
        "The clickable development accounts have no password. Keep DEV_LOGIN_ENABLED off outside local. The seed still creates the seven test accounts, including two admins.",
        "On SQLite (local only) there is no per-pool lock. If a commit fails after the live file was written, the live pool is ahead of the ledger until the action is retried.",
        "Smaller UI items remain: the editor allows typing into a pending pool (Save then 409); a few buttons are shown that the server will refuse; the editor does not refresh after approve/withdraw.",
    ])
    return s


def main() -> None:
    doc = Doc(OUT)
    doc.multiBuild(build())
    print("wrote", OUT)


if __name__ == "__main__":
    main()
