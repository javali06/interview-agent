# Plan: Scale the AI Interview Engine into tiered services (`interview-scaled-dev`)

## Context

`Interview_agent_app/` is a GenAI autonomous interviewer: recruiters schedule
candidates, generate interview + observer links, and the system runs a live
voice interview in the browser (plus job-profile creation, resume shortlisting,
interview generation).

Today it deploys as **one Azure App Service container** (`interview-ai-backend`,
Linux B3, gunicorn `--workers 1`). Concurrent interviews already work *inside one
process* via a module-level `_token_sessions` dict (`deploy/azure_app.py:644`),
but that dict **is the ceiling**: single worker, single core, ~20 concurrent. A
browsing spike also starves live interviews of CPU because web/API, live
interviews, and slow LLM work (cadence-gen ~10s, evaluation, shortlist scoring)
all share the one box and run **inline in the request path**.

The target design (`Interview-Agent-Architecture-Scaled.docx`) splits the
monolith **by scaling profile**, bounded by the ~900ms turn budget — the live
loop is never split across the network. This plan implements that split.

**Decisions (confirmed with user):**
- **Distributed-only implementation.** The new branch builds the multi-tier
  system directly — **no in-process/inline fallbacks, no feature flags**. Redis,
  the job queue, Postgres, and the capacity broker are **hard dependencies**. The
  live session objects (broadcaster/brain) inherently stay in-memory on their
  pinned replica; Redis holds only the routing pointer + admission + pub-sub
  ("Redis points to the truth").
- **`demo-prod` is preserved untouched** as the rollback monolith. All work is on
  a new branch **`interview-scaled-dev`** cloned from `demo-prod` — it carries the
  full existing code (engine/brain, UI, services) and refactors it toward the
  distributed tiers.
- **Full Azure Container Apps** target (per doc), behind Front Door.
- **User provisions Azure**; I deliver idempotent Bicep + `az` scripts + a
  resource/cost list.

## Step 0 — Save this plan into the repo

Create branch `interview-scaled-dev` off `demo-prod` and commit this document to
`docs/scaling-architecture-plan.md` so it is versioned, shareable, and travels
with the branch.

## Target tiers

| Tier | Type | Role |
|---|---|---|
| Azure Front Door | managed | one public address; TLS; `/*`→gateway, `/ws/*`→gateway (which proxies to the owning session shard) |
| Gateway | ACA (stateless) | SPA + `/api/*`, auth, eval-read/results/downloads, bulk control, **WS reverse-proxy** to session shards |
| Session | ACA (stateful, pinned) | live interview: candidate+observer WS, brain/director, Stream A, events.jsonl. Shard-addressed replicas |
| Redis | managed | **scale-out unlock**: token→replica registry, admission counters, locks, observer/hint pub-sub |
| Workers + queue | ACA | cadence-gen, rubric-gen, shortlist scoring, eval-v2, recording-finalize, webhooks, bulk, invites |
| Capacity/Speech broker | ACA + Redis | multi-key Speech rotation, STT fallback (Azure↔Groq), LLM timeout/backup, cluster-wide admission |
| Data plane | managed | Postgres (system of record), Blob (recordings/eval/exports), events.jsonl |

## Current-state findings (what's already true)

- **Head start:** DB is already Postgres-ready via `DATABASE_URL` with portable
  column types (`db/engine.py:43-51`); Blob already mirrors `events.jsonl`,
  `evaluation.json`, and recordings (`app/blob_store.py`).
- **Speech is Azure everywhere** (STT + TTS). Kokoro TTS and local Whisper STT are
  lazy/optional imports and unused in the tiered deploy, yet the current monolith
  image still bakes torch/torchaudio/transformers/accelerate/spacy + a ~350 MB
  Kokoro model (~1.5 GB dead weight). The only local speech component is **Silero
  VAD** on `onnxruntime` against a baked `silero_vad.onnx` (`azure_app.py:109`).
  `_spawn_stream_a` (`azure_app.py:135`) currently spawns VAD + a (Kokoro) TTS
  subprocess → the tiered session tier spawns **VAD only**.
- **The single scale blocker:** `_token_sessions` dict + `_evict_session_orphans`
  (`deploy/azure_app.py:644-691`); WS handlers `candidate_ws` / `observer_ws`
  (`azure_app.py:719-1017`) read/write it directly. It maps token→live in-memory
  session; only ONE replica can see it → **replaced outright by the Redis registry.**
- **All session state is process-local** and cannot move replicas mid-interview
  (`SessionState`, `CadenceTracker`, `Director`, `WebBroadcaster`, TTS client) —
  but `events.jsonl` + `cadence.yaml` are the replay source of truth. So the
  design **pins** an interview to its replica and externalizes only the routing
  pointer, not the live objects.
- **No queue / worker / Redis / broker exist.** Slow jobs run inline:
  cadence-gen (`app/cadence_service.py:461`) in `POST /api/schedule`; eval v1/v2
  post-session (`app/plugin_evaluation.py`); shortlist scoring in
  `POST /api/shortlist/score` (`features/shortlist/routes.py`).
  → **all moved to the worker tier.**
- **Speech:** single `AZURE_SPEECH_KEY`, no rotation/admission; 5 concurrent
  streams/key is the external cap. Known event-loop blockers noted in
  `deploy/README.md:208` (sync `parse_resume`, `JsonlEventLog.write`, sqlite
  writes) will bite harder at scale → fixed.
- **Infra:** subscription *AzureSimple Pactera* `da74e3ed-9c9a-4605-8fae-10f3492c0f5c`,
  RG `AI-COE`, ACR `interviewagentacr`, existing Storage account (Blob) + one
  Azure Speech resource.

## Proposed approach

**Guiding rule:** build each tier as its distributed implementation directly.
No dual impls, no fallback branches. **Each tier ships its own right-sized Docker
image** built on a shared base, so each ACA app scales, deploys, and cold-starts
independently. Crucially, since **STT + TTS are Azure everywhere**, the tiered
images **drop the ~1.5 GB Kokoro/Whisper stack** (`torch`, `torchaudio`,
`transformers`, `accelerate`, `spacy` + the ~350 MB baked model) that the current
monolith image carries but never uses in cloud — the only local speech component
is Silero VAD on `onnxruntime`. Result: session = *moderate* (Azure Speech SDK +
Silero VAD + audio libs), gateway/worker = *slim*. A
`deploy/local/docker-compose.yml` (Redis + Postgres + Azurite for the
Storage-Queue emulator) lets the full distributed stack run on a laptop for
dev/test, since there is no single-box path.

### WS0 — Coordination plane (Redis) — the unlock
New package `app/coordination/`:
- `client.py` — Redis client from `REDIS_URL` (**required**; app refuses to start without it).
- `registry.py` — `SessionRegistry`: token→{shard_fqdn, created_at} + TTL
  heartbeat. **Replaces** the `_token_sessions` dict access in
  `azure_app.py:644-897`; the local `_SessionHandle` map stays per-replica (live
  objects), only the routing pointer is shared. Distributed orphan eviction driven
  off registry TTL.
- `admission.py` — atomic Redis counters + caps: `active_sessions`,
  `speech_streams:{key_id}`, `llm_inflight`; `try_admit()`/`release()`.
- `locks.py` — `SET NX PX` claim/approve lock (stops a token starting on two shards).
- `pubsub.py` — `obs:{token}` (transcript/events fan-out) / `hint:{token}` (steer back to owning shard).

### WS1 — Session tier (stateful, pinned)
- Keep the existing engine (`deploy/azure_app.py` runner + broadcaster + brain),
  rebuilt around the registry. On new-session: `locks.claim(token)` →
  `admission.try_admit()` → `registry.claim(token, self_fqdn)`; heartbeat while
  alive; `release` on end/evict.
- **Shard-addressed replicas:** run the session tier as a pool of single-replica
  ACA apps `session-0..N`, each with a stable internal FQDN (ACA default ingress
  can't target a specific replica; shard-per-app gives replica-addressable
  routing). Token→shard chosen at claim (least-loaded via admission counters),
  stored in the registry.
- **Azure-only speech:** wire STT + TTS to Azure Speech via the broker (WS4);
  reduce `_spawn_stream_a` (`azure_app.py:135`) to spawn **VAD only** (Silero/onnx).
  No Kokoro/Whisper subprocesses. Adjust `/health` accordingly.
- Fix the flagged event-loop blockers (`run_in_executor` for
  `JsonlEventLog.write`, resume parse, DB writes) so one replica can host many
  concurrent sessions without stalling the ~900ms loop.

### WS2 — Gateway tier (stateless)
- New `deploy/gateway_app.py`: reuses `app/main.py` routes (SPA, `/api/*`, auth,
  eval/results/downloads, bulk) via the existing `_attach_admin_routes` pattern,
  **minus** the in-process session runner.
- New `app/gateway/ws_proxy.py`: on `/ws/candidate|observer/*`, look up the
  owning shard in the registry (assign one, admission-gated, if none) and
  reverse-proxy the WebSocket over the ACA internal network.
- Serve eval results/downloads **read-through from Blob** so a stateless gateway
  replica needs no session-local disk.

### WS3 — Worker tier + queue
New package `app/jobs/`:
- `queue.py` — **Azure Storage Queue** client (reuses the existing storage
  account — near-zero new cost; Service Bus is a swap-in if richer DLQ is wanted).
- `jobs.py` — handlers that wrap **existing** service fns: cadence-gen
  (`cadence_service.generate_cadence_yaml`), eval-v2
  (`plugin_evaluation.generate_evaluation_v2`), shortlist (`features/shortlist`
  scorer), rubric-gen, recording-finalize, webhook, bulk-export, invite-dispatch.
- `status.py` — job status in a new Postgres `jobs` table (gateway polls it).
- `worker.py` — worker entrypoint: pull → dispatch → retry+backoff → dead-letter;
  KEDA scales on queue depth (→0 idle).
- Enqueue points: `POST /api/schedule` (cadence), post-session eval, shortlist,
  bulk — each **enqueues and returns instantly** (drafts/job-ids), work finishes
  in the worker.

### WS4 — Capacity / Speech broker
New package `app/broker/`:
- `speech_pool.py` — multi-key rotation from `AZURE_SPEECH_KEYS` (N×5 streams via
  Redis `speech_streams:{key_id}` counters).
- `stt_fallback.py` — Azure↔Groq failover (both clients already exist:
  `azure_stt_client`, `groq_stt_client`).
- `llm_guard.py` — LLM call timeout + backup-model failover + `llm_inflight`
  admission, wrapping the AsyncOpenAI calls in `interview_session`.
- Session calls `broker.acquire()` before Stream A start (admits only when a
  Speech slot AND LLM headroom exist), `release()` on end.

### WS5 — Data plane
- Postgres becomes the **only** DB (SQLite path removed for the tiered deploy):
  pool tuning via env (`DB_POOL_SIZE`/`DB_MAX_OVERFLOW`); add `jobs` table to
  `db/models.py`; one-shot `scripts/migrate_sqlite_to_postgres.py` to lift any
  existing prod data.
- Blob read-through in eval/download routes (WS2).
- events.jsonl stays the per-session append log on the owning shard, mirrored to
  Blob (already wired) for durable replay.

### WS6 — Deploy / IaC (ACA + Front Door)
- `deploy/aca/main.bicep` + `deploy/aca/provision.sh`: ACA environment; container
  apps gateway / worker / session-0..N; Azure Cache for Redis; Storage Queue (on
  existing account); Postgres Flexible Server; Front Door; references to existing
  ACR/Storage/Speech; managed identity for ACR pull + Storage/Speech.
- KEDA scale rules: gateway on HTTP concurrency; worker on queue depth (→0);
  session shards fixed 1 replica each.
- Front Door routes: `/*`→gateway, `/ws/*`→gateway (registry-aware proxy lives in
  the gateway, not Front Door — the practical ACA equivalent of the doc's
  "Front Door reads the registry"). Deviation intentional and noted.
- **Per-tier images on a shared base** (replaces today's single `deploy/Dockerfile`),
  with **split requirements** under `deploy/requirements/`:
  - `deploy/Dockerfile.base` (`base.txt`) — OS deps + Python venv + shared web/data
    deps (fastapi, uvicorn, websockets, sqlalchemy, psycopg, redis,
    azure-storage-blob/queue, openai, pyyaml, langfuse, bcrypt/itsdangerous) +
    shared repo code (`app/`, `engine/brain`, `db/`, `config/`). **No torch/Kokoro.**
  - `deploy/Dockerfile.gateway` (`gateway.txt`≈base) — `FROM base` + SPA build
    stage; slim, no audio/native libs.
  - `deploy/Dockerfile.worker` (`worker.txt`) — `FROM base` + eval/resume deps
    (attachments, features/eval + shortlist extras); no audio stack.
  - `deploy/Dockerfile.session` (`session.txt`) — `FROM base` + Azure Speech SDK
    (`azure-cognitiveservices-speech`) + native libs (libssl3, libasound2, ffmpeg)
    + audio (numpy, soundfile, onnxruntime, silero-vad) + baked `silero_vad.onnx`.
    **Drops torch/torchaudio/transformers/accelerate/spacy + the Kokoro model bake.**
  - Each has its own entrypoint; each ACA app pins its own image tag.
    `deploy/build_and_push.sh` extended to build base → 3 tier images.
- `deploy/local/docker-compose.yml` for the full local stack (Redis + Postgres +
  Azurite + the three tier images). Update `.env.example`, `CLAUDE.md`, `deploy/README.md`.

## Azure resources needed (you provision; I supply Bicep + `az` scripts)

**New:**
1. **Azure Cache for Redis** — coordination plane (registry/admission/locks/pubsub). *The* unlock. Standard C1 ≈ $40–80/mo (Basic C0 fine for dev).
2. **Azure Container Apps environment** + apps: `gateway`, `worker`, `session-0..N`. Consumption + dedicated for session shards (~1 vCPU each). Cost scales with replicas/concurrency.
3. **Azure Storage Queue** — job queue on the **existing** storage account (≈ free). *(Alt: Azure Service Bus Standard ≈ $10/mo for richer dead-letter.)*
4. **Azure Database for PostgreSQL** — **REUSED**: the existing server from the previous iteration (passed as `DATABASE_URL`; not provisioned). The tiered schema (jobs table + additive columns) self-creates on first boot.
5. **Azure Front Door** — Standard ≈ $35/mo + traffic.
6. **Additional Azure Speech (Cognitive Services) resources** — one key = 5 concurrent streams; add as many as the concurrency target needs (pay-per-use).

**Reused (no new spend):** ACR `interviewagentacr`, existing Storage account
(Blob + Queue), existing Azure Speech resource. App Service `interview-ai-backend`
(the `demo-prod` monolith) stays live as rollback during cutover, then retire.

**Networking:** Redis + Postgres on private endpoints in the ACA VNet; managed
identity for ACR/Storage/Speech (no keys in env where avoidable).

## Verification

Dev-env note: no node toolchain; `.venv` may be empty — use a scratch venv
(`pydantic pyyaml openai pytest redis fakeredis azure-storage-queue`) for
pure-logic tests; the SPA typecheck runs in the ACR build stage.

1. **Unit tests (new):** coordination (registry/admission/locks/pubsub) against
   `fakeredis`; broker key-rotation + STT fallback; queue enqueue/consume; job
   handlers wrap existing services correctly. Existing brain tests
   (`pytest tests/`) still pass.
2. **Full local stack:** `docker-compose up` (Redis + Postgres + Azurite), start
   gateway + 2 session shards + worker; run one interview end-to-end (schedule →
   candidate + observer → post-session eval via the worker).
3. **Routing:** prove a candidate reconnect AND an observer both route through the
   gateway to the *owning* shard via the registry (kill/restart a shard → token
   re-claim behaves correctly).
4. **Worker:** `POST /api/schedule` returns a draft instantly; cadence-gen
   completes in the worker; job status flips to done; queue drains to zero.
5. **Broker:** 6 concurrent Speech acquires on a 1-key pool → 6th blocks or falls
   back to Groq; counters release on session end.
6. **Staged cloud cutover (after you provision):** deploy gateway + 1 session
   shard + worker to ACA behind Front Door; one end-to-end interview; then scale
   shards and load-test concurrency past the current ~20 ceiling. `demo-prod`
   stays as instant rollback.

## Out of scope (this branch)
- Media transport swap to WebRTC/ACS SFU (doc marks it deferred; the
  AudioSource/AudioSink seam is left untouched).
- Retiring the `demo-prod` App Service (kept as rollback until ACA cutover is validated).
- Auth hardening items from `deploy/README.md:198` (mandatory admin hash, WS token
  validation, key rotation) — flagged for a follow-up security pass; noted but not
  bundled here.
