# Scaling the session tier — phase-wise implementation plan

**Status:** Phase 1 in progress (foundation + token fixes done; the candidate page is next).
**Branch:** `feature/livekit-media` · **Tracking:** Azure DevOps feature **AB#34236**
· **Owner:** Sathwik Badda · **Last updated:** 2026-10-10

**Read with:** [livekit-implementation-plan.md](livekit-implementation-plan.md) (the step-by-step
execution checklist for Phase 1) and [reading/07-scaling-cost-and-decisions.md](reading/07-scaling-cost-and-decisions.md)
(ACA vs AKS cost, and how to measure interviews-per-shard).

---

## 1. Goal, in one paragraph

Let the live-interview tier **scale out automatically and survive bad networks**. Today every live
interview is pinned to one server ("shard") for its whole life, all of its audio and control traffic
squeezes through one WebSocket, and the recording is made in the candidate's browser. We move the
audio onto **LiveKit** (WebRTC), record on LiveKit's servers, take the interview's control messages
off the server's address, and then let the session tier run more than one replica safely.

## 2. Where we are today

| Area | State |
|---|---|
| LiveKit foundation (switch, room tokens, audio adapters, AI joins the room) | ✅ On `feature/livekit-media`, switched **off** — AB#34237 |
| Room tokens served by the gateway, only for live interviews | ✅ Done and verified against LiveKit Cloud — AB#34238 |
| Live observer | ✅ **Removed** — an interview is the AI and the candidate only — AB#34239 |
| LiveKit Cloud project + recording storage credentials | ✅ Created and verified locally (`interviewagentdata` / `sessions`) |
| Candidate page joining the room | ❌ Module exists (`ui/web/src/lib/livekitMedia.ts`) but nothing uses it |
| Server-side recording (composite egress) | ❌ No code yet |
| LiveKit settings in the Azure template (`deploy/aca/main.bicep`) | ❌ Missing |
| More than one replica per session app | ❌ Pinned to 1 (`scale: {minReplicas:1, maxReplicas:1}`) |
| Crash recovery granularity | Phase boundary only (a crash loses the current phase's turns) |

## 3. Why the session tier is pinned to one replica

An interview is **stateful and has exactly one owner**: the AI "brain" (turn-taking, speech
streams, the phase clock, the conversation so far) lives in one process's memory, and the
candidate's WebSocket must reach *that* process. On Azure Container Apps the platform load-balances
across replicas and **you cannot address a specific replica**, so each shard is its own one-replica
app, and the gateway routes each interview to its shard through the Redis registry
(`app/gateway/ws_proxy.py`). Running two replicas of one app would break "this address = the one
owning process". The gateway and worker tiers already autoscale because they hold no interview state.

## 4. What changed since the original plan

- **The observer is gone.** The old Phase 1 had an "observer audio → track" step, and the old Phase 2
  existed mostly to fan observer traffic out. Both shrink: a LiveKit room now has exactly two
  participants, the candidate and the AI.
- **Recording is composite egress, and the browser recording stays until egress is proven.** We
  will not delete anything that records interviews until the server-side recording has passed the
  parity test.
- **No more camera/screen snapshot uploads.** They only ever fed the observer and were removed with it.
  Camera and screen exist only as local previews plus the recording.
- **Two bugs in the foundation were fixed** (AB#34238): the token package was missing from the
  scaled images, and the gateway never handed the candidate the room details.

## 5. Collaborators

Names marked *proposed* are suggestions based on who built the related work. Confirm each before
work on that phase starts.

| Role | Who | Owns / approves | Phases |
|---|---|---|---|
| **Owner / driver** | Sathwik Badda | Implementation, branch `feature/livekit-media`, ADO feature AB#34236 | All |
| **LiveKit + session-tier reviewer** | Ayush Kothiyal *(proposed)* | Wrote the LiveKit foundation and the tiered architecture; reviews the audio path (1D) and the lease/drain work (Phase 3) | 1, 3 |
| **Capacity & cost** | PrabhudevGun2 *(proposed — confirm name)* | Wrote the ACA-vs-AKS cost analysis; measures interviews-per-shard before/after LiveKit; adds LiveKit charges to the cost model | 0, 1F, 3 |
| **Manual testing / QA** | *TBD* (Manual Testing & KT, AB#32787) | Runs the parity checklist and the canary interview | 1F, 1G, 3 |
| **Azure / IT admin** | *TBD* | Container App secrets, Bicep changes, storage access, firewall rules | 1G, 3 |
| **Product owner / manager** | *TBD* | LiveKit plan and billing approval; go/no-go for the canary and for switching LiveKit on | 0, 1G |
| **Legal / compliance** | *TBD* | Sign-off that candidate audio may transit LiveKit Cloud; the Terms & Conditions line about "any human interviewer or proctor who joins" | 0 (before real candidates) |

## 6. The phases at a glance

```mermaid
flowchart LR
    P0["Phase 0<br/>Baseline + approvals"] --> P1["Phase 1<br/>LiveKit media + server recording"]
    P1 --> P2["Phase 2<br/>Control off the brain's address"]
    P2 --> P3["Phase 3<br/>Lease + drain + autoscale"]
    P3 --> P4["Phase 4<br/>Per-turn checkpoints"]
    L["Lease fence fix<br/>(can start early)"] -.-> P3
```

| Phase | Goal | Depends on | Rough size* | Lead | Exit criteria |
|---|---|---|---|---|---|
| **0** | Measure today's capacity; get approvals | — | 2–3 days | Sathwik + Capacity | Baseline interviews-per-shard recorded; LiveKit plan + compliance approved |
| **1** | Audio on LiveKit; server-side recording | 0 | 4–6 weeks | Sathwik + Ayush | Parity test passed; one real interview on LiveKit in the cloud |
| **2** | Candidate control messages no longer need the brain's server address | 1 | 1–2 weeks | Sathwik | An interview runs end to end with no gateway WebSocket proxy |
| **3** | Session tier runs `maxReplicas > 1` safely and scales itself | 2 | 2–3 weeks | Sathwik + Ayush | Scale out under load, scale in without cutting a live interview |
| **4** | A crash loses one turn, not one phase | 3 (best after) | ~1 week | Sathwik | Mid-phase crash resumes at the last answer |

\* Rough person-time estimates for planning only — refine after Phase 1D, the least predictable piece.

---

## 7. Phase 0 — Baseline and approvals

**Why first:** every later number (cost, how many servers, whether LiveKit helped) needs a
before/after comparison, and the cloud rollout is blocked on approvals that take calendar time.

| # | Task | Lead | Done when |
|---|---|---|---|
| 0.1 | Measure **interviews-per-shard (C)** on today's WebSocket path with `scripts/loadtest_interviews.py` against one shard pinned to 1 vCPU (method: [08-observability-and-stress-test.md](reading/08-observability-and-stress-test.md)) | Capacity + Sathwik | C and the bottleneck (CPU / speech / LLM) recorded |
| 0.2 | Choose the LiveKit Cloud plan; confirm whether composite egress needs a paid tier | Product owner | Plan approved, billing set up |
| 0.3 | Compliance sign-off: candidate audio transits LiveKit Cloud (it leaves our Azure tenancy) | Legal | Written approval — **required before any real candidate uses LiveKit** |
| 0.4 | Decide the Terms & Conditions wording now that no human joins (bumps `TERMS_VERSION`) | Legal + Product owner | Decision recorded |

## 8. Phase 1 — LiveKit media and server-side recording

**Outcome:** the candidate's mic and the AI's voice travel over LiveKit; the interview is recorded on
LiveKit's servers into our storage. Everything sits behind `MEDIA_TRANSPORT=livekit`, so rollback is
an environment-variable change, not a redeploy.

| Step | What | Status | Lead | Size |
|---|---|---|---|---|
| **1A** | Foundation on current code, without RBAC | ✅ AB#34237 | Sathwik | done |
| **1B** | Room tokens from the gateway, live interviews only | ✅ AB#34238 | Sathwik | done |
| — | Observer removed (drops the old "observer audio → track" step) | ✅ AB#34239 | Sathwik | done |
| **1C** | Turn the switch on locally; confirm the AI joins the room and its audio adapters run | ✅ | Sathwik | done |
| **1D** | Candidate page joins the room (details below) | ✅ code + bot-verified; real-browser check open | Sathwik, review: Ayush | done |
| **1E** | Composite egress recording into `interviewagentdata` / `sessions/<token>/recording/` | ✅ audio | Sathwik | done |
| **1F** | Parity test + measure C again with LiveKit on | ◐ automated half done; by-ear + C open | QA + Capacity + Sathwik | M |
| **1G** | Cloud rollout: Bicep secrets, deploy with the switch off, one canary interview, then switch on | ◐ template ready; deploy needs go-ahead | Sathwik + Azure admin, go/no-go: Product owner | M |
| **1H** | Remove the old WebSocket audio path (only after LiveKit has been the default and stable) | ☐ | Sathwik | S |

### 1C — Server side on, locally
Set `MEDIA_TRANSPORT=livekit` in `deploy/local/.env` and start an interview. The AI joins room
`<interview token>` (`deploy/azure_app.py` session runner → `engine/orchestrator/livekit/transport.py`).
**Done when:** the room appears in the LiveKit Cloud dashboard with the AI agent in it, and the
session falls back to the WebSocket path cleanly if LiveKit is unreachable.

**Done (2026-10-08).** Verified on the local stack with a real interview through the gateway: the
agent joined room `<token>` in ~1.3 s and published `ai-voice`, and no AI audio went over the
WebSocket. With LiveKit pointed at an unreachable address, start-up waited
`LIVEKIT_CONNECT_TIMEOUT_S` (default 10 s) and then ran on the WebSocket. Three things had to change
to get there:
- **The AI-voice sink now honours the playout contract** (`LiveKitAudioSink`): a non-blocking
  `play_sync` (one feeder task, 20 ms frames), the same `expect_playout` / `mark_played` /
  `playout_done_event` ack as the WebSocket sink, and `bytes_buffered()` that stays busy until the
  audio has left the server AND the browser has acked it. Without this the silence timer and the
  goodbye hold would have run off generation time on LiveKit, which is the old farewell cutoff.
  Proven live against LiveKit Cloud with a simulated candidate: 640-byte frames in, 2.0 s of AI audio
  drains in 2.18 s, and a barge-in `flush()` silences it at once (`tests/test_livekit_sink.py` pins
  it offline).
- **The server now tells the page which transport it chose.** `/session-info` offers the room before
  the shard has tried to connect, so a page can't know about a fallback. The runner emits
  `{"type":"media_transport","transport":"livekit"|"websocket"}` on the control socket, and
  **1D must follow that message, not `/session-info`.** Otherwise a fallback means the page publishes
  into a room nobody reads, and the interview is silent.
- **Bug found while testing (not LiveKit):** a reconnect to a shard that had restarted, made before
  the token's registry entry expired, took `claim()`'s "already mine" branch. That branch returned no
  speech lease, so the runner crashed on `no azure_speech_key`. In other words, crash-resume after a
  shard restart was broken in the tiered deploy. `claim()` now *adopts* the token: it reuses the dead
  runner's admission slots, takes a fresh speech lease and re-registers
  (`app/session_tier/lifecycle.py::_adopt`).

### 1D — The candidate page (the biggest and riskiest step)
Wire `ui/web/src/lib/livekitMedia.ts` into `ui/web/src/lib/candidateEngine.ts`. A `livekit` block
from `/session-info` means the page MAY join the room early, to save time. The mic switches to the
room only when the server sends `media_transport: livekit`; on `websocket` the page leaves the room
and keeps today's path (see 1C). The control WebSocket stays for now (Phase 2 removes it).

| Concern | Today | With LiveKit |
|---|---|---|
| Mic to the AI | AudioWorklet PCM over the WebSocket | Publish a LiveKit mic track |
| Mic level meter / "you're muted" nudge | Worklet RMS | Keep the worklet, for metering only |
| Mute | Stop sending frames | `micTrack.mute()` / `unmute()` |
| AI voice playback | PCM queue → AudioContext player | Attach the AI's remote audio track |
| **"Finished playing" signal** ⚠️ | Browser sends `audio_playback_finished` per utterance | **Same message**, derived from the remote track's playout |
| Avatar lip-sync | Driven by the PCM chunks | Driven by the remote track (needs rework) |
| Recording mix (mic + AI) | Browser taps raw PCM | Unchanged until 1E is proven |

**The three hard parts:**
1. **"Finished playing" signal — highest risk.** The server times silence and the end-of-interview
   goodbye off it; getting it wrong is exactly what cut off the AI's farewell twice before (v10, v20).
   Keep the message byte-identical so `engine/orchestrator/web/audio_sink.py` and the wrap-up logic
   don't change. Dedicated parity check.
2. **48 kHz ↔ 16 kHz.** The brain is 16 kHz end to end; WebRTC is 48 kHz. Ask the SDK for 16 kHz
   (`AudioStream(sample_rate=16000)`) rather than resampling by hand — hand-rolled resampling is where
   the old mic-drift bug came from.
3. **Barge-in latency.** The jitter buffer may add a short tail; stop publishing on the VAD
   `speech_start` the brain already receives, and check the cutoff by ear.

**Done (2026-10-09).** What was built, and the decisions in it:
- **Join on "hello", not on page load.** The page joins only once the server has ACCEPTED its socket,
  so a tab refused as "in progress elsewhere" never joins and can't take over the candidate's room
  identity. The mic goes to the room only when the server says `media_transport: livekit`; on
  `websocket` the page leaves.
- **The server waits for the candidate before greeting** (`LiveKitTransport.wait_candidate_ready`:
  mic subscribed AND the AI's voice subscribed, `LIVEKIT_CANDIDATE_JOIN_TIMEOUT_S`, default 20 s). An
  SFU keeps nothing for late joiners, so greeting earlier loses the greeting. If the page never
  joins, its network can't reach LiveKit, and the interview falls back to the WebSocket. This also
  closes the "browser can't reach LiveKit" gap that 1C left open.
- **"Finished playing" from real playout.** After `audio_end` the page watches the AI track's level
  and sends the byte-identical `audio_playback_finished` once it has been quiet for 600 ms. Ayush's
  fixed 350 ms timer was replaced: `audio_end` means *generated*, and the voice can have seconds left.
- **Mic only.** The page publishes the lobby's existing mic track (never stops it, so the WebSocket
  fallback still has a mic); camera and screen are not published.
- **Avatars are off on LiveKit.** Both avatars lip-sync from raw PCM chunks, which a WebRTC track
  doesn't give the page, so the lobby offers only the orb when the interview may use LiveKit.
  Reworking the avatars to read the track is a follow-up.
- **Recording mix:** the AI's remote track is mixed into the browser recording instead of the PCM.
- **Refresh:** the page rejoins with the same identity; the agent's source follows the newest mic
  track (one pump task per track; a new track cancels the old). The broadcaster re-sends
  `media_transport` to any page that attaches.

### 1E — Server-side composite recording
Start a room-composite egress (audio + camera + screen once they are tracks) when the interview
starts; stop it at the end; write to `sessions/<token>/recording/` next to today's files; record
completion through the reserved `recording_finalize` worker job. Credentials:
`LIVEKIT_EGRESS_AZURE_*` (already set and verified locally). **The browser recording keeps running in
parallel** until 1F shows the egress file is complete and in sync; only then do we decide whether to
retire it.

**Done (2026-10-09), audio only:** a room-composite, audio-only egress (both voices) writes
`<token>/recording/livekit-audio.ogg` into the container the app already reads, and the admin
Recording tab shows it as "Server recording". It starts right after the agent joins, and the greeting
waits (bounded, `LIVEKIT_EGRESS_START_WAIT_S`) until it is recording; it stops 1.5 s after the goodbye
(`LIVEKIT_EGRESS_STOP_GRACE_S`) so the last words aren't clipped. Verified: a 263 s interview produced
260.3 s of Opus audio in Azure. **Cost of waiting for the recorder:** ~3.5 s more before the greeting
(first audio 8.1 s after Start, vs ~4 s without LiveKit). Setting `LIVEKIT_EGRESS_START_WAIT_S=0`
removes the wait, and the server recording may then miss the greeting's first seconds.
Camera/screen in the egress need them published to the room: a separate bandwidth/cost decision.

**Completion is confirmed (2026-10-10).** LiveKit uploads the file only after the stop, and writes
nothing at all if it fails, so the file's presence can't say "still uploading" or "failed". Each
part now has a manifest beside it (`<part>.ogg.json`): the session writes `recording` at start and
`processing` at stop and enqueues the **`recording_finalize`** worker job, which polls LiveKit
(bounded by `RECORDING_FINALIZE_WAIT_S`, default 90 s, then retried off the queue) and writes
`ready` with the duration and size, or `failed` with LiveKit's error. One manifest per part, so a
handed-off interview's jobs never write the same file. `/api/sessions/{token}/recording-parts`
returns `livekit_parts` (including a part whose file never landed) and the admin Recording tab shows
"Finishing up…" (polling every 5 s), the player, or "could not be saved — the browser recording
still has this part". A file that exists always wins over a stale manifest (a crashed runner never
writes `processing`, but LiveKit still uploads once the room empties). `ready` with no file the app
can see reads `unavailable`, not `failed`: on the local stack the app's blob store is the disk
fallback while LiveKit writes to the real Azure account, so the file is saved but not readable there
(in ACA both use the same account and `sessions` container). Verified locally: a 246 s pool interview
→ finalize job `ready`, `duration_s` 245.3.

### 1F — Parity gate (do not skip)
Two real interviews, one on each transport, then compare:
- [ ] VAD / speech-to-text timing unchanged (`interview_stt_partial_lag_ms` p50/p95)
- [ ] Barge-in feels the same — interrupt a question mid-sentence
- [ ] **The AI's goodbye is not cut off**
- [ ] Captions stay in sync with the audio
- [ ] Egress recording complete, in sync, both voices present — matches the browser recording
- [ ] Reconnect: drop Wi-Fi for 5 s, the interview continues without a restart
- [ ] **C measured again** and compared with the Phase 0 baseline

**Automated half done (2026-10-09)** with `scripts/livekit_parity_check.py`: a bot candidate that
joins and acks exactly like the page, answers with real Azure-TTS speech, and runs a whole interview.
Same interview type, once per transport, on the local stack:

| | WebSocket | LiveKit |
|---|---|---|
| Ended naturally, goodbye heard to the end | ✅ | ✅ |
| Words the server transcribed | 90% | 88% |
| Playback acks | 15, `onended` | 26, all from measured playout |
| Bot stops talking → hears the AI, median / p95 | 3.99 s / 4.88 s | 4.74 s / 7.11 s |
| Server-side part (endpoint → first AI audio), median | 3.07 s | 3.50 s |
| Server recording in Azure | — | ✅ 260 s |

The server-side part differs by LLM variance between two different conversations (the LiveKit run
also hit 3 Groq tool-call errors to 1). The rest, ~0.3 s, is the trip to LiveKit Cloud and back; the
local WebSocket never leaves the machine, so this comparison flatters it — in production it crosses
the internet too. **Still open, needs a person and real browsers:** barge-in by ear, captions in sync,
Wi-Fi drop for 5 s, avatar-less UX acceptable, and C measured with LiveKit on.

### 1G — Cloud rollout
Add `LIVEKIT_URL` / `LIVEKIT_API_KEY` / `LIVEKIT_API_SECRET` (secret) and the egress storage settings
to `deploy/aca/main.bicep` for the gateway and session apps — they are **not** in the template today.
Deploy with `MEDIA_TRANSPORT` unset, run one canary interview with it set on one shard, then switch on
after the go/no-go. **Rollback:** unset `MEDIA_TRANSPORT`.

**Template done (2026-10-09), not deployed:** `main.bicep` takes `mediaTransport` (default
`websocket`), `livekitUrl`, `livekitApiKey`, `livekitApiSecret`; `provision.sh` passes them from the
environment. Egress needs no new credentials: it writes with the key of the storage account the
template already provisions, into its `sessions` container. Compiles with Bicep 0.48.1. NB: the gateway
must have `MEDIA_TRANSPORT=livekit` too, or `/session-info` never offers the room and every interview
stays on the WebSocket.

---

## 9. Phase 2 — Control messages off the brain's address

**Why:** after Phase 1 the audio no longer needs the brain's address, but the candidate's **control
WebSocket** (captions, phase changes, coding and scenario events, start/end, the "finished playing"
signal) still has to reach the exact process running the brain — which is precisely what prevents
more than one replica.

**Recommended:** carry those control messages over **LiveKit's data channel**. The brain is already a
room participant, so the candidate and the brain can exchange messages through the room without
either knowing the other's server. The gateway's WebSocket proxy then has nothing left to do for
voice interviews.

**Alternative (the original plan):** a Redis Streams channel per interview (`events:{session_id}`).
It was chosen mainly to fan observer traffic out and replay it on reconnect; with the observer gone
that rationale is much weaker, and it would still need a way to deliver candidate messages to the
right process.

| # | Task | Done when | Status |
|---|---|---|---|
| 2.1 | Decide data channel vs Redis Streams (team decision) | Recorded here | ✅ **LiveKit data channel** (2026-10-09, owner) |
| 2.2 | Move each control message type to the chosen channel; keep the message shapes identical | Candidate page works with the WebSocket disconnected | ✅ |
| 2.3 | Reconnect: the brain re-sends current state (phase, open coding/scenario item) — the scenario panel already does this | Refresh mid-interview resumes cleanly | ✅ |
| 2.4 | Retire the gateway's interview WebSocket proxy | No `/ws/candidate` traffic in a full interview | ◐ zero WS traffic on LiveKit; the proxy stays as the fallback until 1H |

**Done (2026-10-09).** How a LiveKit interview runs now:
1. On Start the page calls `POST /api/candidate/{token}/start` with its tab id. The gateway forwards it
   (signed, `app/session_tier/internal_auth.py`) to the shard that owns or will own the token
   (`/internal/room/{token}/start`, retried once if placement raced).
2. The shard applies the WebSocket path's rules in the same order — finished link → 410; another tab
   in the room or still joining → 409 `session_in_use`; otherwise claim + runner — and answers with
   **this tab's room token** once the AI is in the room. `/session-info` now only *offers* LiveKit
   (`{"enabled": true}`) and carries no token, so a second tab can't join as the candidate.
3. Every control message rides the room's reliable data channel, same JSON shapes; messages over
   ~2000 characters (a coding question with its tests) go as ordered chunks. `{"type":"attach"}`
   gets the same catch-up a WebSocket attach gets (hello, phase, transport, scenario item).
4. A per-interview supervisor (`_supervise_session`) owns teardown; `_finish_session` is the one
   teardown both paths use. The 180 s orphan reaper counts "candidate in the room" as connected.
5. Failure paths: the agent can't connect → `{"transport":"websocket"}`; the page can't join → it
   opens the WebSocket and the server falls back at once (measured 2.3 s); the AI leaves without a
   goodbye (crash) → the page rejoins, which resumes from the checkpoint; the room is lost → rejoin.

Verified on the local stack: 12/12 edge cases (`room_scenarios`: owner, second tab refused, refresh,
takeover after the owner left, end over the data channel, finished link refused, page-can't-join
fallback) and a full bot interview with **0 WebSocket frames**. **Found on the way:** on a flaky
network the agent's LiveKit connection was rebuilt and the candidate's audio never resumed — the
speech detector then waited forever for the end of a sentence and the interview froze. The audio
source now restarts its reader if no audio arrives for 3 s (`LIVEKIT_MIC_STALL_S`) while the
candidate's track is unmuted, and has the same `mic_health()`/`stats()` as the WebSocket source (the
mic-silence detector was blind on LiveKit). Also seen: a LiveKit Python SDK bug that logs
`InvalidStateError` after a full reconnect — harmless, logged by the SDK.

Text interviews are unaffected — they are already stateless HTTP.

## 10. Phase 3 — Ownership lease, drain, and autoscaling

**Why:** with nothing needing a specific server's address, the session tier can run several replicas
— as long as **exactly one** runs each interview, and scale-in never cuts a live one.

**Ownership lease, in plain terms:** a server "rents" an interview for ~30 seconds and must keep
renewing. If it crashes or loses contact, the rental lapses and another server may take over. A
**fence** (a receipt with an increasing serial number) stops a briefly-disconnected server from
taking the interview back. **Safety rule: a server that cannot renew must stop working on that
interview immediately.**

| # | Task | Done when |
|---|---|---|
| 3.1 | **Fence + no blind re-claim.** Today the heartbeat re-claims a lost registry entry (`app/session_tier/lifecycle.py`) — a split-brain hole that is only unreachable because of `maxReplicas: 1`. Can be done early, standalone. | Lease is fenced; heartbeat renews or stops — ✅ 2026-10-09 |
| 3.2 | **Placement:** decide how a free server picks up a new interview — a Redis work queue the session tier claims from, or LiveKit agent dispatch (LiveKit assigns rooms to registered workers) | Decision recorded + implemented — ✅ Redis queue |
| 3.3 | **Drain on SIGTERM:** stop accepting new interviews, let current ones finish, then exit; set the termination grace period | A deploy never cuts a live interview — ✅ |
| 3.4 | **Scale rule:** scale out on interviews-per-replica (using C from Phase 0/1F), scale in conservatively | Ramp test scales out and back in cleanly — ◐ rule written; needs Azure + C |
| 3.5 | Flip `maxReplicas > 1`; retire the "one app per shard" convention | Load test passes with replicas added and removed mid-run — ◐ pool app written + verified locally; shards kept for the WebSocket path |

**3.1 done (2026-10-09).** Each claim takes the next number of a per-token counter (`reg:fence:{token}`)
and records it in the entry. `registry.renew` (atomic) renews only our own entry; restores it if
Redis lost it *and* no newer claim exists; else reports LOST. `registry.release` deletes only our own
entry. On LOST the heartbeat calls `on_lost` — the shard cancels its runner (the crash path: the
checkpoint is kept for the new owner) — and stops. Its teardown still returns its own admission slots.
**3.2 decision recorded:** placement via a **Redis work queue** (2026-10-09, owner).

**3.2–3.5 done (2026-10-09), verified on the local stack with a 2-replica pool:**
- **Placement** (`app/session_tier/placement.py`). The gateway's `POST /api/candidate/{token}/start`
  becomes a Redis request: to the owner's **inbox** if the interview is running (refresh, second
  tab, hand-off), else to the **shared queue** any replica with spare capacity takes from
  (`PLACEMENT_MAX_SESSIONS`, default 4 until C is measured). A request carries a deadline so one the
  gateway gave up on is never run late. Each replica publishes a 10 s liveness key; a fenced entry
  whose owner has no liveness key is **taken over at once** instead of waiting out the registry TTL
  (pre-fencing entries never are, so a rollout can't mistake an old replica for a dead one).
- **Hand-off instead of in-place fallback.** A room interview never switches to the WebSocket inside
  its server: if LiveKit fails (agent can't connect, page can't join, page asks for the WebSocket)
  the runner stops *without marking the interview completed* (`broadcaster.handover`, also honoured
  by the DB-status event hook), frees its claim, and the page starts over on the WebSocket path on an
  addressable shard. That's what lets room interviews run on replicas nothing can route to.
- **Drain** (Phase 3.3). SIGTERM → the replica takes nothing new; WebSocket interviews are handed off
  at once (their sockets are about to close); LiveKit interviews keep running in place (they need no
  inbound connection) until `DRAIN_TIMEOUT_S` (540 s; ACA `terminationGracePeriodSeconds: 600`,
  gunicorn `--graceful-timeout 600`), then are handed off — the page sees the AI leave, rejoins, and
  another replica resumes from the checkpoint. Measured: the conversation continued for the full
  60 s local drain window after SIGTERM, then resumed on the other replica and ended naturally.
- **Pool + scale rule** (`main.bicep`): `session-pool` app, `SESSION_POOL=1`, **no ingress**,
  min 1 / max 10 replicas, KEDA `metrics-api` on the gateway's `/scaler/pool` = interviews running on
  the pool + waiting in the queue, divided by `sessionPoolPerReplica`. The addressable shards stay
  (1 replica each) for the WebSocket path; `PLACEMENT_SHARED_QUEUE=0` stops them taking LiveKit
  interviews when the pool should. Local: `docker compose --profile pool up -d --scale session-pool=2`.
- **Found and fixed while testing:** the resumed replica's server recording overwrote the first one
  (fixed name) → one file per runner, `livekit-audio-<start>.ogg`, all listed in order; the
  status-event hook marked a handed-off interview `completed`, and the token helper then refused its
  room → every resume looped (fence reached 19) → the hook honours the hand-off and the helper leaves
  the run/over decision to the shard.
- **Still open:** C (sets `sessionPoolPerReplica`), a real KEDA ramp test (Azure only), the WebSocket
  path still needs the addressable shards until 1H.

Whether this stays on Azure Container Apps or moves to AKS is decided with the capacity numbers —
[07-scaling-cost-and-decisions.md](reading/07-scaling-cost-and-decisions.md) puts the break-even at
roughly 90 × C interviews per day.

## 11. Phase 4 — Per-turn checkpoints

**Why:** recovery today restarts the *current phase* — everything said since the phase began is lost
from the AI's memory. With per-turn checkpoints, a crash costs at most one answer.

| # | Task | Done when |
|---|---|---|
| 4.1 | Checkpoint the conversation and question cursors after each turn (Redis, small and bounded) | Checkpoint written every turn — ✅ |
| 4.2 | Resume mid-phase from the last turn; keep the phase clock honest | A crash mid-phase resumes at the last answer — ✅ |
| 4.3 | Make the evaluation read the resumed run without double counting | Scores match an uninterrupted run — ✅ |

**Done (2026-10-09).** The director writes a **turn checkpoint** at each AI dispatch — the moment the
candidate's answer is in the state and the AI is about to respond — in the background, with the
phase's turns, the question cursor (`CadenceTracker.to_snapshot`) and the phase time used. A resume
from it (`session_resumed` `mode: "turn"`) restores all three; the first turn answers the
candidate's last answer (or re-asks the last question) with a one-line "we're back", and the phase
keeps only its remaining time. So the candidate never repeats an answer; only an AI reply that was
being generated is regenerated. Coding and scenario phases keep the phase-start checkpoint (editor
state and media cursor aren't captured). The trace/eval view (`app/resume_collapse.py`) keeps every
answer before the checkpoint and drops only what was in flight; the v2 evaluation now reads that
collapsed view too (it used to read the raw log and double-count a resumed phase). Verified live:
drained mid-phase, resumed `mode: turn` in the same phase with its used time, natural end; on the
real log the collapse kept 7/7 answers and dropped only the 6 hand-off/teardown events.

---

## 12. Cross-cutting

- **Rollback:** every phase ships behind a switch until it is the default and stable. Phase 1:
  `MEDIA_TRANSPORT`. Phase 3: `maxReplicas`.
- **Observability (done 2026-10-10):** the dashboard
  (`deploy/observability/dashboards/interview.json`) has a "LiveKit media & scaling" row: room-join
  time by stage (`interview_livekit_join_ms{stage=agent_connect|candidate_ready|egress_active}`),
  "finished playing" delay per transport (`interview_playback_ack_lag_ms{transport}` — from when
  the utterance should have finished playing, i.e. audio_end + the sink's remaining queue, to the
  page's ack; acks that arrive before that are counted apart in
  `interview_playback_ack_early_total` and shown as an "early share"; each ack's signed `lag_ms` is
  on its `audio_playback_finished` event), egress outcomes (`interview_livekit_egress_total{outcome}`, started/stopped
  from the session, complete/failed from the worker), hand-offs by reason
  (`interview_handoffs_total{reason=no_room|livekit_unavailable|page_fallback|drain_ws|drain_deadline|lease_lost}`,
  counted once per interview) and resumes by mode (`interview_resumes_by_mode_total{mode=turn|phase}`),
  the placement queue, and mic self-heals (`interview_livekit_mic_stall_heals_total`).
  **Replicas Prometheus can't reach** (the session pool has no ingress, nor does the worker) publish
  their own `/metrics` text to Redis every `METRICS_PUSH_INTERVAL_S` (10 s; key expires after 3
  missed pushes, so a dead replica drops out) and the gateway serves them merged at
  `/metrics/pushed`, each sample labelled `instance` (the replica) and `tier`, plus
  `interview_placement_queue_depth` and `interview_pushed_replicas`. Prometheus scrapes it as job
  `pushed` with `honor_labels: true`, so pool replicas appear per instance in the existing panels like
  the shards. The gateway is public: set `METRICS_TOKEN` (Bicep `metricsToken`, passed to both the
  gateway and the Prometheus container) to require a bearer token. The worker also exports
  `interview_jobs_total{type,outcome}`. Verified locally: two pool replicas and the worker reported
  through the gateway and Prometheus scraped them with their own instance labels.
- **Cost:** LiveKit bills connection minutes, bandwidth and — the largest — recording minutes. Add
  them to the usage line of the cost model in Phase 0/1F; check current prices at livekit.io/pricing.
- **Load testing:** `scripts/loadtest_interviews.py` drives the WebSocket path only.
  **`scripts/loadtest_livekit.py`** (2026-10-10) drives the LiveKit path: N parity-check bots per
  level (`--levels 1,2,4,8`, staggered by `--stagger-s`), each a full interview with real speech, and
  per level reports started / on LiveKit / fell back / ended naturally / goodbye heard / transcription
  recall / response p50-p95 pooled over every turn / time to the greeting p50-p95. Tokens from
  `--token-file`, or `--make-tokens --template <token>` clones an approved interview (`--cleanup`
  deletes them after). A bot still running at `--max-s` sends `end`, so nothing is left running.
  Every interview is real (LLM, Speech, LiveKit minutes): start small and watch the Grafana row.

**Found by the new lag metric (2026-10-10), NOT fixed — the page can confirm an utterance before
it plays.** On LiveKit the page acks when the AI track has been quiet for 600 ms since a loud frame
heard after that utterance's `audio_start` *message*. The message arrives over the data channel
ahead of the audio, while the previous sentence's tail is still playing, so if there is a ≥600 ms
gap before the next sentence's audio arrives, both are acked together. Measured on a bot interview:
11 of 26 acks early, up to 2.5 s before the server expected the audio to end. Impact is small
because `LiveKitAudioSink` stays busy while it still has audio queued (the silence timer can start at
most about one network delay early), but the ack no longer means "heard". Likely fix: count "heard"
from the first loud frame after the previous utterance's ack instead of from the message's arrival.
That is a change in `candidateEngine.ts` (and the bot), so it needs a real-browser check.

**Avatars on LiveKit (2026-10-11).** Both avatars now work in room mode: the page taps the AI's
track back into 16 kHz PCM and streams it to the avatar for the face only, while the LiveKit
element keeps playing the voice — no change to latency, the ack, the recording, or server/LiveKit
load (rendering stays in the candidate's browser). TalkingHead gets per-utterance word timings
from `audio_end.duration_ms`. Verified in real Chrome for TalkingHead; Simli needs a live check
with a `SIMLI_API_KEY`. Found on the way: the lobby's connection probe used the real interview
WebSocket URL and claimed the interview, so a real browser never got LiveKit — fixed (`?probe=1`).

## 13. Decisions needed

| Decision | Needed by | Who |
|---|---|---|
| LiveKit Cloud plan / billing | 1E | Product owner |
| Compliance approval for LiveKit Cloud | 1G (before real candidates) | Legal |
| Terms & Conditions wording (no human joins) | Before real candidates | Legal + Product owner |
| Retire the browser recording after egress is proven? | After 1F | Owner + Product owner |
| Control channel: LiveKit data channel vs Redis Streams | Start of Phase 2 | ✅ data channel |
| Placement: Redis queue vs LiveKit agent dispatch | Start of Phase 3 | ✅ Redis queue |
| Stay on ACA vs move to AKS | Phase 3, with capacity numbers | Capacity + Product owner |

---

## Appendix A — How LiveKit moves and stores media

**Publish → forward → subscribe**, plus a separate **record** path.
- **Publish:** the browser or the brain encodes (audio → Opus) and streams packets to the LiveKit
  server over WebRTC. Continuous packets, not files.
- **Forward:** LiveKit forwards packets to subscribers without mixing them — that is why it scales.
- **Subscribe:** the receiver's jitter buffer smooths the stream and plays it. The brain subscribes
  as a participant and the Python SDK hands it decoded PCM.
- **Record (egress):** a server-side recorder subscribes, mixes and encodes to a file written to
  **our** storage. This is the only place anything is stored.

## Appendix B — Why Phase 1 is tractable

The brain (`InterviewSession`, the director, speech-to-text, VAD, text-to-speech, the latency
engine) touches audio only through two small contracts — `AudioSource` and `AudioSink` in
`engine/brain/contracts/audio.py`. Phase 1 supplies LiveKit-backed versions of both
(`engine/orchestrator/livekit/transport.py`); nothing else in the brain changes.
