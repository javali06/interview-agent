# Interview Evaluation Rubric (v2) — Team Reference

One page. How every candidate is scored, per cadence section, with verifiable evidence.

---

## 1. Scoring dimensions

| Dimension | What it measures | Evidence that counts | Never use (banned proxy) |
|---|---|---|---|
| **Technical depth** | Causal understanding that survives probing | Mechanism explanations ("X because Y"); correct answers to 2–3 level follow-ups | Buzzwords, fluent English, confidence tone |
| **Problem-solving process** | How they attack a problem | Decomposition that shaped the answer; ambiguity handled (asked OR stated assumption); recovery visible in code runs/edits | Counting clarifying questions; think-aloud narration volume |
| **Communication clarity** | Could a listener reconstruct the answer? | Load-bearing facts present, retrievable under one probe | Accent, fillers, answer-first style, grammar |
| **Ownership specificity** | Did THEY do it? | Specifics under probing: the decision they made, alternatives weighed, bug they fixed | "I vs we" pronouns; brand names; job titles |
| **Role fit** | Operated at the role's altitude | Probed verifiable facts (team size, scale, stakeholders) vs JD requirements | Company research; enthusiasm; self-promotion style |
| **Code quality** (coding only) | Working, well-structured code | Test pass rate; structure/decomposition; edge-case awareness | Typing speed, time used, hints, runs; "pythonic" style (unless JD needs it); identifier English |

---

## 2. Anchor scale (every dimension, every section — 5 named levels)

| Level | /10 score band | Meaning | Typical behavior |
|---|---|---|---|
| **Below bar** | 0–2 | Cannot do it with help | Naïve attempt only; detail collapses at first probe |
| **Approaching** | 3–4 | Does it with help | Needs prompting; reactive; bolted-together answers |
| **Mixed** | 5–6 | Inconsistent | Some independent work, but thin under 2nd probe |
| **Solid** ← **HIRE BAR** | 7–8 | Independent at role level | Proactive, coherent, detail survives probing |
| **Exceptional** | 9–10 | Above role level | Multiple approaches + tradeoffs unprompted; teaches the interviewer something |

*Anchors are calibrated to the role's seniority bar (from JD). Hire bar sits at Mixed→Solid (7/10). All numeric scores in the product are /10; band names map to these ranges everywhere.*

---

## 3. Section lenses (what each section is FOR — derived per cadence, frozen for all candidates)

| Section type | Purpose | Score | Ignore | Weight |
|---|---|---|---|---|
| Warm-up | Settle nerves; logistics | — (quarantined) | Everything competence-related | 0 |
| Project / resume deep-dive | Real-work depth & ownership | Ownership specificity, technical depth | Charisma, brand names | 1.5 |
| Technical Q&A | Fundamentals under probing | Technical depth, problem-solving | Memorized definitions | 1.0–1.5 |
| Coding | Working code + process | Code quality, problem-solving (from event trail) | Speed, narration | 1.5–2.0 |
| System design | Navigating ambiguity, tradeoffs | Problem-solving, technical depth, role fit | Trivia | 1.5–2.0 |
| Wrap-up | Close well; candidate questions | — (quarantined) | "Why us" answers | 0 |

*Any custom section gets a lens derived from its `intent` + questions + JD. Same cadence = same rubric for every candidate.*

---

## 3b. How section weights are decided

**Scale:** `0` quarantined · `0.5` context · `1.0` standard · `1.5` important · `2.0` core (max). Final score = Σ(section level × weight) ÷ Σ(weights). Sections with insufficient evidence drop out of the denominator entirely (they never drag the score).

| Factor | Rule |
|---|---|
| **1 · JD-criticality** | The closer the section tests the role's *core* competency, the higher the weight. Coding round for an SDE role → 2.0; the same round for an ML-research role → 1.0–1.5 |
| **2 · Evidence quality** | Probed, verifiable signal outweighs unprobed narrative. A deep-dive with follow-ups (1.5) > a broad Q&A where answers go unprobed (1.0) |
| **3 · Section function** | Rapport/logistics sections (warm-up, wrap-up) are always 0 — they exist to make *other* sections valid, not to be scored |
| **4 · Depth over duration** | Planned length is a sanity check, not the driver — a 5-min section can't be the highest-weighted; but a long section isn't automatically heavy |

**Who sets it (precedence):**

| Order | Who | When |
|---|---|---|
| 1 | **TA override** | Anytime; audit-logged; applies to the whole cadence/requisition going forward |
| 2 | **Cadence author** | Written in the cadence YAML alongside the questions |
| 3 | **Lens-derivation LLM** | Proposes weights from `intent` + questions + JD when not authored |
| 4 | **Default** | 1.0 (heuristic quarantines obvious warm-up/wrap-up) |

**Guards (enforced in code):**
- Same cadence = **identical weights for every candidate** (frozen; changed mid-pipeline → prior evaluations flagged "scored under previous rubric")
- Never quarantine the **only** or the **longest** section
- Any derived weight ≥1.5 is flagged **"review me"** until a TA acknowledges it once
- If all sections end up at weight 0 → verdict is **"insufficient evidence"**, never a number

---

## 4. Evidence rules (what makes a score trustworthy)

| Rule | Meaning |
|---|---|
| **Quote or it didn't happen** | Every score points at validated verbatim transcript moments — clickable to the exact row |
| **Fact ≠ interpretation** | The quote is shown separately from what the AI says it shows; you verify the quote yourself |
| **Counter-evidence required** | Every section card names the strongest evidence AGAINST its own level |
| **"Not observed" is honest** | Unprobed/skipped → excluded from scoring, flagged for the next round — never scored 0 |
| **No probe, no penalty** | Below-bar depth/ownership requires ≥2 probes actually delivered in that section |
| **Process signals: credit-only** | Good process adds; silent process never subtracts (and narrated process needs a consequence — talk is not credit) |
| **"As transcribed"** | Candidate quotes are STT text; mis-transcriptions can be contested and the score re-run |
| **Integrity caps the verdict** | High-confidence cheating/injection flags cap at "Mixed" with a banner — human override only, logged |

---

## 5. Final verdict

| Verdict | Composite basis |
|---|---|
| Strong No / No / **Mixed** / Yes / Strong Yes | Weighted section levels (computed in code, not by the LLM) + narrative with cited receipts + "what would change this verdict" |

**Output per candidate:** per-section cards (level + evidence + counter-evidence + not-observed) → dimension rollup → bar-calibrated verdict. Everything clickable, every re-score appends to history.
