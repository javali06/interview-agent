# Why we need an IT-provisioned mailbox for candidate invite emails

## TL;DR

We tried three accounts to send the automated candidate-invite email. Two failed for
concrete, documented reasons that have nothing to do with our code — both are
authentication restrictions imposed by Microsoft, one on the personal side and one on
the corporate side. The only reliable fix is a **Microsoft 365 shared mailbox that IT
provisions with Authenticated SMTP explicitly turned on**, since that is the one
configuration an admin can actually control end to end.

| # | Account | Type | Result |
|---|---|---|---|
| 1 | `javali.manda@centific.com` | Corporate M365 (individual) | ❌ No self-service SMTP auth path exists |
| 2 | `ava.interviews@outlook.com` | Personal/consumer Outlook.com, created for this purpose | ❌ SMTP AUTH disabled by Microsoft, no toggle to re-enable it |
| 3 | `mandajavali@gmail.com` | Personal Gmail | ✅ Works, but only off the office network (see note below) |

---

## 1) Why the personal Centific (corporate) account won't work

Checked the account's own **Security info** page
(`https://mysignins.microsoft.com/security-info`). The available sign-in methods were:

- Password
- Microsoft Authenticator (push MFA)
- Passkey (device-bound)

**There is no "App passwords" option.** That option only appears on tenants that still
allow legacy per-user MFA app passwords; Centific's tenant has moved to
**Conditional Access-only** authentication, so it is not offered at all — not something
missing from this one account, a tenant-wide policy.

Two separate things would both need to be true for this account to send mail over SMTP,
and neither is available without IT:

1. **Authenticated SMTP** would need to be turned on for this mailbox specifically
   (`Set-CASMailbox -SmtpClientAuthenticationDisabled $false`) — an admin-only action.
2. Even with that enabled, the account still has **MFA enforced**. SMTP AUTH is a plain
   username+password handshake — there is no interactive prompt inside it, so it
   **cannot satisfy an MFA challenge**. The account would additionally need an explicit
   Conditional Access **exclusion**, which is also admin-only.

**Conclusion:** this is not a setting we can turn on ourselves. It requires an Exchange
admin to grant both an Authenticated-SMTP exception and an MFA exclusion for this
specific account.

---

## 2) Why the newly-created Outlook.com account won't work

We created a dedicated personal account for this — `ava.interviews@outlook.com` — with
no corporate policy attached to it at all, specifically to sidestep problem #1. It still
failed.

**Setup performed:**
- Enabled 2-Step Verification
- Generated an App Password from `account.microsoft.com/security`
- Configured the app: `smtp-mail.outlook.com:587`, STARTTLS

**First attempt** failed immediately:

```
535 5.7.139 Authentication unsuccessful, SmtpClientAuthentication is disabled for the
Mailbox. Visit https://aka.ms/smtp_auth_disabled for more information.
```

We then tried the one setting Microsoft's consumer UI exposes that sounds related:

- **Settings → Mail → Sync email → POP and IMAP → "Let devices and apps use POP"** → turned ON → retried → **same exact error**
- Also turned on **"Let devices and apps use IMAP"** → retried again → **same exact error, byte-for-byte**

**Conclusion:** the POP/IMAP toggles do not control SMTP AUTH at all for this account.
Microsoft now disables SMTP AUTH by default on **newly created personal mailboxes** as
an anti-abuse measure, and — unlike older consumer accounts — there is currently no
self-service setting anywhere in the Outlook.com UI to turn it back on. Since this is a
personal (non-organizational) account, there is also **no admin to escalate to** — the
restriction is simply final for this account.

---

## 3) Why it has to be an IT-provisioned mailbox with Authenticated SMTP enabled

Putting #1 and #2 together, the requirements rule out every option except one:

- A **personal consumer account** (Outlook.com, and by the same Microsoft policy trend,
  likely any newly created one) can have SMTP AUTH disabled by Microsoft with **no way
  for anyone — not even the account owner — to turn it back on**.
- An **individual corporate account** is blocked by Conditional Access / MFA, which
  **only an Exchange admin can grant an exception for**, and doing so for a personal
  human account is also not appropriate practice (that exception should apply to a
  dedicated service mailbox, not someone's personal login).
- A **Microsoft 365 shared mailbox that IT creates specifically for this purpose** is
  the one configuration where:
  1. An admin can explicitly run
     `Set-CASMailbox -Identity ava.interviews@centific.com -SmtpClientAuthenticationDisabled $false`
     — a supported, documented, reversible setting under IT's own control.
  2. It can be cleanly excluded from MFA/Conditional Access as a recognized **service
     account** pattern (authenticates by password only, never signs in interactively) —
     a normal, well-understood exception request, not a workaround.
  3. It authenticates against `smtp.office365.com`, which — unlike `gmail.com` — is
     **not blocked on the corporate network's DNS** (see note below), so it works
     from the office without needing a workaround like a phone hotspot.

This is a small, well-scoped, one-time request — see `docs/candidate-email-notifications-RD.pdf`
and the message drafted for IT for the exact ask.

---

## Two ways forward

Both of these are viable; they trade off differently between "who has to do
something" and "how much code changes."

### Approach A — IT creates a dedicated shared mailbox (SMTP, no code changes)

The path detailed above. IT provisions a normal M365 shared mailbox and turns on two
settings for it:

1. **Authenticated SMTP** enabled for that one mailbox:
   ```powershell
   Set-CASMailbox -Identity ava.interviews@centific.com -SmtpClientAuthenticationDisabled $false
   ```
2. **MFA / Conditional Access excluded** for that mailbox, since it's a service account
   authenticating by password only, not a person signing in interactively.

Once that's done, it's a drop-in credential swap — the app already speaks plain SMTP
(`aiosmtplib`), so this is just filling in `SMTP_HOST` / `SMTP_USERNAME` /
`SMTP_PASSWORD` / `SMTP_FROM_ADDRESS` in `.env` with the new mailbox's details. **No
code changes.**

- **Effort:** one IT ticket; ~zero engineering time once granted.
- **Risk:** depends entirely on IT actually enabling both settings — if either one is
  missed, it fails exactly like the two accounts documented above.
- **Ongoing ownership:** IT owns the mailbox (password rotation policy, keeping the
  Conditional Access exclusion in place) the same way they own any other shared
  mailbox.

### Approach B — register a Microsoft Entra (Azure AD) app + Microsoft Graph API

Instead of authenticating as a mailbox over SMTP, the app authenticates as an **Entra
app registration** (a service identity, not a mailbox) and sends mail through
Microsoft's **Graph API** (`POST /users/{mailbox}/sendMail`) over plain HTTPS — no SMTP
protocol involved at all, so none of the `SmtpClientAuthenticationDisabled` restrictions
above even apply.

**What IT/an Entra admin needs to do (one-time):**
1. Register a new **app registration** in Entra ID (Azure AD) — e.g. named
   `interview-agent-mailer`.
2. Grant it the **`Mail.Send`** **application permission** (not delegated — this app
   sends as a mailbox with nobody signed in) under Microsoft Graph.
3. An admin must **grant admin consent** for that permission (application permissions
   always require this — a normal user can't self-consent).
4. Generate a **client secret** for the app registration (or a certificate, more
   secure but more setup) and hand over three values: **Tenant ID**, **Client ID**,
   **Client secret**.
5. Still need a mailbox for it to send *as* — either the same shared mailbox from
   Approach A (without needing SMTP AUTH on it at all this time), or any mailbox in the
   tenant; `Mail.Send` lets the app send as any mailbox unless scoped down with an
   Exchange application access policy.

**What changes in our code:**
- A new module using `msal` (Microsoft's auth library) to fetch an OAuth2 access token
  via the client-credentials flow, then a plain HTTPS call to
  `https://graph.microsoft.com/v1.0/users/{mailbox}/sendMail` with the email payload as
  JSON — replacing `app/notifications/email_client.py`'s `aiosmtplib.send(...)` call.
  `templates.py` (the HTML content) stays exactly the same either way.
- New env vars: `GRAPH_TENANT_ID`, `GRAPH_CLIENT_ID`, `GRAPH_CLIENT_SECRET`,
  `GRAPH_SENDER_MAILBOX` in place of the `SMTP_*` block.
- Roughly **1.5–2 days** of work (mostly the token-acquisition plumbing + testing);
  see the earlier cost/effort research doc for the full breakdown.

- **Effort:** one Entra admin task (15–20 minutes) + noticeably more engineering time
  than Approach A.
- **Risk:** lower long-term — this is Microsoft's actively supported, forward-looking
  path (they are deprecating SMTP AUTH broadly, as both incidents in this document
  show); an app registration doesn't get caught by future SMTP-AUTH policy tightening.
- **Ongoing ownership:** the client secret **expires** (typically 6–24 months, admin's
  choice) and must be rotated by whoever owns Entra app registrations — a different kind
  of upkeep than a mailbox password, but still small.

### Recommendation

**Approach A first** — it's the fast path and needs zero code changes, so there's no
reason not to ask for it today. If IT is slow to grant the MFA exclusion, or the org's
security policy won't allow it for any mailbox (increasingly common, per the two
failures already documented above), **Approach B is the durable fallback** that
sidesteps the whole SMTP-AUTH-disabled problem permanently.

---

## Note: the Gmail account works, but only off the office network

`mandajavali@gmail.com` (personal Gmail, app password) **does** send successfully — this
was verified multiple times. However, it only works when **not connected to the office
Wi-Fi** (confirmed as the `IDC IT 2 Wi-Fi` network). On that network, DNS resolution for
`gmail.com` and all its subdomains (including `smtp.gmail.com`) fails outright — a
corporate DNS content-filtering policy that blocks personal webmail domains, unrelated
to Google or our app. `google.com` itself, and Microsoft's `smtp.office365.com` /
`smtp-mail.outlook.com`, all resolve fine on the same network — only `gmail.com` is
filtered.

This is the practical reason Gmail is not a viable long-term choice even though it
technically works: it depends on which network the containers happen to be running from,
which is not something a production deployment should depend on.
