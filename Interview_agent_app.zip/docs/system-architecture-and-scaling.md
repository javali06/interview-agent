# System Architecture, Failure Analysis & Scaling Plan — Voice Interviews

**Status:** analysis + recommendation · **Date:** 2026-09-06
**Read with:** [media-server-scaling-plan.md](media-server-scaling-plan.md) (the locked LiveKit Phase 1–4 path), [reading/01-architecture.md](reading/01-architecture.md) (as-built tiers), [reading/07-scaling-cost-and-decisions.md](reading/07-scaling-cost-and-decisions.md) (ACA vs AKS economics).

This document answers three questions with diagrams rather than prose:

1. **What do we run today?** (§1)
2. **Why did candidates report slow/missed transcription, the AI talking over them, "Reconnecting" loops, refresh-restarts, lost transcript, and 15–20 s coding submits?** — exact root causes with `file:line` evidence (§2)
3. **How do we scale video interviews next** — what micro1 actually does (§3), what the industry does (§4), and our prioritized plan (§5–6).

---

## 0. TL;DR

| Reported symptom | Root cause (all code-confirmed) | Fix class |
|---|---|---|
| Transcription slow / voice not picked up | VAD is a **hard gate** in front of Azure STT (missed speech = zero bytes to Azure) + 50 ms preroll < 120 ms VAD hysteresis (every utterance head clipped) + mic-queue drop-oldest + per-frame ONNX on a shared thread pool + unfixed browser audio-rate drift | P0 config + P1 un-gate STT |
| AI speaks while candidate still answering | End-of-turn = a bare **1.5 s silence timer**. No semantic turn detection; STT partials cannot veto the endpoint; a thinking pause > 1.5 s *is* an endpoint. Recovery is punished by a 1.5 s barge-in warm-up | P1 semantic endpointing |
| "Reconnecting" repeatedly | Stale Redis registry pointer (60 s TTL) routes reconnects to a dead shard for up to a minute; no gateway→browser keepalive pings; PCM-over-TCP stalls on home Wi-Fi | P0 TTL/drain + P2 WebRTC |
| Refresh restarts interview / transcript lost | Checkpoints exist **only at phase boundaries** — and not at all in phase 1. Mid-phase resume rehydrates `[anchor, phase-marker]` only; everything said since phase start is gone from the LLM working set | P1 per-turn checkpoints |
| Coding submit 15–20 s | Submit creates **no dispatch trigger** — the AI's next turn waits for the 15 s silence rule, then serially pays a 2.5 s panel handshake + slow-LLM + TTS (≈ 5–26 s, centered on 15–20) | P0 one policy rule |

**Competitive reality check (§3):** micro1 runs ~1,500 interviews/day ≈ **30–60 concurrent on average** on a cascaded STT→LLM→TTS pipeline of vendor APIs (Google STT + GPT‑4.1 + Cartesia TTS won their bake-off). Their own research names **STT as the weakest link**. There is no evidence they solved real-time infrastructure any harder than we have — their moat is product (adaptive questioning, fused proctoring score, instant reports, 15+ languages). The scaling bar to beat is lower than assumed; the *quality* bar (turn-taking feel, reliability) is where we're losing.

**Recommendation (§6):** ship the P0 one-liners now; per-turn checkpoints + semantic endpointing next; then execute the already-locked LiveKit Phase 1 ([media-server-scaling-plan.md](media-server-scaling-plan.md)) with an STT bake-off (AssemblyAI Universal-Streaming / Deepgram Flux vs Azure) riding on it.

---

## 1. Current system — as built

### 1.1 Deployment topology

```mermaid
flowchart TB
    subgraph CLIENT["Candidate browser (uncontrolled home network)"]
        MIC["Mic: AudioWorklet<br/>PCM16 @16 kHz = 256 kbps up,<br/>continuous, uncompressed"]
        CAM["Camera → JPEG ~6.7 fps<br/>(~65–165 KB/s)"]
        SCR["Screen → JPEG 1080p ~2.5 fps<br/>(~0.25–1 MB/s, base64)"]
        REC["MediaRecorder ×2<br/>3 s webm chunks → POST"]
        SPK["PCM player + avatar"]
    end

    subgraph ACA["Azure Container Apps"]
        subgraph GW["Gateway — stateless, KEDA 1→10"]
            SPA["React SPA /app"]
            API["HTTP /api/*"]
            WSP["WS reverse proxy<br/>app/gateway/ws_proxy.py"]
        end
        subgraph SH0["session-0 — PINNED 1 replica, 1 process, 1 event loop"]
            BC["WebBroadcaster<br/>ONE WS = mic PCM + TTS PCM<br/>+ JSON control + base64 JPEG"]
            DIR["Director — turn-taking FSM"]
            VADS["Silero VAD service<br/>1 ONNX inference / 20 ms frame<br/>/ interview (asyncio.to_thread)"]
        end
        SH1["session-1 … session-N<br/>hand-provisioned Bicep apps<br/>(no autoscaling)"]
        WK["Worker — queue-scaled 0→10<br/>cadence-gen · eval-v2 · shortlist"]
    end

    REDIS[("Redis<br/>registry (TTL 60 s) · admission<br/>locks · PHASE checkpoints (TTL 2 h)")]
    PG[("Postgres — sessions, jobs")]
    BLOB[("Blob — recordings,<br/>events.jsonl, artifacts")]
    SPEECH["Azure Speech<br/>STT + TTS — 5 streams/key,<br/>multi-key broker rotation"]
    LLM["Groq / OpenRouter<br/>fast (verifier/guardrail)<br/>+ slow (interviewer) LLM"]

    MIC -- "20 ms frames over ONE WebSocket" --> WSP
    CAM --> WSP
    SCR --> WSP
    REC -- "HTTP chunk upload" --> API
    WSP -- "proxied WS (registry lookup)" --> BC
    BC --> DIR
    BC --> VADS
    DIR <--> LLM
    DIR <--> SPEECH
    BC -- "TTS PCM + captions" --> SPK
    SH0 <--> REDIS
    GW <--> REDIS
    SH0 --> BLOB
    WK <--> PG
    API --> BLOB
```

Key structural facts (each is a scale ceiling, quantified in §2.5):

- **Transport is NOT WebRTC.** Everything — mic PCM, TTS PCM, control JSON, base64 JPEG video — multiplexes through **one WebSocket over TCP**, proxied by the gateway to the owning shard.
- **A shard is one process with one event loop** (`deploy/Dockerfile.session:34`, gunicorn `-w 1`). All interviews on the shard share it.
- **Shards are static.** `SESSION_SHARDS` is a hand-maintained env list (`app/session_tier/identity.py:37-46`); adding capacity = provisioning a new ACA app + editing gateway env. `minReplicas: 1, maxReplicas: 1` (`deploy/aca/main.bicep:337`).
- **Recording is assembled in the candidate's browser** (MediaRecorder, 3 s chunks, no retry on failed upload).
- **Interview state lives in process RAM**, checkpointed to Redis **only at phase transitions**.

### 1.2 The real-time audio loop (one candidate turn)

```mermaid
sequenceDiagram
    participant B as Browser worklet
    participant G as Gateway _pump
    participant Q as Mic queue (4096, drop-oldest)
    participant V as VAD service (Silero)
    participant A as Azure STT (push stream)
    participant D as Director
    participant L as LLM (fast + slow)
    participant T as Azure TTS

    B->>G: 20 ms PCM frames (tag 0x00), 50/s
    G->>Q: relay
    Q->>V: every frame
    Note over Q,A: frames reach Azure ONLY while the<br/>VAD window is open — otherwise DISCARDED
    V-->>D: speech_start (after 120 ms hysteresis)
    Note over A: push stream seeded with just 50 ms preroll<br/>→ ≥70 ms of utterance head lost, always
    Q->>A: frames (window open)
    A-->>D: partials (streaming lag while candidate talks)
    V-->>D: endpoint_detected (1500 ms silence tail)
    Note over D: Turn finalized from PARTIALS at the VAD endpoint —<br/>STT partials cannot extend or veto the endpoint
    D->>L: verifier + guardrail + phase-override (parallel, fast LLM)
    D->>L: interviewer turn (slow LLM, TTFT unbounded, 5 s filler net)
    L-->>T: sentence stream
    T-->>B: PCM (tag 0x00) + audio_start{session_id}
    B-->>D: audio_playback_finished ack (grounds silence timer)
```

### 1.3 Turn-taking state machine — where the barge-in lives

```mermaid
stateDiagram-v2
    [*] --> Listening
    Listening --> CandidateSpeaking: VAD speech_start<br/>(120 ms hysteresis)
    CandidateSpeaking --> SilenceTail: silence begins
    SilenceTail --> CandidateSpeaking: speech resumes < 1500 ms
    SilenceTail --> EndpointFired: 1500 ms of silence<br/>(NO semantic check — a thinking<br/>pause IS an endpoint)
    EndpointFired --> AgentsRun: verifier + guardrail + override
    AgentsRun --> AIDispatch: policy Rule 1 fires YES immediately<br/>(turn_taking.py:87-93)
    AIDispatch --> AISpeaking: slow LLM → TTS → playout
    AISpeaking --> WarmupWindow: candidate starts speaking<br/>(false endpoint recovery)
    WarmupWindow --> AISpeaking: < 1500 ms barge-in warm-up —<br/>AI KEEPS TALKING OVER THEM
    WarmupWindow --> Listening: warm-up elapsed → flush
    AISpeaking --> Listening: playback ack
    Listening --> AIDispatch: 15 s total silence → re-ask
```

### 1.4 Session lifecycle, state durability & resume (as-built)

```mermaid
flowchart LR
    subgraph LIVE["Live session (shard RAM)"]
        TURNS["state.turns — full transcript<br/>+ phase clock + pool cursors"]
    end
    subgraph DURABLE["Durable"]
        EV["events.jsonl — EVERY event<br/>(never lost, append-only)"]
        CKPT["Redis ckpt:interview:token<br/>written ONLY at phase apply<br/>(director.py:887-889)<br/>payload = anchor + phase marker"]
        PGDB[("Postgres row — status")]
    end
    TURNS -- "per event" --> EV
    TURNS -- "phase boundary only" --> CKPT
    CKPT -- "resume: jump_to(phase),<br/>rehydrate 2 turns,<br/>mid-phase answers NOT restored" --> TURNS
    EV -. "read at eval time only —<br/>NOT used for live resume" .-> PGDB
```

The gap is visible in the diagram: `events.jsonl` already contains everything needed to resume mid-phase — but the live resume path reads only the phase-boundary checkpoint.

---

## 2. Where it fails — per-symptom root causes (with evidence)

### 2.1 "Transcription was slow and sometimes didn't pick up our voice"

Six independent causes stack along one path. Everything upstream of Azure can silently discard audio:

```mermaid
flowchart TB
    F["20 ms mic frame arrives on shard"] --> QF{"mic queue full?<br/>(4096 cap)"}
    QF -- "yes" --> DROP1["DROP OLDEST frame<br/>broadcaster.py:583-596<br/>→ audio splice → garbled STT"]
    QF -- no --> VADQ["VAD: 1 ONNX call per frame<br/>via asyncio.to_thread<br/>vad_service/main.py:108"]
    VADQ --> SAT{"thread pool saturated?<br/>(50 calls/s × N interviews)"}
    SAT -- yes --> LATE["speech_start arrives LATE<br/>→ Azure window opens late"]
    SAT -- no --> TH{"speech prob ≥ 0.5?<br/>config.yaml:6"}
    TH -- "no (soft speaker, low gain)" --> LOST["Azure receives ZERO BYTES —<br/>utterance never transcribed<br/>azure_stt_client.py:329-332"]
    TH -- yes --> HYST["speech_start after 120 ms hysteresis<br/>endpointing.py:84"]
    HYST --> PREROLL["STT preroll ring = 50 ms<br/>interview_session.py:138<br/>50 < 120 → ≥70 ms of EVERY<br/>utterance head clipped"]
    PREROLL --> AZ["Azure STT finally gets audio"]
    AZ --> LAG["streaming partial lag<br/>(interview_stt_partial_lag_ms —<br/>measured, not mitigated)"]

    DRIFT["Browser audio-rate drift (~2×)<br/>mic-worklet.js:11-17 — KNOWN, unfixed.<br/>ts_ms = seq × 20 ms (frame clock,<br/>not wall clock) interview_session.py:1446<br/>→ VAD silence measured in frame-time<br/>→ endpoints fire at wrong wall-clock moments"]
    DRIFT -.-> VADQ
    DRIFT -.-> AZ
```

| # | Cause | Evidence | Effect |
|---|---|---|---|
| A | **VAD hard-gates Azure STT** — `_buffer_active` false ⇒ frames discarded | `azure_stt_client.py:329-332`; `no_speech_threshold` explicitly dead (`:107` "unused") | Speech Silero misses is **never transcribed at all** |
| B | **Preroll < hysteresis** — 50 ms ring vs 120 ms speech-start delay | `interview_session.py:138` vs `vad_service/config.yaml:15` | First words ("Yes", names) truncated on **every** utterance |
| C | **Drop-oldest mic queue** under backpressure | `broadcaster.py:583-596` (logged every 500 drops) | Mid-stream splices → mis-transcription |
| D | **Per-frame ONNX via to_thread**, shared executor, 1–2 vCPU | `vad_service/main.py:108` | Late VAD events under load — compounds A+B |
| E | **Audio-rate drift** (~2×), instrumented but unfixed; frame-count timestamps | `audio_source.py:157,177-184`; `interview_session.py:1446` | Burst audio, endpoints at wrong times, "recognized never fires" |
| F | **One event loop** also parsing ~1 MB/s of base64 screen JPEG per interview | `Dockerfile.session:34`; `broadcaster.py:722-738` | Loop lag delays VAD/STT event handling for **all** interviews on the shard |

The audible face of "didn't pick up our voice": when VAD fires an endpoint but STT produced nothing, the candidate hears *"Give me a moment to process that"* every 10 s up to 3×, then *"Could you say that again?"* (`latency/orchestrator.py:429-436`).

### 2.2 "The model would start speaking while we were still answering"

```mermaid
flowchart LR
    P["Candidate pauses<br/>mid-answer to think"] --> T15["1.5 s silence tail elapses<br/>config.yaml:9"]
    T15 --> EP["VAD endpoint fires —<br/>no semantic check exists;<br/>partials CANNOT veto<br/>director.py:1521-1523"]
    EP --> R1["Policy Rule 1: candidate turn<br/>+ endpoint ⇒ YES immediately<br/>turn_taking.py:87-93"]
    R1 --> AI["AI dispatches + starts speaking"]
    AI --> RESUME["Candidate resumes their answer"]
    RESUME --> WU["barge-in warm-up 1500 ms<br/>system_config.yaml:86 —<br/>AI talks OVER them ~1.5 s more"]
    WU --> FLUSH["flush finally lands —<br/>answer now split across turns"]
```

- The **only** end-of-turn signal is the 1.5 s VAD silence timer. Pitch can *boost* endpoint confidence but "cannot trigger an endpoint on its own" (`endpointing.py:15`) — and that confidence is recorded, never used to defer dispatch (`director.py:2166`).
- Industry norm (§4.3) is layered: VAD **+ semantic end-of-turn model + STT-partial veto**, with the silence timeout *extended* (to ~3 s+) when the partial ends mid-clause. We have layer 1 of 3.
- The noise-rejection gate at `director.py:2189` (min utterance 1500 ms) is near-dead code: measured duration includes the silence tail itself, so it only trips on sub-120 ms blips.

### 2.3 "Reconnecting… repeatedly; refresh restarted the interview; parts of the conversation lost"

Three distinct failures share one overlay:

```mermaid
sequenceDiagram
    participant C as Browser (30 retries, ≤4 s backoff ≈ 2 min window)
    participant G as Gateway
    participant R as Redis registry (TTL 60 s)
    participant S0 as session-0 (dying/restarting)
    participant S1 as session-1 (healthy)

    Note over S0: shard restart (deploy · OOM · revision swap)
    C->>G: reconnect attempt 1
    G->>R: get(token) → session-0 (STALE ≤ 60 s)
    G--xS0: connect fails (open_timeout 10 s)
    G-->>C: close 1011 → "Reconnecting…"
    loop until registry TTL expires
        C->>G: retry
        G--xS0: stale pointer again
        G-->>C: close 1011 → overlay AGAIN
    end
    C->>G: retry after TTL expiry
    G->>R: get(token) → miss → least_loaded_shard
    G->>S1: proxy connects
    Note over S1: resume from checkpoint =<br/>PHASE START (or re-greet if phase 1:<br/>no checkpoint exists yet)<br/>mid-phase answers absent from<br/>LLM working set
```

| Sub-symptom | Root cause | Evidence |
|---|---|---|
| Reconnect loop | Stale registry pointer served for up to **60 s** after shard death; every retry hits the dead FQDN | `registry.py:34` (TTL), `ws_proxy.py:37-47,71-79` |
| Mid-conversation drops | No gateway→browser keepalive pings; `_pump` swallows all errors and closes both legs; PCM-over-TCP stalls on packet loss (head-of-line blocking) look like dead connections | `ws_proxy.py:100-137`; §4.1 |
| Refresh = restart | Checkpoint **only at phase apply** (`director.py:887-889`); none in phase 1 → full re-greet | `interview_checkpoint.py:18-19` |
| Transcript loss | Resume rehydrates `[anchor, phase-marker]` and `jump_to(phase)` — answers since phase start gone from working set; `resume_collapse.py` then *also* excludes them from trace/eval at read time | `interview_session.py:1249-1251` |
| (Benign case) | Same-shard reconnect within 180 s attaches to the **live** session, no loss — the loss cases are crash/restart/>180 s | `azure_app.py:943,1064-1086` |

### 2.4 "Coding submission took 15–20 seconds"

The submit itself is instant (results are cached client-side, no re-run: `coding_panel.js:404-424`). The delay is **orchestration**: nothing tells the policy to dispatch.

```mermaid
flowchart LR
    S["Submit clicked<br/>t = 0"] --> P["pending_phase set +<br/>ai_activity = AUDIO_DONE<br/>azure_app.py:2166-2170"]
    P --> W["NO dispatch trigger:<br/>Rule 1 needs a VOICE endpoint<br/>(candidate was typing).<br/>Falls through to Rule 4 —<br/>15 s silence timer<br/>turn_taking.py:104-113"]
    W --> H["panel-close handshake<br/>≤ 2.5 s<br/>director.py:301-303"]
    H --> L["slow-LLM discussion turn<br/>2–8 s (5 s filler threshold<br/>admits this)"]
    L --> T["TTS + playout 1–3 s"]
    T --> E["Heard: ≈ 5–26 s<br/>centered on 15–20 s"]
```

And if the candidate said *anything* VAD heard shortly before submitting ("okay, submitting now…"), `last_any_speech_ms` resets and Rule 4 waits the **full** 15 s from that utterance (`director.py:2110-2114`). Meanwhile the server sends nothing — the candidate stares at a silent screen.

### 2.5 Scale ceilings — what one interview costs a shard

| Resource | Per interview | Ceiling it hits |
|---|---|---|
| Mic upstream | 50 pkt/s × 640 B ≈ 32 KB/s + 100 WS sends/s to STT+VAD | Event loop |
| TTS downstream | ~32 KB/s while speaking × (1 + observers) | Event loop / WS |
| Camera JPEG | ~6.7 fps × 10–25 KB ≈ 65–165 KB/s | WS + loop |
| Screen JPEG | ~2.5 fps × 100–400 KB ≈ **0.25–1 MB/s**, each frame `JSON.parse` of a megabyte-scale base64 string **on the interview event loop** (`broadcaster.py:722-738`) | **The** loop killer |
| VAD | 50 ONNX calls/s via `to_thread` | Shared executor on 1–2 vCPU |
| Azure Speech | 1 STT + 1 TTS stream | **5 streams/key** default (`admission.py:55-56`) — 5 concurrent interviews per key before refusal |
| Recording | 2 × MediaRecorder POST every 3 s, **no retry** (`candidateEngine.ts:1373-1377`) — last ≤3 s lost on abrupt close | Reliability, not capacity |

Practical shard capacity ≈ **20–30 interviews** (1 vCPU) *if* audio keeps real-time — but the screen-JPEG parsing and VAD thread contention erode that well before 20. Scaling out is manual (new Bicep app + env edit). There is **no autoscaling, no drain, no lease** — the session tier scales by human.


---

## 3. How micro1 actually scales (research findings)

micro1 publishes arXiv papers on its own production system, so unusually much is **confirmed**:

- **Architecture: a cascaded STT → LLM → TTS pipeline of vendor APIs — the same shape as ours.** Their July 2025 paper ([arXiv 2507.16835](https://arxiv.org/abs/2507.16835)) benchmarks **five live production configs** over data from 300,000+ interviews. Winner: **Google STT + GPT‑4.1 + Cartesia TTS** (candidate rating 4.53/5). Runner configs used GPT‑4o, OpenAI TTS, Whisper.
- **Their own headline finding: STT is the weakest link** in cascaded voice agents — and objective pipeline metrics correlate only **r ≈ 0.11** with candidate satisfaction. (Lesson: collect per-interview candidate CSAT as a first-class metric; latency dashboards alone don't measure "felt good".)
- **Concurrency is modest.** ~1,500 interviews/day × 20–40 min ≈ **30–60 concurrent average**, "hundreds simultaneously" at marketing peak. The "thousands" figure is per **day**, not concurrent. A 35-person company runs this because the heavy lifting (STT/LLM/TTS) is all vendor APIs — their own infra is session orchestration + browser-side recording.
- **No evidence of WebRTC / media-server sophistication.** No job posting, paper, or blog mentions a transport layer, media server, or voice framework. Turn-taking/endpointing methods: undisclosed.
- **RAG for candidate clarifications**: LangChain + ChromaDB, resolves 75% of candidate questions without humans ([arXiv 2507.02869](https://arxiv.org/html/2507.02869v1)).
- **Proctoring is their standout product feature**: full-desktop share + camera + keystroke logging fused into an **integrity score** (gaze, tab switches, external monitor, liveness, AI-copilot detection) with a hard ~70% threshold. All browser-side signals — copyable pattern.
- Business context: $500M valuation (Sept 2025), Zara SaaS ≈ **$4–8/interview** — consistent with a cheap cascaded API pipeline (cf. Azure's real-time avatar at $17–25/interview, which we already rejected).

```mermaid
flowchart LR
    subgraph M1["micro1 Zara (confirmed shape)"]
        CAND["Browser: avatar UI,<br/>code editor, proctoring signals"] --> ORCH["Their orchestration layer<br/>(transport undisclosed)"]
        ORCH --> GSTT["Google STT"] --> GPT["GPT-4.1 / 4o"] --> CART["Cartesia TTS"] --> ORCH
        GPT <--> RAGDB["LangChain + ChromaDB<br/>(clarification RAG)"]
    end
    NOTE["~1,500/day ≈ 30–60 concurrent avg.<br/>Their moat = product features + eval flywheel<br/>(A/B five configs on live traffic, LLM-as-judge),<br/>NOT real-time infra."]
    M1 -.-> NOTE
```

**Takeaway:** the scaling bar (concurrency) is beatable with our existing shard model + P0/P1 fixes. The bar that matters is **conversation quality** — turn-taking feel, transcript reliability, reconnect resilience — plus their eval flywheel: they route live traffic across whole-stack configs and score with LLM-as-judge + CSAT. Our broker (Azure↔Groq STT, provider-pinned LLM) is the same philosophy one level shallower.

---

## 4. What the industry does (and we don't — yet)

### 4.1 Transport: why "Reconnecting" is partly physics

PCM16@16 kHz over WebSocket = **256 kbps uncompressed on TCP**. One lost packet head-of-line-blocks the whole stream ~hundreds of ms; congestion recovery is slow-start. WebRTC = Opus at 16–32 kbps (**~10× less uplink**) over UDP with jitter buffers, FEC and loss concealment — intelligible at 10% packet loss, with **ICE restarts** resuming the same session across network blips instead of a full reconnect. WS audio is defensible only on clean/controlled networks — the opposite of candidates on home Wi-Fi. ([LiveKit: why WebRTC beats WebSockets](https://livekit.com/blog/why-webrtc-beats-websockets-for-voice-ai-agents))

### 4.2 Voice-agent platforms (cost per interview-hour, media + orchestration)

| Platform | Handles | ~Cost/hr | Self-host | Python |
|---|---|---|---|---|
| **LiveKit + Agents** | SFU, reconnect/ICE-restart, server-side Egress recording, turn-detector plugin, SIP | ~$0.65 (Cloud) → $0 self-host above ~150 concurrent | ✅ Apache 2.0 | ✅ first-class |
| **Daily + Pipecat** | WebRTC infra + open Python pipeline framework (smart-turn, interruptions) | ~$0.85 all-in | Pipecat yes / Daily no | ✅ |
| **Vapi / Retell** | Fully managed agents | $6–18 | ❌ | webhooks only |
| **Agora** | Proprietary RTN + conv-AI engine | ~$6 + vendors | ❌ | SDK |

We already **locked LiveKit Phase 1** in [media-server-scaling-plan.md](media-server-scaling-plan.md) — the industry research independently converges on the same answer.

### 4.3 STT: the vendor field moved past us

| Vendor | First partial / final | Endpointing | Price | Concurrency |
|---|---|---|---|---|
| **AssemblyAI Universal-Streaming** | **~300 ms immutable partials** (never rewritten) | intelligent, turn-based API | **$0.15/hr** | 100 default, **auto-scales, no ceiling** |
| **Deepgram Flux** | conversational STT | **turn detection inside the model**: EagerEndOfTurn / TurnResumed / EndOfTurn events | $4.50/hr bundled agent API (Nova-3 raw: $0.46/hr) | 50–150 |
| **Speechmatics Ursa 2** | <1 s | configurable | $0.24–0.72/hr | plan |
| **Azure Speech (current)** | slowest finalization in third-party tests | silence-based only | $1.00/hr | **100/resource, support-ticket gated** → our multi-key broker exists to work around this |
| Whisper/Groq | **not streaming** (batch) | none | cheap | good for post-hoc re-transcription only |

Immutable partials + model-integrated endpointing directly attack our §2.1/§2.2 symptoms. AssemblyAI's auto-scaling concurrency would make the Speech-key broker largely unnecessary. For accented candidate pools, benchmark on **our own recorded interviews** — published figures degrade on accents; Speechmatics leads there.

### 4.4 Turn-taking: the missing layers

```mermaid
flowchart TB
    L1["Layer 1 — acoustic VAD (Silero)<br/>WE HAVE THIS (it's our only layer)"]
    L2["Layer 2 — semantic end-of-turn model<br/>LiveKit turn-detector v1 (open weights, CPU) /<br/>Pipecat smart-turn v3 (CPU-capable, trained on fillers) /<br/>Krisp TT (6M params)<br/>→ when it says INCOMPLETE, silence timeout<br/>EXTENDS to ~3 s+ — thinking pauses survive"]
    L3["Layer 3 — STT-partial veto + eager prefill<br/>hold endpoint when partial ends mid-clause;<br/>Flux EagerEndOfTurn = speculative LLM prefill,<br/>cancelled on TurnResumed"]
    BVC["Krisp background-voice cancellation BEFORE VAD<br/>(kills TV/other-speaker false endpoints —<br/>real interview-from-home failure mode)"]
    L1 --> L2 --> L3
    BVC -.-> L1
```

Barge-in norm: require an STT partial of **≥2–3 words** before interrupting the AI (so "mm-hm" doesn't kill the question), then flush TTS <60 ms + cancel LLM <40 ms, and **truncate the committed transcript to what was actually played**. Production targets: >96% barge-in success, <2% false barge-ins, turn-gap P95 200–450 ms. Our 1.5 s warm-up is an order of magnitude off this.

### 4.5 Session resilience norm

Server-authoritative, **event-sourced, per-turn checkpointed**. LiveKit's documented refresh-resume recipe (transplantable as requirements regardless of stack): keep the agent session alive on client disconnect, ~300 s departure grace, client rejoins with the **same identity**, conversation context survives; pair with an away-timeout. Our equivalents: token-keyed session survives WS death (we have 180 s), resume re-asks the current question (we re-greet the phase), rehydrate from event log (we rehydrate 2 turns).

### 4.6 Fleet scaling norm

Process-per-session (LiveKit Agents forks per room; Pipecat Cloud = container per session) — isolation means one pathological session can't stall neighbors (our Silero-in-loop issue is exactly that class). Worker pools autoscale on active-session count with warm spares; scale-down waits for drain. Our static hand-provisioned shard list is the outlier — and [media-server-scaling-plan.md](media-server-scaling-plan.md) Phase 3 (ownership lease + drain) is the already-planned path to it.

---

## 5. Target architecture

```mermaid
flowchart TB
    subgraph CL["Candidate browser"]
        TRK["WebRTC tracks: mic (Opus),<br/>camera, screen — adaptive,<br/>survives blips via ICE restart"]
        CWS["Thin control WS:<br/>captions, phases, coding events"]
    end

    subgraph LK["LiveKit (Cloud now → self-host at ~150+ concurrent)"]
        SFU["SFU — jitter buffers, FEC,<br/>simulcast, session resumption"]
        EG["Egress — SERVER-SIDE recording<br/>→ Azure Blob (deletes MediaRecorder,<br/>no 3 s loss, no seq holes,<br/>audio-bleed impossible by construction)"]
    end

    subgraph BR["Agent workers — process per interview, autoscaled, lease + drain"]
        DIR2["Director — UNCHANGED<br/>(AudioSource/AudioSink contracts,<br/>engine/brain/contracts/audio.py)"]
        TD["Turn detector: Silero VAD<br/>+ semantic end-of-turn model<br/>+ STT-partial veto"]
        STT2["Streaming STT — immutable partials,<br/>continuous feed (not VAD-gated);<br/>bake-off: AssemblyAI / Flux / Azure"]
        TTS3["TTS (Azure now;<br/>Cartesia = micro1's winner, later)"]
    end

    CKV[("Redis — lease + registry<br/>+ PER-TURN checkpoints")]
    EVS[("events.jsonl — event source<br/>= the resume/rehydrate authority")]
    LLM2["Groq / OpenRouter"]
    PG2[("Postgres")]
    BL2[("Blob")]

    TRK <--> SFU
    CWS <--> BR
    SFU <--> DIR2
    SFU --> EG --> BL2
    DIR2 <--> LLM2
    DIR2 --> TD
    STT2 --> TD
    DIR2 <--> STT2
    DIR2 <--> TTS3
    BR <--> CKV
    BR --> EVS
    BR <--> PG2
```

This is exactly [media-server-scaling-plan.md](media-server-scaling-plan.md)'s Phases 1–4 with two additions the research justifies: the **STT bake-off** (4.3) and the **layered turn detector** (4.4).

### The three end-states, priced

| | A — self-host LiveKit on AKS | B — LiveKit Cloud + our brain as agent | C — harden the WS stack |
|---|---|---|---|
| Fixes transport loss, reconnect, refresh-resume, recording, turn-taking, scaling | all | all (managed) | endpointing + resume only — **TCP audio stalls remain** |
| Time | 1–2 quarters | **weeks** | ≈ same eng cost as B without the payoff |
| Cost | ops burden (TURN, mesh), $0/min | ~$0.65–0.85/hr media (+$0.15/hr STT) ≈ **$1–2/interview all-in** | lowest cash cost |
| When | >~150 concurrent | **now** | only if media plane contractually locked to Azure |

**Recommendation: B now, A as the scale exit.** Same Agents code ports from Cloud to self-host — B is not a dead end. (The text-interview branch is the validated de-risking track — Sapia runs chat-only interviews at 8M+ scale.)

---

## 6. Prioritized remediation plan

### P0 — days (config + single-rule changes; ship before anything else)

| Fix | Change | Symptom killed |
|---|---|---|
| Preroll ≥ hysteresis | `stt_preroll_ms: 50 → 300` (`interview_session.py:138`) | head-clipped first words (§2.1B) |
| Coding-submit dispatch rule | policy: `pending_phase set + AUDIO_DONE ⇒ YES` (one rule in `turn_taking.py`) + speak a canned "Got your submission — give me a moment" immediately | 15–20 s submit (§2.4) |
| Registry staleness | drop registry TTL 60→15 s + faster heartbeat; delete entries on graceful shard drain | reconnect loop (§2.3A) |
| Gateway keepalive | ping/pong toward browser in `ws_proxy.py`; overlay shows "attempt n of 30" | silent WS deaths, candidate anxiety |
| VAD sensitivity | `speech_threshold 0.5 → ~0.35–0.4`, env-tunable; alert on `interview_mic_frames_dropped_total` + drift warning | soft speakers never picked up (§2.1A) |
| Silence tail per phase | `silence_tail_ms 1500 → 2000–2500` on scenario/discussion phases (cadence-driven) | cheapest barge-in reduction (§2.2) |

### P1 — weeks (contained engineering)

1. **Per-turn checkpoints** — add a second `on_checkpoint` call site at candidate-Turn append; rehydrate the full phase transcript on resume. Payload is already tiny JSON. Kills refresh-restart + transcript loss (§2.3B). *(= media-server plan Phase 4, pulled forward — it does not depend on LiveKit.)*
2. **Un-gate Azure STT** — feed it continuously (it worked this way before: `azure_stt_client.py:164-166`), use VAD only for turn-taking. Kills the "zero bytes to Azure" class (§2.1A).
3. **Semantic endpoint veto** — hold the VAD endpoint when the running STT partial ends mid-clause (punctuation/filler heuristic first, then Pipecat **smart-turn v3** on CPU). Single funnel to change: `director.on_vad_event(endpoint_detected)`. Cut `barge_in_warmup_ms` 1500→~300 for the first 2 s of an AI turn.
4. **Fix the worklet drift** — wall-clock-anchored timestamps end-to-end instead of `ts_ms = seq × 20 ms`; assert browser sample-rate assumptions at lobby mic-check.
5. **Recording upload retry** + browser transcript rehydrate on refresh (from `/state`-style endpoint reading events.jsonl tail).
6. **Candidate CSAT prompt** at interview end — micro1's r≈0.11 finding says our dashboards can't see what candidates feel.

### P2 — the quarter (the locked plan + bake-off)

1. **LiveKit Phase 1** (audio transport + Egress recording) per [media-server-scaling-plan.md](media-server-scaling-plan.md) — resume Workstream A (gateway token endpoint), then B/C behind `MEDIA_TRANSPORT=livekit|ws`, parity-gate, canary.
2. **STT bake-off on our own recordings** — AssemblyAI Universal-Streaming vs Deepgram Flux vs Azure baseline: partial latency, finalization, accent WER, endpointing quality. Swap is contained behind the existing STT-client seam + broker.
3. **Turn-detector model** as the Layer-2 endpointing (LiveKit plugin if on LiveKit; smart-turn v3 standalone otherwise).
4. **Phases 2–3** (control broker, ownership lease + drain + autoscaling) — unlocks `maxReplicas > 1`, deletes the hand-scaled shard list.
5. **Video tracks + server-side proctoring signals** — replace JPEG-over-WS; then build the fused **integrity score** (micro1's best product idea: gaze + tab + monitor + liveness + copilot detection → one thresholded number).

### KPIs to hold the line on

| Metric | Today | Target |
|---|---|---|
| Turn gap (endpoint → first TTS audio) P95 | multi-second | 200–450 ms (industry norm) |
| False AI barge-ins (spoke while candidate mid-answer) | frequent (reported) | <2% of turns |
| Utterance head loss | ≥70 ms always | 0 (preroll fix), then n/a (continuous STT) |
| Reconnect → resumed in place | restart from phase/greeting | <5 s, mid-phase, full transcript |
| Coding submit → AI speaks | 15–20 s | <3 s (canned bridge), <8 s (substantive) |
| Recording loss on abrupt close | ≤3 s + seq holes | 0 (server-side Egress) |
| Candidate CSAT | not collected | collected on 100% of interviews |

---

## Appendix — evidence index (file:line)

- VAD-gated STT write: `engine/brain/streamA_bridge/azure_stt_client.py:329-332`; dead `no_speech_threshold`: `:107`; pre-gating comment `:164-166`
- Preroll 50 ms: `engine/brain/runtime/interview_session.py:138` · hysteresis 120 ms: `engine/speech/services/speech_io/vad_service/config.yaml:15`, `endpointing.py:84` · silence tail 1500 ms: `config.yaml:9`, `endpointing.py:110`
- Mic drop-oldest: `engine/orchestrator/web/broadcaster.py:583-596` · VAD to_thread: `vad_service/main.py:108` · frame-count clock: `interview_session.py:1446` · drift detectors: `engine/orchestrator/web/audio_source.py:157,177-184`
- Endpoint = single trigger; partials can't veto: `engine/brain/core/director.py:1391-1394,1521-1523` · policy Rule 1: `engine/brain/core/policy/turn_taking.py:87-93` · Rule 4 (15 s): `:104-113` · barge-in warm-up: `interview_session.py:196`, `config/system_config.yaml:86`
- Registry TTL: `app/coordination/registry.py:34` · gateway proxy fail path: `app/gateway/ws_proxy.py:37-47,71-79,100-137` · reconnect window: `ui/web/src/lib/candidateEngine.ts:120,880-885`
- Phase-only checkpoint: `director.py:887-889`, `app/coordination/interview_checkpoint.py:18-19` · resume rehydrate: `interview_session.py:1249-1251` · orphan TTL 180 s: `deploy/azure_app.py:943`
- Coding submit path: `ui/web/src/coding/coding_panel.js:404-424`, `deploy/azure_app.py:2069-2170`, handshake `director.py:301-303,807-817`
- Scale ceilings: `deploy/Dockerfile.session:34` (`-w 1`), `deploy/aca/main.bicep:337` (pinned), `app/coordination/admission.py:55-56` (5 streams/key), `broadcaster.py:722-738` (JPEG parse on loop), `candidateEngine.ts:1298,1337,1373-1377` (recording)

**Research sources:** micro1 — [arXiv 2507.16835](https://arxiv.org/abs/2507.16835), [arXiv 2507.02869](https://arxiv.org/html/2507.02869v1), [micro1.ai/research](https://www.micro1.ai/research), [TechCrunch Sept 2025](https://techcrunch.com/2025/09/12/micro1-a-competitor-to-scale-ai-raises-funds-at-500m-valuation/), [Sacra](https://sacra.com/c/micro1/). Industry — [LiveKit WebRTC-vs-WS](https://livekit.com/blog/why-webrtc-beats-websockets-for-voice-ai-agents), [LiveKit reconnect recipe](https://livekit.com/blog/keep-your-agent-in-the-room-on-reconnect), [LiveKit turn detector](https://livekit.com/blog/solving-end-of-turn-detection), [smart-turn v3](https://huggingface.co/pipecat-ai/smart-turn-v3), [AssemblyAI Universal-Streaming](https://www.assemblyai.com/blog/introducing-universal-streaming), [Deepgram Flux](https://developers.deepgram.com/docs/flux/configuration), [Azure Speech quotas](https://learn.microsoft.com/en-us/azure/ai-services/speech-service/speech-services-quotas-and-limits), [Krisp turn-taking](https://krisp.ai/blog/turn-taking-for-voice-ai/), [Hamming barge-in runbook](https://hamming.ai/resources/voice-agent-interruption-handling-runbook), [Coval STT benchmarks](https://www.coval.ai/blog/best-speech-to-text-providers-in-2026-independent-benchmarks-and-how-to-choose/), [LiveKit pricing](https://livekit.com/pricing), [Pipecat Cloud pricing](https://www.daily.co/pricing/pipecat-cloud/).
