# Text-to-Text Interview Mode — Architecture & Plan

**Date:** 2026-08-14 · **Status:** Draft for review · **Author:** (interview-assist team)

A second interview modality alongside the live voice interview: a **stateless,
autoscaling, question-driven text chatbot**. The candidate types, the AI
interviewer types back. No STT, no TTS, no VAD, no media server. Modality is
chosen up-front on the New Interview form; everything from resume-parse and
cadence generation onward is reused, with cadence made **untimed** for text.

---

## 1. Why this is a good fit for the existing code

Three findings from the codebase make this far cheaper than it looks:

1. **The interviewer brain is already text-in / text-out.** The speech layer
   only wraps it. A candidate utterance enters as a plain `Turn`; the AI reply
   leaves as plain text (`LatencyOrchestrator._send_slow_chunk_now` →
   `speak_chunk`, mirrored on the bus as `TTS_SPEAK_CHUNK_SENT` with the raw
   text). TTS is the *last* step, not woven through.
2. **The fixed-question loop already exists.** A `question_mode: "specific"`
   phase with a `question_pool` already asks one question at a time, follows up
   until coverage tags are satisfied (verifier `missing_tags` → probe), pops the
   question when answered, and **auto-advances the phase on pool exhaustion,
   regardless of time** (`cadence_tracker.py:198-200`). Adaptive difficulty and
   coverage-tag probing are already answer-driven, not clock-driven.
3. **Evaluation is timing-agnostic.** The v2 sectioner splits on event markers
   (`phase_changed`, `question_dispatched`), never on elapsed seconds, and every
   plugin scores on coverage tags / rubric marks / difficulty / coding ids. A
   text-mode interview that emits the same `events.jsonl` scores **identically,
   with zero eval changes.**

So text mode is mostly *subtraction* (drop the tick loop, LatencyOrchestrator,
STT/VAD/TTS, media transport, the time trigger) plus one genuinely new piece:
**serialize the interview state to Redis so each turn is a stateless
request/response.**

---

## 2. Target architecture

A **new ACA app** — call it the **text tier** (`text-0`… or a single
autoscaling app) — separate image, stateless, KEDA-autoscaled on HTTP
concurrency (like the gateway), `minReplicas: 0/1 → maxReplicas: N`. It does
**not** hold interview state in memory; any replica can serve any turn.

```
Candidate browser (React text UI)
      │  POST /text/{token}/turn   { answer: "..." }      (one HTTP call per answer)
      ▼
Gateway (existing)  ── routes text sessions to the text tier ──►  TEXT TIER (new, stateless, autoscale)
                                                                     │ 1. load state blob from Redis (ckpt/state key)
                                                                     │ 2. append candidate Turn
                                                                     │ 3. verifier + guardrail (fast LLM)  → merge/cap/pool-pop
                                                                     │ 4. advance phase if pool exhausted / override
                                                                     │ 5. build_context → QuestionAgent.run (slow LLM)  → AI text
                                                                     │ 6. append events.jsonl (per-turn, append-blob)
                                                                     │ 7. save state blob to Redis
                                                                     ▼
                                                              { question: "...", phase, done: false }
      ...repeat until done...
   session end → mirror events.jsonl to Blob → ENQUEUE eval_v2 (existing worker path, unchanged)
```

**Reused infrastructure (no change):** Postgres (system of record), Redis
(coordination + now state store), Azure Files / Blob (per-session artifacts +
events.jsonl), the worker tier (cadence-gen, eval), and the whole
schedule→cadence→approve admin flow.

**Not needed for text:** the LiveKit media server, the pinned session shards,
the `WebBroadcaster` PCM relay, Speech-key admission/broker, `MEDIA_TRANSPORT`.
Redis + Blob fully cover text state and durability.

### Why stateless works here (and didn't for voice)
Voice is pinned because a live audio turn (~900 ms budget, TTS buffers, VAD FSM)
can't take a network hop mid-turn. Text has no real-time loop: a turn is one
HTTP request bounded by two LLM calls (verifier + question). Between turns there
is nothing live to keep in memory — so the state can live in Redis and any
replica can pick up the next turn. That is exactly what makes autoscaling +
scale-to-zero possible.

---

## 3. The stateless turn engine (`TextTurnEngine`)

A new, thin, audio-free coordinator that **reuses the brain's real logic** and
replaces only the tick loop + LatencyOrchestrator. Reuse ledger from the code
audit:

**Reused as-is (no changes):**
- `QuestionAgent.run(ctx, on_utterance_char, on_first_token, cancel_event)` —
  drive with an accumulating char sink, a no-op first-token, and a never-set
  `cancel_event`; read `res.utterance` (the full, tag-stripped AI text).
- `build_context(...)` — pure: state in → `ConversationContext` out. Derives its
  "elapsed"/"silence" values by arithmetic on stored timestamps, so it works
  with a per-turn cumulative clock.
- `VerifierAgent.verify(ctx)` and `GuardrailAgent.classify(ctx)` — already
  discrete, per-candidate-turn calls, no audio coupling.
- `CadenceTracker` phase/pool logic — `current_phase`, `peek_next_question`,
  `mark_current_question_presented`, `pick_next_question`,
  `render_think_directive`, `jump_to`.
- `SessionState`, `Turn`, `LLMClient`, `ConversationContext`.

**Lifted out of `Director` into the engine (plain logic, no audio):**
- The verifier/guardrail/override **priority merge + consecutive-`partial_answer`
  follow-up cap + pool-pop** (today `director.py:1628-1757`).
- The **apply-pending-phase + `mark_current_question_presented` +
  `question_dispatched` emission** (today the YES branch, `director.py:919-1155`).

**Dropped entirely (voice-only):** `Director.run`/`_tick` and the `policy.decide`
"should I speak now" gate (the POST *is* the trigger), all STT/VAD ingestion,
`LatencyOrchestrator` in full (fillers, apologies, TTS chunking, sink-drain,
barge-in, strikes), `FillerAgent`/`ApologyAgent`, `TTSClient`, audio sink, mic
pump, watchdog, silence re-engagement.

**Turn model (locked): one candidate message = one turn.** Each POST carries one
answer and triggers exactly one AI reply; the verifier fires on that message. No
multi-message composition before the AI responds (submit-based essay phases in
§6.5 are the deliberate exception — there the whole panel submission is the turn).

### One turn, precisely
```
load state + tracker snapshot from Redis
append Turn(speaker=CANDIDATE, text=answer)
ctx = build_context(state, tracker=tracker)
verifier, guardrail = await gather(verify(ctx), classify(ctx))     # + optional override
apply merge → maybe scrub+re-ask (guardrail) / re-probe (partial) / pop question (answered)
if pool_exhausted(current_phase): tracker.advance()  (or end if terminal)   # UNTIMED trigger
if interview_over: emit session_ended; enqueue eval; return {done:true, closing:"..."}
ctx = build_context(state, tracker, verifier_instruction=...)      # rebuild after pool/phase moves
ai_text = (await QuestionAgent.run(ctx, ...)).utterance
append Turn(speaker=AI, text=ai_text); emit question_dispatched/ai_utterance events
save state + tracker snapshot to Redis
return {question: ai_text, phase, done:false}
```

---

## 4. State model & resume (the one genuinely new subsystem)

Today only a phase-boundary *anchor* is checkpointed (`ckpt:interview:{token}` =
`{phase_id, 2 anchor turns, resume_count, elapsed_ms_at_phase_entry}`, 2 h TTL),
because a live in-memory session owns the truth. A stateless service must persist
the **full** state every turn.

**Persist per turn (Redis blob, keyed `text:state:{token}`, TTL refreshed):**
- Identity: `session_id`, `candidate_id`, `candidate_profile` (name/role/resume
  summary — or reload from the precomputed resume artifact).
- **Full `turns` history** (not 2 anchors) via an extended `turn_to_jsonable`.
- `rolling_summary` (compressed older context).
- **CadenceTracker snapshot** — *net new*: `_current_phase_id`, question-pool
  cursor (`remaining`/`asked_ids`), adaptive-difficulty ladder state,
  `_presented_question_id`, phase-entry marker. Without this the pool resets
  every turn (re-asks Q1 forever). Needs a `tracker.to_jsonable()/from_jsonable()`.
- Per-question counters from the Director logic: `partial_count_current_q`,
  `latest_missing_tags`, `latest_verifier_instruction`.
- Scoring/cost/integrity: `rubric_scores`, `active_flags`, `risk_score`,
  `cost_so_far_usd`, `llm_usage`.
- `last_coding_submission` (only if coding phases are in scope).

**Drop:** the entire live-audio/VAD block, observer-PTT fields,
`kokoro_chars_per_second`, `audio_played_ms` — all meaningless for text.

**New serializers to write:** `state_to_jsonable` / `state_from_jsonable` and the
`CadenceTracker` snapshot pair. These don't exist today (the checkpoint only
covers phase+anchor-turns).

**Resume = free.** Because state is loaded from Redis every turn, "resume after
disconnect" is just the next POST re-loading the same key. The candidate reopens
the link, the UI GETs the current transcript + pending question from state, and
continues. No special resume bring-up, no re-greeting. (Redis TTL is the backstop;
Postgres + events.jsonl remain the durable truth.)

---

## 5. Events & evaluation (keep the pipeline unchanged)

The text engine emits the **same `events.jsonl`** the eval sectioner already
reads, using the existing `append_event_oneshot()` row shape
(`{session_id, ts, kind, payload}`), appended **per turn to Blob (append-blob) /
`sessions/{token}/events.jsonl`**. This keeps the sectioner, event viewer,
evaluation_service, resume-collapse, and `event_index` deep-linking byte-for-byte
compatible — no eval code changes.

**Required event set** (non-coding): `session_started`(`initial_phase`) →
`phase_changed` (applied marker, **must not carry `queued:true`**, with
`to_phase`) → `question_dispatched`(`question_id`, `question_text`, `topic`,
`difficulty`, `coverage_tags`) → `stt_final`(candidate answer in `text`) →
`ai_utterance`(`text`) → `session_ended`. Optional but recommended (benchmark
plugins consume them): `verifier_classified`(`missing_tags`, `intent`),
`guardrail_triggered`. Coding phases additionally need `coding_phase_started` +
`coding_code_submitted`.

> Note: we reuse the `stt_final` kind for the candidate's typed answer (the
> sectioner already maps it to a candidate turn) rather than inventing a new
> event, so nothing downstream needs to learn a new kind. (Optionally add a
> `source:"text"` payload field for clarity — ignored by eval.)

Session-end mirrors artifacts to Blob and enqueues `eval_v2` exactly as the voice
path does today.

---

## 6. Cadence: schedule-time modality + untimed plans

### 6.1 Modality chosen on the New Interview form
Add a modality selector next to name/resume/role (`ui/web/src/pages/Schedule.tsx`,
mirroring the existing `record_enabled` checkbox precedent end-to-end):
- `ScheduleForm` gains `modality: "voice" | "text"` (or a boolean `text_only`).
- New DB column on `sessions` (+ additive migration in `db/engine.py`), written
  at `create_draft`, immutable after creation (same discipline as
  `record_enabled`).
- Mirrored into `cadence.yaml` (new `timed: bool` — see below) via a stamp
  function alongside `apply_recording_flag`, so the runtime reads modality from
  the approved plan.

Because modality is known **before** cadence generation, the worker generates the
right *shape* of plan from the start (no later conversion).

### 6.2 Untimed cadence + per-phase timing — minimal schema change
"Untimed" is a **per-interview default that text mode sets, but timing is really a
per-phase property.** A voice interview is fully timed by its cadence; a text
interview is untimed *except* for special submit-based phases (see §6.5) that run
their own timer. So:

- Add `timed: bool = True` at the **plan** level (`CadencePlan`) and gate the
  totals validator on it. Voice: `timed=True`, unchanged validation. Text:
  `timed=False`, `_check_totals` skipped, durations ignored at runtime.
- Keep per-phase `duration_s` populated with a dummy `1` for untimed plans so the
  strict `PhaseDef.duration_s > 0` check stays intact for the voice path.
- The tracker's wall-clock trigger (`check_phase_budget`,
  `cadence_tracker.py:210-216`) is gated on the plan's `timed`; untimed phases
  advance only on pool exhaustion / override. Suppress the `elapsed_s`/`budget_s`
  prompt lines (`cadence_tracker.py:428-434`) so the LLM is never told about a
  clock.

**Phase termination (locked):** all text-mode phases are **pool-backed
(`specific`)**. Each question in the pool runs up to **N follow-ups** (the
existing `max_follow_ups` cap + `coverage_tags`/`follow_ups` probing) and then
moves on; the phase advances when the pool is exhausted. No new completion logic
— this is exactly today's `specific`-phase behavior with the time trigger off.

### 6.5 Timed submit-based phases (written-response / essay) — both verticals
A new phase type generalizing the existing **coding-phase submit lifecycle** (panel
pops → timer starts on display → ends on submit). The admin configures a
**question**, a **word limit**, and a **time limit**. Applies to **both voice and
text**:
- **Voice:** the phase is already timed by cadence; the essay panel + word limit
  is the new part.
- **Text (otherwise untimed):** this specific phase is **timed** — when the panel
  is presented the client starts the countdown; on submit (or expiry) the client
  posts a `written_response_submitted` event that ends the phase. **The server
  stays stateless** — the timer is client-enforced (like today's coding countdown)
  and the submit is just another turn POST; we persist the submitted text + the
  elapsed time in state/events. No live server clock is required.

Schema: a phase carries an optional `timed_submission: {word_limit, time_limit_s}`
(or reuse/rename the coding fields). Runtime: reuse the coding phase's
present-panel / submit-ends-phase path (`coding_phase_started` →
`coding_code_submitted` analog), swapping Monaco for a word-limited text composer.
Evaluation: the submitted essay is scored by an eval plugin like any other segment
(reuse `rubric_marks` / `conversational_rubric`). **Deferred to Phase 6** — noted
here because it makes `timed` a per-phase concept from the start, so the schema
should not assume timing is purely plan-level.

> **Coding phases are unchanged and stay fully supported for voice.** They are
> simply **not offered in text mode at launch** — the text cadence editor won't
> expose a coding phase, and the text turn engine won't wire the Monaco/Pyodide
> panel yet. Nothing about the existing coding feature is removed or altered.

### 6.3 Cadence generation
Reuse the generation path (`_cadence_gen` → `generate_cadence_yaml` →
`load_cadence`). Add a **text-mode variant of the `cadence_converter` prompt**
that stops allocating seconds and instead allocates questions-per-phase +
`coverage_tags` (exactly what the fixed-question runtime consumes). The loader's
validation-driven retry loop then "just works" once the schema accepts `timed`.

### 6.4 Cadence editor
~⅔ of the editor is modality-agnostic structure/content (phase add/remove/reorder,
the phase resolver, the modifying agent that authors intents/prompts/questions).
The duration machinery (parse/rescale/reconcile, ~121 lines) is self-contained.
For text mode: gate the duration step out of `plan_deterministic` and present a
**questions-and-coverage editor** (no durations). The router/validating agents'
duration logic becomes dead-but-harmless.

---

## 7. Frontend (candidate)

Target the React SPA (`ui/web/`), which already has the display half:
`TranscriptView`, AI captions, and a full text-input `ChatPanel`. Work:
- **Lobby:** for text mode, skip mic/camera/screen/AudioWorklet setup entirely
  (gate `refreshStartReady` on modality); simple "Start" → consent → chat.
- **Live:** a chat transcript + a candidate answer composer (reuse the
  `ChatPanel` pattern). On submit, `POST /text/{token}/turn`; render the returned
  question as an AI row. No WebSocket/PCM path.
- **Resume:** on open, GET current state → render transcript + pending question.
- Essay/written-response phase (Phase 6, §6.5): a word-limited composer with a
  client-side countdown, following the existing coding-panel present/submit
  pattern; submit posts the answer as the phase-ending turn.

Admin side needs the modality selector on Schedule + a modality-aware cadence
review screen (hide durations for text).

---

## 8. Deployment & routing

- **New image + ACA app** (`Dockerfile.text` on the shared base, slim — no audio
  deps). Stateless; KEDA HTTP-concurrency scaling; scale-to-zero capable.
- **Routing:** the gateway (or Front Door route) sends text sessions to the text
  tier and voice sessions to the pinned session shards, keyed on the session's
  modality (looked up from Redis registry / Postgres at connect time). This
  mirrors the existing "pick a shard" placement, with a modality-aware target.
- Env: reuse `REDIS_URL`, `DATABASE_URL`, `AZURE_STORAGE_CONNECTION_STRING`,
  `SESSIONS_DIR`, `SLOW_*`/`FAST_*` model routing. No Speech keys, no LiveKit.

---

## 9. Phased delivery

- **Phase 0 — schema + modality plumbing.** `timed` flag + validator gate; drop
  durations for untimed; `modality` on `ScheduleForm`/DB/cadence stamp; Schedule
  UI selector. (Backward-compatible; voice path provably unchanged.)
- **Phase 1 — `TextTurnEngine` (offline).** Assemble the one-turn engine from the
  reuse ledger; drive it from a script over a fixed cadence + canned answers;
  assert it emits an eval-compatible `events.jsonl` and runs the existing eval.
- **Phase 2 — state serialization + Redis.** `state_to_jsonable` + tracker
  snapshot; per-turn load/save; prove resume by killing between turns.
- **Phase 3 — HTTP service + new ACA app.** `POST /text/{token}/turn`,
  `GET /text/{token}/state`; per-turn append-blob events; deploy the text tier;
  gateway routing.
- **Phase 4 — candidate + admin UI.** Text lobby/chat/resume; modality-aware
  cadence review.
- **Phase 5 — cadence-gen text prompt + editor gating.** Text-mode
  `cadence_converter`; duration-free editor.
- **Phase 6 — timed submit-based written-response (essay) phase (both verticals,
  §6.5).** Generalizes the coding submit lifecycle: admin-configured question +
  word limit + time limit; client-enforced timer; submit ends the phase; scored
  by an existing eval plugin. Coding phases are unchanged and still available for
  voice — just not exposed in text mode at launch.

Each phase is independently shippable; the voice path is untouched throughout.

## Locked decisions (from review)
- **Coding rounds:** unchanged and still supported for voice; **not exposed in
  text mode at launch** (not removed). The related new need is the **timed
  written-response/essay phase** (§6.5, Phase 6), for both voice and text.
- **Phase termination:** all text-mode phases are pool-backed (`specific`) with N
  follow-ups per question, then advance on pool exhaustion. No generic
  untimed phases.
- **Turn model:** one candidate message = one turn (essay panel submission is the
  one exception).
- **`timed` is a per-phase concept** even though the plan carries a default:
  an untimed text interview may contain a timed essay phase.

---

## 10. Open decisions

1. **Schema approach** — `timed: bool` (plan) + a per-phase `timed_submission`
   for essay phases + dummy durations (recommended, keeps voice validation
   strict) vs. pure dummy durations with no schema change. *(Recommend the flag.)*
2. **One text ACA app vs. a shard pool** — stateless means a single autoscaling
   app suffices; confirm no per-session pinning is wanted. *(Recommend one app.)*
3. **Essay-phase timer authority** — client-enforced countdown + submit POST
   (keeps the tier stateless; matches today's coding countdown) vs. a
   server-tracked deadline stored in Redis state (survives a client clock skew but
   adds a time check per turn). *(Recommend client-enforced for launch.)*
