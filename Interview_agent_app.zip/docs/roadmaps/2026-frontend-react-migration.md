# Frontend Migration — Jinja → React SPA (industry-standard)

**Date:** 2026-06-12 · **Status:** Approved, in progress on `demo-prod` · **Decision owner:** Prabhudev

The product moves from server-rendered Jinja templates + vanilla JS to a single
React SPA + JSON API, deployed in the **same FastAPI container** (no new Azure
cost). Migration is **incremental** — the app keeps working the whole time;
screens flip from Jinja to React one at a time.

## Locked decisions
- **Stack:** Vite + **React + TypeScript**, **React Router** (routing),
  **TanStack Query** (server-state/data fetching), **Tailwind CSS + Radix/
  shadcn-style headless components**.
- **Backend:** FastAPI stays. It exposes a JSON API and serves the built SPA.
- **Auth:** existing **cookie session** (httpOnly, same-origin) — SPA calls the
  API with the cookie. One login, no JWT.
- **Deploy:** **multi-stage Dockerfile** — a Node stage builds the SPA; the
  Python image copies only `dist/` (the Node toolchain is discarded, so the
  runtime image stays lean). Single container, B-tier, unchanged cost.
- **Scope:** **everything**, including the real-time clients (live candidate
  interview UI + observer audio/WS) — but those migrate **LAST** (highest risk).

## Where the SPA lives
`ui/web/` — Vite React+TS app (seeded from the `recruit_ui` branch's
components). Built output `ui/web/dist/` is served by FastAPI.

## Coexistence (the app never breaks)
During migration the SPA and the existing Jinja UI run side by side:
- Existing Jinja screens keep serving at `/admin/*`.
- The SPA serves at `/` (and owns client-side routes); FastAPI returns
  `index.html` for any non-`/api`, non-`/admin`, non-asset path (SPA fallback).
- Each screen's React version is built against the JSON API, then its route is
  flipped and the old Jinja template deleted.

## Phases
| Phase | Work | Exit criteria |
|---|---|---|
| **0 — Foundations** | Scaffold `ui/web/` (Vite+TS+Tailwind+Router+Query). Multi-stage Docker. FastAPI serves `dist/` + SPA fallback. Cookie login screen. Home tiles (Shortlist · Interview). | SPA builds; `/` shows Home tiles behind login; `/admin/*` untouched |
| **1 — API-fy backend** | JSON counterparts for the remaining HTML routes (dashboard list, schedule CRUD, cadence get/approve, session detail eval). Many JSON endpoints already exist (cadence validate/revise, rubric, coding, shortlist). | every screen the SPA needs has a JSON endpoint |
| **2 — Migrate console screens** | React, one at a time: Home → **Shortlist** → Dashboard → Schedule → **Cadence review** (preview + rubric panel + customizer + adaptive-difficulty + question picker) → **Session detail** (performance + interview trace + cadence + observability + coding replay). Flip route, delete template. | console fully on React; Jinja admin templates removed |
| **3 — Real-time clients (last)** | Port the candidate interview client (AudioWorklet, WS framing, barge-in, coding panel w/ Monaco+Pyodide) and the observer (PTT audio, presence) to React — carefully, behind a flag, with the old client kept until verified. | real-time UX parity proven, then old clients removed |
| **4 — Cleanup** | Remove Jinja (`templates/`, `admin.js`), drop `jinja2` if unused, fold `ui/candidate` into the SPA. | one frontend stack |

## Screen inventory (migration checklist)
- [ ] Login (cookie) · [ ] Home tiles
- [ ] Shortlist: create role · upload JD + resumes · threshold · ranked results · candidate detail
- [ ] Dashboard (sessions list, archive/delete) · [ ] Schedule (role/JD/resume/cadence-reqs form)
- [ ] Cadence review (preview, rubric panel, customizer, adaptive difficulty, question picker, approve)
- [ ] Session detail (performance dashboard, interview trace, cadence tab, observability, coding replay)
- [ ] **(last)** Candidate interview client · Observer live page

## Risks / notes
- **Real-time clients are the risk.** Audio worklet + WS + barge-in is working,
  specialized code; rewrite last, keep the old client behind a flag until parity
  is proven. Do NOT block console migration on it.
- **API boundary is the long pole**, not React. Most HTML routes need a JSON
  twin; do Phase 1 thoroughly so screens aren't blocked.
- **Build time** grows (Node stage) but runtime image/cost is unchanged.
- **TanStack Query** owns caching/refetch; avoid bespoke fetch state.
- Cookie auth + same-origin API = no CORS, no token storage in JS.
