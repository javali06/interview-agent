# Simli avatar — setup, comparison and cost

Photoreal interviewer avatar, offered as a third visual mode alongside the
TalkingHead 3D model and the minimal orb. This document covers how to run it
locally, how it compares to what we already have, and what it would cost.

**Status: exploration.** It is wired in and works, but has not been adopted.
See [Adopt / do-not-adopt](#adopt--do-not-adopt) at the end.

---

## 1. Setup

### 1.1 Get an account

1. Sign up at <https://www.simli.com/> and open the dashboard.
2. Copy the **API key**.
3. Pick a **face** and copy its **Face ID** (a UUID).

The free plan is enough to develop against — see [sandbox limits](#74-sandbox-limits-that-cap-testing).

### 1.2 Configure

The key is **server-side only**. Add to `deploy/local/.env` (containers) or the
repo-root `.env` (native run):

```ini
SIMLI_API_KEY=<your key>
SIMLI_FACE_ID=<face uuid>

# Optional
SIMLI_MODEL=              # "fasttalk" | "artalk" — blank uses Simli's default
SIMLI_MAX_SESSION_S=3600  # hard cap; the session is cut at this point
SIMLI_MAX_IDLE_S=300      # disconnect after this much silence — the cost guard
```

> **Never expose the key as `VITE_*`.** Anything prefixed `VITE_` is compiled
> into the browser bundle. Simli is metered, the candidate page is public, and
> the key would be readable in devtools by anyone who opens an interview.

`SIMLI_MAX_IDLE_S` matters more than it looks: Simli bills **wall-clock
streaming minutes including silence**, and an interview is mostly the candidate
talking. Without an idle cap, a tab left open bills until `MAX_SESSION_S`.

### 1.3 Rebuild and run

Application source lives in `Dockerfile.base`, so **base first**, then the tier,
then recreate the container (a new image tag alone does not replace a running
container):

```powershell
podman build -f deploy/Dockerfile.base -t interview-agent-base:local .
podman build -f deploy/Dockerfile.gateway --build-arg BASE_IMAGE=interview-agent-base:local -t interview-agent-gateway:local .
podman stop interview-scaled_gateway_1 ; podman rm interview-scaled_gateway_1
podman-compose -f deploy/local/docker-compose.yml up -d
```

### 1.4 Verify

```powershell
# 1. endpoint present in the running container
podman exec interview-scaled_gateway_1 grep -c "api/simli/token" /app/app/main.py

# 2. env reached the container
podman exec interview-scaled_gateway_1 sh -c 'echo "${SIMLI_API_KEY:+key set}"'

# 3. a real mint (use any scheduled interview token)
curl.exe -s "http://localhost:8080/api/simli/token?token=<INTERVIEW_TOKEN>"
```

A healthy response is `{"session_token":"trinity1_...","ice_servers":[...]}`.

| Response | Meaning |
|---|---|
`503 simli_not_configured` | `SIMLI_API_KEY` / `SIMLI_FACE_ID` missing from the container |
`503 simli_token_failed` | Simli rejected the key, or the face id is wrong |
`503 simli_unreachable` | network / DNS |
`403 unknown_session` | the interview token is not a real session |

Then open a candidate link, hard-refresh, and choose **Photoreal (Simli)** in the
lobby's *Interviewer* row **before** starting — the mode cannot be changed once
the interview is live.

### 1.5 Troubleshooting

**The lobby only shows two options.** The browser is on a cached bundle, or the
gateway image was not rebuilt. Confirm the served bundle contains the option:

```powershell
podman exec interview-scaled_gateway_1 sh -c 'grep -rl "Photoreal (Simli)" /app/ui/web/dist/assets/'
```

**You get the orb instead of a face.** That is the designed fallback. The
browser console says which path failed:

| Console line | Cause |
|---|---|
`[simli] token endpoint returned 503` | configuration (see table above) |
`[simli] boot failed` | WebRTC could not connect |
`[simli] needs 16000Hz PCM16 …` | TTS output format changed |

**The container build fails with `Could not resolve "./Client"`.**
`simli-client@3.0.2` ships a broken entry point: `dist/index.js` does
`require("./Client")` but the file on disk is `dist/client.js`. Windows and macOS
are case-insensitive so it resolves; Linux is not, so it passes local typecheck
and fails the Docker build. We deep-import `simli-client/dist/client` to bypass
it. Revisit if upstream fixes the case.

---

## 2. How it works

```
                    ┌─────────────────────────────────────┐
  browser           │  gateway                            │      Simli
    │               │                                     │
    │ GET /api/simli/token?token=…                        │
    │──────────────>│  POST /compose/token  (key in header)──────>│
    │               │  GET  /compose/ice                  │──────>│
    │<── session_token + ice_servers ──                   │
    │                                                     │
    │ new SimliClient(session_token, …)  ── WebRTC ───────────────>│
```

The **API key never leaves the gateway.** The browser only ever holds a
short-lived session token, and the endpoint is gated on a real interview token
so it cannot be used as an open minting service.

### 2.1 The audio split — the load-bearing decision

The `AvatarSink` contract is that `speak()` resolves only when the candidate has
**actually stopped hearing** the utterance. The backend keys the no-response
silence timer, VAD gating and wrap-up teardown off that moment.

Simli cannot provide it. Its SDK emits `speaking` / `silent`, but those are
relayed **server** control messages — see `simli-client`
`lib/transports/BaseTransport.ts`, `case "SILENT": transport.emit("silent")`.
They mean *the server stopped sending*, which happens before the audio crosses
the network and drains the client jitter buffer. Resolving on that would start
the silence timer while the AI is still audibly speaking.

So the two jobs are split:

```
PCM ─┬─→ our own AudioContext   → the candidate HEARS this
     │                           → real AudioBufferSourceNode.onended
     │                           → THAT resolves speak()        (grounded)
     └─→ Simli sendAudioData()  → drives the lip-sync VIDEO only
                                  (its <audio> element stays muted)
```

Consequences, in order of importance:

- the completion signal is **local and exact** — the same mechanism minimal mode
  already uses, which the engine already trusts (`via:"onended"`);
- **VAD behaviour is unchanged**, because the AI's voice reaches the speaker by
  exactly the path it does today;
- if Simli's video stalls or drops, the candidate **still hears the whole
  interview**. Video is decorative; audio is the interview;
- recording is unaffected — it already taps raw PCM *before* the sink.

The cost of this design: face and voice are driven independently and can
**drift**. `AV_OFFSET_MS` in `simliAvatar.ts` delays local playback to
compensate; it ships at `0` so that drift can be measured honestly first.

### 2.2 Files

| File | Change |
|---|---|
`ui/web/src/lib/simliAvatar.ts` | New. The adapter. |
`app/main.py` | New `GET /api/simli/token`. |
`ui/web/src/lib/candidateEngine.ts` | `VisualMode` gains `"simli"`; new `getToken()`. **No call-site changes.** |
`ui/web/src/pages/Candidate.tsx` | Third radio option; `Stage` picks the boot fn. |
`ui/web/package.json` | `simli-client@^3.0.2`. |

`talkingHead.ts`, `kickPlayer()`, the sink contract and everything under
`engine/` are untouched. The server does not know which avatar is in use.

### 2.3 Tuning

All in `ui/web/src/lib/simliAvatar.ts`:

| Constant | Default | Effect |
|---|---|---|
`AV_OFFSET_MS` | `0` | Delays local audio to match the face. Raise if lips lead the voice. |
`AUDIO_BUFFER_SIZE` | `1024` | SDK default is 3000. Lower = the mouth starts sooner. |
`CHUNK_BYTES` | `960` | 30 ms of audio per websocket write. |
`CONNECT_TIMEOUT_MS` | `20000` | Boot gives up and falls back to the orb. |

There is **no expression or emotion API** — the SDK exposes only
`sendAudioData`, `ClearBuffer` and `listenTo*`. How expressive the avatar looks
is decided entirely by the chosen **face** and the `SIMLI_MODEL` setting.

---

## 3. Comparison note

### 3.1 Lip-sync quality

| | TalkingHead | Simli |
|---|---|---|
Method | Estimated | Real, audio-driven |
How | `estimateWordTimings()` spreads an utterance's duration across words **by character count** | Trinity model infers mouth shapes from the audio itself |
Failure mode | Drifts on unusual pacing; no alignment | Face can lag the voice by Simli's ~300 ms speech-to-video hop |

Simli's is **better in kind** — actual audio-driven animation versus a
character-count heuristic. But our split-audio design introduces a *systemic*
offset that TalkingHead does not have, because TalkingHead plays the audio
itself and is therefore synchronised by construction. That offset is constant
and correctable via `AV_OFFSET_MS`; TalkingHead's error is variable and is not.

> **Measured drift: _to be filled from the test run_.**

### 3.2 Time-to-first-frame

Logged automatically to the browser console on every boot:

```
[simli] time-to-first-frame ###ms
```

It covers the whole chain: token mint → WebRTC connect → first decoded frame.
TalkingHead's equivalent is a CDN module fetch plus a `.glb` download and WebGL
scene init, which is not instrumented.

> **Measured: _to be filled from the test run_.**

### 3.3 CPU / memory load

Architecturally these load the machine very differently:

| | TalkingHead | Simli |
|---|---|---|
Rendering | **Local** — WebGL/Three.js on the candidate's GPU | **Remote** — Simli's servers |
Client cost | 3D scene render every frame | Video decode + WebRTC |
Expected | Higher CPU/GPU, no network | Lower CPU, sustained bandwidth |

Simli should be **lighter on a weak laptop** but needs steady throughput; a
candidate on poor wifi is better served by TalkingHead, which needs none after
the initial download.

> **Measured: _to be filled from the test run_.**

### 3.4 Licensing

| | License | Notes |
|---|---|---|
TalkingHead | **MIT** | 1,561 stars, actively maintained (last push June 2026). Pinned to v1.7 via jsDelivr. |
`simli-client` | **MIT** | v3.0.2, published June 2026. Only dependency is `livekit-client`. |

Both **client libraries** are MIT and unproblematic.

The difference is not the library, it is the **service**. TalkingHead is a file
we download and run. Simli is a vendor that processes candidate audio on their
infrastructure — which makes it a **data-protection question, not a licensing
one**: a DPA, a data-residency answer and a retention policy would all be needed
before this touches a real candidate. That review has not been done.

### 3.5 Incidental findings

- `simli-client`'s **published README is stale** — it documents a v1 API
  (`Initialize`, `close`, events `connected`/`disconnected`/`failed`) that no
  longer exists. The shipped `.d.ts` is the only accurate reference.
- The **broken entry point** in §1.5 fails only on Linux. Both are small quality
  signals about the vendor's packaging discipline.
- Simli v3 is built on **LiveKit** (`transport: "livekit" | "p2p"`). We already
  depend on `livekit==1.1.8` for echo cancellation, and a LiveKit media server
  is on the roadmap — those may align.

---

## 4. Cost

### 4.1 Pricing model

Billed **per streaming minute**, metered per second of generated video, with a
**hard cap on concurrent sessions per plan**. There is no per-session fee.

Two things follow, and both matter more than the headline rate:

1. **You pay for silence.** Billing is wall-clock session time, not speech time.
   In an interview the candidate talks for most of it while the AI is quiet, so
   the effective cost *per minute of avatar speech* is roughly **3–4× the
   headline rate**. This is the same billing shape that made Azure's avatar
   unaffordable — just two orders of magnitude cheaper.
2. **You are buying concurrency, not minutes.** The rate moves 10% across a 25×
   price increase; the concurrent-session limit moves 25×.

| Plan | Price | Minutes/mo | Rate | **Concurrent** | Faces |
|---|---|---|---|---|---|
Free | $0 | 50 | — | **1** | — |
Hobby | $10 | 1,000 | $0.01 | 2 | 1 |
Pro | $49 | 5,500 | $0.0095 | 10 | 5 |
Scale | $249 | 27,500 | $0.009 | **50** | 30 |

### 4.2 Cost per interview

Our generated cadences run **~25 minutes** (the last generated plan was
`total_duration_s: 1500`); the candidate lobby quotes ~30 minutes when it has no
plan to read. Bracketing both:

| Interview length | Hobby $0.01 | Pro $0.0095 | Scale $0.009 |
|---|---|---|---|
20 min | $0.20 | $0.19 | $0.18 |
**25 min** | **$0.25** | **$0.24** | **$0.23** |
30 min | $0.30 | $0.29 | $0.27 |

### 4.3 Cost per month by volume

At 25 minutes per interview:

| Interviews/mo | Minutes | Cheapest plan that fits | Cost |
|---|---|---|---|
10 | 250 | Hobby | **$10** |
40 | 1,000 | Hobby (at its limit) | **$10** |
200 | 5,000 | Pro | **$49** |
1,000 | 25,000 | Scale | **$249** |
2,000 | 50,000 | **exceeds Scale** | enterprise quote |

> Volume figures are **assumptions** — there is no production volume data to
> read. Confirm real monthly interview counts before treating these as a budget.

### 4.4 At the 400-concurrent target

**This is the finding that matters, and it is not about money.**

The largest self-serve plan allows **50 concurrent sessions**. The benchmark
target is **400**. That is **8× the top published tier**, so at that scale Simli
is not purchasable through the website at all — it requires a negotiated
enterprise contract at an unknown price.

Even setting concurrency aside, the minutes do not stretch:

| | |
|---|---|
400 concurrent × 25 min | **10,000 minutes per wave** |
Scale's entire monthly allowance | 27,500 minutes |
Waves per month on Scale | **2.75** |

Usage cost alone at 400 concurrent, if the rate held, would be **~$90 per wave**
— trivial. The blocker is not price. It is that **we would be inserting a
vendor-imposed 50-concurrent ceiling in front of a system we are benchmarking at
400**, and paying for the privilege.

### 4.5 The baseline

**TalkingHead is a CDN asset with zero marginal cost per interview.** It has no
per-minute charge, no concurrency ceiling, no vendor contract and no data
leaving the candidate's browser. It scales to 400 concurrent interviews by
running in 400 browsers.

Every figure above is therefore **net-new spend** for an improvement that is
cosmetic: a better-looking face and better lip-sync. It does not improve
question quality, scoring accuracy or hiring signal.

### 4.6 Sandbox limits that cap testing

The free plan is **50 minutes/month and 1 concurrent session**.

| Activity | Cost |
|---|---|
One full measured interview run | 20–30 min |
Failure paths (bad key, network drop) | ~0 — they abort before streaming |
TalkingHead side-by-side | free |
**Full runs available per month** | **~2** |

Two consequences for testing:

- **Concurrency cannot be tested at all on Free**, and only to 2 on Hobby / 10
  on Pro. The 400-concurrent projection in §4.4 is therefore **modelled, never
  measured** — but it follows from a published limit, so spending $49 to observe
  it would prove nothing new.
- **Rehearse on TalkingHead.** It is free and exercises the identical cadence,
  so the paid run can be a single careful take.

**Recommendation for the test story:** Hobby at **$10/month**, giving 1,000
minutes and 5× the headroom actually needed, cancelled after the cycle. Pro is
not justified, because the concurrency question is already answered by the
published limits.

---

## 5. Adopt / do-not-adopt

Not yet decided — the end-to-end test story has not run. What the exploration
established:

**For**
- Cost per interview is negligible (~$0.25) and the Azure objection does not apply.
- Lip-sync is genuinely better in kind than our character-count estimate.
- Photorealism is materially more impressive in a demo.
- The integration is clean: no engine changes, and the fallback is the existing orb.

**Against**
- A **50-concurrent vendor ceiling** in front of a 400-concurrent target.
- Candidate audio leaves our infrastructure — unresolved DPA / residency question.
- A live third-party dependency that can fail **mid-interview**, which the
  CDN-loaded TalkingHead structurally cannot.
- Net-new spend for a cosmetic gain, against a free baseline.
- Two packaging defects found in a single afternoon.

**Suggested bar for the decision:** adopt only if the measured A/V drift and the
turn-taking regression checks come back clean *and* the data-protection review
passes. A better-looking avatar that disturbs turn-taking is worse than a
cartoon that does not.
