# Decision: candidate PII in the evaluation export

**Status:** decided · **Scope:** the machine-readable evaluation export
(`features/eval/plugins/export.py` and every plugin section built on it).

The export is the first artefact in this system that is *designed to leave the
portal*. Inside the portal, a scorecard is shown to an authenticated TA next to
the transcript it was derived from. An export file is a copy that can be
downloaded, forwarded, stored in a client's system and kept after the interview
record is gone. So the question "what goes in it" is a privacy decision, not a
formatting one, and it is recorded here rather than being settled implicitly by
whatever each plugin happened to put in its payload.

## The decision

**Pointers ship. Transcript text does not — with two narrow, named exceptions.**

| What | In the export? | Why |
|---|---|---|
| `evidence_refs` (integer event indices) | **Yes** | Bare integers. They carry no personal information on their own and are meaningless without the portal, but they let an auditor inside the portal re-open the exact turns behind a score. Without them a disputed score cannot be traced at all. |
| Scores, states, marks, verdicts, rationales | **Yes** | The point of the export. Rationales are the grader's words about an answer, not the answer. |
| Transcript excerpts (candidate turns, AI questions, follow-up probes) | **No** | This is the bulk of the candidate's personal data and the export does not need it — `evidence_refs` already points at it for anyone entitled to look. |
| **Exception 1** — the graded answer, in `GroundTruthComparison.actual` | **Yes** | For transcription / translation / image-description, the candidate's answer *is the graded artefact*. "6 of 9 words matched" is an unverifiable assertion without the text it was computed from, so exporting the score without it would be exporting a number nobody can check. |
| **Exception 2** — coding per-test rows (`name`, `input`, `expected`, `actual`, `error`) | **Yes** | These are the deterministic facts a coding score is computed from, and the story requires the section to carry per-test results. `actual`/`error` are program output rather than anything the candidate wrote about themselves. |
| Submitted source code | **No** | Not needed to justify the score (the tests and the judge verdict already are), and it is the candidate's own work product. |
| Test `stdout` / `stderr` | **No** | Free-form captured output with no scoring value and no bound on what it might contain. |

## Why not the alternatives

**Excerpts behind an opt-in flag** was considered and rejected for now. It would
help offline review, but it puts a switch in the codebase that widens the
personal data in every future export, and a flag flipped in a config file does
not get the review this decision got. If a real need appears, reopen this
document rather than adding the flag quietly.

**Dropping `evidence_refs` too** was rejected: it is the strictest option and
costs the most. Without any link back to the transcript there is no way to
adjudicate a challenged score, which is a fairness problem for the candidate as
much as an operational one for us.

## How it is enforced

Not by convention — by the contract and a test.

- Section models set `extra="forbid"`, so a plugin cannot quietly add a
  transcript field to its section without changing its declared schema.
- `tests/test_eval_export.py::test_export_carries_pointers_not_transcript_text`
  asserts the emitted sections carry integer pointers, that the coding section
  contains neither the submitted source nor captured console output, and that
  the AI's question text does not appear in any section.

## Revisiting this

Reopen when: a consumer asks for excerpts; the export starts being written to a
location outside the portal's retention policy; or a fifth plugin family joins
the export and its graded artefact does not fit either exception above.
