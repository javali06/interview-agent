# Human review on top of the LLM evaluation — schema design

**Status:** IMPLEMENTED (local stack, not deployed to Azure). Extends the export
contract shipped in AB#34149/34150/34151 (`features/eval/plugins/export.py`,
`features/eval/export.py`). Deferred, deliberately: the sign-off workflow (§3),
the calibration endpoint (§9) and anything adaptive (§10). Everything else in
this document is live — see `tests/test_eval_human_review.py` (26 tests).

The LLM produces a score. A human reviewer must be able to say *"that's wrong,
here's the right mark, and here's why"* — and that correction must be durable,
auditable, and later, learnable from.

---

## 1. The one decision everything else follows from

**The AI's number is never overwritten.**

`marks_earned` on an exported section keeps meaning *what the model said*,
forever. A human adjustment is recorded **beside** it, and a derived
`final_marks_earned` is what counts.

Three reasons this is not negotiable:

1. **Audit.** In a hiring context "the score was 8" is a different claim from
   "the AI said 4 and a recruiter raised it to 8". The second is the truth and
   it must be reconstructible from the file.
2. **Measurement.** Every adjustment is one labelled training example of where
   the model is wrong. Overwriting destroys the label.
3. **Regeneration.** Re-running the evaluation rewrites the AI values. If the
   human value lived in the same field, regenerate would silently erase every
   human correction.

Everything below is a consequence of that.

---

## 2. Two documents, not one

| | `evaluation_export.json` | review ledger (Postgres) |
|---|---|---|
| Written by | the evaluation run | the reviewer |
| Mutability | immutable per run | append-only |
| Contains | what the AI concluded | what a human changed and why |
| Scope | one session | queryable across all sessions |

They are **joined at read time**. The download and the scorecard both serve the
merged document, so there is still exactly one number a customer sees — and
both inputs to it are visible in the same file.

Why the ledger is a **table and not a file in `sessions/<token>/`**:

- The learning loop's core question is cross-session — *"across 200 interviews,
  how far off is `role_fit`?"* A file per session can only answer that by
  scanning every session directory.
- We already lost per-session JSON once this month: `evaluation_plan.json`
  lived in a path that resolved inside the image, so every rebuild deleted it
  (fixed in `b8cb1a3`). Human corrections are more expensive to lose than a plan.

---

## 3. The ledger

```python
# features/eval/review.py

REVIEW_VERSION = "1.0"

ReasonKind = Literal[
    "ai_misread",        # the model misunderstood what was actually said
    "rubric_wrong",      # the model applied the rubric correctly; the rubric is wrong
    "evidence_missing",  # real evidence the model never saw (audio gap, whiteboard, off-transcript)
    "calibration",       # right judgement, wrong severity for this role/seniority
    "other",
]
```

`reason_kind` is the field that makes this more than a comment box. Each value
routes to a different fix, and the four of them answer different questions:

| reason_kind | what it means | what it feeds later |
|---|---|---|
| `ai_misread` | prompt / evidence problem | prompt + retrieval work |
| `rubric_wrong` | the cadence's rubric is wrong | rubric refinement (Layer 2) |
| `evidence_missing` | transcript or capture gap | STT / sectioner work |
| `calibration` | systematic harshness or leniency | per-dimension offset (Layer 1) |

A free-text `reason` with no `reason_kind` is a dead end — you can read it but
you cannot aggregate it.

### The target

```python
class ReviewTarget(BaseModel):
    model_config = ConfigDict(extra="forbid")

    segment_id: str
    section: str                       # the declared section key = the plugin's identity
    item_label: Optional[str] = None   # a breakdown line; None = the section total
```

Two granularities, deliberately:

- **`item_label = None`** — adjust the section's marks directly. Always allowed.
- **`item_label = "role_fit"`** — adjust one line of the breakdown and let the
  marks recompute. This is the one you want reviewers to use, because a
  dimension-level correction is specific enough to learn from; "this phase felt
  low" is not.

### The record

```python
class ReviewRecord(BaseModel):
    model_config = ConfigDict(extra="forbid")

    record_id: str
    token: str
    target: ReviewTarget
    kind: Literal["mark", "state", "note"]

    # kind="mark" — a number changed.
    ai_value: Optional[float] = None       # frozen at review time
    human_value: Optional[float] = None
    # `delta` is DERIVED on read, never stored: one number, one place.

    # kind="state" — "the AI couldn't grade this, but I can" (or the reverse).
    ai_state: Optional[EvalState] = None
    human_state: Optional[EvalState] = None

    # kind="note" — feedback with no mark change.
    body: str = ""

    reason_kind: ReasonKind
    reason: str                            # required and non-empty for mark/state

    reviewer: str
    reviewed_at: str

    # Provenance: WHICH AI output was being corrected.
    evaluation_generated_at: str = ""
    section_schema_version: str = ""
    ai_rationale: str = ""                 # frozen snapshot of what the model said

    status: Literal["active", "superseded", "stale"] = "active"
    supersedes: Optional[str] = None
```

**Append-only.** Changing your mind writes a new record with
`supersedes = <old id>` and flips the old one to `superseded`. There is no
UPDATE. The full history of who thought what, when, is the point.

### Sign-off

```python
class ReviewSignOff(BaseModel):
    model_config = ConfigDict(extra="forbid")

    reviewer: str
    signed_at: str
    decision: Literal["endorsed", "adjusted", "rejected"]
    comment: str = ""
```

`endorsed` with zero adjustments is a real and valuable signal — it says a human
looked and agreed, which is different from nobody having looked.

---

## 4. What is adjustable is declared by the plugin

Same principle the export already uses: *the plugin declares, the consumer
renders*. A reviewer should not be offered a slider for a unit test result.

```python
class AdjustableSpec(BaseModel):
    model_config = ConfigDict(extra="forbid")

    marks: bool = True                  # can the section total be set directly?
    items: bool = False                 # can individual breakdown lines be set?
    item_scale: Optional[tuple[float, float]] = None
    item_label_noun: str = "item"       # what the UI calls one ("dimension", "option", "tag")
    recompute: Literal["none", "mean_scaled", "sum_deltas"] = "none"
```

Added to the existing descriptor, so it lives with the rest of the plugin's
self-description:

```python
@dataclass(frozen=True)
class ExportSection:
    key: str
    title: str
    version: str
    model: type[ExportSectionModel]
    adjustable: AdjustableSpec = AdjustableSpec()   # NEW
```

| plugin | section | items adjustable? | recompute |
|---|---|---|---|
| `conversational_rubric` | `rubric_dimensions` | yes — dimensions, 0–10 | `mean_scaled` |
| `rubric_marks` | `rubric_options` | yes — which options apply | `sum_deltas` |
| `coverage_tags` | `coverage_tags` | yes — per tag | `sum_deltas` |
| `dynamic_difficulty` | `difficulty_breakdown` | yes — per deduction | `sum_deltas` |
| `coding` | `coding_result` | no — total only | `none` |
| `transcription_scoring` | `ground_truth` | no — total only | `none` |
| `translation_scoring` | `ground_truth` | no — total only | `none` |
| `image_description_scoring` | `ground_truth` | no — total only | `none` |

The four `sum_deltas` families unify because a breakdown line already carries a
`delta`. Toggling "option 3 does apply" is the same operation as "set this
line's delta to +2" — one edit shape covers selection *and* magnitude.

The `python`-method plugins deliberately expose total-only. Overriding "3 of 5
tests passed" is not a rubric judgement; if the harness was broken, that's a
total override with `reason_kind="evidence_missing"`, and it reads as exactly
that in the file.

---

## 5. What the merged document looks like

One new optional field on the envelope — so **zero plugin changes**, all eight
inherit it:

```python
class SectionReview(BaseModel):
    model_config = ConfigDict(extra="forbid")

    final_state: EvalState
    final_marks_earned: Optional[float] = None
    final_marks_possible: Optional[float] = None
    items: list[ReviewedItem] = Field(default_factory=list)
    reason_kind: Optional[ReasonKind] = None
    reason: str = ""
    notes: list[str] = Field(default_factory=list)
    reviewer: str = ""
    reviewed_at: str = ""
    stale: bool = False        # the AI's value changed since this was recorded

    @model_validator(mode="after")
    def _marks_only_when_scored(self) -> "SectionReview":
        # The SAME rule as the envelope. A human cannot turn "we couldn't grade
        # this" into a zero any more than the model can.
        ...

class ReviewedItem(BaseModel):
    model_config = ConfigDict(extra="forbid")
    label: str
    ai_value: Optional[float]
    human_value: float
    reason: str = ""


class ExportSectionModel(BaseModel):
    ...
    review: Optional[SectionReview] = None    # absent = no human touched this
```

`review = None` is meaningful and is the common case: the section is pure AI
output. There is no "empty review" state to disambiguate.

Totals get a parallel block rather than extra fields:

```python
class EvaluationReport(BaseModel):
    ...
    totals: ExportedTotals                              # AI only, unchanged forever
    totals_after_review: Optional[ExportedTotals] = None   # null = nothing adjusted
    review_status: Literal["ai_only", "human_reviewed", "human_signed_off"] = "ai_only"
    sign_off: Optional[ReviewSignOff] = None
```

Same model, same `build_totals()` arithmetic with a different value extractor —
so the two totals cannot diverge in how they're computed. A consumer that only
wants the final reads `totals_after_review or totals`.

### Worked example

The model read "ML Intern" on the résumé and scored `role_fit` low. The
recruiter knows the candidate led the modelling work.

```json
{
  "section": "rubric_dimensions",
  "plugin_id": "conversational_rubric",
  "segment_id": "warm_up::generic::0",
  "phase_id": "warm_up",
  "state": "scored",
  "marks_earned": 2.8,
  "marks_possible": 5.0,
  "dimensions": { "communication_clarity": 7.0, "role_fit": 4.0 },
  "review": {
    "final_state": "scored",
    "final_marks_earned": 4.0,
    "final_marks_possible": 5.0,
    "items": [
      { "label": "role_fit", "ai_value": 4.0, "human_value": 9.0,
        "reason": "Title was 'intern' but they led the modelling work end to end." }
    ],
    "reason_kind": "ai_misread",
    "reason": "Scored seniority off the job title rather than the described scope.",
    "reviewer": "sathwik.badda@centific.com",
    "reviewed_at": "2026-09-23T11:04:00+00:00",
    "stale": false
  }
}
```

Read it top to bottom: **the AI said 2.8/5, a named human raised it to 4.0/5 on
2026-09-23 because the model scored seniority off a job title, and the specific
correction was `role_fit` 4 → 9.** `2.8` is still right there. Nothing was lost.

`4.0` is not typed in by hand — `recompute: "mean_scaled"` derives it:
mean(7.0, 9.0) = 8.0 → 8.0/10 × 5.0 = 4.0. The reviewer moves the dimension
they actually have an opinion about; the arithmetic stays the system's job.

---

## 6. Invariants that must survive human editing

1. **Non-scored is still not zero.** `SectionReview` carries the same validator
   as the envelope. A reviewer can change the *state* — "there was enough here
   to judge after all" — and that is a `kind="state"` record with its own
   reason. What they cannot do is attach a mark to a segment that stays
   non-scored. One rule, enforced in two places, for the same reason.
2. **Bounds.** `0 ≤ final_marks_earned ≤ final_marks_possible`, and an item
   value inside `item_scale`. Rejected at write, not clamped silently.
3. **`marks_possible` is never editable.** Changing what a question is worth is
   a cadence edit, not a review — otherwise two candidates get scored out of
   different denominators and the comparison is meaningless.
4. **A reason is mandatory** for `mark` and `state`. A correction with no reason
   is unusable for the learning loop and indefensible in an audit.
5. **`extra="forbid"` still holds.** The review block is a declared shape like
   everything else.

---

## 7. Regeneration — the sharp edge

Regenerate rewrites every AI value. Each active record froze the `ai_value` it
was correcting, so on the next run:

- **AI value unchanged** → the adjustment carries forward. The model said the
  same thing; the correction still applies.
- **AI value changed** → `status = "stale"`, the merged section renders
  `review.stale = true`, and the UI says *"the AI's score moved from 4.0 to 6.0
  since you adjusted this — confirm or redo."*

Never silently dropped (the human's work vanishes), never silently re-applied
(a correction to a judgement the model no longer makes). The reviewer decides.

---

## 8. Storage

```sql
CREATE TABLE evaluation_reviews (
  record_id         TEXT PRIMARY KEY,
  token             TEXT NOT NULL,
  segment_id        TEXT NOT NULL,
  section           TEXT NOT NULL,
  plugin_id         TEXT NOT NULL,
  phase_id          TEXT NOT NULL,
  item_label        TEXT,                    -- NULL = the section total
  kind              TEXT NOT NULL,           -- mark | state | note
  ai_value          DOUBLE PRECISION,
  human_value       DOUBLE PRECISION,
  ai_state          TEXT,
  human_state       TEXT,
  body              TEXT,
  reason_kind       TEXT NOT NULL,
  reason            TEXT NOT NULL,
  reviewer          TEXT NOT NULL,
  created_at        TIMESTAMPTZ NOT NULL,
  eval_generated_at TEXT,
  ai_rationale      TEXT,
  status            TEXT NOT NULL,
  supersedes        TEXT
);

CREATE INDEX ix_reviews_token  ON evaluation_reviews (token, status);
CREATE INDEX ix_reviews_target ON evaluation_reviews (section, item_label, status);
```

`ix_reviews_target` is the one that matters later: it makes
*"mean human−AI delta on `role_fit` across every interview"* a single indexed
query instead of a scan. That query **is** Layer 1 calibration.

---

## 9. API

| route | purpose |
|---|---|
| `POST /api/sessions/{token}/review` | submit one or many records, atomically |
| `POST /api/sessions/{token}/review/sign-off` | endorse / adjust / reject |
| `GET /api/sessions/{token}/evaluation-view` | export **merged with review** + evidence sidecar |
| `GET /admin/sessions/{token}/evaluation-export.json` | the merged document (download) |
| `GET /api/eval/calibration?section=&item=` | read-only aggregate deltas |

`evaluation-view` already returns the export verbatim, and a test pins that the
screen and the download are byte-identical. **That test must keep passing** —
so merging happens in one function used by both routes, not once per route.

---

## 10. Why this shape is also the learning loop

Nothing here mentions machine learning, and that's deliberate — the schema is
worth shipping for audit alone. But it is exactly the dataset the adaptive
layers need:

- **Layer 1 (calibration)** — `AVG(human_value - ai_value) GROUP BY section, item_label`
  over `reason_kind = 'calibration'`. A per-dimension offset shown to the judge
  as a hint. No retraining, no fine-tuning, one query.
- **Layer 2 (rubric refinement)** — cluster `reason_kind = 'rubric_wrong'` by
  phase. A phase with many of them has a bad rubric, and the reasons say how.
- **Layer 3 (guardrail)** — sessions with a sign-off and zero adjustments are a
  golden set. Any prompt or model change is checked against them before it ships.

That ordering matters. Layers 1–3 are queries over this table. Anything that
changes model weights comes after there is enough data here to justify it, and
the honest volume threshold is in the hundreds of adjustments, not dozens.

---

## 11. Suggested first PR

Ship the ledger and the merge, not the learning:

1. `features/eval/review.py` — the models above.
2. The `evaluation_reviews` table + additive migration (`db/engine.py` pattern).
3. `AdjustableSpec` on `ExportSection`; fill it for all 8 plugins (8 one-liners).
4. `review` on `ExportSectionModel` + `totals_after_review` / `review_status`
   on `EvaluationReport`; one shared merge function.
5. `POST /api/sessions/{token}/review` + wire both read routes through the merge.
6. Scorecard UI: per-section edit affordance driven by `adjustable`, showing
   AI-vs-final side by side, reason kind required.

Deferred: sign-off workflow, the calibration endpoint, anything adaptive.

---

## 12. What shipping it surfaced

`EvaluationReport.sections` was declared as `list[ExportSectionModel]` — the
shared envelope. Pydantic serialises a model field using its DECLARED type, so
every plugin-specific key (`dimensions`, `criteria`, `tags`, the per-plugin
`rationale`) was silently dropped on the way out. The stored
`evaluation_export.json` carried the envelope alone: it did not validate against
the `section_schemas` travelling inside it, and the scorecard's `view_id`
templates were rendering empty payloads.

Fixed with `SerializeAsAny` on the way out, and a `mode="before"` validator that
dispatches each section to its own plugin's declared model on the way back in —
so "the document validates itself" is now true in both directions, rather than
only on paper. Pinned by
`test_a_section_exports_its_plugins_own_payload_not_just_the_envelope`, which
asserts every declared property is actually emitted.

**Consequence for existing sessions:** exports written before this fix still
carry only the envelope. Human review works on them (the breakdown lines it
edits are envelope fields), but the per-plugin detail and rationale only appear
after the evaluation is regenerated.
