# 01 — Architecture

How the system is split, what each piece does, where it runs, how they interact,
and how each scales.

## Why it's split at all

The monolith put three very different workloads on one box:

- **Web/API** — bursty, stateless, scales with browsing traffic.
- **Live interviews** — long-lived, stateful, latency-critical (~900 ms turn
  budget), pinned to one process, capped by Speech streams + one CPU core.
- **Slow LLM work** — cadence generation (~10 s), evaluation (~30–60 s),
  resume scoring — bursty, must not block anything interactive.

Bundled together, a browsing spike starves interviews of CPU, bulk work blocks
requests, and you can't scale one without scaling all. The fix: **split by
scaling profile** and let each tier scale on its own trigger. The one rule that
shapes everything: **the real-time loop is never split across the network** — an
interview stays pinned to one replica for its whole life.

## The tiers and services

### Gateway (ACA container app — stateless)
- **Code:** `deploy/gateway_app.py` (entry) + reuses all of `app/main.py`'s
  routes; WS proxy in `app/gateway/ws_proxy.py`.
- **Does:** serves the React SPA (`/app`), every HTTP `/api/*`, admin auth,
  cadence/rubric review + approve, eval-read / results / downloads, and
  **reverse-proxies `/ws/*`** to the session shard that owns the interview.
- **Holds nothing** between requests → any replica serves any request.
- **Scales on:** HTTP concurrency (KEDA), `minReplicas: 1 → maxReplicas: 10`.
- **Image:** `interview-agent-gateway` — slim (no audio/ML deps).

### Session tier (ACA container apps — stateful, **pinned**)
- **Code:** `deploy/azure_app.py` (the live engine) + `app/session_tier/`
  (`identity.py` = shard id/FQDN; `lifecycle.py` = claim/heartbeat/release).
- **Does:** runs one live interview end-to-end — candidate + observer
  WebSockets, the brain/director loop, Stream A **VAD** (Silero/onnx), and STT +
  TTS via **Azure Speech**. Writes `events.jsonl` per turn.
- **Why pinned:** the interview's live state (transcript, phase, FSM, TTS
  buffers) lives in that replica's memory and can't take a network hop mid-turn.
- **Shard-addressed:** ACA's default ingress load-balances and can't target a
  specific replica, so the tier runs as a **pool of single-replica apps**
  (`session-0`, `session-1`, …), each with a stable internal FQDN. A token is
  placed on one shard; every later connection routes back to it.
- **Scales on:** you add **more shard apps** (the `sessionShards` Bicep param) —
  each shard is pinned `minReplicas: 1, maxReplicas: 1`. Capacity per shard ≈
  20–30 concurrent interviews (1 vCPU, CPU-bound) *and* bounded by Speech streams.
- **Image:** `interview-agent-session` — base + Azure Speech SDK + Silero VAD +
  audio libs. **No torch/Kokoro** (STT+TTS are Azure), so ~1.5 GB lighter than
  the old monolith image.

### Worker tier (ACA container app — stateless, scale-to-zero)
- **Code:** `app/jobs/` — `worker.py` (consumer loop), `queue.py` (Azure Storage
  Queue client), `jobs.py` (handlers), `status.py` (job status in Postgres).
- **Does:** runs slow/bursty jobs off the request path. Registered jobs:
  **cadence-gen**, **eval-v2**, **shortlist scoring**. (More seams exist for
  rubric/webhook/bulk/invite when those features are built.)
- **Retry model:** the queue's visibility timeout — a message reappears if not
  deleted; past `JOBS_MAX_ATTEMPTS` it's dead-lettered to a `jobs-poison` queue.
- **Scales on:** queue depth (KEDA `azure-queue` rule), `minReplicas: 0` (down
  to zero when idle) `→ maxReplicas: 10`.
- **Image:** `interview-agent-worker` — slim (base only, no audio).

### Redis — coordination plane (managed: Azure Cache for Redis) ★ the unlock
- **Code:** `app/coordination/` — `registry`, `admission`, `locks`, `pubsub`.
- **Holds (all ephemeral, TTL'd):**
  - **registry** `reg:session:{token}` → `{shard, fqdn}` — replaces the old
    in-process `_token_sessions` dict. This is what lets >1 session replica exist.
  - **admission** counters — `adm:active_sessions`, `adm:speech:{key_id}`,
    `adm:llm_inflight`, `adm:shard:{shard}` — cluster-wide caps so no replica
    overshoots a shared external limit.
  - **locks** `lock:session:{token}` — single-winner token claim (no double-start).
  - **pubsub** `obs:{token}` / `hint:{token}` — observer relay + steer.
- **If it vanished:** only live routing is lost; interviews rebuild from Postgres
  + `events.jsonl`. *Redis points to the truth; Postgres is the truth.*

### Capacity / Speech broker (code + Redis, runs inside the session tier)
- **Code:** `app/broker/` — `speech_pool` (multi-key Azure Speech rotation, N×5
  streams via the Redis counters), `stt_fallback` (Azure ↔ Groq), `llm_guard`
  (LLM timeout + backup model + inflight admission).
- **Does:** hands out scarce voice/LLM capacity cluster-wide. A session starts
  only when a Speech slot **and** LLM headroom actually exist.

### Data plane (managed)
- **Postgres** (reused existing server) — durable system of record: roles,
  candidates, sessions, scores, **jobs**. Set via `DATABASE_URL`. Code:
  `db/engine.py`, `db/models.py`.
- **Azure Files** — a shared filesystem mounted at `SESSIONS_DIR` (`/app/sessions`)
  on **every tier**. Per-session files (resume, `cadence.yaml`, `events.jsonl`,
  `evaluation.json`) are written by one tier and read by another, so they must
  live on one shared filesystem (locally: a docker volume). **This is load-bearing
  — without it the session shard can't find the gateway's files.**
- **Blob** — durable mirror of recordings + results (`app/blob_store.py`), gated
  on `BLOB_ENABLED`.

### Azure Front Door (managed) — entry & router
- One public HTTPS/WSS address + TLS termination. Routes `/*` and `/ws/*` to the
  **gateway** (the gateway then does the registry-aware proxy to the owning
  session shard — the practical ACA equivalent of "Front Door reads the
  registry"; Front Door itself can't read Redis).
- **Provisioned by the Bicep** (`Microsoft.Cdn/profiles` `interview-afd`) →
  **cloud only**. Locally there is no Front Door: the browser hits the gateway
  container directly at `http://localhost:8080`. Nothing functional is lost — the
  gateway is the real router in both environments; Front Door only adds the public
  address + TLS + health-aware failover in cloud.

## The three core flows

### A. Schedule → cadence (slow work goes to the worker)
```
recruiter → POST /api/schedule (gateway)
   ├─ no JD/requirements → default.yaml inline, status="draft"   (instant)
   └─ with input → insert status="generating", ENQUEUE cadence_gen, return now
                         │
                    Storage Queue ──► WORKER: generate YAML, write row, status="draft"
                         ▲
   SPA polls /api/schedule/{token}/cadence every 2s until status flips → shows editor
```

### B. Live interview (pinned to one shard)
```
candidate clicks link → WSS /ws/candidate/{sid}?token=T  → Front Door → GATEWAY
   gateway: registry.get(T)?  no → pick least-loaded shard  → proxy ws:// to shard
   shard: locks.claim(T) → admission.try_acquire → broker.acquire_stt (Azure slot|Groq)
          → registry.claim(T, this-shard) → run interview (brain + Stream A + Azure Speech)
          → heartbeat registry TTL while alive
   reconnect / observer for T → gateway: registry.get(T) → SAME shard (routing pointer)
   end → registry.release + admission.release + upload artifacts to Blob + ENQUEUE eval_v2
```

### C. Post-interview evaluation (worker, off the live tier)
```
session end (shard) → mirror events.jsonl to Blob → ENQUEUE eval_v2
   WORKER: hydrate from Blob/shared FS → run_evaluation → write evaluation.json → Blob
   GATEWAY serves the result (read-through from Blob / shared FS)
```

## Scaling — at a glance

| Tier / service | State | Scales on | Scale unit | First ceiling |
|---|---|---|---|---|
| Gateway | stateless | HTTP concurrency | replicas 1→10 | CPU/mem + DB pool |
| Session | stateful (pinned) | live-session count | **add shard apps** (1 replica each) | 1 vCPU (~20–30) + Speech streams |
| Worker | stateless | queue depth | replicas 0→10 | LLM rate (broker-governed) |
| Redis | ephemeral | — (coordination) | managed instance | memory / ops-sec |
| Broker | ephemeral (in Redis) | — (quota arbiter) | Speech keys (5 streams each) | Σ keys × 5 + LLM headroom |
| Postgres | durable | — | server tier + `DB_POOL_SIZE`/replica | max_connections |

**To take more concurrent interviews:** add session shards **and** Azure Speech
keys together (each key = +5 concurrent streams). One without the other doesn't
help — shards are CPU capacity, keys are the external Speech cap.

## Key environment variables

| Var | Used by | Meaning |
|---|---|---|
| `REDIS_URL` | all | coordination plane (required) |
| `DATABASE_URL` | all | Postgres system of record (required) |
| `AZURE_STORAGE_CONNECTION_STRING` | gateway, session, worker | Blob + Queue |
| `SESSIONS_DIR` | all | shared per-session filesystem (`/app/sessions`) |
| `BLOB_ENABLED` | all | mirror artifacts to Blob (1 cloud / 0 local) |
| `AZURE_SPEECH_KEYS` | session | comma list of Speech keys (`key` or `key:region`) |
| `SPEECH_STREAMS_PER_KEY` | session | per-key concurrency cap (default 5) |
| `SHARD_ID` / `SHARD_FQDN` | session | this replica's shard id + internal address |
| `SESSION_SHARDS` / `SESSION_SHARD_FQDNS` | gateway | the shard pool (for new-token placement) |
| `MAX_ACTIVE_SESSIONS` / `MAX_LLM_INFLIGHT` | all | cluster admission caps (blank = uncapped) |
| `JOBS_QUEUE_NAME` / `JOBS_MAX_ATTEMPTS` | worker | queue name + dead-letter threshold |
| `EVAL_PLUGINS_ENABLED` | worker, gateway | v2 plugin evaluation pipeline |
| `SLOW_*` / `FAST_*` | session, worker | LLM model + provider routing |
| `LANGFUSE_*` | session, gateway | tracing (+ `LANGFUSE_PROJECT_ID` for the UI link) |

See `deploy/local/.env.example` for the full list with the prod-matched values.
