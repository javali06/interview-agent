# 07 — Scaling economics & the ACA-vs-AKS decision

> **What this is.** A decision log written *on top of* [06-session-autoscaling-design.md](06-session-autoscaling-design.md).
> Doc 06 proposes moving the session tier to AKS for elastic autoscaling; this doc
> pressure-tests that: are the concerns real, is AKS worth the cost, what does it
> actually cost at 100–500 interviews/day, where's the break-even, is there a
> cheaper path, and how do we measure the one number the whole thing hinges on
> (**interviews-per-shard, C**). Read after [01-architecture.md](01-architecture.md) (as-built) and 06 (the proposal).
>
> **Status:** analysis + recommendation. Nothing here changes the deployment yet.
> **Date:** 2026-07-08.

---

## 0. How we got here (chronology)

The order this was worked through — each step answered a question the previous one raised:

1. Pulled `interview-scaled-dev`, read 01 (as-built) and 06 (AKS proposal).
2. **Extracted doc 06's concerns** — why the session tier can't just autoscale.
3. Asked **is AKS necessary / cost-effective?** → found a cheaper ACA path.
4. **Settled the vocabulary** (replica vs shard vs interview, FQDN) because the cost math depends on it.
5. Nailed **how ACA autoscaling actually works** (KEDA up *and* down) and why it doesn't fit sessions.
6. Built a **cost model for 100→500/day**, ACA vs AKS.
7. Found the **break-even** — and that it moves with **C** (interviews-per-shard).
8. Designed the **cost-effective ACA path** (schedule-driven / cron scaling).
9. Defined **how to measure C** (the load test + `scripts/loadtest_interviews.py`).
10. Landed a **recommendation**.

---

## 1. The concerns doc 06 raises

All of them descend from one fact: **a live interview is stateful, real-time, and long-lived (20–40 min); its state (brain, director, history, VAD stream, open STT/TTS connections) lives in one process's RAM and can't move mid-call.** Consequences:

1. **Sessions can't use ordinary replica autoscaling.** KEDA scales *anonymous* replicas and *picks which to kill* on scale-in — right for stateless gateway/worker, wrong for a pinned session. Today the tier is faked as **one app per shard, pinned to 1 replica** (static, hand-scaled).
2. **You can't scale in by killing.** A 20–40 min interview outlives any autoscaler's grace; removing a busy box drops the call. Safe scale-down must **drain** (cordon → finish → remove).
3. **Placement must be capacity-aware** (measured room, not least-loaded).
4. **Cold start** — placing on a not-yet-warm shard hurts the first turns.
5. **Failure = interview lost** — no checkpoint/resume yet.
6. **The proposed fix (AKS) is expensive & operationally heavy** — you own a cluster (upgrades, node pools, PDBs, a drain controller, monitoring). This is 06's honest trade-off.
7. **Step zero is unmeasured** — every number depends on *interviews-per-shard at a given vCPU*, and if a shard can't process audio in real-time that number is ~1 (see 04's STT-latency finding). Fix CPU/threads before any scaling math.

---

## 2. Vocabulary (settle it once — the cost math depends on it)

Azure only knows **environment → container app → replicas**. "Shard" is **not** an Azure term — it was introduced by the branch author (Ayush) as an app-level convention.

- **Replica** — an anonymous copy of an app behind one shared address; the ingress picks one, you can't dial a specific one. Used by the **stateless** gateway/worker.
- **Shard** — a *named, addressable* instance. Because ACA can't target a specific replica, each shard is run as its **own app pinned to exactly 1 replica** (`session-0`, `session-1`, …), each with its own **FQDN** (Fully Qualified Domain Name — its complete DNS address, e.g. `session-0.internal.<env>.<region>.azurecontainerapps.io`). The gateway proxies a WebSocket to that exact address.
- **So `shard = app = 1 replica`** — they're the same unit, not parent/child. What lives *inside* a replica is **many interviews** (~C async tasks).
- **"Pinned"** = a given interview stays on its shard for its whole life — **not** one interview per shard.

```
session tier
  └── shard (= 1 app = 1 replica, own FQDN)   ← add MORE of these to scale
        ├── interview 1
        ├── interview 2
        └── … ~C interviews (one process)
```

You scale by **adding shard-apps**, never by adding replicas to a shard. "Multiple shards in one replica" isn't a thing — a shard *is* a replica.

---

## 3. How ACA autoscaling works (and why not for sessions)

ACA autoscaling = **KEDA**. It changes an app's **replica count** on a **trigger**:

- **gateway** → HTTP concurrency (this branch: `concurrentRequests: 50`), `min 1 → max 10`.
- **worker** → Azure Storage Queue depth, `min 0 → max 10` (scale-to-zero when idle).
- (CPU/memory/custom triggers exist but aren't used here — so ACA scaling is **not** "CPU-bound"; "CPU-bound" in the docs refers to a *shard's capacity ceiling*, 1 vCPU → ~20–30 interviews.)

**Scale-down:** when the metric falls below target, KEDA computes a lower desired count, waits a **cooldown (~5 min default, configurable)** to avoid flapping, then terminates chosen replicas (**SIGTERM → ~30 s grace → SIGKILL**) down to `min`. The platform picks *which* replica.

**Why it's wrong for sessions:** replicas are anonymous + platform-killed + get only ~30 s grace. You can't route a reconnect to the exact replica holding an interview, and scale-in would kill a live call. That's why the **session tier is pinned `min=max=1` and never scales in** — scaling it = adding shard apps by hand.

---

## 4. AKS vs ACA — what each gives

| | **ACA (managed)** | **AKS (you run a cluster)** |
|---|---|---|
| unit | replicas (KEDA) | pods (StatefulSet) |
| addressable? | no (anonymous, LB picks) | yes (stable pod DNS) |
| scale-in | platform kills | cordon + **drain** (PDB + hooks) |
| stateful sessions | no safe elastic scale-in | safe (drain, never kill busy) |
| node elasticity | managed/serverless | Cluster Autoscaler |
| ops | minimal | you own upgrades, nodes, YAML, monitoring |

AKS gives the primitives that solve §1 (addressable shards + drain-safe scale-in + a custom allocator) — at the price of owning a cluster.

---

## 5. Cost model, 100 → 500 interviews/day

**Method.** Split **usage** (Speech STT+TTS + LLM ≈ **$0.55/interview** — STT $0.25, TTS $0.10, LLM/brain+cadence+eval ~$0.15, misc ~$0.05) from **fixed infra**. *Usage is identical on ACA and AKS and scales with volume; the platform choice only moves infra.* Assume ~22 business days/mo and that **one shard ≈ 25 concurrent**. 100/day = 25 interview-hours/day spread over business hours ≈ 3–4 concurrent, so even 500/day peaks ~28 concurrent → **1–2 shards throughout**.

| Interviews/day | Usage/mo (both) | ACA infra | AKS infra | **ACA total** | **AKS total** |
|---|---|---|---|---|---|
| 100 | ~$1,210 | ~$145 (1 shard) | ~$310 | **~$1,355** | ~$1,520 |
| 200 | ~$2,420 | ~$145 (1) | ~$310 | **~$2,565** | ~$2,730 |
| 300 | ~$3,630 | ~$145 (1) | ~$310 | **~$3,775** | ~$3,940 |
| 400 | ~$4,840 | ~$180 (2) | ~$310 | **~$5,020** | ~$5,150 |
| 500 | ~$6,050 | ~$180 (2) | ~$380 | **~$6,230** | ~$6,430 |

ACA fixed infra ≈ base ~$110 (gateway ~$25 + worker ~$10 + Redis ~$30 + Front Door ~$35 + storage ~$10; Postgres reused) + **$35 per always-on shard** (matches 06's ~$130–220 baseline). AKS ≈ control plane ~$73 (Standard SLA; $0 on Free) + nodes ~$140–210 + LB ~$20 + same managed stores ~$75.

**Two findings:**
- **Usage is ~85–95 % of the bill** and identical on both platforms → the ACA-vs-AKS question moves the *total* by ~1 %. The real cost levers are **LLM model choice** and **Speech mode** (batch STT ≈ $0.60/hr vs $1.00 real-time), not the platform.
- **ACA is cheaper at every volume 100–500/day** (~$130–200/mo less) *and* simpler, because 1–2 shards already cover the load.

*(Infra figures are ballpark — node SKU/region/tier dependent.)*

---

## 6. The break-even (the crux — it moves with C)

The infra crossover happens **when you need ≈ 5 shards** — because ACA bills each shard as a full container (~$35) while AKS bin-packs ~3 shards/node (~$23/shard) on a higher fixed base (~$170). The *volume* that reaches 5 shards depends on capacity-per-shard **C**:

> **break-even ≈ 90 × C  interviews/day**

| C (interviews/shard) | AKS starts winning around | At 500/day |
|---|---|---|
| 25 | ~2,200/day | ACA clearly cheaper |
| 10 | ~900/day | ACA cheaper |
| **5** | **~450/day** | **AKS ≈ ACA / edges ahead** |

So **if C is low (a CPU/STT-bound shard), AKS wins much sooner.** But the right response to low C isn't "switch to AKS" — it's **fix C**: raising 5 → 25 (more vCPU, onnxruntime threads, STT/TTS kept on Azure) cuts shard count 5× and pushes the break-even from ~450 back to ~2,200/day. **Fixing C is higher leverage than any platform migration.**

---

## 7. The cost-effective path on ACA (no AKS)

The lever doc 06 under-uses: **interviews are pre-scheduled.** You don't need reactive elastic autoscaling — drive the shards from the **booking calendar**.

**Level 1 — static cron (zero code).** ACA supports KEDA's `cron` scale rule. Set the shard to `minReplicas: 0` and hold it at 1 during interview hours:
```bicep
scale: {
  minReplicas: 0
  maxReplicas: 1
  rules: [ {
    name: 'business-hours'
    custom: { type: 'cron', metadata: {
      timezone: 'Asia/Kolkata'
      start: '0 9 * * 1-5'      // up 09:00 Mon–Fri
      end:   '0 19 * * 1-5'     // down 19:00  (pad past the last slot)
      desiredReplicas: '1'
    } }
  } ]
}
```
Outside the window it costs $0; inside it's warm. Pad `end` past the last slot **and** pair it with app-level drain (refuse-new-at-close, finish-current) so an overrun isn't cut.

**Level 2 — dynamic, driven by the bulk-schedule phase.** When slots are irregular, the scheduler *emits demand* and a small controller *enacts* it (don't call Azure from the request path):
```
bulk schedule ──writes──▶ capacity plan (slot→shards, in Redis/Postgres)
                              │ reads upcoming
                              ▼
                    scaling controller (timer / Function) ──set replicas (ARM)──▶ ACA shards
                                                                                  (pre-warm before, 0 after)
```
- **Gate bookings per slot ≤ shards × C** → free admission control at booking time.
- Controller needs an identity with rights to update the Container Apps (RBAC) — note the current deploy uses ACR admin creds precisely because the deployer is a Contributor (see [TODO.md](TODO.md) / [05-cloud-deploy-runbook.md](05-cloud-deploy-runbook.md)).

Start with Level 1; add Level 2 only if slots are irregular.

---

## 8. Step zero — measure interviews-per-shard (C)

Everything above keys off **C**, and it's currently unmeasured. Measure it before committing to any platform or scaling number.

**Method.** Ramp N concurrent synthetic interviews against **one** shard; **C = the largest N before p95 turn-latency knees upward** (or errors appear).

- **One measured turn:** the driver streams ~4 s of candidate speech, then silence (`t0`); the server runs VAD-endpoint → STT → LLM → TTS; the first AI-audio frame arrives (`t1`). **latency = t1 − t0** (includes the ~1 s VAD window; the processing budget itself is ~900 ms — watch for the *knee*, not just an absolute).
- **Driver:** `scripts/loadtest_interviews.py` (added on this branch). Uses the **no-token** candidate path (independent throwaway interviews), streams 16 kHz mono PCM as real-time binary frames, ramps N, prints p50/p95/p99.
  ```bash
  pip install websockets
  python scripts/loadtest_interviews.py --url ws://localhost:8080 \
      --wav answer_16k.wav --ramp 1,5,10,20,25,30 --turns 6
  ```

**Make it a valid measurement:**
- **Prod vCPU parity** — pin the shard to 1 vCPU (`docker run --cpus=1 --memory=2g …`) or test a real ACA shard. A laptop core over-reports C ~4×.
- **Speech un-bottlenecked** — give the shard `ceil(maxN/5)` Speech keys (or Groq fallback) so you measure CPU, not the 5-stream cap.
- **One shard** — locally that's the single session container; in cloud target one container / temporarily run one shard.
- **Discard the warm-up turn** (model load + TTS cold-start); the driver already skips turn 0.

**Optional instrumentation — to see *why* it knees** (CPU vs Speech vs LLM):
```python
# deploy/azure_app.py
@app.get("/debug/stats")
async def debug_stats():
    import os
    return {"shard": shard_identity.shard_id(),
            "active_sessions": len(_token_sessions),
            "load1": round(os.getloadavg()[0], 2)}
```
Poll it during the ramp alongside `docker stats` / `az containerapp` CPU. p95 knees **and** CPU pegs → CPU-bound (add vCPU/shards). p95 knees but CPU low → Speech/LLM (429s / model latency). A per-turn **STT real-time-factor** log (audio-sec ÷ processing-sec) confirms the 04 "capacity ≈ 1" bug if RTF > 1.

---

## 9. Decision & recommendation

1. **Measure C first** (§8). Target ~20–25/shard. If it's ~5, treat it as the CPU/STT bug to fix, not a platform to buy around.
2. **Stay on ACA** while you need ≤ ~4–5 shards (≈ 90 × C interviews/day) — cheaper and simpler there across 100–500/day.
3. **Add cron scale-to-zero** (§7 Level 1) now for the always-on shard cost; add the schedule-driven controller (Level 2) only if slots go irregular.
4. **Scale shards + Speech keys in lockstep** as volume climbs (each key = +5 concurrent; each shard ≈ C).
5. **Switch to AKS only** when you're steadily past ~5–6 shards (≈ 90 × C/day) *or* demand turns spiky/unpredictable — then bin-packing + drain-safe elastic scale-in pay for the cluster.
6. **Remember the real levers:** usage dominates the bill, so optimize **LLM model** and **Speech mode** before agonizing over the platform.

---

## 10. Open items

- [ ] Run `scripts/loadtest_interviews.py` and record the real **C** (and whether the shard is CPU- or Speech-bound).
- [ ] If C < ~15, fix the shard CPU/thread issue (04) before scaling.
- [ ] Land the cron scale rule (§7 Level 1) in `deploy/aca/main.bicep` + app-level drain on SIGTERM.
- [ ] Decide static vs dynamic scaling based on how regular the booking slots are.
- [ ] Carry the P1/P2 hardening items from [TODO.md](TODO.md) before external use.
