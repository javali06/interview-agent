# 08 — Observability & stress-testing a shard

How to find **interviews-per-shard (C)** — the number of concurrent interviews one
session replica handles before quality degrades — and *which resource* is the
bottleneck. Read [07-scaling-cost-and-decisions.md](07-scaling-cost-and-decisions.md)
first for why C matters; this doc is the hands-on measurement.

## The three signals that knee together at C

As you ramp concurrency, watch these — they should bend upward at the same N,
and that N is your C:

1. **CPU %** — from cAdvisor (local) or Azure Monitor (cloud). ~100% of one vCPU = saturated.
2. **Event-loop lag** — the session's own gauge/log. All interviews on a replica share
   one event loop; when lag crosses **~50–100 ms** the loop is starved.
3. **Turn latency p95/p99** — from the load-test harness (stop-speaking → first AI audio).

If CPU is still low but loop-lag spikes, the bottleneck is a blocking call on the
loop, not raw CPU. If CPU pins at 100% first, it's genuinely CPU-bound → smaller C,
add shards. Speech (5/key) or LLM rate limits can knee *before* CPU — the Grafana
panels for `speech_inflight` / `llm_inflight` show that.

## Local: the Grafana stack (rich breakdown — recommended)

A `--profile obs` add-on to the local stack: **Prometheus + Grafana**, scraping the
session `/metrics` — which exports *everything*: loop-lag, live Redis concurrency,
**and container CPU/mem read straight from the cgroup** (so it works on Docker
Desktop for macOS, where cAdvisor does not) — plus the VAD `/metrics` (`:8011`).

```bash
# 1. build the local images (includes the /metrics endpoint)
deploy/build_tiers.sh local
# 2. bring up the stack WITH observability
docker compose -f deploy/local/docker-compose.yml --profile obs up
# 3. open Grafana → dashboard "Interview shard capacity"
open http://localhost:3000          # anonymous admin, no login
```

**Isolate ONE shard for a clean C** (a laptop core is faster than an ACA vCPU, so
pin it): run a single session container limited to 1 CPU and point the harness at
it. Either add `deploy: { resources: { limits: { cpus: '1' } } }` to `session-0` in
the compose file, or run it standalone:
```bash
docker run --rm --cpus=1 --network interview-scaled_default \
  -e REDIS_URL=redis://redis:6379/0 -e SHARD_ID=session-0 ... \
  interview-agent-session:local
```

**Drive load** with the harness (needs a 16 kHz mono PCM WAV + `pip install websockets`):
```bash
python scripts/loadtest_interviews.py \
  --url ws://localhost:8080 --wav answer_16k.wav --ramp 1,5,10,15,20,25 --turns 6
```
Watch the Grafana panels climb as N ramps; the N where CPU%/loop-lag/p95 all knee is C.

### The dashboard — "Interview scaling & bottlenecks"

Read it top-to-bottom; each row is a layer of the funnel. Everything comes from
the session `/metrics` on `:8080` (the VAD histograms are **federated** onto it —
one scrape target, no separate `:8011` job). Prometheus's `instance` label
separates shards.

| Row → panel | Read it as |
|---|---|
| **Load** — Scheduled vs running (per shard) | running = live now; a growing *scheduled (waiting)* line = demand outrunning capacity |
| **Load** — Azure Speech streams per key (cap 5) | a key pinned at 5 = add a Speech key or new interviews queue |
| **Load** — LLM peak concurrency per key·model | max simultaneous LLM calls a key sees, summed across shards (peak-since-scrape → short calls not missed) |
| **Service latency** — LLM first-token delay p95 (TTFT, per model) | request→first-token per model tier (solid); total gen dashed. Timed at the client chokepoint so EVERY call counts |
| **Service latency** — Speech latency p95 (STT / TTS / VAD) | STT endpoint→final, TTS first-byte + synth, VAD endpoint |
| **Audio backpressure** — Mic queue depth / drops /s / STT-vs-concurrency | queue depth = leading saturation signal; ANY sustained drop = audio can't keep up |
| **Event loop** — Event-loop lag (ms) | >100 ms = the shared loop is starved (every latency knees together) |
| **Resources** — CPU % / memory (working set vs total) per shard | 100% = one vCPU maxed; watch working set for real memory pressure |
| **Startup & detail** — Startup → first AI audio p95 | whole start-click→first-audio window (the number a candidate waits) |
| **Startup breakdown** — per bring-up step p95 (NEW) | **the slow-start diagnostic** — the stalled step (e.g. `vad_connect`, `resume_summarize`, `claim`) spikes |
| **Startup & detail** — Per-stage latency p95 (drill-down, non-LLM) | every other `log_timing` (service, action) pair |
| **LLM call rate** — calls/sec per key·model (NEW) | throughput per key (Little's-law companion to peak concurrency); what a provider's req/min limit sees |

**The 3 knee signals** still hold: **CPU %**, **event-loop lag**, **turn/STT
latency p95** should bend upward at the same N — that N is C. New at scale:
**mic queue depth + drop rate** tell you specifically whether the *audio pipeline*
(not LLM/CPU) is what gives out first. **Attributing a lag to a stage:** the
per-stage drill-down carries every timed boundary (`interview_stage_latency_ms`,
labeled `service`/`action`), so a slow turn/startup shows *exactly which stage*
spiked (`LLM-slow/first_token`, `STT/final`, `TTS/audio_start`,
`session/startup_to_first_audio`) instead of guessing.

**LLM latency is timed at the client chokepoint** (`LLMClient._observe_call`), so
EVERY LLM call is measured regardless of which agent made it — labeled only by
model tier (`fast` / `slow`), request→TTFT and request→completion. This also
closes the old gap where the `verifier` + `phase_override` calls (which gate every
turn) were never timed; they're now counted like any other fast-model call.

**Diagnosing a slow interview START:** the **Startup breakdown** panel breaks the
whole bring-up (start-click → first AI audio) into per-step p95s
(`interview_stage_latency_ms{service="startup"}`). When a start is slow with LOW
CPU + LOW loop-lag, the culprit is a network-wait — the spiking step names it
(`vad_connect` = wedged/slow VAD, `resume_summarize` = slow LLM, `claim` /
`session_lock_wait` = coordination, `stt_connect`/`tts_connect` = Azure). A wedged
VAD now fails fast (`VAD_CONNECT_TIMEOUT_S`, `interview_vad_connect_failures_total`)
instead of hanging, and VAD inference runs off its event loop so one busy interview
can't head-of-line-block a second one's connect.

**LLM in-flight, done right:** the raw live gauge (`interview_llm_active`) reads ~0
at a 5s scrape because LLM calls are sub-second — so the dashboard uses
**`interview_llm_active_peak`** (max concurrent per key·model since last scrape,
published by `snapshot_llm_peaks()` on each scrape) for true concurrency, and
**`rate(interview_llm_calls_total)`** for calls/sec. Both merge across shards with
`sum by (key_id, …)` — the per-key load a shared provider key actually sees.

> **macOS note:** CPU/mem come from the container's own cgroup (via session
> `/metrics`), not cAdvisor — so the CPU panel works on Docker Desktop for Mac,
> where cAdvisor's container metrics are unreliable. `docker stats` is still a
> handy cross-check.

## Cloud: the SAME dashboard, on the real shards

The deployed shards are internal-only, so a *local* Prometheus can't reach them —
the fix is **one ACA app running Prometheus + Grafana as sidecar containers**
(`deploy/aca/observability/`, defined in the Bicep as the `grafana` app). The two
containers share `localhost`, so Grafana queries Prometheus at
`http://localhost:9090` — Prometheus is never exposed, only Grafana's `:3000` is
external. Prometheus scrapes the shards' internal FQDNs
(`session-N.internal.<envDomain>/metrics`, rendered at boot from the env domain);
Grafana bakes in the **same dashboard file** as local, so what you tuned locally
is exactly what you watch in production.

```bash
# 1. build ALL images incl. the two obs images, at a new tag
TAG=v13 deploy/build_tiers.sh acr
# 2a. FIRST rollout of the obs app → re-run provision (adds the `grafana` app;
#     GRAFANA_ADMIN_PASSWORD is required — external FQDN):
GRAFANA_ADMIN_PASSWORD='<strong-pw>' IMAGE_TAG=v13 ... deploy/aca/provision.sh
# 2b. AFTER it exists, a normal redeploy just repoints BOTH sidecar containers:
az containerapp update -g AI-COE -n grafana \
  --container-name prometheus --image interviewagentacr.azurecr.io/interview-agent-prometheus:v13
az containerapp update -g AI-COE -n grafana \
  --container-name grafana    --image interviewagentacr.azurecr.io/interview-agent-grafana:v13
# 3. open the dashboard (URL is a Bicep output `grafanaUrl`); log in admin / <pw>
```

The `grafana` app has an **external** FQDN (its own, not behind Front Door) so you
can open it in a browser — it's password-gated (anonymous access off). Prometheus
is a localhost-only sidecar. Its TSDB is ephemeral (a live at-scale view, not
archival), so history resets if the app restarts — that's intentional (Azure Files
is unsafe for a TSDB). Run a ramp through Front Door and read the knee off the
dashboard; set `MAX_ACTIVE_SESSIONS = C`, Speech keys = `ceil(target / 5)`, and
`MAX_LLM_INFLIGHT` (see [07](07-scaling-cost-and-decisions.md)).

**Lightweight cloud checks** (no dashboard needed) still work:
```bash
python3 scripts/dump_shard_metrics.py --app session-0 --minutes 30   # Azure Monitor CPU/mem
az containerapp logs show -g AI-COE -n session-0 --follow | grep loop-lag
```

## Optional: py-spy flamegraph (find the *code* hotspot)

Metrics say *which resource* saturates; py-spy says *which function* burns the CPU.
On-demand, against a running session process:
```bash
# local (session container)
docker exec -it <session-container> pip install py-spy && \
docker exec -it <session-container> py-spy dump --pid 1
# cloud
az containerapp exec -g AI-COE -n session-0 --command "sh -c 'pip install py-spy && py-spy dump --pid 1'"
```
(Needs `SYS_PTRACE`; on ACA the exec runs in the container's namespace.)
