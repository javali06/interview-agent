# 03 — Deploy to Azure (from scratch)

End-to-end: build + push the images, run the Bicep, verify, update, roll back.
The target is **Azure Container Apps** behind **Front Door**, coordinated by
**Redis**, reusing your existing **ACR**, **Storage account**, and **Postgres**.

- Subscription: **AzureSimple Pactera** (`da74e3ed-9c9a-4605-8fae-10f3492c0f5c`)
- Resource group: **AI-COE** · ACR: **interviewagentacr**
- IaC: `deploy/aca/main.bicep` · wrapper: `deploy/aca/provision.sh` ·
  cost/resource list: `deploy/aca/RESOURCES.md`

## What gets created vs reused

**Created by the Bicep** (new):
- **Azure Cache for Redis** `interview-redis` (Standard C1) — coordination plane.
- **ACA managed environment** `interview-aca-env` + a **managed-env storage** for
  the Azure Files share.
- **Container apps**: `gateway` (external, HTTP-scaled 1→10), `worker` (no
  ingress, queue-scaled 0→10), `session-0…N` (internal, pinned 1 replica each).
- **AcrPull** role assignments (each app's managed identity → pull from ACR).
- **Azure Front Door** `interview-afd` (Standard) → routes to the gateway.
- **Azure Files share** `sessions` on the existing storage account (mounted at
  `SESSIONS_DIR` on every tier).

**Reused (no new spend):**
- **ACR** `interviewagentacr` (images), **Storage account** (Blob + Queue +
  the new Files share), **Postgres** (your existing server — passed as
  `DATABASE_URL`; not provisioned), **Azure Speech** (add more keys for more
  concurrency: 1 key = 5 streams).

Rough baseline (2 shards, low traffic): **~$130–220/mo** (Redis + always-on
session shards + Front Door dominate). Full table in `deploy/aca/RESOURCES.md`.

## Prerequisites

1. **Azure CLI** logged in to the right subscription:
   ```bash
   az login
   az account set --subscription "da74e3ed-9c9a-4605-8fae-10f3492c0f5c"
   ```
2. **Bicep** (bundled with recent `az`; `az bicep version` to confirm).
3. Your existing **Postgres URL** and **Storage account name**.
4. **Postgres reachability:** make sure the existing Postgres server allows the
   ACA environment to connect — enable *"Allow public access from Azure services"*
   on the Flexible Server, or put it on the ACA VNet via a private endpoint. The
   Bicep can't do this for you since the server isn't in the template.
5. Secrets ready: `PG`/DB URL, `ADMIN_PASSWORD_HASH` (`python scripts/admin_password.py`),
   `ADMIN_SECRET_KEY`, `AZURE_SPEECH_KEYS`, `OPENROUTER_API_KEY`, `GROQ_API_KEY`.

## Step 1 — Validate the Bicep

```bash
az bicep build -f deploy/aca/main.bicep
```
Compiles to `main.json` (gitignored) and surfaces any template errors before you
deploy.

## Step 2 — Build + push the images to ACR

```bash
TAG=v1 deploy/build_tiers.sh acr
```
This uses **`az acr build`** — the images build *in the cloud*, so you need no
local Docker. It builds `interview-agent-base:v1` first, then the three tier
images on top (each `--build-arg BASE_IMAGE=…base:v1`), and pushes all to ACR.
The gateway build compiles the SPA (a TS error fails the build).

## Step 3 — Provision

```bash
RESOURCE_GROUP=AI-COE STORAGE_ACCOUNT=<your-storage-acct> IMAGE_TAG=v1 \
  DATABASE_URL='postgresql+psycopg://user:pw@<host>.postgres.database.azure.com:5432/interview?sslmode=require' \
  ADMIN_PASSWORD_HASH='...' ADMIN_SECRET_KEY='...' \
  AZURE_SPEECH_KEYS='key1:eastus,key2:eastus' OPENROUTER_API_KEY='...' GROQ_API_KEY='...' \
  deploy/aca/provision.sh
```
`provision.sh`:
1. Pre-creates the `jobs` + `jobs-poison` Storage Queues (so the worker can scale
   from zero — KEDA needs the queue to exist).
2. Runs `az deployment group what-if` and asks you to confirm.
3. Runs `az deployment group create` and prints the outputs (Front Door hostname,
   gateway FQDN, Redis host, shard FQDNs).

**Session shard count** is the `sessionShards` Bicep param (default
`['session-0','session-1']`). To run more shards, pass e.g.
`sessionShards='["session-0","session-1","session-2"]'` to the deployment (edit
`provision.sh` or add `-p sessionShards=…`), and add matching Speech keys.

## Step 4 — Verify

```bash
FD=<frontDoorHostname-from-outputs>
curl https://$FD/healthz/live          # {"status":"live"}
curl https://$FD/ready                 # {"status":"ready","redis":true}
```
Then open `https://$FD/admin/login`, schedule an interview with a JD (watch the
worker wake up), approve, run candidate + observer, confirm the evaluation is
produced.

Watch tier logs:
```bash
az containerapp logs show -g AI-COE -n gateway   --follow
az containerapp logs show -g AI-COE -n worker    --follow
az containerapp logs show -g AI-COE -n session-0 --follow
```

## Step 5 — (Optional) migrate existing SQLite data

Only if lifting old monolith data into Postgres (usually not needed — the schema
self-creates on first boot):
```bash
DATABASE_URL='postgresql+psycopg://…' \
  python scripts/migrate_sqlite_to_postgres.py --sqlite /path/to/sessions.db
```

## Updating (new code)

```bash
TAG=v2 deploy/build_tiers.sh acr           # build + push new images
az containerapp update -g AI-COE -n gateway   --image interviewagentacr.azurecr.io/interview-agent-gateway:v2
az containerapp update -g AI-COE -n worker    --image interviewagentacr.azurecr.io/interview-agent-worker:v2
az containerapp update -g AI-COE -n session-0 --image interviewagentacr.azurecr.io/interview-agent-session:v2
# …repeat for each session shard
```
Or re-run `provision.sh` with `IMAGE_TAG=v2` to update everything via the Bicep.

**Roll back:** `az containerapp update … --image …:<previous-tag>`, or fail over
to the `demo-prod` App Service monolith (untouched).

## Deployment topology (what talks to what)

```
Internet ─HTTPS/WSS─► Front Door (interview-afd)
                          │ /*  /ws/*
                          ▼
                    gateway  (external ingress, public)
                    ├─ /api, SPA, auth      → Postgres, Blob, shared Files
                    └─ /ws/* proxy ─internal ACA network─► session-N (internal ingress)
                                                              ├─ Redis (claim/registry/admission)
                                                              ├─ Azure Speech (STT/TTS)
                                                              └─ shared Files (cadence, events.jsonl)
                    worker (no ingress) ◄── Storage Queue (KEDA scale 0→N)
                          └─ Postgres, Blob, shared Files
   All tiers ─► Redis · Postgres · Storage (Queue+Blob+Files) · managed identity → ACR pull
```

## Networking notes / production hardening

- Session apps use **internal ingress** with `allowInsecure: true` so the
  gateway's `ws://` upgrade to a shard isn't 301'd to HTTPS (traffic never leaves
  the ACA environment).
- The Bicep currently reaches Redis/Postgres over their public endpoints (with
  the "allow Azure services" rule). For production, move Redis + Postgres to
  **private endpoints** on the ACA VNet, and prefer **managed identity** over
  connection-string secrets for Storage/Speech where the SDK supports it.
- Do the auth-hardening items in `deploy/README.md` before an external pilot.

## Teardown (to stop the bill)

```bash
# delete just the tiered resources (keep ACR/Storage/Postgres):
az containerapp delete -g AI-COE -n gateway --yes
az containerapp delete -g AI-COE -n worker --yes
az containerapp delete -g AI-COE -n session-0 --yes   # + each shard
az containerapp env delete -g AI-COE -n interview-aca-env --yes
az redis delete -g AI-COE -n interview-redis --yes
az afd profile delete -g AI-COE --profile-name interview-afd --yes
# (leave the existing ACR, Storage account, and Postgres alone)
```
