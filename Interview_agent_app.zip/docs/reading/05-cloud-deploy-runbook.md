# 05 — Cloud deploy runbook (as-built)

A concrete, follow-along walkthrough of deploying the tiered system to Azure —
the exact steps, real resource names, where every secret/env comes from, and the
gotchas we hit (so you don't). This is the "do it like it was done" guide;
[03-deploy-azure.md](03-deploy-azure.md) is the conceptual reference.

## The environment (real values)

| Thing | Value |
|---|---|
| Subscription | AzureSimple Pactera (`da74e3ed-9c9a-4605-8fae-10f3492c0f5c`) |
| Resource group | `AI-COE` (region `eastus`) |
| Container registry (existing) | `interviewagentacr` |
| Storage account (existing) | `interviewagentdata` — blob container `sessions`, queues `jobs`/`jobs-poison`, Azure Files share `sessions` |
| Postgres (existing, reused) | `interviewagent-sql`, user `admin_aicoe`, db `postgres` |
| Deployed monolith (secret source + rollback) | App Service `interview-ai-backend` |

Provisioned by the Bicep: `interview-redis` (Redis), `interview-aca-env` (ACA
env) + Azure Files storage, container apps `gateway` / `worker` / `session-0` /
`session-1`, and `interview-afd` (Front Door).

## Where env & secrets live (important — there is NO cloud `.env`)

- **Local** uses a file: `deploy/local/.env` (docker-compose reads it).
- **Cloud does NOT.** Secrets are passed as **secure parameters** to the Bicep at
  deploy time (`provision.sh` reads them from your shell env), and the Bicep
  stores them as **Container App secrets** (encrypted), injected into each tier
  via `secretRef`. Non-secret config (models, provider order, shard names, blob
  flags) is set as plain env in the Bicep's `commonEnv` / `llmEnv`.

So "adding/modifying a cloud env var" means one of:
- **Non-secret** (e.g. `SLOW_MODEL`, `SPEECH_STREAMS_PER_KEY`, `MAX_ACTIVE_SESSIONS`):
  edit the `commonEnv`/`llmEnv` arrays in `deploy/aca/main.bicep`, redeploy.
- **Secret** (e.g. `AZURE_SPEECH_KEYS`, `OPENROUTER_API_KEY`): change the value
  you pass to `provision.sh` (we source these from `deploy/local/.env` + the
  deployed app), redeploy. The Bicep re-writes the corresponding secret.
- **Quick one-off** (no redeploy): `az containerapp secret set …` +
  `az containerapp update` to roll a revision — but this drifts from the Bicep,
  so prefer the redeploy path.

Where each secret comes from for this deploy:

| Secret param | Source |
|---|---|
| `DATABASE_URL` | the deployed app's setting (`az webapp config appsettings list … DATABASE_URL`) — reuses `interviewagent-sql` |
| `AZURE_SPEECH_KEYS`, `OPENROUTER_API_KEY`, `GROQ_API_KEY`, `ADMIN_PASSWORD_HASH`, `ADMIN_SECRET_KEY` | `deploy/local/.env` (the same ones you tested locally) |
| `STORAGE_ACCOUNT` (param, not secret) | `interviewagentdata` |
| ACR pull password | fetched **inside** the Bicep via `acr.listCredentials()` — never on the command line |

## Prerequisites

1. `az login` and select the subscription:
   ```bash
   az account set --subscription da74e3ed-9c9a-4605-8fae-10f3492c0f5c
   ```
2. **`az` on PATH for scripts.** On this machine `az` is a shell *alias*
   (`/Users/ayush.kothiyal/azure-cli-env/bin/az`) — aliases don't exist in
   scripts/background shells, so prefix commands that call scripts with:
   ```bash
   export PATH="/Users/ayush.kothiyal/azure-cli-env/bin:$PATH"
   ```
3. **Contributor is enough** — the deploy needs *no* Owner/role-assignment
   rights (that's why image pull uses ACR admin creds, not managed-identity
   AcrPull).
4. Postgres must accept ACA connections — `interviewagent-sql` already has public
   access + an "allow Azure services" firewall rule, so nothing to do.

## Step 1 — build + push the four images (in the cloud, no local Docker)

```bash
cd Interview_agent_app
export PATH="/Users/ayush.kothiyal/azure-cli-env/bin:$PATH"
TAG=v1 deploy/build_tiers.sh acr
```
Builds `interview-agent-base` → then `gateway` / `worker` / `session` on top,
pushes all as `:v1`. The gateway stage compiles the SPA (`tsc && vite build`) —
a TS error fails the build here.

> If you edit code later, rebuild with a new tag (`TAG=v2 …`) and update the apps
> (Step 4 / §Updating).

## Step 2 — validate the Bicep

```bash
az bicep build -f deploy/aca/main.bicep      # compiles to main.json (gitignored)
```

## Step 3 — gather secrets, create queues, run what-if, deploy

`provision.sh` does queues → what-if → (confirm) → create. Feed it the secrets
via env. The safe secret-gathering (handles `$` in the bcrypt hash, values never
printed):

```bash
export PATH="/Users/ayush.kothiyal/azure-cli-env/bin:$PATH"
# secrets from local .env
eval "$(python3 - <<'PY'
import shlex
d={}
for line in open("deploy/local/.env"):
    if "=" in line and not line.lstrip().startswith("#"):
        k,v=line.split("=",1); d[k.strip()]=v.strip()
for k in ("AZURE_SPEECH_KEYS","OPENROUTER_API_KEY","GROQ_API_KEY","ADMIN_PASSWORD_HASH","ADMIN_SECRET_KEY"):
    if d.get(k): print("export %s=%s"%(k, shlex.quote(d[k])))
PY
)"
# DATABASE_URL from the deployed monolith (reuse the existing Postgres)
export DATABASE_URL="$(az webapp config appsettings list -g AI-COE -n interview-ai-backend --query "[?name=='DATABASE_URL'].value" -o tsv)"
export RESOURCE_GROUP=AI-COE STORAGE_ACCOUNT=interviewagentdata IMAGE_TAG=v1 LOCATION=eastus

deploy/aca/provision.sh
```
Review the what-if (should be "N to create, … to ignore"), confirm, and it
deploys. Redis is the slow part (~10–20 min). Outputs include the **Front Door
hostname**, gateway FQDN, Redis host, shard FQDNs.

## Step 4 — verify

```bash
GW=$(az containerapp show -g AI-COE -n gateway --query properties.configuration.ingress.fqdn -o tsv)
curl -s "https://$GW/healthz/live"   # {"status":"live"}
curl -s "https://$GW/ready"          # {"status":"ready","redis":true}
curl -s -o /dev/null -w "%{http_code}\n" "https://$GW/admin/login"   # 200
```
Front Door 404s for a few minutes after first creation (edge propagation) — use
the gateway URL until it's live, then the AFD hostname is your permanent URL.
Log in at `/admin/login` (`admin` / your password), schedule an interview **with
a JD** (the worker scales 0→1 to generate the cadence), run candidate + observer,
end it (the worker produces the eval).

## Scaling — add Speech keys (concurrency)

The 5-concurrent limit is **per Speech *resource***, not per key string
(`key1`/`key2` of one resource share the quota). To raise the ceiling, add
**distinct resources**:

```bash
export PATH="/Users/ayush.kothiyal/azure-cli-env/bin:$PATH"; RG=AI-COE; LOC=eastus
# create N more Speech resources (each = +5 concurrent)
for i in $(seq 1 10); do
  az cognitiveservices account create -g $RG -n "interview-speech-$i" \
    --kind SpeechServices --sku S0 -l $LOC --yes -o none
done
# collect one key from each, region-suffixed
NEW=""; for i in $(seq 1 10); do
  k=$(az cognitiveservices account keys list -g $RG -n "interview-speech-$i" --query key1 -o tsv)
  NEW="${NEW:+$NEW,}${k}:${LOC}"; done
echo "$NEW"
```
Put the full comma list (existing key + the new ones) into `AZURE_SPEECH_KEYS` in
`deploy/local/.env`, then re-run Step 3 — the Bicep updates the `speech-keys`
secret on the session apps (new revision picks it up; no image rebuild). Raise
`sessionShards` in the Bicep to add CPU capacity in lockstep (each shard ≈ 20–30
interviews). Ceiling = min(shards × ~25, Σ Speech resources × 5).

## Updating code

```bash
TAG=v2 deploy/build_tiers.sh acr
az containerapp update -g AI-COE -n gateway   --image interviewagentacr.azurecr.io/interview-agent-gateway:v2
az containerapp update -g AI-COE -n worker    --image interviewagentacr.azurecr.io/interview-agent-worker:v2
az containerapp update -g AI-COE -n session-0 --image interviewagentacr.azurecr.io/interview-agent-session:v2
az containerapp update -g AI-COE -n session-1 --image interviewagentacr.azurecr.io/interview-agent-session:v2
```
Or re-run `provision.sh` with `IMAGE_TAG=v2`. Roll back with a previous tag, or
fail over to the `demo-prod` App Service.

## Gotchas we actually hit (and the fixes)

| Symptom | Cause | Fix |
|---|---|---|
| `az: command not found` in the build script | `az` is a shell alias, not on script PATH | `export PATH=".../azure-cli-env/bin:$PATH"` before running scripts |
| Session build pulling `torch`+`nvidia-cuda` (~5 GB) | `silero-vad` pip pkg hard-deps torch (unpinned → CUDA) | removed `silero-vad` from `session.txt`; VAD uses onnxruntime + the baked `.onnx` |
| what-if: `Authorization failed … roleAssignments/write` | Contributor can't create AcrPull role assignments | pull via ACR **admin creds** (`acr.listCredentials()`); removed the role-assignment resources |
| deploy: `Conflict — That resource name isn't available` | AFD endpoint name `interview` globally taken | endpoint name = `interview-${uniqueString(resourceGroup().id)}` |
| session crashed `FileNotFoundError` (cadence/resume) | tiers are separate containers; per-session files not shared | **Azure Files** share mounted at `SESSIONS_DIR` on all tiers |
| worker crash `ModuleNotFoundError: aiohttp` | async Azure Queue client needs aiohttp | `aiohttp` in `base.txt` |
| local: worker `AzureSigningError: Invalid base64` | wrong Azurite key in compose | corrected the well-known key (local only) |
| Front Door 404 right after deploy | AFD edge propagation | wait a few minutes; use the gateway URL meanwhile |
| `az afd profile delete … --yes` → `unrecognized arguments: --yes` (profile never deletes) | the built-in `afd`/`cdn` command group is deprecated and its `profile delete` has no `--yes`; installing the `cdn` extension didn't override it in-session | delete via the ARM REST API instead (works headless, no `--yes`): `az rest --method delete --uri "https://management.azure.com/subscriptions/<sub>/resourceGroups/<rg>/providers/Microsoft.Cdn/profiles/<name>?api-version=2023-05-01"` then poll `az afd profile list`. If it 409s with *"another operation is in progress"*, a prior failed delete is still pending — just re-poll; it completes (~5–8 min). |

## Teardown (stop the bill)

```bash
export PATH="/Users/ayush.kothiyal/azure-cli-env/bin:$PATH"
for a in gateway worker session-0 session-1; do az containerapp delete -g AI-COE -n $a --yes; done
az containerapp env delete -g AI-COE -n interview-aca-env --yes
az redis delete -g AI-COE -n interview-redis --yes
# Front Door: `az afd profile delete --yes` is BROKEN (unrecognized --yes on the
# deprecated built-in command). Delete via the ARM REST API instead:
az rest --method delete --uri "https://management.azure.com/subscriptions/da74e3ed-9c9a-4605-8fae-10f3492c0f5c/resourceGroups/AI-COE/providers/Microsoft.Cdn/profiles/interview-afd?api-version=2023-05-01"
# then confirm it's gone (async; ~5-8 min):
az afd profile list -g AI-COE --query "[].name" -o tsv
# leave ACR, Storage, Postgres (shared/existing). Speech resources: delete the
# interview-speech-* ones you created if you added them.
```
