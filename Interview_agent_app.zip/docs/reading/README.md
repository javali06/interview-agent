# Reading — the tiered AI Interview Engine

Everything you need to **understand**, **run locally**, and **deploy to Azure**
the scaled (multi-tier) version of the interview app. This is the material for a
new engineer joining the `interview-scaled-dev` branch.

## What this is (in one paragraph)

The app runs autonomous voice interviews. The original app was **one webapp**
(a single container) — live interviews, web/API traffic, and slow LLM work all
shared one box, so it capped at ~20 concurrent interviews and a browsing spike
could starve interviews of CPU. The scaled version **splits the monolith by
scaling profile** into independent tiers — a stateless **gateway**, a stateful
pinned **session** tier, and a **worker** tier — coordinated by **Redis**, behind
**Azure Front Door** on **Azure Container Apps**. Each tier scales on its own
curve. `demo-prod` (the monolith) stays untouched as a rollback.

## Read in this order

1. **[01-architecture.md](01-architecture.md)** — every component, what runs
   where, how they interact, the request/data flows, and how each tier scales.
   *Start here.*
2. **[02-run-locally.md](02-run-locally.md)** — run the whole distributed stack
   on your laptop with Docker (Redis + Postgres + Azurite + all tiers), from a
   clean machine to a working interview.
3. **[03-deploy-azure.md](03-deploy-azure.md)** — deploy to Azure from scratch
   (conceptual reference): build + push images, run the Bicep, what gets
   provisioned, verify, update, roll back.
4. **[04-troubleshooting.md](04-troubleshooting.md)** — the gotchas we already
   hit and fixed, plus how to debug each tier.
5. **[05-cloud-deploy-runbook.md](05-cloud-deploy-runbook.md)** — the *as-built*
   cloud deploy: exact commands + real resource names, where every secret/env
   comes from (there is **no cloud `.env`**), how to scale Speech keys, and the
   gotchas we actually hit. Follow this to deploy it yourself.
6. **[06-session-autoscaling-design.md](06-session-autoscaling-design.md)** — a
   *proposal* for making the session tier elastically + robustly auto-scale by
   moving it off ACA onto **AKS** (StatefulSet shards + a drain-based
   scale-in controller + schedule-driven pre-warm). The "where we go next" doc.
7. **[07-scaling-cost-and-decisions.md](07-scaling-cost-and-decisions.md)** — the
   ACA-vs-AKS cost analysis (100→500/day), the break-even by interviews-per-shard,
   the cheaper schedule-driven (cron) ACA path, and how to measure capacity
   (`scripts/loadtest_interviews.py`). The "should we actually move to AKS, and
   what does it cost" companion to 06. Read after 06.
8. **[08-observability-and-stress-test.md](08-observability-and-stress-test.md)** —
   hands-on: the local Grafana + Prometheus + cAdvisor stack (`--profile obs`), the
   session `/metrics` endpoint, and how to stress-test one shard to find
   interviews-per-shard (C) + which resource is the bottleneck. Cloud calibration
   via `dump_shard_metrics.py`. Read after 07.
9. **[TODO.md](TODO.md)** — hardening & follow-ups before a real pilot (lock the
   gateway to Front Door only, tighten the Postgres firewall, Redis counter
   reconciliation, private endpoints, scaling).

## The 30-second mental model

```
                    ┌─────────────────┐
   browsers  ─────► │ Azure Front Door│  one public HTTPS/WSS address
                    └────────┬────────┘
                             │ /*  and  /ws/*
                    ┌────────▼────────┐
                    │  GATEWAY (ACA)  │  stateless: SPA + /api + auth + WS proxy
                    │  scale on HTTP  │  scales 1→10 on traffic
                    └───┬─────────┬───┘
              /ws/* proxy│         │enqueue slow jobs
        (to owning shard)│         │
        ┌────────────────▼──┐   ┌──▼───────────────┐
        │ SESSION shards    │   │  WORKER (ACA)     │  cadence-gen, eval, …
        │ (ACA, pinned 1ea) │   │  scale 0→10 on    │  scales to ZERO when idle
        │ live interview +  │   │  queue depth      │
        │ Stream A (VAD)    │   └──┬────────────────┘
        └───┬───────────────┘      │
            │        ┌─────────────┼───────────────┐
            ▼        ▼             ▼               ▼
        ┌───────┐ ┌──────────┐ ┌──────────┐  ┌──────────────┐
        │ Redis │ │ Postgres │ │  Blob +  │  │ Azure Speech │
        │ coord │ │  truth   │ │ Az Files │  │  (STT/TTS)   │
        └───────┘ └──────────┘ └──────────┘  └──────────────┘
```

- **Redis** is the scale-out unlock: it holds the *token → owning shard*
  registry (replacing the old in-process dict), cluster-wide admission counters,
  locks, and observer pub/sub.
- **Postgres** is the durable system of record (roles, candidates, sessions,
  scores, jobs). **Azure Files** (a shared filesystem at `SESSIONS_DIR`) holds
  per-session files (resume, cadence.yaml, events.jsonl) every tier reads/writes.
- **Blob** durably mirrors recordings + results. **Azure Speech** does STT + TTS.

## Where the code lives (quick map)

| Concern | Path |
|---|---|
| Gateway app | `deploy/gateway_app.py`, `app/gateway/ws_proxy.py` |
| Session app | `deploy/azure_app.py`, `app/session_tier/` |
| Worker | `app/jobs/` (`worker.py`, `queue.py`, `jobs.py`, `status.py`) |
| Coordination (Redis) | `app/coordination/` (`registry`, `admission`, `locks`, `pubsub`) |
| Capacity broker | `app/broker/` (`speech_pool`, `stt_fallback`, `llm_guard`) |
| Data layer | `db/` (`engine.py`, `models.py`), `app/blob_store.py` |
| Images / deploy | `deploy/Dockerfile.{base,gateway,worker,session}`, `deploy/requirements/`, `deploy/build_tiers.sh` |
| Local stack | `deploy/local/docker-compose.yml`, `deploy/local/.env.example` |
| Azure IaC | `deploy/aca/main.bicep`, `deploy/aca/provision.sh`, `deploy/aca/RESOURCES.md` |
| The plan | `docs/scaling-architecture-plan.md` |
