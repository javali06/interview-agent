# 02 — Run the whole stack locally

Run the full distributed system on your laptop with Docker. The local stack uses
**containerized stand-ins** for the Azure managed services, so you need **no
Azure account** and **nothing installed** except Docker:

| Cloud service | Local stand-in (a container) |
|---|---|
| Azure Cache for Redis | `redis:7-alpine` |
| Azure Database for PostgreSQL | `postgres:16-alpine` |
| Azure Storage (Queue + Blob) | `azurite` (Microsoft's official emulator) |
| Azure Files (shared `SESSIONS_DIR`) | a named docker volume (`sessions`) |
| Azure Speech (STT/TTS) + LLMs | **real** cloud APIs — need real keys (pay-per-use) |

> There's no emulator for Azure Speech or the LLMs. The *plumbing* (scheduling,
> cadence-gen job, registry routing, worker, eval) runs fully offline, but an
> actual **voice** interview calls Azure Speech + OpenRouter/Groq over the
> internet with your real keys.

Everything is defined in `deploy/local/docker-compose.yml`.

## Prerequisites

1. **Docker Desktop** (macOS/Windows) or Docker Engine + Compose v2. That's it.
   Verify:
   ```bash
   docker --version
   docker compose version
   ```
2. Real API keys for a voice interview: an **Azure Speech** key, an
   **OpenRouter** key (and optionally **Groq**).

## Step 1 — Configure secrets (`deploy/local/.env`)

The compose file provides all the *wiring* (Redis/Postgres/Azurite URLs, shard
names). You only supply **secrets + model config** in `deploy/local/.env`:

```bash
cd Interview_agent_app
cp deploy/local/.env.example deploy/local/.env
```

Then fill these in `deploy/local/.env`:

| Key | Notes |
|---|---|
| `OPENROUTER_API_KEY` | required (slow + fast LLM) |
| `GROQ_API_KEY` | optional (STT fallback / fast LLM) |
| `AZURE_SPEECH_KEYS` | your Speech key(s), comma-separated. One key = just the key, no comma. `key` or `key:region`. |
| `AZURE_SPEECH_REGION` | e.g. `eastus` (used when a key has no `:region`) |
| `ADMIN_PASSWORD_HASH` | bcrypt hash — `python scripts/admin_password.py` |
| `ADMIN_SECRET_KEY` | any 32+ random chars |
| `LANGFUSE_PUBLIC_KEY` / `LANGFUSE_SECRET_KEY` / `LANGFUSE_PROJECT_ID` | optional (tracing + the "View in Langfuse" UI link) |

The model/provider values (`SLOW_MODEL`, `FAST_MODEL`, provider orders) are
pre-filled in `.env.example` to match the deployed app — leave them as-is.

**Shortcut — copy secrets from the deployed app** (they never print):
```bash
az webapp config appsettings list -g AI-COE -n interview-ai-backend -o json > /tmp/ps.json
python3 - <<'PY'
import json
d={i['name']:i['value'] for i in json.load(open('/tmp/ps.json'))}
keep=['OPENROUTER_API_KEY','GROQ_API_KEY','ADMIN_PASSWORD_HASH','ADMIN_SECRET_KEY',
      'LANGFUSE_PUBLIC_KEY','LANGFUSE_SECRET_KEY','LANGFUSE_PROJECT_ID','LANGFUSE_BASE_URL',
      'AZURE_SPEECH_REGION','AZURE_SPEECH_VOICE','SLOW_PROVIDER','SLOW_MODEL',
      'SLOW_PROVIDER_ORDER','SLOW_LLM_MAX_TOKENS','FAST_MODEL','FAST_PROVIDER_ORDER']
lines=[f'{k}={d[k]}' for k in keep if d.get(k)]
lines.append(f"AZURE_SPEECH_KEYS={d.get('AZURE_SPEECH_KEY','')}")  # single prod key → local pool
lines.append('SPEECH_STREAMS_PER_KEY=5')
open('deploy/local/.env','w').write('\n'.join(lines)+'\n')
print('wrote deploy/local/.env:', ', '.join(l.split('=')[0] for l in lines))
PY
rm -f /tmp/ps.json
```

## Step 2 — Build the four images

Base image + the three tier images (gateway/worker/session), all `:local`:
```bash
deploy/build_tiers.sh local
```
This runs `docker build` for `Dockerfile.base` then each tier on top. The
**gateway** stage compiles the React SPA (`tsc && vite build`) — a TypeScript
error fails the build here (your frontend safety net). First build takes a few
minutes; later builds are cached.

## Step 3 — Run it

```bash
docker compose -f deploy/local/docker-compose.yml up
```

Compose starts Redis, Postgres, Azurite, then the gateway + `session-0` +
`session-1` + worker. Wait for `gateway-1 … Application startup complete` and
`session-… Stream A is healthy`.

Open **http://localhost:8080/admin/login** (user `admin`, your `.env` password).

## Step 4 — Test an interview end-to-end

1. **Schedule** an interview. Upload a **JD** (so cadence generation goes through
   the worker) → you'll see a **"Generating interview plan…"** screen that
   auto-resolves to the cadence editor. Watch `worker-1` logs pick up the job.
2. **Approve** → copy the **candidate link** → open in an incognito window →
   allow mic/camera → the interview should start and the AI should speak.
3. **Observer**: open the **observer link** in another tab to watch live
   (candidate audio/video + transcript relayed through the gateway proxy).
4. **End** the interview → the shard enqueues `eval_v2` → the worker produces the
   evaluation → view it on the session detail page.

### What to watch in the logs
- `gateway … [gw-proxy] candidate token=… -> session-0:8080` — routing works.
- `session-0 … [claim] token=… -> shard=session-0 stt=azure` — the shard claimed it.
- `worker … <job> ok` — the worker drained a job.

## Everyday commands

```bash
# stop (keep data)
docker compose -f deploy/local/docker-compose.yml down

# stop + wipe Postgres AND the shared sessions volume (clean slate)
docker compose -f deploy/local/docker-compose.yml down -v

# rebuild after a CODE change, then restart
deploy/build_tiers.sh local
docker compose -f deploy/local/docker-compose.yml up

# tail one tier
docker compose -f deploy/local/docker-compose.yml logs -f worker
docker compose -f deploy/local/docker-compose.yml logs -f session-0

# open a shell in a running container
docker compose -f deploy/local/docker-compose.yml exec gateway bash
```

> **When to `down -v`:** after changing the DB schema, or when old draft rows
> point at session files that aren't on the current volume. It wipes Postgres +
> the `sessions` volume for a truly clean run. After it, create a fresh interview.

> **When to rebuild:** any change under `app/`, `engine/`, `db/`, `deploy/…` or
> `deploy/requirements/*` is baked into the images — rebuild with
> `deploy/build_tiers.sh local`. Changes to `docker-compose.yml` or `.env` only
> need a `down` + `up`.

## Local vs cloud differences (intentional)

| Thing | Local | Cloud |
|---|---|---|
| Public entry / router | **no Front Door** — browser hits the gateway directly at `localhost:8080` | **Azure Front Door** (public HTTPS/WSS + TLS) → gateway |
| TLS | none (plain HTTP on localhost) | Front Door terminates HTTPS/WSS |
| Blob mirror | `BLOB_ENABLED=0` (Azurite append is flaky) | `BLOB_ENABLED=1` (real Blob) |
| Recordings (webm) | not saved | saved to Blob |
| Shared `SESSIONS_DIR` | docker volume | Azure Files share |
| Redis/Postgres/Queue | containers | managed Azure services |
| STT/TTS/LLM | real cloud APIs | real cloud APIs |
| Session shards | 2 (`session-0/1`) | `sessionShards` param (N apps) |

> **Front Door is cloud-only.** Its jobs — a single public address, TLS, and
> forwarding to the gateway — are pointless on localhost, so we omit it and talk
> to the gateway container directly. It does *not* do the per-interview routing
> (it can't read Redis); the **gateway** does that WS proxy in both environments,
> so nothing functional is lost locally.

See **[04-troubleshooting.md](04-troubleshooting.md)** if something doesn't come up.
