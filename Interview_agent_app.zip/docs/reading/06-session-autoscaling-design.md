# 06 — Session-aware autoscaling design (AKS)

A design proposal for making the **session tier** elastically and *robustly*
scalable — the thing the current ACA deployment can't do well. This is the
"where we go next" document; [01-architecture.md](01-architecture.md) is the
as-built system.

> **Status: proposal.** Nothing here is deployed. It's the plan for moving the
> live-interview tier off Azure Container Apps onto **AKS** so it can auto-scale
> *without cutting live interviews*.

## Why the current model can't auto-scale sessions

The live interview is a **stateful, long-lived, real-time session**: its brain,
director, conversation history, VAD stream, and open Azure STT/TTS connections
all live in **one process's RAM** and cannot migrate mid-call. Two consequences
drive this entire design:

1. **Inbound connections must return to the exact process** holding the session
   (candidate reconnect, observer join, recording resume). A load balancer over
   anonymous replicas can't guarantee that.
2. **You cannot remove a box that has a live interview on it.** An interview
   runs 20–40 minutes; no autoscaler's termination grace period is that long.

ACA's managed autoscaler (KEDA) only scales **replicas** — anonymous, not
individually addressable, and it picks which ones to kill on scale-in. That's
fine for stateless tiers (gateway, worker) and fundamentally wrong for sessions.

### Shard vs. replica (the core distinction)

- **Replica** — an anonymous copy of an app behind one shared address; the load
  balancer picks one; you can't dial a specific replica. Great for stateless work.
- **Shard** — a *named, individually addressable* instance. Today we fake this
  on ACA by running one app per shard (`session-0`, `session-1`), each pinned to
  a single replica, so each has a stable FQDN we can route to.

Interviews need addressable instances → shards. Scaling sessions = **more/bigger
shards**, never "more replicas of one session app."

## The three invariants any robust design must satisfy

1. **Capacity-aware placement** — a new interview goes to a shard with *measured*
   room, or triggers new capacity.
2. **Pinned + addressable** — all of an interview's traffic returns to its shard
   (already implemented: Redis registry + gateway WS proxy).
3. **Scale-in only by draining** — never terminate a shard with a live
   interview; cordon it, let its interviews finish, *then* remove it.

Plus resilience: survive pod/node failure, gate placement on health, apply
graceful backpressure at the ceiling.

## Platform: AKS

Move the session tier to **Azure Kubernetes Service**. AKS gives the primitives
ACA withholds: **StatefulSets** (stable pod identity + headless-Service DNS =
native shards), **lifecycle hooks** + **PodDisruptionBudgets** (controlled
drain, no involuntary eviction of a busy pod), **Cluster Autoscaler** (node
elasticity), and the ability to run **Agones** if wanted. Gateway + worker can
stay on ACA or move to AKS as ordinary Deployments — they have no drain problem.

### Pattern choice

| Approach | What you get | Verdict |
|---|---|---|
| **AKS StatefulSet + custom allocator** | Stable pod identities; **reuses the existing Redis registry/admission/broker** almost unchanged | **Recommended** — most incremental; ~80% of the control plane already exists |
| **AKS + Agones** | Purpose-built session lifecycle (`Ready→Allocated→Shutdown`) + fleet autoscaler + drain, batteries-included | Right model, but a whole game-server framework (CRDs, SDK) — more than this app needs. Fallback if you outgrow the custom allocator |
| **Azure PlayFab Multiplayer Servers** | *Managed* session allocation + scaling | Game-oriented; awkward fit for a web app |

## Target components

**Session pods** — a StatefulSet on a **dedicated, regular (non-spot) node pool**.
Stable per-pod DNS replaces the one-app-per-shard hack. A **readiness gate**
keeps a pod out of rotation until the VAD model is loaded and Speech is
reachable, so the allocator never places on a cold pod.

**Allocator / matchmaker** — reuses the Redis control plane. On interview start:
pick a pod whose *live count < measured capacity* (capacity-aware, not just
least-loaded), record `token→pod` in the registry; the gateway proxies there.
Because interviews are **pre-scheduled**, it can pre-warm pods against the
*booking calendar* — scaling ahead of start times, sidestepping cold-start.

**Autoscaler (the net-new controller)**
- **Scale-out**: when fleet headroom (Σ capacity − Σ live) drops below a buffer,
  or the schedule demands it, add a pod (Cluster Autoscaler adds a node if
  needed).
- **Scale-in (drain, never kill)**: cordon the emptiest pod (allocator stops
  placing there) → it keeps serving its current interviews → when it reaches
  zero live, delete it → node scales down if empty. The pod is
  *cordoned-but-healthy*, so there's no termination-grace problem.
- **PodDisruptionBudget** blocks involuntary eviction (node upgrades) of a busy
  pod.

**Node topology** — session pool: regular VMs + Cluster Autoscaler, tainted for
session pods only. Stateless pool: gateway/worker as Deployments with KEDA/HPA
(worker can use spot).

**Ingress** — Front Door → AKS ingress (nginx/AGIC) → gateway → WS proxy → session
pod DNS. Front Door stays.

## Robustness beyond scaling

1. **Session checkpointing → real resume.** Snapshot recoverable state
   (conversation history, cadence position, phase) to Redis/Postgres every few
   turns. If a pod dies unexpectedly, a reconnect resumes the conversation on a
   new pod (the audio stream re-establishes; context isn't lost). Turns "pod
   died = interview lost" into "pod died = brief blip."
2. **PDB + non-spot nodes** minimize involuntary kills.
3. **Health-gated placement + a small warm pool** so a spike is instant.
4. **Graceful backpressure** — at capacity, refuse/queue new *starts* cleanly
   (already returns `at_capacity`); cap bookings per time slot.
5. **Observability** — per-pod live-count/capacity/drain gauges; alert on
   "headroom < buffer."

## What carries over (most of it)

Reusable unchanged: **Docker images**, the **Redis coordination plane**
(registry/admission/locks/pubsub), the **gateway WS proxy**, the **capacity
broker**, the **worker + queue**. Net-new: the **allocator + drain controller**,
**K8s manifests** (StatefulSet/Deployment/Service/PDB), **Cluster Autoscaler +
node pools**, **ingress**, and **session checkpointing** for resume.

## Phased migration (de-risked)

1. **Lift to AKS at parity** — StatefulSet with a *fixed* pod count (= today's
   static shards). Prove an interview works identically. No new behavior.
2. **Capacity-aware allocator + schedule-driven pre-warm** — placement gets
   smart; capacity calibrated by the single-interview measurement.
3. **Drain-based scale-in controller + Cluster Autoscaler + PDB** — now it's
   elastic *and* safe on scale-down.
4. **Session checkpoint/resume** — failure robustness.

## The honest trade-off

AKS means you **own a cluster** (upgrades, node pools, more YAML, more to
monitor). That's the price of real-time elasticity done right — the same price
Zoom and game-server fleets pay. The simpler alternative is to **stay on ACA
with static, right-sized shards** (no elastic scale-down); adequate when your
peak is known and bounded.

## Prerequisite either way: the measurement

Every capacity/scaling number here (pods needed, per-pod CPU, headroom buffer)
depends on **interviews-per-shard at a given vCPU** — measured from a real
interview under load. That measurement is step zero. See the STT-latency finding
in [04-troubleshooting.md](04-troubleshooting.md): a shard that can't process
audio at real-time has an interviews-per-shard of ~1, which makes *any* scaling
math wrong until CPU/threads are fixed first.
