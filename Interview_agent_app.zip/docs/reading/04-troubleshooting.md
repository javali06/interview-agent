# 04 — Troubleshooting

The problems we already hit (with root cause + fix), then a per-tier debug guide.
Most bugs at this layer are **config/wiring**, not logic.

## Issues we found and fixed

### Candidate "could not connect" / session crashes with `FileNotFoundError`
**Symptom:** candidate link retries 3× then fails; session logs show
`resume parse failed … Resume file not found` then
`task session-… raised: FileNotFoundError` on cadence load.
**Cause:** per-session files (resume, `cadence.yaml`) are written by the
**gateway** container but read by the **session shard** — a *different* container
with its own disk.
**Fix:** a shared filesystem at `SESSIONS_DIR` — a docker volume locally, an
**Azure Files** share in cloud (mounted on all tiers). This is load-bearing.

### Worker exits with `ModuleNotFoundError: aiohttp`
**Cause:** the async Azure Queue client (`azure-storage-queue.aio`) needs
`aiohttp` as its transport.
**Fix:** `aiohttp` is in `deploy/requirements/base.txt` (baked into every image).
If you see this, you're on an old image — rebuild.

### Worker `AzureSigningError: Invalid base64-encoded string` (local)
**Cause:** the **Azurite** well-known account key in `docker-compose.yml` was one
char short → queue auth failed. Local-only (prod uses your real storage key).
**Fix:** corrected the key (ends `…HBeksoGMGw==`). If you edit it, validate:
`python -c "import base64;base64.b64decode('<key>',validate=True)"`.

### No "View in Langfuse" link in the admin UI
**Cause:** tracing needs `LANGFUSE_PUBLIC_KEY`+`LANGFUSE_SECRET_KEY` (traces emit
to the Langfuse dashboard), but the **UI link** also needs `LANGFUSE_PROJECT_ID`.
**Fix:** set `LANGFUSE_PROJECT_ID` (and `LANGFUSE_BASE_URL`) — see `.env.example`.
Not a bug; traces are already in Langfuse cloud even without the link.

### Azurite `ApplicationInsights … ETIMEDOUT` log spam (local)
Harmless — Azurite's own telemetry can't phone home. Silenced with
`--disableTelemetry` in the compose file. No prod analogue.

### Docker build: `base name (${BASE_IMAGE}) should not be blank`
**Cause:** in a multi-stage Dockerfile, an `ARG` used in `FROM` must be declared
**before the first `FROM`** (global scope). The gateway Dockerfile's `ARG` sat
after the `webbuild` stage.
**Fix:** `ARG BASE_IMAGE` is now global at the top of `Dockerfile.gateway`.

### Recordings not saved locally
Intentional: `BLOB_ENABLED=0` locally because Azurite's append-blob support is
flaky. Works in cloud with real Blob (`BLOB_ENABLED=1`). The **live** observer
view is independent of Blob (relayed over the WebSocket) and works locally.

## Per-tier debug guide

### Gateway won't start / 500s
- Needs `REDIS_URL`, `DATABASE_URL`, `AZURE_STORAGE_CONNECTION_STRING`.
- `GET /ready` returns 503 if Redis is unreachable; `GET /healthz/live` = process up.
- SPA missing (`/app disabled`)? The gateway image didn't get `ui/web/dist` — the
  `tsc`/`vite build` stage failed; rebuild and read the build output.

### Candidate connects but interview doesn't start
- Look at the **session** shard logs (not the gateway). Common causes:
  - `FileNotFoundError` on cadence/resume → `SESSIONS_DIR` isn't shared (see above).
  - `claim refused … reason=at_capacity` → `MAX_ACTIVE_SESSIONS` hit.
  - `claim refused … reason=no_speech_capacity` → all Speech streams in use
    (Σ keys × `SPEECH_STREAMS_PER_KEY`) and no Groq fallback.
  - `claim refused … reason=owned_elsewhere` → the token is already on another
    shard; the gateway should route there (check the registry).

### Reconnect / observer lands on the wrong shard
- The gateway reads the owning shard from the Redis **registry**
  (`reg:session:{token}`). If it 404s the observer, the interview isn't live
  (no registry entry). Confirm the candidate session is running.

### Cadence stuck on "Generating…"
- The **worker** isn't draining the queue. Check `worker` logs and that the
  `jobs` queue exists + `AZURE_STORAGE_CONNECTION_STRING` is valid.
- Job status lives in the Postgres `jobs` table
  (`SELECT id,type,status,error FROM jobs ORDER BY created_at DESC LIMIT 10;`).
  `status=dead` → check `error`; the message was dead-lettered to `jobs-poison`.

### Worker never wakes up (cloud)
- KEDA scales on the `jobs` queue; if the queue doesn't exist it stays at 0.
  `provision.sh` pre-creates it — confirm `jobs`/`jobs-poison` exist on the
  storage account.

### Evaluation never appears
- Session end enqueues `eval_v2`; the worker hydrates inputs (Blob / shared FS),
  runs it, writes `evaluation.json`. Check worker logs for `eval_v2 … ok`, and
  that `events.jsonl` is present on the shared filesystem.

## Handy inspection commands

```bash
# Redis state (local)
docker compose -f deploy/local/docker-compose.yml exec redis redis-cli keys 'reg:*'
docker compose -f deploy/local/docker-compose.yml exec redis redis-cli get reg:session:<token>
docker compose -f deploy/local/docker-compose.yml exec redis redis-cli mget adm:active_sessions adm:llm_inflight

# Postgres (local)
docker compose -f deploy/local/docker-compose.yml exec postgres \
  psql -U interview -c "select token,status from sessions order by created_at desc limit 5;"
docker compose -f deploy/local/docker-compose.yml exec postgres \
  psql -U interview -c "select id,type,status,error from jobs order by created_at desc limit 5;"

# Queue depth (local, via azurite)
docker compose -f deploy/local/docker-compose.yml logs azurite | tail

# Cloud logs
az containerapp logs show -g AI-COE -n <gateway|worker|session-0> --follow
```

## The golden rules

- **Redis or Postgres unreachable → nothing works.** They're hard dependencies.
- **`SESSIONS_DIR` must be shared** across tiers, or interviews can't start.
- **Session shards are pinned** (1 replica each); scale by adding shard apps +
  Speech keys together.
- **Rebuild images** after any `app/`/`engine/`/`db/`/requirements change; only
  compose/env changes work with a plain restart.
- A local bug with a cloud analogue gets fixed in **both** `docker-compose.yml`
  and `deploy/aca/main.bicep`.
