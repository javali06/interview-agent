# TODO — hardening & follow-ups before a real pilot

The tiered system is deployed and works, but a few things were intentionally
deferred for the initial cutover. Do these before opening it to real candidates
at scale. Grouped by priority.

## P1 — before external / high-concurrency use

- [ ] **Lock the gateway to Front Door only.** The gateway's ACA ingress is
  currently public (both the `*.azurecontainerapps.io` URL and Front Door reach
  it). Restrict it so only Front Door traffic is accepted — set ingress IP
  restrictions to Front Door's `AzureFrontDoor.Backend` service tag and/or
  validate the `X-Azure-FDID` header against the AFD profile id. Then the raw
  ACA hostname can't be hit directly.
- [ ] **Tighten the Postgres firewall.** `interviewagent-sql` has a wide-open
  `AllowAll 0.0.0.0–255.255.255.255` rule (anyone on the internet with creds can
  connect). Remove it; rely on `AllowAllAzureServicesAndResourcesWithinAzureIps`
  or, better, a **private endpoint** on the ACA VNet.
- [ ] **Auth hardening** (from `deploy/README.md`): make `ADMIN_PASSWORD_HASH`
  mandatory (no dev fallback), validate the candidate token on the WS before
  `accept()`, and rotate any keys that ever leaked into git history.

## P2 — resilience / correctness

- [ ] **Redis counter reconciliation.** The admission counters
  (`adm:speech:{key_id}`, `adm:llm_inflight`, `adm:active_sessions`) don't
  self-heal after a Redis flush (unlike the registry, which the shard heartbeat
  re-asserts). Add a reconciler that, on Redis reconnect and/or a timer,
  recomputes the counters from the live registry entries — closing the brief
  over-admission window (possible Speech 429s) after a rare Redis wipe.
  Files: `app/coordination/admission.py` + a small loop in the session tier.
- [ ] **Redis durability.** Standard tier is replicated with failover; for a
  hard guarantee consider **Premium** (RDB/AOF persistence). Ephemeral by
  design, so optional — the truth is Postgres + Blob/Files.
- [ ] **Private endpoints** for Redis + Postgres on the ACA environment's VNet
  (currently reached over public endpoints with firewall rules).
- [ ] **Managed identity for Storage/Speech** instead of connection-string /
  key secrets where the SDK supports it. Needs a role-assignment-capable account
  (Owner / User Access Administrator) — the current deploy uses ACR **admin
  creds** precisely because the deploying user is a Contributor and can't create
  role assignments.

## P3 — scale & product

- [ ] **Scale Speech + shards together** for the target concurrency: each Speech
  *resource* = 5 concurrent streams; each session shard ≈ 20–30 CPU-bound
  interviews. Add distinct Speech resources to `AZURE_SPEECH_KEYS` and raise the
  `sessionShards` Bicep param in lockstep (see the runbook §"Scaling").
- [ ] **Decide DB isolation.** The tiered apps currently share the *same*
  Postgres db (`postgres` on `interviewagent-sql`) as the `demo-prod` monolith —
  convenient for data continuity, but the two systems write the same tables.
  Consider a dedicated db for the tiered system if you want isolation.
- [ ] **Wire the remaining job types** when those features exist:
  `rubric_gen`, `recording_finalize`, `webhook`, `bulk_export`, `invite_dispatch`
  (the queue/worker machinery already supports any registered handler).
- [ ] **Cost controls.** Review Redis SKU, session-shard count (each is
  always-on ~$35/mo), and Front Door tier. Tear down when idle (runbook
  §"Teardown"). Baseline is ~$130–220/mo.
- [ ] **Retire `demo-prod`** App Service once the tiered deploy is validated
  (it's the current rollback).

## Done (for reference — fixed during the initial deploy)

- [x] Session image slimmed — dropped `silero-vad` (it pulled torch+CUDA ~5 GB);
      VAD runs on onnxruntime against the baked `silero_vad.onnx`.
- [x] ACR pull via admin creds (Contributor can't create AcrPull role assignments).
- [x] Front Door endpoint name made globally unique.
- [x] Shared `SESSIONS_DIR` via Azure Files across all tiers.
- [x] `aiohttp` added for the async Azure Queue client.
- [x] `deploy/local/` excluded from the image build context (no `.env` leak).
