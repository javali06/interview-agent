# Authentication and RBAC — working guide

**Personal implementation notes. This is not a proposal or a document for approval.**

The purpose is to keep a clear picture of what we already have, what is still
missing, and how we will finish it. It answers two questions:

1. **Authentication** — who is this person?
2. **RBAC** (role-based access control) — what is this person allowed to do?

Maker-checker sits on top of RBAC: the Author writes, the Checker reviews, and
only approved questions become available to interviews.

This is the file we will keep editing until it says exactly what we are going
to build.

### The simple mental model

When someone opens the app, the system should answer these questions in order:

1. **Are you signed in?** If no, show the login page.
2. **Who are you?** Find the person's application user record.
3. **What roles do you have?** For example Author on one team, or Checker on another.
4. **What permissions come from those roles?**
5. **Does the requested action belong to the team covered by the permission?**
6. **Are there extra workflow rules?** For example, an Author cannot approve
   their own pool even if they also hold a Checker role.

The browser uses those answers to show the right screens and buttons. The
server repeats the permission check before doing the action. The server's
answer is final.

---

## 1. The three layers

| Layer | Question it answers | Built? |
|---|---|---|
| Authentication | Who signed in? | Partly. A shared admin password, plus a development chooser that signs in as a named person. Company Microsoft sign-in is not built. |
| RBAC | What may that person do, and for which team? | Yes, for question pools, and the Access screens (People, Teams, Roles) now change it. Sign-in is still the development chooser, not Microsoft. |
| Maker-checker | May this pool go live? | Yes. Submit, per-question approve/reject, return, withdraw, force-publish. |

Hiding a button is not the security control. The server refuses the request even if the button is shown, or if someone calls the API directly.

---

## 2. How someone signs in today

There are two doors. They issue the same cookie (`admin_session`, httpOnly, 12 hours). They do not grant the same rights.

### Door A — shared admin login

`POST /api/login` with the username and password from the environment (`ADMIN_USERNAME`, `ADMIN_PASSWORD_HASH`). If no password hash is set, the development fallback password is `centific123`.

The cookie records a **name string only**. It does not record an `app_users` id. Every permission check then fails closed: this session is "someone is signed in", not "this person holds a role".

That session can still open pages that only ask "is anyone logged in?" — Dashboard, Shortlist, New interview, and the sidebar. It cannot pass a question-pool permission check.

While development sign-in is on, the same form also accepts a seeded person's **email** in place of the username. The password is still the one admin password above. Nothing is stored on the person. The cookie then carries their `app_users` id, so the menu follows their role. With development sign-in off, an email is refused.

### Door B — development sign-in

Shown on the login page only when `DEV_LOGIN_ENABLED=1`. It lists the seven seeded accounts. Picking one calls `POST /api/dev/login`. There is no password.

The cookie records **both** the email and the person's `app_users.id`. That id is what every permission check reads.

This door is off unless the environment variable is set. A normal deployment returns 404 for `/api/dev/accounts` and `/api/dev/login`, so the chooser does not appear.

This is a stand-in so we can test Author, Checker, Admin, and HR. It is not production authentication.

### What production sign-in still has to do

Microsoft (Entra) will answer "who is this person?" and our database will keep answering "what may they do?". Until that sign-in exists, a named person with a role signs in through Door B, or by typing their email on Door A while development sign-in is on. The steps for Microsoft sign-in are in section 13 of this file.

---

## 3. What the server knows after sign-in

`GET /api/me` answers only "is a cookie valid?" and returns the name string. The sidebar uses this. It does **not** look at roles, which is why every signed-in person currently sees the same four menu items.

`GET /api/me/permissions` is what the question-pool screens use. For a development sign-in it returns:

- id, email, display name
- roles, each with the team it applies to
- permissions, as `{ permission: [team, ...] }`

A shared-admin cookie gets `{ authenticated: true, legacy: true, permissions: {} }`. Signed in, allowed to do nothing that requires a permission.

An inactive user, an unknown user, or a permission that is not in the fixed list below is treated as **not allowed**.

---

## 4. The permission list

Permissions are a closed list in `app/rbac.py`. A typo cannot invent a new one. A role can only be given names from this list.

### Question pools

| Permission | Allows |
|---|---|
| `pools.view` | See the pool list, open a pool, export YAML, read history of pools they are allowed to see. |
| `pools.edit` | Create, edit, duplicate, and delete a **draft**. Upload question material. |
| `pools.submit` | Submit a draft into the approval chain. Withdraw their own pending submission. |
| `pools.approve` | Review a pending pool: approve or reject each question, or return the whole pool. |
| `pools.publish` | Force-publish, skipping the chain. Also required to delete a pool that is already published. |

### Interviews (defined, not enforced on routes yet)

| Permission | Intended for |
|---|---|
| `interviews.view` | See interviews and results. |
| `interviews.schedule` | Create and schedule interviews. |
| `interviews.cancel` | Cancel an interview. |

HR is given these three. No interview route currently calls `require("interviews.view")` or the others. Dashboard, Shortlist, and New interview still open for anyone with a valid cookie, including an Author who was never meant to schedule interviews, and including HR.

### Administration (defined, no screen and no route)

| Permission | Intended for |
|---|---|
| `admin.users` | Add people, grant and remove roles. |
| `admin.teams` | Create teams and set their approval chain. |
| `admin.permissions` | Edit which role holds which permission. |

Nothing in the frontend calls these. Holding `admin.users` does not open an admin page, because that page does not exist.

---

## 5. Roles, and what each one holds

A **role** is a bundle of permissions. A person is not given permissions one by one. They are given a role, on a team.

Seeded in `app/rbac_seed.py`. The grid is written only when the permission table is empty, so a later edit in the database is not overwritten on restart. Teams, roles, and the seven accounts are created if missing on every startup.

| Role | Scope | Permissions |
|---|---|---|
| Platform Admin | Global | All eleven permissions above. |
| Question Author | One team | `pools.view`, `pools.edit`, `pools.submit` |
| Question Checker | One team, or every team | `pools.view`, `pools.approve` |
| HR / Recruiter | Global | `interviews.view`, `interviews.schedule`, `interviews.cancel`. No `pools.*` permission at all. |

An Author cannot approve. A Checker cannot edit or submit. HR cannot open a pool through the API. An Admin can do all of it, including force-publish.

One person can hold more than one grant. A grant is the triple **(person, role, team)**.

A checker on one team can also be the author on another team. That is a real case we will allow: two grants, one person. On the team where they are the author, they write and submit. On the team where they are the checker, they review other people's pools. They still cannot approve a pool they submitted or authored themselves. The second pair of eyes has to be someone else.

The same person is not both author and checker on the same team. Giving them the Author grant and the Checker grant for one team is refused. A Checker grant on `*` covers every team, so that grant plus an Author grant on any team is the same refusal: they would be checker of the team they write for. Platform Admin is the separate role that already holds both permissions, on every team, and the self-approval rule still applies to an admin.

---

## 6. Teams

A permission is never "for the whole product" unless the team on the grant is `*`.

The rows below are **examples taken for testing**, not the teams we will ship. `backend` and `qa` exist so we can try "this person may act on one team and must be refused on another." Before the production release we replace them with the real teams. The names and how many teams there are come from that requirement.

| Team key | Meaning |
|---|---|
| `backend` | Example only: Backend Engineering. A test team, not a production team. |
| `qa` | Example only: Quality Assurance. A test team, not a production team. |
| `*` | Every team. A real row, not a blank. Called `GLOBAL_TEAM` in code. This one we keep: a grant on `*` covers every team, whatever the real teams are named. |

Rules:

- A check **with** a team passes if the person holds that permission for that team, or for `*`.
- A check **without** a team passes if they hold the permission anywhere. That is what a menu button uses ("do they approve anything?").
- A checker on one team is refused on another team's pool. A checker granted `*` can sign any team's pool.
- A new pool must name a team the author is allowed to write for. Leaving the team blank means `*`, and an author who only has one team cannot create an "every team" pool.

The development sign-in chooser has test accounts so we can click through these roles. They are not production users, and this guide does not name them. Real people come from Microsoft sign-in, and an administrator assigns the role and team. The grants we test with are:

| Role | Grant we test with |
|---|---|
| Platform Admin | Admin on `*` |
| Question Author | Author on one example team |
| Question Checker | Checker on one example team |
| Question Checker | Checker on `*` (every team) |
| Question Author | Author on the other example team, to prove a cross-team refusal |
| HR / Recruiter | HR on `*` |

---

## 7. How one check is decided

`has_permission(user_id, permission, team)`:

1. No user id → no.
2. Permission not in the closed list → no.
3. User missing or inactive → no.
4. Load every grant: role permissions joined to the teams those roles were given on.
5. If no team was asked, any grant of that permission is enough.
6. If a team was asked, the grant's team must be that team or `*`.

Question-pool routes use `require("pools.something")`, which returns 401 when nobody is signed in and 403 when the signed-in person lacks the permission.

The browser mirrors the same rule in `can()` (`ui/web/src/lib/auth.ts`) so it can hide buttons. The mirror is a convenience. The route is the control.

---

## 8. What the UI shows each person

### Sidebar and home — same for everyone who is signed in

The sidebar always shows Dashboard, Shortlist, New interview, and Question pools. Home always shows the same three tiles. These do not read permissions.

So HR sees Question pools in the menu. Clicking it asks the server for the list, the server requires `pools.view`, and HR gets an error. An Author sees New interview even though scheduling is meant to be an HR permission, and that page does not check the permission.

This is the main unfinished UI piece.

### Question pools list

| Control | Who sees it |
|---|---|
| Approvals | Anyone with `pools.approve` anywhere (Checker, Admin). |
| New pool | Anyone with `pools.edit` anywhere (Author, Admin). |
| Edit, on a card | `pools.edit` on **that pool's team**. Otherwise the button says View. |
| Duplicate | `pools.edit` anywhere. The copy is new work of their own. |
| Delete a draft | `pools.edit` on that team. |
| Delete a published pool | `pools.publish` on that team (Admin). |
| YAML export | Shown on custom pools. The download route still requires `pools.view`. |
| Submit / Approve / Force publish | The workflow bar on the card. See below. |
| Built-in pools | View only. They ship in the image. Duplicate is how you get an editable copy, and that copy goes through review like any other draft. |

### Workflow bar on a pool

Buttons depend on the pool's **state** and the person's permission. The same pool looks different to the author and the checker.

| Button | Shown when |
|---|---|
| Submit | `pools.submit` on that team, the pool is not pending, and a draft file actually exists. |
| Withdraw | The pool is pending and **this person** submitted it. |
| Approve | `pools.approve` on that team, the pool is pending, and this person is not the submitter. |
| Force publish | `pools.publish` on that team, and a draft exists. |

A pool that was published before review existed can look like a draft in the ledger while having no draft file. Submit and force-publish stay hidden in that case, because there is nothing to send.

### Inside a pool

- An author who may edit that team gets a live form.
- A checker, and anyone else who can open it, gets the same form with every control disabled. They can read. They cannot type a change that would be saved.
- While permissions are still loading, the page waits. "Not loaded yet" is not treated as "this person is denied", or an author would briefly see a locked form.
- A built-in pool opens read-only and has no approval bar.

### Approvals queue

Only someone with `pools.approve` gets a useful page. The queue lists pending pools they are allowed to sign, with a **Review** action. Approving from the queue without reading the questions is no longer the primary button. The review screen is one row per question, plus **Approve all**.

---

## 9. What each role sees when they open the site

Today, after any successful sign-in, every person gets the same console. The left sidebar lists Dashboard, Shortlist, New interview, and Question pools. The bottom of the sidebar says "Signed in". The Welcome page shows three cards: Shortlist, AI Interview, and Question Pools. That is what we are changing. The pictures below are the pages we will show. A person with two grants sees the combination of those pages.

The pool screens already exist. The new pages are the Microsoft sign-in card, the no-role page, the no-access page, the filtered sidebar and Welcome page, and the Access area (People, Teams, the approval chain, and the role grid). Those are drawn under the role that opens them.

While permissions are still loading, the console shows "Loading…" and does not flash the full menu.

### The sign-in page

This is the page before any role matters. Production replaces the username and password form with one card, centered, same Centific mark as today:

- Title: **Sign in**
- One line: "Access the interview console."
- One button: **Sign in with Microsoft**

There is no username field and no password field. On a local test box the development chooser can still sit under a divider, labelled Development sign-in. A normal deployment does not show that divider.

After Microsoft accepts them, we look up the person. No role yet → the no-role page at the end of this section. A role → the console for that role. An inactive account stays on the sign-in card with "This account is turned off."

### The no-access page

Shared by every role. The sidebar stays, showing only that person's own menu, so they can still see who they are. The main area is one card:

- Title: **You don't have access to this page**
- One line: "Ask a platform administrator if you need it."
- One button: **Back to Welcome**

This is not the "Page not found" card. A URL that matches nothing still says the link does not match any page. A URL that matches a real page they are not allowed to open shows this card instead of an error toast after the API refuses them.

### Question Author

**What they can do.** On their own team: see pools and the built-in pools, create a pool, edit it, duplicate, upload material, delete a draft, submit it, and withdraw it while it is waiting. After a return, read the checker's comment on the rejected question and edit that draft.

**What they cannot do.** Approve anything, including their own pool. See another team's draft, its comments, or edit it. Force-publish. Delete a pool that is already live. Schedule interviews or open Shortlist, unless someone also gives them an interview role. A published pool from another team can still appear on the list, as View only.

**When they open the site.** The console is the left sidebar and the main area. The sidebar Workspace list has one item: **Question pools**. Dashboard, Shortlist, New interview, Approvals, and Access are not in the menu. Sign out stays at the bottom. Under their name the second line reads **Question Author · their team**, not "Signed in".

The first page is Welcome. The subtitle stays "Pick a workspace to get started." There is one card, **Question Pools**, with Open. The Shortlist and AI Interview cards are not there.

**Question pools, the page they work on.** Title "Question pools" and the existing subtitle. Top right has **New pool** only. There is no Approvals button and no Force publish.

Each card shows the pool name, a state pill (draft, pending, published), the question count, and topic pills. On their own team's pools the actions are **Edit**, **Duplicate**, **YAML**, and a delete icon on a draft. The workflow bar shows **Submit** when a draft exists, and **Withdraw** when they are the one who submitted it. After a checker sends questions back, the editor shows that checker's comment on the question it belongs to.

Built-in pools show **View** only. Another team's published pool also shows **View** only: no Edit, no Submit, no Delete, and no return comment. Another team's draft is missing from the list entirely.

**New pool and the editor.** The form is unlocked: name, description, team, and the questions. The team dropdown lists only the teams this person may author. Save writes a draft. The page does not offer Approve.

**Typing a hidden address.** `/dashboard`, `/shortlist`, `/schedule`, `/question-pools/approvals`, or `/access` shows the no-access page. The pool API already returns 403 for an action they cannot take.

### Question Checker

**What they can do.** On their own team: see pools, open the approvals queue, and review each question. Approve all is one click. A rejection needs a comment. A checker granted `*` can sign every team.

**What they cannot do.** Create or edit a pool on a team where they hold the checker grant. They are not also the author of that same team. Approve a pool they submitted or authored themselves. Sign a team their checker grant does not cover. If they are an author on a different team, they write pools there the same way any author does.

**When they open the site.** Same shell as an author. The sidebar has one Workspace item: **Question pools**. The name line reads **Question Checker · their team**, or **Question Checker · every team** when the grant is `*`. Welcome has the one Question Pools card.

**Question pools.** Top right has **Approvals** only. There is no New pool button. Cards for their team say **View**, not Edit. Duplicate and Delete are absent. YAML stays, because they can read the pool. The workflow bar shows **Approve** only on a pending pool they are allowed to sign, and it is absent on a pool they submitted themselves.

Opening a pool shows the same form an author uses, with every control disabled. The text stays readable. There is no Save.

**Approvals, already built.** Title "Approvals". Subtitle: pools waiting on them, not yet visible to a candidate. An empty queue is a card: "Nothing waiting". Each row is a pool they can actually sign, with **Review** as the action. Approving from the row without reading the questions is not the primary button.

**Review, already built.** Title "Review: {pool name}" and a line with the question count and the team. A sticky bar stays at the top: **Approve all**, a counter ("8 approved · 2 rejected · 1 undecided"), and **Submit review**. Each question is a card with the wording, Approve, and Reject. Reject opens a comment box: "What needs to change? The author sees only this." Nothing is sent until Submit review. Submit review stays disabled while any question is undecided or a rejection has no comment. There is no editing on this page.

**Typing a hidden address.** New pool, Dashboard, Shortlist, New interview, and Access show the no-access page.

### A person who is an author on one team and a checker on another

They see both jobs at once, and never both jobs on the same team.

The sidebar is still only **Question pools**, because neither grant is an interview grant or an admin grant. The name block has two lines: **Question Author · team A** and **Question Checker · team B**.

Welcome is still the one Question Pools card. On the pools page the top right shows **both** New pool and Approvals. A card on team A has Edit, Duplicate, and Submit. A card on team B has View and, when it is pending, Approve. The review screen is available for team B. The editor is unlocked only for team A.

### Admin

The Platform Admin grant is on `*` and holds every permission. On question pools that already works, on every team: create, edit, duplicate, delete a draft, submit, withdraw their own submission, review someone else's pool, force-publish, and delete a published pool. They cannot approve a pool they themselves submitted.

**When they open the site.** The sidebar Workspace list is the full set, plus the new item:

- Dashboard
- Shortlist
- New interview
- Question pools
- **Access**

Sign out stays at the bottom. The name line reads **Platform Admin**.

Welcome shows the three cards that exist today — Shortlist, AI Interview, Question Pools — and a fourth card, **Access**, described as "Assign roles and teams."

On Question pools they see both **New pool** and **Approvals**, on every team. A card also shows **Force publish** when a draft exists, and the delete icon on a published pool. The editor is unlocked. The review screen is the same one a checker uses.

Access is in the product. Sign-in is still the development chooser, not Microsoft. Opening Access lands on People. Three tabs sit under the title: **People**, **Teams**, **Roles**. The approval chain is not a fourth tab. It is the lower half of a team.

#### People

Title **Access**. Subtitle: "Who can use the platform, and on which team."

A search box for name or email, and a filter: All, No role, Active, Inactive.

The table columns are Name, Email, Status, Roles, Last sign-in. Status is a pill, Active or Inactive. Roles are pills in plain language, such as **Question Author · their team**. A person who has signed in and not been assigned anything shows a **No role** pill and an empty roles cell. There is no "create person" button. A colleague appears here the first time they sign in with Microsoft. The admin's job on this screen is to give them a role, not to type them in.

Clicking a row opens that person on the same page, beside the list on a wide window and below it on a narrow one:

- Name and email, not editable here. Microsoft owns those.
- An **Active** switch. Off means the next request is refused even if their cookie is still in the browser.
- The grants they hold, each on its own row: **Question Checker · their team**, with **Remove**.
- **Add a grant**: a Role dropdown (Platform Admin, Question Author, Question Checker, HR / Recruiter) and a Team dropdown (the real teams, plus Every team where that role is allowed to be global). **Add** writes the grant.

The dropdowns say the role and the team. They do not show a database id. **Add** stays disabled, with the line "A person is not both author and checker on the same team", when the new grant would do that. A Checker grant on every team is refused the same way if they already author any team. Remove and the Active switch are disabled on the last active Platform Admin, with the line "Someone has to be able to assign roles."

#### Teams

The same Access header, Teams tab selected.

Each row is a team: its name, its key, Active or Inactive, how many people, how many pools. **Every team** (`*`) is a row that cannot be renamed, deactivated, or deleted.

**New team** asks for a name. The key is filled in from the name and can be edited before the first save. After that the key stays put, because pools and grants store it.

Opening a team shows two blocks on one page.

The first block is the team itself: name (editable), Active switch, and Delete. Delete is absent while any person, pool, or approval step still points at the team, and the row says **In use**. Deactivate is the normal way to retire a team.

The second block is the approval chain. The default we test with is one step, signed by the Question Checker. The block is an ordered list. Each step shows its number, a name the admin can type (for example "Technical review"), and a role dropdown. **Add step**, move up, move down, and Remove. Saving checks that the numbers are 1, 2, 3 with no gaps, and that every step names a real role. If nobody active holds that role for this team, a warning sits on the step: "Nobody can sign this step yet." The save still works. A line under the list says "Pools already waiting keep the steps they started with."

#### Roles

The same Access header, Roles tab selected. There is no Add role button. The four roles stay fixed.

A grid. Rows are Platform Admin, Question Author, Question Checker, and HR / Recruiter. Columns are the eleven permissions, grouped under Pools, Interviews, and Access. Each cell is a checkbox. Ticking one changes what that role means for every person who holds it. There is no text box to invent a permission name. A line under the grid says "This changes the role for everyone who has it."

### HR

**What they can do.** Schedule interviews, cancel them, and read results. That is the job the `interviews.view`, `interviews.schedule`, and `interviews.cancel` permissions are for.

**What they cannot do.** Anything with question pools: no list, no edit, no submit, no approve, no force-publish.

**When they open the site.** The sidebar Workspace list is:

- Dashboard
- Shortlist
- New interview

Question pools and Access are not in the menu. The name line reads **HR / Recruiter**.

Welcome shows two cards: **Shortlist** and **AI Interview**. The Question Pools card is not there. There is no Access card. New interview is in the sidebar, which is where it lives today. The Shortlist, Dashboard, and New interview pages themselves stay as they are. We are not redesigning those screens. We are deciding who is allowed to open them.

**Typing a hidden address.** `/question-pools` or `/access` shows the no-access page. Today those addresses still open, and the Question pools API then returns 403. The menu must stop offering the page.

Dashboard, Shortlist, New interview, and Cancel still have to check `interviews.view`, `interviews.schedule`, and `interviews.cancel` on the server. Until that lands, an author who types the address can still schedule, and HR is only hidden from pools in the menu.

### A person with no role

This is the default after Microsoft sign-in. A company member can sign in, and we create their account, but we assign **no role** until an administrator does. They do not become an Author, a Checker, HR, or an Admin just because they work here.

**When they open the site.** There is no sidebar and no Welcome page. The whole window is one centered card, the same width as the sign-in card:

- Their name
- Their work email
- One line: "Your account does not have access yet. Ask a platform administrator to assign your role and team."
- One button: **Sign out**

No Dashboard, Shortlist, New interview, Question pools, or Access. No role name, because they do not have one. Refreshing the page stays on this card. The next sign-in after an admin assigns a role opens the console for that role.

That page is what we will build. It is not on the screen today. Right now a person with no role — including the shared admin login, which is not a person in the role system — still sees the full menu. The server refuses them only when they open Question pools.

---

## 10. Rules that are stricter than the permission alone

The permission gets you to the door. These rules still apply inside the room.

| Rule | What happens |
|---|---|
| Self-approval | The person who submitted cannot approve that submission. |
| Wrong team | A checker is refused if their grant does not cover the pool's team. |
| Signing twice | The same person cannot sign the same step twice in one cycle. |
| Every question | A review must say `approved` or `rejected` for every question. Anything else, including a blank, is refused and nothing is published. |
| Rejection comment | Every rejected question needs a comment. |
| Partial approval | Approved questions go live. Rejected ones stay as the draft and come back to the author. Rejecting an edit does not delete the previously published wording. |
| Nothing live before the last step | If a team has more than one approval step, an early step does not publish. The seeded chain has one step, so the first (only) approval can publish. |
| Draft privacy | `pools.view` is not enough to read another team's draft, review comments, or history. Authors and checkers of that team can. Anyone else gets 403. |
| Interviews read published only | A cadence can only pull questions from the published copy. An unapproved question cannot be asked, even by someone who can see the draft. |
| One transaction | Refusals run before any question is published. A failed or forbidden review leaves the pool pending and writes no verdicts. |

---

## 11. Where this lives in the code

| Piece | File |
|---|---|
| Permission names | `app/rbac.py` |
| Roles, grid, teams, seeded people, default chain | `app/rbac_seed.py` |
| "Does this person hold this, on this team?" | `has_permission` in `app/rbac.py` |
| Route guard | `require(...)` in `app/rbac.py` |
| Cookie, shared login | `app/auth.py`, `/api/login` and `/api/me` in `app/main.py` |
| Development chooser | `/api/dev/login`, `/api/dev/accounts` |
| What the UI is allowed to show | `GET /api/me/permissions`, `can()` in `ui/web/src/lib/auth.ts` |
| Pool routes and who may call them | `app/question_pool_routes.py` |
| Submit, review, return, publish, the refusals | `app/approval_service.py` |
| Draft versus published files | `app/question_pools.py` |
| Buttons on a pool | `ui/web/src/components/PoolWorkflow.tsx` |
| List, editor, review screen | `QuestionPools.tsx`, `QuestionPoolEditor.tsx`, `PoolReview.tsx`, `PoolApprovals.tsx` |
| Access screens | `app/access_service.py`, `app/access_routes.py`, `ui/web/src/pages/Access.tsx` |
| Which menu item a role sees | `ui/web/src/lib/workspace.ts` |

---

## 12. How access is changed today

An admin signs in with the development chooser and opens **Access**. People adds or removes a role on a team. Teams creates a team and edits its approval chain. Roles ticks what a role includes. The last Platform Admin cannot be removed. The same person cannot be author and checker on one team.

The seed still creates the starting teams, roles and test accounts when they are missing. The permission grid is inserted only when `app_role_permissions` is empty, so a restart does not put a removed permission back. The every-team chain starts as one step, signed by the Question Checker. A team with its own steps uses those instead.

---

## 13. How we finish it

This is the working implementation order, not a proposal.

1. **Company sign-in.** Microsoft Entra tells us the person. We match that identity to an `app_users` row. Door B goes away. Door A should stop being a way into the console.
2. **An admin screen for people, roles, and teams.** Built: Access → People, Teams, Roles. Sign-in is still the development chooser.
3. **A default for a new person: no role.** Built for a signed-in person who has no grant: name, email, one line, Sign out. A brand-new Microsoft user is not created yet, because Microsoft sign-in is not built.
4. **Menus that follow permissions.** Built. The sidebar and Welcome cards read `ui/web/src/lib/workspace.ts`. A typed address the person cannot open shows the no-access card. The interview APIs themselves still only check that someone is signed in.
5. **Interview routes that actually check `interviews.*`.** The page is hidden. The schedule, dashboard and shortlist APIs do not consult the permission yet.
6. **A screen for the approval chain.** Built, on the team in Access.
7. **Notifying a checker.** Work appears only when they open the approvals queue.

Maker-checker on question pools already runs against the seeded people. An admin can now say who is the author from Access, without editing the seed. What is still missing is Microsoft sign-in, so a new colleague does not appear on People until they have an `app_users` row.

### Step 1 — make every login a real person

Replace the shared username/password entry with Microsoft Entra sign-in.

The request flow will be:

1. The person clicks **Sign in with Microsoft**.
2. Microsoft authenticates them and sends the app a signed identity response.
3. The backend validates that response: issuer, tenant, audience, signature,
   nonce, and expiry.
4. The backend reads the stable Microsoft user id and work email.
5. It finds the matching `app_users` row.
6. If the account is inactive, refuse the login.
7. If the person is new, create an active user with **no role**.
8. Issue our existing signed session cookie with `uid=app_users.id`.
9. Every later permission check continues to use that local user id. Microsoft
   does not decide who is an Author or Checker.

The seeded development chooser stays available locally while this is built. It
should remain disabled in production.

### Step 2 — give a new person a safe landing page

A valid company identity is not automatically permission to use the platform.
Build the page described in "A person with no role" above: name, email, the
one line asking an administrator to assign a role and a team, and Sign out.
No sidebar. No role name. This is the default. We do not automatically make a
new employee HR, Author, Checker, or Admin.

### Step 3 — make the whole navigation permission-aware

Change the sidebar and Home tiles to read `/api/me/permissions`.

| Screen/menu item | Permission needed |
|---|---|
| Dashboard / interview results | `interviews.view` |
| Shortlist | `interviews.view` (or a separate shortlist permission later, if needed) |
| New interview | `interviews.schedule` |
| Question pools | Any `pools.*` permission, normally `pools.view` |
| Access administration | Any appropriate `admin.*` permission |

Directly typing a hidden URL must not work. Add a reusable frontend route guard
for a friendly message, but still enforce the same permission on the backend
route. The route guard is usability; the API guard is security.

The sidebar user block should show the real display name and useful role/team
text, such as **Question Author · their team**, rather than only “Signed in”.

### Step 4 — enforce interview permissions on the server

The permission names already exist. Add them to the routes that currently check
only for a valid cookie:

- list/details/results/downloads → `interviews.view`
- schedule/create/edit/approve interview → `interviews.schedule`
- cancel/delete a live interview → `interviews.cancel`
- Shortlist reads and writes need an explicit decision: reuse the interview
  permissions initially, or add `shortlist.view` / `shortlist.manage` if the
  people doing Shortlist work differ from interview schedulers.

Before adding the checks, build an endpoint inventory. A route is easy to miss,
and hiding its page does not secure it.

### Step 5 — build Access Administration

Add an **Access** area visible only to the required `admin.*` permissions.

#### People screen (`admin.users`)

List:

- display name and email
- active/inactive state
- last login
- current role and team grants

Actions:

- activate/deactivate
- add a role + team grant
- remove a grant

A grant editor should say **Question Checker on their team**, not expose database
ids. Prevent removing the final active Platform Admin. Refuse a grant that
would make the same person both author and checker on one team, including a
Checker grant on `*` while they already author any team.

#### Teams screen (`admin.teams`)

List and create teams. Do not allow deleting a team while users, pools, or
approval steps still reference it. Prefer deactivate/rename over destructive
delete.

#### Role-permission screen (`admin.permissions`)

Show the fixed permission vocabulary as a matrix. Editing the matrix changes
which permissions a role grants; it does not create arbitrary permission
strings.

The first version can keep the four system roles fixed. Creating custom roles
is not required to solve who is the Author or Checker.

### Step 6 — build Approval Chain administration

Inside a team's settings, show ordered steps:

1. Step number
2. Name, such as “Technical Review”
3. Required role, usually Question Checker

Allow add, reorder, and remove. Validate:

- step numbers are unique and contiguous
- every step names a real role
- at least one eligible active person can sign that team's step, or show a
  warning before saving
- changing the chain does not rewrite a submission already in progress; its
  cycle keeps the steps it opened with

### Step 7 — remove temporary authentication

After Microsoft sign-in and Access Administration are verified:

- turn off and then remove the shared admin login
- keep the development chooser behind `DEV_LOGIN_ENABLED`, local/test only
- make `/api/me` return the same named-person shape as
  `/api/me/permissions`, or merge them into one endpoint
- rotate `ADMIN_SECRET_KEY` if the cookie format or deployment environment
  changes

### Step 8 — add notifications

When an Author submits, notify the eligible Checker(s). When a Checker returns
questions, notify the Author. The permissions and team identify recipients;
the notification must not become a second source of truth for who may act.

The approvals queue remains authoritative even if an email is delayed or lost.

---

## 14. The finished user journeys

### First login

Microsoft sign-in → local user created with no role → access-pending screen →
Admin assigns a role and team → next refresh shows only the permitted workspace.

### Author

Microsoft sign-in → Question pools visible → creates a pool for their team →
saves → submits → waits → receives returned comments or sees the pool published.

### Checker

Microsoft sign-in → Question pools and Approvals visible → opens only pools for
their team → reads every question → Approve all, or approve/reject individually
with comments → submits the review.

### HR

Microsoft sign-in → Dashboard, Shortlist, and New interview visible → Question
pools absent → direct pool API request receives 403.

### Admin

Microsoft sign-in → all workspaces plus Access visible → assigns people to
roles/teams → configures chains → uses force-publish only as a recorded
break-glass action.

---

## 15. How we know it is complete

- A new Microsoft user gets no product access until a role is assigned.
- An Author sees authoring controls but no approval controls.
- A Checker sees the queue and review controls but cannot edit questions.
- HR cannot see or call any question-pool feature.
- A grant on one team never works on another team unless it is a `*` grant.
- The same person is never both author and checker on the same team. Author on
  one team and checker on a different team is allowed.
- A hidden screen is also refused by its API.
- Deactivating a person invalidates their effective permissions immediately,
  even if their cookie has not expired.
- Every publish, return, force-publish, role change, and chain change records
  the named person who did it.
- No production request can enter through the shared password or development
  chooser.
