# Sending interview invites by email

**A proposal. Nothing here is built yet.**

Today a recruiter copies each candidate's interview link and pastes it into an
email by hand. This is about sending it directly instead.

---

## The short version

| | |
|---|---|
| **Volume** | Up to ~2,000 interviews a day, so ~2,000–6,000 emails a day with reminders |
| **Recommended** | **Azure Communication Services** — built for this volume, ~$0.50/day |
| **Not recommended** | Microsoft Graph — free, but capped at ~30 messages/minute and throttling hits a real corporate mailbox |
| **Cost** | ~$15/month at 2,000 emails a day. The money is not the decision |
| **Effort** | ~2–3 developer days; the sending is the easy part |
| **Main risk** | **An interview link is a credential.** Automating the send removes the human who currently checks the address |

---

## 1. Why the per-email cost is not the decision

| Option | 1,000 emails | 2,000/day for a month |
|---|---|---|
| Microsoft Graph | $0 | $0 |
| Azure Communication Services | ~$0.25 | ~$15 |
| Amazon SES | ~$0.10 | ~$6 |
| SendGrid | $0 up to 100/day | ~$20+/month |

Every option is trivially cheap at our volume. Confirm current rates before
quoting them, but the choice is decided by **throughput, deliverability and blast
radius** — not price.

---

## 2. Microsoft Graph vs Azure Communication Services

**Microsoft Graph** is an API for acting **on behalf of a mailbox**. Mail goes out
through Exchange Online as a person or shared mailbox, appears in Sent Items, and
obeys Exchange's person-to-person limits. It is your work inbox, automated.

**Azure Communication Services (ACS)** is a **standalone sending service** —
Azure's equivalent of SendGrid or SES. No mailbox, no Exchange. Built for
application-generated mail at volume, priced per message, with delivery and
bounce events you can subscribe to. It is a mailroom, not an inbox.

| | Microsoft Graph | Azure Communication Services |
|---|---|---|
| Rate ceiling | **~30 messages/minute** per mailbox | Built for volume; quota raised on request |
| Daily cap | ~10,000 recipients per mailbox | Quota-based |
| 2,000 emails takes | **~67 minutes of continuous sending** | Minutes |
| Cost | $0 | ~$0.50/day |
| Domain setup | None — IT already did it | One-time SPF/DKIM verification |
| Bounce handling | Build it yourself | Built in, via events |
| **If throttled** | **A real corporate mailbox is rate-limited** | Isolated — business mail unaffected |

That last row is the deciding one. Exchange Online is designed for humans
emailing humans. Push bulk automated mail through it and the thing that gets
throttled or flagged is a **real corporate mailbox**, which can affect actual
business email — not just interview invites.

And 2,000 is the floor. Add reminders, completion notices and results to hiring
managers, and one interview becomes two or three emails: 4,000–6,000 a day, which
is *hours* of continuous sending at Graph's ceiling and over half the daily
mailbox cap.

**Recommendation: Azure Communication Services.** Still Azure-native, still one
vendor, still trivial money — and it is the tool built for this shape of load.

---

## 3. Drawbacks — of the feature, and of the choice

### Of automating the send at all

**An interview link is a credential.** Anyone holding
`/app/candidate?token=…` can sit that interview as that candidate.

Today a person copies the link into an email they are looking at, so there is a
human checking the address. Automating the send removes that check — and the
address we would send to is **extracted from the resume by an LLM**. It is
regularly wrong or missing; that is exactly why the platform already lets an
admin edit it before sending.

Send to a wrong-but-plausible address and a stranger can complete the interview
under that candidate's name, and the scorecard would look entirely normal.

**What we would do about it:**

- Confirm before sending, showing the exact addresses on screen
- Refuse to send to a blank or malformed address rather than skipping silently
- Record every send — to whom, when, by whom
- Expire the link, so a forwarded invite eventually stops working
- Surface bounces, so "they never got it" is visible rather than assumed

### Of choosing ACS

| Drawback | Detail |
|---|---|
| Domain verification needed | IT must add SPF and DKIM DNS records once. Using Azure's free subdomain instead works but looks unprofessional and lands in spam more often |
| Default quota is low | Must be raised by request before a 2,000/day run. **Do this well ahead of the first big day** |
| Replies go nowhere useful | A candidate replying to an automated sender needs a reply-to address that a human actually reads |
| Another Azure resource | One more thing to provision, monitor and pay for, however little |

### Of choosing Graph instead

| Drawback | Detail |
|---|---|
| ~30 messages/minute | 2,000 emails is over an hour of continuous sending |
| Throttling hits a corporate mailbox | Consequences reach beyond this platform |
| Not designed for bulk | Microsoft's own guidance points volume sending elsewhere |
| Bounce handling is manual | Nothing tells you an invite failed |

**One thing to avoid either way:** do not build on **SMTP AUTH** with Microsoft
365. It is on a deprecation path.

---

## 4. What we would build

The sending itself is small. The work around it is the real cost.

| Piece | What it is |
|---|---|
| A send job | One handler on the existing worker tier |
| Templates | Invite, reminder, and "interview complete" — plain text and HTML |
| Confirm-before-send | Shows exactly who each email is going to |
| Bounce handling | Subscribe to delivery events; mark an invite as failed |
| Send record | Who was sent what, when, and by whom |

**The infrastructure already exists.** [app/jobs/jobs.py](../app/jobs/jobs.py)
names `invite_dispatch` as a planned job type, and the worker tier already
provides **retries and dead-lettering** — so a transient failure retries itself
instead of silently losing an invite. There is no email code in the repository
yet, so this is a clean addition rather than a rework.

Estimated **2–3 developer days**, most of it the confirm, audit and bounce work.

---

## 5. What we need from IT

| # | Request |
|---|---|
| 1 | An **Azure Communication Services** resource with Email enabled |
| 2 | A **verified sending domain** — SPF and DKIM DNS records for e.g. `interviews.centific.com` |
| 3 | The **from address** and a **reply-to** address a human monitors |
| 4 | A **quota increase** to cover peak day volume, requested ahead of time |

If the decision goes to Graph instead, the ask changes to `Mail.Send` on the
Entra app registration in the access-control proposal, plus a shared mailbox to
send from.

---

## 6. The open question

**Which address does mail come from?**

- A **shared address** (`interviews@centific.com`) — simpler, survives someone
  leaving, and the obvious choice for automated invites.
- **The recruiter's own address** — better reply rates, but needs per-user
  permission and breaks when they leave.

This changes what we ask IT for, so it is worth settling before the ticket goes
in.

---

## 7. A caveat worth raising alongside this

Email at 2,000 a day is the easy part. 2,000 interviews spread over eight hours
is roughly **four starting every minute**, and at ~38 minutes each that is about
**160 concurrent live interviews**.

Each one holds a speech stream for the AI's listening and speaking, and the
platform's own admission setting caps that at **5 streams per key** by default —
so 160 concurrent implies roughly **32 speech keys**, unless the real per-key
limit is higher than the conservative default currently configured.

Email costs about fifteen dollars a month and two days of work. **Sustaining 160
concurrent interviews is the real engineering question**, and it decides whether
2,000 a day is achievable at all. Worth confirming before committing to that
number.
