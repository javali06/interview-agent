"""Shared database layer — one SQLAlchemy engine + schema for the whole product.

Public surface:
    from db import engine            # engine/session helpers
    from db.engine import session_scope, get_engine, create_all, database_url
    from db.models import Role, Candidate, JobDescription, Score, ScoreDimension, InterviewSession

Local dev defaults to the existing SQLite file (<SESSIONS_DIR>/sessions.db);
set DATABASE_URL to point everything at Postgres.
"""
from db.engine import (
    Base,
    JSONType,
    UUIDType,
    create_all,
    database_url,
    get_engine,
    get_sessionmaker,
    reset_engine,
    session_scope,
)

__all__ = [
    "Base",
    "JSONType",
    "UUIDType",
    "create_all",
    "database_url",
    "get_engine",
    "get_sessionmaker",
    "reset_engine",
    "session_scope",
]
