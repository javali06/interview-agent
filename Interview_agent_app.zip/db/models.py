"""Shared ORM models — one schema for the whole product.

Relational shape:

    roles ──< candidates ──< scores >── job_descriptions
                  │              └──< score_dimensions
                  └──< interview_sessions

- candidates / job_descriptions / scores / score_dimensions: lifted verbatim
  from the resume_scorer branch (the Shortlist feature).
- roles: the "create a role" landing-page entity that both features hang off.
- interview_sessions: the admin app's existing `sessions` table, moved onto
  SQLAlchemy UNCHANGED (same column names/types) so an existing sessions.db
  keeps working under create_all(). The role_id / candidate_id FKs that link
  an interview to the Shortlist come in a follow-up Alembic migration (adding
  columns needs ALTER TABLE, which create_all can't do).
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone


def _now_iso() -> str:
    """UTC ISO-8601 timestamp string. Matches app.db.now_iso so observer
    notes sort consistently against the TEXT-timestamp sessions table."""
    return datetime.now(timezone.utc).isoformat()

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
    func,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from db.engine import Base, JSONType, UUIDType


# ── Shortlist domain (from resume_scorer) ─────────────────────────────


class Role(Base):
    """A job opening. Created on the landing page; both Shortlist and
    Interview reference it. Deliberately lightweight; the JD text lives here
    so a role is self-contained."""

    __tablename__ = "roles"

    id: Mapped[int] = mapped_column(primary_key=True)
    public_id: Mapped[uuid.UUID] = mapped_column(
        UUIDType, default=uuid.uuid4, unique=True, index=True
    )
    title: Mapped[str] = mapped_column(String(255))
    jd_text: Mapped[str] = mapped_column(Text, default="")
    # Match score (0..100) at/above which a candidate is a "fit" for this role.
    threshold: Mapped[float] = mapped_column(Float, default=70.0, server_default="70.0")
    status: Mapped[str] = mapped_column(String(32), default="open", index=True)  # open|closed
    # Token of the role's CADENCE TEMPLATE — a session row (status='template')
    # that never runs and exists only to hold the interview plan + evaluation
    # plugins every candidate for this role will get. Deliberately a real
    # session: the cadence editor, the "Revise with AI" agents and the eval
    # plugin panel are all session-token-keyed, so the template reuses every one
    # of them unchanged instead of growing a parallel role-scoped copy.
    template_token: Mapped[str | None] = mapped_column(String, nullable=True)
    # voice (spoken) or text (typed chat). A property of the ROLE, not of each
    # interview: every candidate for a role takes the same interview, so the
    # mode is chosen once when the role is created and inherited by the cadence
    # template and by every interview made from it.
    modality: Mapped[str] = mapped_column(String(16), default="voice", nullable=False)
    created_by: Mapped[str] = mapped_column(String(255), default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )


class Candidate(Base):
    """One row per person, deduped by email."""

    __tablename__ = "candidates"

    id: Mapped[int] = mapped_column(primary_key=True)
    public_id: Mapped[uuid.UUID] = mapped_column(
        UUIDType, default=uuid.uuid4, unique=True, index=True
    )
    name: Mapped[str] = mapped_column(String(255), default="")
    email: Mapped[str] = mapped_column(String(320), default="", index=True)
    phone: Mapped[str] = mapped_column(String(64), default="")
    # Stored resume (so a matched candidate can be sent straight to interview
    # without re-uploading). resume_path is relative to SESSIONS_DIR.
    resume_path: Mapped[str] = mapped_column(String(512), default="", server_default="")
    resume_text: Mapped[str] = mapped_column(Text, default="", server_default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    scores: Mapped[list["Score"]] = relationship(back_populates="candidate")


class JobDescription(Base):
    """A JD stored once, deduped by content hash."""

    __tablename__ = "job_descriptions"

    id: Mapped[int] = mapped_column(primary_key=True)
    content_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    text: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    scores: Mapped[list["Score"]] = relationship(back_populates="job_description")


class Score(Base):
    """One resume→role scoring run."""

    __tablename__ = "scores"

    id: Mapped[int] = mapped_column(primary_key=True)
    candidate_id: Mapped[int] = mapped_column(ForeignKey("candidates.id"), index=True)
    job_description_id: Mapped[int | None] = mapped_column(
        ForeignKey("job_descriptions.id"), nullable=True
    )
    # Ties this score to a specific role (the role-centric Shortlist). Nullable
    # so the legacy text-paste scorer (no role) still works.
    role_id: Mapped[int | None] = mapped_column(
        ForeignKey("roles.id"), nullable=True, index=True
    )

    final_score: Mapped[float] = mapped_column(Float)
    llm_score: Mapped[float] = mapped_column(Float)
    coverage_score: Mapped[float] = mapped_column(Float)
    recommendation: Mapped[str] = mapped_column(String(64), default="")
    model: Mapped[str] = mapped_column(String(128), default="")
    source: Mapped[str | None] = mapped_column(String(512), nullable=True)

    weights: Mapped[dict] = mapped_column(JSONType, default=dict)
    coverage: Mapped[dict] = mapped_column(JSONType, default=dict)
    result: Mapped[dict] = mapped_column(JSONType)  # full ScoreResponse, lossless

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    candidate: Mapped[Candidate] = relationship(back_populates="scores")
    job_description: Mapped[JobDescription | None] = relationship(back_populates="scores")
    dimensions: Mapped[list["ScoreDimension"]] = relationship(
        back_populates="score_row", cascade="all, delete-orphan"
    )

    __table_args__ = (
        Index("idx_scores_created_at", "created_at"),
        Index("idx_scores_final_score", "final_score"),
        Index("idx_scores_candidate_created", "candidate_id", "created_at"),
    )


class ScoreDimension(Base):
    """A single LLM-evaluated dimension of a score (normalized for analytics)."""

    __tablename__ = "score_dimensions"

    id: Mapped[int] = mapped_column(primary_key=True)
    score_id: Mapped[int] = mapped_column(
        ForeignKey("scores.id", ondelete="CASCADE"), index=True
    )
    name: Mapped[str] = mapped_column(String(128))
    score: Mapped[float] = mapped_column(Float)
    rationale: Mapped[str] = mapped_column(Text, default="")

    score_row: Mapped[Score] = relationship(back_populates="dimensions")


# ── Interview domain (admin's existing sessions table, unchanged) ──────


class InterviewSession(Base):
    """The admin app's scheduled-interview row. Columns mirror the original
    raw-sqlite3 `sessions` table EXACTLY (TEXT timestamps, optional ports) so
    an existing sessions.db is compatible under create_all(). admin/db.py
    reads/writes this via Core, returning plain dicts for back-compat.

    NOTE: role_id / candidate_id FKs (linking an interview to a Shortlist
    candidate) are intentionally NOT here yet — they arrive via an Alembic
    migration so existing rows get ALTER TABLE'd rather than orphaned."""

    __tablename__ = "sessions"

    token: Mapped[str] = mapped_column(String, primary_key=True)
    candidate_name: Mapped[str] = mapped_column(String, nullable=False)
    role: Mapped[str] = mapped_column(String, nullable=False)
    jd_path: Mapped[str | None] = mapped_column(String, nullable=True)
    jd_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    resume_path: Mapped[str] = mapped_column(String, nullable=False)
    cadence_requirements_path: Mapped[str | None] = mapped_column(String, nullable=True)
    cadence_requirements_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    cadence_yaml: Mapped[str] = mapped_column(Text, nullable=False)
    status: Mapped[str] = mapped_column(String, nullable=False, index=True)
    pid: Mapped[int | None] = mapped_column(Integer, nullable=True)
    ws_port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    http_port: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[str] = mapped_column(String, nullable=False, index=True)
    started_at: Mapped[str | None] = mapped_column(String, nullable=True)
    ended_at: Mapped[str | None] = mapped_column(String, nullable=True)
    event_log_path: Mapped[str | None] = mapped_column(String, nullable=True)
    # When True the candidate UI records camera+mic and screen during the
    # interview and uploads the webm tracks to blob for post-hoc fraud review.
    # Added after the initial table create → also listed in db/engine.py's
    # additive-migration table so existing Postgres rows gain the column.
    # Default True (opt-out, not opt-in) — set once at schedule time and
    # immutable after creation; see app.sessions.update_draft.
    record_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    # Interview modality, admin-set at schedule time and immutable after
    # creation (mirrors record_enabled). "voice" = the live spoken interview
    # (today's default); "text" = the typed/chat interview (question-driven,
    # untimed — see CadencePlan.timed). Drives which tier the session runs on
    # (voice → pinned session shard; text → the stateless text tier) and how
    # the cadence is generated/edited. Added after the initial table create →
    # also in db/engine.py's additive-migration table. Default "voice" so
    # existing rows and the whole voice path are unaffected.
    modality: Mapped[str] = mapped_column(String, default="voice", nullable=False)
    # True for a ROLE CADENCE TEMPLATE: a session that exists only to hold the
    # interview plan + evaluation plugins every candidate for a role will get,
    # and is never run. It is a session on purpose — the cadence editor, the
    # revise-with-AI agents and the eval plugin panel are all session-token-keyed,
    # so a template reuses them unchanged. Status therefore flows normally
    # (generating → draft → ready), and THIS flag is what keeps it out of every
    # interview list and count. Added after the initial table create → also in
    # db/engine.py's additive-migration table.
    is_template: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    # The Shortlist role this interview was created for, when it came from one.
    # `role` above is the role's TITLE as free text — it repeats and is edited,
    # so it cannot answer "which interviews belong to this role". This can, and
    # it is what the role's Sourcing/Interviewing state is derived from.
    role_public_id: Mapped[str | None] = mapped_column(String, nullable=True, index=True)
    # The Shortlist candidate this interview is for, when it came from one. The
    # candidate row owns the email the link gets sent to, and `candidate_name`
    # here is only a display copy — this is what makes the email editable from
    # the interview screens without guessing who the person is.
    candidate_public_id: Mapped[str | None] = mapped_column(String, nullable=True, index=True)
    # Candidate's email for interviews NOT created from a Shortlist candidate
    # (candidate_public_id is None) — used to send the interview link
    # automatically (app/notifications). Optional (nullable): older rows
    # predate this column, and an admin can still copy-paste the link
    # manually if it's left blank. Mutable, unlike record_enabled/modality —
    # a typo'd email is just a data-entry fix, not an immutable interview
    # setting. Added after the initial table create → also in db/engine.py's
    # additive-migration table.
    candidate_email: Mapped[str | None] = mapped_column(String(320), nullable=True)


# ── Observer scorecard / notes ─────────────────────────────────────────


class ObserverNote(Base):
    """A single note or competency rating jotted by a live observer (TA)
    during an interview. Mirrors the lightweight TEXT-timestamp style of the
    sessions table so it slots into the same SQLite/Postgres schema cleanly."""

    __tablename__ = "observer_notes"

    id: Mapped[int] = mapped_column(primary_key=True)
    session_token: Mapped[str] = mapped_column(String, nullable=False, index=True)
    created_at: Mapped[str] = mapped_column(String, nullable=False, default=_now_iso)
    author: Mapped[str] = mapped_column(String, nullable=False, default="")
    kind: Mapped[str] = mapped_column(String, nullable=False, default="note")  # note|rating
    text: Mapped[str] = mapped_column(Text, nullable=False, default="")
    competency: Mapped[str | None] = mapped_column(String, nullable=True)
    score: Mapped[int | None] = mapped_column(Integer, nullable=True)


# ── Async worker tier ──────────────────────────────────────────────────


class Job(Base):
    """A unit of background work run by the worker tier, off the web request
    path (cadence-gen, rubric-gen, shortlist scoring, eval-v2, recording
    finalize, webhook, bulk export, invite dispatch).

    The durable *queue* is Azure Storage Queue; THIS table is the durable
    STATUS the gateway polls to answer "is my draft's cadence ready yet?".
    A message on the queue references a job row by id; the worker flips the
    status as it runs. TEXT-timestamp style matches the sessions table since
    most jobs correlate to a session token."""

    __tablename__ = "jobs"

    # uuid4 hex, minted at enqueue; also the queue message's correlation id.
    id: Mapped[str] = mapped_column(String, primary_key=True)
    type: Mapped[str] = mapped_column(String, nullable=False)  # cadence_gen | eval_v2 | ...
    # queued | running | succeeded | failed | dead (dead-lettered after retries)
    status: Mapped[str] = mapped_column(String, nullable=False, default="queued", index=True)
    # Optional session correlation so the gateway can look up a token's jobs.
    token: Mapped[str | None] = mapped_column(String, nullable=True, index=True)
    payload: Mapped[dict] = mapped_column(JSONType, default=dict)   # job input
    result: Mapped[dict | None] = mapped_column(JSONType, nullable=True)  # job output/summary
    error: Mapped[str | None] = mapped_column(Text, nullable=True)  # last failure detail
    attempts: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[str] = mapped_column(String, nullable=False, default=_now_iso, index=True)
    updated_at: Mapped[str] = mapped_column(String, nullable=False, default=_now_iso)
    started_at: Mapped[str | None] = mapped_column(String, nullable=True)
    finished_at: Mapped[str | None] = mapped_column(String, nullable=True)

    __table_args__ = (
        Index("idx_jobs_type_status", "type", "status"),
    )


# ── Human review of an LLM evaluation ──────────────────────────────────


class EvaluationReview(Base):
    """One append-only correction a human made to the LLM's evaluation.

    APPEND-ONLY BY DESIGN: changing your mind writes a new row that supersedes
    the old one, never an UPDATE. "The AI said 4 and a recruiter raised it to 8"
    is the auditable truth, and it is also one labelled example of where the
    model is wrong — an in-place edit destroys both.

    A TABLE rather than a file in sessions/<token>/ because the useful question
    is cross-session ("how far off is role_fit across 200 interviews?"), which a
    per-session file can only answer by scanning every session directory.

    TEXT timestamps match the sessions/jobs tables so everything correlating to
    a token sorts consistently."""

    __tablename__ = "evaluation_reviews"

    record_id: Mapped[str] = mapped_column(String, primary_key=True)
    token: Mapped[str] = mapped_column(String, nullable=False, index=True)
    segment_id: Mapped[str] = mapped_column(String, nullable=False)
    section: Mapped[str] = mapped_column(String, nullable=False)
    # NULL = the section's total; otherwise the breakdown line that moved.
    item_label: Mapped[str | None] = mapped_column(String, nullable=True)
    kind: Mapped[str] = mapped_column(String, nullable=False)  # mark|state|note

    # Frozen at review time — what makes a stale correction detectable after a
    # regenerate rewrites the AI's values.
    ai_value: Mapped[float | None] = mapped_column(Float, nullable=True)
    human_value: Mapped[float | None] = mapped_column(Float, nullable=True)
    ai_state: Mapped[str | None] = mapped_column(String, nullable=True)
    human_state: Mapped[str | None] = mapped_column(String, nullable=True)
    body: Mapped[str] = mapped_column(Text, nullable=False, default="")

    # ai_misread | rubric_wrong | evidence_missing | calibration | other.
    # Mandatory: each value routes to a different fix, and a free-text reason
    # with no kind is readable but not aggregatable.
    reason_kind: Mapped[str] = mapped_column(String, nullable=False)
    reason: Mapped[str] = mapped_column(Text, nullable=False, default="")

    reviewer: Mapped[str] = mapped_column(String, nullable=False, default="")
    created_at: Mapped[str] = mapped_column(String, nullable=False, default=_now_iso, index=True)
    evaluation_generated_at: Mapped[str] = mapped_column(String, nullable=False, default="")
    ai_rationale: Mapped[str] = mapped_column(Text, nullable=False, default="")

    status: Mapped[str] = mapped_column(String, nullable=False, default="active")
    supersedes: Mapped[str | None] = mapped_column(String, nullable=True)

    __table_args__ = (
        Index("idx_reviews_token_status", "token", "status"),
        # The learning-loop index: "mean human-AI delta on role_fit across every
        # interview" is one indexed query instead of a scan.
        Index("idx_reviews_target", "section", "item_label", "status"),
    )


# -- Access control (RBAC) -------------------------------------------------
#
# Design notes live in docs/question-pool-maker-checker.md. The two a reader of
# this file needs:
#
# 1. The `roles` table above is a JOB OPENING. These are `app_roles` -- what a
#    PERSON may do. Never conflate them.
# 2. "All teams" is a real seeded row (`AppTeam.key == "*"`), not a NULL
#    team_id. A composite primary key cannot hold NULL, and UNIQUE treats NULLs
#    as distinct on both SQLite and Postgres -- so NULL-as-global would
#    silently permit duplicate grants. A real row keeps the PK clean, the FK
#    intact, and renders as "All teams" with no special case.


class AppTeam(Base):
    """A scope for a role grant. Seeded with the `*` row plus the real teams."""

    __tablename__ = "app_teams"

    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255), default="")
    # True only for the `*` row, so the admin UI can refuse to delete it.
    is_system: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class AppUser(Base):
    """One row per person who may sign in.

    `entra_oid` is NULLABLE on purpose: every account is seeded locally today
    (app/rbac_seed.py), so the whole feature is buildable and testable with no
    dependency on an Entra app registration. When Microsoft sign-in lands a
    person is matched by email once and the oid stamped on; from then on the
    oid is the identity, because people change their email and the oid does
    not.
    """

    __tablename__ = "app_users"

    id: Mapped[int] = mapped_column(primary_key=True)
    entra_oid: Mapped[str | None] = mapped_column(String(64), unique=True, nullable=True)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    display_name: Mapped[str] = mapped_column(String(255), default="")
    # Local off-switch. The real one, once Entra lands, is IT disabling the
    # work account -- that stops sign-in at the door.
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    last_login_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class AppRole(Base):
    """A persona: admin | pool_author | pool_checker | hr."""

    __tablename__ = "app_roles"

    id: Mapped[int] = mapped_column(primary_key=True)
    key: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(255), default="")
    description: Mapped[str] = mapped_column(Text, default="")
    # True for `admin`, so nobody can delete the role that grants the
    # permission to fix mistakes.
    is_system: Mapped[bool] = mapped_column(Boolean, default=False, server_default="false")
    # "global" | "team" -- whether granting it per-team is meaningful. Granting
    # `admin` to one team is not, so the admin UI refuses it rather than storing
    # a grant that silently does nothing.
    scope_kind: Mapped[str] = mapped_column(String(16), default="team", server_default="team")


class AppUserRole(Base):
    """The grant: this person holds this role, for this team.

    A team_id pointing at the `*` team means every team.
    """

    __tablename__ = "app_user_roles"

    user_id: Mapped[int] = mapped_column(ForeignKey("app_users.id"), primary_key=True)
    role_id: Mapped[int] = mapped_column(ForeignKey("app_roles.id"), primary_key=True)
    team_id: Mapped[int] = mapped_column(ForeignKey("app_teams.id"), primary_key=True)
    granted_by: Mapped[int | None] = mapped_column(ForeignKey("app_users.id"), nullable=True)
    granted_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())


class AppRolePermission(Base):
    """The grid, as rows. THIS is what makes the system dynamic: changing what a
    role can do is an UPDATE here, not a deployment.

    `permission` is validated against the closed vocabulary in app/rbac.py on
    the way in, so the admin screen cannot invent one that grants nothing.
    """

    __tablename__ = "app_role_permissions"

    role_id: Mapped[int] = mapped_column(ForeignKey("app_roles.id"), primary_key=True)
    permission: Mapped[str] = mapped_column(String(64), primary_key=True)


class AppApprovalStep(Base):
    """One step of a team's approval chain.

    A team with no rows of its own falls back to the `*` team's chain, seeded
    with a SINGLE step -- so one approval is the default, and a second level is
    a row rather than a code change.
    """

    __tablename__ = "app_approval_steps"

    id: Mapped[int] = mapped_column(primary_key=True)
    team_id: Mapped[int] = mapped_column(ForeignKey("app_teams.id"), index=True)
    step_no: Mapped[int] = mapped_column(Integer)
    approver_role_id: Mapped[int] = mapped_column(ForeignKey("app_roles.id"))
    name: Mapped[str] = mapped_column(String(255), default="")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, server_default="true")

    __table_args__ = (UniqueConstraint("team_id", "step_no", name="uq_step_per_team"),)


class PoolApproval(Base):
    """The maker-checker ledger. APPEND-ONLY -- never updated, never deleted.

    A pool's current state is DERIVED from these rows rather than stored, so a
    status column and a history can never disagree about what is true.

    `cycle_id` groups one submit-to-decision round. Without it, "which approvals
    count toward the current submission" is a timestamp comparison against the
    latest `submitted` row -- fragile, and ambiguous the moment two events share
    a second.

    `chain_snapshot` is set only on `submitted` rows and records the steps the
    cycle is judged against. An admin editing a team's chain therefore cannot
    publish a live pool by accident: without it, deleting a pending step makes
    the derivation find no unsigned steps and silently publish.
    """

    __tablename__ = "pool_approvals"

    id: Mapped[int] = mapped_column(primary_key=True)
    pool_id: Mapped[str] = mapped_column(String(80), index=True)
    team_id: Mapped[int] = mapped_column(ForeignKey("app_teams.id"))
    cycle_id: Mapped[str] = mapped_column(String(36), index=True)
    # submitted | approved | returned | published | withdrawn
    action: Mapped[str] = mapped_column(String(16))
    step_no: Mapped[int | None] = mapped_column(Integer, nullable=True)
    chain_snapshot: Mapped[dict | None] = mapped_column(JSONType, nullable=True)
    actor_user_id: Mapped[int] = mapped_column(ForeignKey("app_users.id"))
    comment: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), index=True
    )

    __table_args__ = (Index("idx_pool_approvals_pool_cycle", "pool_id", "cycle_id"),)


class PoolQuestionReview(Base):
    """One checker's verdict on ONE question, inside one approval cycle.

    Separate from `pool_approvals` because the grain differs: that ledger
    records what happened to the POOL (submitted, approved, returned), while a
    review is per question. Keeping them apart means the pool's state is still
    derived from one place and cannot be contradicted by question rows.

    Append-only, like the rest of the ledger: a checker changing their mind
    writes a new row, and the latest row per (cycle, question) wins. That keeps
    "what did the reviewer think at the time" answerable later.
    """

    __tablename__ = "pool_question_reviews"

    id: Mapped[int] = mapped_column(primary_key=True)
    pool_id: Mapped[str] = mapped_column(String(80), index=True)
    cycle_id: Mapped[str] = mapped_column(String(36), index=True)
    question_id: Mapped[str] = mapped_column(String(80))
    # approved | rejected
    verdict: Mapped[str] = mapped_column(String(16))
    # Why it was rejected. The author reads this, so it is the whole point of a
    # rejection -- "no" without a reason sends them guessing.
    comment: Mapped[str] = mapped_column(Text, default="")
    actor_user_id: Mapped[int] = mapped_column(ForeignKey("app_users.id"))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), index=True
    )

    __table_args__ = (
        Index("idx_pool_q_reviews_cycle", "pool_id", "cycle_id", "question_id"),
    )


class AuditLog(Base):
    """Consequential acts outside the pool workflow: a role granted, a
    permission changed, a team created. Append-only, and the thing an auditor
    asks for.
    """

    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(primary_key=True)
    # NULL = the system did it (a seed, a migration).
    actor_user_id: Mapped[int | None] = mapped_column(ForeignKey("app_users.id"), nullable=True)
    action: Mapped[str] = mapped_column(String(64), index=True)
    target_type: Mapped[str] = mapped_column(String(32), default="")
    target_id: Mapped[str] = mapped_column(String(80), default="")
    detail: Mapped[dict | None] = mapped_column(JSONType, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), index=True
    )
