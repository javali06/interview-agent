"""Shared SQLAlchemy engine, declarative Base, and portable column types.

ONE database for the whole product (interview sessions + shortlist scoring +
roles/candidates). Lifted from the resume_scorer branch's database.py and
adapted to this repo's conventions:

- URL comes from the ``DATABASE_URL`` env var. When unset it defaults to the
  SAME local SQLite file the admin app has always used
  (``<SESSIONS_DIR>/sessions.db``) so nothing changes for local dev / an
  existing deployment until you deliberately point ``DATABASE_URL`` at
  Postgres.
- Portable JSON / UUID types: native JSONB / UUID on Postgres, generic
  fallbacks (JSON-as-text, CHAR(32)) on SQLite — the same model classes run
  on either backend.
- The engine is built lazily so importing this module never opens a
  connection (safe for tooling / tests). ``reset_engine(url)`` repoints it
  (used by tests).

Cloud cutover is a one-liner: set ``DATABASE_URL=postgresql+psycopg://…`` as
an App Setting. See docs/azure-postgres-networking (Private endpoint / TLS).
"""
from __future__ import annotations

import os
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from sqlalchemy import JSON, Uuid, create_engine, event, inspect
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

_REPO_ROOT = Path(__file__).resolve().parent.parent


def _default_sqlite_url() -> str:
    """The existing admin DB path, so an existing sessions.db keeps working
    when DATABASE_URL is unset. Mirrors admin.paths.SESSIONS_DIR exactly."""
    sessions_dir = Path(os.environ.get("SESSIONS_DIR", str(_REPO_ROOT / "sessions")))
    return f"sqlite:///{sessions_dir / 'sessions.db'}"


def database_url() -> str:
    """Resolved SQLAlchemy URL: DATABASE_URL env, else the local SQLite file."""
    return (os.environ.get("DATABASE_URL") or "").strip() or _default_sqlite_url()


# Portable column types — use these in the ORM models so one class set runs
# on both backends.
JSONType = JSON().with_variant(JSONB(), "postgresql")
UUIDType = Uuid(as_uuid=True)  # native uuid on Postgres, CHAR(32) elsewhere


class Base(DeclarativeBase):
    pass


_engine = None
_SessionLocal: "sessionmaker[Session] | None" = None


def _build(url: str):
    # check_same_thread=False lets SQLite be shared across FastAPI's threadpool
    # AND across the admin web process + the orchestrator subprocess (both go
    # through this layer). WAL (set below) makes that concurrency safe. Both
    # ignored by non-SQLite dialects.
    is_sqlite = url.startswith("sqlite")
    connect_args = {"check_same_thread": False} if is_sqlite else {}
    kwargs = dict(pool_pre_ping=True, future=True, connect_args=connect_args)
    if not is_sqlite:
        # Tiered deploy: many stateless gateway/worker replicas share ONE
        # Postgres. Cap each replica's pool so the fleet stays inside the
        # server's max_connections (Flexible Server Burstable tiers are small,
        # e.g. B1ms ~ 35). Env-tunable per tier with no redeploy.
        kwargs["pool_size"] = int(os.environ.get("DB_POOL_SIZE", "5"))
        kwargs["max_overflow"] = int(os.environ.get("DB_MAX_OVERFLOW", "10"))
        kwargs["pool_recycle"] = int(os.environ.get("DB_POOL_RECYCLE_S", "1800"))
    engine = create_engine(url, **kwargs)
    if is_sqlite:
        # Cross-process reader/writer safety on the shared file (parity with
        # the old raw-sqlite3 layer, which set WAL explicitly).
        @event.listens_for(engine, "connect")
        def _set_sqlite_pragma(dbapi_conn, _rec):  # pragma: no cover - trivial
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA journal_mode=WAL;")
            cur.execute("PRAGMA foreign_keys=ON;")
            cur.close()
    return engine, sessionmaker(bind=engine, expire_on_commit=False, future=True)


def reset_engine(url: str | None = None) -> None:
    """(Re)build the engine + session factory. Disposes any previous engine."""
    global _engine, _SessionLocal
    if _engine is not None:
        _engine.dispose()
    _engine, _SessionLocal = _build(url or database_url())


def get_engine():
    if _engine is None:
        reset_engine()
    return _engine


def get_sessionmaker() -> "sessionmaker[Session]":
    if _SessionLocal is None:
        reset_engine()
    assert _SessionLocal is not None
    return _SessionLocal


@contextmanager
def session_scope() -> Iterator[Session]:
    """Transactional ORM session: commit on success, rollback on error."""
    session = get_sessionmaker()()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


# Columns added after the initial table create. create_all() does NOT alter
# existing tables, so for a DB whose tables predate these we ADD COLUMN them.
# Idempotent + works on SQLite and Postgres. (Alembic owns this once it lands;
# this keeps the demo schema evolving without a full migration chain yet.)
_ADDED_COLUMNS = [
    ("roles", "threshold", "FLOAT", "70.0"),
    ("scores", "role_id", "INTEGER", None),
    ("candidates", "resume_path", "VARCHAR(512)", "''"),
    ("candidates", "resume_text", "TEXT", "''"),
    # Recording opt-in flag on the existing sessions table (candidate
    # camera+mic / screen capture → blob). Existing Postgres rows predate
    # this column, so ADD COLUMN it with a False default.
    ("sessions", "record_enabled", "BOOLEAN", "false"),
    # Interview modality (voice|text). Existing Postgres rows predate this
    # column → ADD COLUMN with a 'voice' default so they stay voice interviews.
    ("sessions", "modality", "VARCHAR(16)", "'voice'"),
    # The role's cadence-template session. Existing roles predate it → NULL,
    # which reads as "no template yet" and sends the admin through authoring one.
    ("roles", "template_token", "VARCHAR", None),
    # Pre-existing roles predate the mode choice → voice, today's behaviour.
    ("roles", "modality", "VARCHAR(16)", "'voice'"),
    # Role cadence templates. Every existing session predates this → false,
    # i.e. they all stay ordinary interviews.
    ("sessions", "is_template", "BOOLEAN", "false"),
    # Interviews predating the role-first flow have no owning role → NULL.
    ("sessions", "role_public_id", "VARCHAR", None),
    ("sessions", "candidate_public_id", "VARCHAR", None),
    # Candidate email, for the automated invite-link send (app/notifications).
    # Existing rows predate this column and have none — NULL is fine, they
    # just don't get an automated email (link is still copy-pasteable).
    ("sessions", "candidate_email", "VARCHAR(320)", None),
]


def _ensure_added_columns(engine) -> None:
    insp = inspect(engine)
    tables = set(insp.get_table_names())
    with engine.begin() as conn:
        for table, col, coltype, default in _ADDED_COLUMNS:
            if table not in tables:
                continue  # create_all just built it with the column present
            if col in {c["name"] for c in insp.get_columns(table)}:
                continue
            ddl = f"ALTER TABLE {table} ADD COLUMN {col} {coltype}"
            if default is not None:
                ddl += f" DEFAULT {default}"
            conn.exec_driver_sql(ddl)


def create_all() -> None:
    """Create any missing tables (idempotent) + add any columns introduced
    after a table's initial create. Dev/test convenience; Alembic owns the
    schema in production. Importing models registers them on Base first."""
    import db.models  # noqa: F401  (register mappers)

    engine = get_engine()
    Base.metadata.create_all(engine)
    _ensure_added_columns(engine)
